<?php
namespace local_aisgk\local;

defined('MOODLE_INTERNAL') || die();

use local_aisgk\book_repository;

class sgk_processor {
    public const COMPONENT = 'local_aisgk';
    public const FILEAREA = 'bookpdf';

    protected static function get_book_record(int $bookid): \stdClass {
        $book = book_repository::get_by_id($bookid);
        if (!$book) {
            throw new \moodle_exception('invalidparameter');
        }
        return $book;
    }

    protected static function get_book_file(int $bookid): \stored_file {
        $book = self::get_book_record($bookid);
        $context = \context_course::instance((int)$book->courseid);
        $fs = get_file_storage();
        $files = $fs->get_area_files($context->id, self::COMPONENT, self::FILEAREA, (int)$book->fileitemid, 'itemid, filepath, filename', false);
        foreach ($files as $file) {
            if (!$file->is_directory()) {
                return $file;
            }
        }
        throw new \moodle_exception('bookrequired', 'local_aisgk');
    }

    public static function get_temp_dir(int $courseid, int $bookid): string {
        global $CFG;
        $dir = $CFG->dataroot . '/local_aisgk/tmp/' . $courseid . '/' . $bookid;
        if (!is_dir($dir)) {
            mkdir($dir, $CFG->directorypermissions, true);
        }
        return $dir;
    }

    public static function clear_temp_dir(int $courseid, int $bookid): void {
        $dir = self::get_temp_dir($courseid, $bookid);
        foreach (glob($dir . '/*') ?: [] as $file) {
            @unlink($file);
        }
    }

    protected static function export_pdf_to_temp(int $bookid): string {
        $book = self::get_book_record($bookid);
        $storedfile = self::get_book_file($bookid);
        $dir = self::get_temp_dir((int)$book->courseid, $bookid);
        $pdfpath = $dir . '/book_' . $bookid . '.pdf';
        @unlink($pdfpath);
        $storedfile->copy_content_to($pdfpath);
        if (!is_file($pdfpath) || filesize($pdfpath) < 1) {
            throw new \moodle_exception('errorprocessingbook', 'local_aisgk');
        }
        return $pdfpath;
    }

    public static function get_source_images(int $courseid, int $bookid): array {
        $images = glob(self::get_temp_dir($courseid, $bookid) . '/' . $bookid . '_*.png') ?: [];
        $images = array_values(array_filter($images, static function(string $path): bool {
            return (bool)preg_match('/_\d+\.png$/', $path);
        }));
        natsort($images);
        return array_values($images);
    }

    public static function render_toc_images(int $bookid, int $frompage, int $topage, int $dpi = 200): array {
        $book = self::get_book_record($bookid);
        if ($frompage < 1 || $topage < $frompage) {
            throw new \invalid_parameter_exception('Khoảng trang không hợp lệ');
        }
        self::clear_temp_dir((int)$book->courseid, $bookid);
        $pdfpath = self::export_pdf_to_temp($bookid);
        $dir = self::get_temp_dir((int)$book->courseid, $bookid);
        return ocr_runner::render_pdf_pages($pdfpath, $dir, $bookid, $frompage, $topage, $dpi);
    }

    public static function preview_topic_items(int $bookid, int $columns = 1, int $psm = 4, ?int $frompage = null, ?int $topage = null): array {
        $book = self::get_book_record($bookid);
        $frompage = $frompage ?: (int)$book->tocfrompage;
        $topage = $topage ?: (int)$book->toctopage;
        self::render_toc_images($bookid, $frompage, $topage, 200);
        $images = self::get_source_images((int)$book->courseid, $bookid);
        if (!$images) {
            throw new \moodle_exception('bookimagesmissing', 'local_aisgk');
        }

        if ((int)$columns === 2) {
            return self::preview_topic_items_2col($images, max(6, min(13, $psm)));
        }

        $texts = ocr_runner::ocr_images($images, 1, 50, max(3, min(13, $psm)));
        $raw = implode("\n\n", $texts);
        $lines = self::normalize_lines($raw);
        $items = self::parse_bai_lines($lines);

        return [
            'raw' => $raw,
            'content_lines' => $lines,
            'matched_lines' => array_values(array_map(static fn($item) => $item['rawocr'], $items)),
            'items' => $items,
        ];
    }

    protected static function preview_topic_items_2col(array $images, int $psm = 6): array {
        $rawlines = [];
        $matched = [];
        $items = [];

        foreach ($images as $image) {
            $page = self::process_smart_2col_image($image, $psm);
            $rawlines = array_merge($rawlines, $page['raw_lines']);
            $matched = array_merge($matched, $page['matched_lines']);
            $items = array_merge($items, $page['items']);
        }

        return [
            'raw' => implode("\n", $rawlines),
            'content_lines' => array_values($rawlines),
            'matched_lines' => array_values($matched),
            'items' => self::normalize_item_sequence($items),
        ];
    }

    protected static function process_smart_2col_image(string $imagepath, int $psm = 6): array {
        $parts = ocr_runner::crop_detected_regions($imagepath);
        $left = self::process_half_2col($parts['l1'], $parts['l2'], $psm, 'l');
        $right = self::process_half_2col($parts['r1'], $parts['r2'], $psm, 'r');

        $leftitems = self::combine_pairs_to_items_2col($left['pairs']);
        $rightitems = self::combine_pairs_to_items_2col($right['pairs']);
        $items = array_merge($leftitems, $rightitems);
        $matched = array_values(array_map(static fn(array $item): string => (string)($item['rawocr'] ?? ''), $items));
        $rawlines = array_merge(
            array_values(array_map(static function(array $pair): string {
                return trim($pair['text'] . ($pair['page'] !== null ? ' ' . $pair['page'] : ''));
            }, $left['pairs'])),
            array_values(array_map(static function(array $pair): string {
                return trim($pair['text'] . ($pair['page'] !== null ? ' ' . $pair['page'] : ''));
            }, $right['pairs']))
        );

        return [
            'raw_lines' => $rawlines,
            'matched_lines' => $matched,
            'items' => self::normalize_item_sequence($items),
        ];
    }

    protected static function process_half_2col(string $titleimg, string $pageimg, int $psm = 6, string $halfname = 'l'): array {
        $titleentries = self::extract_title_entries_with_fallback_2col($titleimg, $psm, $halfname);
        $pageentries = self::extract_page_entries_with_fallback_2col($pageimg, 6, $halfname);
        $pairs = ocr_runner::pair_title_page_entries_by_y_2col($titleentries, $pageentries, 50);
        return [
            'title_entries' => $titleentries,
            'page_entries' => $pageentries,
            'pairs' => $pairs,
        ];
    }

    protected static function extract_title_entries_with_fallback_2col(string $titleimg, int $titlepsm = 6, string $halfname = 'l'): array {
        $variants = [
            ocr_runner::preprocess_title_image_2col($titleimg, $halfname . '1_title'),
            ocr_runner::preprocess_page_image_2col($titleimg, $halfname . '1_alt'),
        ];
        $best = [];
        foreach ($variants as $variant) {
            $entries = ocr_runner::ocr_tsv_exact($variant, 'vie+eng', $titlepsm);
            $entries = ocr_runner::merge_wrapped_title_entries_2col($entries);
            $entries = ocr_runner::filter_title_entry_lines_2col($entries);
            if (count($entries) > count($best)) {
                $best = $entries;
            }
            if (count($entries) >= 2) {
                break;
            }
        }
        return $best;
    }

    protected static function extract_page_entries_with_fallback_2col(string $pageimg, int $pagepsm = 6, string $halfname = 'l'): array {
        $invert = ocr_runner::page_region_should_invert_2col($pageimg);
        $workimg = ocr_runner::extract_real_page_band_by_two_peaks_2col($pageimg, $halfname . '2_band', $invert);
        $variants = [];
        $variants[] = $invert
            ? ocr_runner::preprocess_page_image_invert_2col($workimg, $halfname . '2_inv')
            : ocr_runner::preprocess_page_image_2col($workimg, $halfname . '2_page');
        $variants[] = ocr_runner::preprocess_page_image_strong_2col($workimg, $halfname . '2_strong');

        $best = [];
        foreach ($variants as $variant) {
            $entries = ocr_runner::ocr_tsv_exact($variant, 'eng', $pagepsm, '0123456789OolIsSBZT+');
            $entries = ocr_runner::filter_page_entry_lines_2col($entries);
            if (count($entries) > count($best)) {
                $best = $entries;
            }
            if (count($entries) >= 2) {
                break;
            }
        }
        return $best;
    }

    protected static function parse_title_line_2col(string $line): ?array {
        $line = trim((string)$line);
        if ($line === '') {
            return null;
        }
        $line = preg_replace('/\s+/u', ' ', $line);
        $raw = mb_substr($line, 0, 255);
        if (!preg_match('/^\p{Lu}/u', $line)) {
            return null;
        }
        if (preg_match('/^(chương|chuong|chủ\s*đề|chu\s*de|phần|phan)\s+[IVXLCDM]+\b/ui', $line)) {
            return null;
        }
        $lessonno = null;
        $lessontitle = $line;
        if (preg_match('/^(?:Bài|Bai|bài|bai)\s+(\d+)\.?\s*(.+)$/ui', $line, $m)) {
            $lessonno = (int)$m[1];
            $lessontitle = trim($m[2], " \t\n\r\0\x0B.-_|");
        }
        return [
            'lessonno' => $lessonno,
            'lessontitle' => $lessontitle,
            'startpage' => null,
            'endpage' => null,
            'rawocr' => $raw,
        ];
    }

    protected static function combine_pairs_to_items_2col(array $pairs): array {
        $items = [];
        foreach ($pairs as $pair) {
            $parsed = self::parse_title_line_2col((string)($pair['text'] ?? ''));
            if (!$parsed) {
                continue;
            }
            $parsed['startpage'] = $pair['page'] ?? null;
            $parsed['rawocr'] = trim($parsed['rawocr'] . ($parsed['startpage'] !== null ? ' ' . $parsed['startpage'] : ''));
            $items[] = $parsed;
        }
        return array_values($items);
    }

    protected static function normalize_item_sequence(array $items): array {
        $out = [];
        foreach ($items as $item) {
            if (trim((string)($item['lessontitle'] ?? '')) === '') {
                continue;
            }
            $out[] = $item;
        }
        return array_values($out);
    }

    protected static function normalize_lines(string $raw): array {
        $raw = preg_replace("/\r\n|\r/u", "\n", $raw);
        $lines = explode("\n", $raw);
        $lines = array_map(static function(string $line): string {
            $line = preg_replace('/\s+/u', ' ', trim($line));
            $line = preg_replace('/[.…·•]{2,}/u', ' ', $line);
            return trim($line);
        }, $lines);
        $lines = array_values(array_filter($lines, static fn($line) => $line !== ''));
        return self::merge_wrapped_lines($lines);
    }

    protected static function merge_wrapped_lines(array $lines): array {
        $merged = [];
        foreach ($lines as $line) {
            if (!$merged) {
                $merged[] = $line;
                continue;
            }
            $previndex = count($merged) - 1;
            $prev = $merged[$previndex];
            $append = false;
            if (preg_match('/^(và|của|trong|với|theo|ở|cho|về|từ)\b/ui', $line)) {
                $append = true;
            }
            if (preg_match('/^(\d{1,3})$/', $line)) {
                $merged[$previndex] = trim($prev . ' ' . $line);
                continue;
            }
            if ($append) {
                $merged[$previndex] = trim($prev . ' ' . $line);
                continue;
            }
            $merged[] = $line;
        }
        return $merged;
    }

    public static function is_target_line(string $line): bool {
        $line = trim(preg_replace('/\s+/u', ' ', $line));
        if ($line === '') {
            return false;
        }
        if (preg_match('/^(MỤC LỤC|MUC LUC|TRANG|Trang)$/iu', $line)) {
            return false;
        }
        return (bool)preg_match('/^(Bài\s+\d+|Chương\s+[IVX\d]+|CHƯƠNG\s+[IVX\d]+|Chủ\s*đề\b|Phần\b|Luyện tập|Ôn tập|Bài tập cuối chương|Hoạt động)\b/ui', $line);
    }

    public static function parse_bai_lines(array $lines): array {
        $items = [];
        foreach ($lines as $line) {
            if (!self::is_target_line($line)) {
                continue;
            }
            $line = preg_replace('/\s+/u', ' ', trim($line));
            $startpage = null;
            if (preg_match('/\b(\d{1,4})\s*$/u', $line, $m)) {
                $startpage = (int)$m[1];
                $line = trim(preg_replace('/\b\d{1,4}\s*$/u', '', $line));
            }
            $lessonno = null;
            $title = $line;
            if (preg_match('/^Bài\s+(\d+)\.?\s*(.*)$/ui', $line, $m)) {
                $lessonno = (int)$m[1];
                $title = trim($m[2]);
            }
            $items[] = [
                'lessonno' => $lessonno,
                'lessontitle' => $title,
                'startpage' => $startpage,
                'endpage' => null,
                'rawocr' => $line . ($startpage ? ' ' . $startpage : ''),
            ];
        }
        return $items;
    }
}
