<?php
require_once(__DIR__ . '/../../config.php');
require_once($CFG->dirroot . '/course/lib.php');
require_once(__DIR__ . '/locallib.php');

$id = required_param('id', PARAM_INT);
$mode = optional_param('mode', 'upload', PARAM_ALPHA);

$course = $DB->get_record('course', ['id' => $id], '*', MUST_EXIST);
require_login($course);

$context = context_course::instance($id);
require_capability('local/aisgk:manage', $context);

$PAGE->set_url('/local/aisgk/upload.php', ['id' => $id, 'mode' => $mode]);
$PAGE->set_context($context);
$PAGE->set_pagelayout('standard');
$PAGE->set_title(get_string('managerheading', 'local_aisgk'));
$PAGE->set_heading($course->fullname);

$envcheck = local_aisgk_check_environment();
$heading = $mode === 'homework' ? get_string('createhomework', 'local_aisgk') : get_string('uploadbook', 'local_aisgk');

echo $OUTPUT->header();
echo $OUTPUT->heading($heading, 3);

echo html_writer::start_div('alert alert-info');
echo 'Khóa học: ' . format_string($course->fullname) . '<br>';
echo 'Chế độ: ' . s($heading);
echo html_writer::end_div();

if ($envcheck !== true) {
    echo html_writer::div(s($envcheck), 'alert alert-danger');
} else {
    echo html_writer::div('Ghostscript và Tesseract đã sẵn sàng trên VPS.', 'alert alert-success');
}

echo html_writer::start_div('card');
echo html_writer::start_div('card-body');
echo '<form method="post" enctype="multipart/form-data">';
echo '<div class="mb-3">';
echo '<label class="form-label"><strong>Tệp PDF</strong></label>';
echo '<input type="file" name="bookpdf" accept="application/pdf" class="form-control">';
echo '</div>';
echo '<div class="mb-3">';
echo '<label class="form-label"><strong>Ghi chú</strong></label>';
echo '<textarea name="note" class="form-control" rows="4" placeholder="Nhập mô tả ngắn cho tác vụ này"></textarea>';
echo '</div>';
echo '<button type="submit" class="btn btn-success">Lưu và xử lý</button>';
echo '</form>';
echo html_writer::end_div();
echo html_writer::end_div();

echo $OUTPUT->footer();
