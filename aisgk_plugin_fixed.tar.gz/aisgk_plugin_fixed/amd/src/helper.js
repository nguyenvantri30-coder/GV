define(['jquery', 'core/modal_factory'], function($, ModalFactory) {
    return {
        init: function() {
            console.log("AISGK Helper: Đã nạp module thành công!");

            // Bắt sự kiện theo ID để không bao giờ sai lệch
            $(document).on('click', '#btn-aisgk-popup', function(e) {
                console.log("AISGK Helper: Đã bắt được sự kiện click!");
                e.preventDefault();
                e.stopPropagation();
                
                var targetUrl = $(this).attr('href');
                ModalFactory.create({
                    title: 'Hệ thống hỗ trợ AISGK',
                    body: '<iframe src="' + targetUrl + '" style="width:100%;height:500px;border:none;"></iframe>',
                    large: true
                }).done(function(modal) {
                    modal.show();
                });
                return false;
            });
        }
    };
});
