define(['jquery', 'core/url', 'core/notification', 'core/modal_factory'], function($, url, notification, modalFactory) {
    return {
        init: function(courseid) {
            // 1. Nút Tải SGK (Giữ nguyên để mở trang upload.php)
            const general = $('.sectionname:contains("General"), .sectionname:contains("Chung"), .section-title');
            if (general.length && !$('#btn-upload-sgk').length) {
                general.append('<a href="' + url.relativeUrl('/local/aisgk/upload.php', {id: courseid}) + '" class="btn btn-sm btn-primary ml-2" id="btn-upload-sgk">Tải SGK</a>');
            }

            // 2. Nút Tạo BTVN (Sửa lại để chạy ngầm)
            $('.activity-instance, .activity-basis').each(function() {
                if (!$(this).find('.btn-create-btvn').length) {
                    $(this).append('<button class="btn btn-xs btn-success ml-2 btn-create-btvn" style="font-size:10px; cursor:pointer;">Tạo BTVN</button>');
                }
            });

            // Xử lý sự kiện khi nhấn nút Tạo BTVN
            $('body').on('click', '.btn-create-btvn', function(e) {
                e.preventDefault(); // Ngăn không cho nhảy trang linh tinh
                e.stopPropagation();

                const lessonName = $(this).closest('.activity-instance').text().replace('Tạo BTVN', '').trim();

                notification.confirm(
                    'Xác nhận tạo bài tập',
                    'Bạn muốn hệ thống OCR quét nội dung cho bài: "' + lessonName + '"?',
                    'Bắt đầu quét',
                    'Hủy',
                    function() {
                        // Đây là nơi sau này mình sẽ gọi AJAX để chạy Ghostscript
                        notification.alert('Đang xử lý', 'VPS đang tách trang và OCR cho bài ' + lessonName + '. Vui lòng đợi...', 'OK');
                    }
                );
            });
        }
    };
});
