<?php
defined('MOODLE_INTERNAL') || die();

function local_aisgk_check_environment() {
    $required = [
        '/usr/bin/gs' => 'Ghostscript',
        '/usr/bin/tesseract' => 'Tesseract OCR',
    ];

    foreach ($required as $path => $name) {
        if (!file_exists($path)) {
            return "Thiếu {$name} tại {$path}";
        }
    }

    return true;
}
