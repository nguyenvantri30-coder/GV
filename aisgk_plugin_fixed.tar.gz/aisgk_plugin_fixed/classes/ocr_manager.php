﻿<?php
namespace local_aisgk;

class ocr_manager {
    public static function process_range($pdfpath, $start, $end) {
        $outdir = make_temp_directory('aisgk/ocr_' . uniqid());
        $gs_path = '/usr/bin/gs';
        $tess_path = '/usr/bin/tesseract';

        // Chỉ tách các trang cần thiết để nhẹ VPS (3GB RAM)
        $gs_cmd = "{$gs_path} -dNOPAUSE -dBATCH -sDEVICE=png16m -r200 -dFirstPage={$start} -dLastPage={$end} -sOutputFile={$outdir}/p%d.png " . escapeshellarg($pdfpath);
        exec($gs_cmd);

        $result = "";
        foreach (glob($outdir . "/*.png") as $img) {
            exec("{$tess_path} {$img} {$img} -l vie+eng");
            $result .= file_get_contents($img . ".txt") . "\n";
        }
        return $result;
    }
}