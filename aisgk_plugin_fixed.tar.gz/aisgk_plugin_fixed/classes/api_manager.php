<?php
namespace local_aisgk;

class api_manager {
    public static function can_proceed($userid) {
        global $DB;
        if (is_siteadmin($userid)) return true;
        
        $today = strtotime('today');
        $count = $DB->count_records_select('local_aisgk_log', 'userid = ? AND timecreated >= ?', [$userid, $today]);
        return ($count < 5);
    }

    public static function log_call($userid) {
        global $DB;
        $DB->insert_record('local_aisgk_log', (object)['userid' => $userid, 'timecreated' => time()]);
    }
}