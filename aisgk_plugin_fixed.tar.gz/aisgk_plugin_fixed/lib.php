<?php
defined('MOODLE_INTERNAL') || die();

function local_aisgk_before_footer() {
    global $PAGE, $OUTPUT;

    if (empty($PAGE->course) || empty($PAGE->context) || $PAGE->context->contextlevel != CONTEXT_COURSE) {
        return;
    }

    if ($PAGE->pagetype !== 'course-view') {
        return;
    }

    $context = context_course::instance($PAGE->course->id);
    if (!has_capability('local/aisgk:manage', $context)) {
        return;
    }

    $uploadurl = new moodle_url('/local/aisgk/upload.php', [
        'id' => $PAGE->course->id,
        'mode' => 'upload',
    ]);
    $homeworkurl = new moodle_url('/local/aisgk/upload.php', [
        'id' => $PAGE->course->id,
        'mode' => 'homework',
    ]);

    $html = html_writer::start_div('local-aisgk-toolbar');
    $html .= html_writer::link($uploadurl, get_string('uploadbook', 'local_aisgk'), [
        'class' => 'btn btn-primary me-2 local-aisgk-btn',
    ]);
    $html .= html_writer::link($homeworkurl, get_string('createhomework', 'local_aisgk'), [
        'class' => 'btn btn-success local-aisgk-btn',
    ]);
    $html .= html_writer::end_div();

    echo $html;
}
