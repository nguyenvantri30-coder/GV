<?php
$string['pluginname'] = 'AI SGK';
$string['aisgk:manage'] = 'Quản lý AI SGK trong khóa học';
$string['aisgk:view'] = 'Xem AI SGK';
$string['openmanager'] = 'Mở AI SGK';
$string['uploadbook'] = 'Tải SGK';
$string['createhomework'] = 'Tạo BTVN';
$string['managerheading'] = 'AI SGK cho khóa học';
$string['nomanagepermission'] = 'Bạn không có quyền quản lý AI SGK trong khóa học này.';
