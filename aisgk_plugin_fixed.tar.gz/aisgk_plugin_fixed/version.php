<?php
defined('MOODLE_INTERNAL') || die();

$plugin->version   = 2026041407;        // Phải là số nguyên tăng dần
$plugin->requires  = 2022111800;        // Yêu cầu Moodle 4.1 trở lên
$plugin->component = 'local_aisgk';     // Khai báo định danh plugin (Cực kỳ quan trọng)
$plugin->maturity  = MATURITY_STABLE;
$plugin->release   = '1.1';
