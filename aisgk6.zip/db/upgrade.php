<?php

defined('MOODLE_INTERNAL') || die();

function xmldb_local_aisgk_upgrade($oldversion) {
    global $DB;

    $dbman = $DB->get_manager();

    if ($oldversion < 2026041900) {
        $table = new xmldb_table('local_aisgk_books');

        $fields = [
            new xmldb_field('scanstatus', XMLDB_TYPE_CHAR, '20', null, XMLDB_NOTNULL, null, 'idle', 'usermodified'),
            new xmldb_field('scanmessage', XMLDB_TYPE_TEXT, null, null, null, null, null, 'scanstatus'),
            new xmldb_field('scansubmittedby', XMLDB_TYPE_INTEGER, '10', null, XMLDB_NOTNULL, null, 0, 'scanmessage'),
            new xmldb_field('scanstartedat', XMLDB_TYPE_INTEGER, '10', null, XMLDB_NOTNULL, null, 0, 'scansubmittedby'),
            new xmldb_field('scanfinishedat', XMLDB_TYPE_INTEGER, '10', null, XMLDB_NOTNULL, null, 0, 'scanstartedat'),
            new xmldb_field('lastscanitemcount', XMLDB_TYPE_INTEGER, '10', null, XMLDB_NOTNULL, null, 0, 'scanfinishedat'),
        ];

        foreach ($fields as $field) {
            if (!$dbman->field_exists($table, $field)) {
                $dbman->add_field($table, $field);
            }
        }

        upgrade_plugin_savepoint(true, 2026041900, 'local', 'aisgk');
    }

    if ($oldversion < 2026041902) {
        $table = new xmldb_table('local_aisgk_toc_draft');

        if (!$dbman->table_exists($table)) {
            $table->add_field('id', XMLDB_TYPE_INTEGER, '10', null, XMLDB_NOTNULL, XMLDB_SEQUENCE, null);
            $table->add_field('courseid', XMLDB_TYPE_INTEGER, '10', null, XMLDB_NOTNULL, null, 0);
            $table->add_field('userid', XMLDB_TYPE_INTEGER, '10', null, XMLDB_NOTNULL, null, 0);
            $table->add_field('sourcebookid', XMLDB_TYPE_INTEGER, '10', null, XMLDB_NOTNULL, null, 0);
            $table->add_field('sobai', XMLDB_TYPE_INTEGER, '10', null, XMLDB_NOTNULL, null, 0);
            $table->add_field('tenbai', XMLDB_TYPE_CHAR, '255', null, XMLDB_NOTNULL, null, '');
            $table->add_field('trang', XMLDB_TYPE_INTEGER, '10', null, null, null, null);
            $table->add_field('endtrang', XMLDB_TYPE_INTEGER, '10', null, null, null, null);
            $table->add_field('sortorder', XMLDB_TYPE_INTEGER, '10', null, XMLDB_NOTNULL, null, 0);
            $table->add_field('rawline', XMLDB_TYPE_TEXT, null, null, null, null, null);
            $table->add_field('timecreated', XMLDB_TYPE_INTEGER, '10', null, XMLDB_NOTNULL, null, 0);
            $table->add_field('timemodified', XMLDB_TYPE_INTEGER, '10', null, XMLDB_NOTNULL, null, 0);
            $table->add_field('usermodified', XMLDB_TYPE_INTEGER, '10', null, XMLDB_NOTNULL, null, 0);
            $table->add_key('primary', XMLDB_KEY_PRIMARY, ['id']);
            $table->add_index('courseuser_idx', XMLDB_INDEX_NOTUNIQUE, ['courseid', 'userid']);
            $dbman->create_table($table);
        }

        upgrade_plugin_savepoint(true, 2026041902, 'local', 'aisgk');
    }

    return true;
}
