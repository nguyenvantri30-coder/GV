<?php
namespace local_aisgk;

defined('MOODLE_INTERNAL') || die();

class toc_repository {
    public static function get_by_bookid(int $bookid): array {
        global $DB;
        return array_values($DB->get_records('local_aisgk_book_toc', ['bookid' => $bookid], 'sortorder ASC, id ASC'));
    }

    public static function replace_book_toc(int $bookid, array $rows): void {
        global $DB, $USER;

        $transaction = $DB->start_delegated_transaction();
        $DB->delete_records('local_aisgk_book_toc', ['bookid' => $bookid]);
        self::insert_rows('local_aisgk_book_toc', ['bookid' => $bookid], $rows, (int)$USER->id);
        $transaction->allow_commit();
    }

    public static function get_draft_rows(int $courseid, int $userid): array {
        global $DB;
        return array_values($DB->get_records('local_aisgk_toc_draft', ['courseid' => $courseid, 'userid' => $userid], 'sortorder ASC, id ASC'));
    }

    public static function has_draft_rows(int $courseid, int $userid): bool {
        global $DB;
        return $DB->record_exists('local_aisgk_toc_draft', ['courseid' => $courseid, 'userid' => $userid]);
    }

    public static function clear_draft_rows(int $courseid, int $userid): void {
        global $DB;
        $DB->delete_records('local_aisgk_toc_draft', ['courseid' => $courseid, 'userid' => $userid]);
    }

    public static function seed_draft_from_book(int $courseid, int $userid, int $bookid): void {
        if (self::has_draft_rows($courseid, $userid)) {
            return;
        }
        $rows = [];
        foreach (self::get_by_bookid($bookid) as $row) {
            $rows[] = [
                'sobai' => $row->sobai,
                'tenbai' => $row->tenbai,
                'trang' => $row->trang,
                'endtrang' => $row->endtrang,
                'rawline' => $row->rawline,
                'sourcebookid' => $bookid,
            ];
        }
        if ($rows) {
            self::replace_draft_rows($courseid, $userid, $rows);
        }
    }

    public static function replace_draft_rows(int $courseid, int $userid, array $rows): void {
        global $DB;
        $transaction = $DB->start_delegated_transaction();
        self::clear_draft_rows($courseid, $userid);
        self::insert_rows('local_aisgk_toc_draft', ['courseid' => $courseid, 'userid' => $userid], $rows, $userid);
        $transaction->allow_commit();
    }

    public static function append_draft_rows(int $courseid, int $userid, int $sourcebookid, array $rows): int {
        global $DB;
        $existing = self::get_draft_rows($courseid, $userid);
        $sortorder = count($existing) + 1;
        $now = time();
        $count = 0;

        foreach ($rows as $row) {
            $sobai = isset($row['sobai']) ? trim((string)$row['sobai']) : '';
            $tenbai = isset($row['tenbai']) ? trim((string)$row['tenbai']) : '';
            $trang = self::normalize_page($row['trang'] ?? null);
            $endtrang = self::normalize_page($row['endtrang'] ?? null);
            $rawline = isset($row['rawline']) ? trim((string)$row['rawline']) : '';

            if ($sobai === '' && $tenbai === '' && $trang === null && $endtrang === null && $rawline === '') {
                continue;
            }

            $record = new \stdClass();
            $record->courseid = $courseid;
            $record->userid = $userid;
            $record->sourcebookid = $sourcebookid;
            $record->sobai = is_numeric($sobai) ? (int)$sobai : 0;
            $record->tenbai = $tenbai;
            $record->trang = $trang;
            $record->endtrang = $endtrang;
            $record->sortorder = $sortorder++;
            $record->rawline = $rawline;
            $record->timecreated = $now;
            $record->timemodified = $now;
            $record->usermodified = $userid;
            $DB->insert_record('local_aisgk_toc_draft', $record);
            $count++;
        }

        return $count;
    }

    public static function calculate_end_pages(array $rows): array {
        $count = count($rows);
        for ($i = 0; $i < $count; $i++) {
            $current = $rows[$i];
            $currentend = self::normalize_page($current['endtrang'] ?? null);
            $currentstart = self::normalize_page($current['trang'] ?? null);
            if ($currentend !== null) {
                $rows[$i]['endtrang'] = $currentend;
                continue;
            }
            $nextstart = null;
            for ($j = $i + 1; $j < $count; $j++) {
                $candidate = self::normalize_page($rows[$j]['trang'] ?? null);
                if ($candidate !== null) {
                    $nextstart = $candidate;
                    break;
                }
            }
            if ($currentstart !== null && $nextstart !== null && $nextstart > $currentstart) {
                $rows[$i]['endtrang'] = $nextstart - 1;
            } else {
                $rows[$i]['endtrang'] = $currentend;
            }
        }
        return $rows;
    }

    protected static function insert_rows(string $table, array $scope, array $rows, int $userid): void {
        global $DB;

        $now = time();
        $sortorder = 1;
        foreach ($rows as $row) {
            $sobai = isset($row['sobai']) ? trim((string)$row['sobai']) : '';
            $tenbai = isset($row['tenbai']) ? trim((string)$row['tenbai']) : '';
            $trang = self::normalize_page($row['trang'] ?? null);
            $endtrang = self::normalize_page($row['endtrang'] ?? null);
            $rawline = isset($row['rawline']) ? trim((string)$row['rawline']) : '';

            if ($sobai === '' && $tenbai === '' && $trang === null && $endtrang === null && $rawline === '') {
                continue;
            }

            $record = (object)$scope;
            $record->sobai = is_numeric($sobai) ? (int)$sobai : 0;
            $record->tenbai = $tenbai;
            $record->trang = $trang;
            $record->endtrang = $endtrang;
            $record->sortorder = $sortorder++;
            $record->rawline = $rawline;
            $record->timecreated = $now;
            $record->timemodified = $now;
            $record->usermodified = $userid;

            if ($table === 'local_aisgk_book_toc') {
                $record->ismanual = 1;
            } else if ($table === 'local_aisgk_toc_draft') {
                $record->sourcebookid = (int)($row['sourcebookid'] ?? ($scope['sourcebookid'] ?? 0));
            }

            $DB->insert_record($table, $record);
        }
    }

    protected static function normalize_page($value): ?int {
        if ($value === null || $value === '') {
            return null;
        }
        if (!is_numeric($value)) {
            return null;
        }
        $page = (int)$value;
        return $page > 0 ? $page : null;
    }
}
