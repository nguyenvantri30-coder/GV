<?php
namespace local_aisgk\task;

defined('MOODLE_INTERNAL') || die();

use local_aisgk\book_repository;
use local_aisgk\local\service\scan_service;
use local_aisgk\local\sgk_processor;
use local_aisgk\toc_repository;

class scan_toc_task extends \core\task\adhoc_task {
    public function get_name(): string {
        return get_string('taskscantoc', 'local_aisgk');
    }

    public function execute() {
        $data = (object)$this->get_custom_data();
        $bookid = (int)($data->bookid ?? 0);
        $userid = (int)($data->userid ?? 0);
        $courseid = (int)($data->courseid ?? 0);
        $columns = ((int)($data->columns ?? 1) === 2) ? 2 : 1;
        $psm = max(3, min(13, (int)($data->psm ?? 4)));
        $frompage = max(1, (int)($data->frompage ?? 3));
        $topage = max($frompage, (int)($data->topage ?? $frompage));

        if ($bookid < 1 || $userid < 1) {
            return;
        }

        $book = book_repository::get_by_id($bookid);
        if (!$book) {
            return;
        }
        if ($courseid < 1) {
            $courseid = (int)$book->courseid;
        }

        scan_service::mark_running($bookid, $userid);

        try {
            $preview = sgk_processor::preview_topic_items($bookid, $columns, $psm, $frompage, $topage);
            $rows = [];
            foreach ($preview['items'] as $item) {
                $rows[] = [
                    'sobai' => $item['lessonno'] ?? '',
                    'tenbai' => $item['lessontitle'] ?? '',
                    'trang' => $item['startpage'] ?? '',
                    'endtrang' => $item['endpage'] ?? '',
                    'rawline' => $item['rawocr'] ?? '',
                ];
            }
            $rows = toc_repository::calculate_end_pages($rows);
            $added = toc_repository::append_draft_rows($courseid, $userid, $bookid, $rows);
            scan_service::mark_success($bookid, $userid, $added);
            scan_service::send_scan_message(
                $userid,
                get_string('scanresultsubjectsuccess', 'local_aisgk'),
                get_string('scanresultbodysuccess', 'local_aisgk', $added)
            );
        } catch (\Throwable $e) {
            scan_service::mark_error($bookid, $userid, $e->getMessage());
            scan_service::send_scan_message(
                $userid,
                get_string('scanresultsubjectfailed', 'local_aisgk'),
                get_string('scanresultbodyfailed', 'local_aisgk', $e->getMessage())
            );
            throw $e;
        }
    }
}
