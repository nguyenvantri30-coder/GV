<?php
namespace local_aisgk\local\service;

defined('MOODLE_INTERNAL') || die();

use local_aisgk\book_repository;
use local_aisgk\toc_repository;

class scan_service {
    public static function queue_toc_scan(int $bookid, int $userid, int $columns = 1, int $psm = 4, ?int $frompage = null, ?int $topage = null): void {
        global $DB;

        $book = book_repository::get_by_id($bookid);
        if (!$book) {
            throw new \moodle_exception('invalidparameter');
        }

        toc_repository::seed_draft_from_book((int)$book->courseid, $userid, $bookid);

        $frompage = $frompage ?: (int)$book->tocfrompage;
        $topage = $topage ?: (int)$book->toctopage;
        if ($frompage < 1 || $topage < $frompage) {
            throw new \invalid_parameter_exception('Khoảng trang mục lục không hợp lệ');
        }

        $DB->update_record('local_aisgk_books', (object)[
            'id' => $bookid,
            'scanstatus' => 'queued',
            'scanmessage' => '',
            'scansubmittedby' => $userid,
            'scanstartedat' => 0,
            'scanfinishedat' => 0,
            'lastscanitemcount' => 0,
            'timemodified' => time(),
            'usermodified' => $userid,
        ]);

        $task = new \local_aisgk\task\scan_toc_task();
        $task->set_component('local_aisgk');
        $task->set_custom_data([
            'bookid' => $bookid,
            'userid' => $userid,
            'courseid' => (int)$book->courseid,
            'columns' => ((int)$columns === 2) ? 2 : 1,
            'psm' => max(3, min(13, (int)$psm)),
            'frompage' => $frompage,
            'topage' => $topage,
        ]);
        \core\task\manager::queue_adhoc_task($task);
    }

    public static function mark_running(int $bookid, int $userid): void {
        global $DB;
        $DB->update_record('local_aisgk_books', (object)[
            'id' => $bookid,
            'scanstatus' => 'running',
            'scanmessage' => '',
            'scanstartedat' => time(),
            'timemodified' => time(),
            'usermodified' => $userid,
        ]);
    }

    public static function mark_success(int $bookid, int $userid, int $itemcount): void {
        global $DB;
        $DB->update_record('local_aisgk_books', (object)[
            'id' => $bookid,
            'scanstatus' => 'done',
            'scanmessage' => '',
            'scanfinishedat' => time(),
            'lastscanitemcount' => $itemcount,
            'timemodified' => time(),
            'usermodified' => $userid,
        ]);
    }

    public static function mark_error(int $bookid, int $userid, string $message): void {
        global $DB;
        $DB->update_record('local_aisgk_books', (object)[
            'id' => $bookid,
            'scanstatus' => 'failed',
            'scanmessage' => \core_text::substr(trim($message), 0, 1000),
            'scanfinishedat' => time(),
            'timemodified' => time(),
            'usermodified' => $userid,
        ]);
    }

    public static function send_scan_message(int $userid, string $subject, string $body): void {
        $message = new \core\message\message();
        $message->component = 'local_aisgk';
        $message->name = 'scanresult';
        $message->userfrom = \core_user::get_noreply_user();
        $message->userto = \core_user::get_user($userid);
        $message->subject = $subject;
        $message->fullmessage = $body;
        $message->fullmessageformat = FORMAT_PLAIN;
        $message->fullmessagehtml = \text_to_html($body, false, false, true);
        $message->smallmessage = $subject;
        $message->notification = 1;
        message_send($message);
    }
}
