<?php
require('../../config.php');

use local_aisgk\book_repository;
use local_aisgk\local\service\scan_service;
use local_aisgk\toc_repository;

$courseid = required_param('id', PARAM_INT);
$bookid = optional_param('bookid', 0, PARAM_INT);
$action = optional_param('action', '', PARAM_ALPHA);
$columns = optional_param('columns', 1, PARAM_INT);
$psm = optional_param('psm', 4, PARAM_INT);
$pagerange = trim(optional_param('pagerange', '3-4', PARAM_RAW_TRIMMED));

$course = get_course($courseid);
require_login($course);
$context = context_course::instance($courseid);
require_capability('local/aisgk:createtopic', $context);

$PAGE->set_context($context);
$PAGE->set_url('/local/aisgk/topic.php', ['id' => $courseid, 'bookid' => $bookid]);
$PAGE->set_pagelayout('embedded');
$PAGE->set_title(get_string('createtopic', 'local_aisgk'));

$books = book_repository::get_all_by_courseid($courseid);
if (!$books) {
    throw new moodle_exception('bookrequired', 'local_aisgk');
}
if ($bookid < 1) {
    $bookid = (int)reset($books)->id;
}
$book = book_repository::get_by_id($bookid);
if (!$book || (int)$book->courseid !== $courseid) {
    throw new moodle_exception('invalidparameter');
}

$booklabels = [];
foreach ($books as $b) {
    $booklabels[(int)$b->id] = '[' . (int)$b->id . '] ' . ($b->name ?: $b->filename);
}

$parsepagerange = static function(string $value, \stdClass $book): array {
    $value = trim($value);
    if ($value === '') {
        $from = (int)$book->tocfrompage;
        $to = (int)$book->toctopage;
    } else if (preg_match('/^(\d+)\s*[-,:;]\s*(\d+)$/', $value, $m)) {
        $from = (int)$m[1];
        $to = (int)$m[2];
    } else if (preg_match('/^(\d+)$/', $value, $m)) {
        $from = (int)$m[1];
        $to = $from;
    } else {
        throw new invalid_parameter_exception('Khoảng trang mục lục không hợp lệ. Ví dụ: 3-4');
    }
    if ($from < 1 || $to < $from) {
        throw new invalid_parameter_exception('Khoảng trang mục lục không hợp lệ. Ví dụ: 3-4');
    }
    return [$from, $to, ($from === $to ? (string)$from : ($from . '-' . $to))];
};
[$pagefrom, $pageto, $pagerange] = $parsepagerange($pagerange, $book);

if ($action === 'save' && confirm_sesskey() && data_submitted()) {
    $rows = [];
    $sobais = optional_param_array('sobai', [], PARAM_RAW_TRIMMED);
    $tenbais = optional_param_array('tenbai', [], PARAM_RAW_TRIMMED);
    $trangs = optional_param_array('trang', [], PARAM_RAW_TRIMMED);
    $endtrangs = optional_param_array('endtrang', [], PARAM_RAW_TRIMMED);
    $rawlines = optional_param_array('rawline', [], PARAM_RAW_TRIMMED);
    $sourcebookids = optional_param_array('sourcebookid', [], PARAM_INT);
    $max = max(count($sobais), count($tenbais), count($trangs), count($endtrangs), count($rawlines), count($sourcebookids));

    for ($i = 0; $i < $max; $i++) {
        $row = [
            'sobai' => $sobais[$i] ?? '',
            'tenbai' => $tenbais[$i] ?? '',
            'trang' => $trangs[$i] ?? '',
            'endtrang' => $endtrangs[$i] ?? '',
            'rawline' => $rawlines[$i] ?? '',
            'sourcebookid' => $sourcebookids[$i] ?? 0,
        ];
        if (trim(implode('', array_map('strval', $row))) === '') {
            continue;
        }
        $rows[] = $row;
    }

    $rows = toc_repository::calculate_end_pages($rows);
    toc_repository::replace_book_toc($bookid, $rows);
    toc_repository::clear_draft_rows($courseid, (int)$USER->id);
    redirect(
        new moodle_url('/local/aisgk/topic.php', ['id' => $courseid, 'bookid' => $bookid]),
        get_string('tocsaved', 'local_aisgk'),
        null,
        \core\output\notification::NOTIFY_SUCCESS
    );
}

if ($action === 'restore' && confirm_sesskey()) {
    toc_repository::clear_draft_rows($courseid, (int)$USER->id);
    toc_repository::seed_draft_from_book($courseid, (int)$USER->id, $bookid);
    redirect(
        new moodle_url('/local/aisgk/topic.php', ['id' => $courseid, 'bookid' => $bookid]),
        get_string('restoreddraft', 'local_aisgk'),
        null,
        \core\output\notification::NOTIFY_SUCCESS
    );
}

if ($action === 'scan' && confirm_sesskey()) {
    $scanbookid = required_param('bookid', PARAM_INT);
    $scanbook = book_repository::get_by_id($scanbookid);
    if (!$scanbook || (int)$scanbook->courseid !== $courseid) {
        throw new moodle_exception('invalidparameter');
    }
    [$pagefrom, $pageto, $pagerange] = $parsepagerange($pagerange, $scanbook);
    scan_service::queue_toc_scan($scanbookid, (int)$USER->id, $columns, $psm, $pagefrom, $pageto);
    redirect(
        new moodle_url('/local/aisgk/topic.php', ['id' => $courseid, 'bookid' => $scanbookid]),
        get_string('tocscanqueued', 'local_aisgk'),
        null,
        \core\output\notification::NOTIFY_SUCCESS
    );
}

$draftrows = toc_repository::get_draft_rows($courseid, (int)$USER->id);
$tocrows = $draftrows ?: toc_repository::get_by_bookid($bookid);
if (!$tocrows) {
    $tocrows[] = (object)[
        'sobai' => '',
        'tenbai' => '',
        'trang' => '',
        'endtrang' => '',
        'rawline' => '',
        'sourcebookid' => $bookid,
    ];
}

$statusmap = [
    'queued' => ['status-pending', '⏳ ' . get_string('scanstatusqueued', 'local_aisgk')],
    'running' => ['status-running', '⚙ ' . get_string('scanstatusrunning', 'local_aisgk')],
    'done' => ['status-done', '✓ ' . get_string('scanstatusdone', 'local_aisgk', (int)($book->lastscanitemcount ?? 0))],
    'failed' => ['status-failed', '✕ ' . format_string(get_string('scanstatusfailed', 'local_aisgk', s((string)($book->scanmessage ?? ''))))],
    'idle' => ['status-idle', get_string('scanstatusidle', 'local_aisgk')],
];
[$statusclass, $statustext] = $statusmap[$book->scanstatus ?? 'idle'] ?? $statusmap['idle'];
$hasdraft = !empty($draftrows);

$PAGE->requires->js_init_code("(function(){var s=" . json_encode($book->scanstatus ?? 'idle') . ";if(s==='queued'||s==='running'){setTimeout(function(){window.location.reload();},5000);}})();");

echo $OUTPUT->header();
?>
<style>
.local-aisgk-topic-manager{padding:8px 10px 6px;font-size:12px;line-height:1.2}
.local-aisgk-headerline{display:flex;gap:8px;align-items:center;justify-content:space-between;flex-wrap:wrap;margin-bottom:6px}
.local-aisgk-titlemini{font-weight:700;font-size:13px}
.local-aisgk-badges{display:flex;gap:6px;align-items:center;flex-wrap:wrap}
.local-aisgk-badge{display:inline-flex;align-items:center;gap:4px;padding:3px 8px;border-radius:999px;background:#eef2f7;font-size:11px}
.local-aisgk-badge.status-pending{background:#dbeafe;color:#1d4ed8}
.local-aisgk-badge.status-running{background:#fef3c7;color:#92400e}
.local-aisgk-badge.status-done{background:#dcfce7;color:#166534}
.local-aisgk-badge.status-failed{background:#fee2e2;color:#991b1b}
.local-aisgk-badge.status-idle{background:#eef2f7;color:#475569}
.local-aisgk-badge.is-draft{background:#ede9fe;color:#6d28d9}
.local-aisgk-toolbar{display:flex;gap:6px;align-items:center;flex-wrap:wrap;margin-bottom:6px}
.local-aisgk-toolbar .fitem{display:flex;align-items:center;gap:4px}
.local-aisgk-toolbar label{margin:0;font-size:12px;font-weight:600}
.local-aisgk-toolbar select,.local-aisgk-toolbar input{font-size:12px;padding:2px 6px;height:30px}
.local-aisgk-toolbar .btn{padding:4px 10px;height:30px}
.local-aisgk-table-wrap{overflow:auto;max-height:49vh;border:1px solid #dbe3ea;border-radius:6px;background:#fff}
.local-aisgk-toc-table{width:100%;min-width:860px;border-collapse:collapse;table-layout:auto}
.local-aisgk-toc-table th,.local-aisgk-toc-table td{border:1px solid #e5e7eb;padding:3px 4px;vertical-align:top;font-size:12px}
.local-aisgk-toc-table th{background:#f8f9fa;position:sticky;top:0;z-index:2;white-space:nowrap}
.local-aisgk-toc-table input[type="text"],.local-aisgk-toc-table input[type="number"]{width:100%;box-sizing:border-box;font-size:12px;padding:3px 5px;height:28px}
.local-aisgk-col-mini{width:34px;text-align:center}
.local-aisgk-col-auto{width:1%;white-space:nowrap}
.local-aisgk-col-source{width:58px;max-width:58px;text-align:center}
.local-aisgk-col-title{min-width:320px;width:auto}
.local-aisgk-col-title input{min-width:320px}
.local-aisgk-header-action{cursor:pointer;color:#0f6cbf;text-decoration:underline}
.local-aisgk-row-action{display:inline-flex;align-items:center;justify-content:center;width:22px;height:22px;border:1px solid #b8c4ce;border-radius:4px;background:#fff;cursor:pointer;font-weight:700;line-height:1}
.local-aisgk-row-action:hover{background:#f1f5f9}
.local-aisgk-source-pill{display:inline-block;max-width:58px;overflow:hidden;text-overflow:ellipsis;white-space:nowrap;font-size:11px}
.local-aisgk-row-error td{background:#fff1f2}
.local-aisgk-row-error input{border-color:#ef4444}
.local-aisgk-sticky-save{position:sticky;bottom:0;display:flex;justify-content:flex-end;gap:8px;padding:6px 0 0;background:linear-gradient(to top,#fff 70%,rgba(255,255,255,0))}
</style>
<div class="local-aisgk-topic-manager">
    <div class="local-aisgk-headerline">
        <div class="local-aisgk-titlemini"><?php echo s(get_string('createtopic', 'local_aisgk')); ?></div>
        <div class="local-aisgk-badges">
            <span class="local-aisgk-badge <?php echo $statusclass; ?>" id="local-aisgk-status-badge"><?php echo $statustext; ?></span>
            <?php if ($hasdraft): ?><span class="local-aisgk-badge is-draft"><?php echo s(get_string('draftshown', 'local_aisgk')); ?></span><?php endif; ?>
        </div>
    </div>

    <form method="get" action="<?php echo new moodle_url('/local/aisgk/topic.php'); ?>" class="local-aisgk-toolbar">
        <input type="hidden" name="id" value="<?php echo (int)$courseid; ?>">
        <div class="fitem">
            <label for="id_bookid"><?php echo s(get_string('bookselect', 'local_aisgk')); ?></label>
            <select id="id_bookid" name="bookid">
                <?php foreach ($books as $option): ?>
                    <option value="<?php echo (int)$option->id; ?>" <?php echo ((int)$option->id === (int)$bookid) ? 'selected' : ''; ?>><?php echo s($booklabels[(int)$option->id]); ?></option>
                <?php endforeach; ?>
            </select>
        </div>
        <button type="submit" class="btn btn-secondary"><?php echo s(get_string('viewchange', 'local_aisgk')); ?></button>
    </form>

    <form method="post" action="<?php echo new moodle_url('/local/aisgk/topic.php', ['id' => $courseid, 'bookid' => $bookid, 'action' => 'scan']); ?>" class="local-aisgk-toolbar" id="local-aisgk-scan-form">
        <input type="hidden" name="sesskey" value="<?php echo sesskey(); ?>">
        <input type="hidden" name="bookid" value="<?php echo (int)$bookid; ?>">
        <div class="fitem">
            <label for="id_columns">Cột</label>
            <select id="id_columns" name="columns">
                <option value="1" <?php echo ((int)$columns === 1) ? 'selected' : ''; ?>>1</option>
                <option value="2" <?php echo ((int)$columns === 2) ? 'selected' : ''; ?>>2</option>
            </select>
        </div>
        <div class="fitem">
            <label for="id_psm">PSM</label>
            <input type="number" id="id_psm" name="psm" min="3" max="13" value="<?php echo (int)$psm; ?>">
        </div>
        <div class="fitem">
            <label for="id_pagerange">Page</label>
            <input type="text" id="id_pagerange" name="pagerange" value="<?php echo s($pagerange); ?>" size="6" placeholder="3-4">
        </div>
        <button type="submit" class="btn btn-primary" id="local-aisgk-scan-btn"><?php echo s(get_string('scantoc', 'local_aisgk')); ?></button>
        <button type="button" class="btn btn-secondary" id="local-aisgk-validate-btn"><?php echo s(get_string('validatetoc', 'local_aisgk')); ?></button>
        <button type="button" class="btn btn-secondary" id="local-aisgk-spell-btn"><?php echo s(get_string('spellfixtoc', 'local_aisgk')); ?></button>
    </form>

    <form method="post" action="<?php echo new moodle_url('/local/aisgk/topic.php', ['id' => $courseid, 'bookid' => $bookid, 'action' => 'save']); ?>" id="local-aisgk-save-form">
        <input type="hidden" name="sesskey" value="<?php echo sesskey(); ?>">
        <div class="local-aisgk-toolbar">
            <button type="submit" class="btn btn-success"><?php echo s(get_string('savechanges', 'local_aisgk')); ?></button>
            <button type="button" class="btn btn-secondary" id="local-aisgk-restore-btn"><?php echo s(get_string('restoretoc', 'local_aisgk')); ?></button>
            <span id="local-aisgk-check-result" style="font-size:11px;color:#64748b"></span>
        </div>
        <div class="local-aisgk-table-wrap">
            <table class="local-aisgk-toc-table" id="local-aisgk-toc-table">
                <thead>
                <tr>
                    <th class="local-aisgk-col-mini">#</th>
                    <th class="local-aisgk-col-mini">+</th>
                    <th class="local-aisgk-col-auto"><?php echo s(get_string('sobai', 'local_aisgk')); ?></th>
                    <th class="local-aisgk-col-title"><?php echo s(get_string('tenbai', 'local_aisgk')); ?></th>
                    <th class="local-aisgk-col-auto"><?php echo s(get_string('trangbatdau', 'local_aisgk')); ?></th>
                    <th class="local-aisgk-col-auto"><?php echo s(get_string('trangketthuc', 'local_aisgk')); ?></th>
                    <th class="local-aisgk-col-source"><?php echo s(get_string('sourcebook', 'local_aisgk')); ?></th>
                    <th class="local-aisgk-col-mini"><span id="local-aisgk-clear-all" class="local-aisgk-header-action"><?php echo s(get_string('deleteall', 'local_aisgk')); ?></span></th>
                </tr>
                </thead>
                <tbody>
                <?php foreach ($tocrows as $i => $row): $sourcebookid = (int)($row->sourcebookid ?? $bookid); ?>
                    <tr>
                        <td class="local-aisgk-rownum"><?php echo $i + 1; ?></td>
                        <td style="text-align:center"><button type="button" class="local-aisgk-row-action local-aisgk-add-row">+</button></td>
                        <td><input type="number" name="sobai[<?php echo $i; ?>]" value="<?php echo s((string)$row->sobai); ?>"></td>
                        <td>
                            <input type="text" name="tenbai[<?php echo $i; ?>]" value="<?php echo s((string)$row->tenbai); ?>" spellcheck="true">
                            <input type="hidden" name="rawline[<?php echo $i; ?>]" value="<?php echo s((string)($row->rawline ?? '')); ?>">
                            <input type="hidden" name="sourcebookid[<?php echo $i; ?>]" value="<?php echo $sourcebookid; ?>">
                        </td>
                        <td><input type="number" name="trang[<?php echo $i; ?>]" value="<?php echo s((string)$row->trang); ?>"></td>
                        <td><input type="number" name="endtrang[<?php echo $i; ?>]" value="<?php echo s((string)$row->endtrang); ?>"></td>
                        <td style="text-align:center"><span class="local-aisgk-source-pill" title="<?php echo s($booklabels[$sourcebookid] ?? ''); ?>"><?php echo s($booklabels[$sourcebookid] ?? ''); ?></span></td>
                        <td style="text-align:center"><input type="checkbox" class="local-aisgk-delete-now" title="Xóa dòng"></td>
                    </tr>
                <?php endforeach; ?>
                </tbody>
            </table>
        </div>
        <div class="local-aisgk-sticky-save">
            <button type="submit" class="btn btn-success"><?php echo s(get_string('savechanges', 'local_aisgk')); ?></button>
            <button type="button" class="btn btn-secondary" id="local-aisgk-restore-btn-2"><?php echo s(get_string('restoretoc', 'local_aisgk')); ?></button>
        </div>
    </form>

    <form method="post" action="<?php echo new moodle_url('/local/aisgk/topic.php', ['id' => $courseid, 'bookid' => $bookid, 'action' => 'restore']); ?>" id="local-aisgk-restore-form" style="display:none">
        <input type="hidden" name="sesskey" value="<?php echo sesskey(); ?>">
    </form>
</div>
<script>
(function(){
    const table = document.getElementById('local-aisgk-toc-table');
    const tbody = table.querySelector('tbody');
    const saveForm = document.getElementById('local-aisgk-save-form');
    const scanForm = document.getElementById('local-aisgk-scan-form');
    const scanBtn = document.getElementById('local-aisgk-scan-btn');
    const checkResult = document.getElementById('local-aisgk-check-result');
    const bookLabels = <?php echo json_encode($booklabels, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES); ?>;
    const currentBookId = <?php echo (int)$bookid; ?>;

    function refreshIndexes() {
        Array.from(tbody.querySelectorAll('tr')).forEach((tr, index) => {
            tr.querySelector('.local-aisgk-rownum').textContent = String(index + 1);
            ['sobai','tenbai','trang','endtrang','rawline','sourcebookid'].forEach(name => {
                tr.querySelectorAll('[name^="' + name + '["]').forEach(el => {
                    el.name = name + '[' + index + ']';
                });
            });
        });
    }

    function esc(value) {
        return String(value || '').replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;').replace(/"/g, '&quot;');
    }

    function createRow(data) {
        data = data || {};
        const sourcebookid = String(data.sourcebookid || currentBookId);
        const sourceTitle = bookLabels[sourcebookid] || '';
        const tr = document.createElement('tr');
        tr.innerHTML = '<td class="local-aisgk-rownum"></td>' +
            '<td style="text-align:center"><button type="button" class="local-aisgk-row-action local-aisgk-add-row">+</button></td>' +
            '<td><input type="number" name="sobai[]" value="' + esc(data.sobai) + '"></td>' +
            '<td><input type="text" name="tenbai[]" value="' + esc(data.tenbai) + '" spellcheck="true">' +
                '<input type="hidden" name="rawline[]" value="' + esc(data.rawline) + '">' +
                '<input type="hidden" name="sourcebookid[]" value="' + esc(sourcebookid) + '"></td>' +
            '<td><input type="number" name="trang[]" value="' + esc(data.trang) + '"></td>' +
            '<td><input type="number" name="endtrang[]" value="' + esc(data.endtrang) + '"></td>' +
            '<td style="text-align:center"><span class="local-aisgk-source-pill" title="' + esc(sourceTitle) + '">' + esc(sourceTitle) + '</span></td>' +
            '<td style="text-align:center"><input type="checkbox" class="local-aisgk-delete-now" title="Xóa dòng"></td>';
        return tr;
    }

    function ensureOneEmptyRow() {
        if (!tbody.querySelector('tr')) {
            tbody.appendChild(createRow({sourcebookid: currentBookId}));
            refreshIndexes();
        }
    }

    function clearErrors() {
        tbody.querySelectorAll('tr').forEach(tr => tr.classList.remove('local-aisgk-row-error'));
        tbody.querySelectorAll('input').forEach(el => el.removeAttribute('title'));
    }

    function runValidation(showMessage) {
        clearErrors();
        let errors = 0;
        const lastBySource = {};
        Array.from(tbody.querySelectorAll('tr')).forEach(tr => {
            const source = (tr.querySelector('[name^="sourcebookid["]') || {}).value || '0';
            const titleEl = tr.querySelector('[name^="tenbai["]');
            const startEl = tr.querySelector('[name^="trang["]');
            const endEl = tr.querySelector('[name^="endtrang["]');
            const title = (titleEl.value || '').trim();
            const start = startEl.value !== '' ? parseInt(startEl.value, 10) : null;
            const end = endEl.value !== '' ? parseInt(endEl.value, 10) : null;
            const notes = [];
            if (title !== '' || start !== null || end !== null) {
                if (start === null) { notes.push('Thiếu trang bắt đầu'); }
                if (end === null) { notes.push('Thiếu trang kết thúc'); }
                if (start !== null && end !== null && start > end) { notes.push('Trang bắt đầu lớn hơn trang kết thúc'); }
                if (start !== null && lastBySource[source] !== undefined && start <= lastBySource[source]) {
                    notes.push('Trong cùng nguồn, trang bắt đầu phải tăng dần');
                }
                if (start !== null) { lastBySource[source] = start; }
            }
            if (notes.length) {
                errors++;
                tr.classList.add('local-aisgk-row-error');
                [titleEl, startEl, endEl].forEach(el => el.title = notes.join('; '));
            }
        });
        if (showMessage) {
            checkResult.textContent = errors ? ('Có ' + errors + ' dòng cần sửa.') : 'Mục lục hợp lệ.';
        }
        return errors === 0;
    }

    function normalizeText(text) {
        return String(text || '')
            .replace(/[|]/g, 'I')
            .replace(/\s+/g, ' ')
            .replace(/\s*([,:;\.])\s*/g, '$1 ')
            .replace(/^\s+|\s+$/g, '');
    }

    function applySpellFix() {
        tbody.querySelectorAll('input[name^="tenbai["]').forEach(input => {
            let value = normalizeText(input.value);
            value = value.replace(/\bdu lieu\b/gi, 'dữ liệu');
            value = value.replace(/\bthong tin\b/gi, 'thông tin');
            value = value.replace(/\bkhoa hoc\b/gi, 'khoa học');
            value = value.replace(/\bva\b/gi, 'và');
            input.value = value;
        });
        checkResult.textContent = 'Đã chuẩn hóa nhanh lỗi OCR thường gặp.';
    }

    tbody.addEventListener('click', function(e) {
        const btn = e.target.closest('.local-aisgk-add-row');
        if (!btn) { return; }
        const tr = btn.closest('tr');
        const sourcebookid = (tr.querySelector('[name^="sourcebookid["]') || {}).value || currentBookId;
        tr.parentNode.insertBefore(createRow({sourcebookid: sourcebookid}), tr.nextSibling);
        refreshIndexes();
    });

    tbody.addEventListener('change', function(e) {
        if (e.target.classList.contains('local-aisgk-delete-now') && e.target.checked) {
            e.target.closest('tr').remove();
            ensureOneEmptyRow();
            refreshIndexes();
            runValidation(false);
        }
    });

    document.getElementById('local-aisgk-clear-all').addEventListener('click', function() {
        tbody.innerHTML = '';
        ensureOneEmptyRow();
        checkResult.textContent = '';
    });

    document.getElementById('local-aisgk-validate-btn').addEventListener('click', function() { runValidation(true); });
    document.getElementById('local-aisgk-spell-btn').addEventListener('click', applySpellFix);
    function restoreDraft() {
        if (confirm('Bỏ mọi chỉnh sửa draft và tải lại bản đã lưu?')) {
            document.getElementById('local-aisgk-restore-form').submit();
        }
    }
    document.getElementById('local-aisgk-restore-btn').addEventListener('click', restoreDraft);
    document.getElementById('local-aisgk-restore-btn-2').addEventListener('click', restoreDraft);

    scanForm.addEventListener('submit', function() {
        scanBtn.disabled = true;
        scanBtn.textContent = 'Đang quét...';
        document.getElementById('local-aisgk-status-badge').textContent = '⚙ Đang đẩy vào hàng đợi...';
    });

    saveForm.addEventListener('submit', function(e) {
        if (!runValidation(true) && !confirm('Bảng còn lỗi. Vẫn lưu?')) {
            e.preventDefault();
        }
    });
})();
</script>
<?php
echo $OUTPUT->footer();
