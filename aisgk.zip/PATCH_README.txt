Patch nhỏ chỉ sửa prompt TOC, dùng trên nền aisgk_latest_ai_score_keep_phan_mem_fix_v2026053011.zip.
Mục tiêu: không rollback ai_score hoặc các fix khác.

Cách áp dụng:
1) Giải nén/copy patch này lên server.
2) Chạy:
   cd /var/www/html/moodle/local/aisgk
   patch -p0 < /path/to/toc_prompt_safe.patch
   php /var/www/html/moodle/admin/cli/purge_caches.php

Nếu patch báo fail do prompt đã khác, tìm block trong classes/local/ai_service.php gần extract_toc_from_images() và thay đúng 3 dòng cũ bằng 4 dòng mới trong file .patch.
