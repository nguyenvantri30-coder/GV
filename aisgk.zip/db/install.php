<?php

defined('MOODLE_INTERNAL') || die();

/**
 * Create ALSM school-operation roles on fresh installs.
 */
function xmldb_local_aisgk_install() {
    require_once(__DIR__ . '/upgrade.php');
    local_aisgk_ensure_alsm_roles();
}
