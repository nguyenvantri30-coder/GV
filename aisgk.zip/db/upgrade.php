<?php

defined('MOODLE_INTERNAL') || die();

function xmldb_local_aisgk_upgrade($oldversion) {
    global $DB;

    $dbman = $DB->get_manager();

    if ($oldversion < 2026041600) {
        $table = new xmldb_table('local_aisgk_books');

        $field = new xmldb_field('name', XMLDB_TYPE_CHAR, '255', null, XMLDB_NOTNULL, null, '', 'courseid');
        if (!$dbman->field_exists($table, $field)) {
            $dbman->add_field($table, $field);
        }

        $field = new xmldb_field('sortorder', XMLDB_TYPE_INTEGER, '10', null, XMLDB_NOTNULL, null, 0, 'fileitemid');
        if (!$dbman->field_exists($table, $field)) {
            $dbman->add_field($table, $field);
        }

        $field = new xmldb_field('tocfrompage', XMLDB_TYPE_INTEGER, '10', null, XMLDB_NOTNULL, null, 4, 'sortorder');
        if (!$dbman->field_exists($table, $field)) {
            $dbman->add_field($table, $field);
        }

        $field = new xmldb_field('toctopage', XMLDB_TYPE_INTEGER, '10', null, XMLDB_NOTNULL, null, 5, 'tocfrompage');
        if (!$dbman->field_exists($table, $field)) {
            $dbman->add_field($table, $field);
        }

        $index = new xmldb_index('courseid_uix', XMLDB_INDEX_UNIQUE, ['courseid']);
        if ($dbman->index_exists($table, $index)) {
            $dbman->drop_index($table, $index);
        }

        $index = new xmldb_index('courseid_idx', XMLDB_INDEX_NOTUNIQUE, ['courseid']);
        if (!$dbman->index_exists($table, $index)) {
            $dbman->add_index($table, $index);
        }

        $toc = new xmldb_table('local_aisgk_book_toc');
        if (!$dbman->table_exists($toc)) {
            $toc->add_field('id', XMLDB_TYPE_INTEGER, '10', null, XMLDB_NOTNULL, XMLDB_SEQUENCE, null);
            $toc->add_field('bookid', XMLDB_TYPE_INTEGER, '10', null, XMLDB_NOTNULL, null, 0);
            $toc->add_field('sobai', XMLDB_TYPE_INTEGER, '10', null, XMLDB_NOTNULL, null, 0);
            $toc->add_field('tenbai', XMLDB_TYPE_CHAR, '255', null, XMLDB_NOTNULL, null, '');
            $toc->add_field('trang', XMLDB_TYPE_INTEGER, '10', null, null, null, null);
            $toc->add_field('endtrang', XMLDB_TYPE_INTEGER, '10', null, null, null, null);
            $toc->add_field('sortorder', XMLDB_TYPE_INTEGER, '10', null, XMLDB_NOTNULL, null, 0);
            $toc->add_field('ismanual', XMLDB_TYPE_INTEGER, '1', null, XMLDB_NOTNULL, null, 0);
            $toc->add_field('rawline', XMLDB_TYPE_TEXT, null, null, null, null, null);
            $toc->add_field('timecreated', XMLDB_TYPE_INTEGER, '10', null, XMLDB_NOTNULL, null, 0);
            $toc->add_field('timemodified', XMLDB_TYPE_INTEGER, '10', null, XMLDB_NOTNULL, null, 0);
            $toc->add_field('usermodified', XMLDB_TYPE_INTEGER, '10', null, XMLDB_NOTNULL, null, 0);
            $toc->add_key('primary', XMLDB_KEY_PRIMARY, ['id']);
            $toc->add_index('bookid_idx', XMLDB_INDEX_NOTUNIQUE, ['bookid']);
            $dbman->create_table($toc);
        }

        upgrade_plugin_savepoint(true, 2026041600, 'local', 'aisgk');
    }

    if ($oldversion < 2026041601) {
        upgrade_plugin_savepoint(true, 2026041601, 'local', 'aisgk');
    }


    if ($oldversion < 2026041918) {
        $draft = new xmldb_table('local_aisgk_book_toc_draft');
        if (!$dbman->table_exists($draft)) {
            $draft->add_field('id', XMLDB_TYPE_INTEGER, '10', null, XMLDB_NOTNULL, XMLDB_SEQUENCE, null);
            $draft->add_field('courseid', XMLDB_TYPE_INTEGER, '10', null, XMLDB_NOTNULL, null, 0);
            $draft->add_field('bookid', XMLDB_TYPE_INTEGER, '10', null, XMLDB_NOTNULL, null, 0);
            $draft->add_field('sobai', XMLDB_TYPE_INTEGER, '10', null, XMLDB_NOTNULL, null, 0);
            $draft->add_field('tenbai', XMLDB_TYPE_CHAR, '255', null, XMLDB_NOTNULL, null, '');
            $draft->add_field('trang', XMLDB_TYPE_INTEGER, '10', null, null, null, null);
            $draft->add_field('endtrang', XMLDB_TYPE_INTEGER, '10', null, null, null, null);
            $draft->add_field('sortorder', XMLDB_TYPE_INTEGER, '10', null, XMLDB_NOTNULL, null, 0);
            $draft->add_field('rawline', XMLDB_TYPE_TEXT, null, null, null, null, null);
            $draft->add_field('timecreated', XMLDB_TYPE_INTEGER, '10', null, XMLDB_NOTNULL, null, 0);
            $draft->add_field('timemodified', XMLDB_TYPE_INTEGER, '10', null, XMLDB_NOTNULL, null, 0);
            $draft->add_field('usermodified', XMLDB_TYPE_INTEGER, '10', null, XMLDB_NOTNULL, null, 0);
            $draft->add_key('primary', XMLDB_KEY_PRIMARY, ['id']);
            $draft->add_index('courseid_idx', XMLDB_INDEX_NOTUNIQUE, ['courseid']);
            $draft->add_index('bookid_idx', XMLDB_INDEX_NOTUNIQUE, ['bookid']);
            $dbman->create_table($draft);
        }

        upgrade_plugin_savepoint(true, 2026041918, 'local', 'aisgk');
    }

    return true;
}
