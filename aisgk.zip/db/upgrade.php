<?php

defined('MOODLE_INTERNAL') || die();

function xmldb_local_aisgk_upgrade($oldversion) {
    global $DB;

    $dbman = $DB->get_manager();

    if ($oldversion < 2026041900) {
        $table = new xmldb_table('local_aisgk_books');

        $fields = [
            new xmldb_field('scanstatus', XMLDB_TYPE_CHAR, '20', null, XMLDB_NOTNULL, null, 'idle', 'usermodified'),
            new xmldb_field('scanmessage', XMLDB_TYPE_TEXT, null, null, null, null, null, 'scanstatus'),
            new xmldb_field('scansubmittedby', XMLDB_TYPE_INTEGER, '10', null, XMLDB_NOTNULL, null, 0, 'scanmessage'),
            new xmldb_field('scanstartedat', XMLDB_TYPE_INTEGER, '10', null, XMLDB_NOTNULL, null, 0, 'scansubmittedby'),
            new xmldb_field('scanfinishedat', XMLDB_TYPE_INTEGER, '10', null, XMLDB_NOTNULL, null, 0, 'scanstartedat'),
            new xmldb_field('lastscanitemcount', XMLDB_TYPE_INTEGER, '10', null, XMLDB_NOTNULL, null, 0, 'scanfinishedat'),
        ];

        foreach ($fields as $field) {
            if (!$dbman->field_exists($table, $field)) {
                $dbman->add_field($table, $field);
            }
        }

        upgrade_plugin_savepoint(true, 2026041900, 'local', 'aisgk');
    }

    if ($oldversion < 2026041915) {
        $table = new xmldb_table('local_aisgk_book_toc_draft');

        if (!$dbman->table_exists($table)) {
            $table->add_field('id', XMLDB_TYPE_INTEGER, '10', null, XMLDB_NOTNULL, XMLDB_SEQUENCE, null);
            $table->add_field('bookid', XMLDB_TYPE_INTEGER, '10', null, XMLDB_NOTNULL, null, 0);
            $table->add_field('sobai', XMLDB_TYPE_INTEGER, '10', null, XMLDB_NOTNULL, null, 0);
            $table->add_field('tenbai', XMLDB_TYPE_CHAR, '255', null, XMLDB_NOTNULL, null, '');
            $table->add_field('trang', XMLDB_TYPE_INTEGER, '10', null, null, null, null);
            $table->add_field('endtrang', XMLDB_TYPE_INTEGER, '10', null, null, null, null);
            $table->add_field('sortorder', XMLDB_TYPE_INTEGER, '10', null, XMLDB_NOTNULL, null, 0);
            $table->add_field('ismanual', XMLDB_TYPE_INTEGER, '1', null, XMLDB_NOTNULL, null, 0);
            $table->add_field('rawline', XMLDB_TYPE_TEXT, null, null, null, null, null);
            $table->add_field('timecreated', XMLDB_TYPE_INTEGER, '10', null, XMLDB_NOTNULL, null, 0);
            $table->add_field('timemodified', XMLDB_TYPE_INTEGER, '10', null, XMLDB_NOTNULL, null, 0);
            $table->add_field('usermodified', XMLDB_TYPE_INTEGER, '10', null, XMLDB_NOTNULL, null, 0);
            $table->add_key('primary', XMLDB_KEY_PRIMARY, ['id']);
            $table->add_index('bookid_idx', XMLDB_INDEX_NOTUNIQUE, ['bookid']);
            $dbman->create_table($table);
        }

        upgrade_plugin_savepoint(true, 2026041915, 'local', 'aisgk');
    }

    if ($oldversion < 2026042105) {
        $table = new xmldb_table('local_aisgk_jobs');
        if (!$dbman->table_exists($table)) {
            $table->add_field('id', XMLDB_TYPE_INTEGER, '10', null, XMLDB_NOTNULL, XMLDB_SEQUENCE, null);
            $table->add_field('jobtype', XMLDB_TYPE_CHAR, '30', null, XMLDB_NOTNULL, null, '');
            $table->add_field('status', XMLDB_TYPE_CHAR, '20', null, XMLDB_NOTNULL, null, 'queued');
            $table->add_field('userid', XMLDB_TYPE_INTEGER, '10', null, XMLDB_NOTNULL, null, 0);
            $table->add_field('resourcekey', XMLDB_TYPE_CHAR, '120', null, XMLDB_NOTNULL, null, '');
            $table->add_field('payloadjson', XMLDB_TYPE_TEXT, null, null, null, null, null);
            $table->add_field('resultjson', XMLDB_TYPE_TEXT, null, null, null, null, null);
            $table->add_field('message', XMLDB_TYPE_TEXT, null, null, null, null, null);
            $table->add_field('errormsg', XMLDB_TYPE_TEXT, null, null, null, null, null);
            $table->add_field('stepno', XMLDB_TYPE_INTEGER, '2', null, XMLDB_NOTNULL, null, 1);
            $table->add_field('stepkey', XMLDB_TYPE_CHAR, '30', null, XMLDB_NOTNULL, null, 'start');
            $table->add_field('steptext', XMLDB_TYPE_CHAR, '100', null, XMLDB_NOTNULL, null, 'Bắt đầu');
            $table->add_field('progress', XMLDB_TYPE_INTEGER, '3', null, XMLDB_NOTNULL, null, 0);
            $table->add_field('timecreated', XMLDB_TYPE_INTEGER, '10', null, XMLDB_NOTNULL, null, 0);
            $table->add_field('timeupdated', XMLDB_TYPE_INTEGER, '10', null, XMLDB_NOTNULL, null, 0);
            $table->add_field('timestarted', XMLDB_TYPE_INTEGER, '10', null, XMLDB_NOTNULL, null, 0);
            $table->add_field('timefinished', XMLDB_TYPE_INTEGER, '10', null, XMLDB_NOTNULL, null, 0);
            $table->add_key('primary', XMLDB_KEY_PRIMARY, ['id']);
            $table->add_index('jobtype_status_idx', XMLDB_INDEX_NOTUNIQUE, ['jobtype', 'status']);
            $table->add_index('resourcekey_idx', XMLDB_INDEX_NOTUNIQUE, ['resourcekey']);
            $dbman->create_table($table);
        }

        $table = new xmldb_table('local_aisgk_homeworks');
        if (!$dbman->table_exists($table)) {
            $table->add_field('id', XMLDB_TYPE_INTEGER, '10', null, XMLDB_NOTNULL, XMLDB_SEQUENCE, null);
            $table->add_field('jobid', XMLDB_TYPE_INTEGER, '10', null, XMLDB_NOTNULL, null, 0);
            $table->add_field('courseid', XMLDB_TYPE_INTEGER, '10', null, XMLDB_NOTNULL, null, 0);
            $table->add_field('sectionid', XMLDB_TYPE_INTEGER, '10', null, XMLDB_NOTNULL, null, 0);
            $table->add_field('bookid', XMLDB_TYPE_INTEGER, '10', null, XMLDB_NOTNULL, null, 0);
            $table->add_field('userid', XMLDB_TYPE_INTEGER, '10', null, XMLDB_NOTNULL, null, 0);
            $table->add_field('topicname', XMLDB_TYPE_CHAR, '255', null, XMLDB_NOTNULL, null, '');
            $table->add_field('pagefrom', XMLDB_TYPE_INTEGER, '10', null, XMLDB_NOTNULL, null, 0);
            $table->add_field('pageto', XMLDB_TYPE_INTEGER, '10', null, XMLDB_NOTNULL, null, 0);
            $table->add_field('status', XMLDB_TYPE_CHAR, '20', null, XMLDB_NOTNULL, null, 'draft_generating');
            $table->add_field('approvalstatus', XMLDB_TYPE_CHAR, '20', null, XMLDB_NOTNULL, null, 'pending');
            $table->add_field('scheduledtime', XMLDB_TYPE_INTEGER, '10', null, XMLDB_NOTNULL, null, 0);
            $table->add_field('deliveredtime', XMLDB_TYPE_INTEGER, '10', null, XMLDB_NOTNULL, null, 0);
            $table->add_field('resourcekey', XMLDB_TYPE_CHAR, '120', null, XMLDB_NOTNULL, null, '');
            $table->add_field('sourcetext', XMLDB_TYPE_TEXT, null, null, null, null, null);
            $table->add_field('sourceformula', XMLDB_TYPE_TEXT, null, null, null, null, null);
            $table->add_field('questiondata', XMLDB_TYPE_TEXT, null, null, null, null, null);
            $table->add_field('teacheredited', XMLDB_TYPE_TEXT, null, null, null, null, null);
            $table->add_field('moodlemoduleid', XMLDB_TYPE_INTEGER, '10', null, XMLDB_NOTNULL, null, 0);
            $table->add_field('deliverymessage', XMLDB_TYPE_TEXT, null, null, null, null, null);
            $table->add_field('errormsg', XMLDB_TYPE_TEXT, null, null, null, null, null);
            $table->add_field('cancelled', XMLDB_TYPE_INTEGER, '1', null, XMLDB_NOTNULL, null, 0);
            $table->add_field('timecreated', XMLDB_TYPE_INTEGER, '10', null, XMLDB_NOTNULL, null, 0);
            $table->add_field('timemodified', XMLDB_TYPE_INTEGER, '10', null, XMLDB_NOTNULL, null, 0);
            $table->add_key('primary', XMLDB_KEY_PRIMARY, ['id']);
            $table->add_index('courseid_status_idx', XMLDB_INDEX_NOTUNIQUE, ['courseid', 'status']);
            $table->add_index('resourcekey_idx', XMLDB_INDEX_NOTUNIQUE, ['resourcekey']);
            $dbman->create_table($table);
        }

        upgrade_plugin_savepoint(true, 2026042105, 'local', 'aisgk');
    }

    return true;
}
