<?php

defined('MOODLE_INTERNAL') || die();

function xmldb_local_aisgk_upgrade($oldversion) {
    global $DB;

    $dbman = $DB->get_manager();

    if ($oldversion < 2026041900) {
        $table = new xmldb_table('local_aisgk_books');

        $fields = [
            new xmldb_field('scanstatus', XMLDB_TYPE_CHAR, '20', null, XMLDB_NOTNULL, null, 'idle', 'usermodified'),
            new xmldb_field('scanmessage', XMLDB_TYPE_TEXT, null, null, null, null, null, 'scanstatus'),
            new xmldb_field('scansubmittedby', XMLDB_TYPE_INTEGER, '10', null, XMLDB_NOTNULL, null, 0, 'scanmessage'),
            new xmldb_field('scanstartedat', XMLDB_TYPE_INTEGER, '10', null, XMLDB_NOTNULL, null, 0, 'scansubmittedby'),
            new xmldb_field('scanfinishedat', XMLDB_TYPE_INTEGER, '10', null, XMLDB_NOTNULL, null, 0, 'scanstartedat'),
            new xmldb_field('lastscanitemcount', XMLDB_TYPE_INTEGER, '10', null, XMLDB_NOTNULL, null, 0, 'scanfinishedat'),
        ];

        foreach ($fields as $field) {
            if (!$dbman->field_exists($table, $field)) {
                $dbman->add_field($table, $field);
            }
        }

        upgrade_plugin_savepoint(true, 2026041900, 'local', 'aisgk');
    }

    if ($oldversion < 2026041915) {
        $table = new xmldb_table('local_aisgk_book_toc_draft');

        if (!$dbman->table_exists($table)) {
            $table->add_field('id', XMLDB_TYPE_INTEGER, '10', null, XMLDB_NOTNULL, XMLDB_SEQUENCE, null);
            $table->add_field('bookid', XMLDB_TYPE_INTEGER, '10', null, XMLDB_NOTNULL, null, 0);
            $table->add_field('sobai', XMLDB_TYPE_INTEGER, '10', null, XMLDB_NOTNULL, null, 0);
            $table->add_field('tenbai', XMLDB_TYPE_CHAR, '255', null, XMLDB_NOTNULL, null, '');
            $table->add_field('trang', XMLDB_TYPE_INTEGER, '10', null, null, null, null);
            $table->add_field('endtrang', XMLDB_TYPE_INTEGER, '10', null, null, null, null);
            $table->add_field('sortorder', XMLDB_TYPE_INTEGER, '10', null, XMLDB_NOTNULL, null, 0);
            $table->add_field('ismanual', XMLDB_TYPE_INTEGER, '1', null, XMLDB_NOTNULL, null, 0);
            $table->add_field('rawline', XMLDB_TYPE_TEXT, null, null, null, null, null);
            $table->add_field('timecreated', XMLDB_TYPE_INTEGER, '10', null, XMLDB_NOTNULL, null, 0);
            $table->add_field('timemodified', XMLDB_TYPE_INTEGER, '10', null, XMLDB_NOTNULL, null, 0);
            $table->add_field('usermodified', XMLDB_TYPE_INTEGER, '10', null, XMLDB_NOTNULL, null, 0);
            $table->add_key('primary', XMLDB_KEY_PRIMARY, ['id']);
            $table->add_index('bookid_idx', XMLDB_INDEX_NOTUNIQUE, ['bookid']);
            $dbman->create_table($table);
        }

        upgrade_plugin_savepoint(true, 2026041915, 'local', 'aisgk');
    }

    if ($oldversion < 2026042105) {
        $table = new xmldb_table('local_aisgk_jobs');
        if (!$dbman->table_exists($table)) {
            $table->add_field('id', XMLDB_TYPE_INTEGER, '10', null, XMLDB_NOTNULL, XMLDB_SEQUENCE, null);
            $table->add_field('jobtype', XMLDB_TYPE_CHAR, '30', null, XMLDB_NOTNULL, null, '');
            $table->add_field('status', XMLDB_TYPE_CHAR, '20', null, XMLDB_NOTNULL, null, 'queued');
            $table->add_field('userid', XMLDB_TYPE_INTEGER, '10', null, XMLDB_NOTNULL, null, 0);
            $table->add_field('resourcekey', XMLDB_TYPE_CHAR, '120', null, XMLDB_NOTNULL, null, '');
            $table->add_field('payloadjson', XMLDB_TYPE_TEXT, null, null, null, null, null);
            $table->add_field('resultjson', XMLDB_TYPE_TEXT, null, null, null, null, null);
            $table->add_field('message', XMLDB_TYPE_TEXT, null, null, null, null, null);
            $table->add_field('errormsg', XMLDB_TYPE_TEXT, null, null, null, null, null);
            $table->add_field('stepno', XMLDB_TYPE_INTEGER, '2', null, XMLDB_NOTNULL, null, 1);
            $table->add_field('stepkey', XMLDB_TYPE_CHAR, '30', null, XMLDB_NOTNULL, null, 'start');
            $table->add_field('steptext', XMLDB_TYPE_CHAR, '100', null, XMLDB_NOTNULL, null, 'Bắt đầu');
            $table->add_field('progress', XMLDB_TYPE_INTEGER, '3', null, XMLDB_NOTNULL, null, 0);
            $table->add_field('timecreated', XMLDB_TYPE_INTEGER, '10', null, XMLDB_NOTNULL, null, 0);
            $table->add_field('timeupdated', XMLDB_TYPE_INTEGER, '10', null, XMLDB_NOTNULL, null, 0);
            $table->add_field('timestarted', XMLDB_TYPE_INTEGER, '10', null, XMLDB_NOTNULL, null, 0);
            $table->add_field('timefinished', XMLDB_TYPE_INTEGER, '10', null, XMLDB_NOTNULL, null, 0);
            $table->add_key('primary', XMLDB_KEY_PRIMARY, ['id']);
            $table->add_index('jobtype_status_idx', XMLDB_INDEX_NOTUNIQUE, ['jobtype', 'status']);
            $table->add_index('resourcekey_idx', XMLDB_INDEX_NOTUNIQUE, ['resourcekey']);
            $dbman->create_table($table);
        }

        $table = new xmldb_table('local_aisgk_homeworks');
        if (!$dbman->table_exists($table)) {
            $table->add_field('id', XMLDB_TYPE_INTEGER, '10', null, XMLDB_NOTNULL, XMLDB_SEQUENCE, null);
            $table->add_field('jobid', XMLDB_TYPE_INTEGER, '10', null, XMLDB_NOTNULL, null, 0);
            $table->add_field('courseid', XMLDB_TYPE_INTEGER, '10', null, XMLDB_NOTNULL, null, 0);
            $table->add_field('sectionid', XMLDB_TYPE_INTEGER, '10', null, XMLDB_NOTNULL, null, 0);
            $table->add_field('bookid', XMLDB_TYPE_INTEGER, '10', null, XMLDB_NOTNULL, null, 0);
            $table->add_field('userid', XMLDB_TYPE_INTEGER, '10', null, XMLDB_NOTNULL, null, 0);
            $table->add_field('topicname', XMLDB_TYPE_CHAR, '255', null, XMLDB_NOTNULL, null, '');
            $table->add_field('pagefrom', XMLDB_TYPE_INTEGER, '10', null, XMLDB_NOTNULL, null, 0);
            $table->add_field('pageto', XMLDB_TYPE_INTEGER, '10', null, XMLDB_NOTNULL, null, 0);
            $table->add_field('status', XMLDB_TYPE_CHAR, '20', null, XMLDB_NOTNULL, null, 'draft_generating');
            $table->add_field('approvalstatus', XMLDB_TYPE_CHAR, '20', null, XMLDB_NOTNULL, null, 'pending');
            $table->add_field('scheduledtime', XMLDB_TYPE_INTEGER, '10', null, XMLDB_NOTNULL, null, 0);
            $table->add_field('deliveredtime', XMLDB_TYPE_INTEGER, '10', null, XMLDB_NOTNULL, null, 0);
            $table->add_field('resourcekey', XMLDB_TYPE_CHAR, '120', null, XMLDB_NOTNULL, null, '');
            $table->add_field('sourcetext', XMLDB_TYPE_TEXT, null, null, null, null, null);
            $table->add_field('sourceformula', XMLDB_TYPE_TEXT, null, null, null, null, null);
            $table->add_field('questiondata', XMLDB_TYPE_TEXT, null, null, null, null, null);
            $table->add_field('teacheredited', XMLDB_TYPE_TEXT, null, null, null, null, null);
            $table->add_field('moodlemoduleid', XMLDB_TYPE_INTEGER, '10', null, XMLDB_NOTNULL, null, 0);
            $table->add_field('deliverymessage', XMLDB_TYPE_TEXT, null, null, null, null, null);
            $table->add_field('errormsg', XMLDB_TYPE_TEXT, null, null, null, null, null);
            $table->add_field('cancelled', XMLDB_TYPE_INTEGER, '1', null, XMLDB_NOTNULL, null, 0);
            $table->add_field('timecreated', XMLDB_TYPE_INTEGER, '10', null, XMLDB_NOTNULL, null, 0);
            $table->add_field('timemodified', XMLDB_TYPE_INTEGER, '10', null, XMLDB_NOTNULL, null, 0);
            $table->add_key('primary', XMLDB_KEY_PRIMARY, ['id']);
            $table->add_index('courseid_status_idx', XMLDB_INDEX_NOTUNIQUE, ['courseid', 'status']);
            $table->add_index('resourcekey_idx', XMLDB_INDEX_NOTUNIQUE, ['resourcekey']);
            $dbman->create_table($table);
        }

        upgrade_plugin_savepoint(true, 2026042105, 'local', 'aisgk');
    }

    if ($oldversion < 2026042112) {
        $table = new xmldb_table('local_aisgk_ai_keys');
        if (!$dbman->table_exists($table)) {
            $table->add_field('id', XMLDB_TYPE_INTEGER, '10', null, XMLDB_NOTNULL, XMLDB_SEQUENCE, null);
            $table->add_field('gmail_account', XMLDB_TYPE_CHAR, '255', null, XMLDB_NOTNULL, null, '');
            $table->add_field('api_key', XMLDB_TYPE_TEXT, null, null, null, null, null);
            $table->add_field('status', XMLDB_TYPE_CHAR, '20', null, XMLDB_NOTNULL, null, 'active');
            $table->add_field('last_used', XMLDB_TYPE_INTEGER, '10', null, XMLDB_NOTNULL, null, 0);
            $table->add_field('request_count_minute', XMLDB_TYPE_INTEGER, '10', null, XMLDB_NOTNULL, null, 0);
            $table->add_field('total_requests_day', XMLDB_TYPE_INTEGER, '10', null, XMLDB_NOTNULL, null, 0);
            $table->add_field('proxy_info', XMLDB_TYPE_CHAR, '255', null, XMLDB_NOTNULL, null, '');
            $table->add_field('category_key', XMLDB_TYPE_CHAR, '10', null, XMLDB_NOTNULL, null, 'free');
            $table->add_field('timecreated', XMLDB_TYPE_INTEGER, '10', null, XMLDB_NOTNULL, null, 0);
            $table->add_field('timemodified', XMLDB_TYPE_INTEGER, '10', null, XMLDB_NOTNULL, null, 0);
            $table->add_field('usermodified', XMLDB_TYPE_INTEGER, '10', null, XMLDB_NOTNULL, null, 0);
            $table->add_key('primary', XMLDB_KEY_PRIMARY, ['id']);
            $table->add_index('status_idx', XMLDB_INDEX_NOTUNIQUE, ['status']);
            $table->add_index('category_idx', XMLDB_INDEX_NOTUNIQUE, ['category_key']);
            $dbman->create_table($table);
        }

        upgrade_plugin_savepoint(true, 2026042112, 'local', 'aisgk');
    }

    if ($oldversion < 2026042113) {
        $table = new xmldb_table('local_aisgk_ai_keys');
        $fields = [
            new xmldb_field('provider', XMLDB_TYPE_CHAR, '20', null, XMLDB_NOTNULL, null, 'google', 'category_key'),
            new xmldb_field('model_scan', XMLDB_TYPE_CHAR, '255', null, XMLDB_NOTNULL, null, '', 'provider'),
            new xmldb_field('model_homework', XMLDB_TYPE_CHAR, '255', null, XMLDB_NOTNULL, null, '', 'model_scan'),
            new xmldb_field('cooldown_until', XMLDB_TYPE_INTEGER, '10', null, XMLDB_NOTNULL, null, 0, 'model_homework'),
            new xmldb_field('minute_bucket', XMLDB_TYPE_INTEGER, '10', null, XMLDB_NOTNULL, null, 0, 'cooldown_until'),
            new xmldb_field('day_bucket', XMLDB_TYPE_INTEGER, '10', null, XMLDB_NOTNULL, null, 0, 'minute_bucket'),
            new xmldb_field('last_error', XMLDB_TYPE_TEXT, null, null, null, null, null, 'day_bucket'),
            new xmldb_field('usage_remaining', XMLDB_TYPE_NUMBER, '10,2', null, XMLDB_NOTNULL, null, '0', 'last_error'),
            new xmldb_field('usage_last_sync', XMLDB_TYPE_INTEGER, '10', null, XMLDB_NOTNULL, null, 0, 'usage_remaining'),
        ];
        foreach ($fields as $field) {
            if (!$dbman->field_exists($table, $field)) {
                $dbman->add_field($table, $field);
            }
        }
        upgrade_plugin_savepoint(true, 2026042113, 'local', 'aisgk');
    }

    if ($oldversion < 2026042501) {
        $table = new xmldb_table('local_aisgk_section_toc');

        if (!$dbman->table_exists($table)) {
            $table->add_field('id', XMLDB_TYPE_INTEGER, '10', null, XMLDB_NOTNULL, XMLDB_SEQUENCE, null);
            $table->add_field('sectionid', XMLDB_TYPE_INTEGER, '10', null, XMLDB_NOTNULL, null, 0);
            $table->add_field('tocid', XMLDB_TYPE_INTEGER, '10', null, XMLDB_NOTNULL, null, 0);

            $table->add_key('primary', XMLDB_KEY_PRIMARY, ['id']);
            $table->add_index('sectionid_uix', XMLDB_INDEX_UNIQUE, ['sectionid']);
            $table->add_index('tocid_idx', XMLDB_INDEX_NOTUNIQUE, ['tocid']);

            $dbman->create_table($table);
        }

        upgrade_plugin_savepoint(true, 2026042501, 'local', 'aisgk');
    }

    if ($oldversion < 2026042601) {
        $table = new xmldb_table('local_aisgk_ai_keys');
        $newfields = [
            new xmldb_field('limit_rpm', XMLDB_TYPE_INTEGER, '10', null, XMLDB_NOTNULL, null, 8),
            new xmldb_field('limit_rpd', XMLDB_TYPE_INTEGER, '10', null, XMLDB_NOTNULL, null, 200),
            new xmldb_field('limit_tpm', XMLDB_TYPE_INTEGER, '10', null, XMLDB_NOTNULL, null, 200000),
            new xmldb_field('used_rpm', XMLDB_TYPE_INTEGER, '10', null, XMLDB_NOTNULL, null, 0),
            new xmldb_field('used_rpd', XMLDB_TYPE_INTEGER, '10', null, XMLDB_NOTNULL, null, 0),
            new xmldb_field('used_tpm', XMLDB_TYPE_INTEGER, '10', null, XMLDB_NOTNULL, null, 0),
            new xmldb_field('last_model', XMLDB_TYPE_CHAR, '255', null, XMLDB_NOTNULL, null, ''),
            new xmldb_field('last_tokens', XMLDB_TYPE_INTEGER, '10', null, XMLDB_NOTNULL, null, 0),
            new xmldb_field('last_tokens_at', XMLDB_TYPE_INTEGER, '10', null, XMLDB_NOTNULL, null, 0),
            new xmldb_field('remain_calls_est', XMLDB_TYPE_INTEGER, '10', null, XMLDB_NOTNULL, null, 0),
        ];
        foreach ($newfields as $field) {
            if (!$dbman->field_exists($table, $field)) {
                $dbman->add_field($table, $field);
            }
        }

        $usertable = new xmldb_table('local_aisgk_user_ai_keys');
        if (!$dbman->table_exists($usertable)) {
            $usertable->add_field('id', XMLDB_TYPE_INTEGER, '10', null, XMLDB_NOTNULL, XMLDB_SEQUENCE, null);
            $usertable->add_field('userid', XMLDB_TYPE_INTEGER, '10', null, XMLDB_NOTNULL, null, 0);
            $usertable->add_field('gmail_account', XMLDB_TYPE_CHAR, '255', null, XMLDB_NOTNULL, null, '');
            $usertable->add_field('api_key', XMLDB_TYPE_TEXT, null, null, null, null, null);
            $usertable->add_field('status', XMLDB_TYPE_CHAR, '20', null, XMLDB_NOTNULL, null, 'active');
            $usertable->add_field('last_used', XMLDB_TYPE_INTEGER, '10', null, XMLDB_NOTNULL, null, 0);
            $usertable->add_field('request_count_minute', XMLDB_TYPE_INTEGER, '10', null, XMLDB_NOTNULL, null, 0);
            $usertable->add_field('total_requests_day', XMLDB_TYPE_INTEGER, '10', null, XMLDB_NOTNULL, null, 0);
            $usertable->add_field('proxy_info', XMLDB_TYPE_CHAR, '255', null, XMLDB_NOTNULL, null, '');
            $usertable->add_field('category_key', XMLDB_TYPE_CHAR, '10', null, XMLDB_NOTNULL, null, 'free');
            $usertable->add_field('provider', XMLDB_TYPE_CHAR, '20', null, XMLDB_NOTNULL, null, 'google');
            $usertable->add_field('model_scan', XMLDB_TYPE_CHAR, '255', null, XMLDB_NOTNULL, null, 'gemini-flash-latest');
            $usertable->add_field('model_homework', XMLDB_TYPE_CHAR, '255', null, XMLDB_NOTNULL, null, 'gemini-flash-latest');
            $usertable->add_field('cooldown_until', XMLDB_TYPE_INTEGER, '10', null, XMLDB_NOTNULL, null, 0);
            $usertable->add_field('minute_bucket', XMLDB_TYPE_INTEGER, '10', null, XMLDB_NOTNULL, null, 0);
            $usertable->add_field('day_bucket', XMLDB_TYPE_INTEGER, '10', null, XMLDB_NOTNULL, null, 0);
            $usertable->add_field('last_error', XMLDB_TYPE_TEXT, null, null, null, null, null);
            $usertable->add_field('usage_remaining', XMLDB_TYPE_NUMBER, '10,2', null, XMLDB_NOTNULL, null, '0');
            $usertable->add_field('usage_last_sync', XMLDB_TYPE_INTEGER, '10', null, XMLDB_NOTNULL, null, 0);
            $usertable->add_field('limit_rpm', XMLDB_TYPE_INTEGER, '10', null, XMLDB_NOTNULL, null, 8);
            $usertable->add_field('limit_rpd', XMLDB_TYPE_INTEGER, '10', null, XMLDB_NOTNULL, null, 200);
            $usertable->add_field('limit_tpm', XMLDB_TYPE_INTEGER, '10', null, XMLDB_NOTNULL, null, 200000);
            $usertable->add_field('used_rpm', XMLDB_TYPE_INTEGER, '10', null, XMLDB_NOTNULL, null, 0);
            $usertable->add_field('used_rpd', XMLDB_TYPE_INTEGER, '10', null, XMLDB_NOTNULL, null, 0);
            $usertable->add_field('used_tpm', XMLDB_TYPE_INTEGER, '10', null, XMLDB_NOTNULL, null, 0);
            $usertable->add_field('last_model', XMLDB_TYPE_CHAR, '255', null, XMLDB_NOTNULL, null, '');
            $usertable->add_field('last_tokens', XMLDB_TYPE_INTEGER, '10', null, XMLDB_NOTNULL, null, 0);
            $usertable->add_field('last_tokens_at', XMLDB_TYPE_INTEGER, '10', null, XMLDB_NOTNULL, null, 0);
            $usertable->add_field('remain_calls_est', XMLDB_TYPE_INTEGER, '10', null, XMLDB_NOTNULL, null, 0);
            $usertable->add_field('timecreated', XMLDB_TYPE_INTEGER, '10', null, XMLDB_NOTNULL, null, 0);
            $usertable->add_field('timemodified', XMLDB_TYPE_INTEGER, '10', null, XMLDB_NOTNULL, null, 0);
            $usertable->add_field('usermodified', XMLDB_TYPE_INTEGER, '10', null, XMLDB_NOTNULL, null, 0);
            $usertable->add_key('primary', XMLDB_KEY_PRIMARY, ['id']);
            $usertable->add_index('userid_idx', XMLDB_INDEX_NOTUNIQUE, ['userid']);
            $usertable->add_index('status_idx', XMLDB_INDEX_NOTUNIQUE, ['status']);
            $dbman->create_table($usertable);
        }

        upgrade_plugin_savepoint(true, 2026042601, 'local', 'aisgk');
    }


    if ($oldversion < 2026042602) {
        // UI/logic update: rename lesson buttons, delete generated lessons, and prefer section -> TOC mapping for homework jobs.
        upgrade_plugin_savepoint(true, 2026042602, 'local', 'aisgk');
    }

    if ($oldversion < 2026042603) {
        // Queue Scan TOC and redesign Automatic delivery popup.
        upgrade_plugin_savepoint(true, 2026042603, 'local', 'aisgk');
    }

    if ($oldversion < 2026042604) {
        upgrade_plugin_savepoint(true, 2026042604, 'local', 'aisgk');
    }

    if ($oldversion < 2026042605) {
        upgrade_plugin_savepoint(true, 2026042605, 'local', 'aisgk');
    }

    if ($oldversion < 2026042607) {
        foreach (["local_aisgk_ai_keys", "local_aisgk_user_ai_keys"] as $tablename) {
            $table = new xmldb_table($tablename);
            if ($dbman->table_exists($table)) {
                foreach ([
                    new xmldb_field("daily_limit", XMLDB_TYPE_INTEGER, "10", null, XMLDB_NOTNULL, null, 0, "usage_last_sync"),
                    new xmldb_field("daily_used", XMLDB_TYPE_INTEGER, "10", null, XMLDB_NOTNULL, null, 0, "daily_limit"),
                    new xmldb_field("daily_reset_at", XMLDB_TYPE_INTEGER, "10", null, XMLDB_NOTNULL, null, 0, "daily_used"),
                    new xmldb_field("in_use_by", XMLDB_TYPE_INTEGER, "10", null, XMLDB_NOTNULL, null, 0, "daily_reset_at"),
                    new xmldb_field("in_use_until", XMLDB_TYPE_INTEGER, "10", null, XMLDB_NOTNULL, null, 0, "in_use_by"),
                ] as $field) {
                    if (!$dbman->field_exists($table, $field)) {
                        $dbman->add_field($table, $field);
                    }
                }
                foreach (["limit_rpm", "limit_rpd", "limit_tpm", "used_rpm", "used_rpd", "used_tpm"] as $oldfieldname) {
                    $oldfield = new xmldb_field($oldfieldname);
                    if ($dbman->field_exists($table, $oldfield)) {
                        $dbman->drop_field($table, $oldfield);
                    }
                }
            }
        }

        $usagetable = new xmldb_table("local_aisgk_user_usage");
        if (!$dbman->table_exists($usagetable)) {
            $usagetable->add_field("id", XMLDB_TYPE_INTEGER, "10", null, XMLDB_NOTNULL, XMLDB_SEQUENCE, null);
            $usagetable->add_field("userid", XMLDB_TYPE_INTEGER, "10", null, XMLDB_NOTNULL, null, 0);
            $usagetable->add_field("usedate", XMLDB_TYPE_CHAR, "10", null, XMLDB_NOTNULL, null, null);
            $usagetable->add_field("used_calls", XMLDB_TYPE_INTEGER, "10", null, XMLDB_NOTNULL, null, 0);
            $usagetable->add_field("timecreated", XMLDB_TYPE_INTEGER, "10", null, XMLDB_NOTNULL, null, 0);
            $usagetable->add_field("timemodified", XMLDB_TYPE_INTEGER, "10", null, XMLDB_NOTNULL, null, 0);
            $usagetable->add_key("primary", XMLDB_KEY_PRIMARY, ["id"]);
            $usagetable->add_index("userid_date_uix", XMLDB_INDEX_UNIQUE, ["userid", "usedate"]);
            $dbman->create_table($usagetable);
        }

        $calltable = new xmldb_table("local_aisgk_api_calls");
        if (!$dbman->table_exists($calltable)) {
            $calltable->add_field("id", XMLDB_TYPE_INTEGER, "10", null, XMLDB_NOTNULL, XMLDB_SEQUENCE, null);
            $calltable->add_field("timecreated", XMLDB_TYPE_INTEGER, "10", null, XMLDB_NOTNULL, null, 0);
            $calltable->add_key("primary", XMLDB_KEY_PRIMARY, ["id"]);
            $calltable->add_index("timecreated_idx", XMLDB_INDEX_NOTUNIQUE, ["timecreated"]);
            $dbman->create_table($calltable);
        }

        upgrade_plugin_savepoint(true, 2026042607, "local", "aisgk");
    }


    if ($oldversion < 2026042610) {
        // Allow comma-separated model fallback lists in both system and personal API key tables.
        foreach (["local_aisgk_ai_keys", "local_aisgk_user_ai_keys"] as $tablename) {
            $table = new xmldb_table($tablename);
            if ($dbman->table_exists($table)) {
                foreach (["model_scan", "model_homework", "last_model"] as $fieldname) {
                    $field = new xmldb_field($fieldname, XMLDB_TYPE_CHAR, "255", null, XMLDB_NOTNULL, null, "");
                    if ($dbman->field_exists($table, $field)) {
                        $dbman->change_field_type($table, $field);
                    }
                }
            }
        }

        upgrade_plugin_savepoint(true, 2026042610, "local", "aisgk");
    }


    if ($oldversion < 2026042611) {
        // Store per-model runtime state and allow longer fallback model lists.
        foreach (["local_aisgk_ai_keys", "local_aisgk_user_ai_keys"] as $tablename) {
            $table = new xmldb_table($tablename);
            if ($dbman->table_exists($table)) {
                foreach (["model_scan", "model_homework"] as $fieldname) {
                    $field = new xmldb_field($fieldname, XMLDB_TYPE_TEXT, null, null, null, null, null);
                    if ($dbman->field_exists($table, new xmldb_field($fieldname))) {
                        $dbman->change_field_type($table, $field);
                    }
                }
                foreach ([
                    new xmldb_field("model_scan_status", XMLDB_TYPE_TEXT, null, null, null, null, null, "model_homework"),
                    new xmldb_field("model_homework_status", XMLDB_TYPE_TEXT, null, null, null, null, null, "model_scan_status"),
                ] as $field) {
                    if (!$dbman->field_exists($table, $field)) {
                        $dbman->add_field($table, $field);
                    }
                }
            }
        }

        upgrade_plugin_savepoint(true, 2026042611, "local", "aisgk");
    }


    if ($oldversion < 2026042613) {
        $table = new xmldb_table('local_aisgk_pagecache');
        if (!$dbman->table_exists($table)) {
            $table->add_field('id', XMLDB_TYPE_INTEGER, '10', null, XMLDB_NOTNULL, XMLDB_SEQUENCE, null);
            $table->add_field('courseid', XMLDB_TYPE_INTEGER, '10', null, XMLDB_NOTNULL, null, 0);
            $table->add_field('sectionid', XMLDB_TYPE_INTEGER, '10', null, XMLDB_NOTNULL, null, 0);
            $table->add_field('bookid', XMLDB_TYPE_INTEGER, '10', null, XMLDB_NOTNULL, null, 0);
            $table->add_field('pageno', XMLDB_TYPE_INTEGER, '10', null, XMLDB_NOTNULL, null, 0);
            $table->add_field('dpi', XMLDB_TYPE_INTEGER, '10', null, XMLDB_NOTNULL, null, 180);
            $table->add_field('filepath', XMLDB_TYPE_TEXT, null, null, null, null, null);
            $table->add_field('filesize', XMLDB_TYPE_INTEGER, '10', null, XMLDB_NOTNULL, null, 0);
            $table->add_field('timecreated', XMLDB_TYPE_INTEGER, '10', null, XMLDB_NOTNULL, null, 0);
            $table->add_field('timemodified', XMLDB_TYPE_INTEGER, '10', null, XMLDB_NOTNULL, null, 0);
            $table->add_field('lastused', XMLDB_TYPE_INTEGER, '10', null, XMLDB_NOTNULL, null, 0);
            $table->add_key('primary', XMLDB_KEY_PRIMARY, ['id']);
            $table->add_index('cache_uix', XMLDB_INDEX_UNIQUE, ['courseid', 'sectionid', 'bookid', 'pageno', 'dpi']);
            $table->add_index('lastused_idx', XMLDB_INDEX_NOTUNIQUE, ['lastused']);
            $dbman->create_table($table);
        }

        upgrade_plugin_savepoint(true, 2026042613, 'local', 'aisgk');
    }

    if ($oldversion < 2026042623) {
        foreach (['local_aisgk_jobs', 'local_aisgk_homeworks'] as $tablename) {
            $table = new xmldb_table($tablename);
            if ($dbman->table_exists($table)) {
                foreach ([
                    new xmldb_field('fingerprint', XMLDB_TYPE_CHAR, '40', null, XMLDB_NOTNULL, null, '', 'resourcekey'),
                    new xmldb_field('source', XMLDB_TYPE_CHAR, '20', null, XMLDB_NOTNULL, null, 'manual', 'fingerprint'),
                ] as $field) {
                    if (!$dbman->field_exists($table, $field)) { $dbman->add_field($table, $field); }
                }
                $idx = new xmldb_index('fingerprint_idx', XMLDB_INDEX_NOTUNIQUE, ['fingerprint']);
                if (!$dbman->index_exists($table, $idx)) { $dbman->add_index($table, $idx); }
            }
        }
        $jobtable = new xmldb_table('local_aisgk_jobs');
        if ($dbman->table_exists($jobtable)) {
            foreach ([
                new xmldb_field('priority', XMLDB_TYPE_INTEGER, '10', null, XMLDB_NOTNULL, null, 50, 'source'),
                new xmldb_field('runafter', XMLDB_TYPE_INTEGER, '10', null, XMLDB_NOTNULL, null, 0, 'priority'),
            ] as $field) {
                if (!$dbman->field_exists($jobtable, $field)) { $dbman->add_field($jobtable, $field); }
            }
        }
        upgrade_plugin_savepoint(true, 2026042623, 'local', 'aisgk');
    }

    if ($oldversion < 2026043024) {
        // Code-only upgrade: chunked homework generation, sequential autorepair, and model scoring config.
        upgrade_plugin_savepoint(true, 2026043024, 'local', 'aisgk');
    }


    if ($oldversion < 2026043026) {
        // Code-only upgrade: adaptive batch size by key type/model and even batch distribution.
        upgrade_plugin_savepoint(true, 2026043026, 'local', 'aisgk');
    }

    if ($oldversion < 2026043027) {
        // Code-only upgrade: safer placeholder normalization, draft model metadata, and preview math rendering.
        upgrade_plugin_savepoint(true, 2026043027, 'local', 'aisgk');
    }

    if ($oldversion < 2026043028) {
        upgrade_plugin_savepoint(true, 2026043028, 'local', 'aisgk');
    }

    if ($oldversion < 2026050202) {
        // Code-only upgrade: disable repeated click on homework create button while generation is running.
        upgrade_plugin_savepoint(true, 2026050202, 'local', 'aisgk');
    }

    return true;
}
