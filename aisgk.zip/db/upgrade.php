<?php

defined('MOODLE_INTERNAL') || die();

function xmldb_local_aisgk_upgrade($oldversion) {
    global $DB;

    $dbman = $DB->get_manager();

    if ($oldversion < 2026041900) {
        $table = new xmldb_table('local_aisgk_books');

        $fields = [
            new xmldb_field('scanstatus', XMLDB_TYPE_CHAR, '20', null, XMLDB_NOTNULL, null, 'idle', 'usermodified'),
            new xmldb_field('scanmessage', XMLDB_TYPE_TEXT, null, null, null, null, null, 'scanstatus'),
            new xmldb_field('scansubmittedby', XMLDB_TYPE_INTEGER, '10', null, XMLDB_NOTNULL, null, 0, 'scanmessage'),
            new xmldb_field('scanstartedat', XMLDB_TYPE_INTEGER, '10', null, XMLDB_NOTNULL, null, 0, 'scansubmittedby'),
            new xmldb_field('scanfinishedat', XMLDB_TYPE_INTEGER, '10', null, XMLDB_NOTNULL, null, 0, 'scanstartedat'),
            new xmldb_field('lastscanitemcount', XMLDB_TYPE_INTEGER, '10', null, XMLDB_NOTNULL, null, 0, 'scanfinishedat'),
        ];

        foreach ($fields as $field) {
            if (!$dbman->field_exists($table, $field)) {
                $dbman->add_field($table, $field);
            }
        }

        upgrade_plugin_savepoint(true, 2026041900, 'local', 'aisgk');
    }

    return true;
}
