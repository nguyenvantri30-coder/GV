<?php

defined('MOODLE_INTERNAL') || die();

$messageproviders = [
    'scanresult' => [
        'capability' => 'local/aisgk:createtopic',
    ],
];
