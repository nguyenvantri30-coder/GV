<?php
require('../../config.php');

use local_aisgk\user_aikey_repository;

define('AJAX_SCRIPT', true);

$courseid = required_param('id', PARAM_INT);
$op = required_param('op', PARAM_ALPHA);
require_sesskey();

$course = get_course($courseid);
require_login($course);
$context = context_course::instance($courseid);
require_capability('local/aisgk:createtopic', $context);

function local_aisgk_myaikeys_datetime_value(int $timestamp): string {
    if ($timestamp <= 0) {
        return '';
    }
    return userdate($timestamp, '%Y-%m-%dT%H:%M');
}

function local_aisgk_myaikeys_json_rows(array $rows): array {
    $out = [];
    foreach ($rows as $row) {
        $out[] = [
            'id' => (int)($row->id ?? 0),
            'gmail_account' => (string)($row->gmail_account ?? ''),
            'api_key' => (string)($row->api_key ?? ''),
            'status' => (string)($row->status ?? 'active'),
            'last_used' => local_aisgk_myaikeys_datetime_value((int)($row->last_used ?? 0)),
            'request_count_minute' => (int)($row->request_count_minute ?? 0),
            'total_requests_day' => (int)($row->total_requests_day ?? 0),
            'proxy_info' => (string)($row->proxy_info ?? ''),
            'category_key' => (string)($row->category_key ?? 'free'),
            'provider' => (string)($row->provider ?? 'google'),
            'model_scan' => (string)($row->model_scan ?? ''),
            'model_homework' => (string)($row->model_homework ?? ''),
            'cooldown_until' => local_aisgk_myaikeys_datetime_value((int)($row->cooldown_until ?? 0)),
            'minute_bucket' => (int)($row->minute_bucket ?? 0),
            'day_bucket' => (int)($row->day_bucket ?? 0),
            'last_error' => (string)($row->last_error ?? ''),
            'usage_remaining' => (string)($row->usage_remaining ?? '0'),
            'usage_last_sync' => !empty($row->usage_last_sync) ? userdate((int)$row->usage_last_sync, '%Y-%m-%d %H:%M') : '',
        ];
    }
    return $out;
}

$payload = json_decode(file_get_contents('php://input'), true) ?: [];

try {
    if ($op === 'get' || $op === 'restore') {
        user_aikey_repository::sync_usage_remaining_for_pay_keys_for_user((int)$USER->id);
        echo json_encode(['ok' => true, 'rows' => local_aisgk_myaikeys_json_rows(user_aikey_repository::get_all_for_user((int)$USER->id))]);
        exit;
    }

    if ($op === 'save') {
        $rows = $payload['rows'] ?? [];
        if (!is_array($rows)) {
            $rows = [];
        }
        user_aikey_repository::save_rows_for_user((int)$USER->id, $rows);
        user_aikey_repository::sync_usage_remaining_for_pay_keys_for_user((int)$USER->id);
        echo json_encode(['ok' => true, 'rows' => local_aisgk_myaikeys_json_rows(user_aikey_repository::get_all_for_user((int)$USER->id))]);
        exit;
    }

    if ($op === 'setpref') {
        $enabled = !empty($payload['enabled']) ? 1 : 0;
        set_user_preference('local_aisgk_use_my_api', $enabled, (int)$USER->id);
        echo json_encode(['ok' => true, 'enabled' => $enabled]);
        exit;
    }

    if ($op === 'getpref') {
        echo json_encode(['ok' => true, 'enabled' => (int)get_user_preferences('local_aisgk_use_my_api', 0, (int)$USER->id)]);
        exit;
    }

    throw new moodle_exception('invalidrequest', 'error');
} catch (Throwable $e) {
    http_response_code(500);
    echo json_encode(['ok' => false, 'error' => $e->getMessage()]);
}
