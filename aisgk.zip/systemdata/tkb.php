<?php
require_once(__DIR__ . '/../../../config.php');
require_login();
$context = context_system::instance();
$PAGE->set_context($context);
$PAGE->set_url(new moodle_url('/local/aisgk/systemdata/tkb.php'));
$PAGE->set_title(get_string('alsm_tkb_khdh_toan_truong', 'local_aisgk'));
$PAGE->set_heading(get_string('alsm_tkb_khdh_toan_truong', 'local_aisgk'));
$PAGE->set_pagelayout('standard');
echo $OUTPUT->header();
echo html_writer::tag('h2', get_string('alsm_tkb_khdh_toan_truong', 'local_aisgk'));
echo html_writer::tag('p', get_string('alsm_chuc_nang_diem_truong_alsm_buoc', 'local_aisgk'));
echo html_writer::link(new moodle_url('/local/aisgk/index.php'), get_string('alsm_quay_lai_alsm_toan_truong', 'local_aisgk'), ['class' => 'btn btn-secondary']);
echo $OUTPUT->footer();
