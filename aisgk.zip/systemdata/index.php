<?php
require_once(__DIR__ . '/../../../config.php');
require_login();
$context = context_system::instance();
$tab = optional_param('tab', 'overview', PARAM_ALPHANUMEXT);
$PAGE->set_context($context);
$PAGE->set_url(new moodle_url('/local/aisgk/systemdata/index.php', ['tab' => $tab]));
$PAGE->set_title(get_string('alsm_hoc_lieu_2', 'local_aisgk'));
$PAGE->set_heading(get_string('alsm_hoc_lieu_2', 'local_aisgk'));
$PAGE->set_pagelayout('standard');

$labels = [
    'backupyear' => get_string('alsm_backup_old_year', 'local_aisgk'),
    'schoolyear' => get_string('alsm_create_new_year', 'local_aisgk'),
    'inherit' => get_string('alsm_inherit_data', 'local_aisgk'),
    'restore' => get_string('alsm_restore_snapshot', 'local_aisgk'),
    'backup' => get_string('alsm_backup_system', 'local_aisgk'),
    'pl3template' => get_string('alsm_download_pl3_template', 'local_aisgk'),
    'manuals' => get_string('alsm_upload_alsm_manual', 'local_aisgk'),
    'validate' => get_string('alsm_kiem_tra', 'local_aisgk'),
    'semester_scope' => get_string('alsm_sync_semester_scope', 'local_aisgk'),
    'overview' => get_string('alsm_hoc_lieu_2', 'local_aisgk'),
];
$title = $labels[$tab] ?? $labels['overview'];
$introkey = 'alsm_page_intro_' . $tab;
$intro = get_string_manager()->string_exists($introkey, 'local_aisgk') ? get_string($introkey, 'local_aisgk') : get_string('alsm_page_intro_default', 'local_aisgk');

echo $OUTPUT->header();
echo html_writer::start_div('local-aisgk-placeholder', ['style' => 'max-width:980px;margin:0 auto;padding:18px']);
echo html_writer::tag('h2', s($title));
echo html_writer::tag('p', s($intro), ['style' => 'font-size:1rem;line-height:1.55;background:#f7fbff;border:1px solid #dbeafe;border-radius:14px;padding:14px 16px']);
echo html_writer::tag('p', get_string('alsm_chuc_nang_diem_truong_alsm_buoc', 'local_aisgk'));
echo html_writer::link(new moodle_url('/local/aisgk/index.php'), get_string('alsm_quay_lai_alsm_toan_truong', 'local_aisgk'), ['class' => 'btn btn-secondary']);
echo html_writer::end_div();
echo $OUTPUT->footer();
