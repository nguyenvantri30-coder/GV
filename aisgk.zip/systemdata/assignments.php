<?php
require_once(__DIR__ . '/../../../config.php');

$localaisgkmodal = optional_param('modal', 0, PARAM_BOOL);
function local_aisgk_modal_page_open($title = '') {
    global $OUTPUT, $localaisgkmodal;
    if ($localaisgkmodal) {
        echo '<!doctype html><html><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>' . s($title) . '</title><style>html,body{margin:0!important;padding:0!important;background:#fff!important;overflow:hidden;font-family:Arial,Helvetica,sans-serif}.modal-clean-wrap{padding:10px;box-sizing:border-box;width:100%;height:100vh;overflow:auto}.btn,button,input[type=submit]{display:inline-flex!important;align-items:center!important;justify-content:center!important;height:34px!important;line-height:1!important;padding:0 12px!important;box-sizing:border-box!important;vertical-align:middle!important}.table-responsive{overflow:auto}.muted{color:#64748b}</style></head><body><div class="modal-clean-wrap">';
    } else {
        echo $OUTPUT->header();
    }
}
function local_aisgk_modal_page_close() {
    global $OUTPUT, $localaisgkmodal;
    if ($localaisgkmodal) {
        echo '</div></body></html>';
    } else {
        echo $OUTPUT->footer();
    }
}

require_login();
$context = context_system::instance();
$PAGE->set_context($context);
$PAGE->set_url(new moodle_url('/local/aisgk/systemdata/assignments.php'));
$PAGE->set_title(get_string('alsm_phan_cong_gv_lop_mon', 'local_aisgk'));
$PAGE->set_heading(get_string('alsm_phan_cong_gv_lop_mon', 'local_aisgk'));
$PAGE->set_pagelayout('standard');
local_aisgk_modal_page_open($PAGE->title ?? '');
echo html_writer::tag('h2', get_string('alsm_phan_cong_gv_lop_mon', 'local_aisgk'));
echo html_writer::tag('p', get_string('alsm_chuc_nang_diem_truong_alsm_buoc', 'local_aisgk'));
echo html_writer::link(new moodle_url('/local/aisgk/index.php'), get_string('alsm_quay_lai_alsm_toan_truong', 'local_aisgk'), ['class' => 'btn btn-secondary']);
local_aisgk_modal_page_close();
