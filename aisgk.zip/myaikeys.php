<?php
require('../../config.php');

use local_aisgk\user_aikey_repository;

$courseid = required_param('id', PARAM_INT);
$course = get_course($courseid);
require_login($course);
$context = context_course::instance($courseid);
$PAGE->set_context($context);
$PAGE->set_url('/local/aisgk/myaikeys.php', ['id' => $courseid]);
$PAGE->set_pagelayout('embedded');
$PAGE->set_title('API của tôi');

function local_aisgk_aikeys_datetime_value(int $timestamp): string {
    if ($timestamp <= 0) {
        return '';
    }
    return userdate($timestamp, '%Y-%m-%dT%H:%M');
}

user_aikey_repository::sync_usage_remaining_for_pay_keys_for_user((int)$USER->id);
$rows = user_aikey_repository::get_all_for_user((int)$USER->id);
if (!$rows) {
    $rows = [(object)[
        'id' => 0,
        'gmail_account' => '',
        'api_key' => '',
        'status' => 'active',
        'last_used' => 0,
        'request_count_minute' => 0,
        'total_requests_day' => 0,
        'proxy_info' => '',
        'category_key' => 'free',
        'provider' => 'google',
        'model_scan' => '',
        'model_homework' => '',
        'usage_remaining' => 0,
        'usage_last_sync' => 0,
        'last_error' => '',
    ]];
}

echo $OUTPUT->header();
?>
<style>
html, body {background:#fff; height:100%; overflow:hidden; width:100%; max-width:100%;}
body.pagelayout-embedded #region-main-box,
body.pagelayout-embedded #region-main,
body.pagelayout-embedded [role="main"] {padding:0 !important; margin:0 !important; height:100%;}
.local-aisgk-aikeys-shell{width:100%;max-width:100%;height:90vh;box-sizing:border-box;padding:10px 12px 12px;font-size:13px;color:#1f2937;display:flex;flex-direction:column;gap:8px;overflow:hidden;}
.local-aisgk-toolbar{display:flex;align-items:center;gap:8px;flex-wrap:wrap;min-height:36px;}
.local-aisgk-gridwrap{flex:1;min-height:0;border:1px solid #cfd7e3;border-radius:8px;overflow:auto;background:#fff;width:100%;max-width:100%;box-sizing:border-box;-webkit-overflow-scrolling:touch;}
.local-aisgk-btn{height:34px;padding:0 12px;border-radius:6px;border:1px solid #cbd5e1;background:#fff;cursor:pointer;}
.local-aisgk-btn-primary{background:#2563eb;color:#fff;border-color:#2563eb;}
.local-aisgk-pill{display:inline-flex;align-items:center;height:28px;padding:0 10px;border-radius:999px;background:#eef2ff;color:#3730a3;font-size:12px;}
.local-aisgk-table{width:max-content;min-width:100%;border-collapse:collapse;font-size:13px;table-layout:fixed;}
.local-aisgk-table th,.local-aisgk-table td{border-bottom:1px solid #e5e7eb;padding:6px;vertical-align:middle;background:#fff;}
.local-aisgk-table thead th{position:sticky;top:0;z-index:2;background:#f8fafc;}
.local-aisgk-table th:nth-child(1),.local-aisgk-table td:nth-child(1){width:54px;text-align:center;}
.local-aisgk-table th:nth-child(2),.local-aisgk-table td:nth-child(2){width:56px;text-align:center;}
.local-aisgk-table th:nth-child(3),.local-aisgk-table td:nth-child(3){width:180px;}
.local-aisgk-table th:nth-child(4),.local-aisgk-table td:nth-child(4){width:260px;}
.local-aisgk-table th:nth-child(5),.local-aisgk-table td:nth-child(5){width:100px;}
.local-aisgk-table th:nth-child(6),.local-aisgk-table td:nth-child(6){width:110px;}
.local-aisgk-table th:nth-child(7),.local-aisgk-table td:nth-child(7){width:200px;}
.local-aisgk-table th:nth-child(8),.local-aisgk-table td:nth-child(8){width:200px;}
.local-aisgk-table th:nth-child(9),.local-aisgk-table td:nth-child(9){width:90px;}
.local-aisgk-table th:nth-child(10),.local-aisgk-table td:nth-child(10){width:150px;}
.local-aisgk-table th:nth-child(11),.local-aisgk-table td:nth-child(11){width:90px;}
.local-aisgk-table th:nth-child(12),.local-aisgk-table td:nth-child(12){width:90px;}
.local-aisgk-table th:nth-child(13),.local-aisgk-table td:nth-child(13){width:90px;}
.local-aisgk-table th:nth-child(14),.local-aisgk-table td:nth-child(14){width:160px;}
.local-aisgk-table th:nth-child(15),.local-aisgk-table td:nth-child(15){width:260px;}
.local-aisgk-table th:nth-child(16),.local-aisgk-table td:nth-child(16){width:70px;text-align:center;}
.local-aisgk-table input,.local-aisgk-table select{width:100%;height:32px;border:1px solid #cbd5e1;border-radius:4px;padding:4px 6px;box-sizing:border-box;}
.local-aisgk-aikeys-muted{font-size:11px;color:#667085;}
.local-aisgk-addline,.local-aisgk-rowdelete{width:26px;height:26px;border-radius:6px;border:1px solid #cbd5e1;background:#fff;cursor:pointer;padding:0;line-height:1;}
</style>
<div class="local-aisgk-aikeys-shell">
    <div class="local-aisgk-toolbar">
        <button type="button" class="local-aisgk-btn local-aisgk-btn-primary" id="local-aisgk-aikeys-save"><?php echo s(get_string('savechanges', 'local_aisgk')); ?></button>
        <button type="button" class="local-aisgk-btn" id="local-aisgk-aikeys-restore"><?php echo s(get_string('restorelabel', 'local_aisgk')); ?></button>
        <span class="local-aisgk-pill" id="local-aisgk-aikeys-status">✓ Ready</span>
        <span class="local-aisgk-aikeys-muted">Key ở đây chỉ thuộc về tài khoản giáo viên hiện tại.</span>
    </div>
    <div class="local-aisgk-gridwrap">
        <table class="local-aisgk-table" id="local-aisgk-aikeys-table">
            <thead>
                <tr>
                    <th>#</th>
                    <th>+</th>
                    <th>Gmail</th>
                    <th>API Key</th>
                    <th>Category</th>
                    <th>Provider</th>
                    <th>Model Scan</th>
                    <th>Model Homework</th>
                    <th>Status</th>
                    <th>Last used</th>
                    <th>Req/min</th>
                    <th>Req/day</th>
                    <th>Remain</th>
                    <th>Proxy</th>
                    <th>Last error</th>
                    <th>×</th>
                </tr>
            </thead>
            <tbody>
            <?php foreach ($rows as $i => $row): ?>
                <tr>
                    <td><?php echo $i + 1; ?></td>
                    <td><button type="button" class="local-aisgk-addline">+</button></td>
                    <td><input type="hidden" class="row-id" value="<?php echo (int)$row->id; ?>"><input type="text" class="row-gmail" value="<?php echo s((string)$row->gmail_account); ?>"></td>
                    <td><input type="text" class="row-apikey" value="<?php echo s((string)$row->api_key); ?>"></td>
                    <td><select class="row-category"><option value="free" <?php echo ((string)$row->category_key === 'free') ? 'selected' : ''; ?>>free</option><option value="pay" <?php echo ((string)$row->category_key === 'pay') ? 'selected' : ''; ?>>pay</option></select></td>
                    <td><select class="row-provider"><option value="google" <?php echo ((string)($row->provider ?? 'google') === 'google') ? 'selected' : ''; ?>>google</option><option value="shopaikey" <?php echo ((string)($row->provider ?? 'google') === 'shopaikey') ? 'selected' : ''; ?>>shopaikey</option></select></td>
                    <td><input type="text" class="row-modelscan" value="<?php echo s((string)($row->model_scan ?? '')); ?>"></td>
                    <td><input type="text" class="row-modelhomework" value="<?php echo s((string)($row->model_homework ?? '')); ?>"></td>
                    <td><select class="row-status"><option value="active" <?php echo ((string)$row->status === 'active') ? 'selected' : ''; ?>>active</option><option value="cooldown" <?php echo ((string)$row->status === 'cooldown') ? 'selected' : ''; ?>>cooldown</option><option value="blocked" <?php echo ((string)$row->status === 'blocked') ? 'selected' : ''; ?>>blocked</option></select></td>
                    <td><input type="datetime-local" class="row-lastused" value="<?php echo s(local_aisgk_aikeys_datetime_value((int)$row->last_used)); ?>"><div class="local-aisgk-aikeys-muted"><?php echo !empty($row->usage_last_sync) ? 'Sync: ' . s(userdate((int)$row->usage_last_sync, '%Y-%m-%d %H:%M')) : ''; ?></div></td>
                    <td><input type="number" min="0" class="row-reqminute" value="<?php echo (int)$row->request_count_minute; ?>"></td>
                    <td><input type="number" min="0" class="row-reqday" value="<?php echo (int)$row->total_requests_day; ?>"></td>
                    <td><input type="text" class="row-remaining" value="<?php echo s((string)($row->usage_remaining ?? '0')); ?>" readonly></td>
                    <td><input type="text" class="row-proxy" value="<?php echo s((string)$row->proxy_info); ?>"></td>
                    <td><input type="text" class="row-lasterror" value="<?php echo s((string)($row->last_error ?? '')); ?>"></td>
                    <td><button type="button" class="local-aisgk-rowdelete">×</button></td>
                </tr>
            <?php endforeach; ?>
            </tbody>
        </table>
    </div>
</div>
<script>
(function() {
    const courseid = <?php echo (int)$courseid; ?>;
    const sesskey = <?php echo json_encode(sesskey()); ?>;
    const ajaxUrl = <?php echo json_encode((new moodle_url('/local/aisgk/myaikeys_ajax.php', ['id' => $courseid]))->out(false)); ?>;
    const tbody = document.querySelector('#local-aisgk-aikeys-table tbody');
    const statusEl = document.getElementById('local-aisgk-aikeys-status');

    function escapeHtml(value) {
        return String(value || '').replace(/[&<>"']/g, function(ch) {
            return ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#039;'})[ch];
        });
    }
    function setStatus(text) { statusEl.textContent = text; }
    function renumber() {
        Array.from(tbody.querySelectorAll('tr')).forEach(function(tr, i) { tr.children[0].textContent = i + 1; });
    }
    function makeRow(row) {
        row = row || {};
        const tr = document.createElement('tr');
        tr.innerHTML = '' +
            '<td></td>' +
            '<td><button type="button" class="local-aisgk-addline">+</button></td>' +
            '<td><input type="hidden" class="row-id" value="' + escapeHtml(row.id || '') + '"><input type="text" class="row-gmail" value="' + escapeHtml(row.gmail_account || '') + '"></td>' +
            '<td><input type="text" class="row-apikey" value="' + escapeHtml(row.api_key || '') + '"></td>' +
            '<td><select class="row-category"><option value="free">free</option><option value="pay">pay</option></select></td>' +
            '<td><select class="row-provider"><option value="google">google</option><option value="shopaikey">shopaikey</option></select></td>' +
            '<td><input type="text" class="row-modelscan" value="' + escapeHtml(row.model_scan || '') + '"></td>' +
            '<td><input type="text" class="row-modelhomework" value="' + escapeHtml(row.model_homework || '') + '"></td>' +
            '<td><select class="row-status"><option value="active">active</option><option value="cooldown">cooldown</option><option value="blocked">blocked</option></select></td>' +
            '<td><input type="datetime-local" class="row-lastused" value="' + escapeHtml(row.last_used || '') + '"><div class="local-aisgk-aikeys-muted">' + escapeHtml(row.usage_last_sync || '') + '</div></td>' +
            '<td><input type="number" min="0" class="row-reqminute" value="' + escapeHtml(row.request_count_minute || 0) + '"></td>' +
            '<td><input type="number" min="0" class="row-reqday" value="' + escapeHtml(row.total_requests_day || 0) + '"></td>' +
            '<td><input type="text" class="row-remaining" value="' + escapeHtml(row.usage_remaining || 0) + '" readonly></td>' +
            '<td><input type="text" class="row-proxy" value="' + escapeHtml(row.proxy_info || '') + '"></td>' +
            '<td><input type="text" class="row-lasterror" value="' + escapeHtml(row.last_error || '') + '"></td>' +
            '<td><button type="button" class="local-aisgk-rowdelete">×</button></td>';
        tr.querySelector('.row-status').value = row.status || 'active';
        tr.querySelector('.row-category').value = row.category_key || 'free';
        tr.querySelector('.row-provider').value = row.provider || ((row.category_key || 'free') === 'pay' ? 'shopaikey' : 'google');
        return tr;
    }
    function getRows() {
        return Array.from(tbody.querySelectorAll('tr')).map(function(tr) {
            return {
                id: tr.querySelector('.row-id').value,
                gmail_account: tr.querySelector('.row-gmail').value.trim(),
                api_key: tr.querySelector('.row-apikey').value.trim(),
                category_key: tr.querySelector('.row-category').value,
                provider: tr.querySelector('.row-provider').value,
                model_scan: tr.querySelector('.row-modelscan').value.trim(),
                model_homework: tr.querySelector('.row-modelhomework').value.trim(),
                status: tr.querySelector('.row-status').value,
                last_used: tr.querySelector('.row-lastused').value,
                request_count_minute: tr.querySelector('.row-reqminute').value,
                total_requests_day: tr.querySelector('.row-reqday').value,
                proxy_info: tr.querySelector('.row-proxy').value.trim(),
                last_error: tr.querySelector('.row-lasterror').value.trim(),
                usage_remaining: tr.querySelector('.row-remaining').value.trim()
            };
        }).filter(function(row) {
            return row.gmail_account || row.api_key || row.proxy_info || row.model_scan || row.model_homework || row.last_error || row.request_count_minute !== '0' || row.total_requests_day !== '0' || row.last_used;
        });
    }
    function renderRows(rows) {
        tbody.innerHTML = '';
        (rows && rows.length ? rows : [{}]).forEach(function(row) { tbody.appendChild(makeRow(row)); });
        renumber();
        setStatus('✓ Done, +' + tbody.querySelectorAll('tr').length + ' rows');
    }
    async function postJson(op, data) {
        const url = ajaxUrl + '&op=' + encodeURIComponent(op) + '&sesskey=' + encodeURIComponent(sesskey);
        const res = await fetch(url, {method: 'POST', headers: {'Content-Type': 'application/json'}, body: JSON.stringify(data || {})});
        const text = await res.text();
        let json = null;
        try { json = JSON.parse(text); } catch (e) {}
        if (!res.ok || !json || json.ok === false) { throw new Error((json && json.error) ? json.error : (text || 'Request failed')); }
        return json;
    }
    tbody.addEventListener('click', function(e) {
        if (e.target.classList.contains('local-aisgk-addline')) {
            const tr = e.target.closest('tr');
            tr.after(makeRow({}));
            renumber();
        }
        if (e.target.classList.contains('local-aisgk-rowdelete')) {
            const rows = tbody.querySelectorAll('tr');
            if (rows.length > 1) {
                e.target.closest('tr').remove();
            } else {
                e.target.closest('tr').replaceWith(makeRow({}));
            }
            renumber();
        }
    });
    document.getElementById('local-aisgk-aikeys-save').addEventListener('click', async function() {
        try {
            setStatus('Đang lưu API của tôi...');
            const json = await postJson('save', {rows: getRows()});
            renderRows(json.rows || []);
        } catch (err) {
            setStatus('Failed: ' + err.message);
            alert('Failed: ' + err.message);
        }
    });
    document.getElementById('local-aisgk-aikeys-restore').addEventListener('click', async function() {
        try {
            setStatus('Đang tải lại API của tôi...');
            const json = await postJson('restore', {});
            renderRows(json.rows || []);
        } catch (err) {
            setStatus('Failed: ' + err.message);
            alert('Failed: ' + err.message);
        }
    });
    renumber();
})();
</script>
<?php echo $OUTPUT->footer();
