<?php
// Repair Moodle external_functions registry after an accidental over-reset.
define('CLI_SCRIPT', true);
require(__DIR__ . '/../../../config.php');
require_once($CFG->libdir . '/clilib.php');
require_once($CFG->dirroot . '/local/aisgk/classes/local/service/school_year_backup_service.php');

list($options, $unrecognized) = cli_get_params(['help' => false], ['h' => 'help']);
if (!empty($options['help'])) {
    echo "Rebuild external_functions from db/services.php files.\n";
    exit(0);
}

$result = \local_aisgk\local\service\school_year_backup_service::repair_moodle_external_function_registry();
echo "Updated components: " . count($result['updated_components']) . "\n";
if (!empty($result['errors'])) {
    echo "Errors:\n" . implode("\n", $result['errors']) . "\n";
    exit(1);
}
echo "OK\n";
