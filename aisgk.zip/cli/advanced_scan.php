<?php
// phpcs:ignoreFile
define('CLI_SCRIPT', true);
require(__DIR__ . '/../../../config.php');
require_once($CFG->libdir . '/clilib.php');

use local_aisgk\local\sgk_processor;
use local_aisgk\toc_repository;

list($options, $unrecognized) = cli_get_params([
    'jobid' => null,
], []);

if (empty($options['jobid'])) {
    cli_error('Missing --jobid');
}

$jobid = (int)$options['jobid'];
global $DB;
$job = $DB->get_record('local_aisgk_scanjobs', ['id' => $jobid], '*', MUST_EXIST);

$update = function(array $fields) use ($DB, $jobid) {
    $rec = (object)array_merge(['id' => $jobid, 'timeupdated' => time()], $fields);
    $DB->update_record('local_aisgk_scanjobs', $rec);
};

try {
    $update([
        'status' => 'running',
        'stepno' => 1,
        'steptext' => 'Bắt đầu',
        'progress' => 5,
        'message' => 'Khởi động advanced scan',
        'timestarted' => time(),
    ]);

    $update([
        'stepno' => 2,
        'steptext' => 'Đang scan',
        'progress' => 20,
        'message' => 'Đang OCR mục lục theo luồng nền',
    ]);

    $preview = sgk_processor::preview_topic_items((int)$job->bookid, (int)$job->columns, 50, (int)$job->psm);
    $rows = [];
    foreach (($preview['items'] ?? []) as $item) {
        $rows[] = [
            'sobai' => $item['lessonno'] ?? '',
            'tenbai' => $item['lessontitle'] ?? '',
            'trang' => $item['startpage'] ?? '',
            'endtrang' => $item['endpage'] ?? '',
            'rawline' => $item['rawocr'] ?? '',
        ];
    }

    $update([
        'stepno' => 3,
        'steptext' => 'Xong',
        'progress' => 85,
        'message' => 'Đang lưu kết quả vào bảng mục lục',
    ]);

    $rows = toc_repository::calculate_end_pages($rows);
    toc_repository::replace_book_toc((int)$job->bookid, $rows);

    $result = [
        'rows' => count($rows),
        'message' => 'Quét xong ' . count($rows) . ' dòng mục lục',
    ];

    $update([
        'status' => 'done',
        'stepno' => 4,
        'steptext' => 'Kết quả',
        'progress' => 100,
        'message' => $result['message'],
        'resultjson' => json_encode($result, JSON_UNESCAPED_UNICODE),
        'timefinished' => time(),
    ]);
} catch (Throwable $e) {
    $update([
        'status' => 'failed',
        'message' => 'Advanced scan thất bại',
        'errormsg' => $e->getMessage(),
        'timefinished' => time(),
    ]);
}
