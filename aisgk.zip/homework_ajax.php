<?php
require('../../config.php');

use local_aisgk\book_repository;
use local_aisgk\homework_repository;
use local_aisgk\local\job_manager;
use local_aisgk\local\service\homework_service;
use local_aisgk\local\ai_service;
use local_aisgk\local\manual_json_processor;
use local_aisgk\ai_key_manager;
use local_aisgk\local\sgk_processor;

require_login();
require_sesskey();

$action = required_param('action', PARAM_ALPHAEXT);
$courseid = required_param('courseid', PARAM_INT);
$context = context_course::instance($courseid);
require_capability('local/aisgk:createhomework', $context);

header('Content-Type: application/json; charset=utf-8');

function local_aisgk_sourceformula_meta(int $homeworkid): array {
    $hw = homework_repository::get_by_id($homeworkid);
    if (!$hw || empty($hw->sourceformula)) { return []; }
    $meta = json_decode((string)$hw->sourceformula, true);
    return is_array($meta) ? $meta : [];
}

function local_aisgk_merge_sourceformula(array $oldmeta, array $options, array $report = null, array $usage = null, string $model = '', string $raw = ''): string {
    $meta = $oldmeta;
    $meta['options'] = $options;
    if ($report !== null) { $meta['report'] = $report; }
    if ($usage !== null) { $meta['usage'] = $usage; }
    if ($model !== '') {
        $meta['model'] = $model;
        $meta['model_fix'] = $model;
    }
    if ($raw !== '') { $meta['fix_rawtext'] = $raw; }
    return json_encode($meta, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
}


function local_aisgk_questions_from_homework($hw): array {
    foreach ([(string)($hw->questiondata ?? ''), (string)($hw->sourcetext ?? '')] as $raw) {
        if ($raw === '') { continue; }
        $decoded = json_decode($raw, true);
        if (!is_array($decoded)) { continue; }
        $qs = $decoded['questions'] ?? $decoded;
        if (is_array($qs)) { return array_values($qs); }
    }
    return [];
}

function local_aisgk_merge_options(array $base, array $questions): array {
    $out = $base;
    $qtypes = [];
    $levels = [];
    foreach ($questions as $q) {
        if (!is_array($q)) { continue; }
        $type = (string)($q['qtype'] ?? $q['type'] ?? '');
        $level = (string)($q['level'] ?? '');
        if ($type !== '') { $qtypes[$type] = ($qtypes[$type] ?? 0) + 1; }
        if ($level !== '') { $levels[$level] = ($levels[$level] ?? 0) + 1; }
    }
    $out['qtypes'] = $qtypes;
    $out['cognitive'] = $levels;
    $out['total'] = count($questions);
    if (empty($out['distractors']) || !is_array($out['distractors'])) { $out['distractors'] = []; }
    return $out;
}

try {
    switch ($action) {
        case 'prefill':
            $topicname = required_param('topicname', PARAM_TEXT);
            $match = homework_service::find_topic_match($courseid, $topicname);
            $out = ['ok' => true, 'match' => null, 'books' => []];
            foreach (book_repository::get_all_by_courseid($courseid) as $book) {
                $out['books'][] = ['id' => (int)$book->id, 'name' => $book->name];
            }
            if ($match) {
                $out['match'] = [
                    'bookid' => (int)$match['book']->id,
                    'bookname' => $match['book']->name,
                    'pagefrom' => (int)($match['toc']->trang ?? 0),
                    'pageto' => (int)($match['toc']->endtrang ?? 0),
                    'tenbai' => $match['toc']->tenbai,
                ];
            }
            echo json_encode($out);
            break;

        case 'start':
            $sectionid = required_param('sectionid', PARAM_INT);
            $topicname = required_param('topicname', PARAM_TEXT);
            $bookid = required_param('bookid', PARAM_INT);
            $pagefrom = required_param('pagefrom', PARAM_INT);
            $pageto = required_param('pageto', PARAM_INT);
            $scheduled = required_param('scheduledtime', PARAM_TEXT);
            $scheduledtime = strtotime($scheduled) ?: time();
            $optionsraw = optional_param('options', '', PARAM_RAW);
            $options = $optionsraw !== '' ? (json_decode($optionsraw, true) ?: []) : [];

            // Tôn trọng đúng bookid/pagefrom/pageto gửi từ popup. Chỉ dùng mapping section -> mục lục
            // để bổ sung khi popup không có đủ dữ liệu, tránh scan nhầm trang mục lục.
            $mapped = homework_service::find_section_match($courseid, $sectionid);
            if ($mapped && ($bookid < 1 || $pagefrom < 1 || $pageto < $pagefrom)) {
                $bookid = (int)$mapped['book']->id;
                $pagefrom = (int)($mapped['toc']->trang ?? $pagefrom);
                $pageto = (int)($mapped['toc']->endtrang ?? $pageto);
                $topicname = trim((string)($mapped['toc']->tenbai ?? $topicname));
            }

            $result = homework_service::create_draft_job($USER->id, $courseid, $sectionid, $topicname, $bookid, $pagefrom, $pageto, $scheduledtime, $options);
            $job = job_manager::get((int)$result['jobid']);
            echo json_encode(['ok' => true, 'jobid' => (int)$job->id, 'job' => $job, 'reused' => !empty($result['reused']), 'userusage' => ai_key_manager::user_daily_usage_summary((int)$USER->id)]);
            break;

        case 'status':
            $jobid = required_param('jobid', PARAM_INT);
            $job = job_manager::get($jobid);
            if (!$job) {
                throw new moodle_exception('invalidparameter');
            }
            $payload = json_decode((string)$job->payloadjson, true) ?: [];
            $homework = !empty($payload['homeworkid']) ? homework_repository::get_by_id((int)$payload['homeworkid']) : null;
            if ($homework) {
                $opts = is_array($payload['options'] ?? null) ? (array)$payload['options'] : [];
                $homework = homework_service::materialize_homework_images((int)$homework->id, $opts) ?: $homework;
            }
            $result = json_decode((string)$job->resultjson, true) ?: [];
            $position = job_manager::queue_position((int)$job->id);
            if ((string)$job->status === 'queued' && $position > 0) {
                $job->queueposition = $position;
                $job->message = 'Bạn đang ở vị trí thứ ' . $position . ' trong hàng đợi, vui lòng đợi giây lát.';
            }
            echo json_encode(['ok' => true, 'job' => $job, 'homework' => $homework, 'result' => $result, 'queueposition' => $position, 'userusage' => ai_key_manager::user_daily_usage_summary((int)$USER->id)]);
            break;


        case 'usage':
            echo json_encode(['ok' => true, 'userusage' => ai_key_manager::user_daily_usage_summary((int)$USER->id)]);
            break;

        case 'copytemplate':
            $sectionid = required_param('sectionid', PARAM_INT);
            $topicname = required_param('topicname', PARAM_TEXT);
            $bookid = required_param('bookid', PARAM_INT);
            $pagefrom = required_param('pagefrom', PARAM_INT);
            $pageto = required_param('pageto', PARAM_INT);
            $optionsraw = optional_param('options', '', PARAM_RAW);
            $options = $optionsraw !== '' ? (json_decode($optionsraw, true) ?: []) : [];
            $mapped = homework_service::find_section_match($courseid, $sectionid);
            if ($mapped && ($bookid < 1 || $pagefrom < 1 || $pageto < $pagefrom)) {
                $bookid = (int)$mapped['book']->id;
                $pagefrom = (int)($mapped['toc']->trang ?? $pagefrom);
                $pageto = (int)($mapped['toc']->endtrang ?? $pageto);
                $topicname = trim((string)($mapped['toc']->tenbai ?? $topicname));
            }
            $book = book_repository::get_by_id($bookid);
            $bookname = $book ? (string)($book->name ?: $book->filename) : '';
            $total = (int)($options['total'] ?? 0);
            if ($total <= 0 && !empty($options['qtypes']) && is_array($options['qtypes'])) {
                $total = array_sum(array_map('intval', $options['qtypes']));
            }
            $total = max(1, min(60, $total));
            $baseprompt = ai_service::build_homework_prompt($topicname, $bookname, $pagefrom, $pageto, $total, $options);
            $publicoptions = $options;
            foreach (array_keys($publicoptions) as $k) { if (is_string($k) && str_starts_with($k, '_')) { unset($publicoptions[$k]); } }
            $expectedconfigarray = ai_service::expected_teacher_config($publicoptions);
            $expectedconfig = json_encode($expectedconfigarray, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
            $prompt = $baseprompt . "\n\n================ STRICT OUTPUT CONTRACT CHO AI CÁ NHÂN ================\n"
                . "Phần này dùng khi giáo viên dán prompt/ảnh vào AI cá nhân rồi copy JSON về Moodle.\n"
                . "CẤU HÌNH GỐC BẮT BUỘC PHẢI TRẢ LẠI NGUYÊN VẸN 100% trong khóa TEACHER_CONFIG:\n" . $expectedconfig . "\n\n"
                . "Yêu cầu kiểm tra bắt buộc trước khi trả lời:\n"
                . "1) JSON object trả về BẮT BUỘC có khóa TEACHER_CONFIG giống hệt cấu hình gốc ở trên; không đổi tên key, không đổi số lượng, không bỏ qtype có giá trị 0.\n"
                . "2) QUESTION_PLAN phải có đúng tổng số câu, đúng question_no, đúng type, đúng level theo TEACHER_CONFIG.\n"
                . "3) questions phải có đúng từng câu tương ứng với QUESTION_PLAN: questions[i].question_no/type/level phải giống QUESTION_PLAN[i].\n"
                . "4) Không sinh type/level có số lượng = 0; không sinh dư; không sinh thiếu.\n"
                . "5) JSON phải hợp lệ để json_decode đọc được: mọi dấu \\ trong LaTeX phải viết thành \\\\, mọi dấu nháy kép trong nội dung phải escape thành \\\".\n"
                . "6) Chỉ trả JSON object, không markdown, không giải thích, không đặt trong ```json.\n"
                . "7) Cấu trúc JSON gốc bắt buộc: {\"TEACHER_CONFIG\":{...},\"QUESTION_PLAN\":[...],\"questions\":[...]}\n";
            $imageinfo = [];
            if ($book && $bookid > 0 && $pagefrom > 0 && $pageto >= $pagefrom) {
                $renderfrom = $pagefrom + 1;
                $renderto = $pageto + 1;
                try {
                    $aiwidth = homework_service::normalize_ai_image_width($options['ai_image_width'] ?? 1000);
                    $images = sgk_processor::render_page_images_cached($bookid, (int)$book->courseid, $sectionid, $renderfrom, $renderto, 180, null, true, $aiwidth);
                    foreach (array_values($images) as $i => $path) {
                        $sgkpage = $pagefrom + $i;
                        $pdfpage = $renderfrom + $i;
                        $imgurl = (new moodle_url('/local/aisgk/pageimg.php', [
                            'courseid' => $courseid,
                            'bookid' => $bookid,
                            'sectionid' => $sectionid,
                            'page' => $sgkpage,
                            'width' => $aiwidth,
                        ]))->out(false);
                        $imageinfo[] = 'Ảnh ' . ($i + 1) . ' · SGK trang ' . $sgkpage . ' · PDF page ' . $pdfpage . ' · URL: ' . $imgurl;
                    }
                } catch (Throwable $e) {
                    $imageinfo[] = 'Không render được ảnh mẫu: ' . $e->getMessage();
                }
            }
            $copytext = "PROMPT GỬI AI\n================\n" . $prompt . "\n\nẢNH SGK GỬI AI\n================\nTải/mở từng URL ảnh dưới đây rồi đính kèm cùng prompt khi dùng AI cá nhân.\n" . implode("\n", $imageinfo);
            $filename = 'aisgk-mau-' . preg_replace('/[^a-zA-Z0-9_-]+/', '-', strtolower($topicname ?: 'homework')) . '.txt';
            echo json_encode(['ok' => true, 'prompt' => $prompt, 'images' => $imageinfo, 'copytext' => $copytext, 'filename' => $filename]);
            break;

        case 'validatejson':
            $optionsraw = required_param('options', PARAM_RAW);
            $jsonraw = required_param('json', PARAM_RAW);
            $options = json_decode($optionsraw, true) ?: [];
            $hid = optional_param('homeworkid', 0, PARAM_INT);
            if ($hid) {
                $oldmeta = local_aisgk_sourceformula_meta($hid);
                $oldoptions = is_array($oldmeta['options'] ?? null) ? (array)$oldmeta['options'] : [];
                if (!empty($oldmeta['_sent_image_meta']) && empty($options['_sent_image_meta'])) {
                    $options['_sent_image_meta'] = $oldmeta['_sent_image_meta'];
                } else if (!empty($oldoptions['_sent_image_meta']) && empty($options['_sent_image_meta'])) {
                    $options['_sent_image_meta'] = $oldoptions['_sent_image_meta'];
                }
            }
            $manual = manual_json_processor::decode($jsonraw);
            $decoded = is_array($manual['decoded'] ?? null) ? $manual['decoded'] : null;
            if (!is_array($decoded)) {
                echo json_encode(['ok' => true, 'report' => ['ok' => false, 'errors' => ['JSON lỗi: ' . (string)($manual['error'] ?? json_last_error_msg())], 'summary' => ['qtypes' => [], 'levels' => []]]]);
                break;
            }
            $questions = $decoded['questions'] ?? $decoded;
            if (!is_array($questions)) { $questions = []; }
            $teacherconfig = ai_service::teacher_config_from_payload($decoded);
            $validationoptions = is_array($teacherconfig) ? ai_service::options_from_teacher_config($teacherconfig, $options) : $options;
            $normalized = ai_service::normalize_homework_questions(array_values($questions), $validationoptions);
            $report = ai_service::validate_homework_against_plan($normalized, $validationoptions);
            $configerrors = ai_service::validate_teacher_config_from_payload($decoded, $validationoptions);
            $planerrors = ai_service::validate_question_plan_from_payload($decoded, $validationoptions);
            $extraerrors = array_merge($configerrors, $planerrors);
            if (!empty($extraerrors)) {
                $report['ok'] = false;
                $report['errors'] = array_merge($extraerrors, $report['errors'] ?? []);
            }
            $normalizedjson = ai_service::questions_json($normalized);
            $hasdebugraw = is_array($decoded) && array_key_exists('_debug', $decoded);

            // Phase debug: luôn autosave, kể cả report chưa đạt. Nếu sourcetext đang có _debug/raw_ai_text
            // thì giữ nguyên nó để không mất raw kết quả AI; questiondata vẫn lưu JSON đã normalize.
            if ($hid) {
                homework_repository::update($hid, [
                    'sourcetext' => $hasdebugraw ? $jsonraw : $normalizedjson,
                    'sourceformula' => local_aisgk_merge_sourceformula(local_aisgk_sourceformula_meta($hid), $validationoptions, $report),
                    'questiondata' => json_encode($normalized, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES),
                    'errormsg' => $report['ok'] ? '' : implode(' | ', $report['errors']),
                    'status' => $report['ok'] ? 'draft_ready' : 'draft_ready',
                    'timemodified' => time(),
                ]);
                $previewjson = '';
                $previewoptions = $validationoptions;
                $previewoptions['preview_inline_images'] = true;
                $previewhw = homework_service::materialize_homework_images($hid, $previewoptions);
                if ($previewhw && !empty($previewhw->previewquestiondata)) {
                    $previewjson = (string)$previewhw->previewquestiondata;
                }
            }
            echo json_encode(['ok' => true, 'report' => $report, 'normalizedjson' => $normalizedjson, 'hasdebugraw' => $hasdebugraw, 'previewjson' => $previewjson ?? '', 'teacherconfig' => $teacherconfig, 'autosaved' => ($hid && !empty($report['ok']))], JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);

            break;

        case 'fixerrors':
            $homeworkid = required_param('homeworkid', PARAM_INT);
            $jsonraw = required_param('json', PARAM_RAW);
            $optionsraw = required_param('options', PARAM_RAW);
            $reportraw = optional_param('report', '', PARAM_RAW);
            $options = json_decode($optionsraw, true) ?: [];
            $report = $reportraw !== '' ? (json_decode($reportraw, true) ?: []) : [];
            $manual = manual_json_processor::decode($jsonraw);
            $decoded = is_array($manual['decoded'] ?? null) ? $manual['decoded'] : null;
            if (!is_array($decoded)) {
                throw new moodle_exception('JSON lỗi: ' . (string)($manual['error'] ?? json_last_error_msg()));
            }
            $questions = $decoded['questions'] ?? $decoded;
            if (!is_array($questions)) { $questions = []; }
            $hw = $homeworkid ? homework_repository::get_by_id($homeworkid) : null;
            $topicname = $hw ? (string)$hw->topicname : '';
            $bookid = $hw ? (int)$hw->bookid : 0;
            $book = $bookid ? book_repository::get_by_id($bookid) : null;
            $bookname = $book ? (string)($book->name ?: $book->filename) : '';
            $pagefrom = $hw ? (int)$hw->pagefrom : 0;
            $pageto = $hw ? (int)$hw->pageto : 0;
            $fixed = ai_service::fix_homework_errors_with_ai(array_values($questions), $report, $options, (int)$USER->id, $topicname, $bookname, $pagefrom, $pageto);
            $normalized = ai_service::normalize_homework_questions(array_values($fixed['questions'] ?? $questions), $options);
            $newreport = is_array($fixed['report'] ?? null) ? $fixed['report'] : ai_service::validate_homework_against_plan($normalized, $options);
            $normalizedjson = ai_service::questions_json($normalized);
            $previewjson = '';
            if ($hw) {
                $usage = ['model' => (string)($fixed['model'] ?? ''), 'tokens' => (int)($fixed['tokens'] ?? 0)];
                homework_repository::update($homeworkid, [
                    'sourcetext' => $normalizedjson,
                    'sourceformula' => local_aisgk_merge_sourceformula(local_aisgk_sourceformula_meta($homeworkid), $options, $newreport, $usage, (string)($fixed['model'] ?? ''), (string)($fixed['rawtext'] ?? '')),
                    'questiondata' => json_encode($normalized, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES),
                    'errormsg' => $newreport['ok'] ? '' : implode(' | ', $newreport['errors']),
                    'timemodified' => time(),
                ]);
                $previewoptions = $options;
                $previewoptions['preview_inline_images'] = true;
                $previewhw = homework_service::materialize_homework_images($homeworkid, $previewoptions);
                if ($previewhw && !empty($previewhw->previewquestiondata)) {
                    $previewjson = (string)$previewhw->previewquestiondata;
                }
            }
            echo json_encode([
                'ok' => true,
                'report' => $newreport,
                'normalizedjson' => $normalizedjson,
                'previewjson' => $previewjson,
                'usage' => ['model' => (string)($fixed['model'] ?? ''), 'tokens' => (int)($fixed['tokens'] ?? 0)],
                'message' => (string)($fixed['message'] ?? ''),
            ], JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
            break;

        case 'mergedrafts':
            $sectionid = required_param('sectionid', PARAM_INT);
            $idsraw = required_param('ids', PARAM_RAW);
            $ids = json_decode($idsraw, true);
            if (!is_array($ids)) { $ids = array_filter(array_map('intval', explode(',', $idsraw))); }
            $ids = array_values(array_unique(array_map('intval', $ids)));
            if (count($ids) < 2) { throw new moodle_exception('Cần chọn ít nhất 2 bản nháp để gộp.'); }
            $allquestions = [];
            $basehw = null;
            $mergedmeta = ['merged_from' => $ids, 'options' => []];
            foreach ($ids as $hid) {
                $hw = homework_repository::get_by_id((int)$hid);
                if (!$hw || (int)$hw->courseid !== $courseid || (int)$hw->sectionid !== $sectionid || (int)$hw->cancelled !== 0) { throw new moodle_exception('Nháp #' . (int)$hid . ' không hợp lệ.'); }
                if (trim((string)$hw->errormsg) !== '') { throw new moodle_exception('Chỉ được gộp bản nháp đã đạt. Nháp #' . (int)$hid . ' đang có lỗi.'); }
                if (!$basehw) { $basehw = $hw; }
                $sf = json_decode((string)$hw->sourceformula, true);
                if (is_array($sf) && !empty($sf['options']) && is_array($sf['options']) && empty($mergedmeta['options'])) { $mergedmeta['options'] = $sf['options']; }
                $qs = local_aisgk_questions_from_homework($hw);
                foreach ($qs as $q) { if (is_array($q)) { $allquestions[] = $q; } }
            }
            if (!$basehw || !$allquestions) { throw new moodle_exception('Không có câu hỏi để gộp.'); }
            $options = local_aisgk_merge_options((array)($mergedmeta['options'] ?? []), $allquestions);
            $normalized = ai_service::normalize_homework_questions($allquestions, $options);
            foreach ($normalized as $i => $q) { $normalized[$i]['question_no'] = $i + 1; unset($normalized[$i]['name'], $normalized[$i]['qtype']); }
            $report = ai_service::validate_homework_against_plan($normalized, $options);
            if (!$report['ok']) { throw new moodle_exception('Gộp nháp chưa đạt: ' . implode(' | ', $report['errors'])); }
            $json = ai_service::questions_json($normalized);
            $mergedmeta['options'] = $options;
            $mergedmeta['report'] = $report;
            $mergedmeta['merged_at'] = time();
            homework_repository::update((int)$basehw->id, [
                'topicname' => (string)$basehw->topicname . ' (gộp ' . count($ids) . ' nháp)',
                'sourcetext' => $json,
                'sourceformula' => json_encode($mergedmeta, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES),
                'questiondata' => json_encode($normalized, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES),
                'teacheredited' => homework_service::questions_to_text($normalized),
                'errormsg' => '',
                'status' => 'draft_ready',
                'timemodified' => time(),
            ]);
            $deleteids = array_values(array_diff($ids, [(int)$basehw->id]));
            if ($deleteids) { homework_repository::delete_by_ids($deleteids, $courseid, $sectionid); }
            $hw = homework_service::materialize_homework_images((int)$basehw->id, $options) ?: homework_repository::get_by_id((int)$basehw->id);
            echo json_encode(['ok' => true, 'homeworkid' => (int)$basehw->id, 'homework' => $hw, 'report' => $report, 'deleted' => count($deleteids)]);
            break;

        case 'drafts':
            $sectionid = required_param('sectionid', PARAM_INT);
            echo json_encode(['ok' => true, 'drafts' => homework_repository::find_recent_drafts($courseid, $sectionid, 30)]);
            break;

        case 'loaddraft':
            $homeworkid = required_param('homeworkid', PARAM_INT);
            $hw = homework_repository::get_by_id($homeworkid);
            if (!$hw || (int)$hw->courseid !== $courseid) { throw new moodle_exception('invalidparameter'); }
            $options = [];
            $sf = [];
            if (!empty($hw->sourceformula)) {
                $sf = json_decode((string)$hw->sourceformula, true);
                $options = is_array($sf) ? (array)($sf['options'] ?? $sf) : [];
            }
            if (!empty($sf['_sent_image_meta']) && empty($options['_sent_image_meta'])) { $options['_sent_image_meta'] = $sf['_sent_image_meta']; }
            $options['preview_inline_images'] = true;
            $hw = homework_service::materialize_homework_images($homeworkid, $options) ?: $hw;
            echo json_encode(['ok' => true, 'homework' => $hw]);
            break;

        case 'save':
            $homeworkid = required_param('homeworkid', PARAM_INT);
            $teacheredited = required_param('teacheredited', PARAM_RAW);
            $optionsraw = optional_param('options', '', PARAM_RAW);
            $jsonraw = optional_param('json', '', PARAM_RAW);
            $options = $optionsraw !== '' ? (json_decode($optionsraw, true) ?: []) : [];
            $scheduled = required_param('scheduledtime', PARAM_TEXT);
            $scheduledtime = strtotime($scheduled) ?: time();
            homework_service::update_draft($homeworkid, $teacheredited, $scheduledtime);
            $extra = ['sourceformula' => local_aisgk_merge_sourceformula(local_aisgk_sourceformula_meta($homeworkid), $options), 'timemodified' => time()];
            if ($jsonraw !== '') { $extra['sourcetext'] = $jsonraw; }
            homework_repository::update($homeworkid, $extra);
            echo json_encode(['ok' => true]);
            break;

        case 'approve':
            $homeworkid = required_param('homeworkid', PARAM_INT);
            $result = homework_service::approve_and_deliver($homeworkid, (int)$USER->id);
            echo json_encode(['ok' => true] + $result, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
            break;

        case 'cancel':
            $homeworkid = required_param('homeworkid', PARAM_INT);
            homework_service::cancel($homeworkid);
            echo json_encode(['ok' => true]);
            break;

        case 'deletebad':
            $sectionid = required_param('sectionid', PARAM_INT);
            $topicname = optional_param('topicname', '', PARAM_TEXT);
            $deleted = homework_service::delete_bad_drafts($courseid, $sectionid, $topicname);
            echo json_encode(['ok' => true, 'deleted' => $deleted]);
            break;

        case 'wipe':
            $sectionid = required_param('sectionid', PARAM_INT);
            $topicname = optional_param('topicname', '', PARAM_TEXT);
            $result = homework_service::wipe_course_topic($courseid, $sectionid, $topicname);
            echo json_encode(['ok' => true] + $result);
            break;

        default:
            throw new moodle_exception('invalidparameter');
    }
} catch (Throwable $e) {
    http_response_code(500);
    echo json_encode(['ok' => false, 'error' => $e->getMessage()]);
}
