<?php
defined('AJAX_SCRIPT') || define('AJAX_SCRIPT', true);
require('../../config.php');

use local_aisgk\book_repository;
use local_aisgk\homework_repository;
use local_aisgk\local\job_manager;
use local_aisgk\local\service\homework_service;
use local_aisgk\local\ai_service;
use local_aisgk\ai_key_manager;
use local_aisgk\local\sgk_processor;

$action = required_param('action', PARAM_ALPHAEXT);
$courseid = required_param('courseid', PARAM_INT);
$course = get_course($courseid);
require_login($course);
$PAGE->set_context(context_course::instance($course->id));
require_sesskey();
$context = context_course::instance($courseid);
$PAGE->set_context($context);
$PAGE->set_course($course);
$PAGE->set_url('/local/aisgk/homework_ajax.php', ['courseid' => $courseid, 'action' => $action]);
require_capability('local/aisgk:createhomework', $context);


function local_aisgk_download_sample_zip(int $courseid): void {
    global $CFG;
    $sectionid = required_param('sectionid', PARAM_INT);
    $topicname = required_param('topicname', PARAM_TEXT);
    $bookid = required_param('bookid', PARAM_INT);
    $pagefrom = required_param('pagefrom', PARAM_INT);
    $pageto = required_param('pageto', PARAM_INT);
    $optionsraw = optional_param('options', '', PARAM_RAW);
    $options = $optionsraw !== '' ? (json_decode($optionsraw, true) ?: []) : [];

    $mapped = homework_service::find_section_match($courseid, $sectionid);
    if ($mapped && ($bookid < 1 || $pagefrom < 1 || $pageto < $pagefrom)) {
        $bookid = (int)$mapped['book']->id;
        $pagefrom = (int)($mapped['toc']->trang ?? $pagefrom);
        $pageto = (int)($mapped['toc']->endtrang ?? $pageto);
        $topicname = trim((string)($mapped['toc']->tenbai ?? $topicname));
    }

    $book = book_repository::get_by_id($bookid);
    $bookname = $book ? (string)($book->name ?: $book->filename) : '';
    $total = (int)($options['total'] ?? 0);
    if ($total <= 0 && !empty($options['qtypes']) && is_array($options['qtypes'])) {
        $total = array_sum(array_map('intval', $options['qtypes']));
    }
    $total = max(1, min(60, $total));
    $prompt = ai_service::build_homework_prompt($topicname, $bookname, $pagefrom, $pageto, $total, $options);

    $tmpdir = make_temp_directory('local_aisgk/samplezip');
    $zipfile = $tmpdir . '/aisgk_sample_' . time() . '_' . random_int(1000, 9999) . '.zip';
    $zip = new ZipArchive();
    if ($zip->open($zipfile, ZipArchive::CREATE | ZipArchive::OVERWRITE) !== true) {
        throw new moodle_exception('Không tạo được file ZIP mẫu.');
    }
    $readme = "HƯỚNG DẪN\n"
        . "1. Mở prompt.txt và copy toàn bộ prompt.\n"
        . "2. Upload các ảnh trong thư mục images vào Gemini/AI web.\n"
        . "3. Dán prompt và yêu cầu AI trả JSON.\n"
        . "4. Copy JSON AI trả về và dán vào ô JSON đã normalize trong plugin.\n";
    $zip->addFromString('README.txt', $readme);
    $zip->addFromString('prompt.txt', $prompt);

    if ($book && $bookid > 0 && $pagefrom > 0 && $pageto >= $pagefrom) {
        $renderfrom = $pagefrom + 1;
        $renderto = $pageto + 1;
        $aiwidth = homework_service::normalize_ai_image_width($options['ai_image_width'] ?? 1000);
        $images = sgk_processor::render_page_images_cached($bookid, (int)$book->courseid, $sectionid, $renderfrom, $renderto, 200, null, true, $aiwidth);
        foreach (array_values($images) as $i => $path) {
            if (!is_readable($path)) { continue; }
            $ext = strtolower(pathinfo($path, PATHINFO_EXTENSION));
            if ($ext === '') { $ext = 'png'; }
            $sgkpage = $pagefrom + $i;
            $zip->addFile($path, 'images/sgk_page_' . sprintf('%03d', $sgkpage) . '.' . $ext);
        }
    }
    $zip->close();

    while (ob_get_level()) { ob_end_clean(); }
    header('Content-Type: application/zip');
    header('Content-Disposition: attachment; filename="aisgk_sample_package.zip"');
    header('Content-Length: ' . filesize($zipfile));
    header('Cache-Control: no-store, no-cache, must-revalidate, max-age=0');
    readfile($zipfile);
    @unlink($zipfile);
    exit;
}

if ($action === 'samplezip') {
    local_aisgk_download_sample_zip($courseid);
}

header('Content-Type: application/json; charset=utf-8');

function local_aisgk_sourceformula_meta(int $homeworkid): array {
    $hw = homework_repository::get_by_id($homeworkid);
    if (!$hw || empty($hw->sourceformula)) { return []; }
    $meta = json_decode((string)$hw->sourceformula, true);
    return is_array($meta) ? $meta : [];
}

function local_aisgk_merge_sourceformula(array $oldmeta, array $options, array $report = null, array $usage = null, string $model = '', string $raw = ''): string {
    $meta = $oldmeta;
    $meta['options'] = $options;
    if ($report !== null) { $meta['report'] = $report; }
    if ($usage !== null) { $meta['usage'] = $usage; }
    if ($model !== '') {
        $meta['model'] = $model;
        $meta['model_fix'] = $model;
    }
    if ($raw !== '') { $meta['fix_rawtext'] = $raw; }
    return json_encode($meta, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
}


function local_aisgk_questions_from_homework($hw): array {
    foreach ([(string)($hw->questiondata ?? ''), (string)($hw->sourcetext ?? '')] as $raw) {
        if ($raw === '') { continue; }
        $decoded = json_decode($raw, true);
        if (!is_array($decoded)) { continue; }
        $qs = $decoded['questions'] ?? $decoded;
        if (is_array($qs)) { return array_values($qs); }
    }
    return [];
}

function local_aisgk_merge_options(array $base, array $questions): array {
    $out = $base;
    $qtypes = [];
    $levels = [];
    foreach ($questions as $q) {
        if (!is_array($q)) { continue; }
        $type = (string)($q['qtype'] ?? $q['type'] ?? '');
        $level = (string)($q['level'] ?? '');
        if ($type !== '') { $qtypes[$type] = ($qtypes[$type] ?? 0) + 1; }
        if ($level !== '') { $levels[$level] = ($levels[$level] ?? 0) + 1; }
    }
    $out['qtypes'] = $qtypes;
    $out['cognitive'] = $levels;
    $out['total'] = count($questions);
    if (empty($out['distractors']) || !is_array($out['distractors'])) { $out['distractors'] = []; }
    return $out;
}

try {
    switch ($action) {
        case 'prefill':
            $topicname = required_param('topicname', PARAM_TEXT);
            $match = homework_service::find_topic_match($courseid, $topicname);
            $out = ['ok' => true, 'match' => null, 'books' => []];
            foreach (book_repository::get_all_by_courseid($courseid) as $book) {
                $out['books'][] = ['id' => (int)$book->id, 'name' => $book->name];
            }
            if ($match) {
                $out['match'] = [
                    'bookid' => (int)$match['book']->id,
                    'bookname' => $match['book']->name,
                    'pagefrom' => (int)($match['toc']->trang ?? 0),
                    'pageto' => (int)($match['toc']->endtrang ?? 0),
                    'tenbai' => $match['toc']->tenbai,
                ];
            }
            echo json_encode($out);
            break;

        case 'start':
            $sectionid = required_param('sectionid', PARAM_INT);
            $topicname = required_param('topicname', PARAM_TEXT);
            $bookid = required_param('bookid', PARAM_INT);
            $pagefrom = required_param('pagefrom', PARAM_INT);
            $pageto = required_param('pageto', PARAM_INT);
            $scheduled = required_param('scheduledtime', PARAM_TEXT);
            $scheduledtime = strtotime($scheduled) ?: time();
            $optionsraw = optional_param('options', '', PARAM_RAW);
            $options = $optionsraw !== '' ? (json_decode($optionsraw, true) ?: []) : [];

            // Tôn trọng đúng bookid/pagefrom/pageto gửi từ popup. Chỉ dùng mapping section -> mục lục
            // để bổ sung khi popup không có đủ dữ liệu, tránh scan nhầm trang mục lục.
            $mapped = homework_service::find_section_match($courseid, $sectionid);
            if ($mapped && ($bookid < 1 || $pagefrom < 1 || $pageto < $pagefrom)) {
                $bookid = (int)$mapped['book']->id;
                $pagefrom = (int)($mapped['toc']->trang ?? $pagefrom);
                $pageto = (int)($mapped['toc']->endtrang ?? $pageto);
                $topicname = trim((string)($mapped['toc']->tenbai ?? $topicname));
            }

            $result = homework_service::create_draft_job($USER->id, $courseid, $sectionid, $topicname, $bookid, $pagefrom, $pageto, $scheduledtime, $options);
            $job = job_manager::get((int)$result['jobid']);
            } catch (Throwable $e) {
        echo json_encode([
            'ok' => false,
            'error' => $e->getMessage()
        ]);
        die;
    }
}



if ($op === 'approvequiz') {
    define('AJAX_SCRIPT', true);
    require_login($course);
    $PAGE->set_context(context_course::instance($course->id));
    header('Content-Type: application/json');

    try {
        global $DB, $CFG;

        require_once($CFG->dirroot.'/course/modlib.php');
        require_once($CFG->dirroot.'/mod/quiz/lib.php');

        $sectionid = required_param('sectionid', PARAM_INT);

        $moduleinfo = new stdClass();
        $moduleinfo->modulename = 'quiz';
        $moduleinfo->module = $DB->get_field('modules', 'id', ['name' => 'quiz']);
        $moduleinfo->section = $sectionid;
        $moduleinfo->course = $course->id;
        $moduleinfo->name = 'AI Homework';
        $moduleinfo->intro = 'Generated by AISGK';
        $moduleinfo->introformat = FORMAT_HTML;
        $moduleinfo->visible = 1;
        $moduleinfo->groupmode = 0;
        $moduleinfo->groupingid = 0;
        $moduleinfo->password = '';

        $created = add_moduleinfo($moduleinfo, $course);

        rebuild_course_cache($course->id, true);
        course_modinfo::clear_instance_cache();

        echo json_encode([
            'ok' => true,
            'cmid' => $created->coursemodule,
            'reload' => true
        ]);
    } catch (Throwable $e) {
        echo json_encode([
            'ok' => false,
            'error' => $e->getMessage()
        ]);
    }
    die;
}

