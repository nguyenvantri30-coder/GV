<?php
require('../../config.php');

use local_aisgk\book_repository;
use local_aisgk\homework_repository;
use local_aisgk\local\job_manager;
use local_aisgk\local\service\homework_service;
use local_aisgk\local\ai_service;

require_login();
require_sesskey();

$action = required_param('action', PARAM_ALPHAEXT);
$courseid = required_param('courseid', PARAM_INT);
$context = context_course::instance($courseid);
require_capability('local/aisgk:createhomework', $context);

header('Content-Type: application/json; charset=utf-8');

try {
    switch ($action) {
        case 'prefill':
            $topicname = required_param('topicname', PARAM_TEXT);
            $match = homework_service::find_topic_match($courseid, $topicname);
            $out = ['ok' => true, 'match' => null, 'books' => []];
            foreach (book_repository::get_all_by_courseid($courseid) as $book) {
                $out['books'][] = ['id' => (int)$book->id, 'name' => $book->name];
            }
            if ($match) {
                $out['match'] = [
                    'bookid' => (int)$match['book']->id,
                    'bookname' => $match['book']->name,
                    'pagefrom' => (int)($match['toc']->trang ?? 0),
                    'pageto' => (int)($match['toc']->endtrang ?? 0),
                    'tenbai' => $match['toc']->tenbai,
                ];
            }
            echo json_encode($out);
            break;

        case 'start':
            $sectionid = required_param('sectionid', PARAM_INT);
            $topicname = required_param('topicname', PARAM_TEXT);
            $bookid = required_param('bookid', PARAM_INT);
            $pagefrom = required_param('pagefrom', PARAM_INT);
            $pageto = required_param('pageto', PARAM_INT);
            $scheduled = required_param('scheduledtime', PARAM_TEXT);
            $scheduledtime = strtotime($scheduled) ?: time();
            $optionsraw = optional_param('options', '', PARAM_RAW);
            $options = $optionsraw !== '' ? (json_decode($optionsraw, true) ?: []) : [];

            // Tôn trọng đúng bookid/pagefrom/pageto gửi từ popup. Chỉ dùng mapping section -> mục lục
            // để bổ sung khi popup không có đủ dữ liệu, tránh scan nhầm trang mục lục.
            $mapped = homework_service::find_section_match($courseid, $sectionid);
            if ($mapped && ($bookid < 1 || $pagefrom < 1 || $pageto < $pagefrom)) {
                $bookid = (int)$mapped['book']->id;
                $pagefrom = (int)($mapped['toc']->trang ?? $pagefrom);
                $pageto = (int)($mapped['toc']->endtrang ?? $pageto);
                $topicname = trim((string)($mapped['toc']->tenbai ?? $topicname));
            }

            $result = homework_service::create_draft_job($USER->id, $courseid, $sectionid, $topicname, $bookid, $pagefrom, $pageto, $scheduledtime, $options);
            $job = job_manager::get((int)$result['jobid']);
            echo json_encode(['ok' => true, 'jobid' => (int)$job->id, 'job' => $job, 'reused' => !empty($result['reused'])]);
            break;

        case 'status':
            $jobid = required_param('jobid', PARAM_INT);
            $job = job_manager::get($jobid);
            if (!$job) {
                throw new moodle_exception('invalidparameter');
            }
            $payload = json_decode((string)$job->payloadjson, true) ?: [];
            $homework = !empty($payload['homeworkid']) ? homework_repository::get_by_id((int)$payload['homeworkid']) : null;
            $result = json_decode((string)$job->resultjson, true) ?: [];
            echo json_encode(['ok' => true, 'job' => $job, 'homework' => $homework, 'result' => $result]);
            break;

        case 'validatejson':
            $optionsraw = required_param('options', PARAM_RAW);
            $jsonraw = required_param('json', PARAM_RAW);
            $options = json_decode($optionsraw, true) ?: [];
            $decoded = json_decode($jsonraw, true);
            if (!is_array($decoded)) {
                echo json_encode(['ok' => true, 'report' => ['ok' => false, 'errors' => ['JSON lỗi: ' . json_last_error_msg()], 'summary' => ['qtypes' => [], 'levels' => []]]]);
                break;
            }
            $questions = $decoded['questions'] ?? $decoded;
            if (!is_array($questions)) { $questions = []; }
            $normalized = ai_service::normalize_homework_questions(array_values($questions), $options);
            $report = ai_service::validate_homework_against_plan($normalized, $options);
            if ($report['ok'] && optional_param('homeworkid', 0, PARAM_INT)) {
                $hid = optional_param('homeworkid', 0, PARAM_INT);
                homework_repository::update($hid, ['sourcetext' => ai_service::questions_json($normalized), 'questiondata' => json_encode($normalized, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES), 'timemodified' => time()]);
            }
            echo json_encode(['ok' => true, 'report' => $report, 'normalizedjson' => ai_service::questions_json($normalized)]);
            break;

        case 'drafts':
            $sectionid = required_param('sectionid', PARAM_INT);
            echo json_encode(['ok' => true, 'drafts' => homework_repository::find_recent_drafts($courseid, $sectionid, 30)]);
            break;

        case 'loaddraft':
            $homeworkid = required_param('homeworkid', PARAM_INT);
            $hw = homework_repository::get_by_id($homeworkid);
            if (!$hw || (int)$hw->courseid !== $courseid) { throw new moodle_exception('invalidparameter'); }
            echo json_encode(['ok' => true, 'homework' => $hw]);
            break;

        case 'save':
            $homeworkid = required_param('homeworkid', PARAM_INT);
            $teacheredited = required_param('teacheredited', PARAM_RAW);
            $scheduled = required_param('scheduledtime', PARAM_TEXT);
            $scheduledtime = strtotime($scheduled) ?: time();
            homework_service::update_draft($homeworkid, $teacheredited, $scheduledtime);
            echo json_encode(['ok' => true]);
            break;

        case 'approve':
            $homeworkid = required_param('homeworkid', PARAM_INT);
            homework_service::approve($homeworkid);
            echo json_encode(['ok' => true]);
            break;

        case 'cancel':
            $homeworkid = required_param('homeworkid', PARAM_INT);
            homework_service::cancel($homeworkid);
            echo json_encode(['ok' => true]);
            break;

        default:
            throw new moodle_exception('invalidparameter');
    }
} catch (Throwable $e) {
    http_response_code(500);
    echo json_encode(['ok' => false, 'error' => $e->getMessage()]);
}
