<?php
defined('AJAX_SCRIPT') || define('AJAX_SCRIPT', true);
require('../../config.php');

use local_aisgk\book_repository;
use local_aisgk\homework_repository;
use local_aisgk\local\job_manager;
use local_aisgk\local\service\homework_service;
use local_aisgk\local\ai_service;
use local_aisgk\ai_key_manager;
use local_aisgk\local\sgk_processor;

$action = required_param('action', PARAM_ALPHAEXT);
$courseid = required_param('courseid', PARAM_INT);
$course = get_course($courseid);
require_login($course);
$PAGE->set_context(context_course::instance($course->id));
require_sesskey();
$context = context_course::instance($courseid);
$PAGE->set_context($context);
$PAGE->set_course($course);
$PAGE->set_url('/local/aisgk/homework_ajax.php', ['courseid' => $courseid, 'action' => $action]);
require_capability('local/aisgk:createhomework', $context);


function local_aisgk_download_sample_zip(int $courseid): void {
    global $CFG;
    $sectionid = required_param('sectionid', PARAM_INT);
    $topicname = required_param('topicname', PARAM_TEXT);
    $bookid = required_param('bookid', PARAM_INT);
    $pagefrom = required_param('pagefrom', PARAM_INT);
    $pageto = required_param('pageto', PARAM_INT);
    $optionsraw = optional_param('options', '', PARAM_RAW);
    $options = $optionsraw !== '' ? (json_decode($optionsraw, true) ?: []) : [];

    $mapped = homework_service::find_section_match($courseid, $sectionid);
    if ($mapped && ($bookid < 1 || $pagefrom < 1 || $pageto < $pagefrom)) {
        $bookid = (int)$mapped['book']->id;
        $pagefrom = (int)($mapped['toc']->trang ?? $pagefrom);
        $pageto = (int)($mapped['toc']->endtrang ?? $pageto);
        $topicname = trim((string)($mapped['toc']->tenbai ?? $topicname));
    }

    $book = book_repository::get_by_id($bookid);
    $bookname = $book ? (string)($book->name ?: $book->filename) : '';
    $total = (int)($options['total'] ?? 0);
    if ($total <= 0 && !empty($options['qtypes']) && is_array($options['qtypes'])) {
        $total = array_sum(array_map('intval', $options['qtypes']));
    }
    $total = max(1, min(60, $total));
    $prompt = ai_service::build_homework_prompt($topicname, $bookname, $pagefrom, $pageto, $total, $options);

    $tmpdir = make_temp_directory('local_aisgk/samplezip');
    $zipfile = $tmpdir . '/aisgk_sample_' . time() . '_' . random_int(1000, 9999) . '.zip';
    $zip = new ZipArchive();
    if ($zip->open($zipfile, ZipArchive::CREATE | ZipArchive::OVERWRITE) !== true) {
        throw new moodle_exception('Không tạo được file ZIP mẫu.');
    }
    $readme = "HƯỚNG DẪN\n"
        . "1. Mở prompt.txt và copy toàn bộ prompt.\n"
        . "2. Upload các ảnh trong thư mục images vào Gemini/AI web.\n"
        . "3. Dán prompt và yêu cầu AI trả JSON.\n"
        . "4. Copy JSON AI trả về và dán vào ô JSON đã normalize trong plugin.\n";
    $zip->addFromString('README.txt', $readme);
    $zip->addFromString('prompt.txt', $prompt);

    if ($book && $bookid > 0 && $pagefrom > 0 && $pageto >= $pagefrom) {
        $renderfrom = $pagefrom + 1;
        $renderto = $pageto + 1;
        $aiwidth = homework_service::normalize_ai_image_width($options['ai_image_width'] ?? 1000);
        $images = sgk_processor::render_page_images_cached($bookid, (int)$book->courseid, $sectionid, $renderfrom, $renderto, 200, null, true, $aiwidth);
        foreach (array_values($images) as $i => $path) {
            if (!is_readable($path)) { continue; }
            $ext = strtolower(pathinfo($path, PATHINFO_EXTENSION));
            if ($ext === '') { $ext = 'png'; }
            $sgkpage = $pagefrom + $i;
            $zip->addFile($path, 'images/sgk_page_' . sprintf('%03d', $sgkpage) . '.' . $ext);
        }
    }
    $zip->close();

    while (ob_get_level()) { ob_end_clean(); }
    header('Content-Type: application/zip');
    header('Content-Disposition: attachment; filename="aisgk_sample_package.zip"');
    header('Content-Length: ' . filesize($zipfile));
    header('Cache-Control: no-store, no-cache, must-revalidate, max-age=0');
    readfile($zipfile);
    @unlink($zipfile);
    exit;
}

if ($action === 'samplezip') {
    local_aisgk_download_sample_zip($courseid);
}

header('Content-Type: application/json; charset=utf-8');

function local_aisgk_sourceformula_meta(int $homeworkid): array {
    $hw = homework_repository::get_by_id($homeworkid);
    if (!$hw || empty($hw->sourceformula)) { return []; }
    $meta = json_decode((string)$hw->sourceformula, true);
    return is_array($meta) ? $meta : [];
}

function local_aisgk_merge_sourceformula(array $oldmeta, array $options, array $report = null, array $usage = null, string $model = '', string $raw = ''): string {
    $meta = $oldmeta;
    $meta['options'] = $options;
    if ($report !== null) { $meta['report'] = $report; }
    if ($usage !== null) { $meta['usage'] = $usage; }
    if ($model !== '') {
        $meta['model'] = $model;
        $meta['model_fix'] = $model;
    }
    if ($raw !== '') { $meta['fix_rawtext'] = $raw; }
    return json_encode($meta, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
}


function local_aisgk_questions_from_homework($hw): array {
    foreach ([(string)($hw->questiondata ?? ''), (string)($hw->sourcetext ?? '')] as $raw) {
        if ($raw === '') { continue; }
        $decoded = json_decode($raw, true);
        if (!is_array($decoded)) { continue; }
        $qs = $decoded['questions'] ?? $decoded;
        if (is_array($qs)) { return array_values($qs); }
    }
    return [];
}

function local_aisgk_merge_options(array $base, array $questions): array {
    $out = $base;
    $qtypes = [];
    $levels = [];
    foreach ($questions as $q) {
        if (!is_array($q)) { continue; }
        $type = (string)($q['qtype'] ?? $q['type'] ?? '');
        $level = (string)($q['level'] ?? '');
        if ($type !== '') { $qtypes[$type] = ($qtypes[$type] ?? 0) + 1; }
        if ($level !== '') { $levels[$level] = ($levels[$level] ?? 0) + 1; }
    }
    $out['qtypes'] = $qtypes;
    $out['cognitive'] = $levels;
    $out['total'] = count($questions);
    if (empty($out['distractors']) || !is_array($out['distractors'])) { $out['distractors'] = []; }
    return $out;
}

try {
    switch ($action) {
        case 'prefill':
            $topicname = required_param('topicname', PARAM_TEXT);
            $match = homework_service::find_topic_match($courseid, $topicname);
            $out = ['ok' => true, 'match' => null, 'books' => []];
            foreach (book_repository::get_all_by_courseid($courseid) as $book) {
                $out['books'][] = ['id' => (int)$book->id, 'name' => $book->name];
            }
            if ($match) {
                $out['match'] = [
                    'bookid' => (int)$match['book']->id,
                    'bookname' => $match['book']->name,
                    'pagefrom' => (int)($match['toc']->trang ?? 0),
                    'pageto' => (int)($match['toc']->endtrang ?? 0),
                    'tenbai' => $match['toc']->tenbai,
                ];
            }
            echo json_encode($out);
            break;

        case 'start':
            $sectionid = required_param('sectionid', PARAM_INT);
            $topicname = required_param('topicname', PARAM_TEXT);
            $bookid = required_param('bookid', PARAM_INT);
            $pagefrom = required_param('pagefrom', PARAM_INT);
            $pageto = required_param('pageto', PARAM_INT);
            $scheduled = required_param('scheduledtime', PARAM_TEXT);
            $scheduledtime = strtotime($scheduled) ?: time();
            $optionsraw = optional_param('options', '', PARAM_RAW);
            $options = $optionsraw !== '' ? (json_decode($optionsraw, true) ?: []) : [];

            // Tôn trọng đúng bookid/pagefrom/pageto gửi từ popup. Chỉ dùng mapping section -> mục lục
            // để bổ sung khi popup không có đủ dữ liệu, tránh scan nhầm trang mục lục.
            $mapped = homework_service::find_section_match($courseid, $sectionid);
            if ($mapped && ($bookid < 1 || $pagefrom < 1 || $pageto < $pagefrom)) {
                $bookid = (int)$mapped['book']->id;
                $pagefrom = (int)($mapped['toc']->trang ?? $pagefrom);
                $pageto = (int)($mapped['toc']->endtrang ?? $pageto);
                $topicname = trim((string)($mapped['toc']->tenbai ?? $topicname));
            }

            $result = homework_service::create_draft_job($USER->id, $courseid, $sectionid, $topicname, $bookid, $pagefrom, $pageto, $scheduledtime, $options);
            $job = job_manager::get((int)$result['jobid']);
            echo json_encode(['ok' => true, 'jobid' => (int)$job->id, 'job' => $job, 'reused' => !empty($result['reused']), 'userusage' => ai_key_manager::user_daily_usage_summary((int)$USER->id)]);
            break;

        case 'status':
            $jobid = required_param('jobid', PARAM_INT);
            $job = job_manager::get($jobid);
            if (!$job) {
                throw new moodle_exception('invalidparameter');
            }
            $payload = json_decode((string)$job->payloadjson, true) ?: [];
            $homework = !empty($payload['homeworkid']) ? homework_repository::get_by_id((int)$payload['homeworkid']) : null;
            if ($homework) {
                $opts = is_array($payload['options'] ?? null) ? (array)$payload['options'] : [];
                $homework = homework_service::materialize_homework_images((int)$homework->id, $opts) ?: $homework;
            }
            $result = json_decode((string)$job->resultjson, true) ?: [];
            $position = job_manager::queue_position((int)$job->id);
            if ((string)$job->status === 'queued' && $position > 0) {
                $job->queueposition = $position;
                $job->message = 'Bạn đang ở vị trí thứ ' . $position . ' trong hàng đợi, vui lòng đợi giây lát.';
            }
            echo json_encode(['ok' => true, 'job' => $job, 'homework' => $homework, 'result' => $result, 'queueposition' => $position, 'userusage' => ai_key_manager::user_daily_usage_summary((int)$USER->id)]);
            break;


        case 'usage':
            echo json_encode(['ok' => true, 'userusage' => ai_key_manager::user_daily_usage_summary((int)$USER->id)]);
            break;

        case 'copytemplate':
            $sectionid = required_param('sectionid', PARAM_INT);
            $topicname = required_param('topicname', PARAM_TEXT);
            $bookid = required_param('bookid', PARAM_INT);
            $pagefrom = required_param('pagefrom', PARAM_INT);
            $pageto = required_param('pageto', PARAM_INT);
            $optionsraw = optional_param('options', '', PARAM_RAW);
            $options = $optionsraw !== '' ? (json_decode($optionsraw, true) ?: []) : [];
            $mapped = homework_service::find_section_match($courseid, $sectionid);
            if ($mapped && ($bookid < 1 || $pagefrom < 1 || $pageto < $pagefrom)) {
                $bookid = (int)$mapped['book']->id;
                $pagefrom = (int)($mapped['toc']->trang ?? $pagefrom);
                $pageto = (int)($mapped['toc']->endtrang ?? $pageto);
                $topicname = trim((string)($mapped['toc']->tenbai ?? $topicname));
            }
            $book = book_repository::get_by_id($bookid);
            $bookname = $book ? (string)($book->name ?: $book->filename) : '';
            $total = (int)($options['total'] ?? 0);
            if ($total <= 0 && !empty($options['qtypes']) && is_array($options['qtypes'])) {
                $total = array_sum(array_map('intval', $options['qtypes']));
            }
            $total = max(1, min(60, $total));
            $prompt = ai_service::build_homework_prompt($topicname, $bookname, $pagefrom, $pageto, $total, $options);
            $imageinfo = [];
            if ($book && $bookid > 0 && $pagefrom > 0 && $pageto >= $pagefrom) {
                $renderfrom = $pagefrom + 1;
                $renderto = $pageto + 1;
                try {
                    $aiwidth = homework_service::normalize_ai_image_width($options['ai_image_width'] ?? 1000);
                    $images = sgk_processor::render_page_images_cached($bookid, (int)$book->courseid, $sectionid, $renderfrom, $renderto, 180, null, true, $aiwidth);
                    foreach (array_values($images) as $i => $path) {
                        $imageinfo[] = 'Ảnh ' . ($i + 1) . ' · SGK trang ' . ($pagefrom + $i) . ' · PDF page ' . ($renderfrom + $i) . ' · file: ' . $path;
                    }
                } catch (Throwable $e) {
                    $imageinfo[] = 'Không render được ảnh mẫu: ' . $e->getMessage();
                }
            }
            $copytext = "PROMPT GỬI AI\n================\n" . $prompt . "\n\nẢNH GỬI AI\n================\n" . implode("\n", $imageinfo);
            echo json_encode(['ok' => true, 'prompt' => $prompt, 'images' => $imageinfo, 'copytext' => $copytext]);
            break;

        case 'validatejson':
            $optionsraw = required_param('options', PARAM_RAW);
            $jsonraw = required_param('json', PARAM_RAW);
            $options = json_decode($optionsraw, true) ?: [];
            $hid = optional_param('homeworkid', 0, PARAM_INT);
            if ($hid) {
                $oldmeta = local_aisgk_sourceformula_meta($hid);
                $oldoptions = is_array($oldmeta['options'] ?? null) ? (array)$oldmeta['options'] : [];
                if (!empty($oldmeta['_sent_image_meta']) && empty($options['_sent_image_meta'])) {
                    $options['_sent_image_meta'] = $oldmeta['_sent_image_meta'];
                } else if (!empty($oldoptions['_sent_image_meta']) && empty($options['_sent_image_meta'])) {
                    $options['_sent_image_meta'] = $oldoptions['_sent_image_meta'];
                }
            }
            $decoded = json_decode($jsonraw, true);
            if (!is_array($decoded)) {
                echo json_encode(['ok' => true, 'report' => ['ok' => false, 'errors' => ['JSON lỗi: ' . json_last_error_msg()], 'summary' => ['qtypes' => [], 'levels' => []]]]);
                break;
            }
            $questions = $decoded['questions'] ?? $decoded;
            if (!is_array($questions)) { $questions = []; }
            $normalized = ai_service::normalize_homework_questions(array_values($questions), $options);
            $report = ai_service::validate_homework_against_plan($normalized, $options);
            $normalizedjson = ai_service::questions_json($normalized);
            $hasdebugraw = is_array($decoded) && array_key_exists('_debug', $decoded);

            // Phase debug: luôn autosave, kể cả report chưa đạt. Nếu sourcetext đang có _debug/raw_ai_text
            // thì giữ nguyên nó để không mất raw kết quả AI; questiondata vẫn lưu JSON đã normalize.
            if ($hid) {
                homework_repository::update($hid, [
                    'sourcetext' => $hasdebugraw ? $jsonraw : $normalizedjson,
                    'sourceformula' => local_aisgk_merge_sourceformula(local_aisgk_sourceformula_meta($hid), $options, $report),
                    'questiondata' => json_encode($normalized, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES),
                    'errormsg' => $report['ok'] ? '' : implode(' | ', $report['errors']),
                    'timemodified' => time(),
                ]);
                $previewjson = '';
                $previewoptions = $options;
                $previewoptions['preview_inline_images'] = true;
                $previewhw = homework_service::materialize_homework_images($hid, $previewoptions);
                if ($previewhw && !empty($previewhw->previewquestiondata)) {
                    $previewjson = (string)$previewhw->previewquestiondata;
                }
            }
            echo json_encode(['ok' => true, 'report' => $report, 'normalizedjson' => $normalizedjson, 'hasdebugraw' => $hasdebugraw, 'previewjson' => $previewjson ?? '']);

            break;

        case 'fixerrors':
            // DEBUG MODE 2026-05-02: tạm tắt endpoint gửi AI sửa lỗi.
            // Không gọi AI, không ghi đè raw/normalized JSON hiện tại.
            echo json_encode([
                'ok' => false,
                'disabled' => true,
                'error' => 'AUTO_FIX_DISABLED_DEBUG_RAW',
                'message' => 'Đã tạm tắt AI sửa lỗi. Bản chưa đạt vẫn giữ raw để debug.',
            ], JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
            break;

        case 'mergedrafts':
            $sectionid = required_param('sectionid', PARAM_INT);
            $idsraw = required_param('ids', PARAM_RAW);
            $ids = json_decode($idsraw, true);
            if (!is_array($ids)) { $ids = array_filter(array_map('intval', explode(',', $idsraw))); }
            $ids = array_values(array_unique(array_map('intval', $ids)));
            if (count($ids) < 2) { throw new moodle_exception('Cần chọn ít nhất 2 bản nháp để gộp.'); }
            $allquestions = [];
            $basehw = null;
            $mergedmeta = ['merged_from' => $ids, 'options' => []];
            foreach ($ids as $hid) {
                $hw = homework_repository::get_by_id((int)$hid);
                if (!$hw || (int)$hw->courseid !== $courseid || (int)$hw->sectionid !== $sectionid || (int)$hw->cancelled !== 0) { throw new moodle_exception('Nháp #' . (int)$hid . ' không hợp lệ.'); }
                if (trim((string)$hw->errormsg) !== '') { throw new moodle_exception('Chỉ được gộp bản nháp đã đạt. Nháp #' . (int)$hid . ' đang có lỗi.'); }
                if (!$basehw) { $basehw = $hw; }
                $sf = json_decode((string)$hw->sourceformula, true);
                if (is_array($sf) && !empty($sf['options']) && is_array($sf['options']) && empty($mergedmeta['options'])) { $mergedmeta['options'] = $sf['options']; }
                $qs = local_aisgk_questions_from_homework($hw);
                foreach ($qs as $q) { if (is_array($q)) { $allquestions[] = $q; } }
            }
            if (!$basehw || !$allquestions) { throw new moodle_exception('Không có câu hỏi để gộp.'); }
            $options = local_aisgk_merge_options((array)($mergedmeta['options'] ?? []), $allquestions);
            $normalized = ai_service::normalize_homework_questions($allquestions, $options);
            foreach ($normalized as $i => $q) { $normalized[$i]['question_no'] = $i + 1; unset($normalized[$i]['name'], $normalized[$i]['qtype']); }
            $report = ai_service::validate_homework_against_plan($normalized, $options);
            if (!$report['ok']) { throw new moodle_exception('Gộp nháp chưa đạt: ' . implode(' | ', $report['errors'])); }
            $json = ai_service::questions_json($normalized);
            $mergedmeta['options'] = $options;
            $mergedmeta['report'] = $report;
            $mergedmeta['merged_at'] = time();
            homework_repository::update((int)$basehw->id, [
                'topicname' => (string)$basehw->topicname . ' (gộp ' . count($ids) . ' nháp)',
                'sourcetext' => $json,
                'sourceformula' => json_encode($mergedmeta, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES),
                'questiondata' => json_encode($normalized, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES),
                'teacheredited' => homework_service::questions_to_text($normalized),
                'errormsg' => '',
                'status' => 'draft_ready',
                'timemodified' => time(),
            ]);
            $deleteids = array_values(array_diff($ids, [(int)$basehw->id]));
            if ($deleteids) { homework_repository::delete_by_ids($deleteids, $courseid, $sectionid); }
            $hw = homework_service::materialize_homework_images((int)$basehw->id, $options) ?: homework_repository::get_by_id((int)$basehw->id);
            echo json_encode(['ok' => true, 'homeworkid' => (int)$basehw->id, 'homework' => $hw, 'report' => $report, 'deleted' => count($deleteids)]);
            break;

        case 'drafts':
            $sectionid = required_param('sectionid', PARAM_INT);
            echo json_encode(['ok' => true, 'drafts' => homework_repository::find_recent_drafts($courseid, $sectionid, 30)]);
            break;

        case 'loaddraft':
            $homeworkid = required_param('homeworkid', PARAM_INT);
            $hw = homework_repository::get_by_id($homeworkid);
            if (!$hw || (int)$hw->courseid !== $courseid) { throw new moodle_exception('invalidparameter'); }
            $options = [];
            $sf = [];
            if (!empty($hw->sourceformula)) {
                $sf = json_decode((string)$hw->sourceformula, true);
                $options = is_array($sf) ? (array)($sf['options'] ?? $sf) : [];
            }
            if (!empty($sf['_sent_image_meta']) && empty($options['_sent_image_meta'])) { $options['_sent_image_meta'] = $sf['_sent_image_meta']; }
            $options['preview_inline_images'] = true;
            $hw = homework_service::materialize_homework_images($homeworkid, $options) ?: $hw;
            echo json_encode(['ok' => true, 'homework' => $hw]);
            break;

        case 'save':
            $homeworkid = required_param('homeworkid', PARAM_INT);
            $teacheredited = required_param('teacheredited', PARAM_RAW);
            $optionsraw = optional_param('options', '', PARAM_RAW);
            $jsonraw = optional_param('json', '', PARAM_RAW);
            $options = $optionsraw !== '' ? (json_decode($optionsraw, true) ?: []) : [];
            $scheduled = required_param('scheduledtime', PARAM_TEXT);
            $scheduledtime = strtotime($scheduled) ?: time();
            homework_service::update_draft($homeworkid, $teacheredited, $scheduledtime);
            $extra = ['sourceformula' => local_aisgk_merge_sourceformula(local_aisgk_sourceformula_meta($homeworkid), $options), 'timemodified' => time()];
            if ($jsonraw !== '') { $extra['sourcetext'] = $jsonraw; }
            homework_repository::update($homeworkid, $extra);
            echo json_encode(['ok' => true]);
            break;

        case 'approve':
            $homeworkid = required_param('homeworkid', PARAM_INT);
            $result = homework_service::approve_and_deliver($homeworkid, (int)$USER->id);
            echo json_encode(['ok' => true] + $result, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
            break;

        case 'cancel':
            $homeworkid = required_param('homeworkid', PARAM_INT);
            homework_service::cancel($homeworkid);
            echo json_encode(['ok' => true]);
            break;

        case 'deletebad':
            $sectionid = required_param('sectionid', PARAM_INT);
            $topicname = optional_param('topicname', '', PARAM_TEXT);
            $deleted = homework_service::delete_bad_drafts($courseid, $sectionid, $topicname);
            echo json_encode(['ok' => true, 'deleted' => $deleted]);
            break;

        case 'wipe':
            $sectionid = required_param('sectionid', PARAM_INT);
            $topicname = optional_param('topicname', '', PARAM_TEXT);
            $result = homework_service::wipe_course_topic($courseid, $sectionid, $topicname);
            echo json_encode(['ok' => true] + $result);
            break;

        default:
            throw new moodle_exception('invalidparameter');
    }
} catch (Throwable $e) {
    if (!headers_sent()) {
        http_response_code(500);
        header('Content-Type: application/json; charset=utf-8');
    }
    while (ob_get_level()) { ob_end_clean(); }
    echo json_encode(['ok' => false, 'error' => $e->getMessage()], JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
}


// AISGK QUIZ IMPORT PATCH
require_once($CFG->dirroot.'/course/modlib.php');
require_once($CFG->dirroot.'/mod/quiz/lib.php');

if (!empty($courseid) && !empty($sectionid)) {
    try {
        $moduleinfo = new stdClass();
        $moduleinfo->modulename = 'quiz';
        $moduleinfo->module = $DB->get_field('modules', 'id', ['name' => 'quiz']);
        $moduleinfo->course = $courseid;
        $moduleinfo->section = $sectionid;
        $moduleinfo->visible = 1;
        $moduleinfo->groupmode = 0;
        $moduleinfo->groupingid = 0;
        $moduleinfo->name = 'AI Homework';
        $moduleinfo->intro = 'Generated by AISGK';
        $moduleinfo->introformat = FORMAT_HTML;

        $createdcm = add_moduleinfo($moduleinfo, $course);

        rebuild_course_cache($courseid, true);
        course_modinfo::clear_instance_cache();

        echo json_encode([
            'ok' => true,
            'cmid' => $createdcm->coursemodule,
            'refresh' => true
        ]);
        die;
    } catch (Throwable $e) {
        echo json_encode([
            'ok' => false,
            'error' => $e->getMessage()
        ]);
        die;
    }
}
