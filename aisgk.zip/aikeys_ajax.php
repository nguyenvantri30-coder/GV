<?php
require('../../config.php');

use local_aisgk\aikey_repository;

if (!defined('AJAX_SCRIPT')) {
    define('AJAX_SCRIPT', true);
}

$courseid = required_param('id', PARAM_INT);
$op = required_param('op', PARAM_ALPHA);
require_sesskey();

$course = get_course($courseid);
require_login($course);
if (!is_siteadmin()) {
    throw new required_capability_exception(context_system::instance(), 'moodle/site:config', 'nopermissions', '');
}

header('Content-Type: application/json; charset=utf-8');
$payload = json_decode(file_get_contents('php://input'), true) ?: [];

function local_aisgk_aikeys_json_rows(array $rows): array {
    $out = [];
    foreach ($rows as $row) {
        $lastused = (int)($row->last_used ?? $row['last_used'] ?? 0);
        $usagesync = (int)($row->usage_last_sync ?? $row['usage_last_sync'] ?? 0);
        $out[] = [
            'id' => (int)($row->id ?? $row['id'] ?? 0),
            'gmail_account' => (string)($row->gmail_account ?? $row['gmail_account'] ?? ''),
            'api_key' => (string)($row->api_key ?? $row['api_key'] ?? ''),
            'status' => (string)($row->status ?? $row['status'] ?? 'active'),
            'last_used' => $lastused > 0 ? userdate($lastused, '%Y-%m-%dT%H:%M') : '',
            'request_count_minute' => (int)($row->request_count_minute ?? $row['request_count_minute'] ?? 0),
            'total_requests_day' => (int)($row->total_requests_day ?? $row['total_requests_day'] ?? 0),
            'proxy_info' => (string)($row->proxy_info ?? $row['proxy_info'] ?? ''),
            'category_key' => (string)($row->category_key ?? $row['category_key'] ?? 'free'),
            'provider' => (string)($row->provider ?? $row['provider'] ?? 'google'),
            'model_scan' => (string)($row->model_scan ?? $row['model_scan'] ?? ''),
            'model_homework' => (string)($row->model_homework ?? $row['model_homework'] ?? ''),
            'model_scan_status' => (string)($row->model_scan_status ?? $row['model_scan_status'] ?? ''),
            'model_homework_status' => (string)($row->model_homework_status ?? $row['model_homework_status'] ?? ''),
            'usage_remaining' => (string)($row->usage_remaining ?? $row['usage_remaining'] ?? '0'),
            'daily_limit' => (int)($row->daily_limit ?? $row['daily_limit'] ?? 0),
            'daily_used' => (int)($row->daily_used ?? $row['daily_used'] ?? 0),
            'last_model' => (string)($row->last_model ?? $row['last_model'] ?? ''),
            'last_tokens' => (int)($row->last_tokens ?? $row['last_tokens'] ?? 0),
            'usage_last_sync' => $usagesync > 0 ? userdate($usagesync, '%Y-%m-%d %H:%M') : '',
            'last_error' => (string)($row->last_error ?? $row['last_error'] ?? ''),
        ];
    }
    return $out;
}

try {
    if ($op === 'restore') {
        aikey_repository::sync_usage_remaining_for_pay_keys();
        echo json_encode(['ok' => true, 'rows' => local_aisgk_aikeys_json_rows(aikey_repository::get_all()), 'system_user_daily_limit' => (int)(get_config('local_aisgk', 'system_user_daily_limit') ?: 20)]);
        exit;
    }

    if ($op === 'save') {
        $rows = is_array($payload['rows'] ?? null) ? $payload['rows'] : [];
        if (isset($payload['system_user_daily_limit'])) {
            set_config('system_user_daily_limit', max(1, (int)$payload['system_user_daily_limit']), 'local_aisgk');
        }
        aikey_repository::save_rows($rows);
        aikey_repository::sync_usage_remaining_for_pay_keys();
        echo json_encode(['ok' => true, 'rows' => local_aisgk_aikeys_json_rows(aikey_repository::get_all()), 'system_user_daily_limit' => (int)(get_config('local_aisgk', 'system_user_daily_limit') ?: 20)]);
        exit;
    }

    throw new invalid_parameter_exception('Invalid op');
} catch (Throwable $e) {
    http_response_code(500);
    echo json_encode(['ok' => false, 'error' => $e->getMessage()]);
}
