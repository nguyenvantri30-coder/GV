<?php
require('../../config.php');

use local_aisgk\aikey_repository;

define('AJAX_SCRIPT', true);

$courseid = required_param('id', PARAM_INT);
$op = required_param('op', PARAM_ALPHA);
require_sesskey();

$course = get_course($courseid);
require_login($course);
if (!is_siteadmin()) {
    throw new required_capability_exception(context_system::instance(), 'moodle/site:config', 'nopermissions', '');
}

header('Content-Type: application/json; charset=utf-8');
$payload = json_decode(file_get_contents('php://input'), true) ?: [];

function local_aisgk_aikeys_json_rows(array $rows): array {
    $out = [];
    foreach ($rows as $row) {
        $lastused = (int)($row->last_used ?? $row['last_used'] ?? 0);
        $out[] = [
            'id' => (int)($row->id ?? $row['id'] ?? 0),
            'gmail_account' => (string)($row->gmail_account ?? $row['gmail_account'] ?? ''),
            'api_key' => (string)($row->api_key ?? $row['api_key'] ?? ''),
            'status' => (string)($row->status ?? $row['status'] ?? 'active'),
            'last_used' => $lastused > 0 ? userdate($lastused, '%Y-%m-%dT%H:%M') : '',
            'request_count_minute' => (int)($row->request_count_minute ?? $row['request_count_minute'] ?? 0),
            'total_requests_day' => (int)($row->total_requests_day ?? $row['total_requests_day'] ?? 0),
            'proxy_info' => (string)($row->proxy_info ?? $row['proxy_info'] ?? ''),
            'category_key' => (string)($row->category_key ?? $row['category_key'] ?? 'free'),
        ];
    }
    return $out;
}

try {
    if ($op === 'restore') {
        echo json_encode(['ok' => true, 'rows' => local_aisgk_aikeys_json_rows(aikey_repository::get_all())]);
        exit;
    }

    if ($op === 'save') {
        $rows = is_array($payload['rows'] ?? null) ? $payload['rows'] : [];
        $saved = aikey_repository::save_rows($rows);
        echo json_encode(['ok' => true, 'rows' => local_aisgk_aikeys_json_rows($saved)]);
        exit;
    }

    throw new invalid_parameter_exception('Invalid op');
} catch (Throwable $e) {
    http_response_code(500);
    echo json_encode(['ok' => false, 'error' => $e->getMessage()]);
}
