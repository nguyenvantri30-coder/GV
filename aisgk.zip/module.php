<?php
require_once(__DIR__ . '/../../config.php');
require_login();
$context = context_system::instance();
$PAGE->set_context($context);
$m = optional_param('m', 'daily', PARAM_ALPHANUMEXT);
$tab = optional_param('tab', '', PARAM_ALPHANUMEXT);
$PAGE->set_url(new moodle_url('/local/aisgk/module.php', ['m' => $m, 'tab' => $tab]));
$PAGE->set_title('ALSM');
$PAGE->set_heading('ALSM');
$PAGE->set_pagelayout('standard');
$PAGE->requires->css(new moodle_url('/local/aisgk/styles.css'));
$names = [
    'daily' => 'Giám sát & đôn đốc hằng ngày',
    'adaptive' => 'Phân loại & phát triển năng lực',
    'competition' => 'Thi đua & khen thưởng',
    'parent' => 'Báo cáo phụ huynh',
];
echo $OUTPUT->header();
echo html_writer::start_div('alsm-placeholder');
echo html_writer::tag('h2', s($names[$m] ?? 'ALSM'));
echo html_writer::tag('p', 'Trang chức năng đang được chuẩn bị. Tham số: ' . s($m) . ($tab ? ' / ' . s($tab) : ''));
echo html_writer::link(new moodle_url('/local/aisgk/index.php'), 'Quay lại ALSM', ['class' => 'btn btn-primary']);
echo html_writer::end_div();
echo $OUTPUT->footer();
