<?php
require_once(__DIR__ . '/../../config.php');
require_once($CFG->libdir . '/adminlib.php');
require_once($CFG->libdir . '/filelib.php');

use local_aisgk\local\service\school_year_backup_service;

require_login();
require_capability('moodle/site:config', context_system::instance());

$action = optional_param('action', '', PARAM_ALPHAEXT);
$note = optional_param('note', '', PARAM_TEXT);
$backupid = optional_param('backupid', 0, PARAM_INT);
$message = '';
$error = '';

if ($action === 'download' && $backupid > 0 && confirm_sesskey()) {
    $path = school_year_backup_service::get_download_path($backupid);
    send_file($path, basename($path), 0, 0, true, true);
    exit;
}

if ($action === 'backup' && confirm_sesskey()) {
    try {
        $backup = school_year_backup_service::create_current_year_backup($note);
        $message = get_string('backupdone', 'local_aisgk') . ' #' . (int)$backup->id;
        $backupid = (int)$backup->id;
    } catch (Throwable $e) {
        $error = $e->getMessage();
    }
}

$PAGE->set_url(new moodle_url('/local/aisgk/year_backup.php'));
$PAGE->set_title(get_string('yearbackup', 'local_aisgk'));
$PAGE->set_heading(get_string('alsm', 'local_aisgk'));
$PAGE->set_pagelayout('standard');

$year = school_year_backup_service::get_or_create_current_school_year();
$backups = $DB->get_records('local_aisgk_backup', null, 'timecreated DESC', '*', 0, 20);

echo $OUTPUT->header();

echo html_writer::tag('h2', get_string('yearbackup', 'local_aisgk'));
echo html_writer::start_div('local-aisgk-yearbackup');
if ($message) {
    echo $OUTPUT->notification($message, 'notifysuccess');
}
if ($error) {
    echo $OUTPUT->notification($error, 'notifyproblem');
}

echo html_writer::tag('p', get_string('yearbackupintro', 'local_aisgk'));

echo html_writer::start_tag('div', ['class' => 'card mb-3 border-warning']);
echo html_writer::start_tag('div', ['class' => 'card-body']);
echo html_writer::tag('h3', get_string('currentschoolyear', 'local_aisgk') . ': ' . s($year->name));
echo html_writer::tag('p', get_string('yearbackupscope', 'local_aisgk'));
echo html_writer::tag('div', get_string('yearbackupwarning', 'local_aisgk'), ['class' => 'alert alert-warning']);
echo html_writer::start_tag('form', ['method' => 'post', 'action' => $PAGE->url->out(false)]);
echo html_writer::empty_tag('input', ['type' => 'hidden', 'name' => 'sesskey', 'value' => sesskey()]);
echo html_writer::empty_tag('input', ['type' => 'hidden', 'name' => 'action', 'value' => 'backup']);
echo html_writer::tag('label', get_string('backupnote', 'local_aisgk'), ['for' => 'id_note']);
echo html_writer::empty_tag('input', ['type' => 'text', 'class' => 'form-control mb-2', 'id' => 'id_note', 'name' => 'note', 'maxlength' => 255]);
echo html_writer::tag('button', get_string('startyearbackup', 'local_aisgk'), ['type' => 'submit', 'class' => 'btn btn-primary']);
echo html_writer::end_tag('form');
echo html_writer::end_tag('div');
echo html_writer::end_tag('div');

echo html_writer::start_tag('div', ['class' => 'card mb-3 border-info']);
echo html_writer::start_tag('div', ['class' => 'card-body']);
echo html_writer::tag('h3', get_string('nextstepafterbackup', 'local_aisgk'));
echo html_writer::tag('p', get_string('nextstepafterbackupdesc', 'local_aisgk'));
echo html_writer::link(new moodle_url('/local/aisgk/year_new.php'), get_string('newschoolyear', 'local_aisgk'), ['class' => 'btn btn-info']);
echo html_writer::end_tag('div');
echo html_writer::end_tag('div');

echo html_writer::tag('h3', get_string('recentbackups', 'local_aisgk'));
if (!$backups) {
    echo html_writer::tag('p', get_string('nobackups', 'local_aisgk'));
} else {
    $table = new html_table();
    $table->head = [
        get_string('timecreated', 'local_aisgk'),
        get_string('schoolyear', 'local_aisgk'),
        get_string('backuptype', 'local_aisgk'),
        get_string('status'),
        get_string('filesize', 'local_aisgk'),
        get_string('checksum', 'local_aisgk'),
        get_string('download', 'local_aisgk'),
    ];
    foreach ($backups as $b) {
        $sy = $DB->get_record('local_aisgk_school_year', ['id' => $b->schoolyearid]);
        $download = '-';
        if ($b->status === 'done' && !empty($b->filepath)) {
            $downloadurl = new moodle_url('/local/aisgk/year_backup.php', [
                'action' => 'download',
                'backupid' => (int)$b->id,
                'sesskey' => sesskey(),
            ]);
            $download = html_writer::link($downloadurl, get_string('downloadzip', 'local_aisgk'), ['class' => 'btn btn-sm btn-secondary']);
        }
        $table->data[] = [
            userdate($b->timecreated),
            $sy ? s($sy->name) : '-',
            s($b->backuptype),
            s($b->status),
            display_size((int)$b->filesize),
            html_writer::tag('code', s(substr((string)$b->checksum, 0, 12))),
            $download,
        ];
    }
    echo html_writer::table($table);
}

echo html_writer::end_div();
echo html_writer::tag('p', html_writer::link(new moodle_url('/local/aisgk/index.php'), get_string('alsm_quay_lai_alsm_toan_truong', 'local_aisgk'), ['class' => 'btn btn-secondary mt-3']));
echo $OUTPUT->footer();
