<?php
require_once(__DIR__ . '/../../config.php');

$localaisgkmodal = optional_param('modal', 0, PARAM_BOOL);
function local_aisgk_modal_page_open($title = '') {
    global $OUTPUT, $localaisgkmodal;
    if ($localaisgkmodal) {
        echo '<!doctype html><html><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>' . s($title) . '</title><style>html,body{margin:0!important;padding:0!important;background:#fff!important;overflow:hidden;font-family:Arial,Helvetica,sans-serif}.modal-clean-wrap{padding:10px;box-sizing:border-box;width:100%;height:100vh;overflow:auto}.btn,.local-aisgk-modal .btn,button,input[type=submit]{display:inline-flex!important;align-items:center!important;justify-content:center!important;height:34px!important;line-height:1!important;padding:0 12px!important;box-sizing:border-box!important;vertical-align:middle!important}table{border-collapse:collapse}.muted{color:#64748b}.table-responsive{overflow:auto}</style></head><body><div class="modal-clean-wrap">';
    } else {
        local_aisgk_modal_page_open($PAGE->title ?? '');
    }
}
function local_aisgk_modal_page_close() {
    global $OUTPUT, $localaisgkmodal;
    if ($localaisgkmodal) {
        echo '</div></body></html>';
    } else {
        local_aisgk_modal_page_close();
    }
}


$context = context_system::instance();
$PAGE->set_context($context);
require_login();
require_capability('moodle/site:config', $context);

require_once($CFG->libdir . '/adminlib.php');
require_once($CFG->libdir . '/filelib.php');

use local_aisgk\local\service\school_year_backup_service;

$action = optional_param('action', '', PARAM_ALPHAEXT);
$note = optional_param('note', '', PARAM_TEXT);
$backupid = optional_param('backupid', 0, PARAM_INT);
$message = '';
$error = '';

if ($action === 'download' && $backupid > 0 && confirm_sesskey()) {
    $path = school_year_backup_service::get_download_path($backupid);
    send_file($path, basename($path), 0, 0, false, true);
    exit;
}

if ($action === 'delete' && $backupid > 0 && confirm_sesskey()) {
    school_year_backup_service::delete_backup($backupid);
    redirect(new moodle_url('/local/aisgk/year_backup.php'), 'Đã xóa gói backup và các file tạm liên quan.', 2);
}

if ($action === 'progress' && confirm_sesskey()) {
    header('Content-Type: application/json; charset=utf-8');
    echo json_encode(school_year_backup_service::get_latest_backup_progress((int)$USER->id), JSON_UNESCAPED_UNICODE);
    exit;
}

if ($action === 'cancelrunning' && confirm_sesskey()) {
    $cancelled = school_year_backup_service::cancel_running_backups_for_user((int)$USER->id);
    redirect(new moodle_url('/local/aisgk/year_backup.php'), 'Đã đánh dấu hủy ' . $cancelled . ' tiến trình backup đang chạy/kẹt.', 2);
}

if ($action === 'backup' && confirm_sesskey()) {
    try {
        // Release Moodle session lock before the long archive job, otherwise
        // the progress polling request waits behind this backup request.
        if (class_exists('\core\session\manager')) {
            \core\session\manager::write_close();
        } else if (function_exists('session_write_close')) {
            session_write_close();
        }
        $backup = school_year_backup_service::create_current_year_backup($note);
        // Do not auto-stream here. This request runs inside a hidden iframe so
        // the main page can keep polling progress. The admin downloads only
        // after the archive is finalized and the progress API reports status=done.
        header('Content-Type: text/html; charset=utf-8');
        echo '<!doctype html><html><body>Backup completed. ID: ' . (int)$backup->id . '</body></html>';
        exit;
    } catch (Throwable $e) {
        header('Content-Type: text/html; charset=utf-8');
        echo '<!doctype html><html><body>Backup failed: ' . s($e->getMessage()) . '</body></html>';
        exit;
    }
}

$PAGE->set_url(new moodle_url('/local/aisgk/year_backup.php'));
$PAGE->set_title(get_string('yearbackup', 'local_aisgk'));
$PAGE->set_heading(get_string('yearbackup', 'local_aisgk'));
$PAGE->set_pagelayout('standard');

$year = school_year_backup_service::get_or_create_current_school_year();
$backups = $DB->get_records('local_aisgk_backup', null, 'timecreated DESC', '*', 0, 20);
$runningbackup = school_year_backup_service::get_active_running_backup((int)$USER->id);

local_aisgk_modal_page_open($PAGE->title ?? '');

echo html_writer::start_div('local-aisgk-yearbackup');
if ($message) {
    echo $OUTPUT->notification($message, 'notifysuccess');
}
if ($error) {
    echo $OUTPUT->notification($error, 'notifyproblem');
}

echo html_writer::start_tag('div', ['class' => 'card mb-3']);
echo html_writer::start_tag('div', ['class' => 'card-body py-3']);
echo html_writer::tag('h3', get_string('currentschoolyear', 'local_aisgk') . ': ' . s($year->name), ['class' => 'h5 mb-2']);
if ($runningbackup) {
    $cancelurl = new moodle_url('/local/aisgk/year_backup.php', ['action' => 'cancelrunning', 'sesskey' => sesskey()]);
    echo html_writer::start_div('alert alert-danger');
    echo html_writer::tag('strong', 'Đang có một tiến trình backup chạy hoặc bị kẹt.');
    echo html_writer::tag('div', 'Thời gian chạy: ' . format_time(time() - (int)$runningbackup->timecreated) . '. Không nên chạy backup mới cho tới khi tiến trình này xong hoặc được hủy trạng thái.');
    echo html_writer::link($cancelurl, 'Đánh dấu hủy tiến trình kẹt', ['class' => 'btn btn-sm btn-danger mt-2']);
    echo html_writer::end_div();
}
echo html_writer::start_tag('form', ['method' => 'post', 'action' => $PAGE->url->out(false), 'target' => 'alsm_backup_download_frame', 'id' => 'alsm-year-backup-form']);
echo html_writer::empty_tag('input', ['type' => 'hidden', 'name' => 'sesskey', 'value' => sesskey()]);
echo html_writer::empty_tag('input', ['type' => 'hidden', 'name' => 'action', 'value' => 'backup']);
echo html_writer::tag('button', get_string('startyearbackup', 'local_aisgk'), ['type' => 'submit', 'class' => 'btn btn-primary', 'id' => 'alsm-year-backup-submit', 'disabled' => $runningbackup ? 'disabled' : null]);
echo html_writer::end_tag('form');
echo html_writer::tag('iframe', '', ['name' => 'alsm_backup_download_frame', 'id' => 'alsm_backup_download_frame', 'style' => 'display:none;width:0;height:0;border:0;']);
echo html_writer::start_div('alert alert-info mt-2 py-2', ['id' => 'alsm-backup-progress', 'style' => 'display:none;']);
echo html_writer::tag('strong', get_string('backupinprogress', 'local_aisgk'));
echo html_writer::tag('div', '', ['id' => 'alsm-backup-progress-line', 'class' => 'mt-2']);
echo html_writer::tag('div', '', ['id' => 'alsm-backup-progress-last', 'class' => 'small text-muted mt-1']);
echo html_writer::end_div();
echo html_writer::end_tag('div');
echo html_writer::end_tag('div');

echo html_writer::tag('h3', get_string('recentbackups', 'local_aisgk'));
if (!$backups) {
    echo html_writer::tag('p', get_string('nobackups', 'local_aisgk'));
} else {
    $table = new html_table();
    $table->head = [
        get_string('timecreated', 'local_aisgk'),
        get_string('schoolyear', 'local_aisgk'),
        get_string('filesize', 'local_aisgk'),
        get_string('status'),
        get_string('download', 'local_aisgk'),
        'Xóa',
    ];
    foreach ($backups as $b) {
        $sy = $DB->get_record('local_aisgk_school_year', ['id' => $b->schoolyearid]);
        $download = '-';
        if ($b->status === 'done' && !empty($b->filepath) && (int)$b->filesize > 1024) {
            $downloadurl = new moodle_url('/local/aisgk/year_backup.php', [
                'action' => 'download',
                'backupid' => (int)$b->id,
                'sesskey' => sesskey(),
            ]);
            $download = html_writer::link($downloadurl, get_string('downloadzip', 'local_aisgk'), ['class' => 'btn btn-sm btn-secondary']);
        }
        $delete = '-';
        if ($b->status !== 'running') {
            $deleteurl = new moodle_url('/local/aisgk/year_backup.php', [
                'action' => 'delete',
                'backupid' => (int)$b->id,
                'sesskey' => sesskey(),
            ]);
            $delete = html_writer::link($deleteurl, 'Xóa', [
                'class' => 'btn btn-sm btn-danger',
                'onclick' => "return confirm('Xóa gói backup này khỏi server? Hãy chắc chắn đã tải về máy trước.');",
            ]);
        }
        $table->data[] = [
            userdate($b->timecreated),
            $sy ? s($sy->name) : '-',
            display_size((int)$b->filesize),
            s($b->status),
            $download,
            $delete,
        ];
    }
    echo html_writer::table($table);
}

$hasdonebackup = $DB->record_exists('local_aisgk_backup', ['status' => 'done']);
echo html_writer::start_tag('div', ['class' => 'card mb-3 border-info', 'id' => 'alsm-next-step-card', 'style' => $hasdonebackup ? '' : 'display:none;']);
echo html_writer::start_tag('div', ['class' => 'card-body py-3']);
echo html_writer::tag('h3', get_string('nextstepafterbackup', 'local_aisgk'), ['class' => 'h5 mb-2']);
echo html_writer::link(new moodle_url('/local/aisgk/year_new.php'), get_string('newschoolyear', 'local_aisgk'), ['class' => 'btn btn-info']);
echo html_writer::end_tag('div');
echo html_writer::end_tag('div');

echo html_writer::end_div();
echo html_writer::tag('p', html_writer::link(new moodle_url('/local/aisgk/index.php'), get_string('back'), ['class' => 'btn btn-secondary mt-3']));

$progressurl = new moodle_url('/local/aisgk/year_backup.php', ['action' => 'progress', 'sesskey' => sesskey()]);
$downloadbase = new moodle_url('/local/aisgk/year_backup.php', ['action' => 'download', 'sesskey' => sesskey()]);
echo html_writer::script("(function(){\n" .
"var form=document.getElementById('alsm-year-backup-form');\n" .
"var box=document.getElementById('alsm-backup-progress');\n" .
"var line=document.getElementById('alsm-backup-progress-line');\n" .
"var last=document.getElementById('alsm-backup-progress-last');\n" .
"var btn=document.getElementById('alsm-year-backup-submit');\n" .
"var nextcard=document.getElementById('alsm-next-step-card');\n" .
"if(!form||!box){return;}\n" .
"var timer=null,start=0;\n" .
"function fmtBytes(n){n=parseInt(n||0,10); if(!n){return '0 B';} var u=['B','KB','MB','GB','TB']; var i=0; while(n>=1024&&i<u.length-1){n/=1024;i++;} return n.toFixed(i?1:0)+' '+u[i];}\n" .
"function poll(){fetch('" . $progressurl->out(false) . "',{credentials:'same-origin'}).then(function(r){return r.json();}).then(function(d){\n" .
"var elapsed=Math.max(1,Math.floor((Date.now()-start)/1000));\n" .
"if(!d||!d.hasbackup){line.textContent='Đang khởi tạo backup... '+elapsed+'s';return;}\n" .
"line.textContent='Đang chạy: '+elapsed+'s | '+(d.itemcount||0)+' mục | '+d.status;\n" .
"if(d.lastitem){last.textContent=(d.lastitem.itemtype||'')+' / '+(d.lastitem.itemkey||'')+' ('+(d.lastitem.recordcount||0)+')';}
if(d.isstale){last.textContent='Có thể bị kẹt. Tải lại trang để hủy nếu cần.';}\n" .
"if(d.status==='done'){clearInterval(timer); btn.disabled=false; if(nextcard){nextcard.style.display='block';} line.innerHTML='Backup hoàn tất. Kích thước: '+fmtBytes(d.filesize)+'. <a class=\"btn btn-sm btn-success ml-2\" href=\"" . $downloadbase->out(false) . "&backupid='+d.id+'\">Tải ZIP backup</a>'; last.textContent='Đang cập nhật danh sách...'; setTimeout(function(){window.location.reload();},3000);}\n" .
"if(d.status==='failed'){clearInterval(timer); btn.disabled=false; line.textContent='Backup lỗi. Xem bảng bên dưới hoặc log server.';}\n" .
"}).catch(function(){var elapsed=Math.max(1,Math.floor((Date.now()-start)/1000)); line.textContent='Đang backup... '+elapsed+'s';});}\n" .
"form.addEventListener('submit',function(){box.style.display='block'; btn.disabled=true; if(nextcard){nextcard.style.display='none';} start=Date.now(); line.textContent='Đang khởi tạo backup...'; last.textContent='Không đóng trang.'; timer=setInterval(poll,2000); setTimeout(poll,800);});\n" .
"})();");

local_aisgk_modal_page_close();
