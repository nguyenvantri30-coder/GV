<?php
require_once(__DIR__ . '/../../../config.php');
require_login();
$context = context_system::instance();
$PAGE->set_context($context);
$PAGE->set_url(new moodle_url('/local/aisgk/reports/index.php'));
$PAGE->set_title('Phân tích và báo cáo');
$PAGE->set_heading('Phân tích và báo cáo');
$PAGE->set_pagelayout('standard');
echo $OUTPUT->header();
echo html_writer::tag('h2', 'Phân tích và báo cáo');
echo html_writer::tag('p', 'Chức năng này là điểm vào cấp trường của ALSM. Bước tiếp theo sẽ nối form upload, validate và lưu DB.');
echo html_writer::link(new moodle_url('/local/aisgk/index.php'), '← Quay lại ALSM toàn trường', ['class' => 'btn btn-secondary']);
echo $OUTPUT->footer();
