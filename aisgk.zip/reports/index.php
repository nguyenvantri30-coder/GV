<?php
require_once(__DIR__ . '/../../../config.php');

$localaisgkmodal = optional_param('modal', 0, PARAM_BOOL);
function local_aisgk_modal_page_open($title = '') {
    global $OUTPUT, $localaisgkmodal;
    if ($localaisgkmodal) {
        echo '<!doctype html><html><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>' . s($title) . '</title><style>html,body{margin:0!important;padding:0!important;background:#fff!important;overflow:hidden;font-family:Arial,Helvetica,sans-serif}.modal-clean-wrap{padding:10px;box-sizing:border-box;width:100%;height:100vh;overflow:auto}.btn,button,input[type=submit]{display:inline-flex!important;align-items:center!important;justify-content:center!important;height:34px!important;line-height:1!important;padding:0 12px!important;box-sizing:border-box!important;vertical-align:middle!important}.table-responsive{overflow:auto}.muted{color:#64748b}</style></head><body><div class="modal-clean-wrap">';
    } else {
        echo $OUTPUT->header();
    }
}
function local_aisgk_modal_page_close() {
    global $OUTPUT, $localaisgkmodal;
    if ($localaisgkmodal) {
        echo '</div></body></html>';
    } else {
        echo $OUTPUT->footer();
    }
}

require_login();
$context = context_system::instance();
$tab = optional_param('tab', 'overview', PARAM_ALPHANUMEXT);
$PAGE->set_context($context);
$PAGE->set_url(new moodle_url('/local/aisgk/reports/index.php', ['tab' => $tab]));
$PAGE->set_title(get_string('alsm_phan_tich_bao_cao', 'local_aisgk'));
$PAGE->set_heading(get_string('alsm_phan_tich_bao_cao', 'local_aisgk'));
$PAGE->set_pagelayout('standard');

$labels = [
    'schedule' => get_string('alsm_check_teaching_progress', 'local_aisgk'),
    'schedule_alerts' => get_string('alsm_schedule_alerts', 'local_aisgk'),
    'homework' => get_string('alsm_track_homework', 'local_aisgk'),
    'alerts' => get_string('alsm_student_alerts', 'local_aisgk'),
    'competency' => get_string('alsm_competency_analysis', 'local_aisgk'),
    'remediation' => get_string('alsm_remediation_suggestions', 'local_aisgk'),
    'competition' => get_string('alsm_leaderboard', 'local_aisgk'),
    'rewardfund' => get_string('alsm_reward_fund', 'local_aisgk'),
    'sponsors' => get_string('alsm_sponsors', 'local_aisgk'),
    'fund_public' => get_string('alsm_public_income_expense', 'local_aisgk'),
    'parents' => get_string('alsm_parent_reports', 'local_aisgk'),
    'export' => get_string('alsm_export_statistics', 'local_aisgk'),
    'logs' => get_string('alsm_system_logs', 'local_aisgk'),
    'overview' => get_string('alsm_phan_tich_bao_cao', 'local_aisgk'),
];
$title = $labels[$tab] ?? $labels['overview'];
$introkey = ($tab === 'rewardfund' || $tab === 'sponsors' || $tab === 'fund_public' || $tab === 'competition') ? 'alsm_page_intro_rewardfund' : 'alsm_page_intro_default';
$intro = get_string($introkey, 'local_aisgk');

local_aisgk_modal_page_open($PAGE->title ?? '');
echo html_writer::start_div('local-aisgk-placeholder', ['style' => 'max-width:980px;margin:0 auto;padding:18px']);
echo html_writer::tag('h2', s($title));
echo html_writer::tag('p', s($intro), ['style' => 'font-size:1rem;line-height:1.55;background:#f7fbff;border:1px solid #dbeafe;border-radius:14px;padding:14px 16px']);
echo html_writer::tag('p', get_string('alsm_chuc_nang_diem_truong_alsm_buoc', 'local_aisgk'));
echo html_writer::link(new moodle_url('/local/aisgk/index.php'), get_string('alsm_quay_lai_alsm_toan_truong', 'local_aisgk'), ['class' => 'btn btn-secondary']);
echo html_writer::end_div();
local_aisgk_modal_page_close();
