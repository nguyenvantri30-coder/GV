<?php

defined('MOODLE_INTERNAL') || die();

$plugin->component = 'local_aisgk';
$plugin->version   = 2026050109;
$plugin->requires  = 2022112800;
$plugin->maturity  = MATURITY_ALPHA;
$plugin->release   = '0.2.52';
