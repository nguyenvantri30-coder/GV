<?php
require('../../config.php');
require_once($CFG->dirroot . '/question/engine/bank.php');

use local_aisgk\book_repository;
use local_aisgk\local\service\homework_service;

$courseid = required_param('id', PARAM_INT);
$sectionid = optional_param('sectionid', 0, PARAM_INT);
$topicname = optional_param('topicname', '', PARAM_TEXT);

$course = get_course($courseid);
require_login($course);

$context = context_course::instance($courseid);
require_capability('local/aisgk:createhomework', $context);

$PAGE->set_context($context);
$PAGE->set_url('/local/aisgk/homework.php', ['id' => $courseid, 'sectionid' => $sectionid, 'topicname' => $topicname]);
$PAGE->set_pagelayout('embedded');
$PAGE->set_title('Tạo bài tập về nhà' . ($topicname !== '' ? ': ' . $topicname : ''));

if (!book_repository::course_has_book($courseid)) {
    throw new moodle_exception('bookrequired', 'local_aisgk');
}

$section = null;
if ($sectionid) {
    $modinfo = get_fast_modinfo($course);
    $section = $modinfo->get_section_info_by_id($sectionid);
}
$sectionlabel = $section && !empty($section->name) ? format_string($section->name) : '';
$prefill = $sectionid ? homework_service::find_section_match($courseid, $sectionid) : null;
if (!$prefill && $topicname !== '') {
    $prefill = homework_service::find_topic_match($courseid, $topicname);
}
$bookid = $prefill ? (int)$prefill['book']->id : (int)(book_repository::get_by_courseid($courseid)->id ?? 0);
$bookname = $prefill ? (string)($prefill['book']->name ?: $prefill['book']->filename) : '';
$pagefrom = $prefill ? (int)($prefill['toc']->trang ?? 1) : 1;
$pageto = $prefill ? (int)($prefill['toc']->endtrang ?? $pagefrom) : max(1, $pagefrom);
$scheduled = userdate(time() > strtotime(date('Y-m-d 17:00:00')) ? strtotime('tomorrow 17:00') : strtotime('today 17:00'), '%Y-%m-%dT%H:%M');
$usemyapi = (bool)get_user_preferences('local_aisgk_use_my_api', 0, $USER->id);

$qtypevilabels = [
    'multichoice' => 'Trắc nghiệm nhiều lựa chọn',
    'truefalse' => 'Đúng/Sai',
    'shortanswer' => 'Trả lời ngắn',
    'numerical' => 'Dạng số',
    'matching' => 'Ghép đôi',
    'essay' => 'Tự luận',
    'gapselect' => 'Chọn từ điền khuyết',
    'ddwtos' => 'Kéo thả vào văn bản',
    'calculated' => 'Tính toán',
    'calculatedsimple' => 'Tính toán đơn giản',
    'calculatedmulti' => 'Trắc nghiệm tính toán',
    'ddimageortext' => 'Kéo thả lên ảnh',
    'ddmarker' => 'Đánh dấu vùng trên ảnh',
    'random' => 'Câu hỏi ngẫu nhiên',
    'description' => 'Mô tả/nội dung',
];
$qtypemenufallback = $qtypevilabels;
$qtypehelp = [
    'multichoice' => 'Câu hỏi có nhiều phương án, học sinh chọn một hoặc nhiều đáp án đúng. Phù hợp để tạo nhanh từ SGK.',
    'truefalse' => 'Câu hỏi Đúng/Sai. Dễ tạo, phù hợp kiểm tra nhận biết khái niệm, sự kiện, quy tắc.',
    'shortanswer' => 'Học sinh nhập một cụm từ hoặc câu trả lời ngắn. Dùng cho định nghĩa, thuật ngữ, kết quả ngắn.',
    'numerical' => 'Học sinh nhập đáp án dạng số, có thể có sai số. Phù hợp bài tính toán đơn giản.',
    'matching' => 'Ghép mỗi mục ở cột này với một mục tương ứng ở cột kia. Phù hợp thuật ngữ - ý nghĩa, thiết bị - chức năng.',
    'essay' => 'Câu tự luận, giáo viên thường cần chấm thủ công. Phù hợp câu vận dụng, giải thích, trình bày.',
    'gapselect' => 'Điền khuyết bằng cách chọn đáp án từ danh sách có sẵn. Phù hợp hoàn thiện câu/đoạn văn.',
    'ddwtos' => 'Kéo các từ/cụm từ vào chỗ trống trong văn bản. Dễ dùng với câu điền khuyết có nhiều vị trí.',
    'calculated' => 'Câu hỏi tính toán có biến và công thức. Khó tạo tự động, cần kiểm tra kỹ trước khi dùng thật.',
    'calculatedsimple' => 'Dạng tính toán đơn giản hơn calculated. Vẫn cần kiểm tra công thức và khoảng giá trị.',
    'calculatedmulti' => 'Trắc nghiệm có dữ liệu tính toán sinh tự động. Khó tạo và khó chuyển chính xác từ AI.',
    'ddimageortext' => 'Kéo chữ hoặc ảnh vào vị trí trên ảnh nền. Cần ảnh và tọa độ, hiện chưa nên ưu tiên AI tạo tự động.',
    'ddmarker' => 'Học sinh kéo marker vào vùng đúng trên ảnh. Cần tọa độ vùng đáp án, khó tạo tự động.',
    'random' => 'Lấy ngẫu nhiên câu hỏi đã có trong ngân hàng đề. Không phải dạng câu hỏi AI sinh nội dung mới.',
    'description' => 'Khối nội dung/mô tả trong quiz, không phải câu hỏi có điểm. Dùng để đưa đoạn thông tin hoặc hướng dẫn.',
];

try {
    $availableqtypes = class_exists('question_bank') ? question_bank::get_qtype_menu() : $qtypemenufallback;
} catch (Throwable $e) {
    $availableqtypes = $qtypemenufallback;
}

$qtypegroups = [
    'easy' => [
        'title' => 'Dễ tạo',
        'types' => ['multichoice', 'truefalse', 'shortanswer', 'numerical', 'matching'],
    ],
    'medium' => [
        'title' => 'Trung bình',
        'types' => ['essay', 'gapselect', 'ddwtos', 'calculated', 'calculatedsimple'],
    ],
    'hard' => [
        'title' => 'Khó tạo',
        'types' => ['calculatedmulti', 'ddimageortext', 'ddmarker', 'random', 'description'],
    ],
];

$questiontypesbygroup = [];
foreach ($qtypegroups as $groupkey => $group) {
    $questiontypesbygroup[$groupkey] = ['title' => $group['title'], 'types' => []];
    foreach ($group['types'] as $type) {
        if (array_key_exists($type, $availableqtypes)) {
            $questiontypesbygroup[$groupkey]['types'][$type] = $qtypevilabels[$type] ?? $availableqtypes[$type];
        } else if (array_key_exists($type, $qtypemenufallback)) {
            $questiontypesbygroup[$groupkey]['types'][$type] = $qtypevilabels[$type] ?? $qtypemenufallback[$type];
        }
    }
}

foreach ($availableqtypes as $type => $label) {
    $alreadyshown = false;
    foreach ($questiontypesbygroup as $group) {
        if (array_key_exists($type, $group['types'])) {
            $alreadyshown = true;
            break;
        }
    }
    if (!$alreadyshown) {
        $questiontypesbygroup['hard']['types'][$type] = $qtypevilabels[$type] ?? $label;
    }
}

function local_aisgk_count_options(int $max = 30, int $selected = 0): string {
    $html = '';
    for ($i = 0; $i <= $max; $i++) {
        $html .= '<option value="' . $i . '"' . ($i === $selected ? ' selected' : '') . '>' . $i . '</option>';
    }
    return $html;
}

echo $OUTPUT->header();
?>
<style>
html,body{overflow:hidden}
.local-aisgk-homework-wrap{padding:8px;font-size:12.5px;width:100%;max-width:100%;height:100vh;box-sizing:border-box;background:#fff;overflow:hidden}
.local-aisgk-card{height:calc(100vh - 16px);display:flex;flex-direction:column;border:1px solid #d7deea;border-radius:10px;background:#fff;padding:10px;box-sizing:border-box;overflow:hidden}
.local-aisgk-card h3{margin:0 0 8px;font-size:18px;font-weight:700;line-height:1.2}
.local-aisgk-grid{display:grid;grid-template-columns:1.05fr .95fr;gap:8px;margin-top:8px}
.local-aisgk-box{border:1px solid #e5e7eb;border-radius:8px;padding:8px;background:#f8fafc;min-width:0}
.local-aisgk-box.long{grid-column:1 / -1}
.local-aisgk-box strong{display:block;margin-bottom:6px;font-size:13px}
.local-aisgk-info{display:grid;grid-template-columns:90px 1fr;gap:3px 8px;color:#334155}
.local-aisgk-muted{color:#64748b}
.local-aisgk-form input,.local-aisgk-form select,.local-aisgk-form textarea{width:100%;box-sizing:border-box;border:1px solid #cbd5e1;border-radius:7px;padding:5px 7px;background:#fff;font-size:12.5px}
.local-aisgk-row{display:grid;grid-template-columns:1fr 70px 46px;gap:6px;align-items:center;margin:4px 0}
.local-aisgk-row label{font-weight:600;margin:0;white-space:nowrap;overflow:hidden;text-overflow:ellipsis}
.local-aisgk-percent{text-align:right;color:#475467;font-weight:600}
.local-aisgk-actions{display:flex;gap:8px;flex-wrap:wrap;margin-top:8px;align-items:center;justify-content:flex-start}
.local-aisgk-actions .btn{padding:5px 12px;font-size:13px;line-height:1.25}
.local-aisgk-actions-right{display:flex;gap:8px;flex-wrap:wrap}
.local-aisgk-progress{margin:8px 0}.local-aisgk-bar{height:10px;background:#e5e7eb;border-radius:999px;overflow:hidden}.local-aisgk-fill{height:100%;width:0;background:#2563eb;transition:width .25s ease}
.local-aisgk-msg{margin-top:5px;color:#334155}.local-aisgk-note{margin-top:6px;color:#475467}
.local-aisgk-hidden{display:none!important}.local-aisgk-editor{min-height:170px;border:1px solid #cbd5e1;border-radius:8px;background:#fff;padding:8px;overflow:auto;line-height:1.45}.local-aisgk-form textarea{min-height:130px;resize:vertical}
.local-aisgk-totalwarn{color:#b91c1c;font-weight:600;margin-top:6px}.local-aisgk-ok{color:#166534;font-weight:600;margin-top:6px}
.local-aisgk-compact-body{flex:1;min-height:0;overflow:auto;padding-right:2px}
.local-aisgk-cognitive-row{display:grid;grid-template-columns:repeat(4,minmax(0,1fr));gap:8px}
.local-aisgk-cognitive-item{display:grid;grid-template-columns:1fr 64px 42px;gap:5px;align-items:center;border:1px solid #e5e7eb;border-radius:7px;background:#fff;padding:6px}
.local-aisgk-cognitive-item label{font-weight:600;margin:0;white-space:nowrap}
.local-aisgk-cognitive-item input,.local-aisgk-cognitive-item select{padding:4px 5px}
.local-aisgk-qtype-grid{display:grid;grid-template-columns:repeat(3,minmax(0,1fr));gap:8px}
.local-aisgk-qtype-col{border:1px solid #e2e8f0;border-radius:8px;background:#fff;padding:7px;min-width:0}
.local-aisgk-qtype-col h4{margin:0 0 6px;font-size:13px;font-weight:700;color:#0f172a}
.local-aisgk-qtype-col .local-aisgk-row{margin:0 0 4px;grid-template-columns:minmax(80px,1fr) 22px 56px 40px}
.local-aisgk-helpbtn{width:19px;height:19px;border-radius:50%;border:1px solid #94a3b8;background:#fff;color:#334155;font-weight:700;font-size:12px;line-height:16px;padding:0;cursor:pointer}
.local-aisgk-helpbtn:hover{background:#e0f2fe;border-color:#0284c7}
.local-aisgk-helpbox{position:fixed;z-index:9999;left:50%;top:50%;transform:translate(-50%,-50%);width:min(420px,92vw);background:#fff;border:1px solid #94a3b8;border-radius:10px;box-shadow:0 16px 40px rgba(15,23,42,.25);padding:12px}
.local-aisgk-helpbox h4{margin:0 0 8px;font-size:15px}.local-aisgk-helpbox p{margin:0 0 10px;line-height:1.45}.local-aisgk-helpbox .btn{float:right}
.local-aisgk-output-grid{display:grid;grid-template-columns:1fr 1fr;gap:8px;margin-top:8px}
.local-aisgk-output-grid .local-aisgk-box{display:flex;flex-direction:column;min-height:220px}
.local-aisgk-output-grid textarea,.local-aisgk-output-grid .local-aisgk-editor{flex:1;min-height:0}
@media (max-width:992px){html,body{overflow:auto}.local-aisgk-homework-wrap{height:auto;overflow:visible}.local-aisgk-card{height:auto;overflow:visible}.local-aisgk-compact-body{overflow:visible}.local-aisgk-grid,.local-aisgk-output-grid{grid-template-columns:1fr}.local-aisgk-box.long{grid-column:auto}.local-aisgk-info{grid-template-columns:1fr}.local-aisgk-cognitive-row,.local-aisgk-qtype-grid{grid-template-columns:1fr}.local-aisgk-card h3{font-size:17px}}
</style>
<div class="local-aisgk-homework-wrap">
    <div class="local-aisgk-card local-aisgk-form">
        <h3>Tạo bài tập về nhà</h3>

        <div class="local-aisgk-compact-body">
            <div class="local-aisgk-grid">
                <div class="local-aisgk-box" id="box-source">
                    <strong>SGK / Trang</strong>
                    <div class="local-aisgk-info">
                        <div>Chủ đề</div><div><?php echo $sectionlabel !== '' ? $sectionlabel : '-'; ?> <?php echo ($topicname !== '' && trim($topicname) !== trim($sectionlabel)) ? ' · ' . s($topicname) : ''; ?></div>
                        <div>SGK</div><div><?php echo s($bookname !== '' ? $bookname : ('Book #' . $bookid)); ?></div>
                        <div>Trang</div><div><?php echo (int)$pagefrom; ?> → <?php echo (int)$pageto; ?></div>
                    </div>
                    <div class="local-aisgk-muted" style="margin-top:6px"><?php echo $prefill ? s((string)$prefill['toc']->tenbai) : 'Chưa tìm thấy liên kết chủ đề với mục lục.'; ?></div>
                </div>

                <div class="local-aisgk-box">
                    <strong>Lịch giao bài</strong>
                    <label for="scheduledtime">Thời điểm giao bài</label>
                    <input id="scheduledtime" type="datetime-local" value="<?php echo s($scheduled); ?>">
                    <div class="local-aisgk-muted" style="margin-top:6px">Có thể tạo bản nháp, chỉnh sửa, lưu DB rồi duyệt để giao theo lịch.</div>
                </div>

                <div class="local-aisgk-box long" id="cognitivebox">
                    <strong>Mức độ nhận thức</strong>
                    <div class="local-aisgk-cognitive-row">
                        <div class="local-aisgk-cognitive-item"><label>Nhận biết</label><select class="cognitive" data-key="recognize"><?php echo local_aisgk_count_options(30, 4); ?></select><div class="local-aisgk-percent" data-percent="recognize">40%</div></div>
                        <div class="local-aisgk-cognitive-item"><label>Thông hiểu</label><select class="cognitive" data-key="understand"><?php echo local_aisgk_count_options(30, 4); ?></select><div class="local-aisgk-percent" data-percent="understand">40%</div></div>
                        <div class="local-aisgk-cognitive-item"><label>Vận dụng</label><select class="cognitive" data-key="apply"><?php echo local_aisgk_count_options(30, 2); ?></select><div class="local-aisgk-percent" data-percent="apply">20%</div></div>
                        <div class="local-aisgk-cognitive-item"><label>Tổng câu</label><input id="totalquestions" type="number" min="1" max="60" value="10" readonly><div class="local-aisgk-percent" id="totalcognitivepercent">100%</div></div>
                    </div>
                </div>

                <div class="local-aisgk-box long" id="questiontypebox">
                    <strong>Cài đặt loại câu hỏi</strong>
                    <div class="local-aisgk-qtype-grid">
                    <?php $defaults = ['multichoice' => 4, 'truefalse' => 2, 'shortanswer' => 2, 'numerical' => 1, 'essay' => 1]; ?>
                    <?php foreach ($questiontypesbygroup as $group): ?>
                        <div class="local-aisgk-qtype-col">
                            <h4><?php echo s($group['title']); ?></h4>
                            <?php foreach ($group['types'] as $type => $label): ?>
                                <div class="local-aisgk-row"><label title="<?php echo s($label); ?>"><?php echo s($label); ?></label><button type="button" class="local-aisgk-helpbtn" data-title="<?php echo s($label); ?>" data-help="<?php echo s($qtypehelp[$type] ?? 'Loại câu hỏi Moodle. Cần kiểm tra lại trước khi chuyển thành quiz thật.'); ?>">?</button><select class="qtype" data-type="<?php echo s($type); ?>"><?php echo local_aisgk_count_options(30, (int)($defaults[$type] ?? 0)); ?></select><div class="local-aisgk-percent" data-qpercent="<?php echo s($type); ?>">0%</div></div>
                            <?php endforeach; ?>
                        </div>
                    <?php endforeach; ?>
                    </div>
                    <div id="qtypecheck" class="local-aisgk-ok">Tổng loại câu hỏi hợp lệ.</div>
                </div>
            </div>

            <div class="local-aisgk-actions">
                <button class="btn btn-primary" id="startbtn">Tạo ngay</button>
                <span class="local-aisgk-actions-right">
                    <button class="btn btn-secondary local-aisgk-hidden" id="savebtn">Lưu DB</button>
                    <button class="btn btn-danger local-aisgk-hidden" id="cancelbtn">Xóa</button>
                    <button class="btn btn-success local-aisgk-hidden" id="approvebtn">Duyệt</button>
                </span>
            </div>

            <div class="local-aisgk-progress">
                <div class="local-aisgk-bar"><div class="local-aisgk-fill" id="barfill"></div></div>
                <div class="local-aisgk-msg"><span id="jobmsg"><?php echo s(get_string('jobready', 'local_aisgk')); ?></span><span id="aimeta" class="local-aisgk-hidden"></span></div>
            </div>

            <div class="local-aisgk-output-grid">
                <div class="local-aisgk-box">
                    <strong>JSON AI trả về</strong>
                    <textarea id="sourcetext" readonly></textarea>
                </div>
                <div class="local-aisgk-box">
                    <strong>Nội dung câu hỏi nháp / giao bài</strong>
                    <div id="previeweditor" class="local-aisgk-editor" contenteditable="true"></div>
                    <textarea id="teacheredited" class="local-aisgk-hidden"></textarea>
                    <div class="local-aisgk-muted" style="margin-top:5px">Khung này dùng để xem thử và chỉnh sửa trước khi lưu DB hoặc duyệt.</div>
                </div>
            </div>
            <div class="local-aisgk-note" id="resultnote"></div>
        </div>
    </div>
</div>
<div id="qtypehelpbox" class="local-aisgk-helpbox local-aisgk-hidden"><h4 id="qtypehelptitle"></h4><p id="qtypehelptext"></p><button type="button" class="btn btn-secondary" id="qtypehelpclose">Đóng</button></div>
<script>
(function() {
    const cfg = {
        courseid: <?php echo (int)$courseid; ?>,
        sectionid: <?php echo (int)$sectionid; ?>,
        topicname: <?php echo json_encode($topicname); ?>,
        bookid: <?php echo (int)$bookid; ?>,
        pagefrom: <?php echo (int)$pagefrom; ?>,
        pageto: <?php echo (int)$pageto; ?>,
        sesskey: <?php echo json_encode(sesskey()); ?>,
        ajaxurl: <?php echo json_encode((new moodle_url('/local/aisgk/homework_ajax.php'))->out(false)); ?>
    };
    let currentJobId = 0;
    let currentHomeworkId = 0;
    let timer = null;

    const $ = (id) => document.getElementById(id);
    function setMsg(msg) { $('jobmsg').textContent = msg || ''; }
    function setAiMeta(usage) {
        const el = $('aimeta');
        if (!usage) { el.classList.add('local-aisgk-hidden'); el.textContent = ''; return; }
        const model = usage.model || '';
        const tokens = usage.tokens || 0;
        const api = usage.api || (usage.category === 'pay' ? 'API trả phí' : 'API hệ thống/miễn phí');
        el.textContent = ' · Model: ' + model + ' · Token: ' + tokens + ' · API: ' + api;
        el.classList.remove('local-aisgk-hidden');
    }
    function setBar(v) { $('barfill').style.width = Math.max(0, Math.min(100, v || 0)) + '%'; }
    function htmlEscape(s) { return String(s || '').replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;'); }
    function textToHtml(s) { return htmlEscape(s).replace(/\n\n+/g, '</p><p>').replace(/\n/g, '<br>'); }

    function sumSelects(selector) {
        return Array.from(document.querySelectorAll(selector)).reduce((sum, el) => sum + (parseInt(el.value || '0', 10) || 0), 0);
    }
    function updateRatios() {
        const total = sumSelects('.cognitive');
        $('totalquestions').value = total;
        document.querySelectorAll('.cognitive').forEach(el => {
            const key = el.dataset.key;
            const pct = total ? Math.round(((parseInt(el.value || '0', 10) || 0) / total) * 100) : 0;
            document.querySelector('[data-percent="' + key + '"]').textContent = pct + '%';
        });
        const qtotal = sumSelects('.qtype');
        document.querySelectorAll('.qtype').forEach(el => {
            const type = el.dataset.type;
            const pct = total ? Math.round(((parseInt(el.value || '0', 10) || 0) / total) * 100) : 0;
            document.querySelector('[data-qpercent="' + type + '"]').textContent = pct + '%';
        });
        const msg = $('qtypecheck');
        if (qtotal > total) {
            msg.className = 'local-aisgk-totalwarn';
            msg.textContent = 'Tổng loại câu hỏi (' + qtotal + ') vượt tổng câu (' + total + ').';
        } else if (qtotal < total) {
            msg.className = 'local-aisgk-totalwarn';
            msg.textContent = 'Tổng loại câu hỏi còn thiếu ' + (total - qtotal) + ' câu.';
        } else {
            msg.className = 'local-aisgk-ok';
            msg.textContent = 'Tổng loại câu hỏi hợp lệ.';
        }
        return {total: total, qtotal: qtotal, valid: qtotal === total};
    }
    document.querySelectorAll('.cognitive,.qtype').forEach(el => el.addEventListener('change', updateRatios));
    updateRatios();

    function collectOptions() {
        const ratios = updateRatios();
        const cognitive = {};
        document.querySelectorAll('.cognitive').forEach(el => cognitive[el.dataset.key] = parseInt(el.value || '0', 10) || 0);
        const qtypes = {};
        document.querySelectorAll('.qtype').forEach(el => qtypes[el.dataset.type] = parseInt(el.value || '0', 10) || 0);
        return {total: ratios.total, cognitive: cognitive, qtypes: qtypes};
    }

    async function api(action, data) {
        const fd = new URLSearchParams();
        fd.set('action', action);
        fd.set('courseid', cfg.courseid);
        fd.set('sesskey', cfg.sesskey);
        Object.keys(data || {}).forEach((k) => fd.set(k, typeof data[k] === 'object' ? JSON.stringify(data[k]) : data[k]));
        const res = await fetch(cfg.ajaxurl, {method:'POST',headers:{'Content-Type':'application/x-www-form-urlencoded; charset=UTF-8'},body:fd.toString()});
        const json = await res.json();
        if (!res.ok || !json.ok) { throw new Error((json && json.error) ? json.error : 'Request failed'); }
        return json;
    }
    function applyHomework(hw) {
        if (!hw) { return; }
        currentHomeworkId = parseInt(hw.id || 0, 10);
        $('sourcetext').value = hw.sourcetext || '';
        const content = hw.teacheredited || '';
        $('teacheredited').value = content;
        $('previeweditor').innerHTML = '<p>' + textToHtml(content) + '</p>';
        $('resultnote').textContent = hw.deliverymessage ? 'Trạng thái giao bài: ' + hw.deliverymessage : '';
        ['savebtn','approvebtn','cancelbtn'].forEach(id => $(id).classList.remove('local-aisgk-hidden'));
    }
    async function poll() {
        const json = await api('status', {jobid: currentJobId});
        const job = json.job || {};
        setBar(parseInt(job.progress || 0, 10));
        setMsg(job.message || job.steptext || '');
        if (json.result && json.result.usage) {
            setAiMeta(json.result.usage);
        }
        applyHomework(json.homework || null);
        if (job.status === 'done' || job.status === 'failed') { clearInterval(timer); timer = null; }
    }
    document.querySelectorAll('.local-aisgk-helpbtn').forEach(btn => btn.addEventListener('click', function() {
        $('qtypehelptitle').textContent = this.dataset.title || 'Thông tin loại câu hỏi';
        $('qtypehelptext').textContent = this.dataset.help || '';
        $('qtypehelpbox').classList.remove('local-aisgk-hidden');
    }));
    $('qtypehelpclose').addEventListener('click', function() { $('qtypehelpbox').classList.add('local-aisgk-hidden'); });

    $('startbtn').addEventListener('click', async function() {
        try {
            const ratios = updateRatios();
            if (!ratios.valid) { setMsg('Tổng loại câu hỏi phải bằng tổng câu.'); return; }
            setAiMeta(null);
            setMsg('Đang đưa vào hàng đợi...');
            const json = await api('start', {
                sectionid: cfg.sectionid,
                topicname: cfg.topicname,
                bookid: cfg.bookid,
                pagefrom: cfg.pagefrom,
                pageto: cfg.pageto,
                scheduledtime: $('scheduledtime').value,
                options: collectOptions()
            });
            currentJobId = parseInt(json.jobid, 10);
            setBar(5);
            if (timer) { clearInterval(timer); }
            timer = setInterval(poll, 1500);
            poll();
        } catch (e) { setMsg(e.message || String(e)); }
    });
    $('savebtn').addEventListener('click', async function() {
        if (!currentHomeworkId) return;
        try {
            $('teacheredited').value = $('previeweditor').innerHTML;
            await api('save', {homeworkid: currentHomeworkId, teacheredited: $('teacheredited').value, scheduledtime: $('scheduledtime').value});
            setMsg('Đã lưu DB.');
        } catch (e) { setMsg(e.message || String(e)); }
    });
    $('approvebtn').addEventListener('click', async function() {
        if (!currentHomeworkId) return;
        try { await api('approve', {homeworkid: currentHomeworkId}); setMsg('Đã duyệt bài tập.'); } catch (e) { setMsg(e.message || String(e)); }
    });
    $('cancelbtn').addEventListener('click', async function() {
        if (!currentHomeworkId) return;
        try { await api('cancel', {homeworkid: currentHomeworkId}); setMsg('Đã xóa bản nháp.'); } catch (e) { setMsg(e.message || String(e)); }
    });
})();
</script>
<?php echo $OUTPUT->footer();
