<?php
require('../../config.php');
require_once($CFG->dirroot . '/question/engine/bank.php');

use local_aisgk\book_repository;
use local_aisgk\local\service\homework_service;

$courseid = required_param('id', PARAM_INT);
$sectionid = optional_param('sectionid', 0, PARAM_INT);
$topicname = optional_param('topicname', '', PARAM_TEXT);

$course = get_course($courseid);
require_login($course);

$context = context_course::instance($courseid);
require_capability('local/aisgk:createhomework', $context);

$PAGE->set_context($context);
$PAGE->set_url('/local/aisgk/homework.php', ['id' => $courseid, 'sectionid' => $sectionid, 'topicname' => $topicname]);
$PAGE->set_pagelayout('embedded');
$PAGE->set_title('Tạo bài tập về nhà' . ($topicname !== '' ? ': ' . $topicname : ''));

if (!book_repository::course_has_book($courseid)) {
    throw new moodle_exception('bookrequired', 'local_aisgk');
}

$section = null;
if ($sectionid) {
    // Avoid get_fast_modinfo() here because stale/broken course module contexts can make Moodle rebuild
    // course cache and emit debug notices before the popup renders. We only need the section name.
    $section = $DB->get_record('course_sections', ['id' => $sectionid, 'course' => $courseid], 'id,name,section', IGNORE_MISSING);
}
$sectionlabel = $section && !empty($section->name) ? format_string($section->name, true, ['context' => $context]) : '';
$displaytopic = trim($sectionlabel);
if ($topicname !== '') {
    $displaytopic = ($displaytopic === '' || homework_service::normalize_title($displaytopic) === homework_service::normalize_title($topicname)) ? s($topicname) : ($displaytopic . ' · ' . s($topicname));
}
$prefill = $sectionid ? homework_service::find_section_match($courseid, $sectionid) : null;
if (!$prefill && $topicname !== '') {
    $prefill = homework_service::find_topic_match($courseid, $topicname);
}
$bookid = $prefill ? (int)$prefill['book']->id : (int)(book_repository::get_by_courseid($courseid)->id ?? 0);
$bookname = $prefill ? (string)($prefill['book']->name ?: $prefill['book']->filename) : '';
$pagefrom = $prefill ? (int)($prefill['toc']->trang ?? 1) : 1;
$pageto = $prefill ? (int)($prefill['toc']->endtrang ?? $pagefrom) : max(1, $pagefrom);
$scheduledts = time() > strtotime(date('Y-m-d 17:00:00')) ? strtotime('tomorrow 17:00') : strtotime('today 17:00');
$scheduled = date('Y-m-d\TH:i', $scheduledts);
$usemyapi = (bool)get_user_preferences('local_aisgk_use_my_api', 0, $USER->id);

$qtypevilabels = [
    'multichoice' => 'Trắc nghiệm nhiều lựa chọn',
    'truefalse' => 'Đúng/Sai',
    'shortanswer' => 'Trả lời ngắn',
    'numerical' => 'Dạng số',
    'matching' => 'Ghép đôi',
    'essay' => 'Tự luận',
    'gapselect' => 'Chọn từ điền khuyết',
    'ddwtos' => 'Kéo thả vào văn bản',
    'calculated' => 'Tính toán',
    'calculatedsimple' => 'Tính toán đơn giản',
    'calculatedmulti' => 'Trắc nghiệm tính toán',
    'ddimageortext' => 'Kéo thả lên ảnh',
    'ddmarker' => 'Đánh dấu vùng trên ảnh',
    'random' => 'Câu hỏi ngẫu nhiên',
    'description' => 'Mô tả/nội dung',
];
$qtypemenufallback = $qtypevilabels;
$qtypehelp = [
    'multichoice' => 'Câu hỏi có nhiều phương án, học sinh chọn một hoặc nhiều đáp án đúng. Phù hợp để tạo nhanh từ SGK.',
    'truefalse' => 'Câu hỏi Đúng/Sai. Dễ tạo, phù hợp kiểm tra nhận biết khái niệm, sự kiện, quy tắc.',
    'shortanswer' => 'Học sinh nhập một cụm từ hoặc câu trả lời ngắn. Dùng cho định nghĩa, thuật ngữ, kết quả ngắn.',
    'numerical' => 'Học sinh nhập đáp án dạng số, có thể có sai số. Phù hợp bài tính toán đơn giản.',
    'matching' => 'Ghép mỗi mục ở cột này với một mục tương ứng ở cột kia. Phù hợp thuật ngữ - ý nghĩa, thiết bị - chức năng.',
    'essay' => 'Câu tự luận, giáo viên thường cần chấm thủ công. Phù hợp câu vận dụng, giải thích, trình bày.',
    'gapselect' => 'Điền khuyết bằng cách chọn đáp án từ danh sách có sẵn. Phù hợp hoàn thiện câu/đoạn văn.',
    'ddwtos' => 'Kéo các từ/cụm từ vào chỗ trống trong văn bản. Dễ dùng với câu điền khuyết có nhiều vị trí.',
    'calculated' => 'Câu hỏi tính toán có biến và công thức. Khó tạo tự động, cần kiểm tra kỹ trước khi dùng thật.',
    'calculatedsimple' => 'Dạng tính toán đơn giản hơn calculated. Vẫn cần kiểm tra công thức và khoảng giá trị.',
    'calculatedmulti' => 'Trắc nghiệm có dữ liệu tính toán sinh tự động. Khó tạo và khó chuyển chính xác từ AI.',
    'ddimageortext' => 'Kéo chữ hoặc ảnh vào vị trí trên ảnh nền. Cần ảnh và tọa độ, hiện chưa nên ưu tiên AI tạo tự động.',
    'ddmarker' => 'Học sinh kéo marker vào vùng đúng trên ảnh. Cần tọa độ vùng đáp án, khó tạo tự động.',
    'random' => 'Lấy ngẫu nhiên câu hỏi đã có trong ngân hàng đề. Không phải dạng câu hỏi AI sinh nội dung mới.',
    'description' => 'Khối nội dung/mô tả trong quiz, không phải câu hỏi có điểm. Dùng để đưa đoạn thông tin hoặc hướng dẫn.',
];

try {
    $availableqtypes = class_exists('question_bank') ? question_bank::get_qtype_menu() : $qtypemenufallback;
} catch (Throwable $e) {
    $availableqtypes = $qtypemenufallback;
}

$qtypegroups = [
    'easy' => [
        'title' => 'Dễ tạo',
        'types' => ['multichoice', 'truefalse', 'shortanswer', 'numerical', 'matching'],
    ],
    'medium' => [
        'title' => 'Trung bình',
        'types' => ['essay', 'gapselect', 'ddwtos', 'calculated', 'calculatedsimple'],
    ],
    'hard' => [
        'title' => 'Khó tạo',
        'types' => ['calculatedmulti', 'ddimageortext', 'ddmarker', 'random', 'description'],
    ],
];

$questiontypesbygroup = [];
foreach ($qtypegroups as $groupkey => $group) {
    $questiontypesbygroup[$groupkey] = ['title' => $group['title'], 'types' => []];
    foreach ($group['types'] as $type) {
        if (array_key_exists($type, $availableqtypes)) {
            $questiontypesbygroup[$groupkey]['types'][$type] = $qtypevilabels[$type] ?? $availableqtypes[$type];
        } else if (array_key_exists($type, $qtypemenufallback)) {
            $questiontypesbygroup[$groupkey]['types'][$type] = $qtypevilabels[$type] ?? $qtypemenufallback[$type];
        }
    }
}

foreach ($availableqtypes as $type => $label) {
    $alreadyshown = false;
    foreach ($questiontypesbygroup as $group) {
        if (array_key_exists($type, $group['types'])) {
            $alreadyshown = true;
            break;
        }
    }
    if (!$alreadyshown) {
        $questiontypesbygroup['hard']['types'][$type] = $qtypevilabels[$type] ?? $label;
    }
}

function local_aisgk_count_options(int $max = 30, int $selected = 0): string {
    $html = '';
    for ($i = 0; $i <= $max; $i++) {
        $html .= '<option value="' . $i . '"' . ($i === $selected ? ' selected' : '') . '>' . $i . '</option>';
    }
    return $html;
}

echo $OUTPUT->header();
?>
<style>
html,body{overflow:hidden}
.local-aisgk-homework-wrap{padding:8px;font-size:12.5px;width:100%;max-width:100%;height:100vh;box-sizing:border-box;background:#fff;overflow:hidden}
.local-aisgk-card{height:calc(100vh - 16px);display:flex;flex-direction:column;border:1px solid #d7deea;border-radius:10px;background:#fff;padding:10px;box-sizing:border-box;overflow:hidden}
.local-aisgk-card h3{margin:0 0 5px;font-size:15px;font-weight:700;line-height:1.15}
.local-aisgk-grid{display:grid;grid-template-columns:1.05fr .95fr;gap:8px;margin-top:8px}
.local-aisgk-box{border:1px solid #e5e7eb;border-radius:8px;padding:8px;background:#f8fafc;min-width:0}
.local-aisgk-box.long{grid-column:1 / -1}
.local-aisgk-box strong{display:block;margin-bottom:6px;font-size:13px}
.local-aisgk-info{display:grid;grid-template-columns:90px 1fr;gap:3px 8px;color:#334155}
.local-aisgk-page-link{border:0;background:transparent;color:#2563eb;text-decoration:underline;cursor:pointer;padding:0;font:inherit;font-weight:600}.local-aisgk-source-top{display:flex;align-items:center;justify-content:space-between;gap:10px;margin-bottom:6px}.local-aisgk-resize-control{display:flex;align-items:center;gap:6px;white-space:nowrap;font-size:12px}.local-aisgk-resize-control input{width:84px!important;padding:0}.local-aisgk-resize-value{min-width:48px;text-align:right;font-weight:700;color:#0f172a}
.local-aisgk-pageviewer-backdrop{position:fixed;z-index:10001;inset:0;background:rgba(15,23,42,.55);display:none;align-items:center;justify-content:center;padding:12px}.local-aisgk-pageviewer{background:#fff;border-radius:12px;box-shadow:0 20px 60px rgba(15,23,42,.35);width:min(96vw,1080px);height:min(92vh,820px);display:flex;flex-direction:column;overflow:hidden}.local-aisgk-pageviewer-head{display:flex;align-items:center;justify-content:space-between;gap:8px;border-bottom:1px solid #e2e8f0;background:#f8fafc}.local-aisgk-pageviewer-actions{display:flex;gap:6px;align-items:center;flex-wrap:wrap}.local-aisgk-pageviewer-body{flex:1;overflow:auto;background:#0f172a;padding:12px;text-align:center}.local-aisgk-pageviewer-body img{max-width:100%;height:auto;background:#fff;border-radius:8px}
.local-aisgk-muted{color:#64748b}
.local-aisgk-form input,.local-aisgk-form select,.local-aisgk-form textarea{width:100%;box-sizing:border-box;border:1px solid #cbd5e1;border-radius:7px;padding:5px 7px;background:#fff;font-size:12.5px}
.local-aisgk-form input[type=checkbox]{width:13px!important;height:13px!important;min-width:13px;margin:0;vertical-align:middle;accent-color:#2563eb}.local-aisgk-form label{display:inline-flex;align-items:center;line-height:1.15}.local-aisgk-form .local-aisgk-row,.local-aisgk-form .local-aisgk-actions,.local-aisgk-form .local-aisgk-source-top,.local-aisgk-form .local-aisgk-resize-control{align-items:center}
.local-aisgk-row{display:grid;grid-template-columns:1fr 70px 46px;gap:6px;align-items:center;margin:4px 0}
.local-aisgk-row label{font-weight:600;margin:0;white-space:nowrap;overflow:hidden;text-overflow:ellipsis}
.local-aisgk-percent{text-align:right;color:#475467;font-weight:600}
.local-aisgk-actions{display:flex;gap:8px;flex-wrap:wrap;margin-top:8px;align-items:center;justify-content:flex-start}
.local-aisgk-actions .btn{padding:5px 12px;font-size:13px;line-height:1.25}.local-aisgk-actions .btn:disabled{opacity:.45;cursor:not-allowed}
.local-aisgk-actions-right{display:flex;gap:8px;flex-wrap:wrap}
.local-aisgk-progress{margin:8px 0}.local-aisgk-bar{height:10px;background:#e5e7eb;border-radius:999px;overflow:hidden}.local-aisgk-fill{height:100%;width:0;background:#2563eb;transition:width .25s ease}
.local-aisgk-msg{margin-top:5px;color:#334155}.local-aisgk-note{margin-top:6px;color:#475467}
.local-aisgk-hidden{display:none!important}.local-aisgk-editor{min-height:170px;border:1px solid #cbd5e1;border-radius:8px;background:#fff;padding:8px;overflow:auto;line-height:1.45}.local-aisgk-form textarea{min-height:130px;resize:vertical}
.local-aisgk-totalwarn{color:#b91c1c;font-weight:600;margin-top:6px}.local-aisgk-ok{color:#166534;font-weight:600;margin-top:6px}
.local-aisgk-compact-body{flex:1;min-height:0;overflow:auto;padding-right:2px}
.local-aisgk-cognitive-row{display:grid;grid-template-columns:repeat(4,minmax(0,1fr));gap:8px}
.local-aisgk-cognitive-item{display:grid;grid-template-columns:22px 1fr 64px 42px;gap:5px;align-items:center;border:1px solid #e5e7eb;border-radius:7px;background:#fff;padding:6px}
.local-aisgk-cognitive-item label{font-weight:600;margin:0;white-space:nowrap}
.local-aisgk-cognitive-item input,.local-aisgk-cognitive-item select{padding:4px 5px}
.local-aisgk-qtype-grid{display:grid;grid-template-columns:repeat(3,minmax(0,1fr));gap:8px}
.local-aisgk-qtype-col{border:1px solid #e2e8f0;border-radius:8px;background:#fff;padding:7px;min-width:0}
.local-aisgk-qtype-col h4{margin:0 0 6px;font-size:13px;font-weight:700;color:#0f172a}
.local-aisgk-qtype-col .local-aisgk-row{margin:0 0 4px;grid-template-columns:22px minmax(80px,1fr) 22px 56px 22px 40px}
.local-aisgk-distractor{width:18px!important;height:18px;margin:0 auto;cursor:pointer;accent-color:#2563eb}
.local-aisgk-distractor:disabled{cursor:not-allowed;opacity:.28;filter:grayscale(1)}
.local-aisgk-qstatus{font-size:15px;text-align:center}.local-aisgk-draftselect{min-width:220px;max-width:360px}.local-aisgk-helpbtn{width:19px;height:19px;border-radius:50%;border:1px solid #94a3b8;background:#fff;color:#334155;font-weight:700;font-size:12px;line-height:16px;padding:0;cursor:pointer}
.local-aisgk-helpbtn:hover{background:#e0f2fe;border-color:#0284c7}
.local-aisgk-helpbox{position:fixed;z-index:9999;left:50%;top:50%;transform:translate(-50%,-50%);width:min(420px,92vw);background:#fff;border:1px solid #94a3b8;border-radius:10px;box-shadow:0 16px 40px rgba(15,23,42,.25);padding:12px}
.local-aisgk-helpbox h4{margin:0 0 8px;font-size:15px}.local-aisgk-helpbox p{margin:0 0 10px;line-height:1.45}.local-aisgk-helpbox .btn{float:none;margin-left:auto;display:block;padding:4px 10px;font-size:12px;line-height:1.2;border-radius:7px}.local-aisgk-msgbox{position:fixed;top:14px;right:14px;z-index:10050;background:#fff;border:1px solid #cbd5e1;border-radius:10px;box-shadow:0 8px 24px rgba(15,23,42,.18);padding:8px 12px;max-width:320px;font-size:13px;line-height:1.35}.local-aisgk-msgbox.ok{border-color:#86efac}.local-aisgk-msgbox.err{border-color:#fca5a5}.local-aisgk-merge-modal .btn,.local-aisgk-merge-modal button,.local-aisgk-merge-actions .btn,.local-aisgk-merge-actions button{padding:4px 8px!important;font-size:12px!important;line-height:1.2!important;border-radius:7px!important;min-height:auto!important}.local-aisgk-merge-actions{display:flex;gap:6px;flex-wrap:wrap;align-items:center}.local-aisgk-merge-list{max-height:260px;overflow:auto;border:1px solid #e2e8f0;border-radius:8px;padding:6px;background:#f8fafc}.local-aisgk-merge-list label{display:flex;gap:6px;align-items:center;margin:4px 0;font-weight:500;font-size:12px;line-height:1.2}.local-aisgk-merge-list input{width:13px!important;height:13px!important;margin:0}
.local-aisgk-output-grid{display:grid;grid-template-columns:minmax(260px,var(--aisgk-json-width,50%)) 8px minmax(260px,1fr);gap:8px;margin-top:8px;align-items:stretch}
.local-aisgk-output-grid .local-aisgk-box{display:flex;flex-direction:column;min-height:220px;min-width:0}
.local-aisgk-output-grid textarea,.local-aisgk-output-grid .local-aisgk-editor{flex:1;min-height:0}
#previeweditor{max-height:58vh;overflow-y:auto}
.local-aisgk-splitter{width:8px;min-width:8px;cursor:col-resize;border-radius:999px;background:linear-gradient(90deg,#e2e8f0,#cbd5e1,#e2e8f0);align-self:stretch}
.local-aisgk-splitter:hover,.local-aisgk-splitter.is-dragging{background:#2563eb}
#local-aisgk-json{max-height:58vh;overflow-y:auto}
.local-aisgk-preview-question.is-selected{outline:2px solid #2563eb;background:#eff6ff}
.local-aisgk-usage-badge{font-weight:700}
.local-aisgk-editor .MathJax,.local-aisgk-editor mjx-container{font-size:112%!important}
.local-aisgk-editor .local-aisgk-preview-question{border:1px solid #e2e8f0;border-radius:10px;background:#fff;margin:0 0 12px;padding:10px;overflow:auto}
.local-aisgk-editor .local-aisgk-preview-question h4{margin:0 0 8px;font-size:15px;color:#0f172a}.local-aisgk-editor .local-aisgk-preview-question small{color:#64748b;font-weight:400}
.local-aisgk-editor .local-aisgk-img-wrap{display:block;max-width:100%;text-align:center}
.local-aisgk-editor .local-aisgk-img-wrap img{max-width:100%;height:auto;border:1px solid #cbd5e1;border-radius:8px;background:#fff;padding:3px}
.local-aisgk-editor .local-aisgk-img-panel{float:right;clear:right;max-width:42%;margin:4px 0 10px 12px;text-align:center}
.local-aisgk-editor .local-aisgk-img-figure{margin:0 0 8px 0}.local-aisgk-editor .local-aisgk-img-figure figcaption{font-weight:600;font-size:12px;color:#334155;margin-bottom:3px}
.local-aisgk-editor .local-aisgk-img-stage{position:relative;display:inline-block;max-width:100%;line-height:0}
.local-aisgk-editor .local-aisgk-img-stage .local-aisgk-img-wrap{display:inline-block;line-height:0}
.local-aisgk-editor .local-aisgk-overlay-box{position:absolute;box-sizing:border-box;border:2px solid #2563eb;background:rgba(37,99,235,.10);color:#0f172a;font-size:11px;font-weight:700;line-height:1.1;display:flex;align-items:center;justify-content:center;text-align:center;padding:1px 3px;overflow:hidden;min-width:18px;min-height:14px;pointer-events:none}
.local-aisgk-editor .local-aisgk-overlay-marker{border-color:#dc2626;background:rgba(220,38,38,.12);color:#7f1d1d}
.local-aisgk-editor .local-aisgk-overlay-circle{border-radius:999px}
.local-aisgk-editor .local-aisgk-overlay-item{border-color:#16a34a;background:rgba(22,163,74,.12);color:#14532d}
.local-aisgk-editor .local-aisgk-drag-table{margin-top:6px}.local-aisgk-editor .local-aisgk-drag-table .local-aisgk-noise-row td{background:#fff7ed}
.local-aisgk-editor .local-aisgk-choice-pill{display:inline-block;border:1px solid #cbd5e1;border-radius:999px;padding:2px 8px;margin:2px;background:#f8fafc}.local-aisgk-editor .local-aisgk-noise-pill{border-style:dashed;background:#fff7ed}.local-aisgk-img-error{color:#b91c1c;font-weight:600}
.local-aisgk-editor .local-aisgk-preview-table{width:100%;border-collapse:collapse;margin-top:6px;background:#fff}
.local-aisgk-editor .local-aisgk-preview-table th,.local-aisgk-editor .local-aisgk-preview-table td{border:1px solid #e2e8f0;padding:5px;text-align:left;vertical-align:top}
.local-aisgk-editor .local-aisgk-preview-table th{background:#f8fafc}
.local-aisgk-editor .local-aisgk-noise-row td{background:#fff7ed}

.local-aisgk-img-figure[data-pageurl],.local-aisgk-img-figure[data-source="box"]{cursor:pointer}
.local-aisgk-img-figure[data-pageurl]:hover img,.local-aisgk-img-figure[data-source="box"]:hover .local-aisgk-box-bg{outline:2px solid #2563eb}
.local-aisgk-img-picker-backdrop{position:fixed;z-index:10000;inset:0;background:rgba(15,23,42,.55);display:none;align-items:center;justify-content:center;padding:12px}
.local-aisgk-img-picker{background:#fff;border-radius:12px;box-shadow:0 20px 60px rgba(15,23,42,.35);width:min(96vw,1120px);height:min(92vh,820px);display:flex;flex-direction:column;overflow:hidden}
.local-aisgk-img-picker-head{display:flex;align-items:center;justify-content:space-between;gap:8px;border-bottom:1px solid #e2e8f0;background:#f8fafc}
.local-aisgk-img-picker-head strong{font-size:14px}.local-aisgk-img-picker-actions{display:flex;gap:6px;align-items:center;flex-wrap:wrap}.local-aisgk-img-picker-body{flex:1;overflow:auto;background:#0f172a;padding:12px;text-align:center}
.local-aisgk-img-select-stage{display:inline-block;position:relative;background:#fff;line-height:0;user-select:none}
.local-aisgk-img-select-stage img{max-width:none;display:block}
.local-aisgk-img-select-box{position:absolute;border:2px solid #22c55e;background:rgba(34,197,94,.10);box-shadow:0 0 0 9999px rgba(15,23,42,.12);cursor:move;pointer-events:auto;box-sizing:border-box}.local-aisgk-resize-handle{position:absolute;right:-6px;bottom:-6px;width:12px;height:12px;border:2px solid #fff;background:#0f172a;border-radius:3px;cursor:nwse-resize}.local-aisgk-img-box-bg{display:none;position:absolute;inset:0;background:linear-gradient(135deg,#fff,#f8fafc);border:2px dashed #94a3b8;border-radius:10px;align-items:center;justify-content:center;color:#64748b;font-weight:700;line-height:1}.local-aisgk-box-bg{display:block;position:relative;min-width:260px;width:min(100%,520px);background:linear-gradient(135deg,#fff,#f8fafc);border:2px dashed #94a3b8;border-radius:10px;line-height:1}.local-aisgk-box-title{position:absolute;left:8px;top:8px;color:#64748b;font-size:12px}.local-aisgk-edit-box{position:absolute;box-sizing:border-box;display:flex;align-items:center;justify-content:center;text-align:center;padding:2px 4px;min-width:20px;min-height:16px;font-size:12px;font-weight:700;line-height:1.1;overflow:hidden;cursor:move}.local-aisgk-edit-item{border:2px solid #f59e0b;background:rgba(245,158,11,.22);color:#78350f}.local-aisgk-edit-marker{border:2px solid #ef4444;background:rgba(239,68,68,.20);color:#7f1d1d}.local-aisgk-edit-circle{border-radius:999px}.local-aisgk-edit-label{pointer-events:none}
.local-aisgk-img-picker-note{font-size:12px;color:#475569}
@media(max-width:700px){.local-aisgk-editor .local-aisgk-img-panel{float:none;max-width:100%;margin:6px 0}.local-aisgk-editor .local-aisgk-img-wrap{max-width:100%;margin:6px 0}}
.local-aisgk-collapse-title{display:flex!important;align-items:center;justify-content:space-between;gap:8px}
.local-aisgk-collapse-btn{border:1px solid #cbd5e1;background:#fff;border-radius:5px;padding:0 6px;line-height:18px;font-size:12px;cursor:pointer}
.local-aisgk-box.is-collapsed > :not(.local-aisgk-collapse-title){display:none!important}
.local-aisgk-box.is-collapsed{min-height:32px}
.local-aisgk-output-grid.json-left-collapsed{grid-template-columns:46px 0 1fr}
.local-aisgk-output-grid.json-left-collapsed #jsonbox{overflow:hidden;padding:6px 3px}
.local-aisgk-output-grid.json-left-collapsed #jsonbox > :not(.local-aisgk-collapse-title){display:none!important}
.local-aisgk-output-grid.json-left-collapsed #jsonbox .local-aisgk-collapse-title{writing-mode:vertical-rl;min-height:180px;margin:auto}
#jsonbox.json-wide{grid-column:1 / -1;min-height:70vh}
#jsonbox.json-wide textarea{min-height:60vh}
#jsonbox.json-wide ~ #previewbox,#jsonbox.json-wide + .local-aisgk-splitter{display:none}

@media (max-width:992px){html,body{overflow:auto}.local-aisgk-homework-wrap{height:auto;overflow:visible}.local-aisgk-card{height:auto;overflow:visible}.local-aisgk-compact-body{overflow:visible}.local-aisgk-grid,.local-aisgk-output-grid{grid-template-columns:1fr}.local-aisgk-splitter{display:none}.local-aisgk-box.long{grid-column:auto}.local-aisgk-info{grid-template-columns:1fr}.local-aisgk-cognitive-row,.local-aisgk-qtype-grid{grid-template-columns:1fr}.local-aisgk-card h3{font-size:15px}}
</style>
<div class="local-aisgk-homework-wrap">
    <div class="local-aisgk-card local-aisgk-form">
        <h3>Tạo bài tập về nhà</h3>

        <div class="local-aisgk-compact-body">
            <div class="local-aisgk-grid">
                <div class="local-aisgk-box" id="box-source">
                    <div class="local-aisgk-source-top"><strong>SGK / Trang</strong><label class="local-aisgk-resize-control" title="Độ rộng ảnh màu gửi AI và lưu cache. 0 = giữ nguyên kích thước.">Resize AI <input id="aiimagewidthrange" type="range" min="0" max="3" step="1" value="1"><span id="aiimagewidthlabel" class="local-aisgk-resize-value">1000</span></label></div>
                    <div class="local-aisgk-info">
                        <div>Chủ đề</div><div><?php echo $displaytopic !== '' ? $displaytopic : '-'; ?></div>
                        <div>SGK</div><div><?php echo s($bookname !== '' ? $bookname : ('Book #' . $bookid)); ?></div>
                        <div><button type="button" id="openpageviewer" class="local-aisgk-page-link">Trang</button></div><div><?php echo (int)$pagefrom; ?> → <?php echo (int)$pageto; ?></div>
                    </div>
                    <div class="local-aisgk-muted" style="margin-top:6px"><?php echo $prefill ? s((string)$prefill['toc']->tenbai) : 'Chưa tìm thấy liên kết chủ đề với mục lục.'; ?></div>
                </div>

                <div class="local-aisgk-box">
                    <strong>Lịch giao bài</strong>
                    <label for="scheduledtime">Thời điểm giao bài</label>
                    <input id="scheduledtime" type="datetime-local" value="<?php echo s($scheduled); ?>">
                    <div class="local-aisgk-muted" style="margin-top:6px">Có thể tạo bản nháp, chỉnh sửa, lưu DB rồi duyệt để giao theo lịch.</div>
                </div>

                <div class="local-aisgk-box long" id="cognitivebox">
                    <strong>Cài đặt/Xem kết quả tạo Mức độ nhận thức</strong>
                    <div class="local-aisgk-cognitive-row">
                        <div class="local-aisgk-cognitive-item" data-level-row="nhan_biet"><span class="local-aisgk-qstatus" data-lstatus="nhan_biet"></span><label>Nhận biết</label><select class="cognitive" data-key="recognize"><?php echo local_aisgk_count_options(30, 4); ?></select><div class="local-aisgk-percent" data-percent="recognize">40%</div></div>
                        <div class="local-aisgk-cognitive-item" data-level-row="thong_hieu"><span class="local-aisgk-qstatus" data-lstatus="thong_hieu"></span><label>Thông hiểu</label><select class="cognitive" data-key="understand"><?php echo local_aisgk_count_options(30, 4); ?></select><div class="local-aisgk-percent" data-percent="understand">40%</div></div>
                        <div class="local-aisgk-cognitive-item" data-level-row="van_dung"><span class="local-aisgk-qstatus" data-lstatus="van_dung"></span><label>Vận dụng</label><select class="cognitive" data-key="apply"><?php echo local_aisgk_count_options(30, 2); ?></select><div class="local-aisgk-percent" data-percent="apply">20%</div></div>
                        <div class="local-aisgk-cognitive-item"><label>Tổng câu</label><input id="totalquestions" type="number" min="1" max="60" value="10" readonly><div class="local-aisgk-percent" id="totalcognitivepercent">100%</div></div>
                    </div>
                </div>

                <div class="local-aisgk-box long" id="questiontypebox">
                    <strong>Cài đặt/Xem kết quả tạo loại câu hỏi</strong>
                    <div class="local-aisgk-qtype-grid">
                    <?php $defaults = ['multichoice' => 4, 'truefalse' => 2, 'shortanswer' => 2, 'numerical' => 1, 'essay' => 1]; ?>
                    <?php foreach ($questiontypesbygroup as $group): ?>
                        <div class="local-aisgk-qtype-col">
                            <h4><?php echo s($group['title']); ?></h4>
                            <?php foreach ($group['types'] as $type => $label): ?>
                                <div class="local-aisgk-row" data-qtype-row="<?php echo s($type); ?>"><span class="local-aisgk-qstatus" data-qstatus="<?php echo s($type); ?>"></span><label title="<?php echo s($label); ?>"><?php echo s($label); ?></label><button type="button" class="local-aisgk-helpbtn" data-title="<?php echo s($label); ?>" data-help="<?php echo s($qtypehelp[$type] ?? 'Loại câu hỏi Moodle. Cần kiểm tra lại trước khi chuyển thành quiz thật.'); ?>">?</button><select class="qtype" data-type="<?php echo s($type); ?>"><?php echo local_aisgk_count_options(30, (int)($defaults[$type] ?? 0)); ?></select><input type="checkbox" class="local-aisgk-distractor" data-type="<?php echo s($type); ?>" title="Thêm phương án nhiễu cho loại câu hỏi này" aria-label="Thêm nhiễu cho <?php echo s($label); ?>"><div class="local-aisgk-percent" data-qpercent="<?php echo s($type); ?>">0%</div></div>
                            <?php endforeach; ?>
                        </div>
                    <?php endforeach; ?>
                    </div>
                    <div id="qtypecheck" class="local-aisgk-ok">Tổng loại câu hỏi hợp lệ.</div>
                    <div id="validatorreport" class="local-aisgk-note"></div>
                </div>
            </div>

            <div class="local-aisgk-actions">
                <button class="btn btn-primary" id="startbtn">Tạo mới (<span id="apiremaining">*</span>)</button>
                <select id="draftselect" class="local-aisgk-draftselect"><option value="">Tạo bài tập về nhà: chọn bản nháp</option></select>
                <button class="btn btn-warning" id="fixerrorsbtn" disabled title="Gửi các câu hỏi lỗi và mô tả lỗi tới AI để sửa">Sửa lỗi</button>
                <button class="btn btn-secondary" id="mergedraftsbtn" title="Gộp nhiều bản nháp đã đạt thành một bản nháp lớn">Gộp nháp</button>
                <button class="btn btn-info" id="copytemplatebtn">Tải mẫu</button>
                <button class="btn btn-secondary" id="pastejsonbtn" title="Dán JSON từ AI và xử lý theo luồng paste riêng">Paste JSON</button>
                <button class="btn btn-danger" id="wipebtn">Xóa sạch</button>
                <button class="btn btn-secondary local-aisgk-hidden" id="savebtn">Lưu DB</button>
                <button class="btn btn-success local-aisgk-hidden" id="approvebtn" disabled title="Chỉ bật khi JSON đã validate đạt và sẵn sàng đưa vào Moodle">Duyệt</button>
            </div>

            <div class="local-aisgk-progress">
                <div class="local-aisgk-bar"><div class="local-aisgk-fill" id="barfill"></div></div>
                <div class="local-aisgk-msg"><span id="jobmsg"><?php echo s(get_string('jobready', 'local_aisgk')); ?></span><span id="aimeta" class="local-aisgk-hidden"></span></div>
            </div>

            <div class="local-aisgk-output-grid">
                <div class="local-aisgk-box" id="jsonbox">
                    <strong>JSON đã normalize</strong>
                    <textarea id="local-aisgk-json"></textarea>
                    <textarea id="sourcetext" class="local-aisgk-hidden"></textarea>
                </div>
                <div id="local-aisgk-splitter" class="local-aisgk-splitter" title="Kéo để đổi độ rộng JSON / Preview"></div>
                <div class="local-aisgk-box" id="previewbox">
                    <strong>Nội dung câu hỏi nháp / giao bài</strong>
                    <div id="previeweditor" class="local-aisgk-editor" contenteditable="true"></div>
                    <textarea id="teacheredited" class="local-aisgk-hidden"></textarea>
                    <div class="local-aisgk-muted" style="margin-top:5px">Khung này dùng để xem thử và chỉnh sửa trước khi lưu DB hoặc duyệt.</div>
                </div>
            </div>
            <div class="local-aisgk-note" id="resultnote"></div>
        </div>
    </div>
</div>
<div id="qtypehelpbox" class="local-aisgk-helpbox local-aisgk-hidden"><h4 id="qtypehelptitle"></h4><p id="qtypehelptext"></p><button type="button" class="btn btn-secondary" id="qtypehelpclose">Đóng</button></div>
<div id="mergedraftsbox" class="local-aisgk-helpbox local-aisgk-hidden"><h4>Gộp nháp đã đạt</h4><p>Chọn các bản nháp đã đạt để gộp thành một bản nháp lớn. Các nút xóa bên dưới chỉ xử lý nháp của topic hiện tại.</p><div id="mergedraftslist" class="local-aisgk-merge-list"></div><div style="margin-top:10px;text-align:right"><button type="button" class="btn btn-warning" id="mergedraftsdeletebad" title="Chỉ xóa nháp không đạt của topic hiện tại">Xóa nháp không đạt</button> <button type="button" class="btn btn-danger" id="mergedraftsdeleteselected" title="Xóa bản nháp đang chọn trong combo nháp">Xóa nháp đang chọn</button> <button type="button" class="btn btn-secondary" id="mergedraftscancel">Đóng</button> <button type="button" class="btn btn-primary" id="mergedraftsconfirm">Gộp</button></div></div>
<div id="local-aisgk-pageviewer-backdrop" class="local-aisgk-pageviewer-backdrop"><div class="local-aisgk-pageviewer"><div class="local-aisgk-pageviewer-head"><strong id="local-aisgk-pageviewer-title">Trang SGK</strong><div class="local-aisgk-pageviewer-actions"><button type="button" class="btn" id="local-aisgk-pageviewer-prev">‹ Prev</button><button type="button" class="btn" id="local-aisgk-pageviewer-next">Next ›</button><button type="button" class="btn" id="local-aisgk-pageviewer-close">Đóng</button></div></div><div class="local-aisgk-pageviewer-body"><img id="local-aisgk-pageviewer-img" alt="Trang SGK"></div></div></div>
<script>

function localAisgkMsgBox(msg, type) {
    try {
        var old = document.querySelector('.local-aisgk-msgbox');
        if (old) { old.remove(); }
        var box = document.createElement('div');
        box.className = 'local-aisgk-msgbox ' + (type || '');
        box.textContent = String(msg || '');
        document.body.appendChild(box);
        setTimeout(function() {
            if (box && box.parentNode) { box.parentNode.removeChild(box); }
        }, 2800);
    } catch(e) {
        try { window.localAisgkMsgBox(msg); } catch(_e) {}
    }
}

window.MathJax = window.MathJax || {tex:{inlineMath:[["\\(","\\)"]],displayMath:[["\\[","\\]"]]}, startup:{typeset:false}};
</script>
<script src="https://cdn.jsdelivr.net/npm/mathjax@3/es5/tex-mml-chtml.js" async></script>
<script>
(function() {
    const cfg = {
        courseid: <?php echo (int)$courseid; ?>,
        sectionid: <?php echo (int)$sectionid; ?>,
        topicname: <?php echo json_encode($topicname); ?>,
        bookid: <?php echo (int)$bookid; ?>,
        pagefrom: <?php echo (int)$pagefrom; ?>,
        pageto: <?php echo (int)$pageto; ?>,
        sesskey: <?php echo json_encode(sesskey()); ?>,
        ajaxurl: <?php echo json_encode((new moodle_url('/local/aisgk/homework_ajax.php'))->out(false)); ?>,
        pageimgurl: <?php echo json_encode((new moodle_url('/local/aisgk/pageimg.php'))->out(false)); ?>
    };
    let currentJobId = 0;
    let currentHomeworkId = 0;
    let lastDrafts = [];
    let timer = null;
    let generatingBusy = false;

    const $ = (id) => document.getElementById(id);
    const AI_WIDTHS = [0, 1000, 1200, 1400];
    function currentAiImageWidth() { const r = $('aiimagewidthrange'); return AI_WIDTHS[Math.max(0, Math.min(AI_WIDTHS.length - 1, parseInt((r && r.value) || '1', 10) || 0))]; }
    function updateAiImageWidthLabel() { const w = currentAiImageWidth(); const label = $('aiimagewidthlabel'); if (label) { label.textContent = w === 0 ? 'Gốc' : String(w); } }
    function setMsg(msg) { $('jobmsg').textContent = msg || ''; }
    function setAiMeta(usage) {
        const el = $('aimeta');
        if (!usage) { el.classList.add('local-aisgk-hidden'); el.textContent = ''; return; }
        const model = usage.model || '';
        const tokens = usage.tokens || 0;
        const api = usage.api || (usage.category === 'pay' ? 'API trả phí' : 'API hệ thống/miễn phí');
        el.textContent = ' · Model: ' + model + ' · Token: ' + tokens + ' · API: ' + api;
        el.classList.remove('local-aisgk-hidden');
    }
    function ensureApiRemainingSpan() {
        const btn = $('startbtn');
        if (!btn) { return null; }
        let el = $('apiremaining');
        if (!el) {
            btn.innerHTML = 'Tạo mới (<span id="apiremaining">*</span>)';
            el = $('apiremaining');
        }
        return el;
    }
    function setApiUsage(u) {
        const el = ensureApiRemainingSpan();
        if (!el || !u) { return; }
        if (u.isadmin || parseInt(u.remain, 10) < 0) {
            el.textContent = 'Admin';
            $('startbtn').title = u.text || 'Admin không tính lượt API hệ thống';
            return;
        }
        el.textContent = parseInt(u.remain || 0, 10);
        $('startbtn').title = u.text || ('API hệ thống hôm nay: ' + u.used + '/' + u.limit);
    }
    async function refreshApiUsage() {
        try {
            const json = await api('usage', {});
            if (json.userusage) { setApiUsage(json.userusage); }
        } catch (e) {}
    }
    function updateStartButtonState() {
        const ratios = updateRatios();
        const btn = $('startbtn');
        if (generatingBusy) {
            btn.disabled = true;
            btn.title = 'Đang tạo, vui lòng chờ tiến trình hoàn tất.';
        } else {
            btn.disabled = !ratios.valid;
            btn.title = ratios.valid ? (btn.title || '') : 'Tổng loại câu hỏi phải bằng tổng câu thì mới tạo được.';
        }
        return ratios.valid;
    }
    function setBar(v) { $('barfill').style.width = Math.max(0, Math.min(100, v || 0)) + '%'; }
    function htmlEscape(s) { return String(s || '').replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;'); }
    function attrEscape(s) { return htmlEscape(s).replace(/"/g, '&quot;').replace(/\'/g, '&#39;'); }
    function preserveLocalImageHtml(raw) {
        const saved = [];
        const text = String(raw || '').replace(/<span\s+class=["']local-aisgk-img-wrap["'][\s\S]*?<\/span>/gi, function(m) {
            const srcOk = /<img\b/i.test(m) && /src=["'](?:[^"']*pluginfile\.php[^"']*|[^"']*\/local\/aisgk\/previewimg\.php[^"']*)["']/i.test(m);
            if (!srcOk) { return m; }
            const key = '%%AISGK_IMG_' + saved.length + '%%';
            saved.push(m);
            return key;
        });
        return {text: text, saved: saved};
    }
    function restoreLocalImageHtml(text, saved) {
        let out = text;
        (saved || []).forEach(function(html, i) { out = out.replace('%%AISGK_IMG_' + i + '%%', html); });
        return out;
    }
    function fixMoodleVarsForMathJax(raw) {
        return String(raw || '')
            .replace(/\\\(\s*\\?\{([a-zA-Z][a-zA-Z0-9_]*)\}\s*\\\)/g, '{$1}')
            .replace(/\\\[\s*\\?\{([a-zA-Z][a-zA-Z0-9_]*)\}\s*\\\]/g, '{$1}')
            .replace(/\\\{([a-zA-Z][a-zA-Z0-9_]*)\\?\}/g, '{$1}');
    }
    function renderRichText(raw) {
        raw = fixMoodleVarsForMathJax(raw);
        const pack = preserveLocalImageHtml(raw);
        return restoreLocalImageHtml(htmlEscape(pack.text), pack.saved).replace(/\n/g, '<br>');
    }
    function isLikelyMathAtom(s) {
        const t = String(s || '').trim();
        if (!t || /[À-ỹ]/u.test(t)) { return false; }
        if (/\\[a-zA-Z]+/.test(t) || /[\^_]/.test(t)) { return true; }
        if (/^[+\-]?\d+(?:[.,]\d+)?$/.test(t)) { return false; }
        return /^[\\{}()[\]0-9a-zA-Z+\-*/^_.,:·\s]+$/.test(t) && /[a-zA-Z]/.test(t) && /[0-9^_+\-*/·]|\\/.test(t);
    }
    function renderMathText(raw) {
        let t = String(raw || '').trim();
        if (t && !/\\\(|\\\[|\$\$/.test(t) && isLikelyMathAtom(t)) { t = '\\(' + t + '\\)'; }
        return renderRichText(t);
    }
    function textToHtml(s) { return renderRichText(s).replace(/\n\n+/g, '</p><p>'); }
    function looksLikeHtml(s) { return /<\/?(div|p|table|span|img|ul|ol|li|br|strong|h[1-6])\b/i.test(String(s || '')); }
    function renderMathInPreview() {
        const el = $('previeweditor');
        if (!el || !window.MathJax || !window.MathJax.typesetPromise) { return; }
        el.innerHTML = fixMoodleVarsForMathJax(el.innerHTML);
        window.MathJax.typesetClear && window.MathJax.typesetClear([el]);
        window.MathJax.typesetPromise([el]).catch(function() {});
    }


    function setupJsonPreviewSplitter() {
        const grid = document.querySelector('.local-aisgk-output-grid');
        const splitter = $('local-aisgk-splitter');
        if (!grid || !splitter) { return; }
        let dragging = false;
        function setFromClientX(clientX) {
            const rect = grid.getBoundingClientRect();
            const min = 260;
            const max = Math.max(min, rect.width - 260 - 16);
            let w = Math.max(min, Math.min(max, clientX - rect.left));
            grid.style.setProperty('--aisgk-json-width', w + 'px');
        }
        splitter.addEventListener('mousedown', function(e) { dragging = true; splitter.classList.add('is-dragging'); e.preventDefault(); });
        window.addEventListener('mousemove', function(e) { if (dragging) { setFromClientX(e.clientX); } });
        window.addEventListener('mouseup', function() { dragging = false; splitter.classList.remove('is-dragging'); });
        splitter.addEventListener('touchstart', function(e) { dragging = true; splitter.classList.add('is-dragging'); if (e.touches[0]) { setFromClientX(e.touches[0].clientX); } }, {passive:true});
        window.addEventListener('touchmove', function(e) { if (dragging && e.touches[0]) { setFromClientX(e.touches[0].clientX); } }, {passive:true});
        window.addEventListener('touchend', function() { dragging = false; splitter.classList.remove('is-dragging'); });
    }

    function setupCollapse() {
        document.querySelectorAll('.local-aisgk-box > strong').forEach(strong => {
            if (strong.classList.contains('local-aisgk-collapse-title')) { return; }
            strong.classList.add('local-aisgk-collapse-title');
            const btn = document.createElement('button');
            btn.type = 'button';
            btn.className = 'local-aisgk-collapse-btn';
            btn.textContent = '−';
            btn.title = 'Thu gọn / mở rộng';
            strong.appendChild(btn);
            btn.addEventListener('click', function(e) {
                e.preventDefault();
                e.stopPropagation();
                const box = strong.parentElement;
                if (box && box.id === 'jsonbox') {
                    const grid = box.closest('.local-aisgk-output-grid');
                    if (box.classList.contains('json-wide')) {
                        box.classList.remove('json-wide');
                        if (grid) { grid.classList.add('json-left-collapsed'); }
                        btn.textContent = '+';
                    } else if (grid && grid.classList.contains('json-left-collapsed')) {
                        grid.classList.remove('json-left-collapsed');
                        box.classList.add('json-wide');
                        btn.textContent = '↔';
                    } else {
                        box.classList.add('json-wide');
                        btn.textContent = '↔';
                    }
                    return;
                }
                box.classList.toggle('is-collapsed');
                btn.textContent = box.classList.contains('is-collapsed') ? '+' : '−';
            });
        });
    }

    function sumSelects(selector) {
        return Array.from(document.querySelectorAll(selector)).reduce((sum, el) => sum + (parseInt(el.value || '0', 10) || 0), 0);
    }
    function updateRatios() {
        const total = sumSelects('.cognitive');
        $('totalquestions').value = total;
        document.querySelectorAll('.cognitive').forEach(el => {
            const key = el.dataset.key;
            const pct = total ? Math.round(((parseInt(el.value || '0', 10) || 0) / total) * 100) : 0;
            document.querySelector('[data-percent="' + key + '"]').textContent = pct + '%';
        });
        const qtotal = sumSelects('.qtype');
        document.querySelectorAll('.qtype').forEach(el => {
            const type = el.dataset.type;
            const pct = total ? Math.round(((parseInt(el.value || '0', 10) || 0) / total) * 100) : 0;
            document.querySelector('[data-qpercent="' + type + '"]').textContent = pct + '%';
        });
        const msg = $('qtypecheck');
        if (qtotal > total) {
            msg.className = 'local-aisgk-totalwarn';
            msg.textContent = 'Tổng loại câu hỏi (' + qtotal + ') vượt tổng câu (' + total + ').';
        } else if (qtotal < total) {
            msg.className = 'local-aisgk-totalwarn';
            msg.textContent = 'Tổng loại câu hỏi còn thiếu ' + (total - qtotal) + ' câu.';
        } else {
            msg.className = 'local-aisgk-ok';
            msg.textContent = 'Tổng loại câu hỏi hợp lệ.';
        }
        const btn = $('startbtn');
        if (btn && !generatingBusy) { btn.disabled = (qtotal !== total); }
        if (btn && generatingBusy) { btn.disabled = true; }
        return {total: total, qtotal: qtotal, valid: qtotal === total};
    }

    const DISTRACTOR_QTYPES = ['ddwtos', 'gapselect', 'matching', 'multichoice', 'ddmarker', 'ddimageortext'];
    function updateDistractorUi() {
        document.querySelectorAll('.local-aisgk-distractor').forEach(cb => {
            const type = cb.dataset.type || '';
            const enabled = DISTRACTOR_QTYPES.indexOf(type) !== -1;
            cb.disabled = !enabled;
            cb.title = enabled ? 'Thêm phương án nhiễu cho loại câu hỏi này' : 'Loại câu hỏi này chưa hỗ trợ thêm nhiễu';
            if (!enabled) { cb.checked = false; }
        });
    }
    function resetCreateUi() {
        clearTimeout(validateTimer);
        clearReportIcons();
        $('validatorreport').textContent = '';
        $('resultnote').textContent = '';
        $('aimeta').classList.add('local-aisgk-hidden');
        $('aimeta').textContent = '';
        updateRatios();
        updateDistractorUi();
        const base = updateRatios();
        $('qtypecheck').textContent = 'Tổng loại câu hỏi ' + (base.valid ? 'hợp lệ.' : 'chưa hợp lệ.') + ' Kết quả tạo: Chưa kiểm tra.';
        $('savebtn').classList.add('local-aisgk-hidden');
        $('approvebtn').classList.add('local-aisgk-hidden');
        lastValidationOk = false; updateApproveButton();
    }
    document.querySelectorAll('.cognitive,.qtype,.local-aisgk-distractor').forEach(el => el.addEventListener('change', function() { resetCreateUi(); }));
    if ($('aiimagewidthrange')) { $('aiimagewidthrange').addEventListener('input', updateAiImageWidthLabel); $('aiimagewidthrange').addEventListener('change', resetCreateUi); updateAiImageWidthLabel(); }
    setupJsonPreviewSplitter();
    setupCollapse();
    updateRatios();
    updateDistractorUi();

    function collectOptions() {
        const ratios = updateRatios();
        const cognitive = {};
        document.querySelectorAll('.cognitive').forEach(el => cognitive[el.dataset.key] = parseInt(el.value || '0', 10) || 0);
        const qtypes = {};
        document.querySelectorAll('.qtype').forEach(el => qtypes[el.dataset.type] = parseInt(el.value || '0', 10) || 0);
        const distractors = {};
        document.querySelectorAll('.local-aisgk-distractor').forEach(el => {
            if (!el.disabled && el.checked) { distractors[el.dataset.type] = true; }
        });
        return {total: ratios.total, cognitive: cognitive, qtypes: qtypes, distractors: distractors, ai_image_width: currentAiImageWidth()};
    }


    let validateTimer = null;
    let suppressNextInputValidate = false;
    let lastValidationReport = null;
    let lastValidationOk = false;
    function updateApproveButton() {
        const btn = $('approvebtn');
        if (!btn) { return; }
        const ok = !!(currentHomeworkId && lastValidationOk && $('local-aisgk-json').value.trim());
        btn.disabled = !ok;
        btn.title = ok ? 'Duyệt và tạo BTVN trong Moodle cho section hiện tại.' : 'Chỉ bật khi JSON đã validate đạt và có nháp hợp lệ.';
    }
    function updateFixErrorsButton() {
        const btn = $("fixerrorsbtn");
        if (!btn) { return; }
        const hasJson = !!$('local-aisgk-json').value.trim();
        const canFix = !!(currentHomeworkId && hasJson && lastValidationReport && !lastValidationOk);
        btn.disabled = !canFix;
        btn.style.display = '';
        btn.title = canFix ? 'Gửi câu hỏi lỗi + mô tả lỗi tới AI để sửa cấu trúc, loại câu hỏi hoặc mức độ.' : 'Chỉ bật khi có nháp, có JSON và validate chưa đạt.';
    }
    function setStatusIcon(el, ok, title) {
        if (!el) { return; }
        el.className = 'local-aisgk-qstatus icon fa ' + (ok ? 'fa-chevron-down' : 'fa-times') + ' fa-fw';
        el.setAttribute('title', title || '');
    }
    function clearReportIcons() {
        document.querySelectorAll('[data-qstatus],[data-lstatus]').forEach(el => {
            el.className = 'local-aisgk-qstatus';
            el.removeAttribute('title');
        });
    }
    function errorFor(key, report) {
        const errors = report && report.errors ? report.errors : [];
        const lowkey = String(key).toLowerCase();
        return errors.filter(e => String(e).toLowerCase().indexOf(lowkey) !== -1).join('\n');
    }
    function renderReport(report) {
        const box = $('validatorreport');
        box.textContent = '';
        clearReportIcons();
        lastValidationReport = report || null;
        lastValidationOk = !!(report && report.ok);
        updateApproveButton();
        updateFixErrorsButton();
        const base = updateRatios();
        if (!report) {
            $('qtypecheck').textContent = 'Tổng loại câu hỏi ' + (base.valid ? 'hợp lệ.' : 'chưa hợp lệ.') + ' Kết quả tạo: Chưa kiểm tra.';
            return;
        }
        if (report.summary && report.summary.qtypes) {
            Object.keys(report.summary.qtypes).forEach(t => {
                const v = report.summary.qtypes[t];
                const ok = parseInt(v.used || 0, 10) === parseInt(v.required || 0, 10);
                const detail = (ok ? 'Đạt: ' : 'Không đạt: ') + t + ' (' + v.used + '/' + v.required + ').' + (errorFor(t, report) ? '\n' + errorFor(t, report) : '');
                setStatusIcon(document.querySelector('[data-qstatus="' + t + '"]'), ok, detail);
                const row = document.querySelector('[data-qtype-row="' + t + '"]');
                if (row) { row.setAttribute('title', detail); }
                const pct = document.querySelector('[data-qpercent="' + t + '"]');
                if (pct) { pct.textContent = '(' + v.used + '/' + v.required + ')'; pct.setAttribute('title', detail); }
            });
        }
        if (report.summary && report.summary.levels) {
            Object.keys(report.summary.levels).forEach(t => {
                const v = report.summary.levels[t];
                const ok = parseInt(v.used || 0, 10) === parseInt(v.required || 0, 10);
                const detail = (ok ? 'Đạt: ' : 'Không đạt: ') + t + ' (' + v.used + '/' + v.required + ').' + (errorFor(t, report) ? '\n' + errorFor(t, report) : '');
                setStatusIcon(document.querySelector('[data-lstatus="' + t + '"]'), ok, detail);
                const row = document.querySelector('[data-level-row="' + t + '"]');
                if (row) { row.setAttribute('title', detail); }
            });
        }
        $('qtypecheck').className = report.ok ? 'local-aisgk-ok' : 'local-aisgk-totalwarn';
        $('qtypecheck').textContent = 'Tổng loại câu hỏi ' + (base.valid ? 'hợp lệ.' : 'chưa hợp lệ.') + ' Kết quả tạo: ' + (report.ok ? 'Đạt.' : 'Không đạt.');
        updateApproveButton();
        updateFixErrorsButton();
    }
    function updateConfigFromQuestionsJson(raw) {
        const qs = parseQuestionsPayload(raw);
        if (!qs || !qs.length) { return false; }
        const qtypes = {};
        const levels = {};
        qs.forEach(q => {
            if (!q || typeof q !== 'object') { return; }
            const t = String(q.type || q.qtype || '').trim();
            const l = String(q.level || '').trim();
            if (t) { qtypes[t] = (qtypes[t] || 0) + 1; }
            if (l) { levels[l] = (levels[l] || 0) + 1; }
        });
        document.querySelectorAll('.qtype').forEach(el => {
            const v = qtypes[el.dataset.type] || 0;
            if (el.value !== String(v)) { el.value = String(Math.min(30, v)); }
        });
        document.querySelectorAll('.cognitive').forEach(el => {
            const v = levels[el.dataset.key] || 0;
            if (el.value !== String(v)) { el.value = String(Math.min(30, v)); }
        });
        updateRatios();
        updateDistractorUi();
        return true;
    }

    function scheduleLiveValidate() {
        clearTimeout(validateTimer);
        validateTimer = setTimeout(async function() {
            const val = $('local-aisgk-json').value.trim();
            if (!val) { renderReport(null); $('previeweditor').innerHTML = ''; return; }
            renderJsonPreviewFromTextarea();
            try {
                const json = await api('validatejson', {json: val, options: collectOptions(), homeworkid: currentHomeworkId});
                if (json.normalizedjson && json.normalizedjson !== val && !json.hasdebugraw) {
                    $('local-aisgk-json').value = json.normalizedjson;
                    $('sourcetext').value = json.normalizedjson;
                    renderJsonPreviewFromTextarea();
                }
                renderReport(json.report);
                if (json.previewjson) {
                    const previewQuestions = parseQuestionsPayload(json.previewjson);
                    const rendered = renderQuestionsPreview(previewQuestions);
                    if (rendered) { $('previeweditor').innerHTML = rendered; renderMathInPreview(); }
                }
            } catch (e) {
                renderReport({ok:false, errors:[e.message || String(e)], summary:{qtypes:{},levels:{}}});
            }
        }, 500);
    }
    async function loadDrafts(selectId) {
        try {
            const json = await api('drafts', {sectionid: cfg.sectionid});
            lastDrafts = json.drafts || [];
            const sel = $('draftselect');
            sel.innerHTML = '<option value="">Tạo bài tập về nhà: chọn bản nháp</option>';
            let first = '';
            lastDrafts.forEach(d => {
                const o = document.createElement('option');
                o.value = d.id;
                const dmeta = parseMetaFromSourceFormula(d.sourceformula || '');
                const dmodel = dmeta.model_fix || dmeta.model_create || dmeta.model || (dmeta.usage && dmeta.usage.model) || '';
                o.textContent = 'Nháp #' + d.id + ' · ' + (d.topicname || '') + (dmodel ? ' · ' + dmodel : '') + ' · ' + (d.status || '');
                sel.appendChild(o);
                if (!first) { first = String(d.id); }
            });
            const target = selectId ? String(selectId) : first;
            if (target && Array.from(sel.options).some(o => o.value === target)) {
                sel.value = target;
                if (!currentHomeworkId || selectId) {
                    const loaded = await api('loaddraft', {homeworkid: target});
                    applyHomework(loaded.homework);
                }
            }
        } catch (e) { setMsg(e.message || String(e)); }
    }
    async function api(action, data) {
        const fd = new URLSearchParams();
        fd.set('action', action);
        fd.set('courseid', cfg.courseid);
        fd.set('sesskey', cfg.sesskey);
        Object.keys(data || {}).forEach((k) => fd.set(k, typeof data[k] === 'object' ? JSON.stringify(data[k]) : data[k]));
        const res = await fetch(cfg.ajaxurl, {method:'POST',headers:{'Content-Type':'application/x-www-form-urlencoded; charset=UTF-8'},body:fd.toString()});
        const json = await res.json();
        if (!res.ok || !json.ok) { throw new Error((json && json.error) ? json.error : 'Yêu cầu thất bại'); }
        return json;
    }
    function applyOptions(options) {
        if (!options || typeof options !== 'object') { updateRatios(); return; }
        if (Object.prototype.hasOwnProperty.call(options, 'ai_image_width')) {
            const idx = AI_WIDTHS.indexOf(parseInt(options.ai_image_width || 0, 10));
            if (idx >= 0 && $('aiimagewidthrange')) { $('aiimagewidthrange').value = String(idx); updateAiImageWidthLabel(); }
        }
        const cognitive = options.cognitive || {};
        const levelMap = {nhan_biet:'recognize', thong_hieu:'understand', van_dung:'apply'};
        Object.keys(cognitive).forEach(k => {
            const key = levelMap[k] || k;
            const el = document.querySelector('.cognitive[data-key="' + key + '"]');
            if (el) { el.value = parseInt(cognitive[k] || 0, 10) || 0; }
        });
        const qtypes = options.qtypes || {};
        Object.keys(qtypes).forEach(t => {
            const el = document.querySelector('.qtype[data-type="' + t + '"]');
            if (el) { el.value = parseInt(qtypes[t] || 0, 10) || 0; }
        });
        const distractors = options.distractors || {};
        document.querySelectorAll('.local-aisgk-distractor').forEach(cb => {
            cb.checked = !!distractors[cb.dataset.type];
        });
        updateDistractorUi();
        updateRatios();
    }
    function parseMetaFromSourceFormula(sourceformula) {
        if (!sourceformula) { return {}; }
        try {
            const data = JSON.parse(sourceformula);
            return data && typeof data === 'object' ? data : {};
        } catch (e) { return {}; }
    }
    function parseOptionsFromHomework(hw) {
        const data = parseMetaFromSourceFormula(hw && hw.sourceformula);
        return data && data.options ? data.options : data;
    }
    function parseQuestionsPayload(raw) {
        if (!raw) { return []; }
        try {
            const data = typeof raw === 'string' ? JSON.parse(raw) : raw;
            if (Array.isArray(data)) { return data; }
            if (data && Array.isArray(data.questions)) { return data.questions; }
            if (data && data._debug && data._debug.normalizedjson) {
                try {
                    const n = JSON.parse(data._debug.normalizedjson);
                    return Array.isArray(n.questions) ? n.questions : [];
                } catch (e) {}
            }
        } catch (e) {}
        return [];
    }
    function normalizedBoxStyle(box) {
        if (!box || typeof box !== 'object') { return ''; }
        const left = Number(box.left ?? box.x ?? 0);
        const top = Number(box.top ?? box.y ?? 0);
        const width = Number(box.width ?? box.w ?? 0);
        const height = Number(box.height ?? box.h ?? 0);
        if (![left, top, width, height].every(Number.isFinite) || width <= 0 || height <= 0) { return ''; }
        return 'left:' + Math.max(0, Math.min(100, left / 10)) + '%;top:' + Math.max(0, Math.min(100, top / 10)) + '%;width:' + Math.max(1, Math.min(100, width / 10)) + '%;height:' + Math.max(1, Math.min(100, height / 10)) + '%;';
    }
    function normalizedCoordsStyle(coords, shape) {
        if (!Array.isArray(coords) || coords.length < 3) { return ''; }
        if (String(shape || '').toLowerCase() === 'circle' && coords.length === 3) {
            const x = Number(coords[0]), y = Number(coords[1]), r = Math.max(1, Number(coords[2]));
            if (![x, y, r].every(Number.isFinite)) { return ''; }
            return normalizedBoxStyle({left:x-r, top:y-r, width:r*2, height:r*2});
        }
        if (coords.length < 4) { return ''; }
        const x1 = Number(coords[0]), y1 = Number(coords[1]), x2 = Number(coords[2]), y2 = Number(coords[3]);
        if (![x1, y1, x2, y2].every(Number.isFinite)) { return ''; }
        const left = Math.min(x1, x2), top = Math.min(y1, y2);
        const width = Math.max(1, Math.abs(x2 - x1)), height = Math.max(1, Math.abs(y2 - y1));
        return normalizedBoxStyle({left:left, top:top, width:width, height:height});
    }
    function imageIdForOverlay(row, fallback) {
        return String((row && (row.image_id || row.image || row.bg || row.background || row.target_image)) || fallback || '');
    }
    function renderQuestionOverlay(q, imgid) {
        const type = q.qtype || q.type || '';
        let html = '';
        if (type === 'ddimageortext' && Array.isArray(q.items)) {
            q.items.forEach(function(item) {
                if (!item || !item.drop_zone) { return; }
                if (imageIdForOverlay(item, imgid) !== String(imgid || '')) { return; }
                const st = normalizedBoxStyle(item.drop_zone);
                if (!st) { return; }
                const label = String(item.content || item.label || item.id || 'item');
                html += '<span class="local-aisgk-overlay-box local-aisgk-overlay-item" style="' + attrEscape(st) + '" title="' + attrEscape(label) + '">' + renderMathText(label) + '</span>';
            });
        }
        if (type === 'ddmarker' && Array.isArray(q.markers)) {
            q.markers.forEach(function(marker) {
                if (!marker) { return; }
                if (imageIdForOverlay(marker, imgid) !== String(imgid || '')) { return; }
                const shape = String(marker.shape || '').toLowerCase();
                const st = normalizedCoordsStyle(marker.coords || marker.source_box || marker.box, shape);
                if (!st) { return; }
                const label = String(marker.label || marker.text || marker.id || 'marker');
                const cls = 'local-aisgk-overlay-box local-aisgk-overlay-marker' + (shape === 'circle' ? ' local-aisgk-overlay-circle' : '');
                html += '<span class="' + cls + '" style="' + attrEscape(st) + '" title="' + attrEscape(label) + '">' + renderMathText(label) + '</span>';
            });
        }
        return html;
    }
    function renderDdImageOrTextDetails(q) {
        const items = Array.isArray(q.items) ? q.items : [];
        const noise = Array.isArray(q.da_nhieu) ? q.da_nhieu : (q.da_nhieu ? [q.da_nhieu] : []);
        if (!items.length && !noise.length) { return ''; }
        let html = '<table class="local-aisgk-preview-table local-aisgk-drag-table"><thead><tr><th>Item kéo thả</th><th>Loại</th><th>Vùng thả đúng</th></tr></thead><tbody>';
        items.forEach(function(item) {
            const content = (item && (item.content || item.text || item.label || item.id)) || '';
            const dz = item && item.drop_zone ? item.drop_zone : null;
            const dztext = dz ? ('left=' + dz.left + ', top=' + dz.top + ', width=' + dz.width + ', height=' + dz.height) : 'Nhiễu / chưa có vùng thả';
            html += '<tr><td>' + renderMathText(content) + '</td><td>' + htmlEscape((item && item.type) || 'text') + '</td><td>' + htmlEscape(dztext) + '</td></tr>';
        });
        noise.forEach(function(d) {
            const content = (d && typeof d === 'object') ? (d.content || d.text || d.label || d.id || '') : d;
            html += '<tr class="local-aisgk-noise-row"><td>' + renderMathText(content || '') + '</td><td>Nhiễu</td><td>Không có vùng thả đúng</td></tr>';
        });
        html += '</tbody></table>';
        return html;
    }
    function renderDdMarkerDetails(q) {
        const markers = Array.isArray(q.markers) ? q.markers : [];
        if (!markers.length) { return ''; }
        let html = '<table class="local-aisgk-preview-table local-aisgk-drag-table"><thead><tr><th>Marker</th><th>Dạng</th><th>Tọa độ đúng</th></tr></thead><tbody>';
        markers.forEach(function(marker) {
            const label = (marker && (marker.label || marker.text || marker.id)) || '';
            const coords = Array.isArray(marker && marker.coords) ? marker.coords.join(', ') : '';
            html += '<tr><td>' + renderMathText(label) + '</td><td>' + htmlEscape((marker && marker.shape) || 'rectangle') + '</td><td>' + htmlEscape(coords) + '</td></tr>';
        });
        html += '</tbody></table>';
        return html;
    }
    function renderQuestionsPreview(questions) {
        if (!questions || !questions.length) { return ''; }
        return questions.map(function(q, idx) {
            const type = q.qtype || q.type || '';
            let html = '<div class="local-aisgk-preview-question" data-qindex="' + idx + '">';
            html += '<h4>Câu ' + (idx + 1) + ' <small>(' + htmlEscape(type) + ' · ' + htmlEscape(q.level || '') + ')</small></h4>';
            html += '<div class="local-aisgk-preview-qtext">' + renderRichText(q.questiontext || '') + '</div>';
            if (Array.isArray(q._preview_images) && q._preview_images.length) {
                html += '<div class="local-aisgk-img-panel">';
                q._preview_images.forEach(function(im) {
                    const label = htmlEscape((im && im.label) || (im && im.id) || 'ảnh');
                    const pageurl = htmlEscape((im && im.page_url) || '');
                    const imgid = htmlEscape((im && im.id) || '');
                    const source = htmlEscape((im && im.source) || 'sgk');
                    const box = htmlEscape(JSON.stringify((im && im.source_box) || []));
                    const page = htmlEscape(String((im && im.page) || ''));
                    const clickable = (pageurl || source === 'box') ? ' data-pageurl="' + pageurl + '" data-source="' + source + '" data-imgid="' + imgid + '" data-sourcebox="' + box + '" data-page="' + page + '" title="Bấm để chỉnh ảnh/vùng/items/markers"' : '';
                    const overlay = renderQuestionOverlay(q, (im && im.id) || '');
                    html += '<figure class="local-aisgk-img-figure"' + clickable + '><figcaption>' + label + '</figcaption><span class="local-aisgk-img-stage">' + ((im && im.html) || '') + overlay + '</span></figure>';
                });
                html += '</div>';
            }
            if (type === 'matching' && Array.isArray(q.subquestions)) {
                html += '<table class="local-aisgk-preview-table"><thead><tr><th>Vế trái</th><th>Vế phải</th></tr></thead><tbody>';
                q.subquestions.forEach(function(sq) {
                    html += '<tr><td>' + renderRichText((sq && sq.question) || '') + '</td><td>' + renderRichText((sq && sq.answer) || '') + '</td></tr>';
                });
                const matchingNoise = Array.isArray(q.da_nhieu) ? q.da_nhieu : (q.da_nhieu ? [q.da_nhieu] : []);
                matchingNoise.forEach(function(d) {
                    const txt = (d && typeof d === 'object') ? (d.text || d.answer || d.value || '') : d;
                    html += '<tr class="local-aisgk-noise-row"><td><strong>Nhiễu</strong></td><td><span class="local-aisgk-choice-pill local-aisgk-noise-pill">' + renderMathText(txt || '') + '</span></td></tr>';
                });
                html += '</tbody></table>';
            } else if ((type === 'ddwtos' || type === 'gapselect') && Array.isArray(q.choices)) {
                html += '<div class="local-aisgk-preview-choices"><strong>Đáp án kéo thả:</strong> ';
                html += q.choices.map(function(c) {
                    return '<span class="local-aisgk-choice-pill">[[' + parseInt((c && c.group) || 1, 10) + ']] ' + renderMathText((c && c.text) || '') + '</span>';
                }).join(' ');
                if (Array.isArray(q.da_nhieu) && q.da_nhieu.length) {
                    html += ' ' + q.da_nhieu.map(function(d) {
                        const txt = (d && typeof d === 'object') ? (d.text || d.answer || d.value || '') : d;
                        return '<span class="local-aisgk-choice-pill local-aisgk-noise-pill">Nhiễu: ' + renderMathText(txt || '') + '</span>';
                    }).join(' ');
                }
                html += '</div>';
            } else if (type === 'ddimageortext') {
                html += renderDdImageOrTextDetails(q);
            } else if (type === 'ddmarker') {
                html += renderDdMarkerDetails(q);
            } else if (Array.isArray(q.answers)) {
                html += '<ul class="local-aisgk-preview-answers">';
                q.answers.forEach(function(a) {
                    html += '<li>' + renderMathText((a && (a.text || a.answer)) || '') + '</li>';
                });
                html += '</ul>';
            }
            html += '</div>';
            return html;
        }).join('');
    }
    function renderJsonPreviewFromTextarea() {
        const questions = parseQuestionsPayload($('local-aisgk-json').value || '');
        const rendered = renderQuestionsPreview(questions);
        if (rendered) {
            $('previeweditor').innerHTML = rendered;
            renderMathInPreview();
        }
    }

    function selectPreviewQuestion(idx) {
        document.querySelectorAll('.local-aisgk-preview-question').forEach(el => {
            el.classList.toggle('is-selected', parseInt(el.dataset.qindex || '-1', 10) === idx);
        });
        const qel = document.querySelector('.local-aisgk-preview-question[data-qindex="' + idx + '"]');
        if (qel) { qel.scrollIntoView({block:'nearest', behavior:'smooth'}); }
    }
    function selectJsonQuestion(idx) {
        const ta = $('local-aisgk-json');
        const text = ta.value || '';
        if (!text) { return; }
        const needle = '"Câu ' + (idx + 1) + '"';
        let pos = text.indexOf(needle);
        if (pos < 0) {
            let count = -1;
            const re = /"(?:qtype|type)"\s*:/g;
            let m;
            while ((m = re.exec(text)) !== null) {
                count++;
                if (count === idx) { pos = m.index; break; }
            }
        }
        if (pos >= 0) {
            ta.focus();
            const selEnd = Math.min(text.length, pos + Math.max(1, needle.length));
            ta.setSelectionRange(pos, selEnd);
            const beforeLines = text.slice(0, pos).split(/\n/).length;
            const totalLines = Math.max(1, text.split(/\n/).length);
            const maxScroll = Math.max(0, ta.scrollHeight - ta.clientHeight);
            ta.scrollTop = Math.max(0, Math.min(maxScroll, Math.round((beforeLines / totalLines) * ta.scrollHeight) - 80));
        }
    }
    function guessQuestionIndexFromJsonCursor() {
        const ta = $('local-aisgk-json');
        const before = (ta.value || '').slice(0, ta.selectionStart || 0);
        const nameMatches = before.match(/"name"\s*:\s*"Câu\s+\d+"/g);
        if (nameMatches && nameMatches.length) { return Math.max(0, nameMatches.length - 1); }
        const matches = before.match(/"(?:qtype|type)"\s*:/g);
        return matches ? Math.max(0, matches.length - 1) : 0;
    }

    let imagePickerState = null;
    function ensureImagePicker() {
        let wrap = document.getElementById('local-aisgk-img-picker-backdrop');
        if (wrap) { return wrap; }
        wrap = document.createElement('div');
        wrap.id = 'local-aisgk-img-picker-backdrop';
        wrap.className = 'local-aisgk-img-picker-backdrop';
        wrap.innerHTML = '<div class="local-aisgk-img-picker">'
            + '<div class="local-aisgk-img-picker-head"><strong id="local-aisgk-img-picker-title">Chỉnh ảnh/vùng kéo thả</strong>'
            + '<div class="local-aisgk-img-picker-actions"><span class="local-aisgk-img-picker-note">Kéo/resize khung xanh để chọn ảnh; kéo/resize các ô vàng/đỏ để sửa drop_zone hoặc marker.</span>'
            + '<button type="button" class="btn" id="local-aisgk-img-picker-cancel">Đóng</button>'
            + '<button type="button" class="btn primary" id="local-aisgk-img-picker-save">Cập nhật JSON</button></div></div>'
            + '<div class="local-aisgk-img-picker-body"><div class="local-aisgk-img-select-stage" id="local-aisgk-img-edit-stage"><img id="local-aisgk-img-picker-page" alt="Trang SGK"><div id="local-aisgk-img-box-bg" class="local-aisgk-img-box-bg"><span>BOX 0–1000</span></div><div id="local-aisgk-img-select-box" class="local-aisgk-img-select-box"><span class="local-aisgk-resize-handle"></span></div><div id="local-aisgk-img-edit-overlays"></div></div></div>'
            + '</div>';
        document.body.appendChild(wrap);
        wrap.querySelector('#local-aisgk-img-picker-cancel').addEventListener('click', closeImagePicker);
        wrap.addEventListener('click', function(e){ if (e.target === wrap) { closeImagePicker(); } });
        wrap.querySelector('#local-aisgk-img-picker-save').addEventListener('click', saveImagePickerBox);
        const selectbox = wrap.querySelector('#local-aisgk-img-select-box');
        selectbox.addEventListener('mousedown', function(e){ startEditDrag(e, 'source', null); });
        return wrap;
    }
    function closeImagePicker() {
        const wrap = document.getElementById('local-aisgk-img-picker-backdrop');
        if (wrap) { wrap.style.display = 'none'; }
        imagePickerState = null;
    }
    function clamp(v, min, max) { return Math.max(min, Math.min(max, v)); }
    function getJsonData() {
        const ta = $('local-aisgk-json');
        let data;
        try { data = JSON.parse(ta.value || '{}'); } catch(e) { return null; }
        const qs = Array.isArray(data) ? data : (Array.isArray(data.questions) ? data.questions : []);
        return {ta:ta, data:data, qs:qs, isArray:Array.isArray(data)};
    }
    function saveJsonData(jd) {
        if (!jd) { return; }
        if (jd.isArray) { jd.ta.value = JSON.stringify(jd.qs, null, 2); }
        else { jd.data.questions = jd.qs; jd.ta.value = JSON.stringify(jd.data, null, 2); }
        jd.ta.dispatchEvent(new Event('input', {bubbles:true}));
        renderJsonPreviewFromTextarea();
    }
    function boxGridToCss(box, w, h) {
        if (!Array.isArray(box) || box.length !== 4 || !w || !h) { return null; }
        const xmin = parseFloat(box[0]) || 0, ymin = parseFloat(box[1]) || 0, xmax = parseFloat(box[2]) || 0, ymax = parseFloat(box[3]) || 0;
        return {x1:clamp(xmin / 1000 * w, 0, w), y1:clamp(ymin / 1000 * h, 0, h), x2:clamp(xmax / 1000 * w, 0, w), y2:clamp(ymax / 1000 * h, 0, h)};
    }
    function cssRectToGrid(rect, w, h) {
        const x1 = Math.min(rect.x1, rect.x2), y1 = Math.min(rect.y1, rect.y2), x2 = Math.max(rect.x1, rect.x2), y2 = Math.max(rect.y1, rect.y2);
        return [Math.round(x1 / Math.max(1,w) * 1000), Math.round(y1 / Math.max(1,h) * 1000), Math.round(x2 / Math.max(1,w) * 1000), Math.round(y2 / Math.max(1,h) * 1000)];
    }
    function setAbsBox(el, rect) {
        if (!el || !rect) { return; }
        const x = Math.min(rect.x1, rect.x2), y = Math.min(rect.y1, rect.y2);
        const w = Math.abs(rect.x2 - rect.x1), h = Math.abs(rect.y2 - rect.y1);
        el.style.left = x + 'px'; el.style.top = y + 'px'; el.style.width = w + 'px'; el.style.height = h + 'px';
    }
    function getStageSize() {
        const stage = document.getElementById('local-aisgk-img-edit-stage');
        const img = document.getElementById('local-aisgk-img-picker-page');
        return {w:stage.clientWidth || img.clientWidth || 1, h:stage.clientHeight || img.clientHeight || 1};
    }
    function getSourceRect() {
        const st = imagePickerState;
        if (!st) { return {x1:0,y1:0,x2:1,y2:1}; }
        if (st.source === 'box') { const sz = getStageSize(); return {x1:0,y1:0,x2:sz.w,y2:sz.h}; }
        return st.rect || {x1:0,y1:0,x2:1,y2:1};
    }
    function dzToAbsRect(dz) {
        const src = getSourceRect();
        const sw = Math.max(1, Math.abs(src.x2-src.x1)), sh = Math.max(1, Math.abs(src.y2-src.y1));
        const sx = Math.min(src.x1, src.x2), sy = Math.min(src.y1, src.y2);
        const l = Number(dz && (dz.left ?? dz.x) || 0), t = Number(dz && (dz.top ?? dz.y) || 0), w = Number(dz && (dz.width ?? dz.w) || 0), h = Number(dz && (dz.height ?? dz.h) || 0);
        return {x1:sx + l/1000*sw, y1:sy + t/1000*sh, x2:sx + (l+w)/1000*sw, y2:sy + (t+h)/1000*sh};
    }
    function coordsToAbsRect(coords, shape) {
        coords = Array.isArray(coords) ? coords : [0,0,80,80];
        if (String(shape || '').toLowerCase() === 'circle' && coords.length === 3) {
            const x = Number(coords[0]) || 0, y = Number(coords[1]) || 0, r = Math.max(1, Number(coords[2]) || 20);
            return dzToAbsRect({left:x-r, top:y-r, width:r*2, height:r*2});
        }
        const x1 = Number(coords[0]) || 0, y1 = Number(coords[1]) || 0, x2 = Number(coords[2]) || x1 + 80, y2 = Number(coords[3]) || y1 + 80;
        return dzToAbsRect({left:Math.min(x1,x2), top:Math.min(y1,y2), width:Math.max(1,Math.abs(x2-x1)), height:Math.max(1,Math.abs(y2-y1))});
    }
    function absRectToDz(rect) {
        const src = getSourceRect();
        const sw = Math.max(1, Math.abs(src.x2-src.x1)), sh = Math.max(1, Math.abs(src.y2-src.y1));
        const sx = Math.min(src.x1, src.x2), sy = Math.min(src.y1, src.y2);
        const x1 = Math.min(rect.x1, rect.x2), y1 = Math.min(rect.y1, rect.y2), x2 = Math.max(rect.x1, rect.x2), y2 = Math.max(rect.y1, rect.y2);
        const out = {left:clamp(Math.round((x1-sx)/sw*1000),0,1000), top:clamp(Math.round((y1-sy)/sh*1000),0,1000), width:clamp(Math.round((x2-x1)/sw*1000),1,1000), height:clamp(Math.round((y2-y1)/sh*1000),1,1000)};
        if (out.left + out.width > 1000) { out.width = Math.max(1, 1000 - out.left); }
        if (out.top + out.height > 1000) { out.height = Math.max(1, 1000 - out.top); }
        return out;
    }
    function absRectToMarkerCoords(rect, marker) {
        const dz = absRectToDz(rect);
        const shape = String(marker && marker.shape || '').toLowerCase();
        if (shape === 'circle' && Array.isArray(marker && marker.coords) && marker.coords.length === 3) {
            const cx = clamp(Math.round(dz.left + dz.width / 2), 0, 1000);
            const cy = clamp(Math.round(dz.top + dz.height / 2), 0, 1000);
            const rr = clamp(Math.round((dz.width + dz.height) / 4), 1, 1000);
            return [cx, cy, rr];
        }
        return [dz.left, dz.top, dz.left + dz.width, dz.top + dz.height];
    }
    function updateActiveEditElement(rect) {
        const a = imagePickerState && imagePickerState.active;
        if (!a) { return; }
        let selector = '';
        if (a.kind === 'source') { selector = '#local-aisgk-img-select-box'; }
        else { selector = '.local-aisgk-edit-box[data-kind="' + a.kind + '"][data-index="' + a.index + '"]'; }
        const el = document.querySelector(selector);
        if (el) { setAbsBox(el, rect); }
    }
    function refreshAllEditBoxes() {
        if (!imagePickerState) { return; }
        const srcbox = document.getElementById('local-aisgk-img-select-box');
        if (imagePickerState.source === 'box') { srcbox.style.display = 'none'; }
        else { srcbox.style.display = 'block'; setAbsBox(srcbox, imagePickerState.rect); }
        const q = imagePickerState.q || {};
        const layer = document.getElementById('local-aisgk-img-edit-overlays');
        layer.innerHTML = '';
        const imgid = imagePickerState.imgid;
        if ((q.type || q.qtype) === 'ddimageortext' && Array.isArray(q.items)) {
            q.items.forEach(function(item, i){
                if (!item || !item.drop_zone) { return; }
                if (imageIdForOverlay(item, imgid) !== String(imgid || '')) { return; }
                const el = document.createElement('div');
                el.className = 'local-aisgk-edit-box local-aisgk-edit-item';
                el.dataset.kind = 'item'; el.dataset.index = String(i);
                el.innerHTML = '<span class="local-aisgk-edit-label">' + renderMathText(item.content || item.text || item.label || item.id || ('item '+(i+1))) + '</span><span class="local-aisgk-resize-handle"></span>';
                layer.appendChild(el); setAbsBox(el, dzToAbsRect(item.drop_zone));
                el.addEventListener('mousedown', function(e){ startEditDrag(e, 'item', i); });
            });
        }
        if ((q.type || q.qtype) === 'ddmarker' && Array.isArray(q.markers)) {
            q.markers.forEach(function(marker, i){
                if (!marker) { return; }
                if (imageIdForOverlay(marker, imgid) !== String(imgid || '')) { return; }
                const el = document.createElement('div');
                const shape = String(marker.shape || '').toLowerCase();
                el.className = 'local-aisgk-edit-box local-aisgk-edit-marker' + (shape === 'circle' ? ' local-aisgk-edit-circle' : '');
                el.dataset.kind = 'marker'; el.dataset.index = String(i);
                el.innerHTML = '<span class="local-aisgk-edit-label">' + renderMathText(marker.label || marker.text || marker.id || ('marker '+(i+1))) + '</span><span class="local-aisgk-resize-handle"></span>';
                layer.appendChild(el); setAbsBox(el, coordsToAbsRect(marker.coords || marker.source_box || marker.box, shape));
                el.addEventListener('mousedown', function(e){ startEditDrag(e, 'marker', i); });
            });
        }
        renderMathInPreview();
    }
    function openImagePicker(fig, qidx) {
        const source = fig.getAttribute('data-source') || 'sgk';
        const pageurl = fig.getAttribute('data-pageurl') || '';
        if (!pageurl && source !== 'box') { return; }
        const imgid = fig.getAttribute('data-imgid') || '';
        let oldbox = [];
        try { oldbox = JSON.parse(fig.getAttribute('data-sourcebox') || '[]'); } catch(e) {}
        const jd = getJsonData();
        if (!jd || !jd.qs[qidx]) { localAisgkMsgBox('JSON hiện tại không parse được hoặc không tìm thấy câu.'); return; }
        const qcopy = JSON.parse(JSON.stringify(jd.qs[qidx]));
        const wrap = ensureImagePicker();
        const img = wrap.querySelector('#local-aisgk-img-picker-page');
        const boxbg = wrap.querySelector('#local-aisgk-img-box-bg');
        wrap.querySelector('#local-aisgk-img-picker-title').textContent = (source === 'box' ? 'Chỉnh box ' : 'Chọn lại ảnh ') + imgid + (fig.getAttribute('data-page') ? ' · SGK trang ' + fig.getAttribute('data-page') : '');
        imagePickerState = {qidx:qidx, imgid:imgid, source:source, box:oldbox, drawing:false, rect:null, q:qcopy, active:null, jd:jd};
        wrap.style.display = 'flex';
        if (source === 'box') {
            img.style.display = 'none'; img.removeAttribute('src'); boxbg.style.display = 'flex';
            const sourcebox = (qcopy.images && qcopy.images[imgid] && Array.isArray(qcopy.images[imgid].source_box)) ? qcopy.images[imgid].source_box : [0,0,1000,1000];
            const w = Math.max(1, (Number(sourcebox[2])-Number(sourcebox[0])) || 1000), h = Math.max(1, (Number(sourcebox[3])-Number(sourcebox[1])) || 1000);
            const stage = wrap.querySelector('#local-aisgk-img-edit-stage');
            stage.style.width = 'min(80vw, 760px)'; stage.style.aspectRatio = w + ' / ' + h;
            setTimeout(refreshAllEditBoxes, 30);
        } else {
            boxbg.style.display = 'none'; img.style.display = 'block';
            img.onload = function(){
                const stage = wrap.querySelector('#local-aisgk-img-edit-stage');
                stage.style.width = img.clientWidth + 'px'; stage.style.height = img.clientHeight + 'px'; stage.style.aspectRatio = '';
                const cssbox = boxGridToCss(oldbox, img.clientWidth, img.clientHeight);
                imagePickerState.rect = cssbox || {x1:0,y1:0,x2:img.clientWidth,y2:img.clientHeight};
                refreshAllEditBoxes();
            };
            img.src = pageurl + (pageurl.indexOf('?') >= 0 ? '&' : '?') + 't=' + Date.now();
        }
    }
    function stagePoint(e) {
        const stage = document.getElementById('local-aisgk-img-edit-stage');
        const r = stage.getBoundingClientRect();
        return {x:clamp(e.clientX - r.left, 0, stage.clientWidth), y:clamp(e.clientY - r.top, 0, stage.clientHeight)};
    }
    function startEditDrag(e, kind, index) {
        if (!imagePickerState) { return; }
        e.preventDefault(); e.stopPropagation();
        const p = stagePoint(e);
        const resize = !!(e.target && e.target.classList && e.target.classList.contains('local-aisgk-resize-handle'));
        let rect;
        if (kind === 'source') { rect = imagePickerState.rect || {x1:p.x,y1:p.y,x2:p.x+20,y2:p.y+20}; }
        else if (kind === 'item') { rect = dzToAbsRect(imagePickerState.q.items[index].drop_zone); }
        else { const m = imagePickerState.q.markers[index] || {}; rect = coordsToAbsRect(m.coords || m.source_box || m.box, m.shape); }
        imagePickerState.active = {kind:kind, index:index, mode:resize?'resize':'move', start:p, orig:Object.assign({}, rect)};
        document.addEventListener('mousemove', moveEditDrag);
        document.addEventListener('mouseup', endEditDrag);
    }
    function moveEditDrag(e) {
        const st = imagePickerState, a = st && st.active;
        if (!a) { return; }
        const p = stagePoint(e), dx = p.x - a.start.x, dy = p.y - a.start.y;
        let r = Object.assign({}, a.orig);
        if (a.mode === 'resize') { r.x2 = clamp(r.x2 + dx, 0, getStageSize().w); r.y2 = clamp(r.y2 + dy, 0, getStageSize().h); }
        else { const w = r.x2-r.x1, h = r.y2-r.y1, sz = getStageSize(); r.x1 = clamp(r.x1+dx,0,Math.max(0,sz.w-w)); r.y1 = clamp(r.y1+dy,0,Math.max(0,sz.h-h)); r.x2 = r.x1+w; r.y2 = r.y1+h; }
        if (a.kind === 'source') { st.rect = r; }
        else if (a.kind === 'item') { st.q.items[a.index].drop_zone = absRectToDz(r); }
        else { st.q.markers[a.index].coords = absRectToMarkerCoords(r, st.q.markers[a.index]); }
        updateActiveEditElement(r);
    }
    function endEditDrag() {
        if (imagePickerState) { imagePickerState.active = null; }
        document.removeEventListener('mousemove', moveEditDrag);
        document.removeEventListener('mouseup', endEditDrag);
    }
    function saveImagePickerBox() {
        const st = imagePickerState;
        if (!st || !st.imgid) { return; }
        const jd = getJsonData();
        if (!jd || !jd.qs[st.qidx]) { localAisgkMsgBox('JSON hiện tại không parse được.'); return; }
        if (!jd.qs[st.qidx].images || !jd.qs[st.qidx].images[st.imgid]) { localAisgkMsgBox('Không tìm thấy images.' + st.imgid + ' trong câu đang chọn.'); return; }
        if (st.source !== 'box') {
            const sz = getStageSize();
            if (!st.rect || Math.abs(st.rect.x2-st.rect.x1) < 5 || Math.abs(st.rect.y2-st.rect.y1) < 5) { localAisgkMsgBox('Vùng chọn quá nhỏ.'); return; }
            jd.qs[st.qidx].images[st.imgid].source_box = cssRectToGrid(st.rect, sz.w, sz.h);
        } else {
            jd.qs[st.qidx].images[st.imgid].source = 'box';
            if (!Array.isArray(jd.qs[st.qidx].images[st.imgid].source_box)) { jd.qs[st.qidx].images[st.imgid].source_box = [0,0,1000,1000]; }
        }
        if (Array.isArray(st.q.items)) { jd.qs[st.qidx].items = st.q.items; }
        if (Array.isArray(st.q.markers)) { jd.qs[st.qidx].markers = st.q.markers; }
        saveJsonData(jd);
        closeImagePicker();
    }

    let pageViewerPage = cfg.pagefrom;
    function pageViewerUrl(page) {
        return cfg.pageimgurl + '?courseid=' + encodeURIComponent(cfg.courseid) + '&bookid=' + encodeURIComponent(cfg.bookid) + '&sectionid=' + encodeURIComponent(cfg.sectionid) + '&page=' + encodeURIComponent(page) + '&width=' + encodeURIComponent(currentAiImageWidth()) + '&t=' + Date.now();
    }
    function showPageViewer(page) {
        pageViewerPage = Math.max(cfg.pagefrom, Math.min(cfg.pageto, parseInt(page || cfg.pagefrom, 10) || cfg.pagefrom));
        $('local-aisgk-pageviewer-title').textContent = 'SGK trang ' + pageViewerPage + ' / ' + cfg.pagefrom + '–' + cfg.pageto;
        $('local-aisgk-pageviewer-img').src = pageViewerUrl(pageViewerPage);
        $('local-aisgk-pageviewer-prev').disabled = pageViewerPage <= cfg.pagefrom;
        $('local-aisgk-pageviewer-next').disabled = pageViewerPage >= cfg.pageto;
        $('local-aisgk-pageviewer-backdrop').style.display = 'flex';
    }
    if ($('openpageviewer')) { $('openpageviewer').addEventListener('click', function(){ showPageViewer(cfg.pagefrom); }); }
    $('local-aisgk-pageviewer-close').addEventListener('click', function(){ $('local-aisgk-pageviewer-backdrop').style.display = 'none'; });
    $('local-aisgk-pageviewer-backdrop').addEventListener('click', function(e){ if (e.target === this) { this.style.display = 'none'; } });
    $('local-aisgk-pageviewer-prev').addEventListener('click', function(){ showPageViewer(pageViewerPage - 1); });
    $('local-aisgk-pageviewer-next').addEventListener('click', function(){ showPageViewer(pageViewerPage + 1); });

    $('previeweditor').addEventListener('click', function(e) {
        const qel = e.target.closest && e.target.closest('.local-aisgk-preview-question');
        if (!qel) { return; }
        const idx = parseInt(qel.dataset.qindex || '0', 10);
        const fig = e.target.closest && e.target.closest('.local-aisgk-img-figure[data-pageurl]');
        if (fig) { selectPreviewQuestion(idx); selectJsonQuestion(idx); openImagePicker(fig, idx); return; }
        selectPreviewQuestion(idx);
        selectJsonQuestion(idx);
    });
    $("local-aisgk-json").addEventListener("click", function() { selectPreviewQuestion(guessQuestionIndexFromJsonCursor()); });
    $('local-aisgk-json').addEventListener('keyup', function() { lastValidationOk = false; updateApproveButton(); selectPreviewQuestion(guessQuestionIndexFromJsonCursor()); });
    async function processPastedJson(raw) {
        const text = String(raw || '').trim();
        if (!text) { return; }
        clearTimeout(validateTimer);
        setMsg('Đang xử lý JSON paste theo luồng riêng...');
        try {
            const json = await api('processpastejson', {json: text, options: collectOptions(), homeworkid: currentHomeworkId});
            if (json.options) { applyOptions(json.options); }
            suppressNextInputValidate = true;
            $('local-aisgk-json').value = json.normalizedjson || text;
            $('sourcetext').value = $('local-aisgk-json').value;
            renderJsonPreviewFromTextarea();
            renderReport(json.report);
            const previewQuestions = parseQuestionsPayload(json.normalizedjson || '');
            const rendered = renderQuestionsPreview(previewQuestions);
            if (rendered) { $('previeweditor').innerHTML = rendered; renderMathInPreview(); }
            setMsg(json.report && json.report.ok ? 'JSON paste đã xử lý và validate đạt.' : 'JSON paste đã xử lý, nhưng validate chưa đạt.');
        } catch (e) {
            renderReport({ok:false, errors:[e.message || String(e)], summary:{qtypes:{},levels:{}}});
            setMsg(e.message || String(e));
        }
    }
    $('local-aisgk-json').addEventListener('paste', function(e) {
        const clip = e.clipboardData || window.clipboardData;
        const text = clip ? clip.getData('text') : '';
        if (text) {
            e.preventDefault();
            processPastedJson(text);
            return;
        }
        setTimeout(() => processPastedJson($('local-aisgk-json').value), 0);
    });
    $('local-aisgk-json').addEventListener('input', function() {
        if (suppressNextInputValidate) { suppressNextInputValidate = false; return; }
        lastValidationOk = false; updateApproveButton(); scheduleLiveValidate();
    });

    function applyHomework(hw) {
        if (!hw) { return; }
        currentHomeworkId = parseInt(hw.id || 0, 10);
        const hwmeta = parseMetaFromSourceFormula(hw.sourceformula || '');
        applyOptions(hwmeta && hwmeta.options ? hwmeta.options : parseOptionsFromHomework(hw));
        if (hwmeta && (hwmeta.usage || hwmeta.model || hwmeta.model_create || hwmeta.model_fix)) {
            const metaUsage = hwmeta.usage || {};
            metaUsage.model = hwmeta.model_fix ? ((hwmeta.model_create || hwmeta.model || metaUsage.model || "") + " -> sua: " + hwmeta.model_fix) : (hwmeta.model_create || hwmeta.model || metaUsage.model || "");
            if (hwmeta.tokens_create || hwmeta.tokens_fix) { metaUsage.tokens = (parseInt(hwmeta.tokens_create || 0, 10) || 0) + (parseInt(hwmeta.tokens_fix || 0, 10) || 0); }
            setAiMeta(metaUsage);
        }
        $('sourcetext').value = hw.sourcetext || '';
        $('local-aisgk-json').value = hw.sourcetext || hw.questiondata || '';
        renderReport(null);
        scheduleLiveValidate();
        const content = hw.teacheredited || '';
        $('teacheredited').value = content;
        const questions = parseQuestionsPayload(hw.previewquestiondata || hw.questiondata || hw.sourcetext || '');
        const rendered = renderQuestionsPreview(questions);
        if (rendered) {
            $('previeweditor').innerHTML = rendered;
        } else {
            $('previeweditor').innerHTML = looksLikeHtml(content) ? content : ('<p>' + textToHtml(content) + '</p>');
        }
        renderMathInPreview();
        $('resultnote').textContent = hw.deliverymessage ? 'Trạng thái giao bài: ' + hw.deliverymessage : '';
        ['savebtn','approvebtn'].forEach(id => $(id).classList.remove('local-aisgk-hidden'));
    }
    function setGeneratingBusy(isBusy) {
        generatingBusy = !!isBusy;
        const btn = $('startbtn');
        if (btn) {
            btn.disabled = !!isBusy;
            if (isBusy) {
                if (!btn.dataset.oldhtml) { btn.dataset.oldhtml = btn.innerHTML; }
                btn.textContent = 'Đang tạo...';
                btn.title = 'Đang tạo, vui lòng chờ tiến trình hoàn tất.';
            } else {
                btn.innerHTML = btn.dataset.oldhtml || 'Tạo mới (<span id="apiremaining">*</span>)';
                btn.dataset.oldhtml = '';
                ensureApiRemainingSpan();
                updateStartButtonState();
            }
        }
    }
    async function poll() {
        const json = await api('status', {jobid: currentJobId});
        const job = json.job || {};
        setBar(parseInt(job.progress || 0, 10));
        setMsg(job.message || job.steptext || '');
        if (json.userusage) { setApiUsage(json.userusage); }
        if (json.result && json.result.usage) {
            setAiMeta(json.result.usage);
        }
        applyHomework(json.homework || null);
        if (job.status === 'done' || job.status === 'failed') { clearInterval(timer); timer = null; setGeneratingBusy(false); if (json.homework && json.homework.id) { await loadDrafts(json.homework.id); } }
    }
    document.querySelectorAll('.local-aisgk-helpbtn').forEach(btn => btn.addEventListener('click', function() {
        $('qtypehelptitle').textContent = this.dataset.title || 'Thông tin loại câu hỏi';
        $('qtypehelptext').textContent = this.dataset.help || '';
        $('qtypehelpbox').classList.remove('local-aisgk-hidden');
    }));
    $('qtypehelpclose').addEventListener('click', function() { $('qtypehelpbox').classList.add('local-aisgk-hidden'); });

    $('local-aisgk-json').addEventListener('input', scheduleLiveValidate);
    $('draftselect').addEventListener('change', async function() {
        if (!this.value) { return; }
        try { const json = await api('loaddraft', {homeworkid: this.value}); applyHomework(json.homework); setMsg('Đã load bản nháp.'); } catch (e) { setMsg(e.message || String(e)); }
    });
    loadDrafts();
    refreshApiUsage();
    $('startbtn').addEventListener('click', async function() {
        if (generatingBusy) { return; }
        try {
            const ratios = updateRatios();
            if (!ratios.valid) { setMsg('Tổng loại câu hỏi phải bằng tổng câu.'); return; }
            setAiMeta(null);
            renderReport(null);
            $('local-aisgk-json').value = '';
            $('previeweditor').innerHTML = '';
            setMsg('Đang đưa vào hàng đợi...');
            setGeneratingBusy(true);
            const json = await api('start', {
                sectionid: cfg.sectionid,
                topicname: cfg.topicname,
                bookid: cfg.bookid,
                pagefrom: cfg.pagefrom,
                pageto: cfg.pageto,
                scheduledtime: $('scheduledtime').value,
                options: collectOptions()
            });
            if (json.userusage) { setApiUsage(json.userusage); }
            currentJobId = parseInt(json.jobid, 10);
            setBar(5);
            if (timer) { clearInterval(timer); }
            timer = setInterval(poll, 1500);
            poll();
        } catch (e) { setGeneratingBusy(false); setMsg(e.message || String(e)); }
    });

    function renderMergeDraftList() {
        const box = $('mergedraftslist');
        const okdrafts = (lastDrafts || []).filter(d => !(d.errormsg || '').trim());
        if (!okdrafts.length) { box.innerHTML = '<div class="local-aisgk-muted">Chưa có bản nháp đạt để gộp.</div>'; return; }
        box.innerHTML = okdrafts.map(d => {
            const checked = currentHomeworkId && parseInt(d.id, 10) === currentHomeworkId ? ' checked' : '';
            return '<label><input type="checkbox" class="mergedraftcheck" value="' + htmlEscape(String(d.id)) + '"' + checked + '> <span>Nháp #' + htmlEscape(String(d.id)) + ' · ' + htmlEscape(d.topicname || '') + ' · ' + htmlEscape(d.status || '') + '</span></label>';
        }).join('');
    }
    $('mergedraftsbtn').addEventListener('click', function() { renderMergeDraftList(); $('mergedraftsbox').classList.remove('local-aisgk-hidden'); });
    $('mergedraftscancel').addEventListener('click', function() { $('mergedraftsbox').classList.add('local-aisgk-hidden'); });
    $('mergedraftsconfirm').addEventListener('click', async function() {
        const ids = Array.from(document.querySelectorAll('.mergedraftcheck:checked')).map(cb => cb.value);
        if (ids.length < 2) { setMsg('Cần chọn ít nhất 2 bản nháp đã đạt để gộp.'); return; }
        try {
            this.disabled = true;
            setMsg('Đang gộp và validate lại các nháp đã chọn...');
            const json = await api('mergedrafts', {sectionid: cfg.sectionid, ids: ids});
            $('mergedraftsbox').classList.add('local-aisgk-hidden');
            applyHomework(json.homework);
            renderReport(json.report || null);
            await loadDrafts(json.homeworkid);
            setMsg('Đã gộp nháp thành công. Đã xóa ' + (json.deleted || 0) + ' nháp lẻ.');
        } catch (e) { setMsg(e.message || String(e)); }
        finally { this.disabled = false; }
    });

    $('savebtn').addEventListener('click', async function() {
        if (!currentHomeworkId) return;
        try {
            $('teacheredited').value = $('previeweditor').innerHTML;
            await api('save', {homeworkid: currentHomeworkId, teacheredited: $('teacheredited').value, scheduledtime: $('scheduledtime').value, options: collectOptions(), json: $('local-aisgk-json').value});
            scheduleLiveValidate();
            await loadDrafts(currentHomeworkId);
            setMsg('Đã lưu DB.');
        } catch (e) { setMsg(e.message || String(e)); }
    });
    $('approvebtn').addEventListener('click', async function() {
        if (!currentHomeworkId || this.disabled) { return; }
        try {
            this.disabled = true;
            setMsg('Đang validate lần cuối và tạo BTVN trong Moodle...');
            $('teacheredited').value = $('previeweditor').innerHTML;
            const v = await api('validatejson', {json: $('local-aisgk-json').value, options: collectOptions(), homeworkid: currentHomeworkId});
            renderReport(v.report);
            if (!v.report || !v.report.ok) { setMsg('Chưa duyệt: JSON chưa validate đạt.'); return; }
            await api('save', {homeworkid: currentHomeworkId, teacheredited: $('teacheredited').value, scheduledtime: $('scheduledtime').value, options: collectOptions(), json: $('local-aisgk-json').value});
            const out = await api('approve', {homeworkid: currentHomeworkId});
            await loadDrafts(currentHomeworkId);
            setMsg(out.message || 'Đã duyệt và tạo BTVN trong Moodle.');
        } catch (e) { setMsg(e.message || String(e)); }
        finally { updateApproveButton(); }
    });
    $('fixerrorsbtn').addEventListener('click', async function() {
        try {
            const raw = $('local-aisgk-json').value.trim();
            if (!raw) { setMsg('Chưa có JSON để sửa lỗi.'); return; }
            this.disabled = true;
            setMsg('Đang gửi các câu hỏi lỗi và mô tả lỗi tới AI để sửa...');
            const json = await api('fixerrors', {homeworkid: currentHomeworkId, json: raw, options: collectOptions(), report: lastValidationReport || {}});
            if (json.normalizedjson) {
                $('local-aisgk-json').value = json.normalizedjson;
                $('sourcetext').value = json.normalizedjson;
                renderJsonPreviewFromTextarea();
            }
            renderReport(json.report);
            if (json.previewjson) {
                const previewQuestions = parseQuestionsPayload(json.previewjson);
                const rendered = renderQuestionsPreview(previewQuestions);
                if (rendered) { $('previeweditor').innerHTML = rendered; renderMathInPreview(); }
            }
            if (json.usage) { setAiMeta(json.usage); }
            await loadDrafts(currentHomeworkId);
            setMsg(json.message || (json.report && json.report.ok ? 'Đã sửa lỗi và validate đạt.' : 'Đã sửa lỗi, nhưng vẫn còn lỗi cần xem lại.'));
        } catch (e) { setMsg(e.message || String(e)); }
        finally { updateFixErrorsButton(); }
    });

    $('mergedraftsdeletebad').addEventListener('click', async function() {
        if (!confirm('Chỉ xóa các bản nháp không đạt của topic hiện tại?')) { return; }
        try {
            this.disabled = true;
            const json = await api('deletebad', {sectionid: cfg.sectionid, topicname: cfg.topicname});
            currentHomeworkId = 0;
            $('local-aisgk-json').value = '';
            $('sourcetext').value = '';
            $('previeweditor').innerHTML = '';
            renderReport(null);
            await loadDrafts();
            renderMergeDraftList();
            setMsg('Đã xóa ' + (json.deleted || 0) + ' bản nháp không đạt của topic hiện tại.');
        } catch (e) { setMsg(e.message || String(e)); }
        finally { this.disabled = false; }
    });
    $('mergedraftsdeleteselected').addEventListener('click', async function() {
        const hid = parseInt($('draftselect').value || currentHomeworkId || '0', 10);
        if (!hid) { setMsg('Chưa chọn bản nháp để xóa.'); return; }
        if (!confirm('Xóa bản nháp #' + hid + ' của topic hiện tại?')) { return; }
        try {
            this.disabled = true;
            const json = await api('deletedraft', {sectionid: cfg.sectionid, topicname: cfg.topicname, homeworkid: hid});
            if (parseInt(currentHomeworkId || 0, 10) === hid) {
                currentHomeworkId = 0;
                $('local-aisgk-json').value = '';
                $('sourcetext').value = '';
                $('previeweditor').innerHTML = '';
                renderReport(null);
            }
            await loadDrafts();
            renderMergeDraftList();
            setMsg('Đã xóa ' + (json.deleted || 0) + ' bản nháp đang chọn.');
        } catch (e) { setMsg(e.message || String(e)); }
        finally { this.disabled = false; }
    });
    $('pastejsonbtn').addEventListener('click', async function() {
        try {
            let text = '';
            if (navigator.clipboard && navigator.clipboard.readText) { text = await navigator.clipboard.readText(); }
            if (!text) { text = $('local-aisgk-json').value; }
            await processPastedJson(text);
        } catch (e) { setMsg(e.message || String(e)); }
    });
    $('copytemplatebtn').addEventListener('click', async function() {
        try {
            const ratios = updateRatios();
            if (!ratios.valid) { setMsg('Tổng loại câu hỏi phải bằng tổng câu trước khi tải mẫu.'); return; }
            setMsg('Đang tạo file mẫu prompt + ảnh SGK...');
            const json = await api('copytemplate', {
                sectionid: cfg.sectionid,
                topicname: cfg.topicname,
                bookid: cfg.bookid,
                pagefrom: cfg.pagefrom,
                pageto: cfg.pageto,
                options: collectOptions()
            });
            const text = json.copytext || '';
            const blob = new Blob([text], {type:'text/plain;charset=utf-8'});
            const a = document.createElement('a');
            a.href = URL.createObjectURL(blob);
            a.download = json.filename || 'aisgk-mau-prompt.txt';
            document.body.appendChild(a);
            a.click();
            setTimeout(() => { URL.revokeObjectURL(a.href); a.remove(); }, 1000);
            setMsg('Đã tải file mẫu prompt + liên kết ảnh SGK.');
        } catch (e) { setMsg(e.message || String(e)); }
    });

    $('wipebtn').addEventListener('click', async function() {
        if (!confirm('CẢNH BÁO: Xóa sạch bản nháp, DB plugin và Ngân hàng câu hỏi Moodle của khóa học/topic hiện tại?')) { return; }
        if (!confirm('Xác nhận lần 2: thao tác này không hoàn tác. Tiếp tục xóa sạch?')) { return; }
        try {
            const json = await api('wipe', {sectionid: cfg.sectionid, topicname: cfg.topicname});
            currentHomeworkId = 0;
            $('local-aisgk-json').value = '';
            $('sourcetext').value = '';
            $('previeweditor').innerHTML = '';
            renderReport(null);
            await loadDrafts();
            setMsg('Đã xóa sạch: ' + (json.homeworks || 0) + ' bản ghi plugin, ' + (json.questions || 0) + ' câu hỏi Moodle.');
        } catch (e) { setMsg(e.message || String(e)); }
    });
})();
</script>
<?php echo $OUTPUT->footer();
