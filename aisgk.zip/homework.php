<?php
require('../../config.php');

use local_aisgk\book_repository;
use local_aisgk\local\service\homework_service;

$courseid = required_param('id', PARAM_INT);
$sectionid = optional_param('sectionid', 0, PARAM_INT);
$topicname = optional_param('topicname', '', PARAM_TEXT);

$course = get_course($courseid);
require_login($course);

$context = context_course::instance($courseid);
require_capability('local/aisgk:createhomework', $context);

$PAGE->set_context($context);
$PAGE->set_url('/local/aisgk/homework.php', ['id' => $courseid, 'sectionid' => $sectionid, 'topicname' => $topicname]);
$PAGE->set_pagelayout('embedded');
$PAGE->set_title('Automatic delivery' . ($topicname !== '' ? ': ' . $topicname : ''));

if (!book_repository::course_has_book($courseid)) {
    throw new moodle_exception('bookrequired', 'local_aisgk');
}

$section = null;
if ($sectionid) {
    $modinfo = get_fast_modinfo($course);
    $section = $modinfo->get_section_info_by_id($sectionid);
}
$sectionlabel = $section && !empty($section->name) ? format_string($section->name) : '';
$prefill = $sectionid ? homework_service::find_section_match($courseid, $sectionid) : null;
if (!$prefill && $topicname !== '') {
    $prefill = homework_service::find_topic_match($courseid, $topicname);
}
$bookid = $prefill ? (int)$prefill['book']->id : (int)(book_repository::get_by_courseid($courseid)->id ?? 0);
$bookname = $prefill ? (string)($prefill['book']->name ?: $prefill['book']->filename) : '';
$pagefrom = $prefill ? (int)($prefill['toc']->trang ?? 1) : 1;
$pageto = $prefill ? (int)($prefill['toc']->endtrang ?? $pagefrom) : max(1, $pagefrom);
$scheduled = userdate(time() > strtotime(date('Y-m-d 17:00:00')) ? strtotime('tomorrow 17:00') : strtotime('today 17:00'), '%Y-%m-%dT%H:%M');
$usemyapi = (bool)get_user_preferences('local_aisgk_use_my_api', 0, $USER->id);

$questiontypes = [
    'multichoice' => 'Multiple choice',
    'truefalse' => 'True/False',
    'shortanswer' => 'Short answer',
    'numerical' => 'Numerical',
    'matching' => 'Matching',
    'essay' => 'Essay',
    'gapselect' => 'Gap select',
    'ddwtos' => 'Drag/drop into text',
    'calculated' => 'Calculated',
];

function local_aisgk_count_options(int $max = 30, int $selected = 0): string {
    $html = '';
    for ($i = 0; $i <= $max; $i++) {
        $html .= '<option value="' . $i . '"' . ($i === $selected ? ' selected' : '') . '>' . $i . '</option>';
    }
    return $html;
}

echo $OUTPUT->header();
?>
<style>
.local-aisgk-homework-wrap{padding:14px;font-size:13px;width:100%;max-width:100%;box-sizing:border-box;background:#fff}
.local-aisgk-card{border:1px solid #d7deea;border-radius:12px;background:#fff;padding:14px}
.local-aisgk-card h3{margin:0 0 12px;font-size:22px;font-weight:700}
.local-aisgk-grid{display:grid;grid-template-columns:1fr 1fr;gap:12px;margin-top:12px}
.local-aisgk-box{border:1px solid #e5e7eb;border-radius:10px;padding:12px;background:#f8fafc}
.local-aisgk-box.long{grid-column:1 / -1}
.local-aisgk-box strong{display:block;margin-bottom:8px;font-size:14px}
.local-aisgk-info{display:grid;grid-template-columns:130px 1fr;gap:6px 10px;color:#334155}
.local-aisgk-muted{color:#64748b}
.local-aisgk-form input,.local-aisgk-form select,.local-aisgk-form textarea{width:100%;box-sizing:border-box;border:1px solid #cbd5e1;border-radius:8px;padding:8px 10px;background:#fff}
.local-aisgk-row{display:grid;grid-template-columns:1fr 110px 90px;gap:8px;align-items:center;margin:6px 0}
.local-aisgk-row label{font-weight:600;margin:0}
.local-aisgk-percent{text-align:right;color:#475467;font-weight:600}
.local-aisgk-actions{display:flex;gap:8px;flex-wrap:wrap;margin-top:12px;align-items:center}
.local-aisgk-progress{margin:10px 0 12px}.local-aisgk-bar{height:12px;background:#e5e7eb;border-radius:999px;overflow:hidden}.local-aisgk-fill{height:100%;width:0;background:#2563eb;transition:width .25s ease}
.local-aisgk-msg{margin-top:8px;color:#334155}.local-aisgk-note{margin-top:12px;color:#475467}
.local-aisgk-hidden{display:none}.local-aisgk-editor{min-height:280px;border:1px solid #cbd5e1;border-radius:10px;background:#fff;padding:12px;overflow:auto;line-height:1.55}.local-aisgk-form textarea{min-height:220px;resize:vertical}
.local-aisgk-totalwarn{color:#b91c1c;font-weight:600;margin-top:6px}.local-aisgk-ok{color:#166534;font-weight:600;margin-top:6px}
@media (max-width:992px){.local-aisgk-homework-wrap{padding:10px}.local-aisgk-card{padding:10px}.local-aisgk-grid{grid-template-columns:1fr}.local-aisgk-box.long{grid-column:auto}.local-aisgk-row{grid-template-columns:1fr 90px 70px}.local-aisgk-info{grid-template-columns:1fr}.local-aisgk-card h3{font-size:18px}}
</style>
<div class="local-aisgk-homework-wrap">
    <div class="local-aisgk-card local-aisgk-form">
        <h3>Automatic delivery</h3>

        <div class="local-aisgk-grid">
            <div class="local-aisgk-box" id="box-source">
                <strong>SGK / Trang / API</strong>
                <div class="local-aisgk-info">
                    <div>Section</div><div><?php echo $sectionlabel !== '' ? $sectionlabel : '-'; ?> <?php echo $topicname !== '' ? '· ' . s($topicname) : ''; ?></div>
                    <div>SGK</div><div><?php echo s($bookname !== '' ? $bookname : ('Book #' . $bookid)); ?></div>
                    <div>Trang</div><div><?php echo (int)$pagefrom; ?> → <?php echo (int)$pageto; ?></div>
                    <div>Model</div><div id="modelinfo">Sẽ chọn theo key khả dụng</div>
                    <div>Token ước tính</div><div id="tokeninfo">Sẽ tính trước khi gọi API</div>
                    <div>API</div><div id="apisource"><?php echo $usemyapi ? 'API cá nhân nếu khả dụng' : 'API hệ thống'; ?></div>
                </div>
                <div class="local-aisgk-muted" style="margin-top:8px"><?php echo $prefill ? s((string)$prefill['toc']->tenbai) : 'Chưa tìm thấy mapping section → mục lục.'; ?></div>
            </div>

            <div class="local-aisgk-box">
                <strong>Scheduled delivery</strong>
                <label for="scheduledtime">Thời điểm giao bài</label>
                <input id="scheduledtime" type="datetime-local" value="<?php echo s($scheduled); ?>">
                <div class="local-aisgk-muted" style="margin-top:8px">Có thể tạo ngay bản nháp, sau đó Save/Approve để giao theo lịch.</div>
            </div>

            <div class="local-aisgk-box long" id="cognitivebox">
                <strong>Mức độ nhận thức</strong>
                <div class="local-aisgk-row"><label>Nhận biết</label><select class="cognitive" data-key="recognize"><?php echo local_aisgk_count_options(30, 4); ?></select><div class="local-aisgk-percent" data-percent="recognize">40%</div></div>
                <div class="local-aisgk-row"><label>Thông hiểu</label><select class="cognitive" data-key="understand"><?php echo local_aisgk_count_options(30, 4); ?></select><div class="local-aisgk-percent" data-percent="understand">40%</div></div>
                <div class="local-aisgk-row"><label>Vận dụng</label><select class="cognitive" data-key="apply"><?php echo local_aisgk_count_options(30, 2); ?></select><div class="local-aisgk-percent" data-percent="apply">20%</div></div>
                <div class="local-aisgk-row"><label>Tổng câu</label><input id="totalquestions" type="number" min="1" max="60" value="10" readonly><div class="local-aisgk-percent" id="totalcognitivepercent">100%</div></div>
            </div>

            <div class="local-aisgk-box long" id="questiontypebox">
                <strong>Loại câu hỏi Moodle Quiz</strong>
                <?php $defaults = ['multichoice' => 4, 'truefalse' => 2, 'shortanswer' => 2, 'numerical' => 1, 'essay' => 1]; ?>
                <?php foreach ($questiontypes as $type => $label): ?>
                    <div class="local-aisgk-row"><label><?php echo s($label); ?></label><select class="qtype" data-type="<?php echo s($type); ?>"><?php echo local_aisgk_count_options(30, (int)($defaults[$type] ?? 0)); ?></select><div class="local-aisgk-percent" data-qpercent="<?php echo s($type); ?>">0%</div></div>
                <?php endforeach; ?>
                <div id="qtypecheck" class="local-aisgk-ok">Tổng loại câu hỏi hợp lệ.</div>
            </div>
        </div>

        <div class="local-aisgk-actions">
            <button class="btn btn-primary" id="startbtn">Tạo ngay</button>
            <button class="btn btn-secondary local-aisgk-hidden" id="savebtn"><?php echo s(get_string('savechanges', 'local_aisgk')); ?></button>
            <button class="btn btn-success local-aisgk-hidden" id="approvebtn"><?php echo s(get_string('approvehomework', 'local_aisgk')); ?></button>
            <button class="btn btn-danger local-aisgk-hidden" id="cancelbtn"><?php echo s(get_string('cancelhomeworkdraft', 'local_aisgk')); ?></button>
        </div>

        <div class="local-aisgk-progress">
            <div class="local-aisgk-bar"><div class="local-aisgk-fill" id="barfill"></div></div>
            <div class="local-aisgk-msg" id="jobmsg"><?php echo s(get_string('jobready', 'local_aisgk')); ?></div>
        </div>

        <div class="local-aisgk-grid">
            <div class="local-aisgk-box long">
                <strong>Scanned lesson text</strong>
                <textarea id="sourcetext" readonly></textarea>
            </div>
            <div class="local-aisgk-box long">
                <strong>Draft questions / delivery content</strong>
                <div id="previeweditor" class="local-aisgk-editor" contenteditable="true"></div>
                <textarea id="teacheredited" class="local-aisgk-hidden"></textarea>
                <div class="local-aisgk-muted" style="margin-top:6px">Khung này render HTML/công thức cơ bản để xem thử và chỉnh sửa trước khi lưu.</div>
            </div>
        </div>
        <div class="local-aisgk-note" id="resultnote"></div>
    </div>
</div>
<script>
(function() {
    const cfg = {
        courseid: <?php echo (int)$courseid; ?>,
        sectionid: <?php echo (int)$sectionid; ?>,
        topicname: <?php echo json_encode($topicname); ?>,
        bookid: <?php echo (int)$bookid; ?>,
        pagefrom: <?php echo (int)$pagefrom; ?>,
        pageto: <?php echo (int)$pageto; ?>,
        sesskey: <?php echo json_encode(sesskey()); ?>,
        ajaxurl: <?php echo json_encode((new moodle_url('/local/aisgk/homework_ajax.php'))->out(false)); ?>
    };
    let currentJobId = 0;
    let currentHomeworkId = 0;
    let timer = null;

    const $ = (id) => document.getElementById(id);
    function setMsg(msg) { $('jobmsg').textContent = msg || ''; }
    function setBar(v) { $('barfill').style.width = Math.max(0, Math.min(100, v || 0)) + '%'; }
    function htmlEscape(s) { return String(s || '').replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;'); }
    function textToHtml(s) { return htmlEscape(s).replace(/\n\n+/g, '</p><p>').replace(/\n/g, '<br>'); }

    function sumSelects(selector) {
        return Array.from(document.querySelectorAll(selector)).reduce((sum, el) => sum + (parseInt(el.value || '0', 10) || 0), 0);
    }
    function updateRatios() {
        const total = sumSelects('.cognitive');
        $('totalquestions').value = total;
        document.querySelectorAll('.cognitive').forEach(el => {
            const key = el.dataset.key;
            const pct = total ? Math.round(((parseInt(el.value || '0', 10) || 0) / total) * 100) : 0;
            document.querySelector('[data-percent="' + key + '"]').textContent = pct + '%';
        });
        const qtotal = sumSelects('.qtype');
        document.querySelectorAll('.qtype').forEach(el => {
            const type = el.dataset.type;
            const pct = total ? Math.round(((parseInt(el.value || '0', 10) || 0) / total) * 100) : 0;
            document.querySelector('[data-qpercent="' + type + '"]').textContent = pct + '%';
        });
        const msg = $('qtypecheck');
        if (qtotal > total) {
            msg.className = 'local-aisgk-totalwarn';
            msg.textContent = 'Tổng loại câu hỏi (' + qtotal + ') vượt tổng câu (' + total + ').';
        } else if (qtotal < total) {
            msg.className = 'local-aisgk-totalwarn';
            msg.textContent = 'Tổng loại câu hỏi còn thiếu ' + (total - qtotal) + ' câu.';
        } else {
            msg.className = 'local-aisgk-ok';
            msg.textContent = 'Tổng loại câu hỏi hợp lệ.';
        }
        return {total: total, qtotal: qtotal, valid: qtotal === total};
    }
    document.querySelectorAll('.cognitive,.qtype').forEach(el => el.addEventListener('change', updateRatios));
    updateRatios();

    function collectOptions() {
        const ratios = updateRatios();
        const cognitive = {};
        document.querySelectorAll('.cognitive').forEach(el => cognitive[el.dataset.key] = parseInt(el.value || '0', 10) || 0);
        const qtypes = {};
        document.querySelectorAll('.qtype').forEach(el => qtypes[el.dataset.type] = parseInt(el.value || '0', 10) || 0);
        return {total: ratios.total, cognitive: cognitive, qtypes: qtypes};
    }

    async function api(action, data) {
        const fd = new URLSearchParams();
        fd.set('action', action);
        fd.set('courseid', cfg.courseid);
        fd.set('sesskey', cfg.sesskey);
        Object.keys(data || {}).forEach((k) => fd.set(k, typeof data[k] === 'object' ? JSON.stringify(data[k]) : data[k]));
        const res = await fetch(cfg.ajaxurl, {method:'POST',headers:{'Content-Type':'application/x-www-form-urlencoded; charset=UTF-8'},body:fd.toString()});
        const json = await res.json();
        if (!res.ok || !json.ok) { throw new Error((json && json.error) ? json.error : 'Request failed'); }
        return json;
    }
    function applyHomework(hw) {
        if (!hw) { return; }
        currentHomeworkId = parseInt(hw.id || 0, 10);
        $('sourcetext').value = hw.sourcetext || '';
        const content = hw.teacheredited || '';
        $('teacheredited').value = content;
        $('previeweditor').innerHTML = '<p>' + textToHtml(content) + '</p>';
        $('resultnote').textContent = hw.deliverymessage ? 'Delivery: ' + hw.deliverymessage : '';
        ['savebtn','approvebtn','cancelbtn'].forEach(id => $(id).classList.remove('local-aisgk-hidden'));
    }
    async function poll() {
        const json = await api('status', {jobid: currentJobId});
        const job = json.job || {};
        setBar(parseInt(job.progress || 0, 10));
        setMsg(job.message || job.steptext || '');
        if (json.result && json.result.usage) {
            $('modelinfo').textContent = json.result.usage.model || $('modelinfo').textContent;
            $('tokeninfo').textContent = json.result.usage.tokens || $('tokeninfo').textContent;
        }
        applyHomework(json.homework || null);
        if (job.status === 'done' || job.status === 'failed') { clearInterval(timer); timer = null; }
    }
    $('startbtn').addEventListener('click', async function() {
        try {
            const ratios = updateRatios();
            if (!ratios.valid) { setMsg('Tổng loại câu hỏi phải bằng tổng câu.'); return; }
            setMsg('Đang đưa vào hàng đợi...');
            const json = await api('start', {
                sectionid: cfg.sectionid,
                topicname: cfg.topicname,
                bookid: cfg.bookid,
                pagefrom: cfg.pagefrom,
                pageto: cfg.pageto,
                scheduledtime: $('scheduledtime').value,
                options: collectOptions()
            });
            currentJobId = parseInt(json.jobid, 10);
            setBar(5);
            if (timer) { clearInterval(timer); }
            timer = setInterval(poll, 1500);
            poll();
        } catch (e) { setMsg(e.message || String(e)); }
    });
    $('savebtn').addEventListener('click', async function() {
        if (!currentHomeworkId) return;
        try {
            $('teacheredited').value = $('previeweditor').innerHTML;
            await api('save', {homeworkid: currentHomeworkId, teacheredited: $('teacheredited').value, scheduledtime: $('scheduledtime').value});
            setMsg('<?php echo s(get_string('homeworksaved', 'local_aisgk')); ?>');
        } catch (e) { setMsg(e.message || String(e)); }
    });
    $('approvebtn').addEventListener('click', async function() {
        if (!currentHomeworkId) return;
        try { await api('approve', {homeworkid: currentHomeworkId}); setMsg('<?php echo s(get_string('homeworkapproved', 'local_aisgk')); ?>'); } catch (e) { setMsg(e.message || String(e)); }
    });
    $('cancelbtn').addEventListener('click', async function() {
        if (!currentHomeworkId) return;
        try { await api('cancel', {homeworkid: currentHomeworkId}); setMsg('<?php echo s(get_string('homeworkcancelled', 'local_aisgk')); ?>'); } catch (e) { setMsg(e.message || String(e)); }
    });
})();
</script>
<?php echo $OUTPUT->footer();
