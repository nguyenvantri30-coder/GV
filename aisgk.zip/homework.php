<?php
require('../../config.php');

use local_aisgk\book_repository;

$courseid = required_param('id', PARAM_INT);
$sectionid = optional_param('sectionid', 0, PARAM_INT);

$course = get_course($courseid);
require_login($course);

$context = context_course::instance($courseid);
require_capability('local/aisgk:createhomework', $context);

$PAGE->set_context($context);
$PAGE->set_url('/local/aisgk/homework.php', ['id' => $courseid, 'sectionid' => $sectionid]);
$PAGE->set_pagelayout('embedded');
$PAGE->set_title(get_string('createhomework', 'local_aisgk'));

if (!book_repository::course_has_book($courseid)) {
    throw new moodle_exception('bookrequired', 'local_aisgk');
}

$section = null;
if (!empty($sectionid)) {
    $modinfo = get_fast_modinfo($course);
    $sectioninfo = $modinfo->get_section_info_by_id($sectionid);
    if (!$sectioninfo) {
        throw new moodle_exception('sectionnotfound', 'local_aisgk');
    }
    $section = $sectioninfo;
}

echo $OUTPUT->header();

echo html_writer::start_div('local-aisgk-modal-page');
echo html_writer::tag('h4', get_string('createhomeworkforsection', 'local_aisgk'));

if ($section) {
    $label = !empty($section->name) ? format_string($section->name) : (string)$section->section;
    echo html_writer::tag('p', '<strong>' . get_string('section', 'local_aisgk') . ':</strong> ' . $label);
}

echo html_writer::tag('p', get_string('homeworkstubdesc', 'local_aisgk'));
echo html_writer::tag('p', 'courseid = ' . (int)$courseid);
echo html_writer::tag('p', 'sectionid = ' . (int)$sectionid);
echo html_writer::end_div();

echo $OUTPUT->footer();
