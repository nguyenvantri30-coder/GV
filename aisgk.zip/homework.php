<?php
require('../../config.php');

use local_aisgk\book_repository;
use local_aisgk\local\service\homework_service;

$courseid = required_param('id', PARAM_INT);
$sectionid = optional_param('sectionid', 0, PARAM_INT);
$topicname = optional_param('topicname', '', PARAM_TEXT);

$course = get_course($courseid);
require_login($course);

$context = context_course::instance($courseid);
require_capability('local/aisgk:createhomework', $context);

$PAGE->set_context($context);
$PAGE->set_url('/local/aisgk/homework.php', ['id' => $courseid, 'sectionid' => $sectionid, 'topicname' => $topicname]);
$PAGE->set_pagelayout('embedded');
$PAGE->set_title(get_string('createhomework', 'local_aisgk') . ($topicname !== '' ? ': ' . $topicname : ''));

if (!book_repository::course_has_book($courseid)) {
    throw new moodle_exception('bookrequired', 'local_aisgk');
}

$section = null;
if ($sectionid) {
    $modinfo = get_fast_modinfo($course);
    $section = $modinfo->get_section_info_by_id($sectionid);
}
$sectionlabel = $section && !empty($section->name) ? format_string($section->name) : '';
$prefill = $topicname !== '' ? homework_service::find_topic_match($courseid, $topicname) : null;
$bookid = $prefill ? (int)$prefill['book']->id : (int)(book_repository::get_by_courseid($courseid)->id ?? 0);
$pagefrom = $prefill ? (int)($prefill['toc']->trang ?? 1) : 1;
$pageto = $prefill ? (int)($prefill['toc']->endtrang ?? $pagefrom) : max(1, $pagefrom);
$scheduled = userdate(time() > strtotime(date('Y-m-d 17:00:00')) ? strtotime('tomorrow 17:00') : strtotime('today 17:00'), '%Y-%m-%dT%H:%M');

$books = book_repository::get_all_by_courseid($courseid);

echo $OUTPUT->header();
?>
<style>
.local-aisgk-homework-wrap{padding:14px;font-size:13px;width:100%;max-width:100%;box-sizing:border-box}
.local-aisgk-card{border:1px solid #d7deea;border-radius:12px;background:#fff;padding:14px}
.local-aisgk-card h3{margin:0 0 12px;font-size:22px}
.local-aisgk-grid{display:grid;grid-template-columns:1fr 1fr;gap:12px}
.local-aisgk-box{border:1px solid #e5e7eb;border-radius:8px;padding:12px;background:#f8fafc}
.local-aisgk-box strong{display:block;margin-bottom:6px}
.local-aisgk-form label{display:block;font-weight:600;margin:0 0 6px}
.local-aisgk-form input,.local-aisgk-form select,.local-aisgk-form textarea{width:100%;box-sizing:border-box;border:1px solid #cbd5e1;border-radius:8px;padding:8px 10px}
.local-aisgk-form textarea{min-height:220px;resize:vertical}
.local-aisgk-actions{display:flex;gap:8px;flex-wrap:wrap;margin-top:12px}
.local-aisgk-stepper{display:grid;grid-template-columns:repeat(4,minmax(0,1fr));gap:8px;margin:14px 0}
.local-aisgk-step{border:1px solid #d0d7de;border-radius:10px;padding:10px 8px;text-align:center;background:#f6f8fa;color:#57606a;font-weight:600}
.local-aisgk-step.active{background:#e7f1ff;border-color:#54aeff;color:#0969da}
.local-aisgk-step.done{background:#e8f5e9;border-color:#4caf50;color:#2e7d32}
.local-aisgk-step.error{background:#fdecea;border-color:#e53935;color:#b71c1c}
.local-aisgk-progress{margin:10px 0 12px}.local-aisgk-bar{height:10px;background:#e5e7eb;border-radius:999px;overflow:hidden}.local-aisgk-fill{height:100%;width:0;background:#2563eb;transition:width .25s ease}
.local-aisgk-msg{margin-top:8px;color:#334155}.local-aisgk-note{margin-top:12px;color:#475467}
.local-aisgk-hidden{display:none}
@media (max-width:992px){.local-aisgk-homework-wrap{padding:10px}.local-aisgk-card{padding:10px}.local-aisgk-grid{grid-template-columns:1fr}.local-aisgk-stepper{grid-template-columns:1fr 1fr}.local-aisgk-card h3{font-size:18px}}
</style>
<div class="local-aisgk-homework-wrap">
    <div class="local-aisgk-card">
        <h3><?php echo s(get_string('createhomework', 'local_aisgk')); ?></h3>
        <div class="local-aisgk-grid">
            <div class="local-aisgk-box">
                <strong><?php echo s(get_string('section', 'local_aisgk')); ?></strong>
                <div><?php echo $sectionlabel !== '' ? $sectionlabel : '-'; ?></div>
                <div style="margin-top:6px;color:#64748b"><?php echo s($topicname); ?></div>
            </div>
            <div class="local-aisgk-box">
                <strong><?php echo s(get_string('homeworkautodelivernote', 'local_aisgk')); ?></strong>
                <div><?php echo s(get_string('homeworkautodeliverdesc', 'local_aisgk')); ?></div>
            </div>
        </div>

        <div class="local-aisgk-grid local-aisgk-form" style="margin-top:12px">
            <div>
                <label for="bookid"><?php echo s(get_string('booklabel', 'local_aisgk')); ?></label>
                <select id="bookid">
                    <?php foreach ($books as $book): ?>
                        <option value="<?php echo (int)$book->id; ?>" <?php echo ((int)$book->id === $bookid ? 'selected' : ''); ?>><?php echo s($book->name); ?></option>
                    <?php endforeach; ?>
                </select>
            </div>
            <div>
                <label for="scheduledtime"><?php echo s(get_string('scheduledtime', 'local_aisgk')); ?></label>
                <input id="scheduledtime" type="datetime-local" value="<?php echo s($scheduled); ?>">
            </div>
            <div>
                <label for="pagefrom"><?php echo s(get_string('trangbatdau', 'local_aisgk')); ?></label>
                <input id="pagefrom" type="number" min="1" value="<?php echo (int)$pagefrom; ?>">
            </div>
            <div>
                <label for="pageto"><?php echo s(get_string('trangketthuc', 'local_aisgk')); ?></label>
                <input id="pageto" type="number" min="1" value="<?php echo (int)$pageto; ?>">
            </div>
        </div>

        <div class="local-aisgk-actions">
            <button class="btn btn-primary" id="startbtn"><?php echo s(get_string('starthomeworkdraft', 'local_aisgk')); ?></button>
            <button class="btn btn-secondary local-aisgk-hidden" id="savebtn"><?php echo s(get_string('savechanges', 'local_aisgk')); ?></button>
            <button class="btn btn-success local-aisgk-hidden" id="approvebtn"><?php echo s(get_string('approvehomework', 'local_aisgk')); ?></button>
            <button class="btn btn-danger local-aisgk-hidden" id="cancelbtn"><?php echo s(get_string('cancelhomeworkdraft', 'local_aisgk')); ?></button>
        </div>

        <div class="local-aisgk-stepper" id="stepper">
            <div class="local-aisgk-step active" data-step="1">① <?php echo s(get_string('stepstart', 'local_aisgk')); ?></div>
            <div class="local-aisgk-step" data-step="2">② <?php echo s(get_string('stepscanlesson', 'local_aisgk')); ?></div>
            <div class="local-aisgk-step" data-step="3">③ <?php echo s(get_string('stepcreatehomework', 'local_aisgk')); ?></div>
            <div class="local-aisgk-step" data-step="4">④ <?php echo s(get_string('stepresult', 'local_aisgk')); ?></div>
        </div>
        <div class="local-aisgk-progress">
            <div class="local-aisgk-bar"><div class="local-aisgk-fill" id="barfill"></div></div>
            <div class="local-aisgk-msg" id="jobmsg"><?php echo s(get_string('jobready', 'local_aisgk')); ?></div>
        </div>

        <div class="local-aisgk-grid local-aisgk-form">
            <div class="local-aisgk-box">
                <strong><?php echo s(get_string('sourcetextlabel', 'local_aisgk')); ?></strong>
                <textarea id="sourcetext" readonly></textarea>
            </div>
            <div class="local-aisgk-box">
                <strong><?php echo s(get_string('draftquestionslabel', 'local_aisgk')); ?></strong>
                <textarea id="teacheredited"></textarea>
            </div>
        </div>
        <div class="local-aisgk-note" id="resultnote"></div>
    </div>
</div>
<script>
(function() {
    const cfg = {
        courseid: <?php echo (int)$courseid; ?>,
        sectionid: <?php echo (int)$sectionid; ?>,
        topicname: <?php echo json_encode($topicname); ?>,
        sesskey: <?php echo json_encode(sesskey()); ?>,
        ajaxurl: <?php echo json_encode((new moodle_url('/local/aisgk/homework_ajax.php'))->out(false)); ?>
    };
    let currentJobId = 0;
    let currentHomeworkId = 0;
    let timer = null;

    const $ = (id) => document.getElementById(id);
    const steps = Array.from(document.querySelectorAll('.local-aisgk-step'));

    function setMsg(msg) { $('jobmsg').textContent = msg || ''; }
    function setBar(v) { $('barfill').style.width = Math.max(0, Math.min(100, v || 0)) + '%'; }
    function setSteps(stepno, failed) {
        steps.forEach((el) => {
            const n = parseInt(el.dataset.step, 10);
            el.classList.remove('active','done','error');
            if (failed && n === stepno) {
                el.classList.add('error');
            } else if (n < stepno) {
                el.classList.add('done');
            } else if (n === stepno) {
                el.classList.add('active');
            }
        });
    }
    async function api(action, data) {
        const fd = new URLSearchParams();
        fd.set('action', action);
        fd.set('courseid', cfg.courseid);
        fd.set('sesskey', cfg.sesskey);
        Object.keys(data || {}).forEach((k) => fd.set(k, data[k]));
        const res = await fetch(cfg.ajaxurl, {
            method: 'POST',
            headers: {'Content-Type': 'application/x-www-form-urlencoded; charset=UTF-8'},
            body: fd.toString()
        });
        const json = await res.json();
        if (!res.ok || !json.ok) {
            throw new Error((json && json.error) ? json.error : 'Request failed');
        }
        return json;
    }
    function applyHomework(hw) {
        if (!hw) { return; }
        currentHomeworkId = parseInt(hw.id || 0, 10);
        $('sourcetext').value = hw.sourcetext || '';
        $('teacheredited').value = hw.teacheredited || '';
        $('resultnote').textContent = hw.deliverymessage ? 'Delivery: ' + hw.deliverymessage : '';
        ['savebtn','approvebtn','cancelbtn'].forEach(id => $(id).classList.remove('local-aisgk-hidden'));
    }
    async function poll() {
        const json = await api('status', {jobid: currentJobId});
        const job = json.job;
        setSteps(parseInt(job.stepno || 1, 10), job.status === 'failed');
        setBar(parseInt(job.progress || 0, 10));
        setMsg(job.message || job.steptext || '');
        applyHomework(json.homework || null);
        if (job.status === 'done' || job.status === 'failed') {
            clearInterval(timer); timer = null;
        }
    }
    $('startbtn').addEventListener('click', async function() {
        try {
            setMsg('Đang khởi tạo tác vụ...');
            const json = await api('start', {
                sectionid: cfg.sectionid,
                topicname: cfg.topicname,
                bookid: $('bookid').value,
                pagefrom: $('pagefrom').value,
                pageto: $('pageto').value,
                scheduledtime: $('scheduledtime').value
            });
            currentJobId = parseInt(json.jobid, 10);
            setSteps(1, false); setBar(5);
            if (timer) { clearInterval(timer); }
            timer = setInterval(poll, 1500);
            poll();
        } catch (e) { setMsg(e.message || String(e)); }
    });
    $('savebtn').addEventListener('click', async function() {
        if (!currentHomeworkId) return;
        try {
            await api('save', {homeworkid: currentHomeworkId, teacheredited: $('teacheredited').value, scheduledtime: $('scheduledtime').value});
            setMsg('<?php echo s(get_string('homeworksaved', 'local_aisgk')); ?>');
        } catch (e) { setMsg(e.message || String(e)); }
    });
    $('approvebtn').addEventListener('click', async function() {
        if (!currentHomeworkId) return;
        try {
            await api('approve', {homeworkid: currentHomeworkId});
            setMsg('<?php echo s(get_string('homeworkapproved', 'local_aisgk')); ?>');
        } catch (e) { setMsg(e.message || String(e)); }
    });
    $('cancelbtn').addEventListener('click', async function() {
        if (!currentHomeworkId) return;
        try {
            await api('cancel', {homeworkid: currentHomeworkId});
            setMsg('<?php echo s(get_string('homeworkcancelled', 'local_aisgk')); ?>');
        } catch (e) { setMsg(e.message || String(e)); }
    });
})();
</script>
<?php echo $OUTPUT->footer();
