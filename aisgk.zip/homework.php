<?php
require('../../config.php');

use local_aisgk\book_repository;

$courseid = required_param('id', PARAM_INT);
$sectionid = optional_param('sectionid', 0, PARAM_INT);

$course = get_course($courseid);
require_login($course);

$context = context_course::instance($courseid);
require_capability('local/aisgk:createhomework', $context);

$PAGE->set_context($context);
$PAGE->set_url('/local/aisgk/homework.php', ['id' => $courseid, 'sectionid' => $sectionid]);
$PAGE->set_pagelayout('embedded');

$topicname = optional_param('topicname', '', PARAM_TEXT);
$PAGE->set_title(get_string('createhomework', 'local_aisgk') . ($topicname !== '' ? ': ' . $topicname : ''));

if (!book_repository::course_has_book($courseid)) {
    throw new moodle_exception('bookrequired', 'local_aisgk');
}

$section = null;
if (!empty($sectionid)) {
    $modinfo = get_fast_modinfo($course);
    $sectioninfo = $modinfo->get_section_info_by_id($sectionid);
    if (!$sectioninfo) {
        throw new moodle_exception('sectionnotfound', 'local_aisgk');
    }
    $section = $sectioninfo;
}

echo $OUTPUT->header();
$label = '';
if ($section) {
    $label = !empty($section->name) ? format_string($section->name) : (string)$section->section;
}
?>
<style>
.local-aisgk-homework-wrap {padding:14px; font-size:13px; width:100%; max-width:100%; box-sizing:border-box;}
.local-aisgk-homework-card {border:1px solid #d7deea; border-radius:10px; background:#fff; padding:14px;}
.local-aisgk-homework-card h3 {margin:0 0 12px; font-size:22px;}
.local-aisgk-homework-grid {display:grid; grid-template-columns:1fr 1fr; gap:12px;}
@media (max-width: 992px) { .local-aisgk-homework-wrap {padding:10px;} .local-aisgk-homework-card {padding:10px;} .local-aisgk-homework-grid {grid-template-columns:1fr;} .local-aisgk-homework-card h3 {font-size:18px;} }
.local-aisgk-homework-box {border:1px solid #e5e7eb; border-radius:8px; padding:12px; background:#f8fafc;}
.local-aisgk-homework-box strong {display:block; margin-bottom:6px;}
.local-aisgk-homework-note {margin-top:12px; color:#475467;}
</style>
<div class="local-aisgk-homework-wrap">
    <div class="local-aisgk-homework-card">
        <h3><?php echo s(get_string('createhomework', 'local_aisgk')); ?></h3>
        <div class="local-aisgk-homework-grid">
            <div class="local-aisgk-homework-box">
                <strong><?php echo s(get_string('section', 'local_aisgk')); ?></strong>
                <div><?php echo $label !== '' ? $label : '-'; ?></div>
            </div>
            <div class="local-aisgk-homework-box">
                <strong>Course / Section</strong>
                <div>courseid = <?php echo (int)$courseid; ?></div>
                <div>sectionid = <?php echo (int)$sectionid; ?></div>
            </div>
        </div>
        <div class="local-aisgk-homework-note"><?php echo s(get_string('homeworkstubdesc', 'local_aisgk')); ?></div>
    </div>
</div>
<?php
echo $OUTPUT->footer();
