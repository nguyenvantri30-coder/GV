<?php
require('../../config.php');
require_once($CFG->dirroot . '/question/engine/bank.php');

use local_aisgk\book_repository;
use local_aisgk\local\service\homework_service;

$courseid = required_param('id', PARAM_INT);
$sectionid = optional_param('sectionid', 0, PARAM_INT);
$topicname = optional_param('topicname', '', PARAM_TEXT);

$course = get_course($courseid);
require_login($course);

$context = context_course::instance($courseid);
require_capability('local/aisgk:createhomework', $context);

$PAGE->set_context($context);
$PAGE->set_url('/local/aisgk/homework.php', ['id' => $courseid, 'sectionid' => $sectionid, 'topicname' => $topicname]);
$PAGE->set_pagelayout('embedded');
$PAGE->set_title('Tạo bài tập về nhà' . ($topicname !== '' ? ': ' . $topicname : ''));

if (!book_repository::course_has_book($courseid)) {
    throw new moodle_exception('bookrequired', 'local_aisgk');
}

$section = null;
if ($sectionid) {
    $modinfo = get_fast_modinfo($course);
    $section = $modinfo->get_section_info_by_id($sectionid);
}
$sectionlabel = $section && !empty($section->name) ? format_string($section->name) : '';
$prefill = $sectionid ? homework_service::find_section_match($courseid, $sectionid) : null;
if (!$prefill && $topicname !== '') {
    $prefill = homework_service::find_topic_match($courseid, $topicname);
}
$bookid = $prefill ? (int)$prefill['book']->id : (int)(book_repository::get_by_courseid($courseid)->id ?? 0);
$bookname = $prefill ? (string)($prefill['book']->name ?: $prefill['book']->filename) : '';
$pagefrom = $prefill ? (int)($prefill['toc']->trang ?? 1) : 1;
$pageto = $prefill ? (int)($prefill['toc']->endtrang ?? $pagefrom) : max(1, $pagefrom);
$scheduled = userdate(time() > strtotime(date('Y-m-d 17:00:00')) ? strtotime('tomorrow 17:00') : strtotime('today 17:00'), '%Y-%m-%dT%H:%M');
$usemyapi = (bool)get_user_preferences('local_aisgk_use_my_api', 0, $USER->id);

$qtypevilabels = [
    'multichoice' => 'Trắc nghiệm nhiều lựa chọn',
    'truefalse' => 'Đúng/Sai',
    'shortanswer' => 'Trả lời ngắn',
    'numerical' => 'Dạng số',
    'matching' => 'Ghép đôi',
    'essay' => 'Tự luận',
    'gapselect' => 'Chọn từ điền khuyết',
    'ddwtos' => 'Kéo thả vào văn bản',
    'calculated' => 'Tính toán',
    'calculatedsimple' => 'Tính toán đơn giản',
    'calculatedmulti' => 'Trắc nghiệm tính toán',
    'ddimageortext' => 'Kéo thả lên ảnh',
    'ddmarker' => 'Đánh dấu vùng trên ảnh',
    'random' => 'Câu hỏi ngẫu nhiên',
    'description' => 'Mô tả/nội dung',
];
$qtypemenufallback = $qtypevilabels;
$qtypehelp = [
    'multichoice' => 'Câu hỏi có nhiều phương án, học sinh chọn một hoặc nhiều đáp án đúng. Phù hợp để tạo nhanh từ SGK.',
    'truefalse' => 'Câu hỏi Đúng/Sai. Dễ tạo, phù hợp kiểm tra nhận biết khái niệm, sự kiện, quy tắc.',
    'shortanswer' => 'Học sinh nhập một cụm từ hoặc câu trả lời ngắn. Dùng cho định nghĩa, thuật ngữ, kết quả ngắn.',
    'numerical' => 'Học sinh nhập đáp án dạng số, có thể có sai số. Phù hợp bài tính toán đơn giản.',
    'matching' => 'Ghép mỗi mục ở cột này với một mục tương ứng ở cột kia. Phù hợp thuật ngữ - ý nghĩa, thiết bị - chức năng.',
    'essay' => 'Câu tự luận, giáo viên thường cần chấm thủ công. Phù hợp câu vận dụng, giải thích, trình bày.',
    'gapselect' => 'Điền khuyết bằng cách chọn đáp án từ danh sách có sẵn. Phù hợp hoàn thiện câu/đoạn văn.',
    'ddwtos' => 'Kéo các từ/cụm từ vào chỗ trống trong văn bản. Dễ dùng với câu điền khuyết có nhiều vị trí.',
    'calculated' => 'Câu hỏi tính toán có biến và công thức. Khó tạo tự động, cần kiểm tra kỹ trước khi dùng thật.',
    'calculatedsimple' => 'Dạng tính toán đơn giản hơn calculated. Vẫn cần kiểm tra công thức và khoảng giá trị.',
    'calculatedmulti' => 'Trắc nghiệm có dữ liệu tính toán sinh tự động. Khó tạo và khó chuyển chính xác từ AI.',
    'ddimageortext' => 'Kéo chữ hoặc ảnh vào vị trí trên ảnh nền. Cần ảnh và tọa độ, hiện chưa nên ưu tiên AI tạo tự động.',
    'ddmarker' => 'Học sinh kéo marker vào vùng đúng trên ảnh. Cần tọa độ vùng đáp án, khó tạo tự động.',
    'random' => 'Lấy ngẫu nhiên câu hỏi đã có trong ngân hàng đề. Không phải dạng câu hỏi AI sinh nội dung mới.',
    'description' => 'Khối nội dung/mô tả trong quiz, không phải câu hỏi có điểm. Dùng để đưa đoạn thông tin hoặc hướng dẫn.',
];

try {
    $availableqtypes = class_exists('question_bank') ? question_bank::get_qtype_menu() : $qtypemenufallback;
} catch (Throwable $e) {
    $availableqtypes = $qtypemenufallback;
}

$qtypegroups = [
    'easy' => [
        'title' => 'Dễ tạo',
        'types' => ['multichoice', 'truefalse', 'shortanswer', 'numerical', 'matching'],
    ],
    'medium' => [
        'title' => 'Trung bình',
        'types' => ['essay', 'gapselect', 'ddwtos', 'calculated', 'calculatedsimple'],
    ],
    'hard' => [
        'title' => 'Khó tạo',
        'types' => ['calculatedmulti', 'ddimageortext', 'ddmarker', 'random', 'description'],
    ],
];

$questiontypesbygroup = [];
foreach ($qtypegroups as $groupkey => $group) {
    $questiontypesbygroup[$groupkey] = ['title' => $group['title'], 'types' => []];
    foreach ($group['types'] as $type) {
        if (array_key_exists($type, $availableqtypes)) {
            $questiontypesbygroup[$groupkey]['types'][$type] = $qtypevilabels[$type] ?? $availableqtypes[$type];
        } else if (array_key_exists($type, $qtypemenufallback)) {
            $questiontypesbygroup[$groupkey]['types'][$type] = $qtypevilabels[$type] ?? $qtypemenufallback[$type];
        }
    }
}

foreach ($availableqtypes as $type => $label) {
    $alreadyshown = false;
    foreach ($questiontypesbygroup as $group) {
        if (array_key_exists($type, $group['types'])) {
            $alreadyshown = true;
            break;
        }
    }
    if (!$alreadyshown) {
        $questiontypesbygroup['hard']['types'][$type] = $qtypevilabels[$type] ?? $label;
    }
}

function local_aisgk_count_options(int $max = 30, int $selected = 0): string {
    $html = '';
    for ($i = 0; $i <= $max; $i++) {
        $html .= '<option value="' . $i . '"' . ($i === $selected ? ' selected' : '') . '>' . $i . '</option>';
    }
    return $html;
}

echo $OUTPUT->header();
?>
<style>
html,body{overflow:hidden}
.local-aisgk-homework-wrap{padding:8px;font-size:12.5px;width:100%;max-width:100%;height:100vh;box-sizing:border-box;background:#fff;overflow:hidden}
.local-aisgk-card{height:calc(100vh - 16px);display:flex;flex-direction:column;border:1px solid #d7deea;border-radius:10px;background:#fff;padding:10px;box-sizing:border-box;overflow:hidden}
.local-aisgk-card h3{margin:0 0 8px;font-size:18px;font-weight:700;line-height:1.2}
.local-aisgk-grid{display:grid;grid-template-columns:1.05fr .95fr;gap:8px;margin-top:8px}
.local-aisgk-box{border:1px solid #e5e7eb;border-radius:8px;padding:8px;background:#f8fafc;min-width:0}
.local-aisgk-box.long{grid-column:1 / -1}
.local-aisgk-box strong{display:block;margin-bottom:6px;font-size:13px}
.local-aisgk-info{display:grid;grid-template-columns:90px 1fr;gap:3px 8px;color:#334155}
.local-aisgk-muted{color:#64748b}
.local-aisgk-form input,.local-aisgk-form select,.local-aisgk-form textarea{width:100%;box-sizing:border-box;border:1px solid #cbd5e1;border-radius:7px;padding:5px 7px;background:#fff;font-size:12.5px}
.local-aisgk-row{display:grid;grid-template-columns:1fr 70px 46px;gap:6px;align-items:center;margin:4px 0}
.local-aisgk-row label{font-weight:600;margin:0;white-space:nowrap;overflow:hidden;text-overflow:ellipsis}
.local-aisgk-percent{text-align:right;color:#475467;font-weight:600}
.local-aisgk-actions{display:flex;gap:8px;flex-wrap:wrap;margin-top:8px;align-items:center;justify-content:flex-start}
.local-aisgk-actions .btn{padding:5px 12px;font-size:13px;line-height:1.25}
.local-aisgk-actions-right{display:flex;gap:8px;flex-wrap:wrap}
.local-aisgk-progress{margin:8px 0}.local-aisgk-bar{height:10px;background:#e5e7eb;border-radius:999px;overflow:hidden}.local-aisgk-fill{height:100%;width:0;background:#2563eb;transition:width .25s ease}
.local-aisgk-msg{margin-top:5px;color:#334155}.local-aisgk-note{margin-top:6px;color:#475467}
.local-aisgk-hidden{display:none!important}.local-aisgk-editor{min-height:170px;border:1px solid #cbd5e1;border-radius:8px;background:#fff;padding:8px;overflow:auto;line-height:1.45}.local-aisgk-form textarea{min-height:130px;resize:vertical}
.local-aisgk-totalwarn{color:#b91c1c;font-weight:600;margin-top:6px}.local-aisgk-ok{color:#166534;font-weight:600;margin-top:6px}
.local-aisgk-compact-body{flex:1;min-height:0;overflow:auto;padding-right:2px}
.local-aisgk-cognitive-row{display:grid;grid-template-columns:repeat(4,minmax(0,1fr));gap:8px}
.local-aisgk-cognitive-item{display:grid;grid-template-columns:22px 1fr 64px 42px;gap:5px;align-items:center;border:1px solid #e5e7eb;border-radius:7px;background:#fff;padding:6px}
.local-aisgk-cognitive-item label{font-weight:600;margin:0;white-space:nowrap}
.local-aisgk-cognitive-item input,.local-aisgk-cognitive-item select{padding:4px 5px}
.local-aisgk-qtype-grid{display:grid;grid-template-columns:repeat(3,minmax(0,1fr));gap:8px}
.local-aisgk-qtype-col{border:1px solid #e2e8f0;border-radius:8px;background:#fff;padding:7px;min-width:0}
.local-aisgk-qtype-col h4{margin:0 0 6px;font-size:13px;font-weight:700;color:#0f172a}
.local-aisgk-qtype-col .local-aisgk-row{margin:0 0 4px;grid-template-columns:22px minmax(80px,1fr) 22px 56px 22px 40px}
.local-aisgk-distractor{width:18px!important;height:18px;margin:0 auto;cursor:pointer;accent-color:#2563eb}
.local-aisgk-distractor:disabled{cursor:not-allowed;opacity:.28;filter:grayscale(1)}
.local-aisgk-qstatus{font-size:15px;text-align:center}.local-aisgk-draftselect{min-width:220px;max-width:360px}.local-aisgk-helpbtn{width:19px;height:19px;border-radius:50%;border:1px solid #94a3b8;background:#fff;color:#334155;font-weight:700;font-size:12px;line-height:16px;padding:0;cursor:pointer}
.local-aisgk-helpbtn:hover{background:#e0f2fe;border-color:#0284c7}
.local-aisgk-helpbox{position:fixed;z-index:9999;left:50%;top:50%;transform:translate(-50%,-50%);width:min(420px,92vw);background:#fff;border:1px solid #94a3b8;border-radius:10px;box-shadow:0 16px 40px rgba(15,23,42,.25);padding:12px}
.local-aisgk-helpbox h4{margin:0 0 8px;font-size:15px}.local-aisgk-helpbox p{margin:0 0 10px;line-height:1.45}.local-aisgk-helpbox .btn{float:right}
.local-aisgk-output-grid{display:grid;grid-template-columns:1fr 1fr;gap:8px;margin-top:8px}
.local-aisgk-output-grid .local-aisgk-box{display:flex;flex-direction:column;min-height:220px}
.local-aisgk-output-grid textarea,.local-aisgk-output-grid .local-aisgk-editor{flex:1;min-height:0}
.local-aisgk-editor .MathJax,.local-aisgk-editor mjx-container{font-size:112%!important}
.local-aisgk-editor .local-aisgk-preview-question{border:1px solid #e2e8f0;border-radius:10px;background:#fff;margin:0 0 12px;padding:10px;overflow:auto}
.local-aisgk-editor .local-aisgk-preview-question h4{margin:0 0 8px;font-size:15px;color:#0f172a}.local-aisgk-editor .local-aisgk-preview-question small{color:#64748b;font-weight:400}
.local-aisgk-editor .local-aisgk-img-wrap{display:block;float:right;max-width:42%;margin:4px 0 10px 12px;text-align:center;clear:right}
.local-aisgk-editor .local-aisgk-img-wrap img{max-width:100%;height:auto;border:1px solid #cbd5e1;border-radius:8px;background:#fff;padding:3px}
.local-aisgk-editor .local-aisgk-choice-pill{display:inline-block;border:1px solid #cbd5e1;border-radius:999px;padding:2px 8px;margin:2px;background:#f8fafc}.local-aisgk-img-error{color:#b91c1c;font-weight:600}
.local-aisgk-editor .local-aisgk-preview-table{width:100%;border-collapse:collapse;margin-top:6px;background:#fff}
.local-aisgk-editor .local-aisgk-preview-table th,.local-aisgk-editor .local-aisgk-preview-table td{border:1px solid #e2e8f0;padding:5px;text-align:left;vertical-align:top}
.local-aisgk-editor .local-aisgk-preview-table th{background:#f8fafc}
@media(max-width:700px){.local-aisgk-editor .local-aisgk-img-wrap{float:none;max-width:100%;margin:6px 0}}
.local-aisgk-collapse-title{display:flex!important;align-items:center;justify-content:space-between;gap:8px}
.local-aisgk-collapse-btn{border:1px solid #cbd5e1;background:#fff;border-radius:5px;padding:0 6px;line-height:18px;font-size:12px;cursor:pointer}
.local-aisgk-box.is-collapsed > :not(.local-aisgk-collapse-title){display:none!important}
.local-aisgk-box.is-collapsed{min-height:32px}
.local-aisgk-output-grid.json-left-collapsed{grid-template-columns:46px 1fr}
.local-aisgk-output-grid.json-left-collapsed #jsonbox{overflow:hidden;padding:6px 3px}
.local-aisgk-output-grid.json-left-collapsed #jsonbox > :not(.local-aisgk-collapse-title){display:none!important}
.local-aisgk-output-grid.json-left-collapsed #jsonbox .local-aisgk-collapse-title{writing-mode:vertical-rl;min-height:180px;margin:auto}
#jsonbox.json-wide{grid-column:1 / -1;min-height:70vh}
#jsonbox.json-wide textarea{min-height:60vh}
#jsonbox.json-wide + #previewbox{display:none}

@media (max-width:992px){html,body{overflow:auto}.local-aisgk-homework-wrap{height:auto;overflow:visible}.local-aisgk-card{height:auto;overflow:visible}.local-aisgk-compact-body{overflow:visible}.local-aisgk-grid,.local-aisgk-output-grid{grid-template-columns:1fr}.local-aisgk-box.long{grid-column:auto}.local-aisgk-info{grid-template-columns:1fr}.local-aisgk-cognitive-row,.local-aisgk-qtype-grid{grid-template-columns:1fr}.local-aisgk-card h3{font-size:17px}}
</style>
<div class="local-aisgk-homework-wrap">
    <div class="local-aisgk-card local-aisgk-form">
        <h3>Tạo bài tập về nhà</h3>

        <div class="local-aisgk-compact-body">
            <div class="local-aisgk-grid">
                <div class="local-aisgk-box" id="box-source">
                    <strong>SGK / Trang</strong>
                    <div class="local-aisgk-info">
                        <div>Chủ đề</div><div><?php echo $sectionlabel !== '' ? $sectionlabel : '-'; ?> <?php echo $topicname !== '' ? '· ' . s($topicname) : ''; ?></div>
                        <div>SGK</div><div><?php echo s($bookname !== '' ? $bookname : ('Book #' . $bookid)); ?></div>
                        <div>Trang</div><div><?php echo (int)$pagefrom; ?> → <?php echo (int)$pageto; ?></div>
                    </div>
                    <div class="local-aisgk-muted" style="margin-top:6px"><?php echo $prefill ? s((string)$prefill['toc']->tenbai) : 'Chưa tìm thấy liên kết chủ đề với mục lục.'; ?></div>
                </div>

                <div class="local-aisgk-box">
                    <strong>Lịch giao bài</strong>
                    <label for="scheduledtime">Thời điểm giao bài</label>
                    <input id="scheduledtime" type="datetime-local" value="<?php echo s($scheduled); ?>">
                    <div class="local-aisgk-muted" style="margin-top:6px">Có thể tạo bản nháp, chỉnh sửa, lưu DB rồi duyệt để giao theo lịch.</div>
                </div>

                <div class="local-aisgk-box long" id="cognitivebox">
                    <strong>Cài đặt/Xem kết quả tạo Mức độ nhận thức</strong>
                    <div class="local-aisgk-cognitive-row">
                        <div class="local-aisgk-cognitive-item" data-level-row="nhan_biet"><span class="local-aisgk-qstatus" data-lstatus="nhan_biet"></span><label>Nhận biết</label><select class="cognitive" data-key="recognize"><?php echo local_aisgk_count_options(30, 4); ?></select><div class="local-aisgk-percent" data-percent="recognize">40%</div></div>
                        <div class="local-aisgk-cognitive-item" data-level-row="thong_hieu"><span class="local-aisgk-qstatus" data-lstatus="thong_hieu"></span><label>Thông hiểu</label><select class="cognitive" data-key="understand"><?php echo local_aisgk_count_options(30, 4); ?></select><div class="local-aisgk-percent" data-percent="understand">40%</div></div>
                        <div class="local-aisgk-cognitive-item" data-level-row="van_dung"><span class="local-aisgk-qstatus" data-lstatus="van_dung"></span><label>Vận dụng</label><select class="cognitive" data-key="apply"><?php echo local_aisgk_count_options(30, 2); ?></select><div class="local-aisgk-percent" data-percent="apply">20%</div></div>
                        <div class="local-aisgk-cognitive-item"><label>Tổng câu</label><input id="totalquestions" type="number" min="1" max="60" value="10" readonly><div class="local-aisgk-percent" id="totalcognitivepercent">100%</div></div>
                    </div>
                </div>

                <div class="local-aisgk-box long" id="questiontypebox">
                    <strong>Cài đặt/Xem kết quả tạo loại câu hỏi</strong>
                    <div class="local-aisgk-qtype-grid">
                    <?php $defaults = ['multichoice' => 4, 'truefalse' => 2, 'shortanswer' => 2, 'numerical' => 1, 'essay' => 1]; ?>
                    <?php foreach ($questiontypesbygroup as $group): ?>
                        <div class="local-aisgk-qtype-col">
                            <h4><?php echo s($group['title']); ?></h4>
                            <?php foreach ($group['types'] as $type => $label): ?>
                                <div class="local-aisgk-row" data-qtype-row="<?php echo s($type); ?>"><span class="local-aisgk-qstatus" data-qstatus="<?php echo s($type); ?>"></span><label title="<?php echo s($label); ?>"><?php echo s($label); ?></label><button type="button" class="local-aisgk-helpbtn" data-title="<?php echo s($label); ?>" data-help="<?php echo s($qtypehelp[$type] ?? 'Loại câu hỏi Moodle. Cần kiểm tra lại trước khi chuyển thành quiz thật.'); ?>">?</button><select class="qtype" data-type="<?php echo s($type); ?>"><?php echo local_aisgk_count_options(30, (int)($defaults[$type] ?? 0)); ?></select><input type="checkbox" class="local-aisgk-distractor" data-type="<?php echo s($type); ?>" title="Thêm phương án nhiễu cho loại câu hỏi này" aria-label="Thêm nhiễu cho <?php echo s($label); ?>"><div class="local-aisgk-percent" data-qpercent="<?php echo s($type); ?>">0%</div></div>
                            <?php endforeach; ?>
                        </div>
                    <?php endforeach; ?>
                    </div>
                    <div id="qtypecheck" class="local-aisgk-ok">Tổng loại câu hỏi hợp lệ.</div>
                    <div id="validatorreport" class="local-aisgk-note"></div>
                </div>
            </div>

            <div class="local-aisgk-actions">
                <button class="btn btn-primary" id="startbtn">Tạo mới</button>
                <select id="draftselect" class="local-aisgk-draftselect"><option value="">Tạo bài tập về nhà: chọn bản nháp</option></select>
                <button class="btn btn-warning" id="deletebadbtn">Xóa nháp Không đạt</button>
                <button class="btn btn-danger" id="wipebtn">Xóa sạch</button>
                <button class="btn btn-secondary local-aisgk-hidden" id="savebtn">Lưu DB</button>
                <button class="btn btn-success local-aisgk-hidden" id="approvebtn">Duyệt</button>
            </div>

            <div class="local-aisgk-progress">
                <div class="local-aisgk-bar"><div class="local-aisgk-fill" id="barfill"></div></div>
                <div class="local-aisgk-msg"><span id="jobmsg"><?php echo s(get_string('jobready', 'local_aisgk')); ?></span><span id="aimeta" class="local-aisgk-hidden"></span></div>
            </div>

            <div class="local-aisgk-output-grid">
                <div class="local-aisgk-box" id="jsonbox">
                    <strong>JSON đã normalize</strong>
                    <textarea id="local-aisgk-json"></textarea>
                    <textarea id="sourcetext" class="local-aisgk-hidden"></textarea>
                </div>
                <div class="local-aisgk-box" id="previewbox">
                    <strong>Nội dung câu hỏi nháp / giao bài</strong>
                    <div id="previeweditor" class="local-aisgk-editor" contenteditable="true"></div>
                    <textarea id="teacheredited" class="local-aisgk-hidden"></textarea>
                    <div class="local-aisgk-muted" style="margin-top:5px">Khung này dùng để xem thử và chỉnh sửa trước khi lưu DB hoặc duyệt.</div>
                </div>
            </div>
            <div class="local-aisgk-note" id="resultnote"></div>
        </div>
    </div>
</div>
<div id="qtypehelpbox" class="local-aisgk-helpbox local-aisgk-hidden"><h4 id="qtypehelptitle"></h4><p id="qtypehelptext"></p><button type="button" class="btn btn-secondary" id="qtypehelpclose">Đóng</button></div>
<script>
window.MathJax = window.MathJax || {tex:{inlineMath:[["\\(","\\)"]],displayMath:[["\\[","\\]"]]}, startup:{typeset:false}};
</script>
<script src="https://cdn.jsdelivr.net/npm/mathjax@3/es5/tex-mml-chtml.js" async></script>
<script>
(function() {
    const cfg = {
        courseid: <?php echo (int)$courseid; ?>,
        sectionid: <?php echo (int)$sectionid; ?>,
        topicname: <?php echo json_encode($topicname); ?>,
        bookid: <?php echo (int)$bookid; ?>,
        pagefrom: <?php echo (int)$pagefrom; ?>,
        pageto: <?php echo (int)$pageto; ?>,
        sesskey: <?php echo json_encode(sesskey()); ?>,
        ajaxurl: <?php echo json_encode((new moodle_url('/local/aisgk/homework_ajax.php'))->out(false)); ?>
    };
    let currentJobId = 0;
    let currentHomeworkId = 0;
    let timer = null;

    const $ = (id) => document.getElementById(id);
    function setMsg(msg) { $('jobmsg').textContent = msg || ''; }
    function setAiMeta(usage) {
        const el = $('aimeta');
        if (!usage) { el.classList.add('local-aisgk-hidden'); el.textContent = ''; return; }
        const model = usage.model || '';
        const tokens = usage.tokens || 0;
        const api = usage.api || (usage.category === 'pay' ? 'API trả phí' : 'API hệ thống/miễn phí');
        el.textContent = ' · Model: ' + model + ' · Token: ' + tokens + ' · API: ' + api;
        el.classList.remove('local-aisgk-hidden');
    }
    function setBar(v) { $('barfill').style.width = Math.max(0, Math.min(100, v || 0)) + '%'; }
    function htmlEscape(s) { return String(s || '').replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;'); }
    function textToHtml(s) { return htmlEscape(s).replace(/\n\n+/g, '</p><p>').replace(/\n/g, '<br>'); }
    function looksLikeHtml(s) { return /<\/?(div|p|table|span|img|ul|ol|li|br|strong|h[1-6])\b/i.test(String(s || '')); }
    function renderMathInPreview() {
        const el = $('previeweditor');
        if (!el || !window.MathJax || !window.MathJax.typesetPromise) { return; }
        window.MathJax.typesetClear && window.MathJax.typesetClear([el]);
        window.MathJax.typesetPromise([el]).catch(function() {});
    }

    function setupCollapse() {
        document.querySelectorAll('.local-aisgk-box > strong').forEach(strong => {
            if (strong.classList.contains('local-aisgk-collapse-title')) { return; }
            strong.classList.add('local-aisgk-collapse-title');
            const btn = document.createElement('button');
            btn.type = 'button';
            btn.className = 'local-aisgk-collapse-btn';
            btn.textContent = '−';
            btn.title = 'Thu gọn / mở rộng';
            strong.appendChild(btn);
            btn.addEventListener('click', function(e) {
                e.preventDefault();
                e.stopPropagation();
                const box = strong.parentElement;
                if (box && box.id === 'jsonbox') {
                    const grid = box.closest('.local-aisgk-output-grid');
                    if (box.classList.contains('json-wide')) {
                        box.classList.remove('json-wide');
                        if (grid) { grid.classList.add('json-left-collapsed'); }
                        btn.textContent = '+';
                    } else if (grid && grid.classList.contains('json-left-collapsed')) {
                        grid.classList.remove('json-left-collapsed');
                        box.classList.add('json-wide');
                        btn.textContent = '↔';
                    } else {
                        box.classList.add('json-wide');
                        btn.textContent = '↔';
                    }
                    return;
                }
                box.classList.toggle('is-collapsed');
                btn.textContent = box.classList.contains('is-collapsed') ? '+' : '−';
            });
        });
    }

    function sumSelects(selector) {
        return Array.from(document.querySelectorAll(selector)).reduce((sum, el) => sum + (parseInt(el.value || '0', 10) || 0), 0);
    }
    function updateRatios() {
        const total = sumSelects('.cognitive');
        $('totalquestions').value = total;
        document.querySelectorAll('.cognitive').forEach(el => {
            const key = el.dataset.key;
            const pct = total ? Math.round(((parseInt(el.value || '0', 10) || 0) / total) * 100) : 0;
            document.querySelector('[data-percent="' + key + '"]').textContent = pct + '%';
        });
        const qtotal = sumSelects('.qtype');
        document.querySelectorAll('.qtype').forEach(el => {
            const type = el.dataset.type;
            const pct = total ? Math.round(((parseInt(el.value || '0', 10) || 0) / total) * 100) : 0;
            document.querySelector('[data-qpercent="' + type + '"]').textContent = pct + '%';
        });
        const msg = $('qtypecheck');
        if (qtotal > total) {
            msg.className = 'local-aisgk-totalwarn';
            msg.textContent = 'Tổng loại câu hỏi (' + qtotal + ') vượt tổng câu (' + total + ').';
        } else if (qtotal < total) {
            msg.className = 'local-aisgk-totalwarn';
            msg.textContent = 'Tổng loại câu hỏi còn thiếu ' + (total - qtotal) + ' câu.';
        } else {
            msg.className = 'local-aisgk-ok';
            msg.textContent = 'Tổng loại câu hỏi hợp lệ.';
        }
        return {total: total, qtotal: qtotal, valid: qtotal === total};
    }

    const DISTRACTOR_QTYPES = ['ddwtos', 'gapselect', 'matching', 'multichoice', 'ddmarker', 'ddimageortext'];
    function updateDistractorUi() {
        document.querySelectorAll('.local-aisgk-distractor').forEach(cb => {
            const type = cb.dataset.type || '';
            const enabled = DISTRACTOR_QTYPES.indexOf(type) !== -1;
            cb.disabled = !enabled;
            cb.title = enabled ? 'Thêm phương án nhiễu cho loại câu hỏi này' : 'Loại câu hỏi này chưa hỗ trợ thêm nhiễu';
            if (!enabled) { cb.checked = false; }
        });
    }
    function resetCreateUi() {
        clearTimeout(validateTimer);
        clearReportIcons();
        $('validatorreport').textContent = '';
        $('resultnote').textContent = '';
        $('aimeta').classList.add('local-aisgk-hidden');
        $('aimeta').textContent = '';
        updateRatios();
        updateDistractorUi();
        const base = updateRatios();
        $('qtypecheck').textContent = 'Tổng loại câu hỏi ' + (base.valid ? 'hợp lệ.' : 'chưa hợp lệ.') + ' Kết quả tạo: Chưa kiểm tra.';
        $('savebtn').classList.add('local-aisgk-hidden');
        $('approvebtn').classList.add('local-aisgk-hidden');
    }
    document.querySelectorAll('.cognitive,.qtype,.local-aisgk-distractor').forEach(el => el.addEventListener('change', function() { resetCreateUi(); }));
    setupCollapse();
    updateRatios();
    updateDistractorUi();

    function collectOptions() {
        const ratios = updateRatios();
        const cognitive = {};
        document.querySelectorAll('.cognitive').forEach(el => cognitive[el.dataset.key] = parseInt(el.value || '0', 10) || 0);
        const qtypes = {};
        document.querySelectorAll('.qtype').forEach(el => qtypes[el.dataset.type] = parseInt(el.value || '0', 10) || 0);
        const distractors = {};
        document.querySelectorAll('.local-aisgk-distractor').forEach(el => {
            if (!el.disabled && el.checked) { distractors[el.dataset.type] = true; }
        });
        return {total: ratios.total, cognitive: cognitive, qtypes: qtypes, distractors: distractors};
    }


    let validateTimer = null;
    function setStatusIcon(el, ok, title) {
        if (!el) { return; }
        el.className = 'local-aisgk-qstatus icon fa ' + (ok ? 'fa-chevron-down' : 'fa-times') + ' fa-fw';
        el.setAttribute('title', title || '');
    }
    function clearReportIcons() {
        document.querySelectorAll('[data-qstatus],[data-lstatus]').forEach(el => {
            el.className = 'local-aisgk-qstatus';
            el.removeAttribute('title');
        });
    }
    function errorFor(key, report) {
        const errors = report && report.errors ? report.errors : [];
        const lowkey = String(key).toLowerCase();
        return errors.filter(e => String(e).toLowerCase().indexOf(lowkey) !== -1).join('\n');
    }
    function renderReport(report) {
        const box = $('validatorreport');
        box.textContent = '';
        clearReportIcons();
        const base = updateRatios();
        if (!report) {
            $('qtypecheck').textContent = 'Tổng loại câu hỏi ' + (base.valid ? 'hợp lệ.' : 'chưa hợp lệ.') + ' Kết quả tạo: Chưa kiểm tra.';
            return;
        }
        if (report.summary && report.summary.qtypes) {
            Object.keys(report.summary.qtypes).forEach(t => {
                const v = report.summary.qtypes[t];
                const ok = parseInt(v.used || 0, 10) === parseInt(v.required || 0, 10);
                const detail = (ok ? 'Đạt: ' : 'Không đạt: ') + t + ' (' + v.used + '/' + v.required + ').' + (errorFor(t, report) ? '\n' + errorFor(t, report) : '');
                setStatusIcon(document.querySelector('[data-qstatus="' + t + '"]'), ok, detail);
                const row = document.querySelector('[data-qtype-row="' + t + '"]');
                if (row) { row.setAttribute('title', detail); }
                const pct = document.querySelector('[data-qpercent="' + t + '"]');
                if (pct) { pct.textContent = '(' + v.used + '/' + v.required + ')'; pct.setAttribute('title', detail); }
            });
        }
        if (report.summary && report.summary.levels) {
            Object.keys(report.summary.levels).forEach(t => {
                const v = report.summary.levels[t];
                const ok = parseInt(v.used || 0, 10) === parseInt(v.required || 0, 10);
                const detail = (ok ? 'Đạt: ' : 'Không đạt: ') + t + ' (' + v.used + '/' + v.required + ').' + (errorFor(t, report) ? '\n' + errorFor(t, report) : '');
                setStatusIcon(document.querySelector('[data-lstatus="' + t + '"]'), ok, detail);
                const row = document.querySelector('[data-level-row="' + t + '"]');
                if (row) { row.setAttribute('title', detail); }
            });
        }
        $('qtypecheck').className = report.ok ? 'local-aisgk-ok' : 'local-aisgk-totalwarn';
        $('qtypecheck').textContent = 'Tổng loại câu hỏi ' + (base.valid ? 'hợp lệ.' : 'chưa hợp lệ.') + ' Kết quả tạo: ' + (report.ok ? 'Đạt.' : 'Không đạt.');
    }
    function scheduleLiveValidate() {
        clearTimeout(validateTimer);
        validateTimer = setTimeout(async function() {
            const val = $('local-aisgk-json').value.trim();
            if (!val) { renderReport(null); return; }
            try {
                const json = await api('validatejson', {json: val, options: collectOptions(), homeworkid: currentHomeworkId});
                if (json.normalizedjson && json.normalizedjson !== val && !json.hasdebugraw) {
                    $('local-aisgk-json').value = json.normalizedjson;
                    $('sourcetext').value = json.normalizedjson;
                }
                renderReport(json.report);
                if (json.previewjson) {
                    const previewQuestions = parseQuestionsPayload(json.previewjson);
                    const rendered = renderQuestionsPreview(previewQuestions);
                    if (rendered) { $('previeweditor').innerHTML = rendered; renderMathInPreview(); }
                }
            } catch (e) {
                renderReport({ok:false, errors:[e.message || String(e)], summary:{qtypes:{},levels:{}}});
            }
        }, 500);
    }
    async function loadDrafts(selectId) {
        try {
            const json = await api('drafts', {sectionid: cfg.sectionid});
            const sel = $('draftselect');
            sel.innerHTML = '<option value="">Tạo bài tập về nhà: chọn bản nháp</option>';
            let first = '';
            (json.drafts || []).forEach(d => {
                const o = document.createElement('option');
                o.value = d.id;
                o.textContent = 'Nháp #' + d.id + ' · ' + (d.topicname || '') + ' · ' + (d.status || '');
                sel.appendChild(o);
                if (!first) { first = String(d.id); }
            });
            const target = selectId ? String(selectId) : first;
            if (target && Array.from(sel.options).some(o => o.value === target)) {
                sel.value = target;
                if (!currentHomeworkId || selectId) {
                    const loaded = await api('loaddraft', {homeworkid: target});
                    applyHomework(loaded.homework);
                }
            }
        } catch (e) { setMsg(e.message || String(e)); }
    }
    async function api(action, data) {
        const fd = new URLSearchParams();
        fd.set('action', action);
        fd.set('courseid', cfg.courseid);
        fd.set('sesskey', cfg.sesskey);
        Object.keys(data || {}).forEach((k) => fd.set(k, typeof data[k] === 'object' ? JSON.stringify(data[k]) : data[k]));
        const res = await fetch(cfg.ajaxurl, {method:'POST',headers:{'Content-Type':'application/x-www-form-urlencoded; charset=UTF-8'},body:fd.toString()});
        const json = await res.json();
        if (!res.ok || !json.ok) { throw new Error((json && json.error) ? json.error : 'Yêu cầu thất bại'); }
        return json;
    }
    function applyOptions(options) {
        if (!options || typeof options !== 'object') { updateRatios(); return; }
        const cognitive = options.cognitive || {};
        const levelMap = {nhan_biet:'recognize', thong_hieu:'understand', van_dung:'apply'};
        Object.keys(cognitive).forEach(k => {
            const key = levelMap[k] || k;
            const el = document.querySelector('.cognitive[data-key="' + key + '"]');
            if (el) { el.value = parseInt(cognitive[k] || 0, 10) || 0; }
        });
        const qtypes = options.qtypes || {};
        Object.keys(qtypes).forEach(t => {
            const el = document.querySelector('.qtype[data-type="' + t + '"]');
            if (el) { el.value = parseInt(qtypes[t] || 0, 10) || 0; }
        });
        const distractors = options.distractors || {};
        document.querySelectorAll('.local-aisgk-distractor').forEach(cb => {
            cb.checked = !!distractors[cb.dataset.type];
        });
        updateDistractorUi();
        updateRatios();
    }
    function parseOptionsFromHomework(hw) {
        if (!hw || !hw.sourceformula) { return null; }
        try {
            const data = JSON.parse(hw.sourceformula);
            return data && data.options ? data.options : data;
        } catch (e) { return null; }
    }
    function parseQuestionsPayload(raw) {
        if (!raw) { return []; }
        try {
            const data = typeof raw === 'string' ? JSON.parse(raw) : raw;
            if (Array.isArray(data)) { return data; }
            if (data && Array.isArray(data.questions)) { return data.questions; }
            if (data && data._debug && data._debug.normalizedjson) {
                try {
                    const n = JSON.parse(data._debug.normalizedjson);
                    return Array.isArray(n.questions) ? n.questions : [];
                } catch (e) {}
            }
        } catch (e) {}
        return [];
    }
    function renderQuestionsPreview(questions) {
        if (!questions || !questions.length) { return ''; }
        return questions.map(function(q, idx) {
            const type = q.qtype || q.type || '';
            let html = '<div class="local-aisgk-preview-question">';
            html += '<h4>Câu ' + (idx + 1) + ' <small>(' + htmlEscape(type) + ' · ' + htmlEscape(q.level || '') + ')</small></h4>';
            html += '<div class="local-aisgk-preview-qtext">' + (q.questiontext || '') + '</div>';
            if (type === 'matching' && Array.isArray(q.subquestions)) {
                html += '<table class="local-aisgk-preview-table"><thead><tr><th>Vế trái</th><th>Vế phải</th></tr></thead><tbody>';
                q.subquestions.forEach(function(sq) {
                    html += '<tr><td>' + ((sq && sq.question) || '') + '</td><td>' + ((sq && sq.answer) || '') + '</td></tr>';
                });
                html += '</tbody></table>';
            } else if ((type === 'ddwtos' || type === 'gapselect') && Array.isArray(q.choices)) {
                html += '<div class="local-aisgk-preview-choices"><strong>Đáp án kéo thả:</strong> ';
                html += q.choices.map(function(c) {
                    return '<span class="local-aisgk-choice-pill">[[' + parseInt((c && c.group) || 1, 10) + ']] ' + ((c && c.text) || '') + '</span>';
                }).join(' ');
                html += '</div>';
            } else if (Array.isArray(q.answers)) {
                html += '<ul class="local-aisgk-preview-answers">';
                q.answers.forEach(function(a) {
                    html += '<li>' + ((a && (a.text || a.answer)) || '') + '</li>';
                });
                html += '</ul>';
            }
            html += '</div>';
            return html;
        }).join('');
    }
    function applyHomework(hw) {
        if (!hw) { return; }
        currentHomeworkId = parseInt(hw.id || 0, 10);
        applyOptions(parseOptionsFromHomework(hw));
        $('sourcetext').value = hw.sourcetext || '';
        $('local-aisgk-json').value = hw.sourcetext || hw.questiondata || '';
        renderReport(null);
        scheduleLiveValidate();
        const content = hw.teacheredited || '';
        $('teacheredited').value = content;
        const questions = parseQuestionsPayload(hw.previewquestiondata || hw.questiondata || hw.sourcetext || '');
        const rendered = renderQuestionsPreview(questions);
        if (rendered) {
            $('previeweditor').innerHTML = rendered;
        } else {
            $('previeweditor').innerHTML = looksLikeHtml(content) ? content : ('<p>' + textToHtml(content) + '</p>');
        }
        renderMathInPreview();
        $('resultnote').textContent = hw.deliverymessage ? 'Trạng thái giao bài: ' + hw.deliverymessage : '';
        ['savebtn','approvebtn'].forEach(id => $(id).classList.remove('local-aisgk-hidden'));
    }
    async function poll() {
        const json = await api('status', {jobid: currentJobId});
        const job = json.job || {};
        setBar(parseInt(job.progress || 0, 10));
        setMsg(job.message || job.steptext || '');
        if (json.result && json.result.usage) {
            setAiMeta(json.result.usage);
        }
        applyHomework(json.homework || null);
        if (job.status === 'done' || job.status === 'failed') { clearInterval(timer); timer = null; }
    }
    document.querySelectorAll('.local-aisgk-helpbtn').forEach(btn => btn.addEventListener('click', function() {
        $('qtypehelptitle').textContent = this.dataset.title || 'Thông tin loại câu hỏi';
        $('qtypehelptext').textContent = this.dataset.help || '';
        $('qtypehelpbox').classList.remove('local-aisgk-hidden');
    }));
    $('qtypehelpclose').addEventListener('click', function() { $('qtypehelpbox').classList.add('local-aisgk-hidden'); });

    $('local-aisgk-json').addEventListener('input', scheduleLiveValidate);
    $('draftselect').addEventListener('change', async function() {
        if (!this.value) { return; }
        try { const json = await api('loaddraft', {homeworkid: this.value}); applyHomework(json.homework); setMsg('Đã load bản nháp.'); } catch (e) { setMsg(e.message || String(e)); }
    });
    loadDrafts();
    $('startbtn').addEventListener('click', async function() {
        try {
            const ratios = updateRatios();
            if (!ratios.valid) { setMsg('Tổng loại câu hỏi phải bằng tổng câu.'); return; }
            setAiMeta(null);
            renderReport(null);
            $('local-aisgk-json').value = '';
            $('previeweditor').innerHTML = '';
            setMsg('Đang đưa vào hàng đợi...');
            const json = await api('start', {
                sectionid: cfg.sectionid,
                topicname: cfg.topicname,
                bookid: cfg.bookid,
                pagefrom: cfg.pagefrom,
                pageto: cfg.pageto,
                scheduledtime: $('scheduledtime').value,
                options: collectOptions()
            });
            currentJobId = parseInt(json.jobid, 10);
            setBar(5);
            if (timer) { clearInterval(timer); }
            timer = setInterval(poll, 1500);
            poll();
        } catch (e) { setMsg(e.message || String(e)); }
    });
    $('savebtn').addEventListener('click', async function() {
        if (!currentHomeworkId) return;
        try {
            $('teacheredited').value = $('previeweditor').innerHTML;
            await api('save', {homeworkid: currentHomeworkId, teacheredited: $('teacheredited').value, scheduledtime: $('scheduledtime').value, options: collectOptions(), json: $('local-aisgk-json').value});
            scheduleLiveValidate();
            await loadDrafts(currentHomeworkId);
            setMsg('Đã lưu DB.');
        } catch (e) { setMsg(e.message || String(e)); }
    });
    $('approvebtn').addEventListener('click', async function() {
        if (!currentHomeworkId) return;
        try { await api('approve', {homeworkid: currentHomeworkId}); await loadDrafts(currentHomeworkId); setMsg('Đã duyệt bài tập.'); } catch (e) { setMsg(e.message || String(e)); }
    });
    $('deletebadbtn').addEventListener('click', async function() {
        if (!confirm('Xóa các bản nháp Không đạt của khóa học/topic hiện tại?')) { return; }
        try {
            const json = await api('deletebad', {sectionid: cfg.sectionid, topicname: cfg.topicname});
            currentHomeworkId = 0;
            $('local-aisgk-json').value = '';
            $('sourcetext').value = '';
            $('previeweditor').innerHTML = '';
            renderReport(null);
            await loadDrafts();
            setMsg('Đã xóa ' + (json.deleted || 0) + ' bản nháp không đạt.');
        } catch (e) { setMsg(e.message || String(e)); }
    });
    $('wipebtn').addEventListener('click', async function() {
        if (!confirm('CẢNH BÁO: Xóa sạch bản nháp, DB plugin và Ngân hàng câu hỏi Moodle của khóa học/topic hiện tại?')) { return; }
        if (!confirm('Xác nhận lần 2: thao tác này không hoàn tác. Tiếp tục xóa sạch?')) { return; }
        try {
            const json = await api('wipe', {sectionid: cfg.sectionid, topicname: cfg.topicname});
            currentHomeworkId = 0;
            $('local-aisgk-json').value = '';
            $('sourcetext').value = '';
            $('previeweditor').innerHTML = '';
            renderReport(null);
            await loadDrafts();
            setMsg('Đã xóa sạch: ' + (json.homeworks || 0) + ' bản ghi plugin, ' + (json.questions || 0) + ' câu hỏi Moodle.');
        } catch (e) { setMsg(e.message || String(e)); }
    });
})();
</script>
<?php echo $OUTPUT->footer();
