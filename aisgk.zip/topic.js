(function() {
    const courseid = <?php echo (int)$courseid; ?>;
    const sesskey = <?php echo json_encode(sesskey()); ?>;
    const ajaxUrl = <?php echo json_encode((new moodle_url('/local/aisgk/topic_ajax.php', ['id' => $courseid]))->out(false)); ?>;
    const viewBase = <?php echo json_encode((new moodle_url('/local/aisgk/topic.php', ['id' => $courseid]))->out(false)); ?>;
    const bookLabels = <?php echo json_encode(array_reduce($books, static function($carry, $b) { $carry[(string)(int)$b->id] = local_aisgk_book_label($b); return $carry; }, []), JSON_UNESCAPED_UNICODE); ?>;
    const tbody = document.querySelector('#local-aisgk-toc-table tbody');
    const statusEl = document.getElementById('local-aisgk-status');
    const draftEl = document.getElementById('local-aisgk-draftview');
    const selectedBookId = () => document.getElementById('local-aisgk-bookid').value;
    const selectedBookName = () => {
        const sel = document.getElementById('local-aisgk-bookid');
        return sel.options[sel.selectedIndex].text.replace(/^\[\d+\]\s*/, '');
    };
    const sourceLabel = row => {
        if (row && row.bookname) { return row.bookname; }
        if (row && row.bookid && bookLabels[String(row.bookid)]) {
            return bookLabels[String(row.bookid)].replace(/^\[\d+\]\s*/, '');
        }
        return selectedBookName();
    };
    const sourceBookId = row => (row && row.bookid) ? row.bookid : (selectedBookId() !== '0' ? selectedBookId() : '');

    function makeRow(row) {
        row = row || {};
        const tr = document.createElement('tr');
        tr.innerHTML = '' +
            '<td></td>' +
            '<td><button type="button" class="local-aisgk-addline">+</button></td>' +
            '<td><input type="number" class="row-sobai" value="' + escapeHtml(row.sobai || '') + '"></td>' +
            '<td><input type="text" class="row-tenbai" value="' + escapeHtml(row.tenbai || '') + '"></td>' +
            '<td><input type="number" class="row-trang" value="' + escapeHtml(row.trang || '') + '"></td>' +
            '<td><input type="number" class="row-endtrang" value="' + escapeHtml(row.endtrang || '') + '"></td>' +
            '<td class="local-aisgk-source" title="' + escapeHtml(sourceLabel(row)) + '">' + escapeHtml(sourceLabel(row)) + '</td>' +
            '<td><button type="button" class="local-aisgk-rowdelete">×</button><input type="hidden" class="row-bookid" value="' + escapeHtml(sourceBookId(row)) + '"><input type="hidden" class="row-bookname" value="' + escapeHtml(sourceLabel(row)) + '"><input type="hidden" class="row-rawline" value="' + escapeHtml(row.rawline || '') + '"></td>' ;
        return tr;
    }

    function escapeHtml(str) {
        return String(str).replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;').replace(/"/g, '&quot;');
    }

    function renumber() {
        Array.from(tbody.querySelectorAll('tr')).forEach((tr, idx) => {
            tr.children[0].textContent = idx + 1;
            const cell = tr.querySelector('.local-aisgk-source');
            if (cell) {
                const hiddenName = tr.querySelector('.row-bookname');
                const name = hiddenName ? hiddenName.value : sourceLabel({});
                cell.textContent = name;
                cell.title = name;
            }
        });
        if (!tbody.querySelector('tr')) {
            tbody.appendChild(makeRow({}));
            renumber();
        }
    }

    function rowsFromTable() {
        return Array.from(tbody.querySelectorAll('tr')).map(tr => ({
            sobai: tr.querySelector('.row-sobai').value.trim(),
            tenbai: tr.querySelector('.row-tenbai').value.trim(),
            trang: tr.querySelector('.row-trang').value.trim(),
            endtrang: tr.querySelector('.row-endtrang').value.trim(),
            rawline: tr.querySelector('.row-rawline').value.trim(),
            bookid: tr.querySelector('.row-bookid') ? tr.querySelector('.row-bookid').value.trim() : '',
            bookname: tr.querySelector('.row-bookname') ? tr.querySelector('.row-bookname').value.trim() : ''
        }));
    }

    function renderRows(rows) {
        tbody.innerHTML = '';
        (rows && rows.length ? rows : [{}]).forEach(row => tbody.appendChild(makeRow(row)));
        renumber();
    }

    function setStatus(text) {
        statusEl.textContent = text;
    }

    function setDraft(text) {
        draftEl.textContent = text;
    }

    function escapeHtmlAttr(str) {
        return escapeHtml(str).replace(/'/g, '&#39;');
    }

    function renderAdvancedProgress(percent, message, state) {
        const safePercent = Math.max(0, Math.min(100, Number(percent) || 0));
        const text = message || 'Đang xử lý...';
        const color = state === 'done' ? '#2e7d32' : (state === 'error' ? '#b91c1c' : '#2563eb');
        draftEl.innerHTML = '' +
            '<div class="local-aisgk-progressbox">' +
            '<div class="local-aisgk-progressfill" style="width:' + safePercent + '%;background:' + color + '"></div>' +
            '<div class="local-aisgk-progresstext">' + escapeHtml(text) + '</div>' +
            '</div>';
    }

    function localAisgkGetInt(row, selector) {
    const el = row.querySelector(selector);
    if (!el) {
        return null;
    }
    const raw = (el.value || '').trim();
    if (raw === '') {
        return null;
    }
    const num = parseInt(raw, 10);
    return Number.isNaN(num) ? null : num;
    }

    function localAisgkGetText(row, selector) {
        const el = row.querySelector(selector);
        if (!el) {
            return '';
        }
        return (el.textContent || '').replace(/\s+/g, ' ').trim();
    }

    async function postJson(op, payload, label) {
        const bookid = document.getElementById('local-aisgk-bookid').value;
        let timer = null;
        const start = Date.now();
        if (label) {
            timer = setInterval(() => {
                setDraft(label + '... ' + ((Date.now() - start) / 1000).toFixed(1) + 's');
            }, 200);
        }
        try {
            const res = await fetch(ajaxUrl + '&bookid=' + encodeURIComponent(bookid) + '&op=' + encodeURIComponent(op) + '&sesskey=' + encodeURIComponent(sesskey), {
                method: 'POST',
                headers: {'Content-Type': 'application/json'},
                body: JSON.stringify(payload || {})
            });
            const raw = await res.text();
            let data = null;
            try {
                data = JSON.parse(raw);
            } catch (e) {
                throw new Error(raw || 'Response is not JSON');
            }
            if (!res.ok || !data.ok) {
                throw new Error((data && data.error) ? data.error : (raw || 'Yêu cầu thất bại'));
            }
            if (timer) {
                clearInterval(timer);
                const t = ((Date.now() - start) / 1000).toFixed(1);
                setDraft('✓ Done, +' + ((data.rows || []).length) + ' rows (' + t + 's)');
            }
            return data;
        } catch (err) {
            if (timer) {
                clearInterval(timer);
            }
            setDraft('Failed: ' + (err && err.message ? err.message : 'Unknown error'));
            throw err;
        }
    }
    function localAisgkClearInvalidRows() {
        document.querySelectorAll('#local-aisgk-toc-table tbody tr').forEach(function(row) {
            row.classList.remove('local-aisgk-row-invalid');
            row.removeAttribute('title');
        });
    }
    function localAisgkMarkInvalid(row, reason) {
        row.classList.add('local-aisgk-row-invalid');
            if (reason) {
                row.title = reason;
            }
    }
    tbody.addEventListener('click', function(e) {
        const addBtn = e.target.closest('.local-aisgk-addline');
        if (addBtn) {
            const tr = addBtn.closest('tr');
            const next = makeRow({});
            if (tr && tr.nextSibling) {
                tbody.insertBefore(next, tr.nextSibling);
            } else {
                tbody.appendChild(next);
            }
            renumber();
            return;
        }
        const delBtn = e.target.closest('.local-aisgk-rowdelete');
        if (delBtn) {
            delBtn.closest('tr').remove();
            renumber();
        }
    });
    function localAisgkValidateRows() {
        localAisgkClearInvalidRows();

        const rows = Array.from(document.querySelectorAll('#local-aisgk-toc-table tbody tr'));
        let hasError = false;
        let prevBySource = {};

        rows.forEach(function(row) {
            const start = localAisgkGetInt(row, '.row-trang');
            const end = localAisgkGetInt(row, '.row-endtrang');
            const source = localAisgkGetText(row, '.local-aisgk-source');

            let invalid = false;
            let reasons = [];

            if (start === null) {
                invalid = true;
                reasons.push('Start page không được trống');
            }

            if (end === null) {
                invalid = true;
                reasons.push('End page không được trống');
            }

            if (start !== null && end !== null && !(start <= end)) {
                invalid = true;
                reasons.push('Start page phải nhỏ hơn hoặc bằng end page');
            }

            if (source !== '' && prevBySource[source] && start !== null) {
                const prev = prevBySource[source];

                if (!(prev.start < start)) {
                    invalid = true;
                    reasons.push('Start page dòng trên phải nhỏ hơn start page dòng dưới');
                }

                if (start !== prev.end + 1) {
                    invalid = true;
                    reasons.push('Start page dòng dưới phải bằng end page dòng trên + 1');
                }
            }

            if (invalid) {
                hasError = true;
                localAisgkMarkInvalid(row, reasons.join(' | '));
            }

            if (source !== '' && start !== null && end !== null) {
                prevBySource[source] = {
                    start: start,
                    end: end
                };
            }
        });

        return !hasError;
    }


    async function scanAdvanced() {
        const bookid = document.getElementById('local-aisgk-bookid').value;
        const res = await fetch(ajaxUrl + '&bookid=' + encodeURIComponent(bookid) + '&op=scanadvanced&sesskey=' + encodeURIComponent(sesskey), {
            method: 'POST',
            headers: {'Content-Type': 'application/json'},
            body: JSON.stringify({
                columns: document.getElementById('local-aisgk-columns').value,
                psm: document.getElementById('local-aisgk-psm').value,
                pagerange: document.getElementById('local-aisgk-page').value
            })
        });

        if (!res.body) {
            throw new Error('Trình duyệt không hỗ trợ stream phản hồi');
        }

        const reader = res.body.getReader();
        const decoder = new TextDecoder();
        let buffer = '';
        let resultRows = null;
        let streamError = null;

        renderAdvancedProgress(3, 'Khởi động Advanced scan...', 'running');

        while (true) {
            const chunk = await reader.read();
            if (chunk.done) {
                break;
            }
            buffer += decoder.decode(chunk.value, {stream: true});
            const parts = buffer.split(/\r?\n/);
            buffer = parts.pop();

            parts.forEach(function(line) {
                line = line.trim();
                if (!line) {
                    return;
                }
                let data = null;
                try {
                    data = JSON.parse(line);
                } catch (e) {
                    return;
                }
                if (!data.ok) {
                    streamError = data.error || 'Scan nâng cao thất bại';
                    return;
                }
                if (data.type === 'progress' && data.progress) {
                    const step = Number(data.progress.step || 1);
                    const base = {1: 18, 2: 42, 3: 78, 4: 96};
                    let percent = base[step] || 10;
                    if (data.progress.status === 'done' && step === 4) {
                        percent = 100;
                    }
                    renderAdvancedProgress(percent, data.progress.message || '', data.progress.status === 'done' ? 'done' : 'running');
                }
                if (data.type === 'result') {
                    resultRows = data.rows || [];
                }
            });
        }

        if (!res.ok) {
            throw new Error(streamError || 'Scan nâng cao thất bại');
        }
        if (streamError) {
            throw new Error(streamError);
        }
        if (!resultRows) {
            throw new Error('Không nhận được kết quả scan nâng cao');
        }

        renderAdvancedProgress(100, 'Hoàn tất quét mục lục', 'done');
        return {rows: resultRows};
    }

    document.getElementById('local-aisgk-clearall').addEventListener('click', function() {
        renderRows([{}]);
        setStatus('✓ Done, +0 rows');
        setDraft('Cleared');
    });

    document.getElementById('local-aisgk-advancedscan').addEventListener('click', function(e) {
        e.stopPropagation();
    });

    async function loadCurrentSelection() {
        setStatus('Loading');
        const data = await postJson('load', {}, 'Loading');
        renderRows(data.rows || []);
        setStatus('✓ Done, +' + ((data.rows || []).length) + ' rows');
    }

    document.getElementById('local-aisgk-bookid').addEventListener('change', async function() {
        try {
            await loadCurrentSelection();
        } catch (err) {
            setStatus('Failed');
            window.localAisgkMsgBox(err.message);
        }
    });

    async function startScanJob(mode) {
        const startData = await postJson('scanjobstart', {
            mode: mode,
            columns: document.getElementById('local-aisgk-columns').value,
            psm: document.getElementById('local-aisgk-psm').value,
            pagerange: document.getElementById('local-aisgk-page').value
        }, 'Queueing');
        const jobid = parseInt(startData.jobid || 0, 10);
        if (!jobid) {
            throw new Error('Không tạo được job Scan TOC');
        }
        renderAdvancedProgress(5, 'Đã đưa Scan TOC vào hàng đợi...', 'running');
        return await pollScanJob(jobid);
    }

    async function pollScanJob(jobid) {
        let last = null;
        for (let i = 0; i < 240; i++) {
            const data = await postJson('scanjobstatus', {jobid: jobid});
            const job = data.job || {};
            last = data;
            renderAdvancedProgress(parseInt(job.progress || 5, 10), job.message || job.steptext || 'Đang xử lý...', job.status === 'failed' ? 'error' : 'running');
            if (job.status === 'done') {
                const rows = data.rows || [];
                renderAdvancedProgress(100, data.message || ('Hoàn tất, +' + rows.length + ' rows'), 'done');
                return data;
            }
            if (job.status === 'failed') {
                throw new Error(job.errormsg || job.message || 'Scan TOC thất bại');
            }
            await new Promise(resolve => setTimeout(resolve, 2000));
        }
        throw new Error((last && last.message) ? last.message : 'Scan TOC chưa hoàn tất, hãy kiểm tra cron.');
    }

    document.getElementById('local-aisgk-scan').addEventListener('click', async function() {
        try {
            renderRows([{}]);
            setStatus('Queued');
            const mode = document.getElementById('local-aisgk-advancedscan').checked ? 'advanced' : 'ocr';
            const data = await startScanJob(mode);
            renderRows(data.rows || []);
            setStatus('✓ Done, +' + ((data.rows || []).length) + ' rows');
            setDraft(data.message || ('✓ Done, +' + ((data.rows || []).length) + ' rows'));
        } catch (err) {
            setStatus('Failed');
            renderAdvancedProgress(100, 'Scan TOC thất bại', 'error');
            window.localAisgkMsgBox(err.message);
        }
    });

    const aiBtn = document.getElementById('local-aisgk-ai');

    aiBtn.addEventListener('click', async function() {
        const pagerange = (document.getElementById('local-aisgk-page').value || '').trim();
        if (!pagerange) {
            setStatus('Thiếu trang');
            setDraft('Hãy nhập TOC page trước khi chạy AI');
            document.getElementById('local-aisgk-page').focus();
            return;
        }
        try {
            renderRows([{}]);
            setStatus('AI queued');
            const data = await startScanJob('ai');
            renderRows(data.rows || []);
            setStatus('✓ Done, +' + ((data.rows || []).length) + ' rows');
            setDraft(data.message || ('✓ Done, +' + ((data.rows || []).length) + ' rows'));
        } catch (err) {
            setStatus('Failed');
            renderAdvancedProgress(100, 'AI extract thất bại', 'error');
            window.localAisgkMsgBox(err.message || 'AI extract failed');
        }
    });

    document.getElementById('local-aisgk-save').addEventListener('click', async function() {
        try {
            const ok = localAisgkValidateRows();
            if (!ok) {
                const firstInvalid = document.querySelector('#local-aisgk-toc-table tbody tr.local-aisgk-row-invalid');
                if (firstInvalid) {
                    firstInvalid.scrollIntoView({behavior: 'smooth', block: 'center'});
                }
                setStatus('⚠ Dữ liệu chưa hợp lệ');
                return;
            }
            setStatus('Saving');
            const data = await postJson('save', {rows: rowsFromTable()}, 'Saving');
            renderRows(data.rows);
            setStatus('✓ Done, +' + data.rows.length + ' rows');
        } catch (err) {
            setStatus('Failed');
            window.localAisgkMsgBox(err.message);
        }
    });

    document.getElementById('local-aisgk-restore').addEventListener('click', async function() {
        try {
            setStatus('Restoring');
            const data = await postJson('restore', {}, 'Restoring');
            renderRows(data.rows);
            setStatus('✓ Done, +' + data.rows.length + ' rows');
        } catch (err) {
            setStatus('Failed');
            window.localAisgkMsgBox(err.message);
        }
    });

    function refreshParentCoursePage() {
        try {
            if (window.parent && window.parent !== window && window.parent.location) {
                window.parent.location.reload();
                return true;
            }
        } catch (e) {
            // Ignore cross-frame refresh errors.
        }
        return false;
    }

    document.getElementById('local-aisgk-delete').addEventListener('click', async function() {
        if (!confirm('Bạn có chắc muốn xóa toàn bộ mục lục?')) {
            return;
        }
        try {
            setStatus('Deleting');
            await postJson('delete', {}, 'Deleting');
            renderRows([{}]);
            setStatus('✓ Done, +0 rows');
        } catch (err) {
            setStatus('Failed');
            window.localAisgkMsgBox(err.message);
        }
    });


    const deleteLessonsBtn = document.getElementById('local-aisgk-delete-lessons');
    if (deleteLessonsBtn) {
        deleteLessonsBtn.addEventListener('click', async function() {
            if (!confirm('Bạn có chắc muốn xóa toàn bộ bài học đã tạo từ mục lục?')) {
                return;
            }
            try {
                deleteLessonsBtn.disabled = true;
                setStatus('Đang xóa bài học');
                setDraft('Đang xóa toàn bộ bài học đã tạo từ mục lục...');

                const data = await postJson('deletelessons', {}, 'Deleting lessons');

                setStatus('✓ Done');
                setDraft(data.message || 'Đã xóa toàn bộ bài học đã tạo.');
                refreshParentCoursePage();
            } catch (err) {
                setStatus('Failed');
                window.localAisgkMsgBox(err.message || 'Xóa bài học thất bại');
            } finally {
                deleteLessonsBtn.disabled = false;
            }
        });
    }

    document.getElementById('local-aisgk-create').addEventListener('click', async function() {
        const createBtn = document.getElementById('local-aisgk-create');

        try {
            createBtn.disabled = true;
            setStatus('Creating lessons');
            setDraft('Đang tạo/cập nhật bài học từ dữ liệu đã Save trong DB...');

            const data = await postJson('createtopics', {}, 'Creating topics');

            setStatus('✓ Done');
            setDraft(data.message || 'Đã tạo/cập nhật bài học.');
            refreshParentCoursePage();
        } catch (err) {
            setStatus('Failed');
            window.localAisgkMsgBox(err.message || 'Tạo bài học thất bại');
        } finally {
            createBtn.disabled = false;
        }
    });

    renumber();
})();


window.localAisgkMsgBox=function(msg){
 try{
   var old=document.querySelector('.local-aisgk-msgbox');
   if(old){old.remove();}
   var d=document.createElement('div');
   d.className='local-aisgk-msgbox';
   d.innerHTML=msg;
   document.body.appendChild(d);
   setTimeout(function(){
      if(d.parentNode){d.parentNode.removeChild(d);}
   },2600);
 }catch(e){}
};
