<?php
require_once(__DIR__ . '/../../config.php');
require_once($CFG->libdir . '/adminlib.php');

use local_aisgk\local\service\school_year_backup_service;

$context = context_system::instance();
require_login();
require_capability('moodle/site:config', $context);
$PAGE->set_context($context);

$action = optional_param('action', '', PARAM_ALPHAEXT);
$name = optional_param('name', '', PARAM_TEXT);
$mode = optional_param('mode', 'inherit', PARAM_ALPHA);
$message = '';
$error = '';

if ($action === 'create' && confirm_sesskey()) {
    try {
        $record = school_year_backup_service::create_new_school_year_shell($name, $mode);
        $message = get_string('newschoolyearcreated', 'local_aisgk', s($record->name));
    } catch (Throwable $e) {
        $error = $e->getMessage();
    }
}

$PAGE->set_url(new moodle_url('/local/aisgk/year_new.php'));
$PAGE->set_title(get_string('newschoolyear', 'local_aisgk'));
$PAGE->set_heading(get_string('alsm', 'local_aisgk'));
$PAGE->set_pagelayout('standard');

$now = time();
$y = (int)date('Y', $now);
$m = (int)date('n', $now);
$start = ($m >= 8) ? $y : $y;
$defaultname = ($start) . '-' . ($start + 1);
$years = $DB->get_records('local_aisgk_school_year', null, 'timecreated DESC', '*', 0, 20);

echo $OUTPUT->header();
echo html_writer::tag('h2', get_string('newschoolyear', 'local_aisgk'));
if ($message) {
    echo $OUTPUT->notification($message, 'notifysuccess');
}
if ($error) {
    echo $OUTPUT->notification($error, 'notifyproblem');
}

echo html_writer::tag('div', get_string('newschoolyearintro', 'local_aisgk'), ['class' => 'alert alert-info']);

echo html_writer::start_tag('div', ['class' => 'card mb-3']);
echo html_writer::start_tag('div', ['class' => 'card-body']);
echo html_writer::start_tag('form', ['method' => 'post', 'action' => $PAGE->url->out(false)]);
echo html_writer::empty_tag('input', ['type' => 'hidden', 'name' => 'sesskey', 'value' => sesskey()]);
echo html_writer::empty_tag('input', ['type' => 'hidden', 'name' => 'action', 'value' => 'create']);
echo html_writer::tag('label', get_string('schoolyearname', 'local_aisgk'), ['for' => 'id_name']);
echo html_writer::empty_tag('input', ['type' => 'text', 'class' => 'form-control mb-3', 'id' => 'id_name', 'name' => 'name', 'value' => s($defaultname), 'placeholder' => '2026-2027']);
echo html_writer::tag('label', get_string('newschoolyearmode', 'local_aisgk'), ['for' => 'id_mode']);
echo html_writer::select([
    'inherit' => get_string('modeinherit', 'local_aisgk'),
    'wipe' => get_string('modewipe', 'local_aisgk'),
], 'mode', 'inherit', false, ['id' => 'id_mode', 'class' => 'form-control mb-3']);
echo html_writer::tag('div', get_string('newschoolyearnodelete', 'local_aisgk'), ['class' => 'alert alert-warning']);
echo html_writer::tag('button', get_string('createnewschoolyear', 'local_aisgk'), ['type' => 'submit', 'class' => 'btn btn-primary']);
echo html_writer::end_tag('form');
echo html_writer::end_tag('div');
echo html_writer::end_tag('div');

echo html_writer::tag('h3', get_string('schoolyearlist', 'local_aisgk'));
$table = new html_table();
$table->head = [get_string('schoolyear', 'local_aisgk'), get_string('status'), get_string('timecreated', 'local_aisgk'), get_string('config', 'local_aisgk')];
foreach ($years as $yr) {
    $cfg = json_decode((string)$yr->configjson, true) ?: [];
    $table->data[] = [s($yr->name), s($yr->status), userdate($yr->timecreated), html_writer::tag('code', s($cfg['transition_mode'] ?? '-'))];
}
echo html_writer::table($table);

echo html_writer::link(new moodle_url('/local/aisgk/year_inherit.php'), get_string('inheritdata', 'local_aisgk'), ['class' => 'btn btn-info']);

echo html_writer::tag('p', html_writer::link(new moodle_url('/local/aisgk/index.php'), get_string('alsm_quay_lai_alsm_toan_truong', 'local_aisgk'), ['class' => 'btn btn-secondary mt-3']));
echo $OUTPUT->footer();
