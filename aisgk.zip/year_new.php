<?php
require_once(__DIR__ . '/../../config.php');

$context = context_system::instance();
$PAGE->set_context($context);
require_login();
require_capability('moodle/site:config', $context);

require_once($CFG->libdir . '/adminlib.php');

use local_aisgk\local\service\school_year_backup_service;

$action = optional_param('action', '', PARAM_ALPHAEXT);
$name = optional_param('name', '', PARAM_TEXT);
$mode = optional_param('mode', 'inherit', PARAM_ALPHA);
$inherititems = optional_param_array('inherititems', [], PARAM_ALPHANUMEXT);
$message = '';
$error = '';

$protectedgroups = school_year_backup_service::get_hard_protected_groups();
$datagroups = school_year_backup_service::get_inheritance_groups();

if ($action === 'create' && confirm_sesskey()) {
    try {
        $validkeys = array_keys($datagroups);
        $selected = array_values(array_intersect($inherititems, $validkeys));
        if ($mode === 'inherit') {
            $inheritgroups = $selected;
            $deletegroups = array_values(array_diff($validkeys, $selected));
        } else {
            $inheritgroups = [];
            $deletegroups = $validkeys;
        }
        $transitionconfig = [
            'protected_groups' => array_keys($protectedgroups),
            'inherit_groups' => $inheritgroups,
            'delete_groups' => $deletegroups,
            'ui_mode' => $mode,
        ];
        $record = school_year_backup_service::create_new_school_year_shell($name, $mode, $transitionconfig);
        $record = school_year_backup_service::apply_new_school_year_transition((int)$record->id);
        $message = get_string('newschoolyearapplied', 'local_aisgk', s($record->name));
    } catch (Throwable $e) {
        $error = $e->getMessage();
    }
}

$PAGE->set_url(new moodle_url('/local/aisgk/year_new.php'));
$PAGE->set_title(get_string('newschoolyear', 'local_aisgk'));
$PAGE->set_heading(get_string('newschoolyear', 'local_aisgk'));
$PAGE->set_pagelayout('standard');

$activeyear = school_year_backup_service::get_active_school_year();
$defaultname = $activeyear ? school_year_backup_service::get_next_school_year_name_from_active() : school_year_backup_service::get_default_school_year_name_for_empty_site();
$readonlyyear = $activeyear ? ['readonly' => 'readonly'] : [];
$years = $DB->get_records('local_aisgk_school_year', null, 'timecreated DESC', '*', 0, 20);

echo $OUTPUT->header();
if ($message) {
    echo $OUTPUT->notification($message, 'notifysuccess');
}
if ($error) {
    echo $OUTPUT->notification($error, 'notifyproblem');
}

// School-year list first.
echo html_writer::tag('h3', get_string('schoolyearlist', 'local_aisgk'), ['class' => 'mb-2']);
$table = new html_table();
$table->attributes['class'] = 'generaltable table-sm mb-3';
$table->head = [get_string('schoolyear', 'local_aisgk'), get_string('status'), get_string('timecreated', 'local_aisgk'), get_string('newschoolyearmode', 'local_aisgk')];
foreach ($years as $yr) {
    $cfg = json_decode((string)$yr->configjson, true) ?: [];
    $table->data[] = [s($yr->name), s($yr->status), userdate($yr->timecreated), html_writer::tag('code', s($cfg['transition_mode'] ?? '-'))];
}
if (empty($table->data)) {
    $table->data[] = [get_string('none'), '-', '-', '-'];
}
echo html_writer::table($table);

$style = '.aisgk-year-stack{display:grid;grid-template-columns:1fr;gap:12px}.aisgk-box{border:1px solid #e5e7eb;border-radius:10px;padding:12px;background:#fff}.aisgk-box h4{font-size:1rem;margin:0 0 8px}.aisgk-checks{display:grid;grid-template-columns:1fr 1fr;gap:4px 18px}.aisgk-check{display:block;margin:3px 0}.aisgk-muted{color:#6b7280;font-size:.9rem}.aisgk-mode{display:flex;gap:18px;margin:8px 0 12px}.aisgk-actions{display:flex;gap:8px;align-items:center;margin-top:12px}@media(max-width:800px){.aisgk-checks{grid-template-columns:1fr}}';
echo html_writer::tag('style', $style);

echo html_writer::start_tag('div', ['class' => 'card']);
echo html_writer::start_tag('div', ['class' => 'card-body']);
echo html_writer::start_tag('form', ['method' => 'post', 'action' => $PAGE->url->out(false), 'id' => 'aisgk-year-new-form']);
echo html_writer::empty_tag('input', ['type' => 'hidden', 'name' => 'sesskey', 'value' => sesskey()]);
echo html_writer::empty_tag('input', ['type' => 'hidden', 'name' => 'action', 'value' => 'create']);

echo html_writer::tag('label', get_string('schoolyearname', 'local_aisgk'), ['for' => 'id_name']);
echo html_writer::empty_tag('input', array_merge(['type' => 'text', 'class' => 'form-control mb-2', 'id' => 'id_name', 'name' => 'name', 'value' => s($defaultname)], $readonlyyear));
if (!$activeyear) {
    echo html_writer::tag('div', get_string('noactiveschoolyearhint', 'local_aisgk'), ['class' => 'alert alert-info py-2']);
}

echo html_writer::tag('div', get_string('newschoolyearmode', 'local_aisgk'), ['class' => 'font-weight-bold']);
echo html_writer::start_tag('div', ['class' => 'aisgk-mode']);
echo html_writer::tag('label', html_writer::empty_tag('input', ['type' => 'radio', 'name' => 'mode', 'value' => 'inherit', 'checked' => 'checked']) . ' ' . get_string('modeinherit', 'local_aisgk'));
echo html_writer::tag('label', html_writer::empty_tag('input', ['type' => 'radio', 'name' => 'mode', 'value' => 'wipe']) . ' ' . get_string('modewipe', 'local_aisgk'));
echo html_writer::end_tag('div');

echo html_writer::start_tag('div', ['class' => 'aisgk-year-stack']);

// Configurable groups: top row.
echo html_writer::start_tag('div', ['class' => 'aisgk-box']);
echo html_writer::tag('h4', get_string('datagroupconfig', 'local_aisgk'));
echo html_writer::tag('div', get_string('inheritmodehint', 'local_aisgk'), ['class' => 'aisgk-muted aisgk-inherit-text']);
echo html_writer::tag('div', get_string('wipemodehint', 'local_aisgk'), ['class' => 'aisgk-muted aisgk-wipe-text', 'style' => 'display:none']);
echo html_writer::start_tag('div', ['class' => 'aisgk-checks']);
foreach ($datagroups as $key => $label) {
    echo html_writer::tag('label', html_writer::empty_tag('input', [
        'type' => 'checkbox',
        'name' => 'inherititems[]',
        'value' => $key,
        'checked' => 'checked',
        'class' => 'aisgk-data-check',
    ]) . ' ' . s($label), ['class' => 'aisgk-check']);
}
echo html_writer::end_tag('div');
echo html_writer::end_tag('div');

// Hard protected groups: bottom row, always checked and disabled.
echo html_writer::start_tag('div', ['class' => 'aisgk-box']);
echo html_writer::tag('h4', get_string('hardprotectedgroups', 'local_aisgk'));
echo html_writer::start_tag('div', ['class' => 'aisgk-checks']);
foreach ($protectedgroups as $key => $label) {
    echo html_writer::tag('label', html_writer::empty_tag('input', ['type' => 'checkbox', 'checked' => 'checked', 'disabled' => 'disabled']) . ' ' . s($label), ['class' => 'aisgk-check']);
}
echo html_writer::end_tag('div');
echo html_writer::tag('div', get_string('hardprotecteddesc', 'local_aisgk'), ['class' => 'aisgk-muted']);
echo html_writer::end_tag('div');

echo html_writer::end_tag('div');

echo html_writer::start_tag('div', ['class' => 'aisgk-actions']);
echo html_writer::tag('button', get_string('applynewschoolyear', 'local_aisgk'), ['type' => 'submit', 'class' => 'btn btn-primary']);
echo html_writer::link(new moodle_url('/local/aisgk/index.php'), get_string('back'), ['class' => 'btn btn-secondary']);
echo html_writer::end_tag('div');

echo html_writer::end_tag('form');
echo html_writer::end_tag('div');
echo html_writer::end_tag('div');

$js = <<<JS
(function(){
  function syncMode(){
    var mode = document.querySelector('input[name="mode"]:checked').value;
    var wipe = mode === 'wipe';
    document.querySelectorAll('.aisgk-data-check').forEach(function(cb){ cb.checked = true; cb.disabled = wipe; });
    document.querySelectorAll('.aisgk-inherit-text').forEach(function(e){ e.style.display = wipe ? 'none' : ''; });
    document.querySelectorAll('.aisgk-wipe-text').forEach(function(e){ e.style.display = wipe ? '' : 'none'; });
  }
  document.querySelectorAll('input[name="mode"]').forEach(function(r){ r.addEventListener('change', syncMode); });
  syncMode();
})();
JS;

echo html_writer::script($js);

echo $OUTPUT->footer();
