# 2026-05-08

- Giảm chiều cao header modal trong AMD openmodal.
- Đổi Copy mẫu thành Tải mẫu.
- Tải mẫu tạo ZIP gồm README.txt, prompt.txt và ảnh SGK màu đã render/resize.
- AJAX api phía JS không còn báo raw Unexpected token <; nếu server trả HTML sẽ hiển thị lỗi sạch hơn.
- homework_ajax samplezip tải trực tiếp file zip.
- Version 2026050802 / 0.2.90.
