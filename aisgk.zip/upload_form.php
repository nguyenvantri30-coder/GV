<?php
require('../../config.php');

use local_aisgk\form\upload_book_form;

$courseid = required_param('id', PARAM_INT);

$course = get_course($courseid);
require_login($course);

$context = context_course::instance($courseid);
require_capability('local/aisgk:managebooks', $context);

$PAGE->set_context($context);
$PAGE->set_url('/local/aisgk/upload_form.php', ['id' => $courseid]);
$PAGE->set_pagelayout('embedded');
$PAGE->set_title(get_string('uploadbook', 'local_aisgk'));

$mform = new upload_book_form();

echo $OUTPUT->header();

echo html_writer::start_div('local-aisgk-modal-page');
echo html_writer::tag('p', get_string('uploadbookhelp', 'local_aisgk'));
$mform->display();
echo html_writer::end_div();

echo $OUTPUT->footer();
