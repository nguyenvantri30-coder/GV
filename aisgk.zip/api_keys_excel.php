<?php
require('../../config.php');

global $DB, $USER;

$scope = optional_param('scope', 'system', PARAM_ALPHA);
$action = optional_param('action', 'export', PARAM_ALPHA);
$courseid = optional_param('id', 0, PARAM_INT);

if ($courseid > 0) {
    $course = get_course($courseid);
    require_login($course);
} else {
    require_login();
}
$context = context_system::instance();
$PAGE->set_context($context);

if (!in_array($scope, ['system', 'personal'], true)) {
    throw new moodle_exception('invalidrequest');
}

if ($scope === 'system') {
    if (!is_siteadmin()) {
        throw new required_capability_exception($context, 'moodle/site:config', 'nopermissions', '');
    }
    $table = 'local_aisgk_ai_keys';
    $filenameprefix = 'alsm_system_api_keys';
    $returnurl = new moodle_url('/local/aisgk/aikeys.php', ['id' => $courseid]);
} else {
    $table = 'local_aisgk_user_ai_keys';
    $filenameprefix = 'alsm_personal_api_keys_user_' . (int)$USER->id;
    $returnurl = new moodle_url('/local/aisgk/myapi.php', ['id' => $courseid]);
}

if (!$DB->get_manager()->table_exists($table)) {
    throw new moodle_exception('invalidrequest');
}

function local_aisgk_api_excel_columns(string $table): array {
    global $DB;
    $cols = array_keys($DB->get_columns($table));
    return array_values($cols);
}

function local_aisgk_api_excel_rows(string $table, string $scope): array {
    global $DB, $USER;
    if ($scope === 'personal') {
        return array_values($DB->get_records($table, ['userid' => (int)$USER->id], 'id ASC'));
    }
    return array_values($DB->get_records($table, null, 'id ASC'));
}

function local_aisgk_api_excel_cell($value): string {
    return (string)($value ?? '');
}

function local_aisgk_xlsx_col(int $index): string {
    $name = '';
    while ($index >= 0) {
        $name = chr(65 + ($index % 26)) . $name;
        $index = intdiv($index, 26) - 1;
    }
    return $name;
}

function local_aisgk_xlsx_xml($value): string {
    return htmlspecialchars((string)($value ?? ''), ENT_XML1 | ENT_COMPAT, 'UTF-8');
}

function local_aisgk_xlsx_export_rows(array $rows, string $filename): void {
    $tmp = make_temp_directory('local_aisgk') . '/' . uniqid('export_', true) . '.xlsx';
    $zip = new ZipArchive();
    if ($zip->open($tmp, ZipArchive::CREATE | ZipArchive::OVERWRITE) !== true) {
        throw new moodle_exception('Không tạo được file Excel tạm.');
    }
    $zip->addFromString('[Content_Types].xml', '<?xml version="1.0" encoding="UTF-8" standalone="yes"?>'
        . '<Types xmlns="http://schemas.openxmlformats.org/package/2006/content-types">'
        . '<Default Extension="rels" ContentType="application/vnd.openxmlformats-package.relationships+xml"/>'
        . '<Default Extension="xml" ContentType="application/xml"/>'
        . '<Override PartName="/xl/workbook.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet.main+xml"/>'
        . '<Override PartName="/xl/worksheets/sheet1.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.worksheet+xml"/>'
        . '</Types>');
    $zip->addFromString('_rels/.rels', '<?xml version="1.0" encoding="UTF-8" standalone="yes"?>'
        . '<Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships">'
        . '<Relationship Id="rId1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/officeDocument" Target="xl/workbook.xml"/>'
        . '</Relationships>');
    $zip->addFromString('xl/_rels/workbook.xml.rels', '<?xml version="1.0" encoding="UTF-8" standalone="yes"?>'
        . '<Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships">'
        . '<Relationship Id="rId1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/worksheet" Target="worksheets/sheet1.xml"/>'
        . '</Relationships>');
    $zip->addFromString('xl/workbook.xml', '<?xml version="1.0" encoding="UTF-8" standalone="yes"?>'
        . '<workbook xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main" xmlns:r="http://schemas.openxmlformats.org/officeDocument/2006/relationships">'
        . '<sheets><sheet name="Sheet1" sheetId="1" r:id="rId1"/></sheets></workbook>');
    $sheet = '<?xml version="1.0" encoding="UTF-8" standalone="yes"?>'
        . '<worksheet xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main"><sheetData>';
    foreach ($rows as $r => $row) {
        $rn = $r + 1;
        $sheet .= '<row r="' . $rn . '">';
        foreach (array_values($row) as $c => $value) {
            $ref = local_aisgk_xlsx_col($c) . $rn;
            $sheet .= '<c r="' . $ref . '" t="inlineStr"><is><t xml:space="preserve">' . local_aisgk_xlsx_xml($value) . '</t></is></c>';
        }
        $sheet .= '</row>';
    }
    $sheet .= '</sheetData></worksheet>';
    $zip->addFromString('xl/worksheets/sheet1.xml', $sheet);
    if (!$zip->close() || !is_file($tmp) || filesize($tmp) < 1000) {
        @unlink($tmp);
        throw new moodle_exception('Không đóng gói được file Excel.');
    }
    while (ob_get_level()) { @ob_end_clean(); }
    header('Content-Type: application/vnd.openxmlformats-officedocument.spreadsheetml.sheet');
    header('Content-Disposition: attachment; filename="' . $filename . '"');
    header('Content-Length: ' . filesize($tmp));
    header('Cache-Control: no-store, no-cache, must-revalidate, max-age=0');
    readfile($tmp);
    @unlink($tmp);
    exit;
}

function local_aisgk_api_excel_export(string $table, string $scope, string $filenameprefix): void {
    $columns = local_aisgk_api_excel_columns($table);
    $rows = [array_values($columns)];
    foreach (local_aisgk_api_excel_rows($table, $scope) as $row) {
        $line = [];
        foreach ($columns as $col) {
            $line[] = local_aisgk_api_excel_cell($row->$col ?? '');
        }
        $rows[] = $line;
    }
    local_aisgk_xlsx_export_rows($rows, $filenameprefix . '_' . date('Ymd_His') . '.xlsx');
}

function local_aisgk_xlsx_shared_strings(ZipArchive $zip): array {
    $xml = $zip->getFromName('xl/sharedStrings.xml');
    if ($xml === false) {
        return [];
    }
    $sx = simplexml_load_string($xml);
    if (!$sx) {
        return [];
    }
    $out = [];
    foreach ($sx->si as $si) {
        if (isset($si->t)) {
            $out[] = (string)$si->t;
        } else {
            $text = '';
            foreach ($si->r as $r) {
                $text .= (string)$r->t;
            }
            $out[] = $text;
        }
    }
    return $out;
}

function local_aisgk_xlsx_cell_text($cell, array $shared): string {
    $attrs = $cell->attributes();
    $type = isset($attrs['t']) ? (string)$attrs['t'] : '';
    if ($type === 'inlineStr') {
        return isset($cell->is->t) ? (string)$cell->is->t : '';
    }
    $v = isset($cell->v) ? (string)$cell->v : '';
    if ($type === 's') {
        return $shared[(int)$v] ?? '';
    }
    return $v;
}

function local_aisgk_api_excel_parse_xlsx(string $path): array {
    $zip = new ZipArchive();
    if ($zip->open($path) !== true) {
        return [];
    }
    $xml = $zip->getFromName('xl/worksheets/sheet1.xml');
    if ($xml === false) {
        $zip->close();
        return [];
    }
    $shared = local_aisgk_xlsx_shared_strings($zip);
    $zip->close();
    $sx = simplexml_load_string($xml);
    if (!$sx) {
        return [];
    }
    $rows = [];
    foreach ($sx->sheetData->row as $row) {
        $line = [];
        foreach ($row->c as $cell) {
            $line[] = trim(local_aisgk_xlsx_cell_text($cell, $shared));
        }
        $rows[] = $line;
    }
    return $rows;
}

function local_aisgk_api_excel_parse_csv(string $path): array {
    $rows = [];
    $fh = fopen($path, 'rb');
    if (!$fh) {
        return [];
    }
    while (($row = fgetcsv($fh)) !== false) {
        if ($row) {
            $rows[] = array_map(function($v) { return trim((string)$v); }, $row);
        }
    }
    fclose($fh);
    return $rows;
}

function local_aisgk_api_excel_import(string $table, string $scope, string $path): int {
    global $DB, $USER;
    $ext = strtolower(pathinfo((string)($_FILES['apifile']['name'] ?? ''), PATHINFO_EXTENSION));
    if ($ext === 'csv') {
        $rawrows = local_aisgk_api_excel_parse_csv($path);
    } else if ($ext === 'xlsx') {
        $rawrows = local_aisgk_api_excel_parse_xlsx($path);
    } else {
        throw new moodle_exception('Chỉ hỗ trợ file .xlsx hoặc .csv.');
    }
    if (count($rawrows) < 1) {
        throw new moodle_exception('Không đọc được file Excel. Hãy nhập file .xlsx được xuất từ nút Xuất Excel.');
    }
    $headers = array_map('trim', array_shift($rawrows));
    $columns = local_aisgk_api_excel_columns($table);
    $allowed = array_flip($columns);
    $fields = [];
    foreach ($headers as $idx => $header) {
        if (isset($allowed[$header]) && $header !== 'id') {
            $fields[$idx] = $header;
        }
    }
    if (!$fields) {
        throw new moodle_exception('File không đúng cấu trúc bảng API key.');
    }

    $intfields = ['userid','last_used','request_count_minute','total_requests_day','cooldown_until','minute_bucket','day_bucket','models_cache_at','usage_last_sync','daily_limit','daily_used','daily_reset_at','in_use_by','in_use_until','last_tokens','last_tokens_at','remain_calls_est','timecreated','timemodified','usermodified'];
    $floatfields = ['usage_remaining'];
    $now = time();
    $transaction = $DB->start_delegated_transaction();
    if ($scope === 'personal') {
        $DB->delete_records($table, ['userid' => (int)$USER->id]);
    } else {
        $DB->delete_records($table);
    }
    $count = 0;
    foreach ($rawrows as $raw) {
        $record = new stdClass();
        foreach ($fields as $idx => $field) {
            $value = $raw[$idx] ?? '';
            if (in_array($field, $intfields, true)) {
                $record->$field = (int)$value;
            } else if (in_array($field, $floatfields, true)) {
                $record->$field = is_numeric($value) ? (float)$value : 0;
            } else {
                $record->$field = (string)$value;
            }
        }
        if ($scope === 'personal') {
            $record->userid = (int)$USER->id;
        }
        if (trim((string)($record->gmail_account ?? '')) === '' && trim((string)($record->api_key ?? '')) === '') {
            continue;
        }
        foreach ($columns as $col) {
            if ($col === 'id' || isset($record->$col)) {
                continue;
            }
            if (in_array($col, $intfields, true)) {
                $record->$col = 0;
            } else if (in_array($col, $floatfields, true)) {
                $record->$col = 0;
            } else if (in_array($col, ['status'], true)) {
                $record->$col = 'active';
            } else if (in_array($col, ['category_key'], true)) {
                $record->$col = 'free';
            } else if (in_array($col, ['provider'], true)) {
                $record->$col = 'google';
            } else {
                $record->$col = '';
            }
        }
        if (empty($record->timecreated)) {
            $record->timecreated = $now;
        }
        $record->timemodified = $now;
        $record->usermodified = (int)$USER->id;
        $DB->insert_record($table, $record);
        $count++;
    }
    $transaction->allow_commit();
    return $count;
}

require_sesskey();

if ($action === 'export') {
    local_aisgk_api_excel_export($table, $scope, $filenameprefix);
}

if ($action === 'import') {
    if (empty($_FILES['apifile']['tmp_name']) || !is_uploaded_file($_FILES['apifile']['tmp_name'])) {
        redirect($returnurl, 'Chưa chọn file Excel.', null, \core\output\notification::NOTIFY_ERROR);
    }
    try {
        $count = local_aisgk_api_excel_import($table, $scope, $_FILES['apifile']['tmp_name']);
        redirect($returnurl, 'Đã nhập ' . $count . ' API key từ Excel.', null, \core\output\notification::NOTIFY_SUCCESS);
    } catch (Throwable $e) {
        redirect($returnurl, 'Lỗi nhập Excel: ' . $e->getMessage(), null, \core\output\notification::NOTIFY_ERROR);
    }
}

throw new moodle_exception('invalidrequest');
