<?php
require('../../config.php');

global $DB, $USER;

$scope = optional_param('scope', 'system', PARAM_ALPHA);
$action = optional_param('action', 'export', PARAM_ALPHA);
$courseid = optional_param('id', 0, PARAM_INT);

if ($courseid > 0) {
    $course = get_course($courseid);
    require_login($course);
} else {
    require_login();
}
$context = context_system::instance();
$PAGE->set_context($context);

if (!in_array($scope, ['system', 'personal'], true)) {
    throw new moodle_exception('invalidrequest');
}

if ($scope === 'system') {
    if (!is_siteadmin()) {
        throw new required_capability_exception($context, 'moodle/site:config', 'nopermissions', '');
    }
    $table = 'local_aisgk_ai_keys';
    $filenameprefix = 'alsm_system_api_keys';
    $returnurl = new moodle_url('/local/aisgk/aikeys.php', ['id' => $courseid]);
} else {
    $table = 'local_aisgk_user_ai_keys';
    $filenameprefix = 'alsm_personal_api_keys_user_' . (int)$USER->id;
    $returnurl = new moodle_url('/local/aisgk/myapi.php', ['id' => $courseid]);
}

if (!$DB->get_manager()->table_exists($table)) {
    throw new moodle_exception('invalidrequest');
}

function local_aisgk_api_excel_columns(string $table): array {
    global $DB;
    $cols = array_keys($DB->get_columns($table));
    return array_values($cols);
}

function local_aisgk_api_excel_rows(string $table, string $scope): array {
    global $DB, $USER;
    if ($scope === 'personal') {
        return array_values($DB->get_records($table, ['userid' => (int)$USER->id], 'id ASC'));
    }
    return array_values($DB->get_records($table, null, 'id ASC'));
}

function local_aisgk_api_excel_cell($value): string {
    $value = (string)($value ?? '');
    return htmlspecialchars($value, ENT_QUOTES | ENT_SUBSTITUTE, 'UTF-8');
}

function local_aisgk_api_excel_export(string $table, string $scope, string $filenameprefix): void {
    $columns = local_aisgk_api_excel_columns($table);
    $rows = local_aisgk_api_excel_rows($table, $scope);
    $filename = $filenameprefix . '_' . date('Ymd_His') . '.xls';
    @header('Content-Type: application/vnd.ms-excel; charset=utf-8');
    @header('Content-Disposition: attachment; filename="' . $filename . '"');
    @header('Cache-Control: no-store, no-cache, must-revalidate, max-age=0');
    echo "\xEF\xBB\xBF";
    echo '<html><head><meta charset="utf-8"><style>td,th{mso-number-format:"\\@";}</style></head><body>';
    echo '<table border="1" data-alsm-api-table="' . local_aisgk_api_excel_cell($table) . '" data-scope="' . local_aisgk_api_excel_cell($scope) . '">';
    echo '<thead><tr>';
    foreach ($columns as $col) {
        echo '<th>' . local_aisgk_api_excel_cell($col) . '</th>';
    }
    echo '</tr></thead><tbody>';
    foreach ($rows as $row) {
        echo '<tr>';
        foreach ($columns as $col) {
            echo '<td>' . local_aisgk_api_excel_cell($row->$col ?? '') . '</td>';
        }
        echo '</tr>';
    }
    echo '</tbody></table></body></html>';
    exit;
}

function local_aisgk_api_excel_parse_html_table(string $content): array {
    $content = preg_replace('/^\xEF\xBB\xBF/', '', $content);
    $rows = [];
    libxml_use_internal_errors(true);
    $dom = new DOMDocument();
    $loaded = $dom->loadHTML('<?xml encoding="utf-8" ?>' . $content);
    if (!$loaded) {
        return [];
    }
    $trs = $dom->getElementsByTagName('tr');
    foreach ($trs as $tr) {
        $cells = [];
        foreach (['th', 'td'] as $tag) {
            foreach ($tr->getElementsByTagName($tag) as $cell) {
                $cells[] = trim(html_entity_decode($cell->textContent, ENT_QUOTES | ENT_SUBSTITUTE, 'UTF-8'));
            }
            if ($cells) {
                break;
            }
        }
        if ($cells) {
            $rows[] = $cells;
        }
    }
    libxml_clear_errors();
    return $rows;
}

function local_aisgk_api_excel_parse_csv(string $path): array {
    $rows = [];
    $fh = fopen($path, 'rb');
    if (!$fh) {
        return [];
    }
    while (($row = fgetcsv($fh)) !== false) {
        if ($row) {
            $rows[] = array_map(function($v) { return trim((string)$v); }, $row);
        }
    }
    fclose($fh);
    return $rows;
}

function local_aisgk_api_excel_import(string $table, string $scope, string $path): int {
    global $DB, $USER;
    $ext = strtolower(pathinfo((string)($_FILES['apifile']['name'] ?? ''), PATHINFO_EXTENSION));
    if ($ext === 'csv') {
        $rawrows = local_aisgk_api_excel_parse_csv($path);
    } else {
        $rawrows = local_aisgk_api_excel_parse_html_table((string)file_get_contents($path));
    }
    if (count($rawrows) < 1) {
        throw new moodle_exception('Không đọc được file Excel. Hãy nhập file .xls được xuất từ nút Xuất Excel.');
    }
    $headers = array_map('trim', array_shift($rawrows));
    $columns = local_aisgk_api_excel_columns($table);
    $allowed = array_flip($columns);
    $fields = [];
    foreach ($headers as $idx => $header) {
        if (isset($allowed[$header]) && $header !== 'id') {
            $fields[$idx] = $header;
        }
    }
    if (!$fields) {
        throw new moodle_exception('File không đúng cấu trúc bảng API key.');
    }

    $intfields = ['userid','last_used','request_count_minute','total_requests_day','cooldown_until','minute_bucket','day_bucket','models_cache_at','usage_last_sync','daily_limit','daily_used','daily_reset_at','in_use_by','in_use_until','last_tokens','last_tokens_at','remain_calls_est','timecreated','timemodified','usermodified'];
    $floatfields = ['usage_remaining'];
    $now = time();
    $transaction = $DB->start_delegated_transaction();
    if ($scope === 'personal') {
        $DB->delete_records($table, ['userid' => (int)$USER->id]);
    } else {
        $DB->delete_records($table);
    }
    $count = 0;
    foreach ($rawrows as $raw) {
        $record = new stdClass();
        foreach ($fields as $idx => $field) {
            $value = $raw[$idx] ?? '';
            if (in_array($field, $intfields, true)) {
                $record->$field = (int)$value;
            } else if (in_array($field, $floatfields, true)) {
                $record->$field = is_numeric($value) ? (float)$value : 0;
            } else {
                $record->$field = (string)$value;
            }
        }
        if ($scope === 'personal') {
            $record->userid = (int)$USER->id;
        }
        if (trim((string)($record->gmail_account ?? '')) === '' && trim((string)($record->api_key ?? '')) === '') {
            continue;
        }
        foreach ($columns as $col) {
            if ($col === 'id' || isset($record->$col)) {
                continue;
            }
            if (in_array($col, $intfields, true)) {
                $record->$col = 0;
            } else if (in_array($col, $floatfields, true)) {
                $record->$col = 0;
            } else if (in_array($col, ['status'], true)) {
                $record->$col = 'active';
            } else if (in_array($col, ['category_key'], true)) {
                $record->$col = 'free';
            } else if (in_array($col, ['provider'], true)) {
                $record->$col = 'google';
            } else {
                $record->$col = '';
            }
        }
        if (empty($record->timecreated)) {
            $record->timecreated = $now;
        }
        $record->timemodified = $now;
        $record->usermodified = (int)$USER->id;
        $DB->insert_record($table, $record);
        $count++;
    }
    $transaction->allow_commit();
    return $count;
}

require_sesskey();

if ($action === 'export') {
    local_aisgk_api_excel_export($table, $scope, $filenameprefix);
}

if ($action === 'import') {
    if (empty($_FILES['apifile']['tmp_name']) || !is_uploaded_file($_FILES['apifile']['tmp_name'])) {
        redirect($returnurl, 'Chưa chọn file Excel.', null, \core\output\notification::NOTIFY_ERROR);
    }
    try {
        $count = local_aisgk_api_excel_import($table, $scope, $_FILES['apifile']['tmp_name']);
        redirect($returnurl, 'Đã nhập ' . $count . ' API key từ Excel.', null, \core\output\notification::NOTIFY_SUCCESS);
    } catch (Throwable $e) {
        redirect($returnurl, 'Lỗi nhập Excel: ' . $e->getMessage(), null, \core\output\notification::NOTIFY_ERROR);
    }
}

throw new moodle_exception('invalidrequest');
