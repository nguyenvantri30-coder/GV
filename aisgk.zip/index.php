<?php
require_once(__DIR__ . '/../../config.php');
require_once($CFG->libdir . '/adminlib.php');

admin_externalpage_setup('local_aisgk_portal');
require_capability('moodle/site:config', context_system::instance());

$PAGE->set_url(new moodle_url('/local/aisgk/index.php'));
$PAGE->set_title(get_string('alsmportal', 'local_aisgk'));
$PAGE->set_heading(get_string('alsm', 'local_aisgk'));

echo $OUTPUT->header();

$items = [
    ['num' => '①', 'title' => get_string('schoolyear', 'local_aisgk'), 'desc' => get_string('schoolyear_desc', 'local_aisgk'), 'links' => [
        [get_string('yearbackup', 'local_aisgk'), new moodle_url('/local/aisgk/year_backup.php')],
        [get_string('newschoolyear', 'local_aisgk'), new moodle_url('/local/aisgk/year_new.php')],
        [get_string('inheritdata', 'local_aisgk'), new moodle_url('/local/aisgk/year_inherit.php')],
    ]],
    ['num' => '②', 'title' => get_string('standardmaterials', 'local_aisgk'), 'desc' => get_string('standardmaterials_desc', 'local_aisgk'), 'links' => []],
    ['num' => '③', 'title' => get_string('schoolorg', 'local_aisgk'), 'desc' => get_string('schoolorg_desc', 'local_aisgk'), 'links' => []],
    ['num' => '④', 'title' => get_string('courses', 'local_aisgk'), 'desc' => get_string('courses_desc', 'local_aisgk'), 'links' => []],
    ['num' => '⑤', 'title' => get_string('learningprogress', 'local_aisgk'), 'desc' => get_string('learningprogress_desc', 'local_aisgk'), 'links' => []],
    ['num' => '⑥', 'title' => get_string('learningsupervision', 'local_aisgk'), 'desc' => get_string('learningsupervision_desc', 'local_aisgk'), 'links' => []],
    ['num' => '⑦', 'title' => get_string('competitionfund', 'local_aisgk'), 'desc' => get_string('competitionfund_desc', 'local_aisgk'), 'links' => []],
    ['num' => '⑧', 'title' => get_string('publicreports', 'local_aisgk'), 'desc' => get_string('publicreports_desc', 'local_aisgk'), 'links' => []],
];

echo html_writer::start_div('local-aisgk-admin-portal');
echo html_writer::tag('h2', get_string('alsmportal', 'local_aisgk'), ['class' => 'mb-3']);
echo html_writer::tag('p', get_string('alsmportalintro', 'local_aisgk'), ['class' => 'text-muted']);
echo html_writer::start_div('local-aisgk-admin-grid');
foreach ($items as $item) {
    echo html_writer::start_div('local-aisgk-admin-card');
    echo html_writer::tag('div', $item['num'], ['class' => 'local-aisgk-admin-num']);
    echo html_writer::tag('h3', $item['title']);
    echo html_writer::tag('p', $item['desc']);
    if (!empty($item['links'])) {
        echo html_writer::start_tag('ul');
        foreach ($item['links'] as $link) {
            echo html_writer::tag('li', html_writer::link($link[1], $link[0]));
        }
        echo html_writer::end_tag('ul');
    }
    echo html_writer::end_div();
}
echo html_writer::end_div();
echo html_writer::end_div();

echo html_writer::tag('style', '
.local-aisgk-admin-grid{display:grid;grid-template-columns:repeat(auto-fit,minmax(240px,1fr));gap:18px;margin-top:18px}.local-aisgk-admin-card{background:#fff;border:1px solid #e5e7eb;border-radius:16px;padding:18px;box-shadow:0 8px 22px rgba(15,23,42,.06);transition:transform .16s ease,box-shadow .16s ease}.local-aisgk-admin-card:hover{transform:translateY(-3px);box-shadow:0 12px 28px rgba(15,23,42,.12)}.local-aisgk-admin-num{font-size:26px;font-weight:700;margin-bottom:8px}.local-aisgk-admin-card h3{font-size:18px;margin:0 0 8px}.local-aisgk-admin-card p{min-height:42px;color:#4b5563}.local-aisgk-admin-card ul{margin:10px 0 0 18px}
');

echo $OUTPUT->footer();
