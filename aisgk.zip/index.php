<?php
// ALSM school-level portal for local_aisgk. Based on v9 hub layout, role-first content.
require_once(__DIR__ . '/../../config.php');
require_once($CFG->libdir . '/adminlib.php');

require_login();

$context = context_system::instance();
$PAGE->set_context($context);
$PAGE->set_url(new moodle_url('/local/aisgk/index.php'));
$PAGE->set_title('ALSM');
$PAGE->set_heading('');
$PAGE->set_pagelayout('standard');
// Portal is role/session-sensitive (preview role, Moodle message drawer sesskey).
// Do not let proxies/browsers reuse a page generated for another logged-in user.
$PAGE->set_cacheable(false);
$PAGE->add_body_class('local-aisgk-portal-page');
$PAGE->requires->css(new moodle_url('/local/aisgk/styles.css'));

$isadmin = is_siteadmin();
$previewrole = optional_param('alsm_preview_role', '', PARAM_ALPHA);
$allowedpreviewroles = ['admin', 'leader', 'coordinator', 'teacher', 'student', 'parent'];
if ($isadmin && $previewrole && confirm_sesskey() && in_array($previewrole, $allowedpreviewroles, true)) {
    $SESSION->local_aisgk_preview_role = $previewrole;
}
if ($isadmin && optional_param('alsm_clear_preview', 0, PARAM_BOOL) && confirm_sesskey()) {
    unset($SESSION->local_aisgk_preview_role);
}
$activepreviewrole = ($isadmin && !empty($SESSION->local_aisgk_preview_role) && in_array($SESSION->local_aisgk_preview_role, $allowedpreviewroles, true)) ? $SESSION->local_aisgk_preview_role : '';
$canmanageglobal = $isadmin || has_capability('local/aisgk:manageglobaldata', $context);
$canmanagenls = $isadmin || has_capability('local/aisgk:managenls', $context);
$canviewreports = $isadmin || has_capability('local/aisgk:viewschoolreports', $context);
$canmanageai = $isadmin || has_capability('local/aisgk:manageai', $context);
$cancoordinate = $isadmin || has_capability('local/aisgk:coordinatealsm', $context);

$mycoursesurl = new moodle_url('/my/courses.php');
if (empty($CFG->navshowmycoursecategories)) {
    $mycoursesurl = new moodle_url('/my/');
}
$adminsettingsurl = new moodle_url('/admin/settings.php', ['section' => 'localplugins']);

$systemdata = new moodle_url('/local/aisgk/systemdata/index.php');
$tkburl = new moodle_url('/local/aisgk/systemdata/tkb.php');
$booksurl = new moodle_url('/local/aisgk/systemdata/books.php');
$assignurl = new moodle_url('/local/aisgk/systemdata/assignments.php');
$nlsurl = new moodle_url('/local/aisgk/nls/index.php');
$reportsurl = new moodle_url('/local/aisgk/reports/index.php');

/**
 * Detect the real ALSM portal profile for the current user.
 *
 * Important: never fall back to teacher. A normal student normally has no
 * system-level ALSM capability on this portal page, so a teacher fallback makes
 * students see teacher cards. Course teacher/student roles are detected from
 * role assignments when no ALSM system role is present.
 *
 * @param context_system $context
 * @return string admin|leader|coordinator|teacher|student|parent
 */
function local_aisgk_detect_portal_profile(context_system $context): string {
    global $DB, $USER;

    if (is_siteadmin()) {
        return 'admin';
    }

    // Explicit ALSM school roles/capabilities win first.
    if (has_capability('local/aisgk:viewschoolreports', $context)
            && has_capability('local/aisgk:coordinatealsm', $context)) {
        return 'leader';
    }
    if (has_capability('local/aisgk:manageglobaldata', $context)
            || has_capability('local/aisgk:managenls', $context)) {
        return 'coordinator';
    }

    // Parent role can be assigned in user context in Moodle installs that use it.
    $parentsql = "SELECT 1
                    FROM {role_assignments} ra
                    JOIN {role} r ON r.id = ra.roleid
                    JOIN {context} ctx ON ctx.id = ra.contextid
                   WHERE ra.userid = :userid
                     AND r.shortname = :parentrole
                     AND ctx.contextlevel = :usercontext";
    if ($DB->record_exists_sql($parentsql, [
        'userid' => $USER->id,
        'parentrole' => 'parent',
        'usercontext' => CONTEXT_USER,
    ])) {
        return 'parent';
    }

    // Detect real course teaching roles. This is deliberately checked before
    // student, because many teachers are also enrolled as students in sandboxes.
    $teachingsql = "SELECT 1
                      FROM {role_assignments} ra
                      JOIN {role} r ON r.id = ra.roleid
                      JOIN {context} ctx ON ctx.id = ra.contextid
                     WHERE ra.userid = :userid
                       AND ctx.contextlevel = :coursecontext
                       AND r.shortname IN ('editingteacher', 'teacher', 'coursecreator')";
    if ($DB->record_exists_sql($teachingsql, [
        'userid' => $USER->id,
        'coursecontext' => CONTEXT_COURSE,
    ])) {
        return 'teacher';
    }

    // Normal learner view. If the account has no ALSM school role and is not a
    // course teacher, the safe/default portal is the student portal.
    return 'student';
}

function local_aisgk_apply_portal_profile_titles(string $profile): array {
    switch ($profile) {
        case 'admin':
            return [get_string('alsm_quan_tri_alsm', 'local_aisgk'), get_string('alsm_du_lieu_nen_ai_quyen_su', 'local_aisgk')];
        case 'leader':
            return [get_string('alsm_dieu_hanh_nha_truong', 'local_aisgk'), get_string('alsm_chat_luong_tien_do_canh_bao', 'local_aisgk')];
        case 'coordinator':
            return [get_string('alsm_phu_trach_du_lieu', 'local_aisgk'), get_string('alsm_hoc_lieu_nen_tkb_nls_sgk', 'local_aisgk')];
        case 'parent':
            return [get_string('alsm_phu_huynh', 'local_aisgk'), get_string('alsm_bao_cao_tuan_canh_bao_hoc', 'local_aisgk')];
        case 'student':
            return [get_string('alsm_hoc_sinh', 'local_aisgk'), get_string('alsm_bai_hom_tien_do_nang_luc', 'local_aisgk')];
        case 'teacher':
        default:
            return [get_string('alsm_lop_hoc_toi', 'local_aisgk'), get_string('alsm_giao_bai_doi_phan_loai_don', 'local_aisgk')];
    }
}

$profile = local_aisgk_detect_portal_profile($context);
[$profiletitle, $profilesubtitle] = local_aisgk_apply_portal_profile_titles($profile);

function local_aisgk_url_with_tab(moodle_url $url, string $tab): moodle_url {
    $newurl = new moodle_url($url);
    $newurl->param('tab', $tab);
    return $newurl;
}

$modulesbyprofile = [];

$modulesbyprofile['admin'] = [
    ['key' => 'foundation', 'pos' => 'left-1', 'title' => get_string('alsm_hoc_lieu_nen', 'local_aisgk'), 'desc' => get_string('alsm_du_lieu_dung_chung_toan_truong', 'local_aisgk'), 'enabled' => $canmanageglobal || $canmanagenls, 'children' => [
        ['title' => get_string('alsm_tong_quan_hoc_lieu', 'local_aisgk'), 'url' => $systemdata, 'enabled' => $canmanageglobal],
        ['title' => get_string('alsm_tkb_khdh_toan_truong', 'local_aisgk'), 'url' => $tkburl, 'enabled' => $canmanageglobal],
        ['title' => get_string('alsm_danh_muc_nls_chuan', 'local_aisgk'), 'url' => $nlsurl, 'enabled' => $canmanagenls],
        ['title' => get_string('alsm_kho_sgk_dung_chung', 'local_aisgk'), 'url' => $booksurl, 'enabled' => $canmanageglobal],
        ['title' => get_string('alsm_phan_cong_gv_lop_mon', 'local_aisgk'), 'url' => $assignurl, 'enabled' => $canmanageglobal],
    ]],
    ['key' => 'ai', 'pos' => 'right-1', 'title' => get_string('alsm_ai', 'local_aisgk'), 'desc' => get_string('alsm_quan_ly_model_api_key_hang', 'local_aisgk'), 'enabled' => $canmanageai, 'children' => [
        ['title' => get_string('alsm_cau_hinh_plugin_alsm', 'local_aisgk'), 'url' => $adminsettingsurl, 'enabled' => $canmanageai],
        ['title' => 'API key / model AI', 'url' => new moodle_url('/local/aisgk/aikeys.php'), 'enabled' => $canmanageai],
        ['title' => get_string('alsm_kiem_tra_sinh_anh_text', 'local_aisgk'), 'url' => new moodle_url('/local/aisgk/myapi.php'), 'enabled' => $canmanageai],
    ]],
    ['key' => 'courses', 'pos' => 'left-2', 'title' => get_string('alsm_khoa_hoc', 'local_aisgk'), 'desc' => get_string('alsm_di_toi_danh_sach_khoa_hoc', 'local_aisgk'), 'url' => $mycoursesurl, 'enabled' => true],
    ['key' => 'monitoring', 'pos' => 'right-2', 'title' => get_string('alsm_giam_sat', 'local_aisgk'), 'desc' => get_string('alsm_doi_muc_su_dung_tien_do', 'local_aisgk'), 'url' => $reportsurl, 'enabled' => $canviewreports || $cancoordinate],
    ['key' => 'assessment', 'pos' => 'left-3', 'title' => get_string('alsm_nang_luc', 'local_aisgk'), 'desc' => get_string('alsm_xem_ban_do_nang_luc_nang', 'local_aisgk'), 'url' => local_aisgk_url_with_tab($reportsurl, 'competency'), 'enabled' => $canviewreports],
    ['key' => 'reports', 'pos' => 'right-3', 'title' => get_string('alsm_bao_cao', 'local_aisgk'), 'desc' => get_string('alsm_bao_cao_bgh_to_chuyen_mon', 'local_aisgk'), 'url' => $reportsurl, 'enabled' => $canviewreports],
    ['key' => 'parents', 'pos' => 'left-4', 'title' => get_string('alsm_phu_huynh_2', 'local_aisgk'), 'desc' => get_string('alsm_doi_trang_thai_bao_cao_tuan', 'local_aisgk'), 'url' => local_aisgk_url_with_tab($reportsurl, 'parents'), 'enabled' => $canviewreports || $cancoordinate],
    ['key' => 'competition', 'pos' => 'right-4', 'title' => get_string('alsm_thi_dua', 'local_aisgk'), 'desc' => get_string('alsm_bang_xep_hang_lop_khoi_huy', 'local_aisgk'), 'url' => local_aisgk_url_with_tab($reportsurl, 'competition'), 'enabled' => $canviewreports || $cancoordinate],
];

$modulesbyprofile['leader'] = [
    ['key' => 'overview', 'pos' => 'left-1', 'title' => get_string('alsm_toan_canh', 'local_aisgk'), 'desc' => get_string('alsm_nhin_nhanh_ty_le_hoan_thanh', 'local_aisgk'), 'url' => $reportsurl, 'enabled' => $canviewreports],
    ['key' => 'quality', 'pos' => 'right-1', 'title' => get_string('alsm_chat_luong', 'local_aisgk'), 'desc' => get_string('alsm_phan_tich_ket_qua_hoc_tap', 'local_aisgk'), 'url' => local_aisgk_url_with_tab($reportsurl, 'quality'), 'enabled' => $canviewreports],
    ['key' => 'warning', 'pos' => 'left-2', 'title' => get_string('alsm_canh_bao', 'local_aisgk'), 'desc' => get_string('alsm_danh_sach_lop_hoc_sinh_can', 'local_aisgk'), 'url' => local_aisgk_url_with_tab($reportsurl, 'warnings'), 'enabled' => $canviewreports],
    ['key' => 'progress', 'pos' => 'right-2', 'title' => get_string('alsm_chuyen_mon', 'local_aisgk'), 'desc' => get_string('alsm_doi_pl3_khdh_tkb_do_phu', 'local_aisgk'), 'url' => local_aisgk_url_with_tab($reportsurl, 'teaching'), 'enabled' => $canviewreports || $cancoordinate],
    ['key' => 'competition', 'pos' => 'left-3', 'title' => get_string('alsm_thi_dua', 'local_aisgk'), 'desc' => get_string('alsm_top_lop_khoi_phong_trao_hoc', 'local_aisgk'), 'url' => local_aisgk_url_with_tab($reportsurl, 'competition'), 'enabled' => $canviewreports],
    ['key' => 'parents', 'pos' => 'right-3', 'title' => get_string('alsm_phu_huynh_2', 'local_aisgk'), 'desc' => get_string('alsm_tinh_trang_gui_bao_cao_tuan', 'local_aisgk'), 'url' => local_aisgk_url_with_tab($reportsurl, 'parents'), 'enabled' => $canviewreports],
    ['key' => 'foundation', 'pos' => 'left-4', 'title' => get_string('alsm_hoc_lieu', 'local_aisgk'), 'desc' => get_string('alsm_kiem_tra_du_lieu_nen_toan', 'local_aisgk'), 'url' => $systemdata, 'enabled' => $canmanageglobal || $canmanagenls || $cancoordinate],
    ['key' => 'reporting', 'pos' => 'right-4', 'title' => get_string('alsm_bao_cao_bgh', 'local_aisgk'), 'desc' => get_string('alsm_xuat_bao_cao_dieu_hanh_minh', 'local_aisgk'), 'url' => $reportsurl, 'enabled' => $canviewreports],
];

$modulesbyprofile['coordinator'] = [
    ['key' => 'tkb', 'pos' => 'left-1', 'title' => 'TKB/KHDH', 'desc' => get_string('alsm_upload_kiem_tra_thoi_khoa_bieu', 'local_aisgk'), 'url' => $tkburl, 'enabled' => $canmanageglobal],
    ['key' => 'nls', 'pos' => 'right-1', 'title' => get_string('alsm_nls_chuan', 'local_aisgk'), 'desc' => get_string('alsm_quan_ly_catalog_nang_luc_so', 'local_aisgk'), 'url' => $nlsurl, 'enabled' => $canmanagenls],
    ['key' => 'books', 'pos' => 'left-2', 'title' => 'Kho SGK', 'desc' => get_string('alsm_quan_ly_sgk_pdf_anh_dung', 'local_aisgk'), 'url' => $booksurl, 'enabled' => $canmanageglobal],
    ['key' => 'assignments', 'pos' => 'right-2', 'title' => get_string('alsm_phan_cong', 'local_aisgk'), 'desc' => get_string('alsm_dong_bo_giao_vien_lop_mon', 'local_aisgk'), 'url' => $assignurl, 'enabled' => $canmanageglobal],
    ['key' => 'pl3', 'pos' => 'left-3', 'title' => 'PL3', 'desc' => get_string('alsm_doi_pl3_toan_truong_ty_le', 'local_aisgk'), 'url' => local_aisgk_url_with_tab($systemdata, 'pl3'), 'enabled' => $canmanageglobal || $cancoordinate],
    ['key' => 'validate', 'pos' => 'right-3', 'title' => get_string('alsm_kiem_tra', 'local_aisgk'), 'desc' => get_string('alsm_validate_du_lieu_import_ma_nls', 'local_aisgk'), 'url' => local_aisgk_url_with_tab($systemdata, 'validate'), 'enabled' => $canmanageglobal || $canmanagenls],
    ['key' => 'reports', 'pos' => 'left-4', 'title' => get_string('alsm_bao_cao', 'local_aisgk'), 'desc' => get_string('alsm_xem_trang_thai_du_lieu_nen', 'local_aisgk'), 'url' => $reportsurl, 'enabled' => $canviewreports || $cancoordinate],
    ['key' => 'courses', 'pos' => 'right-4', 'title' => get_string('alsm_khoa_hoc', 'local_aisgk'), 'desc' => get_string('alsm_di_toi_khoa_hoc_kiem_tra', 'local_aisgk'), 'url' => $mycoursesurl, 'enabled' => true],
];

$modulesbyprofile['teacher'] = [
    ['key' => 'today', 'pos' => 'left-1', 'title' => get_string('alsm_hom', 'local_aisgk'), 'desc' => get_string('alsm_viec_can_lam_bai_can_giao', 'local_aisgk'), 'url' => $mycoursesurl, 'enabled' => true],
    ['key' => 'create', 'pos' => 'right-1', 'title' => get_string('alsm_sinh_bai', 'local_aisgk'), 'desc' => get_string('alsm_khoa_hoc_sinh_bai_sgk_pl3', 'local_aisgk'), 'url' => $mycoursesurl, 'enabled' => true],
    ['key' => 'deliver', 'pos' => 'left-2', 'title' => get_string('alsm_giao_bai', 'local_aisgk'), 'desc' => get_string('alsm_duyet_bai_giao_nhiem_vu_dat', 'local_aisgk'), 'url' => $mycoursesurl, 'enabled' => true],
    ['key' => 'tracking', 'pos' => 'right-2', 'title' => get_string('alsm_doi', 'local_aisgk'), 'desc' => get_string('alsm_xem_hoc_sinh_lam_chua_lam', 'local_aisgk'), 'url' => $mycoursesurl, 'enabled' => true],
    ['key' => 'support', 'pos' => 'left-3', 'title' => get_string('alsm_ho_tro', 'local_aisgk'), 'desc' => get_string('alsm_phan_loai_hoc_sinh_goi_y', 'local_aisgk'), 'url' => $mycoursesurl, 'enabled' => true],
    ['key' => 'competency', 'pos' => 'right-3', 'title' => get_string('alsm_nang_luc', 'local_aisgk'), 'desc' => get_string('alsm_doi_nang_luc_mon_hoc_pham', 'local_aisgk'), 'url' => $mycoursesurl, 'enabled' => true],
    ['key' => 'parents', 'pos' => 'left-4', 'title' => get_string('alsm_phu_huynh_2', 'local_aisgk'), 'desc' => get_string('alsm_xem_noi_dung_bao_cao_tuan', 'local_aisgk'), 'url' => $mycoursesurl, 'enabled' => true],
    ['key' => 'reports', 'pos' => 'right-4', 'title' => get_string('alsm_bao_cao_lop', 'local_aisgk'), 'desc' => get_string('alsm_tong_hop_lop_day_hoan_thanh', 'local_aisgk'), 'url' => $mycoursesurl, 'enabled' => true],
];


$modulesbyprofile['student'] = [
    ['key' => 'tasks', 'pos' => 'left-1', 'title' => get_string('alsm_bai_hom', 'local_aisgk'), 'desc' => get_string('alsm_xem_nhiem_vu_duoc_giao_han', 'local_aisgk'), 'url' => $mycoursesurl, 'enabled' => true],
    ['key' => 'progress', 'pos' => 'right-1', 'title' => get_string('alsm_tien_do', 'local_aisgk'), 'desc' => get_string('alsm_doi_diem_so_lan_lam_bai', 'local_aisgk'), 'url' => $mycoursesurl, 'enabled' => true],
    ['key' => 'competency', 'pos' => 'left-2', 'title' => get_string('alsm_nang_luc', 'local_aisgk'), 'desc' => get_string('alsm_ban_do_nang_luc_mon_hoc', 'local_aisgk'), 'url' => $mycoursesurl, 'enabled' => true],
    ['key' => 'practice', 'pos' => 'right-2', 'title' => get_string('alsm_luyen_them', 'local_aisgk'), 'desc' => get_string('alsm_bai_tap_bo_tro_lo_hong', 'local_aisgk'), 'url' => $mycoursesurl, 'enabled' => true],
    ['key' => 'competition', 'pos' => 'left-3', 'title' => get_string('alsm_thi_dua', 'local_aisgk'), 'desc' => get_string('alsm_xep_hang_huy_hieu_diem_tien', 'local_aisgk'), 'url' => $mycoursesurl, 'enabled' => true],
    ['key' => 'help', 'pos' => 'right-3', 'title' => get_string('alsm_can_ho_tro', 'local_aisgk'), 'desc' => get_string('alsm_xem_goi_y_on_tap_noi', 'local_aisgk'), 'url' => $mycoursesurl, 'enabled' => true],
];

$modulesbyprofile['parent'] = [
    ['key' => 'weekly', 'pos' => 'left-1', 'title' => get_string('alsm_bao_cao_tuan', 'local_aisgk'), 'desc' => get_string('alsm_ket_qua_hoc_tap_bai_lam', 'local_aisgk'), 'url' => $reportsurl, 'enabled' => true],
    ['key' => 'alerts', 'pos' => 'right-1', 'title' => get_string('alsm_canh_bao', 'local_aisgk'), 'desc' => get_string('alsm_tin_can_phu_huynh_phoi_hop', 'local_aisgk'), 'url' => local_aisgk_url_with_tab($reportsurl, 'parents'), 'enabled' => true],
    ['key' => 'progress', 'pos' => 'left-2', 'title' => get_string('alsm_tien_bo', 'local_aisgk'), 'desc' => get_string('alsm_doi_xu_huong_hoc_tap_thay', 'local_aisgk'), 'url' => local_aisgk_url_with_tab($reportsurl, 'progress'), 'enabled' => true],
    ['key' => 'support', 'pos' => 'right-2', 'title' => get_string('alsm_ho_tro_tai_nha', 'local_aisgk'), 'desc' => get_string('alsm_goi_y_phu_huynh_ho_tro', 'local_aisgk'), 'url' => local_aisgk_url_with_tab($reportsurl, 'support'), 'enabled' => true],
];

if ($activepreviewrole) {
    $profile = $activepreviewrole;
    if ($profile === 'admin') {
        $profiletitle = get_string('alsm_xem_thu_admin', 'local_aisgk');
        $profilesubtitle = get_string('alsm_mo_phong_giao_dien_quan_tri', 'local_aisgk');
    } else if ($profile === 'leader') {
        $profiletitle = get_string('alsm_xem_thu_bgh', 'local_aisgk');
        $profilesubtitle = get_string('alsm_mo_phong_giao_dien_hieu_truong', 'local_aisgk');
    } else if ($profile === 'coordinator') {
        $profiletitle = get_string('alsm_xem_thu_phu_trach', 'local_aisgk');
        $profilesubtitle = get_string('alsm_mo_phong_giao_dien_giao_vien', 'local_aisgk');
    } else if ($profile === 'student') {
        $profiletitle = get_string('alsm_xem_thu_hoc_sinh', 'local_aisgk');
        $profilesubtitle = get_string('alsm_mo_phong_ban_do_hoc_tap', 'local_aisgk');
    } else if ($profile === 'parent') {
        $profiletitle = get_string('alsm_xem_thu_phu_huynh', 'local_aisgk');
        $profilesubtitle = get_string('alsm_mo_phong_bao_cao_tuan_canh', 'local_aisgk');
    } else {
        $profiletitle = get_string('alsm_xem_thu_giao_vien', 'local_aisgk');
        $profilesubtitle = get_string('alsm_mo_phong_giao_dien_lop_hoc', 'local_aisgk');
    }
}

$modules = $modulesbyprofile[$profile] ?? $modulesbyprofile['student'];

function local_aisgk_portal_card(array $module): string {
    $title = s($module['title']);
    $desc = s($module['desc']);
    $enabled = !empty($module['enabled']);
    $pos = !empty($module['pos']) ? ' pos-' . clean_param($module['pos'], PARAM_ALPHANUMEXT) : '';
    $side = (strpos($pos, 'left-') !== false) ? ' side-left' : ((strpos($pos, 'right-') !== false) ? ' side-right' : '');
    $hassubmenu = !empty($module['children']);
    $classes = 'alsm-portal-card' . $pos . $side . ($enabled ? ' is-enabled' : ' is-disabled') . ($hassubmenu ? ' has-submenu' : '');
    $lock = $enabled ? '' : '<span class="alsm-lock" aria-hidden="true">🔒</span>';
    $inner = $lock . '<span class="alsm-card-title">' . $title . '</span><span class="alsm-card-node" aria-hidden="true"></span>';

    if ($hassubmenu) {
        $submenu = '<div class="alsm-submenu" aria-label="' . $title . '">';
        $submenu .= '<span class="alsm-subitem alsm-subdesc" aria-disabled="true">' . $desc . '</span>';
        foreach ($module['children'] as $child) {
            $ctitle = s($child['title']);
            if (!empty($child['enabled'])) {
                $submenu .= html_writer::link($child['url'], $ctitle, ['class' => 'alsm-subitem']);
            } else {
                $submenu .= '<span class="alsm-subitem is-disabled">' . $ctitle . '</span>';
            }
        }
        $submenu .= '</div>';
        return '<div class="' . $classes . '" tabindex="0" data-module="' . s($module['key']) . '" data-desc="' . $desc . '">' . $inner . $submenu . '</div>';
    }

    if ($enabled) {
        return html_writer::link($module['url'], $inner, ['class' => $classes, 'data-module' => $module['key'], 'data-desc' => $desc]);
    }
    return '<div class="' . $classes . '" data-module="' . s($module['key']) . '" data-desc="' . $desc . '" title="' . s(get_string('alsmnopermission', 'local_aisgk')) . '">' . $inner . '</div>';
}

$cards = array_map('local_aisgk_portal_card', $modules);

$centerhtml = '<div class="alsm-core"><strong>ALSM</strong><span class="alsm-core-role">' . s($profiletitle) . '</span><em>' . s($profilesubtitle) . '</em></div>';

echo $OUTPUT->header();
?>
<div class="alsm-portal-wrap alsm-portal-v9 alsm-portal-v9r role-<?php echo s($profile); ?>">
    <?php if ($isadmin) { ?>
    <div class="alsm-role-preview-bar">
        <span><?php echo get_string('alsm_preview_mode', 'local_aisgk'); ?></span>
        <?php
        $previewlabels = [
            'admin' => 'Admin',
            'leader' => get_string('alsm_hieu_truong_pht', 'local_aisgk'),
            'coordinator' => get_string('alsm_gv_phu_trach', 'local_aisgk'),
            'teacher' => get_string('alsm_giao_vien', 'local_aisgk'),
            'student' => get_string('alsm_hoc_sinh_2', 'local_aisgk'),
            'parent' => get_string('alsm_phu_huynh_2', 'local_aisgk'),
        ];
        foreach ($previewlabels as $rolekey => $label) {
            $url = new moodle_url('/local/aisgk/index.php', ['alsm_preview_role' => $rolekey, 'sesskey' => sesskey()]);
            $class = 'alsm-role-preview-link' . ($activepreviewrole === $rolekey ? ' is-active' : '');
            echo html_writer::link($url, $label, ['class' => $class]);
        }
        $clearurl = new moodle_url('/local/aisgk/index.php', ['alsm_clear_preview' => 1, 'sesskey' => sesskey()]);
        echo html_writer::link($clearurl, get_string('alsm_vai_tro_that', 'local_aisgk'), ['class' => 'alsm-role-preview-link alsm-role-preview-clear' . (!$activepreviewrole ? ' is-active' : '')]);
        ?>
    </div>
    <?php } ?>
    <div class="alsm-portal-layout alsm-orbit-stage">
        <svg class="alsm-line-svg" viewBox="0 0 1200 620" preserveAspectRatio="none" aria-hidden="true" focusable="false">
            <g class="alsm-lines">
                <line x1="520" y1="243" x2="389" y2="133"></line>
                <line x1="499" y1="281" x2="336" y2="234"></line>
                <line x1="499" y1="339" x2="336" y2="386"></line>
                <line x1="520" y1="377" x2="389" y2="487"></line>
                <line x1="680" y1="243" x2="811" y2="133"></line>
                <line x1="701" y1="281" x2="864" y2="234"></line>
                <line x1="701" y1="339" x2="864" y2="386"></line>
                <line x1="680" y1="377" x2="811" y2="487"></line>
            </g>
            <g class="alsm-line-dots">
                <circle cx="520" cy="243" r="10"></circle>
                <circle cx="499" cy="281" r="10"></circle>
                <circle cx="499" cy="339" r="10"></circle>
                <circle cx="520" cy="377" r="10"></circle>
                <circle cx="680" cy="243" r="10"></circle>
                <circle cx="701" cy="281" r="10"></circle>
                <circle cx="701" cy="339" r="10"></circle>
                <circle cx="680" cy="377" r="10"></circle>
            </g>
        </svg>

        <div class="alsm-portal-center" aria-label="ALSM">
            <?php echo $centerhtml; ?>
        </div>

        <?php echo implode("\n", $cards); ?>
    </div>
</div>

<script>
(function() {
    // Keep Moodle core AJAX/message drawer on the current page sesskey. This
    // avoids invalidsesskey after role switch / browser back-forward cache.
    window.M = window.M || {};
    M.cfg = M.cfg || {};
    M.cfg.sesskey = '<?php echo sesskey(); ?>';
    M.cfg.wwwroot = M.cfg.wwwroot || '<?php echo s($CFG->wwwroot); ?>';
    var root = document.querySelector('.alsm-portal-v9r');
    if (!root) { return; }
    function closeAll(except) {
        root.querySelectorAll('.alsm-portal-card.has-submenu.is-open').forEach(function(card) {
            if (card !== except) { card.classList.remove('is-open'); card.setAttribute('aria-expanded', 'false'); }
        });
    }
    root.querySelectorAll('.alsm-portal-card.has-submenu').forEach(function(card) {
        card.setAttribute('role', 'button');
        card.setAttribute('aria-haspopup', 'true');
        card.setAttribute('aria-expanded', 'false');
        card.addEventListener('click', function(e) {
            if (e.target.closest('.alsm-submenu')) { return; }
            e.preventDefault();
            var open = card.classList.contains('is-open');
            closeAll(card);
            card.classList.toggle('is-open', !open);
            card.setAttribute('aria-expanded', open ? 'false' : 'true');
        });
        card.addEventListener('keydown', function(e) {
            if (e.key === 'Enter' || e.key === ' ') { e.preventDefault(); card.click(); }
        });
    });
    document.addEventListener('click', function(e) {
        if (!e.target.closest('.alsm-portal-card.has-submenu')) { closeAll(null); }
    });
    document.addEventListener('keydown', function(e) {
        if (e.key === 'Escape') { closeAll(null); }
    });
})();
</script>
<?php
echo $OUTPUT->footer();
