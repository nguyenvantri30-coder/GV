<?php
// ALSM school-level portal for local_aisgk.
require_once(__DIR__ . '/../../config.php');
require_once($CFG->libdir . '/adminlib.php');

require_login();

$context = context_system::instance();
$PAGE->set_context($context);
$PAGE->set_url(new moodle_url('/local/aisgk/index.php'));
$PAGE->set_title(get_string('alsmportal', 'local_aisgk'));
$PAGE->set_heading(get_string('alsmportal', 'local_aisgk'));
$PAGE->set_pagelayout('standard');

$PAGE->requires->css(new moodle_url('/local/aisgk/styles.css'));

$isadmin = is_siteadmin();
$canmanageglobal = $isadmin || has_capability('local/aisgk:manageglobaldata', $context);
$canmanagenls = $isadmin || has_capability('local/aisgk:managenls', $context);
$canviewreports = $isadmin || has_capability('local/aisgk:viewschoolreports', $context);
$canmanageai = $isadmin || has_capability('local/aisgk:manageai', $context);
$cancoordinate = $isadmin || has_capability('local/aisgk:coordinatealsm', $context);

$mycoursesurl = new moodle_url('/my/courses.php');
if (empty($CFG->navshowmycoursecategories)) {
    $mycoursesurl = new moodle_url('/my/');
}

$adminsettingsurl = new moodle_url('/admin/settings.php', ['section' => 'localplugins']);

$modulesleft = [
    [
        'key' => 'globaldata',
        'pos' => 'left-1',
        'title' => get_string('alsmglobaldata', 'local_aisgk'),
        'desc' => get_string('alsmglobaldatadesc', 'local_aisgk'),
        'url' => new moodle_url('/local/aisgk/systemdata/index.php'),
        'enabled' => $canmanageglobal,
        'badge' => get_string('schoollevel', 'local_aisgk'),
    ],
    [
        'key' => 'tkb',
        'pos' => 'left-2',
        'title' => get_string('alsmtkb', 'local_aisgk'),
        'desc' => get_string('alsmtkbdesc', 'local_aisgk'),
        'url' => new moodle_url('/local/aisgk/systemdata/tkb.php'),
        'enabled' => $canmanageglobal,
        'badge' => get_string('adminupload', 'local_aisgk'),
    ],
    [
        'key' => 'nls',
        'pos' => 'left-3',
        'title' => get_string('alsmnls', 'local_aisgk'),
        'desc' => get_string('alsmnlsdesc', 'local_aisgk'),
        'url' => new moodle_url('/local/aisgk/nls/index.php'),
        'enabled' => $canmanagenls,
        'badge' => get_string('canonicaldata', 'local_aisgk'),
    ],
    [
        'key' => 'sgk',
        'pos' => 'left-4',
        'title' => get_string('alsmsgk', 'local_aisgk'),
        'desc' => get_string('alsmsgkdesc', 'local_aisgk'),
        'url' => new moodle_url('/local/aisgk/systemdata/books.php'),
        'enabled' => $canmanageglobal,
        'badge' => get_string('shareddata', 'local_aisgk'),
    ],
];

$modulesright = [
    [
        'key' => 'courses',
        'pos' => 'right-1',
        'title' => get_string('alsmcourses', 'local_aisgk'),
        'desc' => get_string('alsmcoursesdesc', 'local_aisgk'),
        'url' => $mycoursesurl,
        'enabled' => true,
        'badge' => get_string('courselevel', 'local_aisgk'),
    ],
    [
        'key' => 'assignment',
        'pos' => 'right-2',
        'title' => get_string('alsmassignment', 'local_aisgk'),
        'desc' => get_string('alsmassignmentdesc', 'local_aisgk'),
        'url' => new moodle_url('/local/aisgk/systemdata/assignments.php'),
        'enabled' => $canmanageglobal || $cancoordinate,
        'badge' => get_string('schoollevel', 'local_aisgk'),
    ],
    [
        'key' => 'reports',
        'pos' => 'right-3',
        'title' => get_string('alsmreports', 'local_aisgk'),
        'desc' => get_string('alsmreportsdesc', 'local_aisgk'),
        'url' => new moodle_url('/local/aisgk/reports/index.php'),
        'enabled' => $canviewreports || $cancoordinate,
        'badge' => get_string('leadership', 'local_aisgk'),
    ],
    [
        'key' => 'ai',
        'pos' => 'right-4',
        'title' => get_string('alsmai', 'local_aisgk'),
        'desc' => get_string('alsmaidesc', 'local_aisgk'),
        'url' => $adminsettingsurl,
        'enabled' => $canmanageai,
        'badge' => get_string('technicalconfig', 'local_aisgk'),
    ],
];

function local_aisgk_portal_card(array $module): string {
    $title = s($module['title']);
    $desc = s($module['desc']);
    $badge = s($module['badge']);
    $enabled = !empty($module['enabled']);
    $pos = !empty($module['pos']) ? ' pos-' . clean_param($module['pos'], PARAM_ALPHANUMEXT) : '';
    $side = (strpos($pos, 'left-') !== false) ? ' side-left' : ((strpos($pos, 'right-') !== false) ? ' side-right' : '');
    $classes = 'alsm-portal-card' . $pos . $side . ($enabled ? ' is-enabled' : ' is-disabled');
    $lock = $enabled ? '' : '<span class="alsm-lock" aria-hidden="true">🔒</span>';
    $tooltip = $enabled ? '' : ' title="' . s(get_string('alsmnopermission', 'local_aisgk')) . '"';
    $inner = '<span class="alsm-card-badge">' . $badge . '</span>' . $lock . '<span class="alsm-card-title">' . $title . '</span><span class="alsm-card-desc">' . $desc . '</span><span class="alsm-card-node" aria-hidden="true"></span>';
    if ($enabled) {
        return html_writer::link($module['url'], $inner, ['class' => $classes, 'data-module' => $module['key']]);
    }
    return '<div class="' . $classes . '" data-module="' . s($module['key']) . '"' . $tooltip . '>' . $inner . '</div>';
}

echo $OUTPUT->header();

$leftcards = array_map('local_aisgk_portal_card', $modulesleft);
$rightcards = array_map('local_aisgk_portal_card', $modulesright);

?>
<div class="alsm-portal-wrap">
    <div class="alsm-portal-hero">
        <div class="alsm-brand-mark">ALSM</div>
        <div>
            <h2><?php echo get_string('alsmportalheading', 'local_aisgk'); ?></h2>
            <p><?php echo get_string('alsmportalsubheading', 'local_aisgk'); ?></p>
        </div>
    </div>

    <div class="alsm-portal-layout alsm-orbit-stage">
        <div class="alsm-connector c-left-1" aria-hidden="true"></div>
        <div class="alsm-connector c-left-2" aria-hidden="true"></div>
        <div class="alsm-connector c-left-3" aria-hidden="true"></div>
        <div class="alsm-connector c-left-4" aria-hidden="true"></div>
        <div class="alsm-connector c-right-1" aria-hidden="true"></div>
        <div class="alsm-connector c-right-2" aria-hidden="true"></div>
        <div class="alsm-connector c-right-3" aria-hidden="true"></div>
        <div class="alsm-connector c-right-4" aria-hidden="true"></div>

        <div class="alsm-portal-center" aria-label="ALSM">
            <div class="alsm-orbit-dot d1"></div>
            <div class="alsm-orbit-dot d2"></div>
            <div class="alsm-orbit-dot d3"></div>
            <div class="alsm-orbit-dot d4"></div>
            <div class="alsm-orbit-dot d5"></div>
            <div class="alsm-orbit-dot d6"></div>
            <div class="alsm-orbit-dot d7"></div>
            <div class="alsm-orbit-dot d8"></div>
            <div class="alsm-core">
                <span class="alsm-core-small"><?php echo get_string('alsmcoretop', 'local_aisgk'); ?></span>
                <strong><?php echo get_string('alsmcoremain', 'local_aisgk'); ?></strong>
                <span class="alsm-core-small"><?php echo get_string('alsmcorebottom', 'local_aisgk'); ?></span>
            </div>
        </div>

        <?php echo implode("
", array_merge($leftcards, $rightcards)); ?>
    </div>

    <div class="alsm-portal-note">
        <?php echo get_string('alsmportalnote', 'local_aisgk'); ?>
    </div>
</div>
<?php

echo $OUTPUT->footer();
