<?php
// ALSM school-level product portal for local_aisgk.
require_once(__DIR__ . '/../../config.php');
require_once($CFG->libdir . '/adminlib.php');

require_login();

$context = context_system::instance();
$PAGE->set_context($context);
$PAGE->set_url(new moodle_url('/local/aisgk/index.php'));
$PAGE->set_title('ALSM');
$PAGE->set_heading('');
$PAGE->set_pagelayout('standard');
$PAGE->add_body_class('local-aisgk-portal-page');
$PAGE->requires->css(new moodle_url('/local/aisgk/styles.css'));

$isadmin = is_siteadmin();
$canmanageglobal = $isadmin || has_capability('local/aisgk:manageglobaldata', $context);
$canmanagenls = $isadmin || has_capability('local/aisgk:managenls', $context);
$canviewreports = $isadmin || has_capability('local/aisgk:viewschoolreports', $context);
$canmanageai = $isadmin || has_capability('local/aisgk:manageai', $context);
$cancoordinate = $isadmin || has_capability('local/aisgk:coordinatealsm', $context);
$isschooloperator = $canmanageglobal || $canmanagenls || $canviewreports || $canmanageai || $cancoordinate;

$mycoursesurl = new moodle_url('/my/courses.php');
if (empty($CFG->navshowmycoursecategories)) {
    $mycoursesurl = new moodle_url('/my/');
}
$adminsettingsurl = new moodle_url('/admin/settings.php', ['section' => 'localplugins']);

$modules = [
    [
        'key' => 'resources',
        'title' => 'Học liệu nền',
        'desc' => 'Dữ liệu dùng chung toàn trường: TKB/KHDH, NLS, SGK, PL3, năm học và phân công.',
        'enabled' => $canmanageglobal || $canmanagenls,
        'x' => 50, 'y' => 10,
        'children' => [
            ['title' => 'TKB/KHDH toàn trường', 'url' => new moodle_url('/local/aisgk/systemdata/tkb.php'), 'enabled' => $canmanageglobal],
            ['title' => 'Danh mục NLS chuẩn', 'url' => new moodle_url('/local/aisgk/nls/index.php'), 'enabled' => $canmanagenls],
            ['title' => 'Kho SGK dùng chung', 'url' => new moodle_url('/local/aisgk/systemdata/books.php'), 'enabled' => $canmanageglobal],
            ['title' => 'PL3 toàn trường', 'url' => new moodle_url('/local/aisgk/systemdata/assignments.php'), 'enabled' => $canmanageglobal || $cancoordinate],
        ],
    ],
    [
        'key' => 'daily',
        'title' => 'Điều phối học tập',
        'desc' => 'Sinh nhiệm vụ, giao bài, kiểm soát làm bài và đôn đốc học sinh theo ngày.',
        'enabled' => true,
        'x' => 91, 'y' => 40,
        'children' => [
            ['title' => 'Vào khóa học để sinh bài', 'url' => $mycoursesurl, 'enabled' => true],
            ['title' => 'Giao bài theo lịch', 'url' => new moodle_url('/local/aisgk/module.php', ['m' => 'daily', 'tab' => 'schedule']), 'enabled' => $cancoordinate || $canmanageglobal],
            ['title' => 'Danh sách cần nhắc', 'url' => new moodle_url('/local/aisgk/module.php', ['m' => 'daily', 'tab' => 'remind']), 'enabled' => $canviewreports || $cancoordinate],
        ],
    ],
    [
        'key' => 'adaptive',
        'title' => 'Năng lực',
        'desc' => 'Phân loại học sinh, phát hiện lỗ hổng năng lực và giao bài bổ trợ phù hợp.',
        'enabled' => $canviewreports || $cancoordinate,
        'x' => 75, 'y' => 88,
        'children' => [
            ['title' => 'Bản đồ năng lực lớp', 'url' => new moodle_url('/local/aisgk/module.php', ['m' => 'adaptive', 'tab' => 'map']), 'enabled' => $canviewreports || $cancoordinate],
            ['title' => 'Nhóm học sinh nguy cơ', 'url' => new moodle_url('/local/aisgk/module.php', ['m' => 'adaptive', 'tab' => 'risk']), 'enabled' => $canviewreports || $cancoordinate],
            ['title' => 'Giao bài bổ trợ', 'url' => new moodle_url('/local/aisgk/module.php', ['m' => 'adaptive', 'tab' => 'remedial']), 'enabled' => $cancoordinate],
        ],
    ],
    [
        'key' => 'competition',
        'title' => 'Thi đua',
        'desc' => 'Tạo động lực học tập bằng điểm tiến bộ, huy hiệu, xếp hạng lớp/khối/toàn trường.',
        'enabled' => $canviewreports || $cancoordinate,
        'x' => 25, 'y' => 88,
        'children' => [
            ['title' => 'Bảng xếp hạng tuần', 'url' => new moodle_url('/local/aisgk/module.php', ['m' => 'competition', 'tab' => 'rank']), 'enabled' => $canviewreports || $cancoordinate],
            ['title' => 'Huy hiệu tiến bộ', 'url' => new moodle_url('/local/aisgk/module.php', ['m' => 'competition', 'tab' => 'badges']), 'enabled' => $cancoordinate],
            ['title' => 'Thi đua lớp/khối', 'url' => new moodle_url('/local/aisgk/module.php', ['m' => 'competition', 'tab' => 'class']), 'enabled' => $canviewreports || $cancoordinate],
        ],
    ],
    [
        'key' => 'parent',
        'title' => 'Phụ huynh',
        'desc' => 'Gửi báo cáo tuần, cảnh báo chậm tiến độ và gợi ý phối hợp hỗ trợ học sinh tại nhà.',
        'enabled' => $canviewreports || $cancoordinate,
        'x' => 9, 'y' => 40,
        'children' => [
            ['title' => 'Báo cáo tuần', 'url' => new moodle_url('/local/aisgk/module.php', ['m' => 'parent', 'tab' => 'weekly']), 'enabled' => $canviewreports || $cancoordinate],
            ['title' => 'Cảnh báo cần gửi', 'url' => new moodle_url('/local/aisgk/module.php', ['m' => 'parent', 'tab' => 'alerts']), 'enabled' => $canviewreports || $cancoordinate],
            ['title' => 'Mẫu nhận xét AI', 'url' => new moodle_url('/local/aisgk/module.php', ['m' => 'parent', 'tab' => 'preview']), 'enabled' => $cancoordinate],
        ],
    ],
];

$pillars = [
    [
        'title' => 'Giám sát & đôn đốc',
        'icon' => '📊',
        'desc' => 'Theo dõi hoàn thành bài theo ngày, phát hiện học sinh chưa làm và nhắc nhanh.',
        'status' => 'Cần làm: dashboard tiến độ + nhắc tự động',
        'enabled' => $canviewreports || $cancoordinate,
        'url' => new moodle_url('/local/aisgk/module.php', ['m' => 'daily']),
    ],
    [
        'title' => 'Phân loại & phát triển năng lực',
        'icon' => '🎯',
        'desc' => 'Bản đồ năng lực, nhóm nguy cơ, bài bù lỗ hổng theo PL3/NLS/kết quả học tập.',
        'status' => 'Cần làm: mapping kết quả học sinh',
        'enabled' => $canviewreports || $cancoordinate,
        'url' => new moodle_url('/local/aisgk/module.php', ['m' => 'adaptive']),
    ],
    [
        'title' => 'Thi đua & khen thưởng',
        'icon' => '🏆',
        'desc' => 'Điểm tiến bộ, huy hiệu, bảng xếp hạng lớp/khối/toàn trường.',
        'status' => 'Phase sau: gamification',
        'enabled' => $canviewreports || $cancoordinate,
        'url' => new moodle_url('/local/aisgk/module.php', ['m' => 'competition']),
    ],
    [
        'title' => 'Báo cáo phụ huynh',
        'icon' => '✉️',
        'desc' => 'Tổng hợp kết quả tuần, nhận xét AI/GV, cảnh báo và gợi ý hỗ trợ tại nhà.',
        'status' => 'Cần làm: mẫu báo cáo tuần',
        'enabled' => $canviewreports || $cancoordinate,
        'url' => new moodle_url('/local/aisgk/module.php', ['m' => 'parent']),
    ],
];

function local_aisgk_v10_node(array $module): string {
    $title = s($module['title']);
    $desc = s($module['desc']);
    $enabled = !empty($module['enabled']);
    $classes = 'alsm-v10-node' . ($enabled ? ' is-enabled' : ' is-disabled');
    $style = 'left:' . ((float)$module['x']) . '%;top:' . ((float)$module['y']) . '%;';
    $submenu = '<div class="alsm-v10-menu" role="menu"><div class="alsm-v10-menu-desc">' . $desc . '</div><div class="alsm-v10-rule"></div>';
    foreach ($module['children'] as $child) {
        $ctitle = s($child['title']);
        if (!empty($child['enabled'])) {
            $submenu .= html_writer::link($child['url'], '— ' . $ctitle, ['class' => 'alsm-v10-subitem', 'role' => 'menuitem']);
        } else {
            $submenu .= '<span class="alsm-v10-subitem is-disabled">— ' . $ctitle . '</span>';
        }
    }
    $submenu .= '</div>';
    return '<button class="' . $classes . '" style="' . s($style) . '" type="button" aria-expanded="false" data-key="' . s($module['key']) . '"><span class="alsm-v10-dot"></span><span class="alsm-v10-label">' . $title . '</span></button>' . $submenu;
}

function local_aisgk_v10_pillar(array $pillar): string {
    $enabled = !empty($pillar['enabled']);
    $classes = 'alsm-v10-pillar' . ($enabled ? ' is-enabled' : ' is-disabled');
    $content = '<span class="alsm-v10-picon">' . s($pillar['icon']) . '</span><span><strong>' . s($pillar['title']) . '</strong><em>' . s($pillar['desc']) . '</em><small>' . s($pillar['status']) . '</small></span>';
    if ($enabled) {
        return html_writer::link($pillar['url'], $content, ['class' => $classes]);
    }
    return '<div class="' . $classes . '" title="Chưa được phân quyền">' . $content . '</div>';
}

$rolelabel = $isadmin ? 'Admin: thấy toàn bộ chức năng' : ($isschooloperator ? 'Tài khoản điều phối: chỉ mở mục được phân quyền' : 'Tài khoản thường: ưu tiên học tập cá nhân');

echo $OUTPUT->header();
?>
<div class="alsm-v10-wrap">
    <section class="alsm-v10-board" aria-label="ALSM portal">
        <div class="alsm-v10-orbit">
            <svg class="alsm-v10-svg" viewBox="0 0 100 100" preserveAspectRatio="none" aria-hidden="true">
                <line x1="50" y1="50" x2="50" y2="10"></line>
                <line x1="50" y1="50" x2="91" y2="40"></line>
                <line x1="50" y1="50" x2="75" y2="88"></line>
                <line x1="50" y1="50" x2="25" y2="88"></line>
                <line x1="50" y1="50" x2="9" y2="40"></line>
            </svg>
            <button class="alsm-v10-core" type="button" data-open-dashboard="1" aria-label="ALSM dashboard">
                <span>ALSM</span>
                <small>Quản lý học tập thông minh</small>
            </button>
            <?php foreach ($modules as $module) { echo local_aisgk_v10_node($module); } ?>
        </div>
        <div class="alsm-v10-panel">
            <div class="alsm-v10-head">
                <div>
                    <h2>ALSM</h2>
                    <p><?php echo s($rolelabel); ?></p>
                </div>
                <?php if ($canmanageai) { echo html_writer::link($adminsettingsurl, 'Cấu hình AI', ['class' => 'alsm-v10-ai']); } ?>
            </div>
            <div class="alsm-v10-pillars">
                <?php foreach ($pillars as $pillar) { echo local_aisgk_v10_pillar($pillar); } ?>
            </div>
            <div class="alsm-v10-progress">
                <strong>Việc cần làm trước</strong>
                <span>1. Học liệu nền → 2. Sinh/giao bài → 3. Theo dõi → 4. Phân loại → 5. Báo cáo/thi đua/phụ huynh.</span>
            </div>
        </div>
    </section>
</div>
<script>
(function() {
    var root = document.querySelector('.alsm-v10-wrap');
    if (!root) { return; }
    var nodes = Array.prototype.slice.call(root.querySelectorAll('.alsm-v10-node'));
    var menus = Array.prototype.slice.call(root.querySelectorAll('.alsm-v10-menu'));
    function closeAll(exceptNode) {
        nodes.forEach(function(n) {
            if (n !== exceptNode) { n.classList.remove('is-open'); n.setAttribute('aria-expanded', 'false'); }
        });
        menus.forEach(function(m) {
            if (!exceptNode || m !== exceptNode.nextElementSibling) { m.classList.remove('is-open'); }
        });
    }
    function openNode(node) {
        closeAll(node);
        var menu = node.nextElementSibling;
        node.classList.add('is-open');
        node.setAttribute('aria-expanded', 'true');
        if (menu) { menu.classList.add('is-open'); }
    }
    nodes.forEach(function(node) {
        node.addEventListener('mouseenter', function() { if (window.matchMedia('(hover:hover)').matches) { openNode(node); } });
        node.addEventListener('click', function(e) {
            e.preventDefault();
            var isOpen = node.classList.contains('is-open');
            if (isOpen) { closeAll(null); } else { openNode(node); }
        });
        node.addEventListener('focus', function() { openNode(node); });
    });
    root.addEventListener('mouseleave', function() { if (window.matchMedia('(hover:hover)').matches) { closeAll(null); } });
    document.addEventListener('click', function(e) { if (!e.target.closest('.alsm-v10-node') && !e.target.closest('.alsm-v10-menu')) { closeAll(null); } });
    document.addEventListener('keydown', function(e) { if (e.key === 'Escape') { closeAll(null); } });
})();
</script>
<?php
echo $OUTPUT->footer();
