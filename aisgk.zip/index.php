<?php
// ALSM school-level portal for local_aisgk.
require_once(__DIR__ . '/../../config.php');
require_once($CFG->libdir . '/adminlib.php');

require_login();

$context = context_system::instance();
$PAGE->set_context($context);
$PAGE->set_url(new moodle_url('/local/aisgk/index.php'));
$PAGE->set_title('ALSM');
$PAGE->set_heading('');
$PAGE->set_pagelayout('standard');
$PAGE->add_body_class('local-aisgk-portal-page');
$PAGE->requires->css(new moodle_url('/local/aisgk/styles.css'));

$isadmin = is_siteadmin();
$canmanageglobal = $isadmin || has_capability('local/aisgk:manageglobaldata', $context);
$canmanagenls = $isadmin || has_capability('local/aisgk:managenls', $context);
$canviewreports = $isadmin || has_capability('local/aisgk:viewschoolreports', $context);
$canmanageai = $isadmin || has_capability('local/aisgk:manageai', $context);
$cancoordinate = $isadmin || has_capability('local/aisgk:coordinatealsm', $context);

$mycoursesurl = new moodle_url('/my/courses.php');
if (empty($CFG->navshowmycoursecategories)) {
    $mycoursesurl = new moodle_url('/my/');
}
$adminsettingsurl = new moodle_url('/admin/settings.php', ['section' => 'localplugins']);

$modules = [
    [
        'key' => 'learningdata',
        'pos' => 'left-1',
        'title' => 'Học liệu',
        'desc' => 'Quản lý học liệu dùng chung: TKB/KHDH, NLS, SGK, năm học và dữ liệu nền toàn trường.',
        'enabled' => $canmanageglobal || $canmanagenls,
        'children' => [
            ['title' => 'Học liệu hệ thống', 'url' => new moodle_url('/local/aisgk/systemdata/index.php'), 'enabled' => $canmanageglobal],
            ['title' => 'TKB/KHDH', 'url' => new moodle_url('/local/aisgk/systemdata/tkb.php'), 'enabled' => $canmanageglobal],
            ['title' => 'NLS chuẩn', 'url' => new moodle_url('/local/aisgk/nls/index.php'), 'enabled' => $canmanagenls],
            ['title' => 'Kho SGK', 'url' => new moodle_url('/local/aisgk/systemdata/books.php'), 'enabled' => $canmanageglobal],
        ],
    ],
    [
        'key' => 'courses',
        'pos' => 'right-1',
        'title' => 'Người dùng & khóa học',
        'desc' => 'Quản lý khóa học, phân công giáo viên - lớp - môn và các quyền sử dụng ALSM.',
        'url' => $mycoursesurl,
        'enabled' => true,
    ],
    [
        'key' => 'model',
        'pos' => 'left-2',
        'title' => 'Mô hình học tập',
        'desc' => 'Thiết lập cách học: theo PL3, theo TKB, theo năng lực, phân tầng đối tượng học sinh.',
        'url' => new moodle_url('/local/aisgk/systemdata/assignments.php'),
        'enabled' => $canmanageglobal || $cancoordinate,
    ],
    [
        'key' => 'content',
        'pos' => 'right-2',
        'title' => 'Sinh nội dung',
        'desc' => 'Vào khóa học để quét SGK, đọc PL3, sinh bài tập, phiếu học tập và học liệu bổ trợ.',
        'url' => $mycoursesurl,
        'enabled' => true,
    ],
    [
        'key' => 'tracking',
        'pos' => 'left-3',
        'title' => 'Theo dõi',
        'desc' => 'Theo dõi làm bài, tiến độ, điểm, cảnh báo học sinh cần hỗ trợ và nhật ký can thiệp.',
        'url' => new moodle_url('/local/aisgk/reports/index.php'),
        'enabled' => $canviewreports || $cancoordinate,
    ],
    [
        'key' => 'reports',
        'pos' => 'right-3',
        'title' => 'Báo cáo',
        'desc' => 'Phân tích theo lớp, khối, môn, năng lực, phẩm chất, NLS và báo cáo BGH.',
        'url' => new moodle_url('/local/aisgk/reports/index.php'),
        'enabled' => $canviewreports || $cancoordinate,
    ],
    [
        'key' => 'parents',
        'pos' => 'left-4',
        'title' => 'Phụ huynh',
        'desc' => 'Báo cáo tuần, cảnh báo chậm tiến độ và gợi ý phối hợp hỗ trợ học sinh tại nhà.',
        'url' => new moodle_url('/local/aisgk/reports/index.php'),
        'enabled' => $canviewreports || $cancoordinate,
    ],
    [
        'key' => 'ai',
        'pos' => 'right-4',
        'title' => 'Cấu hình AI',
        'desc' => 'Quản lý model, API key, hàng đợi sinh nội dung và các thiết lập kỹ thuật.',
        'url' => $adminsettingsurl,
        'enabled' => $canmanageai,
    ],
];

function local_aisgk_portal_card(array $module): string {
    $title = s($module['title']);
    $desc = s($module['desc']);
    $enabled = !empty($module['enabled']);
    $pos = !empty($module['pos']) ? ' pos-' . clean_param($module['pos'], PARAM_ALPHANUMEXT) : '';
    $side = (strpos($pos, 'left-') !== false) ? ' side-left' : ((strpos($pos, 'right-') !== false) ? ' side-right' : '');
    $hassubmenu = !empty($module['children']);
    $classes = 'alsm-portal-card' . $pos . $side . ($enabled ? ' is-enabled' : ' is-disabled') . ($hassubmenu ? ' has-submenu' : '');
    $lock = $enabled ? '' : '<span class="alsm-lock" aria-hidden="true">🔒</span>';
    $tooltip = '<span class="alsm-card-tooltip"><span>' . $desc . '</span></span>';
    $inner = $lock . '<span class="alsm-card-title">' . $title . '</span><span class="alsm-card-node" aria-hidden="true"></span>' . $tooltip;

    if ($hassubmenu) {
        $submenu = '<div class="alsm-submenu" aria-label="' . $title . '">';
        foreach ($module['children'] as $child) {
            $ctitle = s($child['title']);
            if (!empty($child['enabled'])) {
                $submenu .= html_writer::link($child['url'], $ctitle, ['class' => 'alsm-subitem']);
            } else {
                $submenu .= '<span class="alsm-subitem is-disabled">' . $ctitle . '</span>';
            }
        }
        $submenu .= '</div>';
        return '<div class="' . $classes . '" tabindex="0" data-module="' . s($module['key']) . '">' . $inner . $submenu . '</div>';
    }

    if ($enabled) {
        return html_writer::link($module['url'], $inner, ['class' => $classes, 'data-module' => $module['key']]);
    }
    return '<div class="' . $classes . '" data-module="' . s($module['key']) . '" title="' . s(get_string('alsmnopermission', 'local_aisgk')) . '">' . $inner . '</div>';
}

$cards = array_map('local_aisgk_portal_card', $modules);

echo $OUTPUT->header();
?>
<div class="alsm-portal-wrap alsm-portal-v8">
    <div class="alsm-portal-layout alsm-orbit-stage">
        <svg class="alsm-line-svg" viewBox="0 0 1200 620" preserveAspectRatio="none" aria-hidden="true" focusable="false">
            <g class="alsm-lines">
                <line x1="520" y1="243" x2="389" y2="133"></line>
                <line x1="499" y1="281" x2="336" y2="234"></line>
                <line x1="499" y1="339" x2="336" y2="386"></line>
                <line x1="520" y1="377" x2="389" y2="487"></line>
                <line x1="680" y1="243" x2="811" y2="133"></line>
                <line x1="701" y1="281" x2="864" y2="234"></line>
                <line x1="701" y1="339" x2="864" y2="386"></line>
                <line x1="680" y1="377" x2="811" y2="487"></line>
            </g>
            <g class="alsm-line-dots">
                <circle cx="520" cy="243" r="10"></circle>
                <circle cx="499" cy="281" r="10"></circle>
                <circle cx="499" cy="339" r="10"></circle>
                <circle cx="520" cy="377" r="10"></circle>
                <circle cx="680" cy="243" r="10"></circle>
                <circle cx="701" cy="281" r="10"></circle>
                <circle cx="701" cy="339" r="10"></circle>
                <circle cx="680" cy="377" r="10"></circle>
            </g>
        </svg>

        <div class="alsm-portal-center" aria-label="ALSM">
            <div class="alsm-core"><strong>ALSM</strong></div>
        </div>

        <?php echo implode("\n", $cards); ?>
    </div>
</div>

<script>
(function() {
    var root = document.querySelector('.alsm-portal-v8');
    if (!root) { return; }
    function closeAll(except) {
        root.querySelectorAll('.alsm-portal-card.has-submenu.is-open').forEach(function(card) {
            if (card !== except) { card.classList.remove('is-open'); card.setAttribute('aria-expanded', 'false'); }
        });
    }
    root.querySelectorAll('.alsm-portal-card.has-submenu').forEach(function(card) {
        card.setAttribute('role', 'button');
        card.setAttribute('aria-haspopup', 'true');
        card.setAttribute('aria-expanded', 'false');
        card.addEventListener('click', function(e) {
            if (e.target.closest('.alsm-submenu')) { return; }
            e.preventDefault();
            var open = card.classList.contains('is-open');
            closeAll(card);
            card.classList.toggle('is-open', !open);
            card.setAttribute('aria-expanded', open ? 'false' : 'true');
        });
        card.addEventListener('keydown', function(e) {
            if (e.key === 'Enter' || e.key === ' ') {
                e.preventDefault();
                card.click();
            }
        });
    });
    document.addEventListener('click', function(e) {
        if (!e.target.closest('.alsm-portal-card.has-submenu')) { closeAll(null); }
    });
    document.addEventListener('keydown', function(e) {
        if (e.key === 'Escape') { closeAll(null); }
    });
})();
</script>
<?php
echo $OUTPUT->footer();
