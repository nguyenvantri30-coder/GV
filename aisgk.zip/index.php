<?php
// ALSM school-level portal for local_aisgk. Based on v9 hub layout, role-first content.
require_once(__DIR__ . '/../../config.php');
require_once($CFG->libdir . '/adminlib.php');

require_login();

$context = context_system::instance();
$PAGE->set_context($context);
$PAGE->set_url(new moodle_url('/local/aisgk/index.php'));
$PAGE->set_title('ALSM');
$PAGE->set_heading('');
$PAGE->set_pagelayout('standard');
$PAGE->add_body_class('local-aisgk-portal-page');
$PAGE->requires->css(new moodle_url('/local/aisgk/styles.css'));

$isadmin = is_siteadmin();
$canmanageglobal = $isadmin || has_capability('local/aisgk:manageglobaldata', $context);
$canmanagenls = $isadmin || has_capability('local/aisgk:managenls', $context);
$canviewreports = $isadmin || has_capability('local/aisgk:viewschoolreports', $context);
$canmanageai = $isadmin || has_capability('local/aisgk:manageai', $context);
$cancoordinate = $isadmin || has_capability('local/aisgk:coordinatealsm', $context);

$mycoursesurl = new moodle_url('/my/courses.php');
if (empty($CFG->navshowmycoursecategories)) {
    $mycoursesurl = new moodle_url('/my/');
}
$adminsettingsurl = new moodle_url('/admin/settings.php', ['section' => 'localplugins']);

$systemdata = new moodle_url('/local/aisgk/systemdata/index.php');
$tkburl = new moodle_url('/local/aisgk/systemdata/tkb.php');
$booksurl = new moodle_url('/local/aisgk/systemdata/books.php');
$assignurl = new moodle_url('/local/aisgk/systemdata/assignments.php');
$nlsurl = new moodle_url('/local/aisgk/nls/index.php');
$reportsurl = new moodle_url('/local/aisgk/reports/index.php');

$profile = 'teacher';
$profiletitle = 'LỚP HỌC CỦA TÔI';
$profilesubtitle = 'Giao bài, theo dõi, phân loại và đôn đốc học sinh';

if ($isadmin) {
    $profile = 'admin';
    $profiletitle = 'QUẢN TRỊ ALSM';
    $profilesubtitle = 'Dữ liệu nền, AI, quyền sử dụng và toàn cảnh hệ thống';
} else if ($canviewreports && $cancoordinate) {
    $profile = 'leader';
    $profiletitle = 'ĐIỀU HÀNH NHÀ TRƯỜNG';
    $profilesubtitle = 'Chất lượng, tiến độ, cảnh báo, thi đua và phụ huynh';
} else if ($canmanageglobal || $canmanagenls) {
    $profile = 'coordinator';
    $profiletitle = 'PHỤ TRÁCH DỮ LIỆU';
    $profilesubtitle = 'Học liệu nền, TKB, NLS, SGK, PL3 và phân công';
}

function local_aisgk_url_with_tab(moodle_url $url, string $tab): moodle_url {
    $newurl = new moodle_url($url);
    $newurl->param('tab', $tab);
    return $newurl;
}

$modulesbyprofile = [];

$modulesbyprofile['admin'] = [
    ['key' => 'foundation', 'pos' => 'left-1', 'title' => 'Học liệu nền', 'desc' => 'Dữ liệu dùng chung toàn trường: TKB/KHDH, NLS, SGK, năm học, phân công.', 'enabled' => $canmanageglobal || $canmanagenls, 'children' => [
        ['title' => 'Tổng quan học liệu', 'url' => $systemdata, 'enabled' => $canmanageglobal],
        ['title' => 'TKB/KHDH toàn trường', 'url' => $tkburl, 'enabled' => $canmanageglobal],
        ['title' => 'Danh mục NLS chuẩn', 'url' => $nlsurl, 'enabled' => $canmanagenls],
        ['title' => 'Kho SGK dùng chung', 'url' => $booksurl, 'enabled' => $canmanageglobal],
        ['title' => 'Phân công GV - lớp - môn', 'url' => $assignurl, 'enabled' => $canmanageglobal],
    ]],
    ['key' => 'ai', 'pos' => 'right-1', 'title' => 'AI & hệ thống', 'desc' => 'Quản lý model, API key, hàng đợi, log lỗi và cấu hình kỹ thuật.', 'enabled' => $canmanageai, 'children' => [
        ['title' => 'Cấu hình plugin ALSM', 'url' => $adminsettingsurl, 'enabled' => $canmanageai],
        ['title' => 'API key / model AI', 'url' => new moodle_url('/local/aisgk/aikeys.php'), 'enabled' => $canmanageai],
        ['title' => 'Kiểm tra sinh ảnh / text', 'url' => new moodle_url('/local/aisgk/myapi.php'), 'enabled' => $canmanageai],
    ]],
    ['key' => 'courses', 'pos' => 'left-2', 'title' => 'Khóa học', 'desc' => 'Đi tới danh sách khóa học để kiểm tra SGK, PL3, sinh bài và giao bài.', 'url' => $mycoursesurl, 'enabled' => true],
    ['key' => 'monitoring', 'pos' => 'right-2', 'title' => 'Giám sát', 'desc' => 'Theo dõi mức sử dụng, tiến độ triển khai, lớp chưa đồng bộ, lỗi cần xử lý.', 'url' => $reportsurl, 'enabled' => $canviewreports || $cancoordinate],
    ['key' => 'assessment', 'pos' => 'left-3', 'title' => 'Năng lực', 'desc' => 'Xem bản đồ năng lực, năng lực số, nhóm nguy cơ và kết quả phân tầng.', 'url' => local_aisgk_url_with_tab($reportsurl, 'competency'), 'enabled' => $canviewreports],
    ['key' => 'reports', 'pos' => 'right-3', 'title' => 'Báo cáo', 'desc' => 'Báo cáo BGH, tổ chuyên môn, lớp/khối, năng lực, phẩm chất và NLS.', 'url' => $reportsurl, 'enabled' => $canviewreports],
    ['key' => 'parents', 'pos' => 'left-4', 'title' => 'Phụ huynh', 'desc' => 'Theo dõi trạng thái báo cáo tuần, cảnh báo và phối hợp hỗ trợ học sinh.', 'url' => local_aisgk_url_with_tab($reportsurl, 'parents'), 'enabled' => $canviewreports || $cancoordinate],
    ['key' => 'competition', 'pos' => 'right-4', 'title' => 'Thi đua', 'desc' => 'Bảng xếp hạng lớp/khối, huy hiệu, tiến bộ và động lực học tập.', 'url' => local_aisgk_url_with_tab($reportsurl, 'competition'), 'enabled' => $canviewreports || $cancoordinate],
];

$modulesbyprofile['leader'] = [
    ['key' => 'overview', 'pos' => 'left-1', 'title' => 'Toàn cảnh', 'desc' => 'Nhìn nhanh tỷ lệ hoàn thành, lớp nguy cơ, tiến độ triển khai và điểm nóng.', 'url' => $reportsurl, 'enabled' => $canviewreports],
    ['key' => 'quality', 'pos' => 'right-1', 'title' => 'Chất lượng', 'desc' => 'Phân tích kết quả học tập, năng lực, phẩm chất và năng lực số theo lớp/khối.', 'url' => local_aisgk_url_with_tab($reportsurl, 'quality'), 'enabled' => $canviewreports],
    ['key' => 'warning', 'pos' => 'left-2', 'title' => 'Cảnh báo', 'desc' => 'Danh sách lớp/học sinh cần hỗ trợ, chưa làm bài, điểm thấp, chậm tiến độ.', 'url' => local_aisgk_url_with_tab($reportsurl, 'warnings'), 'enabled' => $canviewreports],
    ['key' => 'progress', 'pos' => 'right-2', 'title' => 'Chuyên môn', 'desc' => 'Theo dõi PL3, KHDH/TKB, độ phủ SGK, tiến độ giao bài của giáo viên.', 'url' => local_aisgk_url_with_tab($reportsurl, 'teaching'), 'enabled' => $canviewreports || $cancoordinate],
    ['key' => 'competition', 'pos' => 'left-3', 'title' => 'Thi đua', 'desc' => 'Top lớp/khối, phong trào học tập, huy hiệu và tiến bộ theo tuần.', 'url' => local_aisgk_url_with_tab($reportsurl, 'competition'), 'enabled' => $canviewreports],
    ['key' => 'parents', 'pos' => 'right-3', 'title' => 'Phụ huynh', 'desc' => 'Tình trạng gửi báo cáo tuần, cảnh báo phụ huynh và mẫu nhận xét.', 'url' => local_aisgk_url_with_tab($reportsurl, 'parents'), 'enabled' => $canviewreports],
    ['key' => 'foundation', 'pos' => 'left-4', 'title' => 'Học liệu', 'desc' => 'Kiểm tra dữ liệu nền toàn trường: TKB, NLS, SGK, PL3, phân công.', 'url' => $systemdata, 'enabled' => $canmanageglobal || $canmanagenls || $cancoordinate],
    ['key' => 'reporting', 'pos' => 'right-4', 'title' => 'Báo cáo BGH', 'desc' => 'Xuất báo cáo điều hành, minh chứng triển khai, tổng hợp học kỳ/năm học.', 'url' => $reportsurl, 'enabled' => $canviewreports],
];

$modulesbyprofile['coordinator'] = [
    ['key' => 'tkb', 'pos' => 'left-1', 'title' => 'TKB/KHDH', 'desc' => 'Upload và kiểm tra thời khóa biểu/kế hoạch dạy học toàn trường.', 'url' => $tkburl, 'enabled' => $canmanageglobal],
    ['key' => 'nls', 'pos' => 'right-1', 'title' => 'NLS chuẩn', 'desc' => 'Quản lý catalog năng lực số chuẩn, mã PL3 và đối chiếu theo khối lớp.', 'url' => $nlsurl, 'enabled' => $canmanagenls],
    ['key' => 'books', 'pos' => 'left-2', 'title' => 'Kho SGK', 'desc' => 'Quản lý SGK/PDF/ảnh dùng chung cho môn, khối, bộ sách.', 'url' => $booksurl, 'enabled' => $canmanageglobal],
    ['key' => 'assignments', 'pos' => 'right-2', 'title' => 'Phân công', 'desc' => 'Đồng bộ giáo viên, lớp, môn, tổ chuyên môn và quyền sử dụng ALSM.', 'url' => $assignurl, 'enabled' => $canmanageglobal],
    ['key' => 'pl3', 'pos' => 'left-3', 'title' => 'PL3', 'desc' => 'Theo dõi PL3 toàn trường, tỷ lệ map SGK/NLS, lỗi cần giáo viên sửa.', 'url' => local_aisgk_url_with_tab($systemdata, 'pl3'), 'enabled' => $canmanageglobal || $cancoordinate],
    ['key' => 'validate', 'pos' => 'right-3', 'title' => 'Kiểm tra', 'desc' => 'Validate dữ liệu import, mã NLS, lớp/môn, tuần/tiết và liên kết SGK.', 'url' => local_aisgk_url_with_tab($systemdata, 'validate'), 'enabled' => $canmanageglobal || $canmanagenls],
    ['key' => 'reports', 'pos' => 'left-4', 'title' => 'Báo cáo', 'desc' => 'Xem trạng thái dữ liệu nền và tiến độ triển khai theo tổ/khối.', 'url' => $reportsurl, 'enabled' => $canviewreports || $cancoordinate],
    ['key' => 'courses', 'pos' => 'right-4', 'title' => 'Khóa học', 'desc' => 'Đi tới khóa học để kiểm tra sử dụng thực tế của giáo viên.', 'url' => $mycoursesurl, 'enabled' => true],
];

$modulesbyprofile['teacher'] = [
    ['key' => 'today', 'pos' => 'left-1', 'title' => 'Hôm nay', 'desc' => 'Việc cần làm: bài cần giao, lớp cần nhắc, bài chờ duyệt.', 'url' => $mycoursesurl, 'enabled' => true],
    ['key' => 'create', 'pos' => 'right-1', 'title' => 'Sinh bài', 'desc' => 'Vào khóa học để sinh bài theo SGK, PL3, thời lượng và đối tượng học sinh.', 'url' => $mycoursesurl, 'enabled' => true],
    ['key' => 'deliver', 'pos' => 'left-2', 'title' => 'Giao bài', 'desc' => 'Duyệt bài, giao nhiệm vụ, đặt hạn nộp và cấu hình làm lại.', 'url' => $mycoursesurl, 'enabled' => true],
    ['key' => 'tracking', 'pos' => 'right-2', 'title' => 'Theo dõi', 'desc' => 'Xem học sinh đã làm/chưa làm, điểm, số lần làm và tiến độ lớp.', 'url' => $mycoursesurl, 'enabled' => true],
    ['key' => 'support', 'pos' => 'left-3', 'title' => 'Hỗ trợ', 'desc' => 'Phân loại học sinh, gợi ý bài bù, nhắc nhở và nhật ký can thiệp.', 'url' => $mycoursesurl, 'enabled' => true],
    ['key' => 'competency', 'pos' => 'right-3', 'title' => 'Năng lực', 'desc' => 'Theo dõi năng lực môn học, phẩm chất học tập và năng lực số từ PL3.', 'url' => $mycoursesurl, 'enabled' => true],
    ['key' => 'parents', 'pos' => 'left-4', 'title' => 'Phụ huynh', 'desc' => 'Xem nội dung báo cáo tuần và cảnh báo cần phối hợp với phụ huynh.', 'url' => $mycoursesurl, 'enabled' => true],
    ['key' => 'reports', 'pos' => 'right-4', 'title' => 'Báo cáo lớp', 'desc' => 'Tổng hợp lớp dạy: hoàn thành, điểm, tiến bộ, nhóm cần hỗ trợ.', 'url' => $mycoursesurl, 'enabled' => true],
];

$modules = $modulesbyprofile[$profile];

function local_aisgk_portal_card(array $module): string {
    $title = s($module['title']);
    $desc = s($module['desc']);
    $enabled = !empty($module['enabled']);
    $pos = !empty($module['pos']) ? ' pos-' . clean_param($module['pos'], PARAM_ALPHANUMEXT) : '';
    $side = (strpos($pos, 'left-') !== false) ? ' side-left' : ((strpos($pos, 'right-') !== false) ? ' side-right' : '');
    $hassubmenu = !empty($module['children']);
    $classes = 'alsm-portal-card' . $pos . $side . ($enabled ? ' is-enabled' : ' is-disabled') . ($hassubmenu ? ' has-submenu' : '');
    $lock = $enabled ? '' : '<span class="alsm-lock" aria-hidden="true">🔒</span>';
    $inner = $lock . '<span class="alsm-card-title">' . $title . '</span><span class="alsm-card-node" aria-hidden="true"></span>';

    if ($hassubmenu) {
        $submenu = '<div class="alsm-submenu" aria-label="' . $title . '">';
        $submenu .= '<span class="alsm-subitem alsm-subdesc" aria-disabled="true">' . $desc . '</span>';
        foreach ($module['children'] as $child) {
            $ctitle = s($child['title']);
            if (!empty($child['enabled'])) {
                $submenu .= html_writer::link($child['url'], $ctitle, ['class' => 'alsm-subitem']);
            } else {
                $submenu .= '<span class="alsm-subitem is-disabled">' . $ctitle . '</span>';
            }
        }
        $submenu .= '</div>';
        return '<div class="' . $classes . '" tabindex="0" data-module="' . s($module['key']) . '" data-desc="' . $desc . '">' . $inner . $submenu . '</div>';
    }

    if ($enabled) {
        return html_writer::link($module['url'], $inner, ['class' => $classes, 'data-module' => $module['key'], 'data-desc' => $desc]);
    }
    return '<div class="' . $classes . '" data-module="' . s($module['key']) . '" data-desc="' . $desc . '" title="' . s(get_string('alsmnopermission', 'local_aisgk')) . '">' . $inner . '</div>';
}

$cards = array_map('local_aisgk_portal_card', $modules);

$centerhtml = '<div class="alsm-core"><strong>ALSM</strong><span class="alsm-core-role">' . s($profiletitle) . '</span><em>' . s($profilesubtitle) . '</em></div>';

echo $OUTPUT->header();
?>
<div class="alsm-portal-wrap alsm-portal-v9 alsm-portal-v9r role-<?php echo s($profile); ?>">
    <div class="alsm-portal-layout alsm-orbit-stage">
        <svg class="alsm-line-svg" viewBox="0 0 1200 620" preserveAspectRatio="none" aria-hidden="true" focusable="false">
            <g class="alsm-lines">
                <line x1="520" y1="243" x2="389" y2="133"></line>
                <line x1="499" y1="281" x2="336" y2="234"></line>
                <line x1="499" y1="339" x2="336" y2="386"></line>
                <line x1="520" y1="377" x2="389" y2="487"></line>
                <line x1="680" y1="243" x2="811" y2="133"></line>
                <line x1="701" y1="281" x2="864" y2="234"></line>
                <line x1="701" y1="339" x2="864" y2="386"></line>
                <line x1="680" y1="377" x2="811" y2="487"></line>
            </g>
            <g class="alsm-line-dots">
                <circle cx="520" cy="243" r="10"></circle>
                <circle cx="499" cy="281" r="10"></circle>
                <circle cx="499" cy="339" r="10"></circle>
                <circle cx="520" cy="377" r="10"></circle>
                <circle cx="680" cy="243" r="10"></circle>
                <circle cx="701" cy="281" r="10"></circle>
                <circle cx="701" cy="339" r="10"></circle>
                <circle cx="680" cy="377" r="10"></circle>
            </g>
        </svg>

        <div class="alsm-portal-center" aria-label="ALSM">
            <?php echo $centerhtml; ?>
        </div>

        <?php echo implode("\n", $cards); ?>
    </div>
</div>

<script>
(function() {
    var root = document.querySelector('.alsm-portal-v9r');
    if (!root) { return; }
    function closeAll(except) {
        root.querySelectorAll('.alsm-portal-card.has-submenu.is-open').forEach(function(card) {
            if (card !== except) { card.classList.remove('is-open'); card.setAttribute('aria-expanded', 'false'); }
        });
    }
    root.querySelectorAll('.alsm-portal-card.has-submenu').forEach(function(card) {
        card.setAttribute('role', 'button');
        card.setAttribute('aria-haspopup', 'true');
        card.setAttribute('aria-expanded', 'false');
        card.addEventListener('click', function(e) {
            if (e.target.closest('.alsm-submenu')) { return; }
            e.preventDefault();
            var open = card.classList.contains('is-open');
            closeAll(card);
            card.classList.toggle('is-open', !open);
            card.setAttribute('aria-expanded', open ? 'false' : 'true');
        });
        card.addEventListener('keydown', function(e) {
            if (e.key === 'Enter' || e.key === ' ') { e.preventDefault(); card.click(); }
        });
    });
    document.addEventListener('click', function(e) {
        if (!e.target.closest('.alsm-portal-card.has-submenu')) { closeAll(null); }
    });
    document.addEventListener('keydown', function(e) {
        if (e.key === 'Escape') { closeAll(null); }
    });
})();
</script>
<?php
echo $OUTPUT->footer();
