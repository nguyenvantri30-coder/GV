<?php
// ALSM school-level portal for local_aisgk. Based on v9 hub layout, role-first content.
require_once(__DIR__ . '/../../config.php');
require_once($CFG->libdir . '/adminlib.php');

require_login();

$context = context_system::instance();
$PAGE->set_context($context);
$PAGE->set_url(new moodle_url('/local/aisgk/index.php'));
$PAGE->set_title('ALSM');
$PAGE->set_heading('');
$PAGE->set_pagelayout('standard');
// Portal is role/session-sensitive (preview role, Moodle message drawer sesskey).
// Do not let proxies/browsers reuse a page generated for another logged-in user.
$PAGE->set_cacheable(false);
$PAGE->add_body_class('local-aisgk-portal-page');
$PAGE->requires->css(new moodle_url('/local/aisgk/styles.css'));

$isadmin = is_siteadmin();
$previewrole = optional_param('alsm_preview_role', '', PARAM_ALPHA);
$allowedpreviewroles = ['admin', 'leader', 'coordinator', 'teacher', 'student', 'parent'];
if ($isadmin && $previewrole && confirm_sesskey() && in_array($previewrole, $allowedpreviewroles, true)) {
    $SESSION->local_aisgk_preview_role = $previewrole;
}
if ($isadmin && optional_param('alsm_clear_preview', 0, PARAM_BOOL) && confirm_sesskey()) {
    unset($SESSION->local_aisgk_preview_role);
}
$activepreviewrole = ($isadmin && !empty($SESSION->local_aisgk_preview_role) && in_array($SESSION->local_aisgk_preview_role, $allowedpreviewroles, true)) ? $SESSION->local_aisgk_preview_role : '';
$canmanageglobal = $isadmin || has_capability('local/aisgk:manageglobaldata', $context);
$canmanagenls = $isadmin || has_capability('local/aisgk:managenls', $context);
$canviewreports = $isadmin || has_capability('local/aisgk:viewschoolreports', $context);
$canmanageai = $isadmin || has_capability('local/aisgk:manageai', $context);
$cancoordinate = $isadmin || has_capability('local/aisgk:coordinatealsm', $context);

$mycoursesurl = new moodle_url('/my/courses.php');
if (empty($CFG->navshowmycoursecategories)) {
    $mycoursesurl = new moodle_url('/my/');
}
$adminsettingsurl = new moodle_url('/admin/settings.php', ['section' => 'localplugins']);

$systemdata = new moodle_url('/local/aisgk/systemdata/index.php');
$tkburl = new moodle_url('/local/aisgk/systemdata/tkb.php');
$booksurl = new moodle_url('/local/aisgk/systemdata/books.php');
$assignurl = new moodle_url('/local/aisgk/systemdata/assignments.php');
$nlsurl = new moodle_url('/local/aisgk/nls/index.php');
$reportsurl = new moodle_url('/local/aisgk/reports/index.php');

/**
 * Detect the real ALSM portal profile for the current user.
 *
 * Important: never fall back to teacher. A normal student normally has no
 * system-level ALSM capability on this portal page, so a teacher fallback makes
 * students see teacher cards. Course teacher/student roles are detected from
 * role assignments when no ALSM system role is present.
 *
 * @param context_system $context
 * @return string admin|leader|coordinator|teacher|student|parent
 */
function local_aisgk_detect_portal_profile(context_system $context): string {
    global $DB, $USER;

    if (is_siteadmin()) {
        return 'admin';
    }

    // Explicit ALSM school roles/capabilities win first.
    if (has_capability('local/aisgk:viewschoolreports', $context)
            && has_capability('local/aisgk:coordinatealsm', $context)) {
        return 'leader';
    }
    if (has_capability('local/aisgk:manageglobaldata', $context)
            || has_capability('local/aisgk:managenls', $context)) {
        return 'coordinator';
    }

    // Parent role can be assigned in user context in Moodle installs that use it.
    $parentsql = "SELECT 1
                    FROM {role_assignments} ra
                    JOIN {role} r ON r.id = ra.roleid
                    JOIN {context} ctx ON ctx.id = ra.contextid
                   WHERE ra.userid = :userid
                     AND r.shortname = :parentrole
                     AND ctx.contextlevel = :usercontext";
    if ($DB->record_exists_sql($parentsql, [
        'userid' => $USER->id,
        'parentrole' => 'parent',
        'usercontext' => CONTEXT_USER,
    ])) {
        return 'parent';
    }

    // Detect real course teaching roles. This is deliberately checked before
    // student, because many teachers are also enrolled as students in sandboxes.
    $teachingsql = "SELECT 1
                      FROM {role_assignments} ra
                      JOIN {role} r ON r.id = ra.roleid
                      JOIN {context} ctx ON ctx.id = ra.contextid
                     WHERE ra.userid = :userid
                       AND ctx.contextlevel = :coursecontext
                       AND r.shortname IN ('editingteacher', 'teacher', 'coursecreator')";
    if ($DB->record_exists_sql($teachingsql, [
        'userid' => $USER->id,
        'coursecontext' => CONTEXT_COURSE,
    ])) {
        return 'teacher';
    }

    // Normal learner view. If the account has no ALSM school role and is not a
    // course teacher, the safe/default portal is the student portal.
    return 'student';
}

function local_aisgk_apply_portal_profile_titles(string $profile): array {
    switch ($profile) {
        case 'admin':
            return [get_string('alsm_quan_tri_alsm', 'local_aisgk'), get_string('alsm_du_lieu_nen_ai_quyen_su', 'local_aisgk')];
        case 'leader':
            return [get_string('alsm_dieu_hanh_nha_truong', 'local_aisgk'), get_string('alsm_chat_luong_tien_do_canh_bao', 'local_aisgk')];
        case 'coordinator':
            return [get_string('alsm_phu_trach_du_lieu', 'local_aisgk'), get_string('alsm_hoc_lieu_nen_tkb_nls_sgk', 'local_aisgk')];
        case 'parent':
            return [get_string('alsm_phu_huynh', 'local_aisgk'), get_string('alsm_bao_cao_tuan_canh_bao_hoc', 'local_aisgk')];
        case 'student':
            return [get_string('alsm_hoc_sinh', 'local_aisgk'), get_string('alsm_bai_hom_tien_do_nang_luc', 'local_aisgk')];
        case 'teacher':
        default:
            return [get_string('alsm_lop_hoc_toi', 'local_aisgk'), get_string('alsm_giao_bai_doi_phan_loai_don', 'local_aisgk')];
    }
}

$profile = local_aisgk_detect_portal_profile($context);
[$profiletitle, $profilesubtitle] = local_aisgk_apply_portal_profile_titles($profile);

function local_aisgk_url_with_tab(moodle_url $url, string $tab): moodle_url {
    $newurl = new moodle_url($url);
    $newurl->param('tab', $tab);
    return $newurl;
}

$modulesbyprofile = [];

$modulesbyprofile['admin'] = [
    [
        'key' => 'schoolyear', 'pos' => 'left-1', 'step' => '1',
        'title' => get_string('alsm_admin_schoolyear', 'local_aisgk'),
        'desc' => get_string('alsm_admin_schoolyear_desc', 'local_aisgk'),
        'enabled' => $isadmin,
        'children' => [
            ['title' => get_string('alsm_backup_old_year', 'local_aisgk'), 'url' => new moodle_url('/local/aisgk/year_backup.php'), 'enabled' => $isadmin],
            ['title' => get_string('alsm_create_new_year', 'local_aisgk'), 'url' => new moodle_url('/local/aisgk/year_new.php'), 'enabled' => $isadmin],
            ['title' => get_string('alsm_backup_system', 'local_aisgk'), 'url' => local_aisgk_url_with_tab($systemdata, 'backup'), 'enabled' => $isadmin],
            ['title' => get_string('alsm_restore_system', 'local_aisgk'), 'url' => local_aisgk_url_with_tab($systemdata, 'restore'), 'enabled' => $isadmin],
        ]
    ],
    [
        'key' => 'foundation', 'pos' => 'right-1', 'step' => '2',
        'title' => get_string('alsm_admin_foundation', 'local_aisgk'),
        'desc' => get_string('alsm_admin_foundation_desc', 'local_aisgk'),
        'enabled' => $canmanageglobal || $canmanagenls,
        'children' => [
            ['title' => get_string('alsm_upload_nls_standard', 'local_aisgk'), 'url' => $nlsurl, 'enabled' => $canmanagenls],
            ['title' => get_string('alsm_download_pl3_template', 'local_aisgk'), 'url' => local_aisgk_url_with_tab($systemdata, 'pl3template'), 'enabled' => $canmanageglobal],
            ['title' => get_string('alsm_upload_alsm_manual', 'local_aisgk'), 'url' => local_aisgk_url_with_tab($systemdata, 'manuals'), 'enabled' => $canmanageglobal],
            ['title' => get_string('alsm_check_learning_data_status', 'local_aisgk'), 'url' => $systemdata, 'enabled' => $canmanageglobal || $canmanagenls],
        ]
    ],
    [
        'key' => 'organization', 'pos' => 'left-2', 'step' => '3',
        'title' => get_string('alsm_admin_organization', 'local_aisgk'),
        'desc' => get_string('alsm_admin_organization_desc', 'local_aisgk'),
        'enabled' => $canmanageglobal,
        'children' => [
            ['title' => get_string('alsm_import_users', 'local_aisgk'), 'url' => new moodle_url('/admin/tool/uploaduser/index.php'), 'enabled' => $canmanageglobal],
            ['title' => get_string('alsm_import_groups', 'local_aisgk'), 'url' => local_aisgk_url_with_tab($assignurl, 'groups'), 'enabled' => $canmanageglobal],
            ['title' => get_string('alsm_teacher_assignments', 'local_aisgk'), 'url' => $assignurl, 'enabled' => $canmanageglobal],
            ['title' => get_string('alsm_sync_roles', 'local_aisgk'), 'url' => new moodle_url('/admin/roles/manage.php'), 'enabled' => $isadmin],
        ]
    ],
    [
        'key' => 'courses', 'pos' => 'right-2', 'step' => '4',
        'title' => get_string('alsm_admin_courses', 'local_aisgk'),
        'desc' => get_string('alsm_admin_courses_desc', 'local_aisgk'),
        'enabled' => $canmanageglobal,
        'children' => [
            ['title' => get_string('alsm_create_bulk_courses', 'local_aisgk'), 'url' => new moodle_url('/course/management.php'), 'enabled' => $canmanageglobal],
            ['title' => get_string('alsm_assign_teachers_to_courses', 'local_aisgk'), 'url' => local_aisgk_url_with_tab($assignurl, 'teacher_enrol'), 'enabled' => $canmanageglobal],
            ['title' => get_string('alsm_assign_students_to_courses', 'local_aisgk'), 'url' => local_aisgk_url_with_tab($assignurl, 'student_enrol'), 'enabled' => $canmanageglobal],
            ['title' => get_string('alsm_check_course_status', 'local_aisgk'), 'url' => $mycoursesurl, 'enabled' => true],
        ]
    ],
    [
        'key' => 'schedule', 'pos' => 'left-3', 'step' => '5',
        'title' => get_string('alsm_admin_schedule', 'local_aisgk'),
        'desc' => get_string('alsm_admin_schedule_desc', 'local_aisgk'),
        'enabled' => $canmanageglobal || $cancoordinate,
        'children' => [
            ['title' => get_string('alsm_upload_school_timetable', 'local_aisgk'), 'url' => $tkburl, 'enabled' => $canmanageglobal],
            ['title' => get_string('alsm_check_teaching_progress', 'local_aisgk'), 'url' => local_aisgk_url_with_tab($reportsurl, 'schedule'), 'enabled' => $canviewreports || $cancoordinate],
            ['title' => get_string('alsm_sync_semester_scope', 'local_aisgk'), 'url' => local_aisgk_url_with_tab($systemdata, 'semester_scope'), 'enabled' => $canmanageglobal],
            ['title' => get_string('alsm_schedule_alerts', 'local_aisgk'), 'url' => local_aisgk_url_with_tab($reportsurl, 'schedule_alerts'), 'enabled' => $canviewreports || $cancoordinate],
        ]
    ],
    [
        'key' => 'monitoring', 'pos' => 'right-3', 'step' => '6',
        'title' => get_string('alsm_admin_monitoring', 'local_aisgk'),
        'desc' => get_string('alsm_admin_monitoring_desc', 'local_aisgk'),
        'enabled' => $canviewreports || $cancoordinate,
        'children' => [
            ['title' => get_string('alsm_track_homework', 'local_aisgk'), 'url' => local_aisgk_url_with_tab($reportsurl, 'homework'), 'enabled' => $canviewreports || $cancoordinate],
            ['title' => get_string('alsm_student_alerts', 'local_aisgk'), 'url' => local_aisgk_url_with_tab($reportsurl, 'alerts'), 'enabled' => $canviewreports || $cancoordinate],
            ['title' => get_string('alsm_competency_analysis', 'local_aisgk'), 'url' => local_aisgk_url_with_tab($reportsurl, 'competency'), 'enabled' => $canviewreports],
            ['title' => get_string('alsm_remediation_suggestions', 'local_aisgk'), 'url' => local_aisgk_url_with_tab($reportsurl, 'remediation'), 'enabled' => $canviewreports || $cancoordinate],
        ]
    ],
    [
        'key' => 'rewardfund', 'pos' => 'left-4', 'step' => '7',
        'title' => get_string('alsm_competition_rewardfund', 'local_aisgk'),
        'desc' => get_string('alsm_competition_rewardfund_desc', 'local_aisgk'),
        'enabled' => $canviewreports || $cancoordinate || $isadmin,
        'children' => [
            ['title' => get_string('alsm_leaderboard', 'local_aisgk'), 'url' => local_aisgk_url_with_tab($reportsurl, 'competition'), 'enabled' => $canviewreports || $cancoordinate || $isadmin],
            ['title' => get_string('alsm_reward_fund', 'local_aisgk'), 'url' => local_aisgk_url_with_tab($reportsurl, 'rewardfund'), 'enabled' => $canviewreports || $cancoordinate || $isadmin],
            ['title' => get_string('alsm_sponsors', 'local_aisgk'), 'url' => local_aisgk_url_with_tab($reportsurl, 'sponsors'), 'enabled' => $canviewreports || $cancoordinate || $isadmin],
            ['title' => get_string('alsm_public_income_expense', 'local_aisgk'), 'url' => local_aisgk_url_with_tab($reportsurl, 'fund_public'), 'enabled' => $canviewreports || $cancoordinate || $isadmin],
        ]
    ],
    [
        'key' => 'reports', 'pos' => 'right-4', 'step' => '8',
        'title' => get_string('alsm_reports_public', 'local_aisgk'),
        'desc' => get_string('alsm_reports_public_desc', 'local_aisgk'),
        'enabled' => $canviewreports || $isadmin,
        'children' => [
            ['title' => get_string('alsm_principal_reports', 'local_aisgk'), 'url' => $reportsurl, 'enabled' => $canviewreports || $isadmin],
            ['title' => get_string('alsm_parent_reports', 'local_aisgk'), 'url' => local_aisgk_url_with_tab($reportsurl, 'parents'), 'enabled' => $canviewreports || $isadmin],
            ['title' => get_string('alsm_export_statistics', 'local_aisgk'), 'url' => local_aisgk_url_with_tab($reportsurl, 'export'), 'enabled' => $canviewreports || $isadmin],
            ['title' => get_string('alsm_system_logs', 'local_aisgk'), 'url' => local_aisgk_url_with_tab($reportsurl, 'logs'), 'enabled' => $isadmin],
        ]
    ],
];

$modulesbyprofile['leader'] = [
    ['key' => 'overview', 'pos' => 'left-1', 'step' => '1', 'title' => get_string('alsm_toan_canh', 'local_aisgk'), 'desc' => get_string('alsm_nhin_nhanh_ty_le_hoan_thanh', 'local_aisgk'), 'url' => $reportsurl, 'enabled' => $canviewreports],
    ['key' => 'quality', 'pos' => 'right-1', 'step' => '2', 'title' => get_string('alsm_chat_luong', 'local_aisgk'), 'desc' => get_string('alsm_phan_tich_ket_qua_hoc_tap', 'local_aisgk'), 'url' => local_aisgk_url_with_tab($reportsurl, 'quality'), 'enabled' => $canviewreports],
    ['key' => 'warning', 'pos' => 'left-2', 'step' => '3', 'title' => get_string('alsm_canh_bao', 'local_aisgk'), 'desc' => get_string('alsm_danh_sach_lop_hoc_sinh_can', 'local_aisgk'), 'url' => local_aisgk_url_with_tab($reportsurl, 'warnings'), 'enabled' => $canviewreports],
    ['key' => 'progress', 'pos' => 'right-2', 'step' => '4', 'title' => get_string('alsm_chuyen_mon', 'local_aisgk'), 'desc' => get_string('alsm_doi_pl3_khdh_tkb_do_phu', 'local_aisgk'), 'url' => local_aisgk_url_with_tab($reportsurl, 'teaching'), 'enabled' => $canviewreports || $cancoordinate],
    ['key' => 'competition', 'pos' => 'left-3', 'step' => '5', 'title' => get_string('alsm_competition_rewardfund', 'local_aisgk'), 'desc' => get_string('alsm_competition_rewardfund_public_desc', 'local_aisgk'), 'url' => local_aisgk_url_with_tab($reportsurl, 'rewardfund'), 'enabled' => $canviewreports],
    ['key' => 'parents', 'pos' => 'right-3', 'step' => '6', 'title' => get_string('alsm_phu_huynh_2', 'local_aisgk'), 'desc' => get_string('alsm_tinh_trang_gui_bao_cao_tuan', 'local_aisgk'), 'url' => local_aisgk_url_with_tab($reportsurl, 'parents'), 'enabled' => $canviewreports],
    ['key' => 'foundation', 'pos' => 'left-4', 'step' => '7', 'title' => get_string('alsm_hoc_lieu', 'local_aisgk'), 'desc' => get_string('alsm_kiem_tra_du_lieu_nen_toan', 'local_aisgk'), 'url' => $systemdata, 'enabled' => $canmanageglobal || $canmanagenls || $cancoordinate],
    ['key' => 'reporting', 'pos' => 'right-4', 'step' => '8', 'title' => get_string('alsm_bao_cao_bgh', 'local_aisgk'), 'desc' => get_string('alsm_xuat_bao_cao_dieu_hanh_minh', 'local_aisgk'), 'url' => $reportsurl, 'enabled' => $canviewreports],
];

$modulesbyprofile['coordinator'] = [
    ['key' => 'tkb', 'pos' => 'left-1', 'step' => '1', 'title' => 'TKB/KHDH', 'desc' => get_string('alsm_upload_kiem_tra_thoi_khoa_bieu', 'local_aisgk'), 'url' => $tkburl, 'enabled' => $canmanageglobal],
    ['key' => 'nls', 'pos' => 'right-1', 'step' => '2', 'title' => get_string('alsm_nls_chuan', 'local_aisgk'), 'desc' => get_string('alsm_quan_ly_catalog_nang_luc_so', 'local_aisgk'), 'url' => $nlsurl, 'enabled' => $canmanagenls],
    ['key' => 'books', 'pos' => 'left-2', 'step' => '3', 'title' => 'Kho SGK', 'desc' => get_string('alsm_quan_ly_sgk_pdf_anh_dung', 'local_aisgk'), 'url' => $booksurl, 'enabled' => $canmanageglobal],
    ['key' => 'assignments', 'pos' => 'right-2', 'step' => '4', 'title' => get_string('alsm_phan_cong', 'local_aisgk'), 'desc' => get_string('alsm_dong_bo_giao_vien_lop_mon', 'local_aisgk'), 'url' => $assignurl, 'enabled' => $canmanageglobal],
    ['key' => 'pl3', 'pos' => 'left-3', 'step' => '5', 'title' => 'PL3', 'desc' => get_string('alsm_doi_pl3_toan_truong_ty_le', 'local_aisgk'), 'url' => local_aisgk_url_with_tab($systemdata, 'pl3'), 'enabled' => $canmanageglobal || $cancoordinate],
    ['key' => 'validate', 'pos' => 'right-3', 'step' => '6', 'title' => get_string('alsm_kiem_tra', 'local_aisgk'), 'desc' => get_string('alsm_validate_du_lieu_import_ma_nls', 'local_aisgk'), 'url' => local_aisgk_url_with_tab($systemdata, 'validate'), 'enabled' => $canmanageglobal || $canmanagenls],
    ['key' => 'reports', 'pos' => 'left-4', 'step' => '7', 'title' => get_string('alsm_bao_cao', 'local_aisgk'), 'desc' => get_string('alsm_xem_trang_thai_du_lieu_nen', 'local_aisgk'), 'url' => $reportsurl, 'enabled' => $canviewreports || $cancoordinate],
    ['key' => 'courses', 'pos' => 'right-4', 'step' => '8', 'title' => get_string('alsm_khoa_hoc', 'local_aisgk'), 'desc' => get_string('alsm_di_toi_khoa_hoc_kiem_tra', 'local_aisgk'), 'url' => $mycoursesurl, 'enabled' => true],
];

$modulesbyprofile['teacher'] = [
    ['key' => 'today', 'pos' => 'left-1', 'step' => '1', 'title' => get_string('alsm_hom', 'local_aisgk'), 'desc' => get_string('alsm_viec_can_lam_bai_can_giao', 'local_aisgk'), 'url' => $mycoursesurl, 'enabled' => true],
    ['key' => 'create', 'pos' => 'right-1', 'step' => '2', 'title' => get_string('alsm_sinh_bai', 'local_aisgk'), 'desc' => get_string('alsm_khoa_hoc_sinh_bai_sgk_pl3', 'local_aisgk'), 'url' => $mycoursesurl, 'enabled' => true],
    ['key' => 'deliver', 'pos' => 'left-2', 'step' => '3', 'title' => get_string('alsm_giao_bai', 'local_aisgk'), 'desc' => get_string('alsm_duyet_bai_giao_nhiem_vu_dat', 'local_aisgk'), 'url' => $mycoursesurl, 'enabled' => true],
    ['key' => 'tracking', 'pos' => 'right-2', 'step' => '4', 'title' => get_string('alsm_doi', 'local_aisgk'), 'desc' => get_string('alsm_xem_hoc_sinh_lam_chua_lam', 'local_aisgk'), 'url' => $mycoursesurl, 'enabled' => true],
    ['key' => 'support', 'pos' => 'left-3', 'step' => '5', 'title' => get_string('alsm_ho_tro', 'local_aisgk'), 'desc' => get_string('alsm_phan_loai_hoc_sinh_goi_y', 'local_aisgk'), 'url' => $mycoursesurl, 'enabled' => true],
    ['key' => 'competency', 'pos' => 'right-3', 'step' => '6', 'title' => get_string('alsm_nang_luc', 'local_aisgk'), 'desc' => get_string('alsm_doi_nang_luc_mon_hoc_pham', 'local_aisgk'), 'url' => $mycoursesurl, 'enabled' => true],
    ['key' => 'parents', 'pos' => 'left-4', 'step' => '7', 'title' => get_string('alsm_phu_huynh_2', 'local_aisgk'), 'desc' => get_string('alsm_xem_noi_dung_bao_cao_tuan', 'local_aisgk'), 'url' => $mycoursesurl, 'enabled' => true],
    ['key' => 'rewardfund', 'pos' => 'right-4', 'step' => '8', 'title' => get_string('alsm_competition_rewardfund', 'local_aisgk'), 'desc' => get_string('alsm_competition_rewardfund_public_desc', 'local_aisgk'), 'url' => local_aisgk_url_with_tab($reportsurl, 'rewardfund'), 'enabled' => true],
];


$modulesbyprofile['student'] = [
    ['key' => 'tasks', 'pos' => 'left-1', 'step' => '1', 'title' => get_string('alsm_bai_hom', 'local_aisgk'), 'desc' => get_string('alsm_xem_nhiem_vu_duoc_giao_han', 'local_aisgk'), 'url' => $mycoursesurl, 'enabled' => true],
    ['key' => 'progress', 'pos' => 'right-1', 'step' => '2', 'title' => get_string('alsm_tien_do', 'local_aisgk'), 'desc' => get_string('alsm_doi_diem_so_lan_lam_bai', 'local_aisgk'), 'url' => $mycoursesurl, 'enabled' => true],
    ['key' => 'competency', 'pos' => 'left-2', 'step' => '3', 'title' => get_string('alsm_nang_luc', 'local_aisgk'), 'desc' => get_string('alsm_ban_do_nang_luc_mon_hoc', 'local_aisgk'), 'url' => $mycoursesurl, 'enabled' => true],
    ['key' => 'practice', 'pos' => 'right-2', 'step' => '4', 'title' => get_string('alsm_luyen_them', 'local_aisgk'), 'desc' => get_string('alsm_bai_tap_bo_tro_lo_hong', 'local_aisgk'), 'url' => $mycoursesurl, 'enabled' => true],
    ['key' => 'competition', 'pos' => 'left-3', 'step' => '5', 'title' => get_string('alsm_competition_rewardfund', 'local_aisgk'), 'desc' => get_string('alsm_competition_rewardfund_public_desc', 'local_aisgk'), 'url' => local_aisgk_url_with_tab($reportsurl, 'rewardfund'), 'enabled' => true],
    ['key' => 'help', 'pos' => 'right-3', 'step' => '6', 'title' => get_string('alsm_can_ho_tro', 'local_aisgk'), 'desc' => get_string('alsm_xem_goi_y_on_tap_noi', 'local_aisgk'), 'url' => $mycoursesurl, 'enabled' => true],
];

$modulesbyprofile['parent'] = [
    ['key' => 'weekly', 'pos' => 'left-1', 'step' => '1', 'title' => get_string('alsm_bao_cao_tuan', 'local_aisgk'), 'desc' => get_string('alsm_ket_qua_hoc_tap_bai_lam', 'local_aisgk'), 'url' => $reportsurl, 'enabled' => true],
    ['key' => 'alerts', 'pos' => 'right-1', 'step' => '2', 'title' => get_string('alsm_canh_bao', 'local_aisgk'), 'desc' => get_string('alsm_tin_can_phu_huynh_phoi_hop', 'local_aisgk'), 'url' => local_aisgk_url_with_tab($reportsurl, 'parents'), 'enabled' => true],
    ['key' => 'progress', 'pos' => 'left-2', 'step' => '3', 'title' => get_string('alsm_tien_bo', 'local_aisgk'), 'desc' => get_string('alsm_doi_xu_huong_hoc_tap_thay', 'local_aisgk'), 'url' => local_aisgk_url_with_tab($reportsurl, 'progress'), 'enabled' => true],
    ['key' => 'support', 'pos' => 'right-2', 'step' => '4', 'title' => get_string('alsm_ho_tro_tai_nha', 'local_aisgk'), 'desc' => get_string('alsm_goi_y_phu_huynh_ho_tro', 'local_aisgk'), 'url' => local_aisgk_url_with_tab($reportsurl, 'support'), 'enabled' => true],
    ['key' => 'rewardfund', 'pos' => 'left-3', 'step' => '5', 'title' => get_string('alsm_competition_rewardfund', 'local_aisgk'), 'desc' => get_string('alsm_competition_rewardfund_public_desc', 'local_aisgk'), 'url' => local_aisgk_url_with_tab($reportsurl, 'rewardfund'), 'enabled' => true],
];

if ($activepreviewrole) {
    $profile = $activepreviewrole;
    if ($profile === 'admin') {
        $profiletitle = get_string('alsm_xem_thu_admin', 'local_aisgk');
        $profilesubtitle = get_string('alsm_mo_phong_giao_dien_quan_tri', 'local_aisgk');
    } else if ($profile === 'leader') {
        $profiletitle = get_string('alsm_xem_thu_bgh', 'local_aisgk');
        $profilesubtitle = get_string('alsm_mo_phong_giao_dien_hieu_truong', 'local_aisgk');
    } else if ($profile === 'coordinator') {
        $profiletitle = get_string('alsm_xem_thu_phu_trach', 'local_aisgk');
        $profilesubtitle = get_string('alsm_mo_phong_giao_dien_giao_vien', 'local_aisgk');
    } else if ($profile === 'student') {
        $profiletitle = get_string('alsm_xem_thu_hoc_sinh', 'local_aisgk');
        $profilesubtitle = get_string('alsm_mo_phong_ban_do_hoc_tap', 'local_aisgk');
    } else if ($profile === 'parent') {
        $profiletitle = get_string('alsm_xem_thu_phu_huynh', 'local_aisgk');
        $profilesubtitle = get_string('alsm_mo_phong_bao_cao_tuan_canh', 'local_aisgk');
    } else {
        $profiletitle = get_string('alsm_xem_thu_giao_vien', 'local_aisgk');
        $profilesubtitle = get_string('alsm_mo_phong_giao_dien_lop_hoc', 'local_aisgk');
    }
}

$modules = $modulesbyprofile[$profile] ?? $modulesbyprofile['student'];

function local_aisgk_portal_card(array $module): string {
    $title = s($module['title']);
    $desc = s($module['desc']);
    $step = !empty($module['step']) ? s($module['step']) : '';
    $enabled = !empty($module['enabled']);
    $pos = !empty($module['pos']) ? ' pos-' . clean_param($module['pos'], PARAM_ALPHANUMEXT) : '';
    $side = (strpos($pos, 'left-') !== false) ? ' side-left' : ((strpos($pos, 'right-') !== false) ? ' side-right' : '');
    $hassubmenu = !empty($module['children']);
    $classes = 'alsm-portal-card' . $pos . $side . ($enabled ? ' is-enabled' : ' is-disabled') . ($hassubmenu ? ' has-submenu' : '');
    $lock = $enabled ? '' : '<span class="alsm-lock" aria-hidden="true">🔒</span>';
    $stephtml = $step !== '' ? '<span class="alsm-node-step" aria-hidden="true">' . $step . '</span>' : '';
    $inner = $lock . '<span class="alsm-card-title">' . $title . '</span><span class="alsm-card-node" aria-hidden="true">' . $stephtml . '</span>';

    if ($hassubmenu) {
        $submenu = '<div class="alsm-submenu" aria-label="' . $title . '">';
        $submenu .= '<span class="alsm-subitem alsm-subdesc" aria-disabled="true">' . $desc . '</span>';
        $subindex = 1;
        foreach ($module['children'] as $child) {
            if (!empty($child['separator'])) {
                $submenu .= '<span class="alsm-subseparator" aria-hidden="true"></span>';
                continue;
            }
            $ctitle = s($child['title']);
            $badge = '<span class="alsm-subnum" aria-hidden="true">' . $subindex . '</span>';
            $label = $badge . '<span class="alsm-subtext">' . $ctitle . '</span>';
            $subindex++;
            if (!empty($child['enabled'])) {
                $submenu .= html_writer::link($child['url'], $label, ['class' => 'alsm-subitem']);
            } else {
                $submenu .= '<span class="alsm-subitem is-disabled">' . $label . '</span>';
            }
        }
        $submenu .= '</div>';
        return '<div class="' . $classes . '" tabindex="0" data-module="' . s($module['key']) . '" data-desc="' . $desc . '">' . $inner . $submenu . '</div>';
    }

    if ($enabled) {
        return html_writer::link($module['url'], $inner, ['class' => $classes, 'data-module' => $module['key'], 'data-desc' => $desc]);
    }
    return '<div class="' . $classes . '" data-module="' . s($module['key']) . '" data-desc="' . $desc . '" title="' . s(get_string('alsmnopermission', 'local_aisgk')) . '">' . $inner . '</div>';
}

$cards = array_map('local_aisgk_portal_card', $modules);

$centerhtml = '<div class="alsm-core"><strong>ALSM</strong><span class="alsm-core-role">' . s($profiletitle) . '</span><em>' . s($profilesubtitle) . '</em></div>';

echo $OUTPUT->header();
?>
<div class="alsm-portal-wrap alsm-portal-v9 alsm-portal-v9r role-<?php echo s($profile); ?>">
    <?php if ($isadmin) { ?>
    <div class="alsm-role-preview-bar">
        <span><?php echo get_string('alsm_preview_mode', 'local_aisgk'); ?></span>
        <?php
        $previewlabels = [
            'admin' => get_string('alsm_role_admin', 'local_aisgk'),
            'leader' => get_string('alsm_hieu_truong_pht', 'local_aisgk'),
            'coordinator' => get_string('alsm_gv_phu_trach', 'local_aisgk'),
            'teacher' => get_string('alsm_giao_vien', 'local_aisgk'),
            'student' => get_string('alsm_hoc_sinh_2', 'local_aisgk'),
            'parent' => get_string('alsm_phu_huynh_2', 'local_aisgk'),
        ];
        foreach ($previewlabels as $rolekey => $label) {
            $url = new moodle_url('/local/aisgk/index.php', ['alsm_preview_role' => $rolekey, 'sesskey' => sesskey()]);
            $class = 'alsm-role-preview-link' . ($activepreviewrole === $rolekey ? ' is-active' : '');
            echo html_writer::link($url, $label, ['class' => $class]);
        }
        $clearurl = new moodle_url('/local/aisgk/index.php', ['alsm_clear_preview' => 1, 'sesskey' => sesskey()]);
        echo html_writer::link($clearurl, get_string('alsm_vai_tro_that', 'local_aisgk'), ['class' => 'alsm-role-preview-link alsm-role-preview-clear' . (!$activepreviewrole ? ' is-active' : '')]);
        ?>
    </div>
    <?php } ?>
    <div class="alsm-portal-layout alsm-orbit-stage">
        <svg class="alsm-line-svg" viewBox="0 0 1200 620" preserveAspectRatio="none" aria-hidden="true" focusable="false">
            <g class="alsm-lines">
                <line x1="520" y1="243" x2="389" y2="133"></line>
                <line x1="499" y1="281" x2="336" y2="234"></line>
                <line x1="499" y1="339" x2="336" y2="386"></line>
                <line x1="520" y1="377" x2="389" y2="487"></line>
                <line x1="680" y1="243" x2="811" y2="133"></line>
                <line x1="701" y1="281" x2="864" y2="234"></line>
                <line x1="701" y1="339" x2="864" y2="386"></line>
                <line x1="680" y1="377" x2="811" y2="487"></line>
            </g>
            <g class="alsm-line-dots">
                <circle cx="520" cy="243" r="10"></circle>
                <circle cx="499" cy="281" r="10"></circle>
                <circle cx="499" cy="339" r="10"></circle>
                <circle cx="520" cy="377" r="10"></circle>
                <circle cx="680" cy="243" r="10"></circle>
                <circle cx="701" cy="281" r="10"></circle>
                <circle cx="701" cy="339" r="10"></circle>
                <circle cx="680" cy="377" r="10"></circle>
            </g>
        </svg>

        <div class="alsm-portal-center" aria-label="ALSM">
            <?php echo $centerhtml; ?>
        </div>

        <?php echo implode("\n", $cards); ?>
    </div>
</div>

<script>
(function() {
    // Keep Moodle core AJAX/message drawer on the current page sesskey. This
    // avoids invalidsesskey after role switch / browser back-forward cache.
    window.M = window.M || {};
    M.cfg = M.cfg || {};
    M.cfg.sesskey = '<?php echo sesskey(); ?>';
    M.cfg.wwwroot = M.cfg.wwwroot || '<?php echo s($CFG->wwwroot); ?>';
    var root = document.querySelector('.alsm-portal-v9r');
    if (!root) { return; }
    function closeAll(except) {
        root.querySelectorAll('.alsm-portal-card.has-submenu.is-open').forEach(function(card) {
            if (card !== except) { card.classList.remove('is-open'); card.setAttribute('aria-expanded', 'false'); }
        });
    }
    root.querySelectorAll('.alsm-portal-card.has-submenu').forEach(function(card) {
        card.setAttribute('role', 'button');
        card.setAttribute('aria-haspopup', 'true');
        card.setAttribute('aria-expanded', 'false');
        card.addEventListener('click', function(e) {
            if (e.target.closest('.alsm-submenu')) { return; }
            e.preventDefault();
            var open = card.classList.contains('is-open');
            closeAll(card);
            card.classList.toggle('is-open', !open);
            card.setAttribute('aria-expanded', open ? 'false' : 'true');
        });
        card.addEventListener('keydown', function(e) {
            if (e.key === 'Enter' || e.key === ' ') { e.preventDefault(); card.click(); }
        });
    });
    document.addEventListener('click', function(e) {
        if (!e.target.closest('.alsm-portal-card.has-submenu')) { closeAll(null); }
    });
    document.addEventListener('keydown', function(e) {
        if (e.key === 'Escape') { closeAll(null); }
    });
})();
</script>
<?php
echo $OUTPUT->footer();
