<?php
require('../../config.php');

use local_aisgk\aikey_repository;

$courseid = required_param('id', PARAM_INT);
$course = get_course($courseid);
require_login($course);
if (!is_siteadmin()) {
    throw new required_capability_exception(context_system::instance(), 'moodle/site:config', 'nopermissions', '');
}
$context = context_course::instance($courseid);
$PAGE->set_context($context);
$PAGE->set_url('/local/aisgk/aikeys.php', ['id' => $courseid]);
$PAGE->set_pagelayout('embedded');
$PAGE->set_title(get_string('aikeysmodaltitle', 'local_aisgk'));

aikey_repository::sync_usage_remaining_for_pay_keys();
$rows = aikey_repository::get_all();
if (!$rows) {
    $rows = [(object)['id'=>0,'gmail_account'=>'','api_key'=>'','category_key'=>'free','provider'=>'google','model_scan'=>'','model_homework'=>'','status'=>'active','daily_limit'=>0,'daily_used'=>0,'last_model'=>'','usage_remaining'=>0,'last_error'=>'']];
}

echo $OUTPUT->header();
?>
<style>
html,body{background:#fff;height:100%;overflow:hidden}.shell{height:90vh;padding:10px;display:flex;flex-direction:column;gap:8px;font-size:13px}.toolbar{display:flex;gap:8px;align-items:center;flex-wrap:wrap}.grid{flex:1;overflow:auto;border:1px solid #cfd7e3;border-radius:8px}.btn{height:34px;padding:0 12px;border:1px solid #cbd5e1;border-radius:6px;background:#fff;cursor:pointer}.primary{background:#2563eb;color:#fff;border-color:#2563eb}.pill{background:#eef2ff;color:#3730a3;border-radius:999px;padding:6px 10px}.muted{font-size:11px;color:#667085}table{border-collapse:collapse;width:max-content;min-width:100%}th,td{border-bottom:1px solid #e5e7eb;padding:6px;background:#fff;vertical-align:middle}th{position:sticky;top:0;background:#f8fafc;z-index:2}input,select{width:100%;height:30px;border:1px solid #cbd5e1;border-radius:4px;padding:3px 5px;box-sizing:border-box}.n{width:54px;text-align:center}.act{width:46px}.wide{width:220px}.key{width:280px}.small{width:100px}.err{width:300px}.x{width:28px;height:28px}
</style>
<div class="shell">
  <div class="toolbar">
    <button class="btn primary" id="save"><?php echo s(get_string('savechanges','local_aisgk')); ?></button>
    <button class="btn" id="restore"><?php echo s(get_string('restorelabel','local_aisgk')); ?></button>
    <span class="pill" id="status">✓ Sẵn sàng</span>
    <span class="muted">Model Scan/Homework có thể nhập nhiều model, phân cách bằng dấu phẩy. Hệ thống giới hạn tổng 30 lượt/phút trên cùng VPS.</span>
  </div>
  <div class="grid"><table id="tbl"><thead><tr><th class="n">#</th><th class="act">+</th><th class="wide">Gmail</th><th class="key">API Key</th><th class="small">Category</th><th class="small">Provider</th><th class="wide">Model Scan</th><th class="wide">Model Homework</th><th class="small">Status</th><th class="small">Daily limit</th><th class="small">Daily used</th><th class="wide">Last model</th><th class="small">Remain</th><th class="err">Last error</th><th class="act">×</th></tr></thead><tbody>
<?php foreach ($rows as $i => $r): ?>
<tr><td class="n"><?php echo $i+1; ?></td><td><button class="x add" type="button">+</button></td><td><input type="hidden" class="id" value="<?php echo (int)$r->id; ?>"><input class="gmail" value="<?php echo s($r->gmail_account ?? ''); ?>"></td><td><input class="apikey" value="<?php echo s($r->api_key ?? ''); ?>"></td><td><select class="cat"><option value="free" <?php echo (($r->category_key ?? 'free')==='free')?'selected':''; ?>>free</option><option value="pay" <?php echo (($r->category_key ?? '')==='pay')?'selected':''; ?>>pay</option></select></td><td><select class="provider"><option value="google" <?php echo (($r->provider ?? 'google')==='google')?'selected':''; ?>>google</option><option value="shopaikey" <?php echo (($r->provider ?? '')==='shopaikey')?'selected':''; ?>>shopaikey</option></select></td><td><input class="modelscan" value="<?php echo s($r->model_scan ?? ''); ?>"></td><td><input class="modelhw" value="<?php echo s($r->model_homework ?? ''); ?>"></td><td><select class="keystatus"><option value="active" <?php echo (($r->status ?? 'active')==='active')?'selected':''; ?>>active</option><option value="cooldown" <?php echo (($r->status ?? '')==='cooldown')?'selected':''; ?>>cooldown</option><option value="blocked" <?php echo (($r->status ?? '')==='blocked')?'selected':''; ?>>blocked</option></select></td><td><input type="number" min="0" class="dailylimit" value="<?php echo (int)($r->daily_limit ?? (($r->category_key ?? 'free') === 'pay' ? 100 : 0)); ?>"></td><td><input readonly class="dailyused" value="<?php echo (int)($r->daily_used ?? 0); ?>"></td><td><input readonly class="lastmodel" value="<?php echo s($r->last_model ?? ''); ?>"></td><td><input readonly class="remain" value="<?php echo s((string)($r->usage_remaining ?? '0')); ?>"></td><td><input class="lasterror" value="<?php echo s($r->last_error ?? ''); ?>"></td><td><button class="x del" type="button">×</button></td></tr>
<?php endforeach; ?>
</tbody></table></div>
</div>
<script>
(function(){
const ajax=<?php echo json_encode((new moodle_url('/local/aisgk/aikeys_ajax.php',['id'=>$courseid]))->out(false)); ?>, sess=<?php echo json_encode(sesskey()); ?>, tbody=document.querySelector('#tbl tbody'), st=document.getElementById('status');
const esc=s=>String(s||'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#039;'}[c]));
function renum(){[...tbody.querySelectorAll('tr')].forEach((tr,i)=>tr.children[0].textContent=i+1)}
function row(r={}){let tr=document.createElement('tr');tr.innerHTML='<td class="n"></td><td><button class="x add" type="button">+</button></td><td><input type="hidden" class="id" value="'+esc(r.id||'')+'"><input class="gmail" value="'+esc(r.gmail_account||'')+'"></td><td><input class="apikey" value="'+esc(r.api_key||'')+'"></td><td><select class="cat"><option value="free">free</option><option value="pay">pay</option></select></td><td><select class="provider"><option value="google">google</option><option value="shopaikey">shopaikey</option></select></td><td><input class="modelscan" value="'+esc(r.model_scan||'')+'"></td><td><input class="modelhw" value="'+esc(r.model_homework||'')+'"></td><td><select class="keystatus"><option value="active">active</option><option value="cooldown">cooldown</option><option value="blocked">blocked</option></select></td><td><input type="number" min="0" class="dailylimit" value="'+esc(r.daily_limit||0)+'"></td><td><input readonly class="dailyused" value="'+esc(r.daily_used||0)+'"></td><td><input readonly class="lastmodel" value="'+esc(r.last_model||'')+'"></td><td><input readonly class="remain" value="'+esc(r.usage_remaining||0)+'"></td><td><input class="lasterror" value="'+esc(r.last_error||'')+'"></td><td><button class="x del" type="button">×</button></td>'; tr.querySelector('.cat').value=r.category_key||'free'; tr.querySelector('.provider').value=r.provider||'google'; tr.querySelector('.keystatus').value=r.status||'active'; return tr;}
function rows(){return [...tbody.querySelectorAll('tr')].map(tr=>({id:tr.querySelector('.id').value,gmail_account:tr.querySelector('.gmail').value.trim(),api_key:tr.querySelector('.apikey').value.trim(),category_key:tr.querySelector('.cat').value,provider:tr.querySelector('.provider').value,model_scan:tr.querySelector('.modelscan').value.trim(),model_homework:tr.querySelector('.modelhw').value.trim(),status:tr.querySelector('.keystatus').value,daily_limit:tr.querySelector('.dailylimit').value,last_error:tr.querySelector('.lasterror').value.trim()})).filter(r=>r.gmail_account||r.api_key||r.model_scan||r.model_homework||r.last_error)}
async function post(op,data){let res=await fetch(ajax+'&op='+encodeURIComponent(op)+'&sesskey='+encodeURIComponent(sess),{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify(data||{})});let txt=await res.text(),j;try{j=JSON.parse(txt)}catch(e){}if(!res.ok||!j||j.ok===false)throw new Error((j&&j.error)||txt||'Yêu cầu thất bại');return j}
function render(rs){tbody.innerHTML='';(rs&&rs.length?rs:[{}]).forEach(r=>tbody.appendChild(row(r)));renum();st.textContent='✓ Xong'}
tbody.addEventListener('click',e=>{if(e.target.classList.contains('add')){e.target.closest('tr').after(row({}));renum()} if(e.target.classList.contains('del')){e.target.closest('tr').remove(); if(!tbody.children.length)tbody.appendChild(row({})); renum()}});
document.getElementById('save').onclick=async()=>{try{st.textContent='Đang lưu';let j=await post('save',{rows:rows()});render(j.rows)}catch(e){st.textContent='Lỗi: '+e.message}};
document.getElementById('restore').onclick=async()=>{try{st.textContent='Đang tải';let j=await post('restore',{});render(j.rows)}catch(e){st.textContent='Lỗi: '+e.message}};
})();
</script>
<?php echo $OUTPUT->footer();
