<?php
require('../../config.php');

use local_aisgk\book_repository;
use local_aisgk\local\service\scan_service;
use local_aisgk\toc_repository;

$courseid = required_param('id', PARAM_INT);
$bookid = optional_param('bookid', 0, PARAM_INT);
$action = optional_param('action', '', PARAM_ALPHA);
$columns = optional_param('columns', 1, PARAM_INT);
$psm = optional_param('psm', 4, PARAM_INT);
$splitpercent = optional_param('splitpercent', 50, PARAM_INT);
$pagefrom = optional_param('pagefrom', 0, PARAM_INT);
$pageto = optional_param('pageto', 0, PARAM_INT);

$course = get_course($courseid);
require_login($course);
$context = context_course::instance($courseid);
require_capability('local/aisgk:createtopic', $context);

$PAGE->set_context($context);
$PAGE->set_url('/local/aisgk/topic.php', ['id' => $courseid, 'bookid' => $bookid]);
$PAGE->set_pagelayout('embedded');
$PAGE->set_title(get_string('createtopic', 'local_aisgk'));

$books = book_repository::get_all_by_courseid($courseid);
if (!$books) {
    throw new moodle_exception('bookrequired', 'local_aisgk');
}
if ($bookid < 1) {
    $bookid = (int)reset($books)->id;
}
$book = book_repository::get_by_id($bookid);
if (!$book || (int)$book->courseid !== $courseid) {
    throw new moodle_exception('invalidparameter');
}

if ($pagefrom < 1) {
    $pagefrom = (int)($book->tocfrompage ?? 0);
}
if ($pageto < 1) {
    $pageto = (int)($book->toctopage ?? 0);
}

if ($action === 'save' && confirm_sesskey() && data_submitted()) {
    $rows = [];
    $sobais = optional_param_array('sobai', [], PARAM_RAW_TRIMMED);
    $tenbais = optional_param_array('tenbai', [], PARAM_RAW_TRIMMED);
    $trangs = optional_param_array('trang', [], PARAM_RAW_TRIMMED);
    $endtrangs = optional_param_array('endtrang', [], PARAM_RAW_TRIMMED);
    $rawlines = optional_param_array('rawline', [], PARAM_RAW_TRIMMED);
    $deletes = optional_param_array('delete', [], PARAM_INT);
    $max = max(count($sobais), count($tenbais), count($trangs), count($endtrangs), count($rawlines));

    for ($i = 0; $i < $max; $i++) {
        if (!empty($deletes[$i])) {
            continue;
        }
        $row = [
            'sobai' => $sobais[$i] ?? '',
            'tenbai' => $tenbais[$i] ?? '',
            'trang' => $trangs[$i] ?? '',
            'endtrang' => $endtrangs[$i] ?? '',
            'rawline' => $rawlines[$i] ?? '',
        ];
        if (trim(implode('', array_map('strval', $row))) === '') {
            continue;
        }
        $rows[] = $row;
    }
    $rows = toc_repository::calculate_end_pages($rows);
    toc_repository::replace_book_toc($bookid, $rows);
    redirect(new moodle_url('/local/aisgk/topic.php', ['id' => $courseid, 'bookid' => $bookid]), get_string('tocsaved', 'local_aisgk'), null, \core\output\notification::NOTIFY_SUCCESS);
}

if ($action === 'scan' && confirm_sesskey()) {
    scan_service::queue_toc_scan($bookid, $USER->id, $columns, $splitpercent, $psm);
    redirect(new moodle_url('/local/aisgk/topic.php', ['id' => $courseid, 'bookid' => $bookid]), get_string('tocscanqueued', 'local_aisgk'), null, \core\output\notification::NOTIFY_SUCCESS);
}

$tocrows = toc_repository::get_by_bookid($bookid);
if (!$tocrows) {
    for ($i = 0; $i < 8; $i++) {
        $tocrows[] = (object)['sobai' => '', 'tenbai' => '', 'trang' => '', 'endtrang' => '', 'rawline' => ''];
    }
}

$statusmap = [
    'queued' => ['alert-info', get_string('scanstatusqueued', 'local_aisgk'), 'Done, +0 rows'],
    'running' => ['alert-warning', get_string('scanstatusrunning', 'local_aisgk'), 'Running'],
    'done' => ['alert-success', get_string('scanstatusdone', 'local_aisgk', (int)($book->lastscanitemcount ?? 0)), 'Done, +' . (int)($book->lastscanitemcount ?? 0) . ' rows'],
    'failed' => ['alert-danger', format_string(get_string('scanstatusfailed', 'local_aisgk', s((string)($book->scanmessage ?? '')))), 'Failed'],
];
[$statusclass, $statustext, $statuspill] = $statusmap[$book->scanstatus ?? 'idle'] ?? ['alert-secondary', get_string('scanstatusidle', 'local_aisgk'), 'Idle'];

$bookdisplay = $book->name ?: $book->filename;
$rowcount = count($tocrows);

echo $OUTPUT->header();
?>
<style>
body {background:#fff;}
.local-aisgk-topic-shell {padding:12px 14px 14px; font-size:13px; color:#1f2937;}
.local-aisgk-topic-title {font-size:24px; font-weight:700; margin:0 0 12px;}
.local-aisgk-card {background:#fff; border:1px solid #d9dee7; border-radius:10px; box-shadow:0 1px 2px rgba(16,24,40,.04);}
.local-aisgk-card-head {display:flex; justify-content:space-between; align-items:flex-start; gap:16px; padding:8px 0 10px;}
.local-aisgk-card-head h3 {margin:0; font-size:24px; font-weight:700;}
.local-aisgk-subline {margin:2px 0 0; font-size:12px; color:#6b7280;}
.local-aisgk-head-actions {display:flex; align-items:center; gap:8px; flex-wrap:wrap;}
.local-aisgk-pill {display:inline-flex; align-items:center; gap:6px; border-radius:999px; padding:4px 10px; font-size:12px; line-height:1.2;}
.local-aisgk-pill-success {background:#dcfce7; color:#166534;}
.local-aisgk-pill-draft {background:#ede9fe; color:#6d28d9;}
.local-aisgk-bookbar, .local-aisgk-actionbar, .local-aisgk-savebar {display:flex; gap:8px; align-items:flex-end; flex-wrap:wrap;}
.local-aisgk-bookbar {margin-bottom:10px;}
.local-aisgk-actionbar {margin-bottom:10px;}
.local-aisgk-fitem {display:flex; align-items:center; gap:6px;}
.local-aisgk-fitem label {font-weight:600; margin:0; white-space:nowrap;}
.local-aisgk-fitem select, .local-aisgk-fitem input {height:36px; padding:6px 8px; border:1px solid #bfc7d4; border-radius:6px; box-sizing:border-box;}
.local-aisgk-fitem-small input, .local-aisgk-fitem-small select {width:64px;}
.local-aisgk-fitem-page input {width:76px; text-align:center;}
.local-aisgk-status-inline {margin:0 0 8px; color:#475467;}
.local-aisgk-table-wrap {overflow:auto; max-height:56vh; border:1px solid #cfd7e3; border-radius:8px; background:#fff;}
.local-aisgk-toc-table {width:100%; min-width:1180px; border-collapse:collapse;}
.local-aisgk-toc-table th, .local-aisgk-toc-table td {border:1px solid #cfd7e3; padding:3px; vertical-align:middle; font-size:12px;}
.local-aisgk-toc-table th {position:sticky; top:0; background:#f8fafc; z-index:1; white-space:nowrap;}
.local-aisgk-toc-table input[type="text"], .local-aisgk-toc-table input[type="number"] {width:100%; height:32px; padding:5px 8px; border:1px solid #b8c2d1; border-radius:4px; box-sizing:border-box;}
.local-aisgk-source-cell {max-width:160px; white-space:nowrap; overflow:hidden; text-overflow:ellipsis; color:#475467;}
.local-aisgk-ctr {text-align:center;}
.local-aisgk-addline {width:28px; height:28px; border-radius:6px; border:1px solid #cbd5e1; background:#f8fafc; font-size:16px; line-height:1;}
.local-aisgk-clearhead {font-weight:600; color:#2563eb; background:none; border:none; padding:0; cursor:default;}
.local-aisgk-savebar {justify-content:flex-end; margin-top:10px;}
.local-aisgk-btn-secondary {background:#e5e7eb; border-color:#d1d5db; color:#111827;}
.local-aisgk-btn-green {background:#2e7d32; border-color:#2e7d32; color:#fff;}
.local-aisgk-helpnote {font-size:12px; color:#6b7280; margin-bottom:8px;}
</style>
<div class="local-aisgk-topic-shell">
    <div class="local-aisgk-card-head">
        <div>
            <h3><?php echo s(get_string('createtopic', 'local_aisgk')); ?></h3>
        </div>
        <div class="local-aisgk-head-actions">
            <span class="local-aisgk-pill local-aisgk-pill-success">✓ <?php echo s($statuspill); ?></span>
            <span class="local-aisgk-pill local-aisgk-pill-draft"><?php echo s(get_string('draftview', 'local_aisgk')); ?></span>
        </div>
    </div>

    <div class="local-aisgk-status-inline"><?php echo $statustext; ?></div>

    <form method="get" action="<?php echo new moodle_url('/local/aisgk/topic.php'); ?>" class="local-aisgk-bookbar">
        <input type="hidden" name="id" value="<?php echo (int)$courseid; ?>">
        <div class="local-aisgk-fitem">
            <label for="id_bookid"><?php echo s(get_string('bookselect', 'local_aisgk')); ?></label>
            <select id="id_bookid" name="bookid">
                <?php foreach ($books as $option): ?>
                    <option value="<?php echo (int)$option->id; ?>" <?php echo ((int)$option->id === (int)$bookid) ? 'selected' : ''; ?>><?php echo s($option->name ?: $option->filename); ?></option>
                <?php endforeach; ?>
            </select>
        </div>
        <button type="submit" class="btn btn-secondary"><?php echo s(get_string('viewchange', 'local_aisgk')); ?></button>
    </form>

    <form method="post" action="<?php echo new moodle_url('/local/aisgk/topic.php', ['id' => $courseid, 'bookid' => $bookid, 'action' => 'scan']); ?>" class="local-aisgk-actionbar">
        <input type="hidden" name="sesskey" value="<?php echo sesskey(); ?>">
        <div class="local-aisgk-fitem local-aisgk-fitem-small">
            <label for="id_columns">Cột</label>
            <select id="id_columns" name="columns">
                <option value="1" <?php echo $columns === 1 ? 'selected' : ''; ?>>1</option>
                <option value="2" <?php echo $columns === 2 ? 'selected' : ''; ?>>2</option>
            </select>
        </div>
        <div class="local-aisgk-fitem local-aisgk-fitem-small">
            <label for="id_psm">PSM</label>
            <input type="number" id="id_psm" name="psm" min="3" max="13" value="<?php echo (int)$psm; ?>">
        </div>
        <div class="local-aisgk-fitem local-aisgk-fitem-small">
            <label for="id_splitpercent">Split</label>
            <input type="number" id="id_splitpercent" name="splitpercent" min="20" max="80" value="<?php echo (int)$splitpercent; ?>">
        </div>
        <div class="local-aisgk-fitem local-aisgk-fitem-page">
            <label for="id_pagefrom">Page</label>
            <input type="text" id="id_pagefrom" name="pagefrom" value="<?php echo s((string)$pagefrom); ?>-<?php echo s((string)$pageto); ?>" readonly>
        </div>
        <button type="submit" class="btn btn-primary"><?php echo s(get_string('scantoc', 'local_aisgk')); ?></button>
        <button type="button" class="btn btn-secondary local-aisgk-btn-secondary" disabled><?php echo s(get_string('checklabel', 'local_aisgk')); ?></button>
        <button type="button" class="btn btn-secondary local-aisgk-btn-secondary" disabled><?php echo s(get_string('fixspellinglabel', 'local_aisgk')); ?></button>
    </form>

    <form method="post" action="<?php echo new moodle_url('/local/aisgk/topic.php', ['id' => $courseid, 'bookid' => $bookid, 'action' => 'save']); ?>" id="local-aisgk-save-form">
        <input type="hidden" name="sesskey" value="<?php echo sesskey(); ?>">
        <div class="local-aisgk-savebar" style="justify-content:flex-start; margin-bottom:8px;">
            <button type="submit" class="btn local-aisgk-btn-green"><?php echo s(get_string('savechanges', 'local_aisgk')); ?></button>
            <a href="<?php echo (new moodle_url('/local/aisgk/topic.php', ['id' => $courseid, 'bookid' => $bookid]))->out(false); ?>" class="btn btn-secondary local-aisgk-btn-secondary"><?php echo s(get_string('restorelabel', 'local_aisgk')); ?></a>
        </div>
        <div class="local-aisgk-table-wrap">
            <table class="local-aisgk-toc-table" id="local-aisgk-toc-table">
                <thead>
                    <tr>
                        <th>#</th>
                        <th>+</th>
                        <th><?php echo s(get_string('sobai', 'local_aisgk')); ?></th>
                        <th><?php echo s(get_string('tenbai', 'local_aisgk')); ?></th>
                        <th><?php echo s(get_string('trangbatdau', 'local_aisgk')); ?></th>
                        <th><?php echo s(get_string('trangketthuc', 'local_aisgk')); ?></th>
                        <th>Source</th>
                        <th><span class="local-aisgk-clearhead"><?php echo s(get_string('clearlabel', 'local_aisgk')); ?></span></th>
                    </tr>
                </thead>
                <tbody>
                <?php foreach ($tocrows as $i => $row): ?>
                    <tr>
                        <td class="local-aisgk-ctr"><?php echo (int)$i + 1; ?></td>
                        <td class="local-aisgk-ctr"><button type="button" class="local-aisgk-addline" data-add-after="<?php echo (int)$i; ?>">+</button></td>
                        <td><input type="number" name="sobai[<?php echo $i; ?>]" value="<?php echo s((string)$row->sobai); ?>"></td>
                        <td><input type="text" name="tenbai[<?php echo $i; ?>]" value="<?php echo s((string)$row->tenbai); ?>"></td>
                        <td><input type="number" name="trang[<?php echo $i; ?>]" value="<?php echo s((string)$row->trang); ?>"></td>
                        <td><input type="number" name="endtrang[<?php echo $i; ?>]" value="<?php echo s((string)$row->endtrang); ?>"></td>
                        <td class="local-aisgk-source-cell" title="<?php echo s($bookdisplay); ?>"><?php echo s($bookdisplay); ?></td>
                        <td class="local-aisgk-ctr"><input type="checkbox" name="delete[<?php echo $i; ?>]" value="1"></td>
                        <input type="hidden" name="rawline[<?php echo $i; ?>]" value="<?php echo s((string)$row->rawline); ?>">
                    </tr>
                <?php endforeach; ?>
                </tbody>
            </table>
        </div>
        <div class="local-aisgk-savebar">
            <button type="submit" class="btn local-aisgk-btn-green"><?php echo s(get_string('savechanges', 'local_aisgk')); ?></button>
            <a href="<?php echo (new moodle_url('/local/aisgk/topic.php', ['id' => $courseid, 'bookid' => $bookid]))->out(false); ?>" class="btn btn-secondary local-aisgk-btn-secondary"><?php echo s(get_string('restorelabel', 'local_aisgk')); ?></a>
        </div>
    </form>
</div>
<script>
(function() {
    const tbody = document.querySelector('#local-aisgk-toc-table tbody');
    if (!tbody) {
        return;
    }

    const renumber = function() {
        Array.from(tbody.querySelectorAll('tr')).forEach(function(row, idx) {
            row.querySelector('td').textContent = idx + 1;
            ['sobai', 'tenbai', 'trang', 'endtrang', 'delete', 'rawline'].forEach(function(name) {
                const field = row.querySelector('[name^="' + name + '["]');
                if (field) {
                    field.name = name + '[' + idx + ']';
                }
            });
            const addbtn = row.querySelector('.local-aisgk-addline');
            if (addbtn) {
                addbtn.setAttribute('data-add-after', idx);
            }
        });
    };

    const makeRow = function() {
        const tr = document.createElement('tr');
        tr.innerHTML = '<td class="local-aisgk-ctr"></td>' +
            '<td class="local-aisgk-ctr"><button type="button" class="local-aisgk-addline">+</button></td>' +
            '<td><input type="number" name="sobai[]" value=""></td>' +
            '<td><input type="text" name="tenbai[]" value=""></td>' +
            '<td><input type="number" name="trang[]" value=""></td>' +
            '<td><input type="number" name="endtrang[]" value=""></td>' +
            '<td class="local-aisgk-source-cell" title="<?php echo s($bookdisplay); ?>"><?php echo s($bookdisplay); ?></td>' +
            '<td class="local-aisgk-ctr"><input type="checkbox" name="delete[]" value="1"></td>' +
            '<input type="hidden" name="rawline[]" value="">';
        return tr;
    };

    tbody.addEventListener('click', function(e) {
        const btn = e.target.closest('.local-aisgk-addline');
        if (!btn) {
            return;
        }
        e.preventDefault();
        const row = btn.closest('tr');
        const newRow = makeRow();
        if (row && row.nextSibling) {
            tbody.insertBefore(newRow, row.nextSibling);
        } else {
            tbody.appendChild(newRow);
        }
        renumber();
    });

    renumber();
})();
</script>
<?php
echo $OUTPUT->footer();
