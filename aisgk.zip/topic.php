<?php
require('../../config.php');

use local_aisgk\book_repository;
use local_aisgk\local\service\scan_service;
use local_aisgk\toc_repository;

$courseid = required_param('id', PARAM_INT);
$bookid = optional_param('bookid', 0, PARAM_INT);
$action = optional_param('action', '', PARAM_ALPHA);
$columns = optional_param('columns', 1, PARAM_INT);
$psm = optional_param('psm', 4, PARAM_INT);
$splitpercent = optional_param('splitpercent', 50, PARAM_INT);

$course = get_course($courseid);
require_login($course);
$context = context_course::instance($courseid);
require_capability('local/aisgk:createtopic', $context);

$PAGE->set_context($context);
$PAGE->set_url('/local/aisgk/topic.php', ['id' => $courseid, 'bookid' => $bookid]);
$PAGE->set_pagelayout('embedded');
$PAGE->set_title(get_string('createtopic', 'local_aisgk'));

$books = book_repository::get_all_by_courseid($courseid);
if (!$books) {
    throw new moodle_exception('bookrequired', 'local_aisgk');
}
if ($bookid < 1) {
    $bookid = (int)reset($books)->id;
}
$book = book_repository::get_by_id($bookid);
if (!$book || (int)$book->courseid !== $courseid) {
    throw new moodle_exception('invalidparameter');
}

if ($action === 'save' && confirm_sesskey() && data_submitted()) {
    $rows = [];
    $sobais = optional_param_array('sobai', [], PARAM_RAW_TRIMMED);
    $tenbais = optional_param_array('tenbai', [], PARAM_RAW_TRIMMED);
    $trangs = optional_param_array('trang', [], PARAM_RAW_TRIMMED);
    $endtrangs = optional_param_array('endtrang', [], PARAM_RAW_TRIMMED);
    $rawlines = optional_param_array('rawline', [], PARAM_RAW_TRIMMED);
    $deletes = optional_param_array('delete', [], PARAM_INT);
    $max = max(count($sobais), count($tenbais), count($trangs), count($endtrangs), count($rawlines));

    for ($i = 0; $i < $max; $i++) {
        if (!empty($deletes[$i])) {
            continue;
        }
        $row = [
            'sobai' => $sobais[$i] ?? '',
            'tenbai' => $tenbais[$i] ?? '',
            'trang' => $trangs[$i] ?? '',
            'endtrang' => $endtrangs[$i] ?? '',
            'rawline' => $rawlines[$i] ?? '',
        ];
        if (trim(implode('', array_map('strval', $row))) === '') {
            continue;
        }
        $rows[] = $row;
    }
    $rows = toc_repository::calculate_end_pages($rows);
    toc_repository::replace_book_toc($bookid, $rows);
    redirect(
        new moodle_url('/local/aisgk/topic.php', ['id' => $courseid, 'bookid' => $bookid]),
        get_string('tocsaved', 'local_aisgk'),
        null,
        \core\output\notification::NOTIFY_SUCCESS
    );
}

if ($action === 'scan' && confirm_sesskey()) {
    scan_service::queue_toc_scan($bookid, $USER->id, $columns, $splitpercent, $psm);
    redirect(
        new moodle_url('/local/aisgk/topic.php', ['id' => $courseid, 'bookid' => $bookid]),
        get_string('tocscanqueued', 'local_aisgk'),
        null,
        \core\output\notification::NOTIFY_SUCCESS
    );
}

$tocrows = toc_repository::get_by_bookid($bookid);
if (!$tocrows) {
    for ($i = 0; $i < 8; $i++) {
        $tocrows[] = (object)['sobai' => '', 'tenbai' => '', 'trang' => '', 'endtrang' => '', 'rawline' => ''];
    }
}

$statusmap = [
    'queued' => ['alert-info', get_string('scanstatusqueued', 'local_aisgk')],
    'running' => ['alert-warning', get_string('scanstatusrunning', 'local_aisgk')],
    'done' => ['alert-success', get_string('scanstatusdone', 'local_aisgk', (int)($book->lastscanitemcount ?? 0))],
    'failed' => ['alert-danger', format_string(get_string('scanstatusfailed', 'local_aisgk', s((string)($book->scanmessage ?? ''))))],
];
[$statusclass, $statustext] = $statusmap[$book->scanstatus ?? 'idle'] ?? ['alert-secondary', get_string('scanstatusidle', 'local_aisgk')];

echo $OUTPUT->header();
?>
<style>
.local-aisgk-topic-manager {padding: 10px; font-size: 13px;}
.local-aisgk-topbar, .local-aisgk-actions {display:flex; gap:8px; align-items:end; flex-wrap:wrap; margin-bottom:10px;}
.local-aisgk-topbar .fitem, .local-aisgk-actions .fitem {display:flex; flex-direction:column; gap:4px;}
.local-aisgk-table-wrap {overflow:auto; max-height:58vh; border:1px solid #dbe3ea; border-radius:6px; background:#fff;}
.local-aisgk-toc-table {width:100%; min-width:980px; border-collapse:collapse;}
.local-aisgk-toc-table th, .local-aisgk-toc-table td {border:1px solid #e5e7eb; padding:4px; vertical-align:top; font-size:12px;}
.local-aisgk-toc-table th {background:#f8f9fa; position:sticky; top:0; z-index:1;}
.local-aisgk-toc-table input[type="text"], .local-aisgk-toc-table input[type="number"], .local-aisgk-toc-table textarea {width:100%; box-sizing:border-box; font-size:12px; padding:4px 6px;}
.local-aisgk-toc-table textarea {min-height:52px; resize:vertical;}
.local-aisgk-status {margin-bottom:10px;}
</style>
<div class="local-aisgk-topic-manager">
    <form method="get" action="<?php echo new moodle_url('/local/aisgk/topic.php'); ?>" class="local-aisgk-topbar">
        <input type="hidden" name="id" value="<?php echo (int)$courseid; ?>">
        <div class="fitem">
            <label for="id_bookid"><?php echo s(get_string('bookselect', 'local_aisgk')); ?></label>
            <select id="id_bookid" name="bookid">
                <?php foreach ($books as $option): ?>
                    <option value="<?php echo (int)$option->id; ?>" <?php echo ((int)$option->id === (int)$bookid) ? 'selected' : ''; ?>><?php echo s($option->name ?: $option->filename); ?></option>
                <?php endforeach; ?>
            </select>
        </div>
        <button type="submit" class="btn btn-secondary"><?php echo s(get_string('viewchange', 'local_aisgk')); ?></button>
    </form>

    <div class="alert <?php echo $statusclass; ?> local-aisgk-status"><?php echo $statustext; ?></div>

    <form method="post" action="<?php echo new moodle_url('/local/aisgk/topic.php', ['id' => $courseid, 'bookid' => $bookid, 'action' => 'scan']); ?>" class="local-aisgk-actions">
        <input type="hidden" name="sesskey" value="<?php echo sesskey(); ?>">
        <div class="fitem">
            <label for="id_columns">Cột</label>
            <select id="id_columns" name="columns">
                <option value="1">1</option>
                <option value="2">2</option>
            </select>
        </div>
        <div class="fitem">
            <label for="id_psm">PSM</label>
            <input type="number" id="id_psm" name="psm" min="3" max="13" value="4">
        </div>
        <div class="fitem">
            <label for="id_splitpercent">Split %</label>
            <input type="number" id="id_splitpercent" name="splitpercent" min="20" max="80" value="50">
        </div>
        <button type="submit" class="btn btn-primary"><?php echo s(get_string('scantoc', 'local_aisgk')); ?></button>
    </form>

    <form method="post" action="<?php echo new moodle_url('/local/aisgk/topic.php', ['id' => $courseid, 'bookid' => $bookid, 'action' => 'save']); ?>">
        <input type="hidden" name="sesskey" value="<?php echo sesskey(); ?>">
        <div class="local-aisgk-table-wrap">
            <table class="local-aisgk-toc-table">
                <thead>
                    <tr>
                        <th>#</th>
                        <th><?php echo s(get_string('sobai', 'local_aisgk')); ?></th>
                        <th><?php echo s(get_string('tenbai', 'local_aisgk')); ?></th>
                        <th><?php echo s(get_string('trangbatdau', 'local_aisgk')); ?></th>
                        <th><?php echo s(get_string('trangketthuc', 'local_aisgk')); ?></th>
                        <th><?php echo s(get_string('rawline', 'local_aisgk')); ?></th>
                        <th>Xóa</th>
                    </tr>
                </thead>
                <tbody>
                <?php foreach ($tocrows as $i => $row): ?>
                    <tr>
                        <td><?php echo (int)$i + 1; ?></td>
                        <td><input type="number" name="sobai[<?php echo $i; ?>]" value="<?php echo s((string)$row->sobai); ?>"></td>
                        <td><input type="text" name="tenbai[<?php echo $i; ?>]" value="<?php echo s((string)$row->tenbai); ?>"></td>
                        <td><input type="number" name="trang[<?php echo $i; ?>]" value="<?php echo s((string)$row->trang); ?>"></td>
                        <td><input type="number" name="endtrang[<?php echo $i; ?>]" value="<?php echo s((string)$row->endtrang); ?>"></td>
                        <td><textarea name="rawline[<?php echo $i; ?>]"><?php echo s((string)$row->rawline); ?></textarea></td>
                        <td style="text-align:center"><input type="checkbox" name="delete[<?php echo $i; ?>]" value="1"></td>
                    </tr>
                <?php endforeach; ?>
                </tbody>
            </table>
        </div>
        <div class="mt-2">
            <button type="submit" class="btn btn-success"><?php echo s(get_string('savechanges', 'local_aisgk')); ?></button>
        </div>
    </form>
</div>
<?php
echo $OUTPUT->footer();
