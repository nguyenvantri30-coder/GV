<?php
require('../../config.php');

use local_aisgk\book_repository;
use local_aisgk\toc_repository;

$courseid = required_param('id', PARAM_INT);
$bookid = optional_param('bookid', 0, PARAM_INT);

$course = get_course($courseid);
require_login($course);

$context = context_course::instance($courseid);
require_capability('local/aisgk:createtopic', $context);

$PAGE->set_context($context);
$PAGE->set_url('/local/aisgk/topic.php', ['id' => $courseid, 'bookid' => $bookid]);
$PAGE->set_pagelayout('embedded');
$PAGE->set_title('Tạo chủ đề');

$books = book_repository::get_all_by_courseid($courseid);
if (empty($books)) {
    echo $OUTPUT->header();
    echo html_writer::div('Khóa học này chưa có SGK. Hãy tải SGK trước.', 'alert alert-warning m-3');
    echo $OUTPUT->footer();
    exit;
}

if ($bookid <= 0) {
    $bookid = (int)reset($books)->id;
}
$book = book_repository::get_by_id($bookid);
if (!$book || (int)$book->courseid !== $courseid) {
    $bookid = (int)reset($books)->id;
    $book = book_repository::get_by_id($bookid);
}

$tocrows = toc_repository::get_by_bookid($bookid);
if (empty($tocrows)) {
    $tocrows[] = (object)['sobai'=>'','tenbai'=>'','trang'=>'','endtrang'=>'','rawline'=>''];
}

$bookoptions = [];
foreach ($books as $item) {
    $label = trim((string)$item->name) !== '' ? $item->name : $item->filename;
    $bookoptions[$item->id] = '[' . (int)$item->id . '] ' . $label;
}

echo $OUTPUT->header();
?>
<style>
html, body.pagelayout-embedded {height:100%;overflow:hidden !important;}
body.pagelayout-embedded #page-wrapper,
body.pagelayout-embedded #page,
body.pagelayout-embedded #page-content,
body.pagelayout-embedded #region-main-box,
body.pagelayout-embedded #region-main,
body.pagelayout-embedded [role="main"] {height:100%;overflow:hidden !important;}
#page.drawers, #page {margin-top:0;}
.local-aisgk-topic-ui {height: calc(92vh - 10px); padding:8px; display:flex; flex-direction:column; gap:8px; box-sizing:border-box; overflow:hidden;}
.local-aisgk-toolbar, .local-aisgk-footer {display:flex; align-items:center; gap:6px; flex-wrap:nowrap;}
.local-aisgk-toolbar .field {display:flex; align-items:center; gap:4px; min-width:0;}
.local-aisgk-toolbar label {margin:0; font-size:12px; white-space:nowrap;}
.local-aisgk-toolbar select, .local-aisgk-toolbar input[type="text"] {height:30px; font-size:12px; padding:3px 6px;}
.local-aisgk-toolbar .booksel {min-width:300px; max-width:420px;}
.local-aisgk-toolbar .narrow {width:68px;}
.local-aisgk-toolbar .statusline {margin-left:auto; font-size:12px; white-space:nowrap; color:#2f4f4f; min-width:130px; text-align:right;}
.local-aisgk-draftview {border:1px solid #dbe3ea; background:#f8fbff; border-radius:6px; min-height:30px; max-height:58px; padding:5px 8px; font-size:12px; line-height:1.35; overflow:auto; white-space:pre-line;}
.local-aisgk-tablewrap {flex:1; min-height:0; border:1px solid #dbe3ea; border-radius:6px; overflow:auto; background:#fff;}
.table.local-aisgk-table {width:100%; margin:0; table-layout:fixed; border-collapse:collapse;}
.local-aisgk-table th, .local-aisgk-table td {padding:3px 4px; vertical-align:top; font-size:12px; border:1px solid #e5e7eb;}
.local-aisgk-table thead th {position:sticky; top:0; background:#f8f9fa; z-index:1; white-space:nowrap;}
.local-aisgk-table th.col-index, .local-aisgk-table td.col-index {width:34px; text-align:center;}
.local-aisgk-table th.col-add, .local-aisgk-table td.col-add {width:26px; text-align:center;}
.local-aisgk-table th.col-no, .local-aisgk-table td.col-no {width:72px;}
.local-aisgk-table th.col-start, .local-aisgk-table td.col-start, .local-aisgk-table th.col-end, .local-aisgk-table td.col-end {width:72px;}
.local-aisgk-table th.col-source, .local-aisgk-table td.col-source {width:78px;}
.local-aisgk-table th.col-check, .local-aisgk-table td.col-check {width:44px; text-align:center;}
.local-aisgk-table th.col-title, .local-aisgk-table td.col-title {width:auto;}
.local-aisgk-table input[type="text"], .local-aisgk-table input[type="number"] {width:100%; box-sizing:border-box; height:26px; padding:2px 4px; font-size:12px;}
.local-aisgk-table .btn {min-height:26px; padding:2px 6px; font-size:12px;}
.local-aisgk-footer {padding-top:2px;}
.local-aisgk-footer .leftbtns {display:flex; gap:6px;}
.local-aisgk-footer .rightbtns {margin-left:auto; display:flex; gap:6px;}
.local-aisgk-muted {font-size:11px; color:#6b7280;}
</style>

<div class="local-aisgk-topic-ui" id="local-aisgk-topic-ui"
     data-courseid="<?php echo (int)$courseid; ?>"
     data-bookid="<?php echo (int)$bookid; ?>"
     data-sesskey="<?php echo sesskey(); ?>">

    <div class="local-aisgk-toolbar">
        <div class="field">
            <label for="aisgk-bookid">SGK</label>
            <?php echo html_writer::select($bookoptions, 'bookid', $bookid, false, ['id' => 'aisgk-bookid', 'class' => 'booksel form-select']); ?>
        </div>
        <div class="field">
            <button type="button" class="btn btn-secondary" id="aisgk-view-book">View</button>
        </div>
        <div class="field">
            <label for="aisgk-columns">Cột</label>
            <select id="aisgk-columns" class="form-select narrow"><option value="1">1</option><option value="2">2</option></select>
        </div>
        <div class="field">
            <label for="aisgk-psm">PSM</label>
            <select id="aisgk-psm" class="form-select narrow"><option value="3">3</option><option value="4">4</option><option value="6" selected>6</option><option value="7">7</option><option value="11">11</option></select>
        </div>
        <div class="field">
            <label for="aisgk-tocpage">TOC page</label>
            <input type="text" id="aisgk-tocpage" class="form-control narrow" value="<?php echo (int)$book->tocfrompage . '-' . (int)$book->toctopage; ?>">
        </div>
        <div class="field"><button type="button" class="btn btn-secondary" id="aisgk-scan">Scan TOC</button></div>
        <div class="field"><button type="button" class="btn btn-secondary" id="aisgk-fix">Fix spelling</button></div>
        <div class="field"><button type="button" class="btn btn-secondary" id="aisgk-clear">Clear</button></div>
        <div class="statusline" id="aisgk-status">Ready</div>
    </div>

    <div class="local-aisgk-draftview" id="aisgk-draftview">Draft view</div>

    <div class="local-aisgk-tablewrap">
        <table class="table local-aisgk-table">
            <thead>
                <tr>
                    <th class="col-index">#</th>
                    <th class="col-add">+</th>
                    <th class="col-no">Lesson no.</th>
                    <th class="col-title">Lesson title</th>
                    <th class="col-start">Start page</th>
                    <th class="col-end">End page</th>
                    <th class="col-source">Source</th>
                    <th class="col-check">Check</th>
                </tr>
            </thead>
            <tbody id="aisgk-tbody">
            <?php foreach ($tocrows as $idx => $row): ?>
                <tr>
                    <td class="col-index row-index"><?php echo $idx + 1; ?></td>
                    <td class="col-add"><button type="button" class="btn btn-secondary btn-sm row-add">+</button></td>
                    <td class="col-no"><input type="text" class="form-control row-no" value="<?php echo s((string)($row->sobai ?? '')); ?>"></td>
                    <td class="col-title"><input type="text" class="form-control row-title" value="<?php echo s((string)($row->tenbai ?? '')); ?>"></td>
                    <td class="col-start"><input type="number" min="1" class="form-control row-start" value="<?php echo s((string)($row->trang ?? '')); ?>"></td>
                    <td class="col-end"><input type="number" min="1" class="form-control row-end" value="<?php echo s((string)($row->endtrang ?? '')); ?>"></td>
                    <td class="col-source row-source"><?php echo ((string)($row->rawline ?? '') !== '') ? 'Saved' : ''; ?></td>
                    <td class="col-check"><button type="button" class="btn btn-secondary btn-sm row-delete">✓</button></td>
                </tr>
            <?php endforeach; ?>
            </tbody>
        </table>
    </div>

    <div class="local-aisgk-footer">
        <div class="leftbtns">
            <button type="button" class="btn btn-secondary" id="aisgk-create">Tạo</button>
            <button type="button" class="btn btn-danger" id="aisgk-delete-db">Xóa</button>
        </div>
        <div class="rightbtns">
            <button type="button" class="btn btn-primary" id="aisgk-save">Save</button>
            <button type="button" class="btn btn-secondary" id="aisgk-restore">Restore</button>
        </div>
    </div>
</div>

<script>
(function() {
    const ui = document.getElementById('local-aisgk-topic-ui');
    const courseid = parseInt(ui.dataset.courseid, 10);
    const sesskey = ui.dataset.sesskey;
    const tbody = document.getElementById('aisgk-tbody');
    const statusEl = document.getElementById('aisgk-status');
    const draftEl = document.getElementById('aisgk-draftview');

    function esc(v) {
        return String(v == null ? '' : v)
            .replace(/&/g, '&amp;').replace(/</g, '&lt;')
            .replace(/>/g, '&gt;').replace(/"/g, '&quot;');
    }
    function updateIndexes() {
        Array.prototype.forEach.call(tbody.querySelectorAll('tr'), function(tr, idx) {
            const cell = tr.querySelector('.row-index');
            if (cell) cell.textContent = String(idx + 1);
        });
    }
    function oneEmptyRow() {
        return {sobai:'', tenbai:'', trang:'', endtrang:'', rawline:'', source:''};
    }
    function rowHtml(row) {
        const source = row.source || (row.rawline ? 'Scan' : '');
        return '<tr>' +
            '<td class="col-index row-index"></td>' +
            '<td class="col-add"><button type="button" class="btn btn-secondary btn-sm row-add">+</button></td>' +
            '<td class="col-no"><input type="text" class="form-control row-no" value="'+ esc(row.sobai || '') +'"></td>' +
            '<td class="col-title"><input type="text" class="form-control row-title" value="'+ esc(row.tenbai || '') +'"></td>' +
            '<td class="col-start"><input type="number" min="1" class="form-control row-start" value="'+ esc(row.trang || '') +'"></td>' +
            '<td class="col-end"><input type="number" min="1" class="form-control row-end" value="'+ esc(row.endtrang || '') +'"></td>' +
            '<td class="col-source row-source">'+ esc(source) +'</td>' +
            '<td class="col-check"><button type="button" class="btn btn-secondary btn-sm row-delete">✓</button></td>' +
            '</tr>';
    }
    function appendRow(row, afterTr) {
        const temp = document.createElement('tbody');
        temp.innerHTML = rowHtml(row || oneEmptyRow());
        const tr = temp.firstChild;
        if (afterTr && afterTr.parentNode === tbody) {
            tbody.insertBefore(tr, afterTr.nextSibling);
        } else {
            tbody.appendChild(tr);
        }
        updateIndexes();
        return tr;
    }
    function clearTableToOneRow() {
        tbody.innerHTML = '';
        appendRow(oneEmptyRow());
    }
    function collectRows() {
        return Array.prototype.map.call(tbody.querySelectorAll('tr'), function(tr) {
            return {
                sobai: tr.querySelector('.row-no').value.trim(),
                tenbai: tr.querySelector('.row-title').value.trim(),
                trang: tr.querySelector('.row-start').value.trim(),
                endtrang: tr.querySelector('.row-end').value.trim(),
                rawline: '',
                source: tr.querySelector('.row-source').textContent.trim()
            };
        });
    }
    function setRows(rows) {
        tbody.innerHTML = '';
        (rows && rows.length ? rows : [oneEmptyRow()]).forEach(function(r) { appendRow(r); });
        updateIndexes();
    }
    function parsePageRange(v) {
        const m = String(v || '').trim().match(/^(\d+)\s*[-,]\s*(\d+)$/);
        if (m) return {frompage: parseInt(m[1], 10), topage: parseInt(m[2], 10)};
        const n = String(v || '').trim().match(/^(\d+)$/);
        if (n) { const p = parseInt(n[1], 10); return {frompage: p, topage: p}; }
        return {frompage: 3, topage: 4};
    }
    async function postJson(url, data) {
        const resp = await fetch(url, {
            method: 'POST',
            headers: {'Content-Type': 'application/json'},
            body: JSON.stringify(data)
        });
        if (!resp.ok) {
            throw new Error('HTTP ' + resp.status);
        }
        return await resp.json();
    }
    async function runTimed(label, fn) {
        const start = Date.now();
        draftEl.textContent = label + '... 0.0s';
        statusEl.textContent = label + '...';
        const timer = setInterval(function() {
            draftEl.textContent = label + '... ' + (((Date.now() - start) / 1000).toFixed(1)) + 's';
        }, 200);
        try {
            const result = await fn();
            const secs = ((Date.now() - start) / 1000).toFixed(1);
            const rows = result && typeof result.rowcount !== 'undefined' ? result.rowcount : (result.rows ? result.rows.length : 0);
            statusEl.textContent = '✓ Done, +' + rows + ' rows';
            draftEl.textContent = '✓ Done, +' + rows + ' rows (' + secs + 's)';
            return result;
        } catch (e) {
            statusEl.textContent = 'Error';
            draftEl.textContent = (e && e.message) ? e.message : 'Error';
            throw e;
        } finally {
            clearInterval(timer);
        }
    }

    tbody.addEventListener('click', function(e) {
        const addBtn = e.target.closest('.row-add');
        if (addBtn) {
            appendRow(oneEmptyRow(), addBtn.closest('tr'));
            return;
        }
        const delBtn = e.target.closest('.row-delete');
        if (delBtn) {
            const tr = delBtn.closest('tr');
            if (tr) tr.remove();
            if (!tbody.querySelector('tr')) clearTableToOneRow();
            updateIndexes();
        }
    });

    document.getElementById('aisgk-clear').addEventListener('click', function() {
        clearTableToOneRow();
        statusEl.textContent = '✓ Done, +0 rows';
        draftEl.textContent = '✓ Done, +0 rows';
    });

    document.getElementById('aisgk-fix').addEventListener('click', function() {
        Array.prototype.forEach.call(tbody.querySelectorAll('tr'), function(tr) {
            const input = tr.querySelector('.row-title');
            input.value = input.value.replace(/\s+/g, ' ').trim();
        });
        statusEl.textContent = '✓ Done, +0 rows';
        draftEl.textContent = '✓ Done, +0 rows';
    });

    document.getElementById('aisgk-view-book').addEventListener('click', function() {
        const bid = document.getElementById('aisgk-bookid').value;
        window.location.href = M.cfg.wwwroot + '/local/aisgk/topic.php?id=' + courseid + '&bookid=' + bid;
    });

    document.getElementById('aisgk-scan').addEventListener('click', async function() {
        await runTimed('Scanning', async function() {
            const range = parsePageRange(document.getElementById('aisgk-tocpage').value);
            const data = await postJson(M.cfg.wwwroot + '/local/aisgk/ajax/scan.php', {
                sesskey: sesskey,
                courseid: courseid,
                bookid: parseInt(document.getElementById('aisgk-bookid').value, 10),
                columns: parseInt(document.getElementById('aisgk-columns').value, 10),
                psm: parseInt(document.getElementById('aisgk-psm').value, 10),
                frompage: range.frompage,
                topage: range.topage
            });
            setRows(data.rows || []);
            return {rowcount: (data.rows || []).length};
        });
    });

    document.getElementById('aisgk-save').addEventListener('click', async function() {
        await runTimed('Saving', async function() {
            const range = parsePageRange(document.getElementById('aisgk-tocpage').value);
            return await postJson(M.cfg.wwwroot + '/local/aisgk/ajax/save.php', {
                sesskey: sesskey,
                courseid: courseid,
                bookid: parseInt(document.getElementById('aisgk-bookid').value, 10),
                frompage: range.frompage,
                topage: range.topage,
                rows: collectRows()
            });
        });
    });

    document.getElementById('aisgk-restore').addEventListener('click', async function() {
        await runTimed('Restoring', async function() {
            const data = await postJson(M.cfg.wwwroot + '/local/aisgk/ajax/load.php', {
                sesskey: sesskey,
                courseid: courseid,
                bookid: parseInt(document.getElementById('aisgk-bookid').value, 10)
            });
            setRows(data.rows || []);
            if (data.tocpage) document.getElementById('aisgk-tocpage').value = data.tocpage;
            return {rowcount: (data.rows || []).length};
        });
    });

    document.getElementById('aisgk-delete-db').addEventListener('click', async function() {
        if (!window.confirm('Bạn có chắc muốn xóa toàn bộ mục lục?')) return;
        await runTimed('Deleting', async function() {
            const data = await postJson(M.cfg.wwwroot + '/local/aisgk/ajax/delete.php', {
                sesskey: sesskey,
                courseid: courseid
            });
            clearTableToOneRow();
            return {rowcount: 0};
        });
    });

    document.getElementById('aisgk-create').addEventListener('click', function() {
        draftEl.textContent = 'Nút Tạo sẽ làm sau.';
    });

    updateIndexes();
})();
</script>
<?php
echo $OUTPUT->footer();
