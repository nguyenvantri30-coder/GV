<?php
require('../../config.php');

use local_aisgk\book_repository;
use local_aisgk\toc_repository;

$courseid = required_param('id', PARAM_INT);
$bookid = optional_param('bookid', 0, PARAM_INT);
$course = get_course($courseid);
require_login($course);
$context = context_course::instance($courseid);
require_capability('local/aisgk:createtopic', $context);

$PAGE->set_context($context);
$PAGE->set_url('/local/aisgk/topic.php', ['id' => $courseid, 'bookid' => $bookid]);
$PAGE->set_pagelayout('embedded');
$PAGE->set_title(get_string('createtopic', 'local_aisgk') . ': ' . format_string($course->fullname) );

$books = book_repository::get_all_by_courseid($courseid);
if (!$books) {
    throw new moodle_exception('bookrequired', 'local_aisgk');
}
if ($bookid < 1) {
    $bookid = (int)reset($books)->id;
}
$book = book_repository::get_by_id($bookid);
if (!$book || (int)$book->courseid !== $courseid) {
    throw new moodle_exception('invalidparameter');
}

$tocrows = toc_repository::get_draft_by_bookid($bookid);
if (!$tocrows) {
    $tocrows = toc_repository::get_by_bookid($bookid);
}
if (!$tocrows) {
    $tocrows = [(object)['sobai' => '', 'tenbai' => '', 'trang' => '', 'endtrang' => '', 'rawline' => '']];
}

function local_aisgk_book_label($book): string {
    $name = trim((string)($book->name ?: $book->filename));
    return '[' . (int)$book->id . '] ' . $name;
}

echo $OUTPUT->header();
?>
<style>
.modal-content{
    box-shadow: none !important;
    border: 1px solid #cfd7e3 !important; /* giữ lại viền xám nhẹ */
}

.modal-dialog{
    outline: none !important;
}

.modal:focus,
.modal-dialog:focus,
.modal-content:focus{
    outline: none !important;
    box-shadow: none !important;
}

html, body {background:#fff; height:100%; overflow:hidden; width:100%; max-width:100%;}
body.pagelayout-embedded #region-main-box,
body.pagelayout-embedded #region-main,
body.pagelayout-embedded [role="main"] {padding:0 !important; margin:0 !important; height:100%;}

.local-aisgk-topic-shell{width:100%;max-width:100%;height:90vh;box-sizing:border-box;padding:10px 12px 12px;font-size:13px;color:#1f2937;display:flex;flex-direction:column;gap:8px;overflow:hidden;}
.local-aisgk-gridwrap{flex:1;min-height:0;border:1px solid #cfd7e3;border-radius:8px;overflow:auto;background:#fff;width:100%;max-width:100%;box-sizing:border-box;-webkit-overflow-scrolling:touch;}

.local-aisgk-toolbar,.local-aisgk-footer{display:flex;align-items:center;gap:8px;flex-wrap:wrap;min-height:36px;}
.local-aisgk-advancedscan{display:inline-flex;align-items:center;gap:6px;white-space:nowrap;font-size:12px;color:#344054;}
.local-aisgk-advancedscan input{margin:0;}
.local-aisgk-toolbar select,.local-aisgk-toolbar input{height:34px;border:1px solid #cbd5e1;border-radius:6px;padding:4px 8px;box-sizing:border-box;}
.local-aisgk-toolbar .local-aisgk-bookselect{min-width:100px;max-width:150px;}
.local-aisgk-toolbar .local-aisgk-small{width:70px;text-align:center;}
.local-aisgk-toolbar .local-aisgk-page{width:78px;text-align:center;}
.local-aisgk-btn{height:34px;padding:0 12px;border-radius:6px;border:1px solid #cbd5e1;background:#fff;color:#111827;cursor:pointer;}
.local-aisgk-btn-primary{background:#2563eb;border-color:#2563eb;color:#fff;}
.local-aisgk-btn-green{background:#2e7d32;border-color:#2e7d32;color:#fff;}
.local-aisgk-btn-red{background:#b91c1c;border-color:#b91c1c;color:#fff;}
.local-aisgk-btn:disabled{opacity:.6;cursor:not-allowed;}
.local-aisgk-pill{display:inline-flex;align-items:center;height:28px;padding:0 10px;border-radius:999px;background:#dcfce7;color:#166534;font-size:12px;white-space:nowrap;}
.local-aisgk-draftview{min-height:20px;font-size:12px;color:#475467;}
.local-aisgk-progressbox{position:relative;height:28px;border:1px solid #cbd5e1;border-radius:999px;background:#eef2f7;overflow:hidden;}
.local-aisgk-progressfill{position:absolute;left:0;top:0;height:100%;width:0;background:#2563eb;transition:width .25s ease;}
.local-aisgk-progresstext{position:relative;z-index:1;height:100%;display:flex;align-items:center;justify-content:center;padding:0 12px;font-size:12px;font-weight:600;color:#0f172a;white-space:nowrap;overflow:hidden;text-overflow:ellipsis;}
.local-aisgk-gridwrap{
    flex:1;
    min-height:0;
    border:1px solid #cfd7e3;
    border-radius:8px;
    overflow:auto;
    background:#fff;

    width:100%;
    max-width:100%;
    box-sizing:border-box;
}
.local-aisgk-toc-table{width:max-content;min-width:100%;border-collapse:collapse;table-layout:fixed;max-width:none}
.local-aisgk-toc-table th,.local-aisgk-toc-table td{border:1px solid #d9e1ec;padding:4px;font-size:12px;vertical-align:middle;}
#local-aisgk-toc-table thead th {
    position: sticky;
    top: 0;
    z-index: 2;
    color: white;
    background: #555; /* giống màu header hiện tại */
} 
.local-aisgk-toc-table th{background:#f8fafc;white-space:nowrap;}
.local-aisgk-toc-table th:nth-child(1),.local-aisgk-toc-table td:nth-child(1){width:34px;text-align:center;}
.local-aisgk-toc-table th:nth-child(2),.local-aisgk-toc-table td:nth-child(2){width:34px;text-align:center;}
.local-aisgk-toc-table th:nth-child(3),.local-aisgk-toc-table td:nth-child(3){width:76px;}
.local-aisgk-toc-table th:nth-child(5),.local-aisgk-toc-table td:nth-child(5){width:82px;}
.local-aisgk-toc-table th:nth-child(6),.local-aisgk-toc-table td:nth-child(6){width:82px;}
.local-aisgk-toc-table th:nth-child(7),.local-aisgk-toc-table td:nth-child(7){width:86px;}
.local-aisgk-toc-table th:nth-child(8),.local-aisgk-toc-table td:nth-child(8){width:56px;text-align:center;}
.local-aisgk-toc-table th:nth-child(4),.local-aisgk-toc-table td:nth-child(4){width:320px;min-width:320px;}
.local-aisgk-toc-table input{width:100%;height:30px;border:1px solid #cbd5e1;border-radius:4px;padding:4px 6px;box-sizing:border-box;}
.local-aisgk-addline,.local-aisgk-rowdelete,.local-aisgk-clearall{width:26px;height:26px;border-radius:6px;border:1px solid #cbd5e1;background:#fff;cursor:pointer;padding:0;line-height:1;}
.local-aisgk-clearall{width:auto;padding:0 8px;}
.local-aisgk-source{color:#475467;white-space:nowrap;overflow:hidden;text-overflow:ellipsis;}
.local-aisgk-footer {display: grid; grid-template-columns: 1fr auto 1fr; align-items: center; gap: 12px; margin-top: 12px; }
.local-aisgk-footer-left {display: flex; justify-content: flex-start; align-items: center; gap: 8px; }
.local-aisgk-footer-center {display: flex; justify-content: center; align-items: center; }
.local-aisgk-footer-right {display: flex; justify-content: flex-end; align-items: center; gap: 8px; }
#local-aisgk-create {
    /* Kích thước và font (giữ lại yêu cầu của bạn) */
    min-width: 240px; height: 34px; font-weight: 600; text-align: center;

    /* Căn chỉnh nội dung bên trong */
    display: inline-flex; align-items: center; justify-content: center; cursor: pointer; border: none; outline: none;

    /* Màu sắc và Bo góc */
    background: linear-gradient(135deg, #6e8efb, #a777e3); /* Màu Gradient xanh tím hiện đại */ color: #ffffff; border-radius: 8px; /* Bo góc nhẹ cho hiện đại */
    
    /* Hiệu ứng đổ bóng và chuyển động */
    box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1); transition: all 0.3s ease; /* Làm mượt mọi thay đổi */ padding: 0 20px; text-transform: uppercase; /* Viết hoa nhìn sẽ khỏe khoắn hơn */ letter-spacing: 0.5px;
}

/* Hiệu ứng khi rê chuột vào (Hover) */
#local-aisgk-create:hover {background: linear-gradient(135deg, #a777e3, #6e8efb); /* Đảo ngược màu */ box-shadow: 0 6px 12px rgba(0, 0, 0, 0.15); /* Đổ bóng đậm hơn */ transform: translateY(-2px); /* Nút bay lên nhẹ một chút */ }

/* Hiệu ứng khi click (Active) */
#local-aisgk-create:active {transform: translateY(0); /* Nút lún xuống khi bấm */ box-shadow: 0 2px 4px rgba(0, 0, 0, 0.1); }

/* Hiệu ứng khi bị vô hiệu hóa (Disabled) */
#local-aisgk-create:disabled {background: #ccc; cursor: not-allowed; transform: none; }
.local-aisgk-row-invalid,
.local-aisgk-row-invalid td {background: #fff1f1 !important; }
.local-aisgk-row-invalid input {border-color: #dc3545 !important; background: #fff8f8 !important; }
.local-aisgk-row-invalid td:first-child {box-shadow: inset 3px 0 0 #dc3545; }

.local-aisgk-toc-table th:nth-child(4) input,.local-aisgk-toc-table td:nth-child(4) input{min-width:0;}
@media (max-width: 992px) {
    .local-aisgk-topic-shell{height:calc(100vh - 8px);padding:8px;gap:6px;}
    .local-aisgk-toolbar,.local-aisgk-footer{gap:6px;}
    .local-aisgk-toolbar .local-aisgk-bookselect{min-width:150px;max-width:100%;flex:1 1 220px;}
    .local-aisgk-toolbar label{font-size:12px;}
    .local-aisgk-footer{grid-template-columns:1fr;}
    .local-aisgk-footer-left,.local-aisgk-footer-center,.local-aisgk-footer-right{justify-content:stretch;}
    .local-aisgk-footer-left .local-aisgk-btn,.local-aisgk-footer-center .local-aisgk-btn,.local-aisgk-footer-right .local-aisgk-btn{width:100%;}
    #local-aisgk-create{min-width:0;width:100%;}
}

</style>
<div class="local-aisgk-topic-shell">
    <div class="local-aisgk-toolbar">
        <select id="local-aisgk-bookid" class="local-aisgk-bookselect">
            <?php foreach ($books as $option): ?>
                <option value="<?php echo (int)$option->id; ?>" <?php echo ((int)$option->id === (int)$bookid) ? 'selected' : ''; ?>><?php echo s(local_aisgk_book_label($option)); ?></option>
            <?php endforeach; ?>
        </select>

        <label for="local-aisgk-columns">Cột</label>
        <select id="local-aisgk-columns" class="local-aisgk-small"><option value="1">1</option><option value="2">2</option></select>
        <label for="local-aisgk-psm">PSM</label>
        <input type="number" id="local-aisgk-psm" class="local-aisgk-small" min="3" max="13" value="4">
        <label for="local-aisgk-page">TOC page</label>
        <input type="text" id="local-aisgk-page" class="local-aisgk-page" value="3-4">
        <label class="local-aisgk-advancedscan" for="local-aisgk-advancedscan"><input type="checkbox" id="local-aisgk-advancedscan"> Advanced scan</label>
        <button type="button" class="local-aisgk-btn local-aisgk-btn-primary" id="local-aisgk-scan"><?php echo s(get_string('scantoc', 'local_aisgk')); ?></button>
        <button type="button" class="local-aisgk-btn" id="local-aisgk-fix"><?php echo s(get_string('fixspellinglabel', 'local_aisgk')); ?></button>
        <button type="button" class="local-aisgk-btn" id="local-aisgk-checkspelling"><?php echo 'Check'; ?></button>
        <span class="local-aisgk-pill" id="local-aisgk-status">✓ Done, +<?php echo (int)count($tocrows); ?> rows</span>
    </div>

    <div class="local-aisgk-draftview" id="local-aisgk-draftview"><?php echo s(get_string('draftview', 'local_aisgk')); ?></div>

    <div class="local-aisgk-gridwrap">
        <table class="local-aisgk-toc-table" id="local-aisgk-toc-table">
            <thead>
                <tr>
                    <th>#</th>
                    <th>+</th>
                    <th><?php echo s(get_string('sobai', 'local_aisgk')); ?></th>
                    <th><?php echo s(get_string('tenbai', 'local_aisgk')); ?></th>
                    <th><?php echo s(get_string('trangbatdau', 'local_aisgk')); ?></th>
                    <th><?php echo s(get_string('trangketthuc', 'local_aisgk')); ?></th>
                    <th>Source</th>
                    <th><button type="button" class="local-aisgk-clearall" id="local-aisgk-clearall"><?php echo s(get_string('clearlabel', 'local_aisgk')); ?></button></th>
                </tr>
            </thead>
            <tbody>
            <?php foreach ($tocrows as $i => $row): ?>
                <tr>
                    <td><?php echo $i + 1; ?></td>
                    <td><button type="button" class="local-aisgk-addline">+</button></td>
                    <td><input type="number" class="row-sobai" value="<?php echo s((string)$row->sobai); ?>"></td>
                    <td><input type="text" class="row-tenbai" value="<?php echo s((string)$row->tenbai); ?>"></td>
                    <td><input type="number" class="row-trang" value="<?php echo s((string)$row->trang); ?>"></td>
                    <td><input type="number" class="row-endtrang" value="<?php echo s((string)$row->endtrang); ?>"></td>
                    <td class="local-aisgk-source" title="<?php echo s($book->name ?: $book->filename); ?>"><?php echo s($book->name ?: $book->filename); ?></td>
                    <td><button type="button" class="local-aisgk-rowdelete">×</button><input type="hidden" class="row-rawline" value="<?php echo s((string)$row->rawline); ?>"></td>
                </tr>
            <?php endforeach; ?>
            </tbody>
        </table>
    </div>

    <div class="local-aisgk-footer">
        <div class="local-aisgk-footer-left">
            <button type="button" class="local-aisgk-btn local-aisgk-btn-red" id="local-aisgk-delete"><?php echo 'Xóa'; ?></button>
        </div>

        <div class="local-aisgk-footer-center">
            <button type="button" class="local-aisgk-btn" id="local-aisgk-create"><?php echo 'Tạo'; ?></button>
        </div>

        <div class="local-aisgk-footer-right">
            <button type="button" class="local-aisgk-btn local-aisgk-btn-green" id="local-aisgk-save"><?php echo s(get_string('savechanges', 'local_aisgk')); ?></button>
            <button type="button" class="local-aisgk-btn" id="local-aisgk-restore"><?php echo s(get_string('restorelabel', 'local_aisgk')); ?></button>
        </div>
    </div>
</div>
<script>
(function() {
    const courseid = <?php echo (int)$courseid; ?>;
    const sesskey = <?php echo json_encode(sesskey()); ?>;
    const ajaxUrl = <?php echo json_encode((new moodle_url('/local/aisgk/topic_ajax.php', ['id' => $courseid]))->out(false)); ?>;
    const viewBase = <?php echo json_encode((new moodle_url('/local/aisgk/topic.php', ['id' => $courseid]))->out(false)); ?>;
    const tbody = document.querySelector('#local-aisgk-toc-table tbody');
    const statusEl = document.getElementById('local-aisgk-status');
    const draftEl = document.getElementById('local-aisgk-draftview');
    const sourceLabel = () => {
        const sel = document.getElementById('local-aisgk-bookid');
        return sel.options[sel.selectedIndex].text.replace(/^\[\d+\]\s*/, '');
    };

    function makeRow(row) {
        row = row || {};
        const tr = document.createElement('tr');
        tr.innerHTML = '' +
            '<td></td>' +
            '<td><button type="button" class="local-aisgk-addline">+</button></td>' +
            '<td><input type="number" class="row-sobai" value="' + escapeHtml(row.sobai || '') + '"></td>' +
            '<td><input type="text" class="row-tenbai" value="' + escapeHtml(row.tenbai || '') + '"></td>' +
            '<td><input type="number" class="row-trang" value="' + escapeHtml(row.trang || '') + '"></td>' +
            '<td><input type="number" class="row-endtrang" value="' + escapeHtml(row.endtrang || '') + '"></td>' +
            '<td class="local-aisgk-source" title="' + escapeHtml(sourceLabel()) + '">' + escapeHtml(sourceLabel()) + '</td>' +
            '<td><button type="button" class="local-aisgk-rowdelete">×</button><input type="hidden" class="row-rawline" value="' + escapeHtml(row.rawline || '') + '"></td>' ;
        return tr;
    }

    function escapeHtml(str) {
        return String(str).replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;').replace(/"/g, '&quot;');
    }

    function renumber() {
        Array.from(tbody.querySelectorAll('tr')).forEach((tr, idx) => {
            tr.children[0].textContent = idx + 1;
            const cell = tr.querySelector('.local-aisgk-source');
            if (cell) {
                cell.textContent = sourceLabel();
                cell.title = sourceLabel();
            }
        });
        if (!tbody.querySelector('tr')) {
            tbody.appendChild(makeRow({}));
            renumber();
        }
    }

    function rowsFromTable() {
        return Array.from(tbody.querySelectorAll('tr')).map(tr => ({
            sobai: tr.querySelector('.row-sobai').value.trim(),
            tenbai: tr.querySelector('.row-tenbai').value.trim(),
            trang: tr.querySelector('.row-trang').value.trim(),
            endtrang: tr.querySelector('.row-endtrang').value.trim(),
            rawline: tr.querySelector('.row-rawline').value.trim()
        }));
    }

    function renderRows(rows) {
        tbody.innerHTML = '';
        (rows && rows.length ? rows : [{}]).forEach(row => tbody.appendChild(makeRow(row)));
        renumber();
    }

    function setStatus(text) {
        statusEl.textContent = text;
    }

    function setDraft(text) {
        draftEl.textContent = text;
    }

    function escapeHtmlAttr(str) {
        return escapeHtml(str).replace(/'/g, '&#39;');
    }

    function renderAdvancedProgress(percent, message, state) {
        const safePercent = Math.max(0, Math.min(100, Number(percent) || 0));
        const text = message || 'Đang xử lý...';
        const color = state === 'done' ? '#2e7d32' : (state === 'error' ? '#b91c1c' : '#2563eb');
        draftEl.innerHTML = '' +
            '<div class="local-aisgk-progressbox">' +
            '<div class="local-aisgk-progressfill" style="width:' + safePercent + '%;background:' + color + '"></div>' +
            '<div class="local-aisgk-progresstext">' + escapeHtml(text) + '</div>' +
            '</div>';
    }

    function localAisgkGetInt(row, selector) {
    const el = row.querySelector(selector);
    if (!el) {
        return null;
    }
    const raw = (el.value || '').trim();
    if (raw === '') {
        return null;
    }
    const num = parseInt(raw, 10);
    return Number.isNaN(num) ? null : num;
    }

    function localAisgkGetText(row, selector) {
        const el = row.querySelector(selector);
        if (!el) {
            return '';
        }
        return (el.textContent || '').replace(/\s+/g, ' ').trim();
    }

    async function postJson(op, payload, label) {
        const bookid = document.getElementById('local-aisgk-bookid').value;
        let timer = null;
        const start = Date.now();
        if (label) {
            timer = setInterval(() => {
                setDraft(label + '... ' + ((Date.now() - start) / 1000).toFixed(1) + 's');
            }, 200);
        }
        try {
            const res = await fetch(ajaxUrl + '&bookid=' + encodeURIComponent(bookid) + '&op=' + encodeURIComponent(op) + '&sesskey=' + encodeURIComponent(sesskey), {
                method: 'POST',
                headers: {'Content-Type': 'application/json'},
                body: JSON.stringify(payload || {})
            });
            const data = await res.json();
            if (!res.ok || !data.ok) {
                throw new Error((data && data.error) ? data.error : 'Request failed');
            }
            if (timer) {
                clearInterval(timer);
                const t = ((Date.now() - start) / 1000).toFixed(1);
                setDraft('✓ Done, +' + ((data.rows || []).length) + ' rows (' + t + 's)');
            }
            return data;
        } catch (err) {
            if (timer) {
                clearInterval(timer);
            }
            setDraft('Failed');
            throw err;
        }
    }
    function localAisgkClearInvalidRows() {
        document.querySelectorAll('#local-aisgk-toc-table tbody tr').forEach(function(row) {
            row.classList.remove('local-aisgk-row-invalid');
            row.removeAttribute('title');
        });
    }
    function localAisgkMarkInvalid(row, reason) {
        row.classList.add('local-aisgk-row-invalid');
            if (reason) {
                row.title = reason;
            }
    }
    tbody.addEventListener('click', function(e) {
        const addBtn = e.target.closest('.local-aisgk-addline');
        if (addBtn) {
            const tr = addBtn.closest('tr');
            const next = makeRow({});
            if (tr && tr.nextSibling) {
                tbody.insertBefore(next, tr.nextSibling);
            } else {
                tbody.appendChild(next);
            }
            renumber();
            return;
        }
        const delBtn = e.target.closest('.local-aisgk-rowdelete');
        if (delBtn) {
            delBtn.closest('tr').remove();
            renumber();
        }
    });
    function localAisgkValidateRows() {
        localAisgkClearInvalidRows();

        const rows = Array.from(document.querySelectorAll('#local-aisgk-toc-table tbody tr'));
        let hasError = false;
        let prevBySource = {};

        rows.forEach(function(row) {
            const start = localAisgkGetInt(row, '.row-trang');
            const end = localAisgkGetInt(row, '.row-endtrang');
            const source = localAisgkGetText(row, '.local-aisgk-source');

            let invalid = false;
            let reasons = [];

            if (start === null) {
                invalid = true;
                reasons.push('Start page không được trống');
            }

            if (end === null) {
                invalid = true;
                reasons.push('End page không được trống');
            }

            if (start !== null && end !== null && !(start < end)) {
                invalid = true;
                reasons.push('Start page phải nhỏ hơn end page');
            }

            if (source !== '' && prevBySource[source] && start !== null) {
                const prev = prevBySource[source];

                if (!(prev.start < start)) {
                    invalid = true;
                    reasons.push('Start page dòng trên phải nhỏ hơn start page dòng dưới');
                }

                if (start !== prev.end + 1) {
                    invalid = true;
                    reasons.push('Start page dòng dưới phải bằng end page dòng trên + 1');
                }
            }

            if (invalid) {
                hasError = true;
                localAisgkMarkInvalid(row, reasons.join(' | '));
            }

            if (source !== '' && start !== null && end !== null) {
                prevBySource[source] = {
                    start: start,
                    end: end
                };
            }
        });

        return !hasError;
    }

    const fixBtn = document.getElementById('local-aisgk-fix');
    if (fixBtn) {
        fixBtn.addEventListener('click', function() {
            const ok = localAisgkValidateRows();
            const invalidRows = document.querySelectorAll('#local-aisgk-toc-table tbody tr.local-aisgk-row-invalid');

            if (ok) {
                //setDraft('✓ Hợp lệ');
                setStatus('✓ Hợp lệ');
                return;
            }

            //setDraft('⚠ ' + invalidRows.length + ' dòng có lỗi');
            setStatus('⚠ ' + invalidRows.length + ' dòng có lỗi');

            const firstInvalid = document.querySelector('#local-aisgk-toc-table tbody tr.local-aisgk-row-invalid');
            if (firstInvalid) {
                firstInvalid.scrollIntoView({behavior: 'smooth', block: 'center'});
            }
        });
    }

    const checkSpellingBtn = document.getElementById('local-aisgk-checkspelling');
    if (checkSpellingBtn) {
        checkSpellingBtn.addEventListener('click', function() {
            setDraft('Check chính tả chưa bật');
        });
    }


    async function scanAdvanced() {
        const bookid = document.getElementById('local-aisgk-bookid').value;
        const res = await fetch(ajaxUrl + '&bookid=' + encodeURIComponent(bookid) + '&op=scanadvanced&sesskey=' + encodeURIComponent(sesskey), {
            method: 'POST',
            headers: {'Content-Type': 'application/json'},
            body: JSON.stringify({
                columns: document.getElementById('local-aisgk-columns').value,
                psm: document.getElementById('local-aisgk-psm').value,
                pagerange: document.getElementById('local-aisgk-page').value
            })
        });

        if (!res.body) {
            throw new Error('Trình duyệt không hỗ trợ stream phản hồi');
        }

        const reader = res.body.getReader();
        const decoder = new TextDecoder();
        let buffer = '';
        let resultRows = null;
        let streamError = null;

        renderAdvancedProgress(3, 'Khởi động Advanced scan...', 'running');

        while (true) {
            const chunk = await reader.read();
            if (chunk.done) {
                break;
            }
            buffer += decoder.decode(chunk.value, {stream: true});
            const parts = buffer.split(/\r?\n/);
            buffer = parts.pop();

            parts.forEach(function(line) {
                line = line.trim();
                if (!line) {
                    return;
                }
                let data = null;
                try {
                    data = JSON.parse(line);
                } catch (e) {
                    return;
                }
                if (!data.ok) {
                    streamError = data.error || 'Scan nâng cao thất bại';
                    return;
                }
                if (data.type === 'progress' && data.progress) {
                    const step = Number(data.progress.step || 1);
                    const base = {1: 18, 2: 42, 3: 78, 4: 96};
                    let percent = base[step] || 10;
                    if (data.progress.status === 'done' && step === 4) {
                        percent = 100;
                    }
                    renderAdvancedProgress(percent, data.progress.message || '', data.progress.status === 'done' ? 'done' : 'running');
                }
                if (data.type === 'result') {
                    resultRows = data.rows || [];
                }
            });
        }

        if (!res.ok) {
            throw new Error(streamError || 'Scan nâng cao thất bại');
        }
        if (streamError) {
            throw new Error(streamError);
        }
        if (!resultRows) {
            throw new Error('Không nhận được kết quả scan nâng cao');
        }

        renderAdvancedProgress(100, 'Hoàn tất quét mục lục', 'done');
        return {rows: resultRows};
    }

    document.getElementById('local-aisgk-clearall').addEventListener('click', function() {
        renderRows([{}]);
        setStatus('✓ Done, +0 rows');
        setDraft('Cleared');
    });

    document.getElementById('local-aisgk-scan').addEventListener('click', async function() {
        try {
            setStatus('Scanning');
            const advanced = document.getElementById('local-aisgk-advancedscan').checked;
            const data = advanced ? await scanAdvanced() : await postJson('scan', {
                columns: document.getElementById('local-aisgk-columns').value,
                psm: document.getElementById('local-aisgk-psm').value,
                pagerange: document.getElementById('local-aisgk-page').value
            }, 'Scanning');
            renderRows(data.rows);
            setStatus('✓ Done, +' + data.rows.length + ' rows');
            if (!advanced) {
                setDraft('✓ Done, +' + data.rows.length + ' rows');
            }
        } catch (err) {
            setStatus('Failed');
            if (document.getElementById('local-aisgk-advancedscan').checked) {
                renderAdvancedProgress(100, 'Advanced scan thất bại', 'error');
            }
            alert(err.message);
        }
    });

    document.getElementById('local-aisgk-save').addEventListener('click', async function() {
        try {
            setStatus('Saving');
            const data = await postJson('save', {rows: rowsFromTable()}, 'Saving');
            renderRows(data.rows);
            setStatus('✓ Done, +' + data.rows.length + ' rows');
        } catch (err) {
            setStatus('Failed');
            alert(err.message);
        }
    });

    document.getElementById('local-aisgk-restore').addEventListener('click', async function() {
        try {
            setStatus('Restoring');
            const data = await postJson('restore', {}, 'Restoring');
            renderRows(data.rows);
            setStatus('✓ Done, +' + data.rows.length + ' rows');
        } catch (err) {
            setStatus('Failed');
            alert(err.message);
        }
    });

    document.getElementById('local-aisgk-delete').addEventListener('click', async function() {
        if (!confirm('Bạn có chắc muốn xóa toàn bộ mục lục?')) {
            return;
        }
        try {
            setStatus('Deleting');
            await postJson('delete', {}, 'Deleting');
            renderRows([{}]);
            setStatus('✓ Done, +0 rows');
        } catch (err) {
            setStatus('Failed');
            alert(err.message);
        }
    });


    document.getElementById('local-aisgk-create').addEventListener('click', function() {
        const ok = localAisgkValidateRows();
        if (!ok) {
            const firstInvalid = document.querySelector('#local-aisgk-toc-table tbody tr.local-aisgk-row-invalid');
            if (firstInvalid) {
                firstInvalid.scrollIntoView({behavior: 'smooth', block: 'center'});
            }
            return;
        }
        setDraft('Tạo chưa bật');
    });

    renumber();
})();
</script>
<?php
echo $OUTPUT->footer();
