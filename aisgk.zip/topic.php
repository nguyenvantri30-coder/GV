<style>

.local-aisgk-dialog-backdrop{position:fixed;inset:0;z-index:10050;background:rgba(15,23,42,.24);display:flex;align-items:center;justify-content:center;padding:12px}
.local-aisgk-dialog{width:min(360px,92vw);background:#fff;border:1px solid #cbd5e1;border-radius:12px;box-shadow:0 16px 42px rgba(15,23,42,.26);padding:12px}
.local-aisgk-dialog-title{font-weight:700;font-size:14px;margin-bottom:6px;color:#0f172a}
.local-aisgk-dialog-body{font-size:13px;line-height:1.4;color:#334155;white-space:pre-wrap;max-height:45vh;overflow:auto}
.local-aisgk-dialog-actions{display:flex;gap:6px;justify-content:flex-end;margin-top:10px}
.local-aisgk-dialog-actions .btn,.local-aisgk-dialog-actions button{padding:5px 10px!important;font-size:12px!important;line-height:1.2!important;border-radius:8px!important;min-height:auto!important}
.local-aisgk-dialog-confirm{border-color:#fca5a5}
.local-aisgk-msgbox{position:fixed;top:14px;right:14px;z-index:10050;background:#fff;border:1px solid #cbd5e1;border-radius:10px;box-shadow:0 8px 24px rgba(15,23,42,.18);padding:8px 12px;max-width:340px;font-size:13px;line-height:1.35}

</style>
<?php
require('../../config.php');

use local_aisgk\book_repository;
use local_aisgk\toc_repository;

$courseid = required_param('id', PARAM_INT);
$bookid = optional_param('bookid', 0, PARAM_INT);
$course = get_course($courseid);
require_login($course);
$context = context_course::instance($courseid);
require_capability('local/aisgk:createtopic', $context);

$PAGE->set_context($context);
$PAGE->set_url('/local/aisgk/topic.php', ['id' => $courseid, 'bookid' => $bookid]);
$PAGE->set_pagelayout('embedded');
$PAGE->set_title(get_string('createtopic', 'local_aisgk') . ': ' . format_string($course->fullname) );

$books = book_repository::get_all_by_courseid($courseid);
if (!$books) {
    throw new moodle_exception('bookrequired', 'local_aisgk');
}
$book = null;
if ($bookid > 0) {
    $book = book_repository::get_by_id($bookid);
    if (!$book || (int)$book->courseid !== $courseid) {
        throw new moodle_exception('invalidparameter');
    }
    $tocrows = toc_repository::get_draft_by_bookid($bookid);
    if (!$tocrows) {
        $tocrows = toc_repository::get_by_bookid($bookid);
    }
} else {
    $tocrows = toc_repository::get_draft_by_courseid($courseid);
    if (!$tocrows) {
        $tocrows = toc_repository::get_by_courseid($courseid);
    }
}
if (!$tocrows) {
    $tocrows = [(object)['sobai' => '', 'tenbai' => '', 'trang' => '', 'endtrang' => '', 'rawline' => '']];
}
$initialtocrange = '4';
if ($book) {
    $tf = max(1, (int)($book->tocfrompage ?? 4));
    $tt = max($tf, (int)($book->toctopage ?? $tf));
    $initialtocrange = ($tf === $tt) ? (string)$tf : ($tf . '-' . $tt);
}

function local_aisgk_book_label($book): string {
    $name = trim((string)($book->name ?: $book->filename));
    return '[' . (int)$book->id . '] ' . $name;
}

echo $OUTPUT->header();
?>
<style>
.modal-content{
    box-shadow: none !important;
    border: 1px solid #cfd7e3 !important; /* giữ lại viền xám nhẹ */
}

.modal-dialog{
    outline: none !important;
}

.modal:focus,
.modal-dialog:focus,
.modal-content:focus{
    outline: none !important;
    box-shadow: none !important;
}

html, body {background:#fff; height:100%; overflow:hidden; width:100%; max-width:100%;}
body.pagelayout-embedded #region-main-box,
body.pagelayout-embedded #region-main,
body.pagelayout-embedded [role="main"] {padding:0 !important; margin:0 !important; height:100%;}

.local-aisgk-topic-shell{width:100%;max-width:100%;height:90vh;box-sizing:border-box;padding:10px 12px 12px;font-size:13px;color:#1f2937;display:flex;flex-direction:column;gap:8px;overflow:hidden;}
.local-aisgk-gridwrap{flex:1;min-height:0;border:1px solid #cfd7e3;border-radius:8px;overflow:auto;background:#fff;width:100%;max-width:100%;box-sizing:border-box;-webkit-overflow-scrolling:touch;}

.local-aisgk-toolbar,.local-aisgk-footer{display:flex;align-items:center;gap:8px;flex-wrap:wrap;min-height:36px;}
.local-aisgk-toolbar select,.local-aisgk-toolbar input{height:34px;border:1px solid #cbd5e1;border-radius:6px;padding:4px 8px;box-sizing:border-box;}
.local-aisgk-toolbar .local-aisgk-bookselect{min-width:100px;max-width:150px;}
.local-aisgk-toolbar .local-aisgk-small{width:70px;text-align:center;}
.local-aisgk-toolbar .local-aisgk-page{width:78px;text-align:center;}
.local-aisgk-btn{height:34px;padding:0 12px;border-radius:6px;border:1px solid #cbd5e1;background:#fff;color:#111827;cursor:pointer;}
.local-aisgk-btn-primary{background:#2563eb;border-color:#2563eb;color:#fff;}
.local-aisgk-btn-green{background:#2e7d32;border-color:#2e7d32;color:#fff;}
.local-aisgk-btn-red{background:#b91c1c;border-color:#b91c1c;color:#fff;}
.local-aisgk-btn:disabled{opacity:.6;cursor:not-allowed;}
.local-aisgk-pill{display:inline-flex;align-items:center;height:28px;padding:0 10px;border-radius:999px;background:#dcfce7;color:#166534;font-size:12px;white-space:nowrap;}
.local-aisgk-draftview{min-height:20px;font-size:12px;color:#475467;}
.local-aisgk-progressbox{position:relative;height:28px;border:1px solid #cbd5e1;border-radius:999px;background:#eef2f7;overflow:hidden;}
.local-aisgk-progressfill{position:absolute;left:0;top:0;height:100%;width:0;background:#2563eb;transition:width .25s ease;}
.local-aisgk-progresstext{position:relative;z-index:1;height:100%;display:flex;align-items:center;justify-content:center;padding:0 12px;font-size:12px;font-weight:600;color:#0f172a;white-space:nowrap;overflow:hidden;text-overflow:ellipsis;}
.local-aisgk-gridwrap{
    flex:1;
    min-height:0;
    border:1px solid #cfd7e3;
    border-radius:8px;
    overflow:auto;
    background:#fff;

    width:100%;
    max-width:100%;
    box-sizing:border-box;
}
.local-aisgk-toc-table{width:max-content;min-width:100%;border-collapse:collapse;table-layout:fixed;max-width:none}
.local-aisgk-toc-table th,.local-aisgk-toc-table td{border:1px solid #d9e1ec;padding:4px;font-size:12px;vertical-align:middle;}
#local-aisgk-toc-table thead th {
    position: sticky;
    top: 0;
    z-index: 2;
    color: white;
    background: #555; /* giống màu header hiện tại */
} 
.local-aisgk-toc-table th{background:#f8fafc;white-space:nowrap;}
.local-aisgk-toc-table th:nth-child(1),.local-aisgk-toc-table td:nth-child(1){width:34px;text-align:center;}
.local-aisgk-toc-table th:nth-child(2),.local-aisgk-toc-table td:nth-child(2){width:34px;text-align:center;}
.local-aisgk-toc-table th:nth-child(3),.local-aisgk-toc-table td:nth-child(3){width:76px;}
.local-aisgk-toc-table th:nth-child(5),.local-aisgk-toc-table td:nth-child(5){width:82px;}
.local-aisgk-toc-table th:nth-child(6),.local-aisgk-toc-table td:nth-child(6){width:82px;}
.local-aisgk-toc-table th:nth-child(7),.local-aisgk-toc-table td:nth-child(7){width:86px;}
.local-aisgk-toc-table th:nth-child(8),.local-aisgk-toc-table td:nth-child(8){width:56px;text-align:center;}
.local-aisgk-toc-table th:nth-child(4),.local-aisgk-toc-table td:nth-child(4){width:320px;min-width:320px;}
.local-aisgk-toc-table input{width:100%;height:30px;border:1px solid #cbd5e1;border-radius:4px;padding:4px 6px;box-sizing:border-box;}
.local-aisgk-addline,.local-aisgk-rowdelete,.local-aisgk-clearall{width:26px;height:26px;border-radius:6px;border:1px solid #cbd5e1;background:#fff;cursor:pointer;padding:0;line-height:1;}
.local-aisgk-clearall{width:auto;padding:0 8px;}
.local-aisgk-source{color:#475467;white-space:nowrap;overflow:hidden;text-overflow:ellipsis;}
.local-aisgk-footer {display: grid; grid-template-columns: 1fr auto 1fr; align-items: center; gap: 12px; margin-top: 12px; }
.local-aisgk-footer-left {display: flex; justify-content: flex-start; align-items: center; gap: 8px; }
.local-aisgk-footer-center {display: flex; justify-content: center; align-items: center; }
.local-aisgk-footer-right {display: flex; justify-content: flex-end; align-items: center; gap: 8px; }
#local-aisgk-create {
    /* Kích thước và font (giữ lại yêu cầu của bạn) */
    min-width: 240px; height: 34px; font-weight: 600; text-align: center;

    /* Căn chỉnh nội dung bên trong */
    display: inline-flex; align-items: center; justify-content: center; cursor: pointer; border: none; outline: none;

    /* Màu sắc và Bo góc */
    background: linear-gradient(135deg, #6e8efb, #a777e3); /* Màu Gradient xanh tím hiện đại */ color: #ffffff; border-radius: 8px; /* Bo góc nhẹ cho hiện đại */
    
    /* Hiệu ứng đổ bóng và chuyển động */
    box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1); transition: all 0.3s ease; /* Làm mượt mọi thay đổi */ padding: 0 20px; text-transform: uppercase; /* Viết hoa nhìn sẽ khỏe khoắn hơn */ letter-spacing: 0.5px;
}

/* Hiệu ứng khi rê chuột vào (Hover) */
#local-aisgk-create:hover {background: linear-gradient(135deg, #a777e3, #6e8efb); /* Đảo ngược màu */ box-shadow: 0 6px 12px rgba(0, 0, 0, 0.15); /* Đổ bóng đậm hơn */ transform: translateY(-2px); /* Nút bay lên nhẹ một chút */ }

/* Hiệu ứng khi click (Active) */
#local-aisgk-create:active {transform: translateY(0); /* Nút lún xuống khi bấm */ box-shadow: 0 2px 4px rgba(0, 0, 0, 0.1); }

/* Hiệu ứng khi bị vô hiệu hóa (Disabled) */
#local-aisgk-create:disabled {background: #ccc; cursor: not-allowed; transform: none; }
.local-aisgk-row-invalid,
.local-aisgk-row-invalid td {background: #fff1f1 !important; }
.local-aisgk-row-invalid input {border-color: #dc3545 !important; background: #fff8f8 !important; }
.local-aisgk-row-invalid td:first-child {box-shadow: inset 3px 0 0 #dc3545; }

.local-aisgk-toc-table th:nth-child(4) input,.local-aisgk-toc-table td:nth-child(4) input{min-width:0;}

.local-aisgk-bookviewer-backdrop{position:fixed;inset:0;background:rgba(15,23,42,.55);z-index:9999;display:flex;align-items:center;justify-content:center;padding:18px}
.local-aisgk-bookviewer{background:#fff;border-radius:12px;box-shadow:0 20px 50px rgba(15,23,42,.35);width:min(96vw,1100px);height:min(92vh,820px);display:flex;flex-direction:column;overflow:hidden}
.local-aisgk-bookviewer-head{display:flex;align-items:center;gap:8px;padding:8px 10px;border-bottom:1px solid #e5e7eb;background:#f8fafc}
.local-aisgk-bookviewer-title{font-weight:700;flex:1;white-space:nowrap;overflow:hidden;text-overflow:ellipsis}
.local-aisgk-bookviewer-body{flex:1;overflow:auto;background:#e5e7eb;text-align:center;padding:10px}
.local-aisgk-bookviewer-body img{max-width:100%;height:auto;background:#fff;box-shadow:0 2px 10px rgba(15,23,42,.18)}

@media (max-width: 992px) {
    .local-aisgk-topic-shell{height:calc(100vh - 8px);padding:8px;gap:6px;}
    .local-aisgk-toolbar,.local-aisgk-footer{gap:6px;}
    .local-aisgk-toolbar .local-aisgk-bookselect{min-width:150px;max-width:100%;flex:1 1 220px;}
    .local-aisgk-toolbar label{font-size:12px;}
    .local-aisgk-footer{grid-template-columns:1fr;}
    .local-aisgk-footer-left,.local-aisgk-footer-center,.local-aisgk-footer-right{justify-content:stretch;}
    .local-aisgk-footer-left .local-aisgk-btn,.local-aisgk-footer-center .local-aisgk-btn,.local-aisgk-footer-right .local-aisgk-btn{width:100%;}
    #local-aisgk-create{min-width:0;width:100%;}
}

.local-aisgk-toolbar{display:flex;align-items:center;gap:8px;flex-wrap:wrap}.local-aisgk-toolbar select,.local-aisgk-toolbar input,.local-aisgk-toolbar button{height:34px;box-sizing:border-box;vertical-align:middle}.local-aisgk-bookselect{min-height:34px;padding:4px 8px;border:1px solid #cbd5e1;border-radius:7px;background:#fff}
</style>
<div class="local-aisgk-topic-shell">
    <div class="local-aisgk-toolbar">
        <select id="local-aisgk-bookid" class="local-aisgk-bookselect">
            <option value="0" <?php echo ((int)$bookid === 0) ? 'selected' : ''; ?>>All</option>
            <?php foreach ($books as $option): ?>
                <option value="<?php echo (int)$option->id; ?>" <?php echo ((int)$option->id === (int)$bookid) ? 'selected' : ''; ?>><?php echo s(local_aisgk_book_label($option)); ?></option>
            <?php endforeach; ?>
        </select>

        <label for="local-aisgk-page"><?php echo s(get_string('tocrange', 'local_aisgk')); ?></label>
        <input type="text" id="local-aisgk-page" class="local-aisgk-page" value="<?php echo s($initialtocrange); ?>" title="<?php echo s(get_string('tocrange_help', 'local_aisgk')); ?>">
        <button type="button" class="local-aisgk-btn" id="local-aisgk-viewbook"><?php echo s(get_string('viewbook', 'local_aisgk')); ?></button>
        <button type="button" class="local-aisgk-btn local-aisgk-btn-primary" id="local-aisgk-ai">AI</button>
        <span class="local-aisgk-pill" id="local-aisgk-status">✓ Done, +<?php echo (int)count($tocrows); ?> rows</span>
    </div>

    <div class="local-aisgk-draftview" id="local-aisgk-draftview"><?php echo s(get_string('draftview', 'local_aisgk')); ?></div>

    <div class="local-aisgk-gridwrap">
        <table class="local-aisgk-toc-table" id="local-aisgk-toc-table">
            <thead>
                <tr>
                    <th>#</th>
                    <th>+</th>
                    <th><?php echo s(get_string('sobai', 'local_aisgk')); ?></th>
                    <th><?php echo s(get_string('tenbai', 'local_aisgk')); ?></th>
                    <th><?php echo s(get_string('trangbatdau', 'local_aisgk')); ?></th>
                    <th><?php echo s(get_string('trangketthuc', 'local_aisgk')); ?></th>
                    <th>Source</th>
                    <th><button type="button" class="local-aisgk-clearall" id="local-aisgk-clearall"><?php echo s(get_string('clearlabel', 'local_aisgk')); ?></button></th>
                </tr>
            </thead>
            <tbody>
            <?php foreach ($tocrows as $i => $row): ?>
                <tr>
                    <td><?php echo $i + 1; ?></td>
                    <td><button type="button" class="local-aisgk-addline">+</button></td>
                    <td><input type="number" class="row-sobai" value="<?php echo s((string)$row->sobai); ?>"></td>
                    <td><input type="text" class="row-tenbai" value="<?php echo s((string)$row->tenbai); ?>"></td>
                    <td><input type="number" class="row-trang" value="<?php echo s((string)$row->trang); ?>"></td>
                    <td><input type="number" class="row-endtrang" value="<?php echo s((string)$row->endtrang); ?>"></td>
                    <?php $rowbookid = (int)($row->bookid ?? $bookid); $rowbookname = (string)($row->bookname ?? $row->bookfilename ?? ($book ? ($book->name ?: $book->filename) : 'All')); ?>
                    <td class="local-aisgk-source" title="<?php echo s($rowbookname); ?>"><?php echo s($rowbookname); ?></td>
                    <td><button type="button" class="local-aisgk-rowdelete">×</button><input type="hidden" class="row-bookid" value="<?php echo $rowbookid; ?>"><input type="hidden" class="row-bookname" value="<?php echo s($rowbookname); ?>"><input type="hidden" class="row-rawline" value="<?php echo s((string)$row->rawline); ?>"><input type="hidden" class="row-pl3-order" value="<?php echo s((string)($row->pl3_order ?? '')); ?>"><input type="hidden" class="row-ai-score" value="<?php echo s((string)($row->ai_score ?? '')); ?>"><input type="hidden" class="row-server-score" value="<?php echo s((string)($row->server_score ?? '')); ?>"><input type="hidden" class="row-final-score" value="<?php echo s((string)($row->final_score ?? '')); ?>"><input type="hidden" class="row-match-warning" value="<?php echo s((string)($row->match_warning ?? '')); ?>"></td>
                </tr>
            <?php endforeach; ?>
            </tbody>
        </table>
    </div>

    <div class="local-aisgk-footer">
        <div class="local-aisgk-footer-left">
            <button type="button" class="local-aisgk-btn local-aisgk-btn-red" id="local-aisgk-delete"><?php echo 'Xóa'; ?></button>
        </div>

        <div class="local-aisgk-footer-center">
            <button type="button" class="local-aisgk-btn" id="local-aisgk-create"><?php echo 'Tạo bài học'; ?></button>
            <button type="button" class="local-aisgk-btn local-aisgk-btn-red" id="local-aisgk-delete-lessons"><?php echo 'Xóa bài học'; ?></button>
        </div>

        <div class="local-aisgk-footer-right">
            <button type="button" class="local-aisgk-btn local-aisgk-btn-green" id="local-aisgk-save"><?php echo s(get_string('savechanges', 'local_aisgk')); ?></button>
            <button type="button" class="local-aisgk-btn" id="local-aisgk-restore"><?php echo s(get_string('restorelabel', 'local_aisgk')); ?></button>
        </div>
    </div>
</div>
<script>

function localAisgkDialog(options) {
    options = options || {};
    return new Promise(function(resolve) {
        try {
            var old = document.querySelector('.local-aisgk-dialog-backdrop');
            if (old) { old.remove(); }
            var mode = options.mode || 'message';
            var backdrop = document.createElement('div');
            backdrop.className = 'local-aisgk-dialog-backdrop';
            var box = document.createElement('div');
            box.className = 'local-aisgk-dialog local-aisgk-dialog-' + mode;
            var title = document.createElement('div');
            title.className = 'local-aisgk-dialog-title';
            title.textContent = options.title || (mode === 'confirm' ? 'Xác nhận' : 'Thông báo');
            var body = document.createElement('div');
            body.className = 'local-aisgk-dialog-body';
            body.textContent = String(options.message || '');
            var actions = document.createElement('div');
            actions.className = 'local-aisgk-dialog-actions';
            if (mode === 'confirm') {
                var cancel = document.createElement('button');
                cancel.type = 'button';
                cancel.className = 'btn btn-secondary';
                cancel.textContent = options.cancelText || 'Hủy';
                cancel.onclick = function(){ backdrop.remove(); resolve(false); };
                var ok = document.createElement('button');
                ok.type = 'button';
                ok.className = 'btn btn-danger';
                ok.textContent = options.okText || 'Đồng ý';
                ok.onclick = function(){ backdrop.remove(); resolve(true); };
                actions.appendChild(cancel);
                actions.appendChild(ok);
            } else {
                var close = document.createElement('button');
                close.type = 'button';
                close.className = 'btn btn-primary';
                close.textContent = options.okText || 'OK';
                close.onclick = function(){ backdrop.remove(); resolve(true); };
                actions.appendChild(close);
                if (options.timeout !== 0) {
                    setTimeout(function(){ if (backdrop.parentNode) { backdrop.remove(); resolve(true); } }, options.timeout || 2800);
                }
            }
            box.appendChild(title);
            box.appendChild(body);
            box.appendChild(actions);
            backdrop.appendChild(box);
            document.body.appendChild(backdrop);
        } catch(e) {
            if ((options.mode || 'message') === 'confirm') {
                resolve(window['confirm'](options.message || ''));
            } else {
                try { window['alert'](options.message || ''); } catch(_e) {}
                resolve(true);
            }
        }
    });
}
function localAisgkMsgBox(msg, type) {
    return localAisgkDialog({mode:'message', message:msg, title:(type === 'err' ? 'Lỗi' : 'Thông báo'), timeout:2800});
}
function localAisgkConfirm(msg, title) {
    return localAisgkDialog({mode:'confirm', message:msg, title:title || 'Xác nhận', okText:'Tiếp tục', cancelText:'Hủy'});
}
window.localAisgkDialog = window.localAisgkDialog || localAisgkDialog;
window.localAisgkMsgBox = window.localAisgkMsgBox || localAisgkMsgBox;
window.localAisgkConfirm = window.localAisgkConfirm || localAisgkConfirm;


(function() {
    const courseid = <?php echo (int)$courseid; ?>;
    const sesskey = <?php echo json_encode(sesskey()); ?>;
    const ajaxUrl = <?php echo json_encode((new moodle_url('/local/aisgk/topic_ajax.php', ['id' => $courseid]))->out(false)); ?>;
    const viewBase = <?php echo json_encode((new moodle_url('/local/aisgk/topic.php', ['id' => $courseid]))->out(false)); ?>;
    const bookLabels = <?php echo json_encode(array_reduce($books, static function($carry, $b) { $carry[(string)(int)$b->id] = local_aisgk_book_label($b); return $carry; }, []), JSON_UNESCAPED_UNICODE); ?>;
    const bookRanges = <?php echo json_encode(array_reduce($books, static function($carry, $b) { $from = max(1, (int)($b->tocfrompage ?? 4)); $to = max($from, (int)($b->toctopage ?? $from)); $carry[(string)(int)$b->id] = ($from === $to) ? (string)$from : ($from . '-' . $to); return $carry; }, []), JSON_UNESCAPED_UNICODE); ?>;
    const tbody = document.querySelector('#local-aisgk-toc-table tbody');
    const statusEl = document.getElementById('local-aisgk-status');
    const draftEl = document.getElementById('local-aisgk-draftview');
    const selectedBookId = () => document.getElementById('local-aisgk-bookid').value;
    const selectedBookName = () => {
        const sel = document.getElementById('local-aisgk-bookid');
        return sel.options[sel.selectedIndex].text.replace(/^\[\d+\]\s*/, '');
    };
    const sourceLabel = row => {
        if (row && row.bookname) { return row.bookname; }
        if (row && row.bookid && bookLabels[String(row.bookid)]) {
            return bookLabels[String(row.bookid)].replace(/^\[\d+\]\s*/, '');
        }
        return selectedBookName();
    };
    const sourceBookId = row => (row && row.bookid) ? row.bookid : (selectedBookId() !== '0' ? selectedBookId() : '');

    function makeRow(row) {
        row = row || {};
        const tr = document.createElement('tr');
        tr.innerHTML = '' +
            '<td></td>' +
            '<td><button type="button" class="local-aisgk-addline">+</button></td>' +
            '<td><input type="number" class="row-sobai" value="' + escapeHtml(row.sobai || '') + '"></td>' +
            '<td><input type="text" class="row-tenbai" value="' + escapeHtml(row.tenbai || '') + '"></td>' +
            '<td><input type="number" class="row-trang" value="' + escapeHtml(row.trang || '') + '"></td>' +
            '<td><input type="number" class="row-endtrang" value="' + escapeHtml(row.endtrang || '') + '"></td>' +
            '<td class="local-aisgk-source" title="' + escapeHtml(sourceLabel(row)) + '">' + escapeHtml(sourceLabel(row)) + '</td>' +
            '<td><button type="button" class="local-aisgk-rowdelete">×</button><input type="hidden" class="row-bookid" value="' + escapeHtml(sourceBookId(row)) + '"><input type="hidden" class="row-bookname" value="' + escapeHtml(sourceLabel(row)) + '"><input type="hidden" class="row-rawline" value="' + escapeHtml(row.rawline || '') + '"><input type="hidden" class="row-pl3-order" value="' + escapeHtml(row.pl3_order || '') + '"><input type="hidden" class="row-ai-score" value="' + escapeHtml(row.ai_score || '') + '"><input type="hidden" class="row-server-score" value="' + escapeHtml(row.server_score || '') + '"><input type="hidden" class="row-final-score" value="' + escapeHtml(row.final_score || '') + '"><input type="hidden" class="row-match-warning" value="' + escapeHtml(row.match_warning || '') + '"></td>' ;
        return tr;
    }

    function escapeHtml(str) {
        return String(str).replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;').replace(/"/g, '&quot;');
    }

    function renumber() {
        Array.from(tbody.querySelectorAll('tr')).forEach((tr, idx) => {
            tr.children[0].textContent = idx + 1;
            const cell = tr.querySelector('.local-aisgk-source');
            if (cell) {
                const hiddenName = tr.querySelector('.row-bookname');
                const name = hiddenName ? hiddenName.value : sourceLabel({});
                cell.textContent = name;
                cell.title = name;
            }
        });
        if (!tbody.querySelector('tr')) {
            tbody.appendChild(makeRow({}));
            renumber();
        }
    }

    function rowsFromTable() {
        return Array.from(tbody.querySelectorAll('tr')).map(tr => ({
            sobai: tr.querySelector('.row-sobai').value.trim(),
            tenbai: tr.querySelector('.row-tenbai').value.trim(),
            trang: tr.querySelector('.row-trang').value.trim(),
            endtrang: tr.querySelector('.row-endtrang').value.trim(),
            rawline: tr.querySelector('.row-rawline').value.trim(),
            pl3_order: tr.querySelector('.row-pl3-order') ? tr.querySelector('.row-pl3-order').value.trim() : '',
            ai_score: tr.querySelector('.row-ai-score') ? tr.querySelector('.row-ai-score').value.trim() : '',
            server_score: tr.querySelector('.row-server-score') ? tr.querySelector('.row-server-score').value.trim() : '',
            final_score: tr.querySelector('.row-final-score') ? tr.querySelector('.row-final-score').value.trim() : '',
            match_warning: tr.querySelector('.row-match-warning') ? tr.querySelector('.row-match-warning').value.trim() : '',
            bookid: tr.querySelector('.row-bookid') ? tr.querySelector('.row-bookid').value.trim() : '',
            bookname: tr.querySelector('.row-bookname') ? tr.querySelector('.row-bookname').value.trim() : ''
        }));
    }

    function renderRows(rows) {
        tbody.innerHTML = '';
        (rows && rows.length ? rows : [{}]).forEach(row => tbody.appendChild(makeRow(row)));
        renumber();
    }

    function setStatus(text) {
        statusEl.textContent = text;
    }

    function setDraft(text) {
        draftEl.textContent = text;
    }

    function escapeHtmlAttr(str) {
        return escapeHtml(str).replace(/'/g, '&#39;');
    }

    function renderAdvancedProgress(percent, message, state) {
        const safePercent = Math.max(0, Math.min(100, Number(percent) || 0));
        const text = message || 'Đang xử lý...';
        const color = state === 'done' ? '#2e7d32' : (state === 'error' ? '#b91c1c' : '#2563eb');
        draftEl.innerHTML = '' +
            '<div class="local-aisgk-progressbox">' +
            '<div class="local-aisgk-progressfill" style="width:' + safePercent + '%;background:' + color + '"></div>' +
            '<div class="local-aisgk-progresstext">' + escapeHtml(text) + '</div>' +
            '</div>';
    }

    function localAisgkGetInt(row, selector) {
    const el = row.querySelector(selector);
    if (!el) {
        return null;
    }
    const raw = (el.value || '').trim();
    if (raw === '') {
        return null;
    }
    const num = parseInt(raw, 10);
    return Number.isNaN(num) ? null : num;
    }

    function localAisgkGetText(row, selector) {
        const el = row.querySelector(selector);
        if (!el) {
            return '';
        }
        return (el.textContent || '').replace(/\s+/g, ' ').trim();
    }

    async function postJson(op, payload, label) {
        const bookid = document.getElementById('local-aisgk-bookid').value;
        let timer = null;
        const start = Date.now();
        if (label) {
            timer = setInterval(() => {
                setDraft(label + '... ' + ((Date.now() - start) / 1000).toFixed(1) + 's');
            }, 200);
        }
        try {
            const res = await fetch(ajaxUrl + '&bookid=' + encodeURIComponent(bookid) + '&op=' + encodeURIComponent(op) + '&sesskey=' + encodeURIComponent(sesskey), {
                method: 'POST',
                headers: {'Content-Type': 'application/json'},
                body: JSON.stringify(payload || {})
            });
            const raw = await res.text();
            let data = null;
            try {
                data = JSON.parse(raw);
            } catch (e) {
                throw new Error(raw || 'Response is not JSON');
            }
            if (!res.ok || !data.ok) {
                throw new Error((data && data.error) ? data.error : (raw || 'Yêu cầu thất bại'));
            }
            if (timer) {
                clearInterval(timer);
                const t = ((Date.now() - start) / 1000).toFixed(1);
                setDraft('✓ Done, +' + ((data.rows || []).length) + ' rows (' + t + 's)');
            }
            return data;
        } catch (err) {
            if (timer) {
                clearInterval(timer);
            }
            setDraft('Failed: ' + (err && err.message ? err.message : 'Unknown error'));
            throw err;
        }
    }
    function localAisgkClearInvalidRows() {
        document.querySelectorAll('#local-aisgk-toc-table tbody tr').forEach(function(row) {
            row.classList.remove('local-aisgk-row-invalid');
            row.removeAttribute('title');
        });
    }
    function localAisgkMarkInvalid(row, reason) {
        row.classList.add('local-aisgk-row-invalid');
            if (reason) {
                row.title = reason;
            }
    }
    tbody.addEventListener('click', function(e) {
        const addBtn = e.target.closest('.local-aisgk-addline');
        if (addBtn) {
            const tr = addBtn.closest('tr');
            const next = makeRow({});
            if (tr && tr.nextSibling) {
                tbody.insertBefore(next, tr.nextSibling);
            } else {
                tbody.appendChild(next);
            }
            renumber();
            return;
        }
        const delBtn = e.target.closest('.local-aisgk-rowdelete');
        if (delBtn) {
            delBtn.closest('tr').remove();
            renumber();
        }
    });
    function localAisgkValidateRows() {
        localAisgkClearInvalidRows();

        const rows = Array.from(document.querySelectorAll('#local-aisgk-toc-table tbody tr'));
        let hasError = false;
        let prevBySource = {};

        rows.forEach(function(row) {
            const start = localAisgkGetInt(row, '.row-trang');
            const end = localAisgkGetInt(row, '.row-endtrang');
            const source = localAisgkGetText(row, '.local-aisgk-source');

            let invalid = false;
            let reasons = [];

            if (start === null) {
                invalid = true;
                reasons.push('Start page không được trống');
            }

            if (end === null) {
                invalid = true;
                reasons.push('End page không được trống');
            }

            if (start !== null && end !== null && !(start <= end)) {
                invalid = true;
                reasons.push('Start page phải nhỏ hơn hoặc bằng end page');
            }

            if (source !== '' && prevBySource[source] && start !== null) {
                const prev = prevBySource[source];

                if (!(prev.start < start)) {
                    invalid = true;
                    reasons.push('Start page dòng trên phải nhỏ hơn start page dòng dưới');
                }

                if (start !== prev.end + 1) {
                    invalid = true;
                    reasons.push('Start page dòng dưới phải bằng end page dòng trên + 1');
                }
            }

            if (invalid) {
                hasError = true;
                localAisgkMarkInvalid(row, reasons.join(' | '));
            }

            if (source !== '' && start !== null && end !== null) {
                prevBySource[source] = {
                    start: start,
                    end: end
                };
            }
        });

        return !hasError;
    }


    document.getElementById('local-aisgk-clearall').addEventListener('click', function() {
        renderRows([{}]);
        setStatus('✓ Done, +0 rows');
        setDraft('Cleared');
    });


    async function loadCurrentSelection() {
        setStatus('Loading');
        const data = await postJson('load', {}, 'Loading');
        renderRows(data.rows || []);
        setStatus('✓ Done, +' + ((data.rows || []).length) + ' rows');
    }

    document.getElementById('local-aisgk-bookid').addEventListener('change', async function() {
        const bid = String(selectedBookId());
        const pageInput = document.getElementById('local-aisgk-page');
        if (pageInput && bookRanges[bid]) { pageInput.value = bookRanges[bid]; }
        try {
            await loadCurrentSelection();
        } catch (err) {
            setStatus('Failed');
            localAisgkMsgBox(err.message);
        }
    });

    async function startScanJob() {
        const startData = await postJson('scanjobstart', {
            pagerange: document.getElementById('local-aisgk-page').value
        }, 'Queueing');
        const jobid = parseInt(startData.jobid || 0, 10);
        if (!jobid) {
            throw new Error('Không tạo được job AI TOC');
        }
        renderAdvancedProgress(5, 'Đã đưa AI TOC vào hàng đợi...', 'running');
        return await pollScanJob(jobid);
    }

    async function pollScanJob(jobid) {
        let last = null;
        for (let i = 0; i < 240; i++) {
            const data = await postJson('scanjobstatus', {jobid: jobid});
            const job = data.job || {};
            last = data;
            renderAdvancedProgress(parseInt(job.progress || 5, 10), job.message || job.steptext || 'Đang xử lý...', job.status === 'failed' ? 'error' : 'running');
            if (job.status === 'done') {
                const rows = data.rows || [];
                renderAdvancedProgress(100, data.message || ('Hoàn tất, +' + rows.length + ' rows'), 'done');
                return data;
            }
            if (job.status === 'failed') {
                throw new Error(job.errormsg || job.message || 'Scan TOC thất bại');
            }
            await new Promise(resolve => setTimeout(resolve, 2000));
        }
        throw new Error((last && last.message) ? last.message : 'Scan TOC chưa hoàn tất, hãy kiểm tra cron.');
    }

    function firstTocPdfPage() {
        const raw = (document.getElementById('local-aisgk-page').value || '').trim();
        const m = raw.match(/^(\d+)/);
        const page = m ? parseInt(m[1], 10) : 4;
        return Math.max(1, page || 4);
    }

    function openBookViewer() {
        const bookid = parseInt(selectedBookId(), 10) || 0;
        if (!bookid) {
            localAisgkMsgBox('Hãy chọn một SGK cụ thể trước khi xem sách.', 'err');
            return;
        }
        const pdfPage = firstTocPdfPage();
        const sgkPageParam = Math.max(0, pdfPage - 1);
        const backdrop = document.createElement('div');
        backdrop.className = 'local-aisgk-bookviewer-backdrop';
        const box = document.createElement('div');
        box.className = 'local-aisgk-bookviewer';
        box.innerHTML = '<div class="local-aisgk-bookviewer-head"><div class="local-aisgk-bookviewer-title">' +
            'View Book - PDF page ' + pdfPage + '</div><button type="button" class="local-aisgk-btn local-aisgk-bookviewer-close">×</button></div>' +
            '<div class="local-aisgk-bookviewer-body"><img alt="Book page"></div>';
        const img = box.querySelector('img');
        img.src = <?php echo json_encode((new moodle_url('/local/aisgk/pageimg.php'))->out(false)); ?> +
            '?courseid=' + encodeURIComponent(courseid) +
            '&bookid=' + encodeURIComponent(bookid) +
            '&sectionid=0&page=' + encodeURIComponent(sgkPageParam) +
            '&width=1200';
        box.querySelector('.local-aisgk-bookviewer-close').addEventListener('click', function() { backdrop.remove(); });
        backdrop.addEventListener('click', function(e) { if (e.target === backdrop) { backdrop.remove(); } });
        backdrop.appendChild(box);
        document.body.appendChild(backdrop);
    }

    const viewBookBtn = document.getElementById('local-aisgk-viewbook');
    if (viewBookBtn) { viewBookBtn.addEventListener('click', openBookViewer); }

    const aiBtn = document.getElementById('local-aisgk-ai');

    aiBtn.addEventListener('click', async function() {
        const pagerange = (document.getElementById('local-aisgk-page').value || '').trim();
        if (!pagerange) {
            setStatus('Thiếu trang');
            setDraft('Hãy nhập TOC page trước khi chạy AI');
            document.getElementById('local-aisgk-page').focus();
            return;
        }
        try {
            renderRows([{}]);
            setStatus('AI queued');
            const data = await startScanJob();
            renderRows(data.rows || []);
            setStatus('✓ Done, +' + ((data.rows || []).length) + ' rows');
            setDraft(data.message || ('✓ Done, +' + ((data.rows || []).length) + ' rows'));
        } catch (err) {
            setStatus('Failed');
            renderAdvancedProgress(100, 'AI extract thất bại', 'error');
            localAisgkMsgBox(err.message || 'AI extract failed');
        }
    });

    document.getElementById('local-aisgk-save').addEventListener('click', async function() {
        try {
            const ok = localAisgkValidateRows();
            if (!ok) {
                const firstInvalid = document.querySelector('#local-aisgk-toc-table tbody tr.local-aisgk-row-invalid');
                if (firstInvalid) {
                    firstInvalid.scrollIntoView({behavior: 'smooth', block: 'center'});
                }
                setStatus('⚠ Dữ liệu chưa hợp lệ');
                return;
            }
            setStatus('Saving');
            const data = await postJson('save', {rows: rowsFromTable()}, 'Saving');
            renderRows(data.rows);
            setStatus('✓ Done, +' + data.rows.length + ' rows');
        } catch (err) {
            setStatus('Failed');
            localAisgkMsgBox(err.message);
        }
    });

    document.getElementById('local-aisgk-restore').addEventListener('click', async function() {
        try {
            setStatus('Restoring');
            const data = await postJson('restore', {}, 'Restoring');
            renderRows(data.rows);
            setStatus('✓ Done, +' + data.rows.length + ' rows');
        } catch (err) {
            setStatus('Failed');
            localAisgkMsgBox(err.message);
        }
    });

    function refreshParentCoursePage() {
        try {
            if (window.parent && window.parent !== window && window.parent.location) {
                window.parent.location.reload();
                return true;
            }
        } catch (e) {
            // Ignore cross-frame refresh errors.
        }
        return false;
    }

    document.getElementById('local-aisgk-delete').addEventListener('click', async function() {
        if (!(await localAisgkConfirm('Bạn có chắc muốn xóa toàn bộ mục lục?'))) {
            return;
        }
        try {
            setStatus('Deleting');
            await postJson('delete', {}, 'Deleting');
            renderRows([{}]);
            setStatus('✓ Done, +0 rows');
        } catch (err) {
            setStatus('Failed');
            localAisgkMsgBox(err.message);
        }
    });


    const deleteLessonsBtn = document.getElementById('local-aisgk-delete-lessons');
    if (deleteLessonsBtn) {
        deleteLessonsBtn.addEventListener('click', async function() {
            if (!(await localAisgkConfirm('Bạn có chắc muốn xóa toàn bộ bài học đã tạo từ mục lục?'))) {
                return;
            }
            try {
                deleteLessonsBtn.disabled = true;
                setStatus('Đang xóa bài học');
                setDraft('Đang xóa toàn bộ bài học đã tạo từ mục lục...');

                const data = await postJson('deletelessons', {}, 'Deleting lessons');

                setStatus('✓ Done');
                setDraft(data.message || 'Đã xóa toàn bộ bài học đã tạo.');
                refreshParentCoursePage();
            } catch (err) {
                setStatus('Failed');
                localAisgkMsgBox(err.message || 'Xóa bài học thất bại');
            } finally {
                deleteLessonsBtn.disabled = false;
            }
        });
    }

    document.getElementById('local-aisgk-create').addEventListener('click', async function() {
        const createBtn = document.getElementById('local-aisgk-create');

        try {
            createBtn.disabled = true;
            setStatus('Creating lessons');
            setDraft('Đang tạo/cập nhật bài học từ dữ liệu đã Save trong DB...');

            const data = await postJson('createtopics', {}, 'Creating topics');

            setStatus('✓ Done');
            setDraft(data.message || 'Đã tạo/cập nhật bài học.');
            refreshParentCoursePage();
        } catch (err) {
            setStatus('Failed');
            localAisgkMsgBox(err.message || 'Tạo bài học thất bại');
        } finally {
            createBtn.disabled = false;
        }
    });

    renumber();
})();
</script>
<?php
echo $OUTPUT->footer();
