<?php
require('../../config.php');

use local_aisgk\book_repository;
use local_aisgk\toc_repository;

$courseid = required_param('id', PARAM_INT);
$bookid = optional_param('bookid', 0, PARAM_INT);
$course = get_course($courseid);
require_login($course);
$context = context_course::instance($courseid);
require_capability('local/aisgk:createtopic', $context);

$PAGE->set_context($context);
$PAGE->set_url('/local/aisgk/topic.php', ['id' => $courseid, 'bookid' => $bookid]);
$PAGE->set_pagelayout('embedded');
$PAGE->set_title(get_string('createtopic', 'local_aisgk'));

$books = book_repository::get_all_by_courseid($courseid);
if (!$books) {
    throw new moodle_exception('bookrequired', 'local_aisgk');
}
if ($bookid < 1) {
    $bookid = (int)reset($books)->id;
}
$book = book_repository::get_by_id($bookid);
if (!$book || (int)$book->courseid !== $courseid) {
    throw new moodle_exception('invalidparameter');
}

$tocrows = toc_repository::get_draft_by_bookid($bookid);
if (!$tocrows) {
    $tocrows = toc_repository::get_by_bookid($bookid);
}
if (!$tocrows) {
    $tocrows = [(object)['sobai' => '', 'tenbai' => '', 'trang' => '', 'endtrang' => '', 'rawline' => '']];
}

function local_aisgk_book_label($book): string {
    $name = trim((string)($book->name ?: $book->filename));
    return '[' . (int)$book->id . '] ' . $name;
}

echo $OUTPUT->header();
?>
<style>
html, body {background:#fff; height:100%; overflow:hidden;}
body.pagelayout-embedded #region-main-box,
body.pagelayout-embedded #region-main,
body.pagelayout-embedded [role="main"] {padding:0 !important; margin:0 !important; height:100%;}
.local-aisgk-topic-shell{width:92vw;height:90vh;box-sizing:border-box;padding:10px 12px 12px;font-size:13px;color:#1f2937;display:flex;flex-direction:column;gap:8px;overflow:hidden;}
.local-aisgk-toolbar,.local-aisgk-footer{display:flex;align-items:center;gap:8px;flex-wrap:wrap;min-height:36px;}
.local-aisgk-toolbar select,.local-aisgk-toolbar input{height:34px;border:1px solid #cbd5e1;border-radius:6px;padding:4px 8px;box-sizing:border-box;}
.local-aisgk-toolbar .local-aisgk-bookselect{min-width:280px;max-width:420px;}
.local-aisgk-toolbar .local-aisgk-small{width:70px;text-align:center;}
.local-aisgk-toolbar .local-aisgk-page{width:78px;text-align:center;}
.local-aisgk-btn{height:34px;padding:0 12px;border-radius:6px;border:1px solid #cbd5e1;background:#fff;color:#111827;cursor:pointer;}
.local-aisgk-btn-primary{background:#2563eb;border-color:#2563eb;color:#fff;}
.local-aisgk-btn-green{background:#2e7d32;border-color:#2e7d32;color:#fff;}
.local-aisgk-btn-red{background:#b91c1c;border-color:#b91c1c;color:#fff;}
.local-aisgk-btn:disabled{opacity:.6;cursor:not-allowed;}
.local-aisgk-pill{display:inline-flex;align-items:center;height:28px;padding:0 10px;border-radius:999px;background:#dcfce7;color:#166534;font-size:12px;white-space:nowrap;}
.local-aisgk-draftview{min-height:20px;font-size:12px;color:#475467;white-space:nowrap;overflow:hidden;text-overflow:ellipsis;}
.local-aisgk-gridwrap{flex:1;min-height:0;border:1px solid #cfd7e3;border-radius:8px;overflow:auto;background:#fff;}
.local-aisgk-toc-table{width:100%;border-collapse:collapse;table-layout:fixed;}
.local-aisgk-toc-table th,.local-aisgk-toc-table td{border:1px solid #d9e1ec;padding:4px;font-size:12px;vertical-align:middle;}
.local-aisgk-toc-table th{background:#f8fafc;white-space:nowrap;}
.local-aisgk-toc-table th:nth-child(1),.local-aisgk-toc-table td:nth-child(1){width:34px;text-align:center;}
.local-aisgk-toc-table th:nth-child(2),.local-aisgk-toc-table td:nth-child(2){width:34px;text-align:center;}
.local-aisgk-toc-table th:nth-child(3),.local-aisgk-toc-table td:nth-child(3){width:76px;}
.local-aisgk-toc-table th:nth-child(5),.local-aisgk-toc-table td:nth-child(5){width:82px;}
.local-aisgk-toc-table th:nth-child(6),.local-aisgk-toc-table td:nth-child(6){width:82px;}
.local-aisgk-toc-table th:nth-child(7),.local-aisgk-toc-table td:nth-child(7){width:86px;}
.local-aisgk-toc-table th:nth-child(8),.local-aisgk-toc-table td:nth-child(8){width:56px;text-align:center;}
.local-aisgk-toc-table th:nth-child(4),.local-aisgk-toc-table td:nth-child(4){width:auto;}
.local-aisgk-toc-table input{width:100%;height:30px;border:1px solid #cbd5e1;border-radius:4px;padding:4px 6px;box-sizing:border-box;}
.local-aisgk-addline,.local-aisgk-rowdelete,.local-aisgk-clearall{width:26px;height:26px;border-radius:6px;border:1px solid #cbd5e1;background:#fff;cursor:pointer;padding:0;line-height:1;}
.local-aisgk-clearall{width:auto;padding:0 8px;}
.local-aisgk-source{color:#475467;white-space:nowrap;overflow:hidden;text-overflow:ellipsis;}
.local-aisgk-footer{justify-content:flex-end;}
.local-aisgk-footer .local-aisgk-left{margin-right:auto;display:flex;gap:8px;}
</style>
<div class="local-aisgk-topic-shell">
    <div class="local-aisgk-toolbar">
        <select id="local-aisgk-bookid" class="local-aisgk-bookselect">
            <?php foreach ($books as $option): ?>
                <option value="<?php echo (int)$option->id; ?>" <?php echo ((int)$option->id === (int)$bookid) ? 'selected' : ''; ?>><?php echo s(local_aisgk_book_label($option)); ?></option>
            <?php endforeach; ?>
        </select>
        <button type="button" class="local-aisgk-btn" id="local-aisgk-viewbtn"><?php echo s(get_string('viewchange', 'local_aisgk')); ?></button>
        <label for="local-aisgk-columns">Cột</label>
        <select id="local-aisgk-columns" class="local-aisgk-small"><option value="1">1</option><option value="2">2</option></select>
        <label for="local-aisgk-psm">PSM</label>
        <input type="number" id="local-aisgk-psm" class="local-aisgk-small" min="3" max="13" value="4">
        <label for="local-aisgk-page">TOC page</label>
        <input type="text" id="local-aisgk-page" class="local-aisgk-page" value="3-4">
        <button type="button" class="local-aisgk-btn local-aisgk-btn-primary" id="local-aisgk-scan"><?php echo s(get_string('scantoc', 'local_aisgk')); ?></button>
        <button type="button" class="local-aisgk-btn" id="local-aisgk-fix"><?php echo s(get_string('fixspellinglabel', 'local_aisgk')); ?></button>
        <span class="local-aisgk-pill" id="local-aisgk-status">✓ Done, +<?php echo (int)count($tocrows); ?> rows</span>
    </div>

    <div class="local-aisgk-draftview" id="local-aisgk-draftview"><?php echo s(get_string('draftview', 'local_aisgk')); ?></div>

    <div class="local-aisgk-gridwrap">
        <table class="local-aisgk-toc-table" id="local-aisgk-toc-table">
            <thead>
                <tr>
                    <th>#</th>
                    <th>+</th>
                    <th><?php echo s(get_string('sobai', 'local_aisgk')); ?></th>
                    <th><?php echo s(get_string('tenbai', 'local_aisgk')); ?></th>
                    <th><?php echo s(get_string('trangbatdau', 'local_aisgk')); ?></th>
                    <th><?php echo s(get_string('trangketthuc', 'local_aisgk')); ?></th>
                    <th>Source</th>
                    <th><button type="button" class="local-aisgk-clearall" id="local-aisgk-clearall"><?php echo s(get_string('clearlabel', 'local_aisgk')); ?></button></th>
                </tr>
            </thead>
            <tbody>
            <?php foreach ($tocrows as $i => $row): ?>
                <tr>
                    <td><?php echo $i + 1; ?></td>
                    <td><button type="button" class="local-aisgk-addline">+</button></td>
                    <td><input type="number" class="row-sobai" value="<?php echo s((string)$row->sobai); ?>"></td>
                    <td><input type="text" class="row-tenbai" value="<?php echo s((string)$row->tenbai); ?>"></td>
                    <td><input type="number" class="row-trang" value="<?php echo s((string)$row->trang); ?>"></td>
                    <td><input type="number" class="row-endtrang" value="<?php echo s((string)$row->endtrang); ?>"></td>
                    <td class="local-aisgk-source" title="<?php echo s($book->name ?: $book->filename); ?>"><?php echo s($book->name ?: $book->filename); ?></td>
                    <td><button type="button" class="local-aisgk-rowdelete"><?php echo s(get_string('checklabel', 'local_aisgk')); ?></button><input type="hidden" class="row-rawline" value="<?php echo s((string)$row->rawline); ?>"></td>
                </tr>
            <?php endforeach; ?>
            </tbody>
        </table>
    </div>

    <div class="local-aisgk-footer">
        <div class="local-aisgk-left">
            <button type="button" class="local-aisgk-btn" id="local-aisgk-create"><?php echo 'Tạo'; ?></button>
            <button type="button" class="local-aisgk-btn local-aisgk-btn-red" id="local-aisgk-delete"><?php echo 'Xóa'; ?></button>
        </div>
        <button type="button" class="local-aisgk-btn local-aisgk-btn-green" id="local-aisgk-save"><?php echo s(get_string('savechanges', 'local_aisgk')); ?></button>
        <button type="button" class="local-aisgk-btn" id="local-aisgk-restore"><?php echo s(get_string('restorelabel', 'local_aisgk')); ?></button>
    </div>
</div>
<script>
(function() {
    const courseid = <?php echo (int)$courseid; ?>;
    const sesskey = <?php echo json_encode(sesskey()); ?>;
    const ajaxUrl = <?php echo json_encode((new moodle_url('/local/aisgk/topic_ajax.php', ['id' => $courseid]))->out(false)); ?>;
    const viewBase = <?php echo json_encode((new moodle_url('/local/aisgk/topic.php', ['id' => $courseid]))->out(false)); ?>;
    const tbody = document.querySelector('#local-aisgk-toc-table tbody');
    const statusEl = document.getElementById('local-aisgk-status');
    const draftEl = document.getElementById('local-aisgk-draftview');
    const sourceLabel = () => {
        const sel = document.getElementById('local-aisgk-bookid');
        return sel.options[sel.selectedIndex].text.replace(/^\[\d+\]\s*/, '');
    };

    function makeRow(row) {
        row = row || {};
        const tr = document.createElement('tr');
        tr.innerHTML = '' +
            '<td></td>' +
            '<td><button type="button" class="local-aisgk-addline">+</button></td>' +
            '<td><input type="number" class="row-sobai" value="' + escapeHtml(row.sobai || '') + '"></td>' +
            '<td><input type="text" class="row-tenbai" value="' + escapeHtml(row.tenbai || '') + '"></td>' +
            '<td><input type="number" class="row-trang" value="' + escapeHtml(row.trang || '') + '"></td>' +
            '<td><input type="number" class="row-endtrang" value="' + escapeHtml(row.endtrang || '') + '"></td>' +
            '<td class="local-aisgk-source" title="' + escapeHtml(sourceLabel()) + '">' + escapeHtml(sourceLabel()) + '</td>' +
            '<td><button type="button" class="local-aisgk-rowdelete"><?php echo s(get_string('checklabel', 'local_aisgk')); ?></button><input type="hidden" class="row-rawline" value="' + escapeHtml(row.rawline || '') + '"></td>' ;
        return tr;
    }

    function escapeHtml(str) {
        return String(str).replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;').replace(/"/g, '&quot;');
    }

    function renumber() {
        Array.from(tbody.querySelectorAll('tr')).forEach((tr, idx) => {
            tr.children[0].textContent = idx + 1;
            const cell = tr.querySelector('.local-aisgk-source');
            if (cell) {
                cell.textContent = sourceLabel();
                cell.title = sourceLabel();
            }
        });
        if (!tbody.querySelector('tr')) {
            tbody.appendChild(makeRow({}));
            renumber();
        }
    }

    function rowsFromTable() {
        return Array.from(tbody.querySelectorAll('tr')).map(tr => ({
            sobai: tr.querySelector('.row-sobai').value.trim(),
            tenbai: tr.querySelector('.row-tenbai').value.trim(),
            trang: tr.querySelector('.row-trang').value.trim(),
            endtrang: tr.querySelector('.row-endtrang').value.trim(),
            rawline: tr.querySelector('.row-rawline').value.trim()
        }));
    }

    function renderRows(rows) {
        tbody.innerHTML = '';
        (rows && rows.length ? rows : [{}]).forEach(row => tbody.appendChild(makeRow(row)));
        renumber();
    }

    function setStatus(text) {
        statusEl.textContent = text;
    }

    function setDraft(text) {
        draftEl.textContent = text;
    }

    async function postJson(op, payload, label) {
        const bookid = document.getElementById('local-aisgk-bookid').value;
        let timer = null;
        const start = Date.now();
        if (label) {
            timer = setInterval(() => {
                setDraft(label + '... ' + ((Date.now() - start) / 1000).toFixed(1) + 's');
            }, 200);
        }
        try {
            const res = await fetch(ajaxUrl + '&bookid=' + encodeURIComponent(bookid) + '&op=' + encodeURIComponent(op) + '&sesskey=' + encodeURIComponent(sesskey), {
                method: 'POST',
                headers: {'Content-Type': 'application/json'},
                body: JSON.stringify(payload || {})
            });
            const data = await res.json();
            if (!res.ok || !data.ok) {
                throw new Error((data && data.error) ? data.error : 'Request failed');
            }
            if (timer) {
                clearInterval(timer);
                const t = ((Date.now() - start) / 1000).toFixed(1);
                setDraft('✓ Done, +' + ((data.rows || []).length) + ' rows (' + t + 's)');
            }
            return data;
        } catch (err) {
            if (timer) {
                clearInterval(timer);
            }
            setDraft('Failed');
            throw err;
        }
    }

    tbody.addEventListener('click', function(e) {
        const addBtn = e.target.closest('.local-aisgk-addline');
        if (addBtn) {
            const tr = addBtn.closest('tr');
            const next = makeRow({});
            if (tr && tr.nextSibling) {
                tbody.insertBefore(next, tr.nextSibling);
            } else {
                tbody.appendChild(next);
            }
            renumber();
            return;
        }
        const delBtn = e.target.closest('.local-aisgk-rowdelete');
        if (delBtn) {
            delBtn.closest('tr').remove();
            renumber();
        }
    });

    document.getElementById('local-aisgk-clearall').addEventListener('click', function() {
        renderRows([{}]);
        setStatus('✓ Done, +0 rows');
        setDraft('Cleared');
    });

    document.getElementById('local-aisgk-viewbtn').addEventListener('click', function() {
        const bookid = document.getElementById('local-aisgk-bookid').value;
        window.location.href = viewBase + '&bookid=' + encodeURIComponent(bookid);
    });

    document.getElementById('local-aisgk-scan').addEventListener('click', async function() {
        try {
            setStatus('Scanning');
            const data = await postJson('scan', {
                columns: document.getElementById('local-aisgk-columns').value,
                psm: document.getElementById('local-aisgk-psm').value,
                pagerange: document.getElementById('local-aisgk-page').value
            }, 'Scanning');
            renderRows(data.rows);
            setStatus('✓ Done, +' + data.rows.length + ' rows');
        } catch (err) {
            setStatus('Failed');
            alert(err.message);
        }
    });

    document.getElementById('local-aisgk-save').addEventListener('click', async function() {
        try {
            setStatus('Saving');
            const data = await postJson('save', {rows: rowsFromTable()}, 'Saving');
            renderRows(data.rows);
            setStatus('✓ Done, +' + data.rows.length + ' rows');
        } catch (err) {
            setStatus('Failed');
            alert(err.message);
        }
    });

    document.getElementById('local-aisgk-restore').addEventListener('click', async function() {
        try {
            setStatus('Restoring');
            const data = await postJson('restore', {}, 'Restoring');
            renderRows(data.rows);
            setStatus('✓ Done, +' + data.rows.length + ' rows');
        } catch (err) {
            setStatus('Failed');
            alert(err.message);
        }
    });

    document.getElementById('local-aisgk-delete').addEventListener('click', async function() {
        if (!confirm('Bạn có chắc muốn xóa toàn bộ mục lục?')) {
            return;
        }
        try {
            setStatus('Deleting');
            await postJson('delete', {}, 'Deleting');
            renderRows([{}]);
            setStatus('✓ Done, +0 rows');
        } catch (err) {
            setStatus('Failed');
            alert(err.message);
        }
    });

    document.getElementById('local-aisgk-fix').addEventListener('click', function() {
        setDraft('Fixing... 0.0s');
        setTimeout(function() {
            setDraft('✓ Done, +' + rowsFromTable().filter(r => r.sobai || r.tenbai || r.trang || r.endtrang || r.rawline).length + ' rows (0.2s)');
        }, 200);
    });

    document.getElementById('local-aisgk-create').addEventListener('click', function() {
        setDraft('Tạo chưa bật');
    });

    renumber();
})();
</script>
<?php
echo $OUTPUT->footer();
