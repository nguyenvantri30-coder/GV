<?php
namespace local_aisgk\task;

defined('MOODLE_INTERNAL') || die();

use local_aisgk\local\job_manager;
use local_aisgk\local\service\homework_service;
use local_aisgk\homework_repository;
use local_aisgk\local\service\toc_scan_job_service;

class process_homework_jobs_task extends \core\task\scheduled_task {
    public function get_name(): string {
        return get_string('taskprocesshomeworkjobs', 'local_aisgk');
    }

    public function execute() {
        for ($i = 0; $i < 2; $i++) {
            $job = job_manager::claim_next('createhomework');
            if (!$job) {
                break;
            }
            try {
                homework_service::process_job($job);
            } catch (\Throwable $e) {
                $payload = json_decode((string)$job->payloadjson, true) ?: [];
                if (!empty($payload['homeworkid'])) {
                    homework_repository::update((int)$payload['homeworkid'], [
                        'status' => 'failed',
                        'errormsg' => $e->getMessage(),
                        'timemodified' => time(),
                    ]);
                }
                job_manager::mark_failed((int)$job->id, $e->getMessage());
                throw $e;
            }
        }

        for ($i = 0; $i < 2; $i++) {
            $job = job_manager::claim_next('scan_toc');
            if (!$job) {
                break;
            }
            try {
                toc_scan_job_service::process_job($job);
            } catch (\Throwable $e) {
                job_manager::mark_failed((int)$job->id, $e->getMessage());
                throw $e;
            }
        }
    }
}


// AISGK repair only invalid questions
if (!empty($op) && $op === 'repairquestions') {
    header('Content-Type: application/json');

    $normalizedjson = optional_param('normalizedjson', '', PARAM_RAW);
    $errorsjson = optional_param('errorsjson', '', PARAM_RAW);

    echo json_encode([
        'ok' => true,
        'mode' => 'repair_only_invalid_questions',
        'normalizedjson' => $normalizedjson,
        'errorsjson' => $errorsjson
    ]);
    die;
}
