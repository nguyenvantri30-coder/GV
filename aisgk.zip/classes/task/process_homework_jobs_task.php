<?php
namespace local_aisgk\task;

defined('MOODLE_INTERNAL') || die();

use local_aisgk\local\job_manager;
use local_aisgk\local\service\homework_service;

class process_homework_jobs_task extends \core\task\scheduled_task {
    public function get_name(): string {
        return get_string('taskprocesshomeworkjobs', 'local_aisgk');
    }

    public function execute() {
        for ($i = 0; $i < 2; $i++) {
            $job = job_manager::claim_next('createhomework');
            if (!$job) {
                break;
            }
            try {
                homework_service::process_job($job);
            } catch (\Throwable $e) {
                job_manager::mark_failed((int)$job->id, $e->getMessage());
                throw $e;
            }
        }
    }
}
