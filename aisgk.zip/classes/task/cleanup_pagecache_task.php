<?php
namespace local_aisgk\task;

defined('MOODLE_INTERNAL') || die();

use local_aisgk\local\page_cache;

class cleanup_pagecache_task extends \core\task\scheduled_task {
    public function get_name(): string {
        return 'AISGK cleanup rendered SGK page cache';
    }

    public function execute(): void {
        page_cache::cleanup(page_cache::TTL);
    }
}
