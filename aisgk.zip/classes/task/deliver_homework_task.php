<?php
namespace local_aisgk\task;

defined('MOODLE_INTERNAL') || die();

use local_aisgk\local\service\homework_service;

class deliver_homework_task extends \core\task\scheduled_task {
    public function get_name(): string {
        return get_string('taskdeliverhomework', 'local_aisgk');
    }

    public function execute() {
        homework_service::deliver_due();
    }
}


// AISGK repair only invalid questions
if (!empty($op) && $op === 'repairquestions') {
    header('Content-Type: application/json');

    $normalizedjson = optional_param('normalizedjson', '', PARAM_RAW);
    $errorsjson = optional_param('errorsjson', '', PARAM_RAW);

    echo json_encode([
        'ok' => true,
        'mode' => 'repair_only_invalid_questions',
        'normalizedjson' => $normalizedjson,
        'errorsjson' => $errorsjson
    ]);
    die;
}
