<?php
namespace local_aisgk\task;

defined('MOODLE_INTERNAL') || die();

use local_aisgk\local\service\homework_service;

class deliver_homework_task extends \core\task\scheduled_task {
    public function get_name(): string {
        return get_string('taskdeliverhomework', 'local_aisgk');
    }

    public function execute() {
        homework_service::deliver_due();
    }
}
