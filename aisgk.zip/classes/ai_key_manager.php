<?php
namespace local_aisgk;

defined('MOODLE_INTERNAL') || die();

class ai_key_manager {

    public static function get_available_key(string $feature = 'scan') {
        global $DB;

        $now = time();
        $minute = (int)floor($now / 60);
        $day = (int)floor($now / 86400);

        $keys = $DB->get_records('local_aisgk_ai_keys', null, 'id ASC');

        $free = [];
        $pay = [];

        foreach ($keys as $k) {
            $status = (string)($k->status ?? 'active');
            $category = (string)($k->category_key ?? 'free');

            if ($status === 'blocked') {
                continue;
            }

            if ((int)($k->minute_bucket ?? 0) !== $minute) {
                $k->request_count_minute = 0;
                $k->minute_bucket = $minute;
                $DB->update_record('local_aisgk_ai_keys', $k);
            }

            if ((int)($k->day_bucket ?? 0) !== $day) {
                $k->total_requests_day = 0;
                $k->day_bucket = $day;
                $DB->update_record('local_aisgk_ai_keys', $k);
            }

            if ($status === 'cooldown') {
                $cooldownuntil = (int)($k->cooldown_until ?? 0);
                if ($cooldownuntil > $now) {
                    continue;
                }
                $k->status = 'active';
                $k->cooldown_until = 0;
                $DB->update_record('local_aisgk_ai_keys', $k);
                $status = 'active';
            }

            if ($status !== 'active') {
                continue;
            }

            if (trim((string)($k->api_key ?? '')) === '') {
                continue;
            }

            if ((int)($k->request_count_minute ?? 0) >= 10) {
                continue;
            }

            if (!empty($k->last_used) && ($now - (int)$k->last_used) < 5) {
                continue;
            }

            if ($category === 'pay') {
                $pay[] = $k;
            } else {
                $free[] = $k;
            }
        }

        if (!empty($free)) {
            return $free[array_rand($free)];
        }

        if (!empty($pay)) {
            return $pay[array_rand($pay)];
        }

        return null;
    }

    public static function mark_success(\stdClass $key): void {
        global $DB;

        $now = time();
        $minute = (int)floor($now / 60);
        $day = (int)floor($now / 86400);

        if ((int)($key->minute_bucket ?? 0) !== $minute) {
            $key->request_count_minute = 0;
            $key->minute_bucket = $minute;
        }

        if ((int)($key->day_bucket ?? 0) !== $day) {
            $key->total_requests_day = 0;
            $key->day_bucket = $day;
        }

        $key->request_count_minute = (int)($key->request_count_minute ?? 0) + 1;
        $key->total_requests_day = (int)($key->total_requests_day ?? 0) + 1;
        $key->last_used = $now;
        $key->last_error = '';
        $DB->update_record('local_aisgk_ai_keys', $key);
    }

    public static function mark_429(\stdClass $key): void {
        global $DB;

        $key->status = 'cooldown';
        $key->cooldown_until = time() + rand(300, 900);
        $key->last_error = '429 / rate limit / quota';
        $DB->update_record('local_aisgk_ai_keys', $key);
    }

    public static function mark_blocked(\stdClass $key, string $error): void {
        global $DB;

        $key->status = 'blocked';
        $key->last_error = mb_substr($error, 0, 1000);
        $DB->update_record('local_aisgk_ai_keys', $key);
    }
}
