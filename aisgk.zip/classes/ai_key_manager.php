<?php
namespace local_aisgk;

defined('MOODLE_INTERNAL') || die();

class ai_key_manager {
    const GLOBAL_RPM_LIMIT = 30;
    const USER_DAILY_LIMIT = 20;

    protected static function table_for_key(\stdClass $key): string {
        return (string)($key->_source_table ?? 'local_aisgk_ai_keys');
    }

    protected static function add_runtime_source(\stdClass $key, string $table): \stdClass {
        $key->_source_table = $table;
        return $key;
    }

    protected static function tomorrow_reset_time(): int {
        return strtotime('tomorrow 00:05') ?: (time() + DAYSECS);
    }

    protected static function today_key(): int {
        return (int)date('Ymd');
    }

    protected static function normalize_key(\stdClass $key): \stdClass {
        $today = self::today_key();
        if (empty($key->daily_reset_at) || (int)date('Ymd', (int)$key->daily_reset_at) !== $today) {
            $key->daily_used = 0;
            $key->daily_reset_at = time();
        }
        if (!isset($key->daily_limit)) {
            $key->daily_limit = ((string)($key->category_key ?? 'free') === 'pay') ? 100 : 0;
        }
        foreach (['cooldown_until','last_used','last_tokens','last_tokens_at','usage_last_sync','in_use_by','in_use_until'] as $f) {
            if (!isset($key->$f)) { $key->$f = 0; }
        }
        foreach (['status','category_key','provider','model_scan','model_homework','model_scan_status','model_homework_status','last_error','last_model'] as $f) {
            if (!isset($key->$f)) { $key->$f = ''; }
        }
        if ($key->status === '') { $key->status = 'active'; }
        if ($key->category_key === '') { $key->category_key = 'free'; }
        if ($key->provider === '') { $key->provider = self::provider_for_key($key); }
        return $key;
    }

    protected static function update_key_record(\stdClass $key): void {
        global $DB;
        $table = self::table_for_key($key);
        $record = clone $key;
        unset($record->_source_table);
        $current = !empty($record->id) ? $DB->get_record($table, ['id' => (int)$record->id]) : null;
        if ($current) {
            // Never overwrite configured models from runtime attempts.
            $record->model_scan = $current->model_scan ?? $record->model_scan ?? '';
            $record->model_homework = $current->model_homework ?? $record->model_homework ?? '';
            foreach (['gmail_account','api_key','category_key','provider','proxy_info','timecreated','usermodified'] as $f) {
                if (!isset($record->$f) && isset($current->$f)) { $record->$f = $current->$f; }
            }
        }
        if (property_exists($record, 'timemodified')) { $record->timemodified = time(); }
        $DB->update_record($table, $record);
    }

    public static function provider_for_key(\stdClass $key): string {
        $provider = trim((string)($key->provider ?? ''));
        if ($provider === '') {
            $provider = ((string)($key->category_key ?? 'free') === 'pay') ? 'shopaikey' : 'google';
        }
        return in_array($provider, ['google', 'shopaikey'], true) ? $provider : 'google';
    }

    public static function configured_models_for_key(\stdClass $key, string $feature): array {
        $raw = trim((string)(($feature === 'homework') ? ($key->model_homework ?? '') : ($key->model_scan ?? '')));
        if ($raw === '') {
            return [];
        }
        $out = [];
        foreach (explode(',', $raw) as $model) {
            $model = trim($model);
            if ($model !== '' && !in_array($model, $out, true)) {
                $out[] = $model;
            }
        }
        return $out;
    }

    protected static function status_field_for_feature(string $feature): string {
        return ($feature === 'homework') ? 'model_homework_status' : 'model_scan_status';
    }

    protected static function decode_model_statuses(\stdClass $key, string $feature): array {
        $field = self::status_field_for_feature($feature);
        $raw = trim((string)($key->$field ?? ''));
        $map = [];
        if ($raw !== '') {
            $decoded = json_decode($raw, true);
            if (is_array($decoded)) {
                foreach ($decoded as $model => $state) {
                    if (!is_array($state)) {
                        $state = ['status' => (string)$state];
                    }
                    $status = (string)($state['status'] ?? 'active');
                    if (!in_array($status, ['active', 'cooldown', 'blocked'], true)) {
                        $status = 'active';
                    }
                    $map[(string)$model] = [
                        'status' => $status,
                        'cooldown_until' => max(0, (int)($state['cooldown_until'] ?? 0)),
                        'last_error' => mb_substr((string)($state['last_error'] ?? ''), 0, 1000),
                        'last_used' => max(0, (int)($state['last_used'] ?? 0)),
                    ];
                }
            }
        }
        return $map;
    }

    public static function normalize_model_status_json(string $modelsraw, string $statusjson = ''): string {
        $models = [];
        foreach (explode(',', $modelsraw) as $model) {
            $model = trim($model);
            if ($model !== '' && !in_array($model, $models, true)) {
                $models[] = $model;
            }
        }
        $old = [];
        $decoded = json_decode(trim($statusjson), true);
        if (is_array($decoded)) {
            $old = $decoded;
        }
        $out = [];
        foreach ($models as $model) {
            $state = $old[$model] ?? [];
            if (!is_array($state)) {
                $state = ['status' => (string)$state];
            }
            $status = (string)($state['status'] ?? 'active');
            if (!in_array($status, ['active', 'cooldown', 'blocked'], true)) {
                $status = 'active';
            }
            $out[$model] = [
                'status' => $status,
                'cooldown_until' => max(0, (int)($state['cooldown_until'] ?? 0)),
                'last_error' => mb_substr((string)($state['last_error'] ?? ''), 0, 1000),
                'last_used' => max(0, (int)($state['last_used'] ?? 0)),
            ];
        }
        return $out ? json_encode($out, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES) : '';
    }

    protected static function save_model_statuses(\stdClass $key, string $feature, array $map): void {
        $field = self::status_field_for_feature($feature);
        $models = self::configured_models_for_key($key, $feature);
        $out = [];
        foreach ($models as $model) {
            $state = $map[$model] ?? ['status' => 'active', 'cooldown_until' => 0, 'last_error' => '', 'last_used' => 0];
            $status = (string)($state['status'] ?? 'active');
            if (!in_array($status, ['active', 'cooldown', 'blocked'], true)) {
                $status = 'active';
            }
            $out[$model] = [
                'status' => $status,
                'cooldown_until' => max(0, (int)($state['cooldown_until'] ?? 0)),
                'last_error' => mb_substr((string)($state['last_error'] ?? ''), 0, 1000),
                'last_used' => max(0, (int)($state['last_used'] ?? 0)),
            ];
        }
        $key->$field = $out ? json_encode($out, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES) : '';
        self::update_key_record($key);
    }

    public static function model_attempts_for_key(\stdClass $key, string $feature): array {
        $key = self::normalize_key($key);
        $models = self::configured_models_for_key($key, $feature);
        if (!$models) {
            return [];
        }
        $now = time();
        $map = self::decode_model_statuses($key, $feature);
        $changed = false;
        $out = [];
        foreach ($models as $model) {
            $state = $map[$model] ?? ['status' => 'active', 'cooldown_until' => 0, 'last_error' => '', 'last_used' => 0];
            $status = (string)($state['status'] ?? 'active');
            $until = max(0, (int)($state['cooldown_until'] ?? 0));
            if ($status === 'cooldown' && $until > 0 && $until <= $now) {
                $state['status'] = 'active';
                $state['cooldown_until'] = 0;
                $map[$model] = $state;
                $status = 'active';
                $changed = true;
            }
            if ($status === 'blocked' || $status === 'cooldown') {
                continue;
            }
            $out[] = $model;
        }
        if ($changed) {
            self::save_model_statuses($key, $feature, $map);
        }
        return $out;
    }

    public static function check_user_daily_limit(int $userid): void {
        global $DB;
        if ($userid <= 0 || !$DB->get_manager()->table_exists('local_aisgk_user_usage')) {
            return;
        }
        $today = date('Y-m-d');
        $row = $DB->get_record('local_aisgk_user_usage', ['userid' => $userid, 'usedate' => $today]);
        $limit = (int)get_config('local_aisgk', 'system_user_daily_limit');
        if ($limit <= 0) { $limit = self::USER_DAILY_LIMIT; }
        if ($row && (int)$row->used_calls >= $limit) {
            throw new \moodle_exception('errorprocessingbook', 'local_aisgk', '', 'Bạn đã dùng hết ' . $limit . ' lượt gọi AI hệ thống hôm nay.');
        }
    }

    public static function mark_user_call(int $userid): void {
        global $DB;
        if ($userid <= 0 || !$DB->get_manager()->table_exists('local_aisgk_user_usage')) {
            return;
        }
        $today = date('Y-m-d');
        $now = time();
        $row = $DB->get_record('local_aisgk_user_usage', ['userid' => $userid, 'usedate' => $today]);
        if ($row) {
            $row->used_calls = (int)$row->used_calls + 1;
            $row->timemodified = $now;
            $DB->update_record('local_aisgk_user_usage', $row);
        } else {
            $row = (object)['userid' => $userid, 'usedate' => $today, 'used_calls' => 1, 'timecreated' => $now, 'timemodified' => $now];
            $DB->insert_record('local_aisgk_user_usage', $row);
        }
    }

    public static function wait_global_slot(): void {
        global $DB;
        if (!$DB->get_manager()->table_exists('local_aisgk_api_calls')) {
            return;
        }
        $now = time();
        $DB->delete_records_select('local_aisgk_api_calls', 'timecreated < ?', [$now - 180]);
        $count = $DB->count_records_select('local_aisgk_api_calls', 'timecreated >= ?', [$now - 60]);
        if ($count >= self::GLOBAL_RPM_LIMIT) {
            // Soft throttle to avoid bursting too hard from one VPS IP.
            usleep(700000);
        }
    }

    public static function mark_global_call(): void {
        global $DB;
        if (!$DB->get_manager()->table_exists('local_aisgk_api_calls')) {
            return;
        }
        $DB->insert_record('local_aisgk_api_calls', (object)['timecreated' => time()]);
    }

    public static function get_available_key(string $feature = 'scan', array $excludeids = [], int $userid = 0, bool $preferuser = false, int $estimatedtokens = 0) {
        global $DB;
        $excludeids = array_map('strval', $excludeids);
        $sources = [];
        if ($preferuser && $userid > 0 && $DB->get_manager()->table_exists('local_aisgk_user_ai_keys')) {
            $sources[] = ['table' => 'local_aisgk_user_ai_keys', 'conditions' => ['userid' => $userid]];
        }
        $sources[] = ['table' => 'local_aisgk_ai_keys', 'conditions' => null];

        foreach ($sources as $source) {
            if (!$DB->get_manager()->table_exists($source['table'])) { continue; }
            $keys = $DB->get_records($source['table'], $source['conditions'], 'last_used ASC, id ASC');
            $free = [];
            $pay = [];
            foreach ($keys as $k) {
                $k = self::add_runtime_source($k, $source['table']);
                $compound = (string)$source['table'] . ':' . (int)$k->id;
                if (in_array($compound, $excludeids, true) || in_array((string)(int)$k->id, $excludeids, true)) { continue; }
                if (!self::prepare_key_for_selection($k, $userid)) { continue; }
                if (!self::can_use_key($k, $estimatedtokens)) { continue; }
                if (!self::model_attempts_for_key($k, $feature)) { continue; }
                if ((string)($k->category_key ?? 'free') === 'pay') { $pay[] = $k; } else { $free[] = $k; }
            }
            $chosen = null;
            if ($free) { usort($free, fn($a, $b) => ((int)$a->last_used <=> (int)$b->last_used)); $chosen = $free[0]; }
            else if ($pay) { usort($pay, fn($a, $b) => ((int)$a->last_used <=> (int)$b->last_used)); $chosen = $pay[0]; }
            if ($chosen) {
                self::reserve_key($chosen, $userid);
                return $chosen;
            }
        }
        return null;
    }

    protected static function prepare_key_for_selection(\stdClass $key, int $userid = 0): bool {
        $now = time();
        $key = self::normalize_key($key);
        $status = (string)($key->status ?? 'active');
        if ($status === 'blocked') { return false; }
        if ($status === 'cooldown') {
            if ((int)($key->cooldown_until ?? 0) > $now) { return false; }
            $key->status = 'active';
            $key->cooldown_until = 0;
        }
        if (trim((string)($key->api_key ?? '')) === '') { return false; }
        if (!empty($key->in_use_until) && (int)$key->in_use_until > $now && (int)($key->in_use_by ?? 0) !== $userid) { return false; }
        // Small spacing even without manual RPM counters.
        if (!empty($key->last_used) && ($now - (int)$key->last_used) < 2) { return false; }
        self::update_key_record($key);
        return true;
    }

    protected static function reserve_key(\stdClass $key, int $userid): void {
        $key->in_use_by = $userid;
        $key->in_use_until = time() + 180;
        self::update_key_record($key);
    }

    public static function release_key(\stdClass $key): void {
        $key->in_use_by = 0;
        $key->in_use_until = 0;
        self::update_key_record($key);
    }

    public static function can_use_key(\stdClass $key, int $estimatedtokens = 0): bool {
        $key = self::normalize_key($key);
        if ((int)($key->daily_limit ?? 0) > 0 && (int)($key->daily_used ?? 0) >= (int)$key->daily_limit) {
            return false;
        }
        return true;
    }

    public static function mark_success(\stdClass $key, int $tokens = 0, string $model = '', int $userid = 0, string $feature = ''): array {
        $key = self::normalize_key($key);
        $key->daily_used = (int)($key->daily_used ?? 0) + 1;
        $key->request_count_minute = 0;
        $key->total_requests_day = (int)($key->daily_used ?? 0);
        $key->last_used = time();
        $key->last_error = '';
        $key->last_model = $model;
        $key->last_tokens = max(0, $tokens);
        $key->last_tokens_at = time();
        $key->in_use_by = 0;
        $key->in_use_until = 0;
        if ($feature !== '' && $model !== '') {
            $map = self::decode_model_statuses($key, $feature);
            $map[$model] = ['status' => 'active', 'cooldown_until' => 0, 'last_error' => '', 'last_used' => time()];
            $field = self::status_field_for_feature($feature);
            $key->$field = self::normalize_model_status_json((string)(($feature === 'homework') ? ($key->model_homework ?? '') : ($key->model_scan ?? '')), json_encode($map, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES));
        }
        self::update_key_record($key);
        self::mark_user_call($userid);
        return [
            'model' => $model,
            'tokens' => max(0, $tokens),
            'daily_used' => (int)$key->daily_used,
            'daily_limit' => (int)$key->daily_limit,
            'remain_calls' => ((int)$key->daily_limit > 0) ? max(0, (int)$key->daily_limit - (int)$key->daily_used) : 999999,
        ];
    }

    public static function mark_error(\stdClass $key, string $error): void {
        $key->last_error = mb_substr($error, 0, 1000);
        $key->in_use_by = 0;
        $key->in_use_until = 0;
        self::update_key_record($key);
    }

    public static function mark_429(\stdClass $key, string $error = '', string $model = '', string $feature = ''): void {
        $key = self::normalize_key($key);
        $key->last_error = mb_substr($error ?: '429 / rate limit / quota', 0, 1000);
        $key->in_use_by = 0;
        $key->in_use_until = 0;
        if ($model !== '' && $feature !== '') {
            $map = self::decode_model_statuses($key, $feature);
            $map[$model] = ['status' => 'cooldown', 'cooldown_until' => time() + rand(60, 120), 'last_error' => $key->last_error, 'last_used' => time()];
            $field = self::status_field_for_feature($feature);
            $key->$field = self::normalize_model_status_json((string)(($feature === 'homework') ? ($key->model_homework ?? '') : ($key->model_scan ?? '')), json_encode($map, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES));
        } else {
            $key->status = 'cooldown';
            $key->cooldown_until = time() + rand(300, 900);
        }
        self::update_key_record($key);
    }

    public static function mark_daily_quota(\stdClass $key, string $error = '', string $model = '', string $feature = ''): void {
        $key = self::normalize_key($key);
        $key->last_error = mb_substr($error ?: 'Daily quota exceeded', 0, 1000);
        $key->in_use_by = 0;
        $key->in_use_until = 0;
        if ($model !== '' && $feature !== '') {
            $map = self::decode_model_statuses($key, $feature);
            $map[$model] = ['status' => 'cooldown', 'cooldown_until' => self::tomorrow_reset_time(), 'last_error' => $key->last_error, 'last_used' => time()];
            $field = self::status_field_for_feature($feature);
            $key->$field = self::normalize_model_status_json((string)(($feature === 'homework') ? ($key->model_homework ?? '') : ($key->model_scan ?? '')), json_encode($map, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES));
        } else {
            $key->status = 'cooldown';
            $key->cooldown_until = self::tomorrow_reset_time();
        }
        self::update_key_record($key);
    }

    public static function mark_model_blocked(\stdClass $key, string $model, string $feature, string $error): void {
        $key = self::normalize_key($key);
        $key->last_error = mb_substr($error, 0, 1000);
        $key->in_use_by = 0;
        $key->in_use_until = 0;
        if ($model !== '' && $feature !== '') {
            $map = self::decode_model_statuses($key, $feature);
            $map[$model] = ['status' => 'blocked', 'cooldown_until' => 0, 'last_error' => $key->last_error, 'last_used' => time()];
            $field = self::status_field_for_feature($feature);
            $key->$field = self::normalize_model_status_json((string)(($feature === 'homework') ? ($key->model_homework ?? '') : ($key->model_scan ?? '')), json_encode($map, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES));
        }
        self::update_key_record($key);
    }

    public static function mark_blocked(\stdClass $key, string $error): void {
        $key->status = 'blocked';
        $key->last_error = mb_substr($error, 0, 1000);
        $key->in_use_by = 0;
        $key->in_use_until = 0;
        self::update_key_record($key);
    }

    public static function is_model_channel_error(string $error): bool {
        return (bool)preg_match('/no available channel|model.*not.*available|unsupported model|model not found/i', $error);
    }

    public static function is_daily_quota_error(string $error): bool {
        return (bool)preg_match('/daily|rpd|quota exceeded|exceeded your current quota|limit exceeded/i', $error);
    }

    public static function is_balance_error(string $error): bool {
        return (bool)preg_match('/insufficient balance|balance is not enough|not enough balance|billing|payment required|hết tiền/i', $error);
    }
}
