<?php
namespace local_aisgk;

defined('MOODLE_INTERNAL') || die();

class ai_key_manager {
    const GLOBAL_RPM_LIMIT = 30;
    const USER_DAILY_LIMIT = 20;



    public const MODEL_CAP_TEXT = 'text_output';
    public const MODEL_CAP_IMAGE = 'image_output';

    /**
     * Lightweight capability registry + naming heuristic.
     * Keep this conservative: image feature may only use models that can really
     * return image bytes/inlineData/URL. Text-only multimodal models must not
     * enter the image pipeline just because they can understand images.
     */
    protected static function model_capability_registry(): array {
        return [
            // Known text-only / text-out models.
            'gemini-3.5-flash' => [self::MODEL_CAP_TEXT],
            'gemini-3-flash-preview' => [self::MODEL_CAP_TEXT],
            'gemini-3.1-flash-lite' => [self::MODEL_CAP_TEXT],
            'gemini-3.1-flash-lite-preview' => [self::MODEL_CAP_TEXT],
            'gemini-2.5-flash' => [self::MODEL_CAP_TEXT],
            'gemini-2.5-pro' => [self::MODEL_CAP_TEXT],
            'gemini-flash-latest' => [self::MODEL_CAP_TEXT],

            // Hybrid models: text + real image output when called with IMAGE modality.
            'gemini-2.5-flash-image' => [self::MODEL_CAP_TEXT, self::MODEL_CAP_IMAGE],
            'gemini-3.1-flash-image-preview' => [self::MODEL_CAP_TEXT, self::MODEL_CAP_IMAGE],
            'gemini-3-pro-image-preview' => [self::MODEL_CAP_TEXT, self::MODEL_CAP_IMAGE],

            // Dedicated image models.
            'gpt-image-2' => [self::MODEL_CAP_IMAGE],
            'gpt-image-1.5' => [self::MODEL_CAP_IMAGE],
            'gpt-image-1' => [self::MODEL_CAP_IMAGE],
            'imagen-3.0-generate-002' => [self::MODEL_CAP_IMAGE],
            'imagen-4.0-generate-001' => [self::MODEL_CAP_IMAGE],
            'imagen-4.0-ultra-generate-001' => [self::MODEL_CAP_IMAGE],
            'imagen-4.0-fast-generate-001' => [self::MODEL_CAP_IMAGE],
            'nano-banana' => [self::MODEL_CAP_IMAGE],
            'nano-banana-2' => [self::MODEL_CAP_IMAGE],
            'nano-banana-pro-preview' => [self::MODEL_CAP_IMAGE],
            'nano-banana-pro' => [self::MODEL_CAP_IMAGE],
            'dall-e-2' => [self::MODEL_CAP_IMAGE],
            'dall-e-3' => [self::MODEL_CAP_IMAGE],
        ];
    }

    protected static function normalize_model_name_for_capability(string $model): string {
        $model = strtolower(trim($model));
        $model = preg_replace('#^models/#', '', $model);
        return $model ?: '';
    }

    public static function has_image_capability(string $model): bool {
        $m = self::normalize_model_name_for_capability($model);
        if ($m === '') { return false; }
        $matrix = self::model_capability_registry();
        if (isset($matrix[$m])) {
            return in_array(self::MODEL_CAP_IMAGE, $matrix[$m], true);
        }
        // Conservative allow-list for new/custom models.
        return (bool)preg_match('/(^|[-_])image($|[-_])|^imagen|(^|[-_])imagen($|[-_])|nano[-_]?banana|gpt[-_]?image|dall[-_]?e/i', $m);
    }

    public static function has_text_capability(string $model): bool {
        $m = self::normalize_model_name_for_capability($model);
        if ($m === '') { return false; }
        $matrix = self::model_capability_registry();
        if (isset($matrix[$m])) {
            return in_array(self::MODEL_CAP_TEXT, $matrix[$m], true);
        }
        // Dedicated image/video/audio/embed models are not text-generation choices.
        if (self::has_image_capability($m) && !preg_match('/gemini.*image/i', $m)) {
            return false;
        }
        if (preg_match('/tts|audio|veo|video|embedding|embed|lyria|imagen|nano[-_]?banana|gpt[-_]?image|dall[-_]?e/i', $m)) {
            return false;
        }
        return true;
    }

    public static function model_type(string $model): string {
        $text = self::has_text_capability($model);
        $image = self::has_image_capability($model);
        if ($text && $image) { return 'hybrid'; }
        if ($image) { return 'image_only'; }
        if ($text) { return 'text_only'; }
        return 'unknown';
    }

    protected static function model_allowed_for_feature(string $model, string $feature): bool {
        if ($feature === 'img' || $feature === 'image') {
            return self::has_image_capability($model);
        }
        return self::has_text_capability($model);
    }

    protected static function table_for_key(\stdClass $key): string {
        return (string)($key->_source_table ?? 'local_aisgk_ai_keys');
    }

    protected static function add_runtime_source(\stdClass $key, string $table): \stdClass {
        $key->_source_table = $table;
        return $key;
    }

    protected static function tomorrow_reset_time(): int {
        return strtotime('tomorrow 00:05') ?: (time() + DAYSECS);
    }

    protected static function today_key(): int {
        return (int)date('Ymd');
    }

    protected static function normalize_key(\stdClass $key): \stdClass {
        $today = self::today_key();
        if (empty($key->daily_reset_at) || (int)date('Ymd', (int)$key->daily_reset_at) !== $today) {
            $key->daily_used = 0;
            $key->daily_reset_at = time();
        }
        if (!isset($key->daily_limit)) {
            $key->daily_limit = ((string)($key->category_key ?? 'free') === 'pay') ? 100 : 0;
        }
        foreach (['cooldown_until','last_used','last_tokens','last_tokens_at','usage_last_sync','in_use_by','in_use_until'] as $f) {
            if (!isset($key->$f)) { $key->$f = 0; }
        }
        foreach (['status','category_key','provider','model_homework','model_img','model_homework_status','model_img_status','last_error','last_model'] as $f) {
            if (!isset($key->$f)) { $key->$f = ''; }
        }
        if ($key->status === '') { $key->status = 'active'; }
        if ($key->category_key === '') { $key->category_key = 'free'; }
        if ($key->provider === '') { $key->provider = self::provider_for_key($key); }
        return $key;
    }

    protected static function update_key_record(\stdClass $key): void {
        global $DB;
        $table = self::table_for_key($key);
        $record = clone $key;
        unset($record->_source_table);
        $current = !empty($record->id) ? $DB->get_record($table, ['id' => (int)$record->id]) : null;
        if ($current) {
            // Never overwrite configured models from runtime attempts.
            $record->model_homework = $current->model_homework ?? $record->model_homework ?? '';
            $record->model_img = $current->model_img ?? $record->model_img ?? '';
            foreach (['gmail_account','api_key','category_key','provider','proxy_info','timecreated','usermodified'] as $f) {
                if (!isset($record->$f) && isset($current->$f)) { $record->$f = $current->$f; }
            }
        }
        if (property_exists($record, 'timemodified')) { $record->timemodified = time(); }
        $DB->update_record($table, $record);
    }

    public static function provider_for_key(\stdClass $key): string {
        $provider = trim((string)($key->provider ?? ''));
        if ($provider === '') {
            $provider = ((string)($key->category_key ?? 'free') === 'pay') ? 'shopaikey' : 'google';
        }
        return in_array($provider, ['google', 'shopaikey'], true) ? $provider : 'google';
    }

    public static function configured_models_for_key(\stdClass $key, string $feature): array {
        $raw = trim((string)(($feature === 'img' || $feature === 'image') ? ($key->model_img ?? '') : ($key->model_homework ?? '')));
        if ($raw === '') {
            return [];
        }
        $out = [];
        foreach (explode(',', $raw) as $model) {
            $model = trim($model);
            if ($model !== '' && self::model_allowed_for_feature($model, $feature) && !in_array($model, $out, true)) {
                $out[] = $model;
            }
        }
        return $out;
    }

    protected static function status_field_for_feature(string $feature): string {
        return ($feature === 'img' || $feature === 'image') ? 'model_img_status' : 'model_homework_status';
    }

    protected static function decode_model_statuses(\stdClass $key, string $feature): array {
        $parse = function(string $raw): array {
            $map = [];
            $raw = trim($raw);
            if ($raw === '') { return $map; }
            $decoded = json_decode($raw, true);
            if (!is_array($decoded)) { return $map; }
            foreach ($decoded as $model => $state) {
                if (!is_array($state)) {
                    $state = ['status' => (string)$state];
                }
                $status = (string)($state['status'] ?? 'active');
                if (!in_array($status, ['active', 'cooldown', 'blocked'], true)) {
                    $status = 'active';
                }
                $map[(string)$model] = [
                    'status' => $status,
                    'cooldown_until' => max(0, (int)($state['cooldown_until'] ?? 0)),
                    'last_error' => mb_substr((string)($state['last_error'] ?? ''), 0, 1000),
                    'last_used' => max(0, (int)($state['last_used'] ?? 0)),
                ];
            }
            return $map;
        };

        $field = self::status_field_for_feature($feature);
        $map = $parse((string)($key->$field ?? ''));

        // Text tasks share Model Text / model_homework_status; image status stays independent.
        return $map;
    }

    public static function normalize_model_status_json(string $modelsraw, string $statusjson = ''): string {
        $models = [];
        foreach (explode(',', $modelsraw) as $model) {
            $model = trim($model);
            if ($model !== '' && !in_array($model, $models, true)) {
                $models[] = $model;
            }
        }
        $old = [];
        $decoded = json_decode(trim($statusjson), true);
        if (is_array($decoded)) {
            $old = $decoded;
        }
        $out = [];
        foreach ($models as $model) {
            $state = $old[$model] ?? [];
            if (!is_array($state)) {
                $state = ['status' => (string)$state];
            }
            $status = (string)($state['status'] ?? 'active');
            if (!in_array($status, ['active', 'cooldown', 'blocked'], true)) {
                $status = 'active';
            }
            $out[$model] = [
                'status' => $status,
                'cooldown_until' => max(0, (int)($state['cooldown_until'] ?? 0)),
                'last_error' => mb_substr((string)($state['last_error'] ?? ''), 0, 1000),
                'last_used' => max(0, (int)($state['last_used'] ?? 0)),
            ];
        }
        return $out ? json_encode($out, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES) : '';
    }

    protected static function save_model_statuses(\stdClass $key, string $feature, array $map): void {
        $field = self::status_field_for_feature($feature);
        $models = self::configured_models_for_key($key, $feature);
        $out = [];
        foreach ($models as $model) {
            $state = $map[$model] ?? ['status' => 'active', 'cooldown_until' => 0, 'last_error' => '', 'last_used' => 0];
            $status = (string)($state['status'] ?? 'active');
            if (!in_array($status, ['active', 'cooldown', 'blocked'], true)) {
                $status = 'active';
            }
            $out[$model] = [
                'status' => $status,
                'cooldown_until' => max(0, (int)($state['cooldown_until'] ?? 0)),
                'last_error' => mb_substr((string)($state['last_error'] ?? ''), 0, 1000),
                'last_used' => max(0, (int)($state['last_used'] ?? 0)),
            ];
        }
        $key->$field = $out ? json_encode($out, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES) : '';
        self::update_key_record($key);
    }

    protected static function raw_models_for_feature(\stdClass $key, string $feature): string {
        return (string)(($feature === 'img' || $feature === 'image')
            ? ($key->model_img ?? '')
            : ($key->model_homework ?? ''));
    }

    protected static function set_model_state_on_key(\stdClass $key, string $feature, string $model, array $state): void {
        if ($model === '') { return; }
        $features = ($feature === 'img' || $feature === 'image') ? ['img'] : ['homework'];
        foreach ($features as $f) {
            $map = self::decode_model_statuses($key, $f);
            $map[$model] = $state;
            $field = self::status_field_for_feature($f);
            $key->$field = self::normalize_model_status_json(self::raw_models_for_feature($key, $f), json_encode($map, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES));
        }
    }

    public static function model_attempts_for_key(\stdClass $key, string $feature): array {
        $key = self::normalize_key($key);
        $models = self::configured_models_for_key($key, $feature);
        if (!$models) {
            return [];
        }
        $now = time();
        $map = self::decode_model_statuses($key, $feature);
        $changed = false;
        $out = [];
        foreach ($models as $model) {
            $state = $map[$model] ?? ['status' => 'active', 'cooldown_until' => 0, 'last_error' => '', 'last_used' => 0];
            $status = (string)($state['status'] ?? 'active');
            $until = max(0, (int)($state['cooldown_until'] ?? 0));
            $err = (string)($state['last_error'] ?? '');
            $lastused = max(0, (int)($state['last_used'] ?? 0));
            $quotaerr = self::is_daily_quota_error($err);

            if ($status === 'cooldown' && $until > 0 && $until <= $now) {
                $state['status'] = 'active';
                $state['cooldown_until'] = 0;
                if ($quotaerr) {
                    $state['last_error'] = '';
                    $quotaerr = false;
                }
                $map[$model] = $state;
                $status = 'active';
                $changed = true;
            } else if ($status === 'active' && $quotaerr && $lastused > 0 && (int)date('Ymd', $lastused) === (int)date('Ymd', $now)) {
                // Repair old/bad rows where a quota error was saved but the status stayed active.
                $state['status'] = 'cooldown';
                $state['cooldown_until'] = self::tomorrow_reset_time();
                $map[$model] = $state;
                $status = 'cooldown';
                $changed = true;
            } else if ($status === 'active' && $quotaerr && $lastused > 0 && (int)date('Ymd', $lastused) !== (int)date('Ymd', $now)) {
                $state['last_error'] = '';
                $map[$model] = $state;
                $changed = true;
            }

            if ($status === 'blocked' || $status === 'cooldown') {
                continue;
            }
            $out[] = $model;
        }
        if ($changed) {
            self::save_model_statuses($key, $feature, $map);
        }
        if (self::auto_select_best_model_enabled($feature) && count($out) > 1) {
            usort($out, function($a, $b) use ($feature) {
                $sa = self::model_score_value((string)$a, $feature);
                $sb = self::model_score_value((string)$b, $feature);
                if ($sa == $sb) { return 0; }
                return ($sa > $sb) ? -1 : 1;
            });
        }
        return $out;
    }

    public static function user_daily_usage_summary(int $userid): array {
        global $DB;
        $limit = (int)get_config('local_aisgk', 'system_user_daily_limit');
        if ($limit <= 0) { $limit = self::USER_DAILY_LIMIT; }
        if ($userid <= 0 || is_siteadmin($userid)) {
            return ['used' => 0, 'limit' => $limit, 'remain' => -1, 'isadmin' => true, 'text' => 'Admin: không tính lượt API hệ thống'];
        }
        $used = 0;
        if ($DB->get_manager()->table_exists('local_aisgk_user_usage')) {
            $row = $DB->get_record('local_aisgk_user_usage', ['userid' => $userid, 'usedate' => date('Y-m-d')]);
            if ($row) { $used = (int)$row->used_calls; }
        }
        return ['used' => $used, 'limit' => $limit, 'remain' => max(0, $limit - $used), 'isadmin' => false,
            'text' => 'API hệ thống hôm nay: ' . $used . '/' . $limit];
    }

    public static function check_user_daily_limit(int $userid): void {
        global $DB;
        if ($userid <= 0 || is_siteadmin($userid) || !$DB->get_manager()->table_exists('local_aisgk_user_usage')) {
            return;
        }
        $summary = self::user_daily_usage_summary($userid);
        if (!$summary['isadmin'] && (int)$summary['used'] >= (int)$summary['limit']) {
            throw new \moodle_exception('errorprocessingbook', 'local_aisgk', '', 'Bạn đã dùng hết ' . $summary['limit'] . ' lượt gọi AI hệ thống hôm nay.');
        }
    }

    public static function mark_user_call(int $userid): void {
        global $DB;
        if ($userid <= 0 || is_siteadmin($userid) || !$DB->get_manager()->table_exists('local_aisgk_user_usage')) {
            return;
        }
        $today = date('Y-m-d');
        $now = time();
        $row = $DB->get_record('local_aisgk_user_usage', ['userid' => $userid, 'usedate' => $today]);
        if ($row) {
            $row->used_calls = (int)$row->used_calls + 1;
            $row->timemodified = $now;
            $DB->update_record('local_aisgk_user_usage', $row);
        } else {
            $row = (object)['userid' => $userid, 'usedate' => $today, 'used_calls' => 1, 'timecreated' => $now, 'timemodified' => $now];
            $DB->insert_record('local_aisgk_user_usage', $row);
        }
    }

    public static function wait_global_slot(): void {
        global $DB;
        if (!$DB->get_manager()->table_exists('local_aisgk_api_calls')) {
            return;
        }
        $now = time();
        $DB->delete_records_select('local_aisgk_api_calls', 'timecreated < ?', [$now - 180]);
        $count = $DB->count_records_select('local_aisgk_api_calls', 'timecreated >= ?', [$now - 60]);
        if ($count >= self::GLOBAL_RPM_LIMIT) {
            // Soft throttle to avoid bursting too hard from one VPS IP.
            usleep(700000);
        }
    }

    public static function mark_global_call(): void {
        global $DB;
        if (!$DB->get_manager()->table_exists('local_aisgk_api_calls')) {
            return;
        }
        $DB->insert_record('local_aisgk_api_calls', (object)['timecreated' => time()]);
    }

    public static function get_available_key(string $feature = 'homework', array $excludeids = [], int $userid = 0, bool $preferuser = false, int $estimatedtokens = 0) {
        global $DB;
        $excludeids = array_map('strval', $excludeids);
        $sources = [];
        if ($preferuser && $userid > 0 && $DB->get_manager()->table_exists('local_aisgk_user_ai_keys')) {
            $sources[] = ['table' => 'local_aisgk_user_ai_keys', 'conditions' => ['userid' => $userid]];
        }
        $sources[] = ['table' => 'local_aisgk_ai_keys', 'conditions' => null];

        foreach ($sources as $source) {
            if (!$DB->get_manager()->table_exists($source['table'])) { continue; }
            $keys = $DB->get_records($source['table'], $source['conditions'], 'last_used ASC, id ASC');
            $free = [];
            $pay = [];
            foreach ($keys as $k) {
                $k = self::add_runtime_source($k, $source['table']);
                $compound = (string)$source['table'] . ':' . (int)$k->id;
                if (in_array($compound, $excludeids, true) || in_array((string)(int)$k->id, $excludeids, true)) { continue; }
                if (!self::prepare_key_for_selection($k, $userid)) { continue; }
                if (!self::can_use_key($k, $estimatedtokens)) { continue; }
                if (!self::model_attempts_for_key($k, $feature)) { continue; }
                if ((string)($k->category_key ?? 'free') === 'pay') { $pay[] = $k; } else { $free[] = $k; }
            }
            $chosen = null;
            if ($free) { usort($free, fn($a, $b) => ((int)$a->last_used <=> (int)$b->last_used)); $chosen = $free[0]; }
            else if ($pay) { usort($pay, fn($a, $b) => ((int)$a->last_used <=> (int)$b->last_used)); $chosen = $pay[0]; }
            if ($chosen) {
                self::reserve_key($chosen, $userid);
                return $chosen;
            }
        }
        return null;
    }

    protected static function prepare_key_for_selection(\stdClass $key, int $userid = 0): bool {
        $now = time();
        $key = self::normalize_key($key);
        $status = (string)($key->status ?? 'active');
        if ($status === 'blocked') { return false; }
        if ($status === 'cooldown') {
            if ((int)($key->cooldown_until ?? 0) > $now) { return false; }
            $key->status = 'active';
            $key->cooldown_until = 0;
        }
        if (trim((string)($key->api_key ?? '')) === '') { return false; }

        // Pay ShopAIKey: do not rely on the API Keys popup to refresh quota.
        // When a key is selected for any API call, refresh stale usage info and block empty keys here too.
        if ((string)($key->category_key ?? '') === 'pay' && (string)($key->provider ?? '') === 'shopaikey') {
            $lastsync = (int)($key->usage_last_sync ?? 0);
            if ($lastsync <= 0 || ($now - $lastsync) > 300) {
                try {
                    \local_aisgk\aikey_repository::sync_usage_remaining_for_key($key, self::table_for_key($key));
                    global $DB;
                    $fresh = !empty($key->id) ? $DB->get_record(self::table_for_key($key), ['id' => (int)$key->id]) : null;
                    if ($fresh) {
                        foreach (['usage_remaining','usage_last_sync','status','cooldown_until','last_error'] as $f) {
                            if (isset($fresh->$f)) { $key->$f = $fresh->$f; }
                        }
                    }
                } catch (\Throwable $e) {
                    // Usage refresh is best-effort; API errors will still be handled by mark_429/mark_daily_quota later.
                }
            }
            if (isset($key->usage_remaining) && is_numeric($key->usage_remaining)
                && (float)$key->usage_remaining <= 0 && (int)($key->usage_last_sync ?? 0) > 0) {
                $key->status = 'cooldown';
                $key->cooldown_until = self::tomorrow_reset_time();
                $key->last_error = 'ShopAIKey: hết credit/quota';
                self::update_key_record($key);
                return false;
            }
        }

        if (!empty($key->in_use_until) && (int)$key->in_use_until > $now && (int)($key->in_use_by ?? 0) !== $userid) { return false; }
        // Small spacing even without manual RPM counters.
        if (!empty($key->last_used) && ($now - (int)$key->last_used) < 2) { return false; }
        self::update_key_record($key);
        return true;
    }

    protected static function reserve_key(\stdClass $key, int $userid): void {
        $key->in_use_by = $userid;
        $key->in_use_until = time() + 180;
        self::update_key_record($key);
    }

    public static function release_key(\stdClass $key): void {
        $key->in_use_by = 0;
        $key->in_use_until = 0;
        self::update_key_record($key);
    }

    public static function can_use_key(\stdClass $key, int $estimatedtokens = 0): bool {
        $key = self::normalize_key($key);
        if ((int)($key->daily_limit ?? 0) > 0 && (int)($key->daily_used ?? 0) >= (int)$key->daily_limit) {
            return false;
        }
        return true;
    }

    public static function mark_success(\stdClass $key, int $tokens = 0, string $model = '', int $userid = 0, string $feature = ''): array {
        $key = self::normalize_key($key);
        $key->daily_used = (int)($key->daily_used ?? 0) + 1;
        $key->request_count_minute = 0;
        $key->total_requests_day = (int)($key->daily_used ?? 0);
        $key->last_used = time();
        $key->last_error = '';
        $key->last_model = $model;
        $key->last_tokens = max(0, $tokens);
        $key->last_tokens_at = time();
        $key->in_use_by = 0;
        $key->in_use_until = 0;
        if ($feature !== '' && $model !== '') {
            self::set_model_state_on_key($key, $feature, $model, ['status' => 'active', 'cooldown_until' => 0, 'last_error' => '', 'last_used' => time()]);
        }
        self::update_key_record($key);
        if ((string)($key->_source_table ?? 'local_aisgk_ai_keys') === 'local_aisgk_ai_keys') {
            self::mark_user_call($userid);
        }
        return [
            'model' => $model,
            'tokens' => max(0, $tokens),
            'daily_used' => (int)$key->daily_used,
            'daily_limit' => (int)$key->daily_limit,
            'remain_calls' => ((int)$key->daily_limit > 0) ? max(0, (int)$key->daily_limit - (int)$key->daily_used) : 999999,
        ];
    }

    public static function mark_error(\stdClass $key, string $error): void {
        $key->last_error = mb_substr($error, 0, 1000);
        $key->in_use_by = 0;
        $key->in_use_until = 0;
        self::update_key_record($key);
    }

    public static function mark_429(\stdClass $key, string $error = '', string $model = '', string $feature = ''): void {
        $key = self::normalize_key($key);
        $key->last_error = mb_substr($error ?: '429 / rate limit / quota', 0, 1000);
        $key->in_use_by = 0;
        $key->in_use_until = 0;
        if ($model !== '' && $feature !== '') {
            $retry = rand(60, 120);
            if (preg_match('/retry in\s+([0-9.]+)s/i', $key->last_error, $m)) { $retry = max(10, (int)ceil((float)$m[1]) + 2); }
            self::set_model_state_on_key($key, $feature, $model, ['status' => 'cooldown', 'cooldown_until' => time() + $retry, 'last_error' => $key->last_error, 'last_used' => time()]);
        } else {
            $key->status = 'cooldown';
            $key->cooldown_until = time() + rand(300, 900);
        }
        self::update_key_record($key);
    }

    public static function mark_daily_quota(\stdClass $key, string $error = '', string $model = '', string $feature = ''): void {
        $key = self::normalize_key($key);
        $key->last_error = mb_substr($error ?: 'Daily quota exceeded', 0, 1000);
        $key->in_use_by = 0;
        $key->in_use_until = 0;
        if ($model !== '' && $feature !== '') {
            self::set_model_state_on_key($key, $feature, $model, ['status' => 'cooldown', 'cooldown_until' => self::tomorrow_reset_time(), 'last_error' => $key->last_error, 'last_used' => time()]);
        } else {
            $key->status = 'cooldown';
            $key->cooldown_until = self::tomorrow_reset_time();
        }
        self::update_key_record($key);
    }

    public static function mark_model_blocked(\stdClass $key, string $model, string $feature, string $error): void {
        $key = self::normalize_key($key);
        $key->last_error = mb_substr($error, 0, 1000);
        $key->in_use_by = 0;
        $key->in_use_until = 0;
        if ($model !== '' && $feature !== '') {
            self::set_model_state_on_key($key, $feature, $model, ['status' => 'blocked', 'cooldown_until' => 0, 'last_error' => $key->last_error, 'last_used' => time()]);
        }
        self::update_key_record($key);
    }

    public static function mark_blocked(\stdClass $key, string $error): void {
        $key->status = 'blocked';
        $key->last_error = mb_substr($error, 0, 1000);
        $key->in_use_by = 0;
        $key->in_use_until = 0;
        self::update_key_record($key);
    }

    public static function is_model_channel_error(string $error): bool {
        return (bool)preg_match('/no available channel|model.*not.*available|unsupported model|model not found/i', $error);
    }

    public static function is_daily_quota_error(string $error): bool {
        return (bool)preg_match('/daily|rpd|quota exceeded|exceeded your current quota|limit exceeded/i', $error);
    }

    public static function record_model_score(string $model, string $feature, string $phase, int $earned, int $possible): void {
        $model = trim($model);
        if ($model === '' || $possible <= 0) { return; }
        $key = 'model_score_' . $feature;
        $raw = (string)get_config('local_aisgk', $key);
        $data = json_decode($raw, true);
        if (!is_array($data)) { $data = []; }
        if (empty($data[$model]) || !is_array($data[$model])) {
            $data[$model] = ['earned' => 0, 'possible' => 0, 'create_earned' => 0, 'create_possible' => 0, 'repair_earned' => 0, 'repair_possible' => 0, 'calls' => 0, 'last_used' => 0];
        }
        $data[$model]['earned'] = (int)($data[$model]['earned'] ?? 0) + max(0, $earned);
        $data[$model]['possible'] = (int)($data[$model]['possible'] ?? 0) + max(0, $possible);
        $prefix = (strpos($phase, 'repair') !== false) ? 'repair' : 'create';
        $data[$model][$prefix . '_earned'] = (int)($data[$model][$prefix . '_earned'] ?? 0) + max(0, $earned);
        $data[$model][$prefix . '_possible'] = (int)($data[$model][$prefix . '_possible'] ?? 0) + max(0, $possible);
        $data[$model]['calls'] = (int)($data[$model]['calls'] ?? 0) + 1;
        $data[$model]['last_used'] = time();
        set_config($key, json_encode($data, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES), 'local_aisgk');
    }

    protected static function model_score_value(string $model, string $feature): float {
        $raw = (string)get_config('local_aisgk', 'model_score_' . $feature);
        $data = json_decode($raw, true);
        if (!is_array($data) || empty($data[$model]) || !is_array($data[$model])) { return 0.5; }
        $earned = (float)($data[$model]['earned'] ?? 0);
        $possible = (float)($data[$model]['possible'] ?? 0);
        // Làm mượt để model ít mẫu không 100% ảo.
        return ($earned + 3.0) / max(1.0, ($possible + 6.0));
    }

    protected static function auto_select_best_model_enabled(string $feature): bool {
        // For image generation, preserve the explicit priority order configured
        // in Model Img. Auto-scoring can otherwise reorder a pay key to gpt-image-2
        // even when Gemini image models were placed first by the user.
        if ($feature === 'img' || $feature === 'image') {
            return false;
        }
        return (bool)get_config('local_aisgk', 'auto_select_best_model_' . $feature);
    }
    public static function is_balance_error(string $error): bool {
        return (bool)preg_match('/insufficient balance|balance is not enough|not enough balance|billing|payment required|hết tiền/i', $error);
    }
}
