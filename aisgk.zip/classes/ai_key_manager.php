<?php
namespace local_aisgk;

defined('MOODLE_INTERNAL') || die();

class ai_key_manager {
    protected static function table_for_key(\stdClass $key): string {
        return (string)($key->_source_table ?? 'local_aisgk_ai_keys');
    }

    protected static function add_runtime_source(\stdClass $key, string $table): \stdClass {
        $key->_source_table = $table;
        return $key;
    }

    protected static function reset_buckets(\stdClass $key): \stdClass {
        $nowminute = (int)date('YmdHi');
        $today = (int)date('Ymd');
        if ((int)($key->minute_bucket ?? 0) !== $nowminute) {
            $key->used_rpm = 0;
            $key->used_tpm = 0;
            $key->minute_bucket = $nowminute;
        }
        if ((int)($key->day_bucket ?? 0) !== $today) {
            $key->used_rpd = 0;
            $key->day_bucket = $today;
        }
        return $key;
    }

    protected static function defaults_for_key(\stdClass $key): \stdClass {
        $category = (string)($key->category_key ?? 'free');
        $provider = self::provider_for_key($key);
        if (empty($key->limit_rpm)) {
            $key->limit_rpm = ($category === 'pay') ? 30 : (($provider === 'google' && preg_match('/lite/i', (string)($key->model_scan ?? ''))) ? 12 : 8);
        }
        if (empty($key->limit_rpd)) {
            $key->limit_rpd = ($category === 'pay') ? 3000 : (($provider === 'google' && preg_match('/lite/i', (string)($key->model_scan ?? ''))) ? 800 : 200);
        }
        if (empty($key->limit_tpm)) {
            $key->limit_tpm = ($category === 'pay') ? 500000 : 200000;
        }
        foreach (['used_rpm','used_rpd','used_tpm','last_tokens','remain_calls_est'] as $f) {
            if (!isset($key->$f)) { $key->$f = 0; }
        }
        if (!isset($key->last_model)) { $key->last_model = ''; }
        if (!isset($key->last_tokens_at)) { $key->last_tokens_at = 0; }
        return $key;
    }

    protected static function update_key_record(\stdClass $key): void {
        global $DB;
        $table = self::table_for_key($key);
        $record = clone $key;
        unset($record->_source_table);
        // Runtime calls may try fallback models. Never write fallback/current attempt into
        // admin configured Model Scan / Model Homework. Only last_model records actual use.
        $current = !empty($record->id) ? $DB->get_record($table, ['id' => (int)$record->id]) : null;
        if ($current) {
            $record->model_scan = $current->model_scan ?? $record->model_scan ?? '';
            $record->model_homework = $current->model_homework ?? $record->model_homework ?? '';
        }
        $DB->update_record($table, $record);
    }

    public static function provider_for_key(\stdClass $key): string {
        $provider = trim((string)($key->provider ?? ''));
        if ($provider === '') {
            $provider = ((string)($key->category_key ?? 'free') === 'pay') ? 'shopaikey' : 'google';
        }
        return in_array($provider, ['google', 'shopaikey'], true) ? $provider : 'google';
    }

    public static function model_attempts_for_key(\stdClass $key, string $feature): array {
        $primary = trim((string)(($feature === 'homework') ? ($key->model_homework ?? '') : ($key->model_scan ?? '')));
        if ($primary === '') {
            throw new \moodle_exception('errorprocessingbook', 'local_aisgk', '', ($feature === 'homework') ? 'API key chưa cấu hình Model Homework.' : 'API key chưa cấu hình Model Scan.');
        }

        // Chỉ dùng model đã cấu hình trong key. Không tự chèn gemini-flash-latest/gpt-*.
        // Muốn fallback nhiều model thì nhập trực tiếp nhiều model trong ô model, cách nhau bằng dấu phẩy/ống/xuống dòng.
        $parts = preg_split('/[,\|\s]+/', $primary);
        if (!is_array($parts)) { $parts = [$primary]; }
        $out = [];
        foreach ($parts as $m) {
            $m = trim((string)$m);
            if ($m !== '' && !in_array($m, $out, true)) { $out[] = $m; }
        }
        if (!$out) {
            throw new \moodle_exception('errorprocessingbook', 'local_aisgk', '', 'API key chưa cấu hình model hợp lệ.');
        }
        return $out;
    }

    protected static function key_model_priority(\stdClass $key, string $feature): int {
        $model = trim((string)(($feature === 'homework') ? ($key->model_homework ?? '') : ($key->model_scan ?? '')));
        $category = (string)($key->category_key ?? 'free');
        $score = ($category === 'pay') ? 1000 : 0;
        if ($feature === 'homework') {
            if (preg_match('/gemini-2\.5-flash-lite-latest/i', $model)) { return $score + 0; }
            if (preg_match('/gemini-2\.5-flash-lite/i', $model)) { return $score + 10; }
            if (preg_match('/gemini-flash-latest/i', $model)) { return $score + 20; }
            if (preg_match('/^gpt-/i', $model)) { return $score + 900; }
            return $score + 50;
        }
        if (preg_match('/gemini-3\.1-flash-lite-preview/i', $model)) { return $score + 0; }
        if (preg_match('/gemini-flash-latest/i', $model)) { return $score + 10; }
        if (preg_match('/gemini-2\.5-flash-lite/i', $model)) { return $score + 20; }
        if (preg_match('/^gpt-/i', $model)) { return $score + 900; }
        return $score + 50;
    }

    public static function get_available_key(string $feature = 'scan', array $excludeids = [], int $userid = 0, bool $preferuser = false, int $estimatedtokens = 0) {
        global $DB;
        $excludeids = array_map('strval', $excludeids);
        $tables = [];
        if ($preferuser && $userid > 0 && $DB->get_manager()->table_exists('local_aisgk_user_ai_keys')) {
            $tables[] = ['table' => 'local_aisgk_user_ai_keys', 'conditions' => ['userid' => $userid]];
            // Khi giáo viên đã check "Dùng API của tôi", chỉ dùng bảng API cá nhân.
            // Không fallback sang API hệ thống để tránh sai ý người dùng.
        } else {
            $tables[] = ['table' => 'local_aisgk_ai_keys', 'conditions' => null];
        }

        foreach ($tables as $source) {
            $keys = $DB->get_records($source['table'], $source['conditions'], 'category_key ASC, id ASC');
            $free = [];
            $pay = [];
            foreach ($keys as $k) {
                $k = self::add_runtime_source($k, $source['table']);
                if (in_array((string)$source['table'] . ':' . (int)$k->id, $excludeids, true) || in_array((string)(int)$k->id, $excludeids, true)) { continue; }
                if (!self::prepare_key_for_selection($k)) { continue; }
                if (!self::can_use_key($k, $estimatedtokens)) { continue; }
                if ((string)($k->category_key ?? 'free') === 'pay') { $pay[] = $k; } else { $free[] = $k; }
            }
            usort($free, function($a, $b) use ($feature) {
                $pa = self::key_model_priority($a, $feature);
                $pb = self::key_model_priority($b, $feature);
                if ($pa === $pb) { return (int)$a->id <=> (int)$b->id; }
                return $pa <=> $pb;
            });
            usort($pay, function($a, $b) use ($feature) {
                $pa = self::key_model_priority($a, $feature);
                $pb = self::key_model_priority($b, $feature);
                if ($pa === $pb) { return (int)$a->id <=> (int)$b->id; }
                return $pa <=> $pb;
            });
            if ($free) { return $free[0]; }
            if ($pay) { return $pay[0]; }
        }
        return null;
    }

    protected static function prepare_key_for_selection(\stdClass $key): bool {
        $now = time();
        $key = self::defaults_for_key(self::reset_buckets($key));
        $status = (string)($key->status ?? 'active');
        $ispay = ((string)($key->category_key ?? 'free') === 'pay');
        if ($status === 'blocked') { return false; }
        if (!$ispay && $status === 'cooldown') {
            if ((int)($key->cooldown_until ?? 0) > $now) { return false; }
            $key->status = 'active';
            $key->cooldown_until = 0;
        }
        if ($ispay && $status === 'cooldown') {
            $key->status = 'active';
            $key->cooldown_until = 0;
        }
        if (trim((string)($key->api_key ?? '')) === '') { return false; }
        if (!$ispay && !empty($key->last_used) && ($now - (int)$key->last_used) < 2) { return false; }
        self::update_key_record($key);
        return true;
    }

    public static function can_use_key(\stdClass $key, int $estimatedtokens = 0): bool {
        $key = self::defaults_for_key(self::reset_buckets($key));
        if ((string)($key->category_key ?? 'free') === 'pay') { return true; }
        if ((int)$key->limit_rpm > 0 && (int)$key->used_rpm >= (int)$key->limit_rpm) { return false; }
        if ((int)$key->limit_rpd > 0 && (int)$key->used_rpd >= (int)$key->limit_rpd) { return false; }
        if ($estimatedtokens > 0 && (int)$key->limit_tpm > 0 && ((int)$key->used_tpm + $estimatedtokens) > (int)$key->limit_tpm) { return false; }
        return true;
    }

    public static function mark_success(\stdClass $key, int $tokens = 0, string $model = ''): array {
        $key = self::defaults_for_key(self::reset_buckets($key));
        $tokens = max(0, $tokens);
        $key->used_rpm = (int)($key->used_rpm ?? 0) + 1;
        $key->used_rpd = (int)($key->used_rpd ?? 0) + 1;
        $key->used_tpm = (int)($key->used_tpm ?? 0) + $tokens;
        $key->request_count_minute = $key->used_rpm;
        $key->total_requests_day = $key->used_rpd;
        $key->last_used = time();
        $key->last_error = '';
        $key->last_model = $model;
        $key->last_tokens = $tokens;
        $key->last_tokens_at = time();
        $remainrpm = ((int)$key->limit_rpm > 0) ? max(0, (int)$key->limit_rpm - (int)$key->used_rpm) : 999999;
        $remainrpd = ((int)$key->limit_rpd > 0) ? max(0, (int)$key->limit_rpd - (int)$key->used_rpd) : 999999;
        $remaintpmcalls = 999999;
        if ($tokens > 0 && (int)$key->limit_tpm > 0) {
            $remaintpmcalls = max(0, (int)floor(((int)$key->limit_tpm - (int)$key->used_tpm) / max(1, $tokens)));
        }
        $key->remain_calls_est = min($remainrpm, $remainrpd, $remaintpmcalls);
        self::update_key_record($key);
        return ['model'=>$model, 'tokens'=>$tokens, 'remain_calls'=>(int)$key->remain_calls_est, 'used_rpm'=>(int)$key->used_rpm, 'used_rpd'=>(int)$key->used_rpd, 'used_tpm'=>(int)$key->used_tpm, 'limit_rpm'=>(int)$key->limit_rpm, 'limit_rpd'=>(int)$key->limit_rpd, 'limit_tpm'=>(int)$key->limit_tpm];
    }

    public static function mark_error(\stdClass $key, string $error): void {
        $key->last_error = mb_substr($error, 0, 1000);
        self::update_key_record($key);
    }

    public static function mark_429(\stdClass $key): void {
        $key->status = 'cooldown';
        $key->cooldown_until = time() + rand(300, 900);
        $key->last_error = '429 / rate limit / quota';
        self::update_key_record($key);
    }

    public static function mark_blocked(\stdClass $key, string $error): void {
        $key->status = 'blocked';
        $key->last_error = mb_substr($error, 0, 1000);
        self::update_key_record($key);
    }
}
