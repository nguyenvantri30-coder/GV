<?php
namespace local_aisgk;

defined('MOODLE_INTERNAL') || die();

class book_repository {
    public static function get_by_id(int $id): ?\stdClass {
        global $DB;
        $record = $DB->get_record('local_aisgk_books', ['id' => $id]);
        return $record ?: null;
    }

    public static function get_by_courseid(int $courseid): ?\stdClass {
        global $DB;
        $records = $DB->get_records('local_aisgk_books', ['courseid' => $courseid], 'sortorder ASC, id ASC', '*', 0, 1);
        if (!$records) {
            return null;
        }
        return reset($records);
    }

    public static function get_all_by_courseid(int $courseid): array {
        global $DB;
        return array_values($DB->get_records('local_aisgk_books', ['courseid' => $courseid], 'sortorder ASC, id ASC'));
    }

    public static function course_has_book(int $courseid): bool {
        return !empty(self::get_all_by_courseid($courseid));
    }

    public static function get_next_sortorder(int $courseid): int {
        global $DB;
        $max = $DB->get_field_sql('SELECT MAX(sortorder) FROM {local_aisgk_books} WHERE courseid = ?', [$courseid]);
        return ((int)$max) + 1;
    }

    public static function create_book(int $courseid, string $name, string $filename, string $bookseries = '', string $publisher = '', string $description = ''): int {
        global $DB, $USER;

        $record = new \stdClass();
        $record->courseid = $courseid;
        $record->name = trim($name) !== '' ? trim($name) : $filename;
        $record->filename = $filename;
        $record->bookseries = trim($bookseries);
        $record->publisher = trim($publisher);
        $record->description = trim($description);
        $record->fileitemid = 0;
        $record->sortorder = self::get_next_sortorder($courseid);
        $record->tocfrompage = 4;
        $record->toctopage = 5;
        $record->book_part = 0;
        $record->semester_hint = 0;
        $record->scope_source = '';
        $record->timecreated = time();
        $record->timemodified = $record->timecreated;
        $record->usermodified = $USER->id;

        return (int)$DB->insert_record('local_aisgk_books', $record);
    }

    public static function describe_book(?\stdClass $book): string {
        if (!$book) {
            return '';
        }
        $parts = [];
        $name = trim((string)($book->name ?? ''));
        if ($name === '') {
            $name = trim((string)($book->filename ?? ''));
        }
        if ($name !== '') {
            $parts[] = $name;
        }
        $series = trim((string)($book->bookseries ?? ''));
        if ($series !== '') {
            $parts[] = 'Bộ sách: ' . $series;
        }
        $publisher = trim((string)($book->publisher ?? ''));
        if ($publisher !== '') {
            $parts[] = 'Nhà xuất bản: ' . $publisher;
        }
        $desc = trim((string)($book->description ?? ''));
        if ($desc !== '') {
            $parts[] = 'Ghi chú: ' . $desc;
        }
        return implode('; ', $parts);
    }


    public static function delete_book(int $bookid): void {
        global $DB;
        $DB->delete_records('local_aisgk_books', ['id' => $bookid]);
    }

    public static function update_metadata(int $bookid, string $name, string $bookseries, string $publisher, string $description): void {
        global $DB, $USER;
        $record = $DB->get_record('local_aisgk_books', ['id' => $bookid], '*', MUST_EXIST);
        $record->name = trim($name) !== '' ? trim($name) : $record->filename;
        $record->bookseries = trim($bookseries);
        $record->publisher = trim($publisher);
        $record->description = trim($description);
        $record->timemodified = time();
        $record->usermodified = $USER->id;
        $DB->update_record('local_aisgk_books', $record);
    }

    public static function update_scope(int $bookid, int $part, int $semester, string $source): void {
        global $DB, $USER;
        $record = $DB->get_record('local_aisgk_books', ['id' => $bookid], '*', MUST_EXIST);
        $cols = $DB->get_columns('local_aisgk_books');
        if (isset($cols['book_part'])) { $record->book_part = max(0, min(3, $part)); }
        if (isset($cols['semester_hint'])) { $record->semester_hint = max(0, min(3, $semester)); }
        if (isset($cols['scope_source'])) { $record->scope_source = clean_param($source, PARAM_TEXT); }
        $record->timemodified = time();
        $record->usermodified = $USER->id ?? 0;
        $DB->update_record('local_aisgk_books', $record);
    }

    public static function update_fileitemid(int $bookid, int $fileitemid, string $filename): void {
        global $DB, $USER;
        $record = $DB->get_record('local_aisgk_books', ['id' => $bookid], '*', MUST_EXIST);
        $record->fileitemid = $fileitemid;
        $record->filename = $filename;
        $record->timemodified = time();
        $record->usermodified = $USER->id;
        $DB->update_record('local_aisgk_books', $record);
    }
}
