<?php
namespace local_aisgk;

defined('MOODLE_INTERNAL') || die();

class book_repository {
    public static function get_by_id(int $id): ?\stdClass {
        global $DB;
        $record = $DB->get_record('local_aisgk_books', ['id' => $id]);
        return $record ?: null;
    }

    public static function get_by_courseid(int $courseid): ?\stdClass {
        global $DB;
        $records = $DB->get_records('local_aisgk_books', ['courseid' => $courseid], 'sortorder ASC, id ASC', '*', 0, 1);
        if (!$records) {
            return null;
        }
        return reset($records);
    }

    public static function get_all_by_courseid(int $courseid): array {
        global $DB;
        return array_values($DB->get_records('local_aisgk_books', ['courseid' => $courseid], 'sortorder ASC, id ASC'));
    }

    public static function course_has_book(int $courseid): bool {
        return !empty(self::get_all_by_courseid($courseid));
    }

    public static function get_next_sortorder(int $courseid): int {
        global $DB;
        $max = $DB->get_field_sql('SELECT MAX(sortorder) FROM {local_aisgk_books} WHERE courseid = ?', [$courseid]);
        return ((int)$max) + 1;
    }

    public static function create_book(int $courseid, string $name, string $filename): int {
        global $DB, $USER;

        $record = new \stdClass();
        $record->courseid = $courseid;
        $record->name = trim($name) !== '' ? trim($name) : $filename;
        $record->filename = $filename;
        $record->fileitemid = 0;
        $record->sortorder = self::get_next_sortorder($courseid);
        $record->tocfrompage = 4;
        $record->toctopage = 5;
        $record->timecreated = time();
        $record->timemodified = $record->timecreated;
        $record->usermodified = $USER->id;

        return (int)$DB->insert_record('local_aisgk_books', $record);
    }



    public static function delete_book(int $bookid): void {
        global $DB;
        $DB->delete_records('local_aisgk_books', ['id' => $bookid]);
    }

    public static function update_fileitemid(int $bookid, int $fileitemid, string $filename): void {
        global $DB, $USER;
        $record = $DB->get_record('local_aisgk_books', ['id' => $bookid], '*', MUST_EXIST);
        $record->fileitemid = $fileitemid;
        $record->filename = $filename;
        $record->timemodified = time();
        $record->usermodified = $USER->id;
        $DB->update_record('local_aisgk_books', $record);
    }
}
