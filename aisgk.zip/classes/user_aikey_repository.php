<?php
namespace local_aisgk;

defined('MOODLE_INTERNAL') || die();

class user_aikey_repository extends aikey_repository {
    protected const TABLE = 'local_aisgk_user_ai_keys';

    public static function get_all_for_user(int $userid): array {
        global $DB;
        return array_values($DB->get_records(self::TABLE, ['userid' => $userid], 'id ASC'));
    }

    public static function save_rows_for_user(int $userid, array $rows): array {
        global $DB, $USER;

        $transaction = $DB->start_delegated_transaction();
        $existingids = $DB->get_fieldset_select(self::TABLE, 'id', 'userid = ?', [$userid]);
        $seenids = [];
        $now = time();

        foreach ($rows as $row) {
            $record = self::normalize_user_row($row, $now, (int)$USER->id, $userid);
            if (!empty($row['id']) && is_numeric($row['id'])) {
                $record->id = (int)$row['id'];
                if ($DB->record_exists(self::TABLE, ['id' => $record->id, 'userid' => $userid])) {
                    $seenids[] = $record->id;
                    $current = $DB->get_record(self::TABLE, ['id' => $record->id, 'userid' => $userid], '*', MUST_EXIST);
                    $record->timecreated = (int)$current->timecreated;
                    $DB->update_record(self::TABLE, $record);
                } else {
                    unset($record->id);
                    $newid = (int)$DB->insert_record(self::TABLE, $record);
                    $seenids[] = $newid;
                }
            } else {
                $newid = (int)$DB->insert_record(self::TABLE, $record);
                $seenids[] = $newid;
            }
        }

        $todelete = array_diff(array_map('intval', $existingids), array_map('intval', $seenids));
        if ($todelete) {
            [$insql, $params] = $DB->get_in_or_equal($todelete, SQL_PARAMS_QM);
            $params[] = $userid;
            $DB->delete_records_select(self::TABLE, 'id ' . $insql . ' AND userid = ?', $params);
        }

        $transaction->allow_commit();
        return self::get_all_for_user($userid);
    }

    public static function sync_usage_remaining_for_pay_keys_for_user(int $userid): void {
        global $DB;
        $keys = $DB->get_records(self::TABLE, ['userid' => $userid, 'category_key' => 'pay'], 'id ASC');
        foreach ($keys as $key) {
            self::sync_usage_remaining_for_user_key($key);
        }
    }

    public static function sync_usage_remaining_for_user_key(\stdClass $key): void {
        global $DB;
        $id = (int)($key->id ?? 0);
        if ($id <= 0 || (string)($key->category_key ?? '') !== 'pay' || (string)($key->provider ?? '') !== 'shopaikey') {
            return;
        }
        $apikey = trim((string)($key->api_key ?? ''));
        if ($apikey === '') {
            return;
        }
        $url = 'https://api.shopaikey.com/usage?apiKey=' . urlencode($apikey);
        $ch = curl_init($url);
        curl_setopt_array($ch, [
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_TIMEOUT => 8,
            CURLOPT_CONNECTTIMEOUT => 5,
            CURLOPT_HTTPHEADER => ['Accept: application/json'],
        ]);
        $response = curl_exec($ch);
        $errno = curl_errno($ch);
        $httpcode = (int)curl_getinfo($ch, CURLINFO_RESPONSE_CODE);
        curl_close($ch);
        if ($errno || !is_string($response) || trim($response) === '' || $httpcode >= 400) {
            return;
        }
        $decoded = json_decode($response, true);
        if (!is_array($decoded)) {
            return;
        }
        $remaining = self::find_remaining_value($decoded);
        if ($remaining === null) {
            return;
        }
        $current = $DB->get_record(self::TABLE, ['id' => $id]);
        if (!$current) {
            return;
        }
        $current->usage_remaining = $remaining;
        $current->usage_last_sync = time();
        $DB->update_record(self::TABLE, $current);
    }

    protected static function normalize_user_row(array $row, int $now, int $usermodified, int $ownerid): \stdClass {
        $record = parent::normalize_row($row, $now, $usermodified);
        $record->userid = $ownerid;
        return $record;
    }
}
