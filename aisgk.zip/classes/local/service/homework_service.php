<?php
namespace local_aisgk\local\service;

defined('MOODLE_INTERNAL') || die();

use local_aisgk\book_repository;
use local_aisgk\homework_repository;
use local_aisgk\local\job_manager;
use local_aisgk\local\ocr_runner;
use local_aisgk\local\sgk_processor;
use local_aisgk\local\ai_service;
use local_aisgk\toc_repository;

class homework_service {
    protected static $lastaiusage = [];
    public static function normalize_title(string $s): string {
        $s = \core_text::strtolower(trim($s));
        $s = preg_replace('/\s+/u', ' ', $s);
        $s = preg_replace('/^[\d\.\-\:]+\s*/u', '', $s);
        return trim($s);
    }

    public static function find_section_match(int $courseid, int $sectionid): ?array {
        global $DB;
        if ($sectionid < 1) {
            return null;
        }
        $sql = "SELECT t.*
                  FROM {local_aisgk_section_toc} m
                  JOIN {local_aisgk_book_toc} t ON t.id = m.tocid
                  JOIN {local_aisgk_books} b ON b.id = t.bookid
                 WHERE m.sectionid = ? AND b.courseid = ?";
        $toc = $DB->get_record_sql($sql, [$sectionid, $courseid]);
        if (!$toc) {
            return null;
        }
        $book = book_repository::get_by_id((int)$toc->bookid);
        if (!$book || (int)$book->courseid !== $courseid) {
            return null;
        }
        return ['book' => $book, 'toc' => $toc];
    }

    public static function find_topic_match(int $courseid, string $topicname): ?array {
        $target = self::normalize_title($topicname);
        if ($target === '') {
            return null;
        }
        foreach (book_repository::get_all_by_courseid($courseid) as $book) {
            $rows = toc_repository::get_by_bookid((int)$book->id);
            foreach ($rows as $row) {
                $name = self::normalize_title((string)$row->tenbai);
                if ($name === '') {
                    continue;
                }
                if ($name === $target || str_contains($target, $name) || str_contains($name, $target)) {
                    return ['book' => $book, 'toc' => $row];
                }
            }
        }
        return null;
    }

    public static function create_draft_job(int $userid, int $courseid, int $sectionid, string $topicname, int $bookid, int $pagefrom, int $pageto, int $scheduledtime, array $options = []): array {
        global $DB;
        $resourcekey = 'course:' . $courseid . ':section:' . $sectionid . ':homework';
        if ($existing = job_manager::find_active_by_resource($resourcekey, 'createhomework')) {
            return ['jobid' => (int)$existing->id, 'reused' => true];
        }

        $now = time();
        $homeworkid = homework_repository::create([
            'courseid' => $courseid,
            'sectionid' => $sectionid,
            'topicname' => $topicname,
            'bookid' => $bookid,
            'pagefrom' => $pagefrom,
            'pageto' => $pageto,
            'status' => 'draft_generating',
            'approvalstatus' => 'pending',
            'scheduledtime' => $scheduledtime,
            'deliveredtime' => 0,
            'resourcekey' => $resourcekey,
            'sourcetext' => '',
            'sourceformula' => json_encode(['options' => $options], JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES),
            'questiondata' => '',
            'teacheredited' => '',
            'moodlemoduleid' => 0,
            'deliverymessage' => '',
            'errormsg' => '',
            'cancelled' => 0,
            'timecreated' => $now,
            'timemodified' => $now,
            'userid' => $userid,
        ]);

        $payload = [
            'homeworkid' => $homeworkid,
            'courseid' => $courseid,
            'sectionid' => $sectionid,
            'topicname' => $topicname,
            'bookid' => $bookid,
            'pagefrom' => $pagefrom,
            'pageto' => $pageto,
            'scheduledtime' => $scheduledtime,
                    'options' => $options,
        ];
        $jobid = job_manager::create('createhomework', $userid, $resourcekey, $payload);
        $DB->update_record('local_aisgk_homeworks', (object)['id' => $homeworkid, 'jobid' => $jobid]);
        return ['jobid' => $jobid, 'homeworkid' => $homeworkid, 'reused' => false];
    }

    public static function process_job(\stdClass $job): void {
        global $DB;
        $payload = json_decode((string)$job->payloadjson, true) ?: [];
        $homeworkid = (int)($payload['homeworkid'] ?? 0);
        $homework = homework_repository::get_by_id($homeworkid);
        if (!$homework) {
            throw new \moodle_exception('invalidparameter');
        }

        job_manager::update_progress((int)$job->id, 1, 'start', get_string('stepstart', 'local_aisgk'), 5, get_string('homeworkjobstarting', 'local_aisgk'));

        $bookid = (int)$homework->bookid;
        $pagefrom = max(1, (int)$homework->pagefrom);
        $pageto = max($pagefrom, (int)$homework->pageto);

        job_manager::update_progress((int)$job->id, 2, 'render', get_string('stepscanlesson', 'local_aisgk'), 12,
            'Đang render trang SGK thành ảnh để gửi AI...');
        $book = book_repository::get_by_id($bookid);
        sgk_processor::render_toc_images($bookid, $pagefrom, $pageto, 180, static function(int $done, int $total) use ($job): void {
            $percent = 12 + (int)floor(($done / max(1, $total)) * 28);
            job_manager::update_progress((int)$job->id, 2, 'render', 'Render ảnh trang SGK', $percent,
                'Đang render ảnh trang SGK... (' . $done . '/' . $total . ')');
        });
        $images = sgk_processor::get_source_images((int)$book->courseid, $bookid);
        if (!$images) {
            throw new \moodle_exception('bookimagesmissing', 'local_aisgk');
        }

        job_manager::update_progress((int)$job->id, 3, 'generate', get_string('stepcreatehomework', 'local_aisgk'), 55,
            'Đang gửi ảnh trang ' . $pagefrom . '–' . $pageto . ' cho AI để tạo câu hỏi...');
        $bookname = $book ? (string)($book->name ?: $book->filename) : '';
        $ai = self::generate_questions_from_images($homework->topicname, $images, $pagefrom, $pageto, (int)$job->userid,
            (array)($payload["options"] ?? []), $bookname);
        $questions = (array)($ai['questions'] ?? []);
        $options = (array)($payload['options'] ?? []);
        $report = ai_service::validate_homework_against_plan($questions, $options);

        // Phase debug: KHÔNG chặn khi validator báo lỗi. Luôn lưu raw AI + JSON đã normalize
        // để giáo viên thấy kết quả thật và mình có dữ liệu chỉnh prompt/schema/validator.
        $debugjson = [
            'questions' => array_values($questions),
            '_debug' => [
                'raw_ai_text' => (string)($ai['rawtext'] ?? ''),
                'normalizedjson' => (string)($ai['normalizedjson'] ?? ai_service::questions_json($questions)),
                'report' => $report,
            ],
        ];
        $rawjson = json_encode($debugjson, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
        if ($rawjson === false) {
            $rawjson = ai_service::questions_json($questions);
        }
        $questiontext = self::questions_to_text($questions);
        $usage = self::$lastaiusage;
        $errormsg = $report['ok'] ? '' : implode(' | ', $report['errors']);

        homework_repository::update($homeworkid, [
            'status' => 'draft_ready',
            'sourcetext' => $rawjson,
            'sourceformula' => json_encode(['options' => $options, 'report' => $report], JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES),
            'questiondata' => json_encode($questions, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES),
            'teacheredited' => $questiontext,
            'errormsg' => $errormsg,
            'timemodified' => time(),
        ]);

        job_manager::update_progress((int)$job->id, 3, 'done', get_string('stepdone', 'local_aisgk'), 95, get_string('homeworkjobdraftready', 'local_aisgk'));
        job_manager::mark_done((int)$job->id, [
            'homeworkid' => $homeworkid,
            'questioncount' => count($questions),
            'usage' => $usage,
            'report' => $report,
            'hasvalidationerrors' => !$report['ok'],
        ], get_string('homeworkjobresult', 'local_aisgk', count($questions)));
    }

    protected static function extract_formulas(string $text): array {
        $lines = preg_split('/\R/u', $text) ?: [];
        $formula = [];
        foreach ($lines as $line) {
            $line = trim($line);
            if ($line === '') {
                continue;
            }
            if (preg_match('/[=+\-×x*\/²³√()]/u', $line) && preg_match('/\d/u', $line)) {
                $formula[] = $line;
            }
        }
        return array_values(array_slice(array_unique($formula), 0, 12));
    }

    protected static function generate_questions_from_images(string $topicname, array $images, int $pagefrom, int $pageto, int $userid = 0, array $options = [], string $bookname = ''): array {
        $ai = ai_service::generate_homework_questions_from_images($topicname, $images, $pagefrom, $pageto, $userid, $options, $bookname);
        if (empty($ai["questions"]) || !is_array($ai["questions"])) {
            throw new \moodle_exception('errorprocessingbook', 'local_aisgk', '', 'AI không trả về danh sách câu hỏi hợp lệ.');
        }
        self::$lastaiusage = [
            "model" => (string)($ai["model"] ?? ""),
            "tokens" => (int)($ai["tokens"] ?? 0),
            "keysource" => (string)($ai["keysource"] ?? "system"),
            "category" => (string)($ai["category"] ?? "free"),
            "remain_calls" => (int)($ai["usage"]["remain_calls"] ?? 0),
            "api" => ((string)($ai["category"] ?? "free") === "pay") ? "API trả phí" : "API miễn phí/hệ thống",
            "rawtext" => (string)($ai["rawtext"] ?? ""),
        ];
        return $ai;
    }

    protected static function pretty_ai_json(string $rawtext, array $questions): string {
        $json = json_decode(trim($rawtext), true);
        if (!is_array($json) && preg_match('/\{.*\}/s', $rawtext, $m)) {
            $json = json_decode($m[0], true);
        }
        if (!is_array($json)) {
            $json = ['questions' => $questions, 'raw' => $rawtext];
        }
        return json_encode($json, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
    }

    public static function questions_to_text(array $questions): string {
        $out = [];
        foreach ($questions as $index => $q) {
            $out[] = ($index + 1) . '. ' . trim((string)($q['questiontext'] ?? ''));
        }
        return implode("\n\n", $out);
    }

    public static function update_draft(int $homeworkid, string $teacheredited, int $scheduledtime): void {
        homework_repository::update($homeworkid, [
            'teacheredited' => $teacheredited,
            'scheduledtime' => $scheduledtime,
            'status' => 'scheduled',
            'timemodified' => time(),
        ]);
    }

    public static function approve(int $homeworkid): void {
        homework_repository::update($homeworkid, [
            'approvalstatus' => 'approved',
            'status' => 'approved',
            'timemodified' => time(),
        ]);
    }

    public static function cancel(int $homeworkid): void {
        homework_repository::update($homeworkid, [
            'cancelled' => 1,
            'status' => 'cancelled',
            'timemodified' => time(),
        ]);
    }

    public static function delete_bad_drafts(int $courseid, int $sectionid, string $topicname = ''): int {
        return homework_repository::delete_bad_drafts($courseid, $sectionid, $topicname);
    }

    public static function wipe_course_topic(int $courseid, int $sectionid, string $topicname = ''): array {
        $homeworks = homework_repository::delete_by_course_section_topic($courseid, $sectionid, $topicname);
        $questions = self::delete_moodle_question_bank_items($courseid, $topicname);
        return ['homeworks' => $homeworks, 'questions' => $questions];
    }

    protected static function delete_moodle_question_bank_items(int $courseid, string $topicname = ''): int {
        global $DB;
        $context = \context_course::instance($courseid);
        if (!$DB->get_manager()->table_exists('question_categories') || !$DB->get_manager()->table_exists('question')) {
            return 0;
        }
        $like = $topicname !== '' ? '%' . $DB->sql_like_escape($topicname) . '%' : '%AISGK%';
        $params = ['like1' => $like, 'like2' => $like];
        $catids = $DB->get_fieldset_select('question_categories', 'id', 'contextid = ?', [$context->id]);
        if (!$catids) {
            return 0;
        }
        list($catsql, $catparams) = $DB->get_in_or_equal($catids, SQL_PARAMS_NAMED, 'cat');
        $params = array_merge($params, $catparams);
        if ($DB->get_manager()->table_exists('question_versions') && $DB->get_manager()->table_exists('question_bank_entries')) {
            $sql = "SELECT q.id
                      FROM {question} q
                      JOIN {question_versions} qv ON qv.questionid = q.id
                      JOIN {question_bank_entries} qbe ON qbe.id = qv.questionbankentryid
                     WHERE qbe.questioncategoryid {$catsql}
                       AND (" . $DB->sql_like('q.name', ':like1', false) . " OR " . $DB->sql_like('q.questiontext', ':like2', false) . ")";
            $qids = $DB->get_fieldset_sql($sql, $params);
        } else {
            $where = "category {$catsql} AND (" . $DB->sql_like('name', ':like1', false) . " OR " . $DB->sql_like('questiontext', ':like2', false) . ")";
            $qids = $DB->get_fieldset_select('question', 'id', $where, $params);
        }
        if (!$qids) {
            return 0;
        }
        list($qsql, $qparams) = $DB->get_in_or_equal($qids, SQL_PARAMS_NAMED, 'qid');
        if ($DB->get_manager()->table_exists('question_versions')) {
            $entryids = $DB->get_fieldset_select('question_versions', 'questionbankentryid', 'questionid ' . $qsql, $qparams);
            $DB->delete_records_select('question_versions', 'questionid ' . $qsql, $qparams);
            if ($entryids && $DB->get_manager()->table_exists('question_bank_entries')) {
                $entryids = array_values(array_unique(array_map('intval', $entryids)));
                list($esql, $eparams) = $DB->get_in_or_equal($entryids, SQL_PARAMS_NAMED, 'entry');
                $DB->delete_records_select('question_bank_entries', 'id ' . $esql, $eparams);
            }
        }
        $DB->delete_records_select('question', 'id ' . $qsql, $qparams);
        return count($qids);
    }

    public static function deliver_due(): int {
        $count = 0;
        foreach (homework_repository::find_due_for_delivery(time()) as $homework) {
            self::deliver_one($homework);
            $count++;
        }
        return $count;
    }

    protected static function deliver_one(\stdClass $homework): void {
        global $CFG, $DB;
        require_once($CFG->dirroot . '/course/modlib.php');

        $course = get_course((int)$homework->courseid);
        $modinfo = get_fast_modinfo($course);
        $sectioninfo = $modinfo->get_section_info_by_id((int)$homework->sectionid);
        $sectionnum = $sectioninfo ? (int)$sectioninfo->section : 0;

        $content = trim((string)$homework->teacheredited);
        if ($content === '') {
            $content = trim((string)$homework->sourcetext);
        }
        if ($content === '') {
            $content = get_string('homeworkemptydraftfallback', 'local_aisgk');
        }

        $moduleid = 0;
        $deliverymessage = '';
        try {
            $assignmodule = $DB->get_record('modules', ['name' => 'assign']);
            if ($assignmodule) {
                $moduleinfo = (object)[
                    'course' => (int)$homework->courseid,
                    'section' => $sectionnum,
                    'module' => (int)$assignmodule->id,
                    'modulename' => 'assign',
                    'name' => 'BTVN - ' . $homework->topicname,
                    'intro' => format_text($content, FORMAT_HTML),
                    'introformat' => FORMAT_HTML,
                    'alwaysshowdescription' => 1,
                    'duedate' => max(time() + 3600, (int)$homework->scheduledtime + 86400),
                    'allowsubmissionsfromdate' => (int)$homework->scheduledtime,
                    'cutoffdate' => 0,
                    'gradingduedate' => 0,
                    'grade' => 100,
                    'submissiondrafts' => 0,
                    'sendnotifications' => 0,
                    'sendlatenotifications' => 0,
                    'sendstudentnotifications' => 0,
                    'assignsubmission_onlinetext_enabled' => 1,
                    'assignsubmission_file_enabled' => 0,
                    'visible' => 1,
                ];
                $cm = add_moduleinfo($moduleinfo, $course);
                $moduleid = (int)($cm->coursemodule ?? 0);
                $deliverymessage = 'assign';
            }
        } catch (\Throwable $e) {
            $deliverymessage = 'assign-fallback';
        }

        if (!$moduleid) {
            $labelmodule = $DB->get_record('modules', ['name' => 'label'], '*', MUST_EXIST);
            $moduleinfo = (object)[
                'course' => (int)$homework->courseid,
                'section' => $sectionnum,
                'module' => (int)$labelmodule->id,
                'modulename' => 'label',
                'name' => 'BTVN - ' . $homework->topicname,
                'intro' => format_text($content, FORMAT_HTML),
                'introformat' => FORMAT_HTML,
                'visible' => 1,
            ];
            $cm = add_moduleinfo($moduleinfo, $course);
            $moduleid = (int)($cm->coursemodule ?? 0);
            $deliverymessage = $deliverymessage ?: 'label';
        }

        homework_repository::update((int)$homework->id, [
            'status' => 'delivered',
            'approvalstatus' => $homework->approvalstatus === 'pending' ? 'autoapproved' : $homework->approvalstatus,
            'deliveredtime' => time(),
            'moodlemoduleid' => $moduleid,
            'deliverymessage' => $deliverymessage,
            'timemodified' => time(),
        ]);
    }
}
