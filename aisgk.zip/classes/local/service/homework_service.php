<?php
namespace local_aisgk\local\service;

defined('MOODLE_INTERNAL') || die();

use local_aisgk\book_repository;
use local_aisgk\homework_repository;
use local_aisgk\local\job_manager;
use local_aisgk\local\ocr_runner;
use local_aisgk\local\sgk_processor;
use local_aisgk\local\ai_service;
use local_aisgk\toc_repository;

class homework_service {
    /**
     * The SGK page number shown in TOC/AI marker is the printed/book page.
     * In current SGK PDFs, the physical PDF page to render is printed page + 1.
     * Example: SGK page 6 => PDF page 7.
     */
    protected const SGK_TO_PDF_PAGE_OFFSET = 1;
    protected const AI_SENT_IMAGE_WIDTH = 1000;
    protected const AI_SENT_IMAGE_WIDTH_OPTIONS = [0, 1000, 1200, 1400];
    protected const AI_TRIM_MARGIN_RATIO = 0.05;
    protected const AI_SENT_JPEG_QUALITY = 85;
    // Cache optimized images sent to AI for 1 day only.
    protected const AI_SENT_CACHE_TTL = 86400;

    protected static $lastaiusage = [];
    public static function normalize_title(string $s): string {
        $s = \core_text::strtolower(trim($s));
        $s = preg_replace('/\s+/u', ' ', $s);
        $s = preg_replace('/^[\d\.\-\:]+\s*/u', '', $s);
        return trim($s);
    }

    public static function find_section_match(int $courseid, int $sectionid): ?array {
        global $DB;
        if ($sectionid < 1) {
            return null;
        }
        $sql = "SELECT t.*
                  FROM {local_aisgk_section_toc} m
                  JOIN {local_aisgk_book_toc} t ON t.id = m.tocid
                  JOIN {local_aisgk_books} b ON b.id = t.bookid
                 WHERE m.sectionid = ? AND b.courseid = ?";
        $toc = $DB->get_record_sql($sql, [$sectionid, $courseid]);
        if (!$toc) {
            return null;
        }
        $book = book_repository::get_by_id((int)$toc->bookid);
        if (!$book || (int)$book->courseid !== $courseid) {
            return null;
        }
        return ['book' => $book, 'toc' => $toc];
    }

    public static function find_topic_match(int $courseid, string $topicname): ?array {
        $target = self::normalize_title($topicname);
        if ($target === '') {
            return null;
        }
        foreach (book_repository::get_all_by_courseid($courseid) as $book) {
            $rows = toc_repository::get_by_bookid((int)$book->id);
            foreach ($rows as $row) {
                $name = self::normalize_title((string)$row->tenbai);
                if ($name === '') {
                    continue;
                }
                if ($name === $target || str_contains($target, $name) || str_contains($name, $target)) {
                    return ['book' => $book, 'toc' => $row];
                }
            }
        }
        return null;
    }

    protected static function homework_fingerprint(int $courseid, int $sectionid, string $topicname, int $bookid, int $pagefrom, int $pageto, array $options): string {
        $config = [
            'courseid' => $courseid,
            'sectionid' => $sectionid,
            'topic' => self::normalize_title($topicname),
            'bookid' => $bookid,
            'pagefrom' => $pagefrom,
            'pageto' => $pageto,
            'qtypes' => $options['qtypes'] ?? [],
            'cognitive' => $options['cognitive'] ?? [],
            'distractors' => $options['distractors'] ?? [],
            'ai_image_width' => self::normalize_ai_image_width($options['ai_image_width'] ?? self::AI_SENT_IMAGE_WIDTH),
        ];
        return sha1(json_encode($config, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES));
    }

    protected static function find_ready_draft_by_fingerprint(string $fingerprint): ?\stdClass {
        global $DB;
        if ($fingerprint === '' || !$DB->get_manager()->field_exists(new \xmldb_table('local_aisgk_homeworks'), new \xmldb_field('fingerprint'))) { return null; }
        $records = $DB->get_records_select('local_aisgk_homeworks', "fingerprint = ? AND status = 'draft_ready' AND cancelled = 0", [$fingerprint], 'id DESC', '*', 0, 1);
        return $records ? reset($records) : null;
    }
    public static function create_draft_job(int $userid, int $courseid, int $sectionid, string $topicname, int $bookid, int $pagefrom, int $pageto, int $scheduledtime, array $options = []): array {
        global $DB;
        $fingerprint = self::homework_fingerprint($courseid, $sectionid, $topicname, $bookid, $pagefrom, $pageto, $options);
        $resourcekey = 'course:' . $courseid . ':section:' . $sectionid . ':homework:' . $fingerprint;
        if ($existing = job_manager::find_active_by_fingerprint($fingerprint, 'createhomework')) {
            return ['jobid' => (int)$existing->id, 'reused' => true];
        }
        if ($existingdraft = self::find_ready_draft_by_fingerprint($fingerprint)) {
            $jobid = job_manager::create('createhomework', $userid, $resourcekey, [
                'homeworkid' => (int)$existingdraft->id,
                'reuseddraft' => true,
                'options' => $options,
            ], $fingerprint, 80, time(), 'manual');
            job_manager::mark_done($jobid, ['homeworkid' => (int)$existingdraft->id, 'reuseddraft' => true], 'Đã có bản nháp cùng cấu hình, không gọi AI lại.');
            return ['jobid' => $jobid, 'homeworkid' => (int)$existingdraft->id, 'reused' => true, 'draftreused' => true];
        }

        $now = time();
        $homeworkid = homework_repository::create([
            'courseid' => $courseid,
            'sectionid' => $sectionid,
            'topicname' => $topicname,
            'bookid' => $bookid,
            'pagefrom' => $pagefrom,
            'pageto' => $pageto,
            'status' => 'draft_generating',
            'approvalstatus' => 'pending',
            'scheduledtime' => $scheduledtime,
            'deliveredtime' => 0,
            'resourcekey' => $resourcekey,
            'fingerprint' => $fingerprint,
            'source' => 'manual',
            'sourcetext' => '',
            'sourceformula' => json_encode(['options' => $options], JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES),
            'questiondata' => '',
            'teacheredited' => '',
            'moodlemoduleid' => 0,
            'deliverymessage' => '',
            'errormsg' => '',
            'cancelled' => 0,
            'timecreated' => $now,
            'timemodified' => $now,
            'userid' => $userid,
        ]);

        $payload = [
            'homeworkid' => $homeworkid,
            'courseid' => $courseid,
            'sectionid' => $sectionid,
            'topicname' => $topicname,
            'bookid' => $bookid,
            'pagefrom' => $pagefrom,
            'pageto' => $pageto,
            'scheduledtime' => $scheduledtime,
            'fingerprint' => $fingerprint,
            'source' => 'manual',
            'options' => $options,
        ];
        $jobid = job_manager::create('createhomework', $userid, $resourcekey, $payload, $fingerprint, 80, time(), 'manual');
        $DB->update_record('local_aisgk_homeworks', (object)['id' => $homeworkid, 'jobid' => $jobid]);
        return ['jobid' => $jobid, 'homeworkid' => $homeworkid, 'reused' => false];
    }


    /**
     * Render short [IMG id] markers for preview only.
     * IMPORTANT: Do NOT overwrite questiondata/sourcetext with <img>.
     * Metadata must live in the per-question images map.
     */
    public static function materialize_homework_images(int $homeworkid, array $options = []): ?\stdClass {
        $homework = homework_repository::get_by_id($homeworkid);
        if (!$homework) {
            return null;
        }

        $raws = [
            (string)($homework->questiondata ?? ''),
            (string)($homework->sourcetext ?? ''),
        ];
        $decoded = null;
        foreach ($raws as $raw) {
            if ($raw === '') {
                continue;
            }
            // JSON paste may contain per-question images metadata without an [IMG h1] marker in questiontext.
            // Still materialize/crop preview images from q.images so the teacher can verify source_box.
            if (strpos($raw, '[IMG ') === false && strpos($raw, '"images"') === false && strpos($raw, "'images'") === false) {
                continue;
            }
            $try = json_decode($raw, true);
            if (is_array($try)) {
                $decoded = $try;
                break;
            }
        }
        if (!is_array($decoded)) {
            $homework->previewquestiondata = '';
            $homework->previewteacheredited = '';
            return $homework;
        }

        $questions = $decoded['questions'] ?? $decoded;
        if (!is_array($questions)) {
            $homework->previewquestiondata = '';
            $homework->previewteacheredited = '';
            return $homework;
        }

        $questions = ai_service::normalize_homework_questions(array_values($questions), $options);
        // Draft/preview mode may crop images inline as data URI for display, but must not persist child crops.
        $persistimages = !empty($options['persist_images']);
        $inlinepreview = !$persistimages && !empty($options['preview_inline_images']);
        $sentmeta = is_array($options['_sent_image_meta'] ?? null) ? (array)$options['_sent_image_meta'] : [];
        $previewquestions = self::materialize_image_refs($questions, [], (int)$homework->pagefrom, (int)$homework->pageto,
            (int)$homework->bookid, (int)$homework->courseid, (int)$homework->sectionid, $homeworkid, $persistimages, $inlinepreview, $sentmeta);

        $homework->previewquestiondata = json_encode($previewquestions, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
        $homework->previewteacheredited = self::questions_to_text($previewquestions);
        return $homework;
    }
    public static function process_job(\stdClass $job): void {
        global $DB;
        $payload = json_decode((string)$job->payloadjson, true) ?: [];
        $homeworkid = (int)($payload['homeworkid'] ?? 0);
        $homework = homework_repository::get_by_id($homeworkid);
        if (!$homework) {
            throw new \moodle_exception('invalidparameter');
        }

        job_manager::update_progress((int)$job->id, 1, 'start', get_string('stepstart', 'local_aisgk'), 5, get_string('homeworkjobstarting', 'local_aisgk'));

        $bookid = (int)$homework->bookid;
        $options = (array)($payload['options'] ?? []);
        $aiwidth = self::normalize_ai_image_width($options['ai_image_width'] ?? self::AI_SENT_IMAGE_WIDTH);
        $pagefrom = max(1, (int)$homework->pagefrom);
        $pageto = max($pagefrom, (int)$homework->pageto);

        job_manager::update_progress((int)$job->id, 2, 'render', get_string('stepscanlesson', 'local_aisgk'), 12,
            'Đang render trang SGK thành ảnh để gửi AI...');
        $book = book_repository::get_by_id($bookid);
        $renderfrom = self::sgk_page_to_pdf_page($pagefrom);
        $renderto = self::sgk_page_to_pdf_page($pageto);
        // Render/cache a COLOR page image at the same width chosen for AI.
        // Manual crop/page viewer must use this same-size color image, so 0-1000 boxes map 1:1 by ratio.
        $images = sgk_processor::render_page_images_cached($bookid, (int)$book->courseid, (int)$homework->sectionid,
            $renderfrom, $renderto, 180, static function(int $done, int $total) use ($job): void {
                $percent = 12 + (int)floor(($done / max(1, $total)) * 28);
                job_manager::update_progress((int)$job->id, 2, 'render', 'Render/cache ảnh màu trang SGK', $percent,
                    'Đang chuẩn bị ảnh màu trang SGK cùng kích thước ảnh gửi AI... (' . $done . '/' . $total . ')');
            }, true, $aiwidth);
        if (!$images) {
            throw new \moodle_exception('bookimagesmissing', 'local_aisgk');
        }

        job_manager::update_progress((int)$job->id, 2, 'preprocess', 'Tối ưu ảnh SGK', 45,
            ($aiwidth > 0 ? ('Đang resize nguyên trang SGK về rộng ' . $aiwidth . 'px để gửi AI (không crop lề)...') : 'Đang dùng nguyên kích thước ảnh trang SGK để gửi AI (không resize, không crop lề)...'));
        $prepared = self::prepare_ai_sent_images($images, $pagefrom, (int)$bookid, (int)$book->courseid, (int)$homework->sectionid, (string)$homework->topicname, $aiwidth);
        $aiimages = $prepared['images'];
        $sentmeta = $prepared['meta'];

        job_manager::update_progress((int)$job->id, 3, 'generate', get_string('stepcreatehomework', 'local_aisgk'), 55,
            'Đang gửi ảnh SGK full-page ' . ($aiwidth > 0 ? ('đã resize w' . $aiwidth) : 'nguyên kích thước') . ' trang ' . $pagefrom . '–' . $pageto . ' (PDF ' . $renderfrom . '–' . $renderto . ') cho AI để tạo câu hỏi...');
        $bookname = $book ? (string)($book->name ?: $book->filename) : '';
        $genoptions = $options;
        $genoptions['_jobid'] = (int)$job->id;
        $genoptions['_sent_image_meta'] = $sentmeta;
        $ai = self::generate_questions_from_images($homework->topicname, $aiimages, $pagefrom, $pageto, (int)$job->userid,
            $genoptions, $bookname);
        $questions = (array)($ai['questions'] ?? []);
        // Generate AI backgrounds declared as source="gen" after JSON normalize, before preview/save.
        // This only materializes background images; item images are intentionally not generated yet.
        job_manager::update_progress((int)$job->id, 3, 'generate_images', 'Sinh ảnh nền AI', 72,
            'Đang sinh ảnh nền cho các câu hỏi có source="gen" nếu có...');
        $questions = image_generation_service::generate_backgrounds_for_questions($questions, (int)$job->userid,
            (int)$homework->courseid, (int)$homework->sectionid, $homeworkid, $options);
        // Keep short [IMG id] markers in saved JSON. Render/crop images only for preview/delivery.
        $parseerror = trim((string)($ai['parseerror'] ?? ''));
        if ($parseerror !== '') {
            $report = [
                'ok' => false,
                'errors' => ['Không phân tích được JSON bài tập AI trả về: ' . $parseerror],
                'summary' => ['qtypes' => [], 'levels' => []],
            ];
        } else {
            $report = ai_service::validate_homework_against_plan($questions, $options);
        }

        // Phase debug: KHÔNG chặn khi validator báo lỗi. Luôn lưu raw AI + JSON đã normalize
        // để giáo viên thấy kết quả thật và mình có dữ liệu chỉnh prompt/schema/validator.
        $debugjson = [
            'questions' => array_values($questions),
            '_debug' => [
                'raw_ai_text' => (string)($ai['rawtext'] ?? ''),
                'normalizedjson' => (string)($ai['normalizedjson'] ?? ai_service::questions_json($questions)),
                'parse_error' => $parseerror,
                'report' => $report,
            ],
        ];
        $rawjson = json_encode($debugjson, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
        if ($rawjson === false) {
            $rawjson = ai_service::questions_json($questions);
        }
        $questiontext = self::questions_to_text($questions);
        $usage = self::$lastaiusage;
        $fixmodel = '';
        $fixtokens = 0;
        if (!empty($ai['autorepair']) && is_array($ai['autorepair'])) {
            $fixmodel = (string)($ai['autorepair']['model'] ?? '');
            $fixtokens = (int)($ai['autorepair']['tokens'] ?? 0);
        }
        $meta = [
            'options' => $options,
            'report' => $report,
            'usage' => $usage,
            'model' => (string)($usage['model'] ?? ''),
            'model_create' => (string)($usage['model'] ?? ''),
            'model_fix' => $fixmodel,
            'tokens_create' => (int)($usage['tokens'] ?? 0),
            'tokens_fix' => $fixtokens,
            '_sent_image_meta' => $sentmeta,
        ];
        $errormsg = $report['ok'] ? '' : implode(' | ', $report['errors']);

        homework_repository::update($homeworkid, [
            'status' => 'draft_ready',
            'sourcetext' => $rawjson,
            'sourceformula' => json_encode($meta, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES),
            'questiondata' => json_encode($questions, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES),
            'teacheredited' => $questiontext,
            'errormsg' => $errormsg,
            'timemodified' => time(),
        ]);

        job_manager::update_progress((int)$job->id, 3, 'done', get_string('stepdone', 'local_aisgk'), 95, get_string('homeworkjobdraftready', 'local_aisgk'));
        job_manager::mark_done((int)$job->id, [
            'homeworkid' => $homeworkid,
            'questioncount' => count($questions),
            'usage' => $usage,
            'report' => $report,
            'hasvalidationerrors' => !$report['ok'],
        ], get_string('homeworkjobresult', 'local_aisgk', count($questions)));
    }


    public static function normalize_ai_image_width($value): int {
        $value = (int)$value;
        return in_array($value, self::AI_SENT_IMAGE_WIDTH_OPTIONS, true) ? $value : self::AI_SENT_IMAGE_WIDTH;
    }

    protected static function safe_path_slug(string $value): string {
        $value = trim($value);
        if ($value === '') { return 'topic'; }
        if (class_exists('core_text')) { $value = \core_text::strtolower($value); }
        $value = preg_replace('/[^a-zA-Z0-9\-_]+/u', '_', $value) ?? 'topic';
        $value = trim($value, '_-');
        return mb_substr($value !== '' ? $value : 'topic', 0, 80);
    }

    protected static function cleanup_old_files(string $dir, int $ttl): void {
        $cutoff = time() - max(3600, $ttl);
        foreach (glob(rtrim($dir, '/') . '/*') ?: [] as $file) {
            if (is_file($file) && (int)@filemtime($file) < $cutoff) { @unlink($file); }
        }
    }

    /**
     * Use resized temporary page images only; do not keep full original rendered PDF pages.
     * Do not trim/crop the image sent to AI: this keeps the coordinate system simple and prevents
     * losing figures near page margins. A separate four-margin crop debug image is still saved for inspection.
     * Coordinates returned by AI for source=sgk are [xmin,ymin,xmax,ymax] on 0-1000
     * based on the full-page resized image sent to AI.
     */
    protected static function prepare_ai_sent_images(array $pageimages, int $pagefrom, int $bookid, int $courseid, int $sectionid, string $topicname = '', int $targetwidth = self::AI_SENT_IMAGE_WIDTH): array {
        global $CFG;
        $out = [];
        $meta = [];
        $targetwidth = self::normalize_ai_image_width($targetwidth);
        $topicslug = self::safe_path_slug($topicname !== '' ? $topicname : ('book_' . $bookid));
        $base = rtrim($CFG->dataroot, '/') . '/local_aisgk/ai_sentpages/course_' . $courseid . '/topic_' . $topicslug . '/section_' . max(0, $sectionid) . '/w' . $targetwidth;
        if (!is_dir($base)) { mkdir($base, $CFG->directorypermissions, true); }
        self::cleanup_old_files($base, self::AI_SENT_CACHE_TTL);
        foreach (array_values($pageimages) as $i => $src) {
            $page = $pagefrom + $i;
            if (!is_file($src)) { continue; }
            $info = @getimagesize($src);
            if (!$info || empty($info[0]) || empty($info[1])) { continue; }
            $pdfw = (int)$info[0];
            $pdfh = (int)$info[1];

            // Debug-only four-margin crop, not sent to AI.
            $mx = max(0, (int)round($pdfw * self::AI_TRIM_MARGIN_RATIO));
            $my = max(0, (int)round($pdfh * self::AI_TRIM_MARGIN_RATIO));
            $trimw = max(10, $pdfw - 2 * $mx);
            $trimh = max(10, $pdfh - 2 * $my);
            if ($trimw < 200 || $trimh < 200) { $mx = 0; $my = 0; $trimw = $pdfw; $trimh = $pdfh; }

            $sentw = $targetwidth > 0 ? min($targetwidth, $pdfw) : $pdfw;
            $scale = $sentw / max(1, $pdfw);
            $senth = max(1, (int)round($pdfh * $scale));
            $hash = substr(sha1($src . '|' . @filemtime($src) . '|fullpage-v3|' . $targetwidth), 0, 10);
            $dest = $base . '/page_' . $page . '_full_w' . $targetwidth . '_' . $hash . '.jpg';
            $debugtrim = $base . '/page_' . $page . '_trim_debug_m' . (int)round(self::AI_TRIM_MARGIN_RATIO * 100) . '_' . $hash . '.jpg';
            $cachefresh = is_file($dest) && @filesize($dest) >= 100 && (time() - (int)@filemtime($dest) <= self::AI_SENT_CACHE_TTL);
            if (!$cachefresh) {
                $img = self::image_create_from_file($src);
                if (!$img) { continue; }

                // Save debug crop of the old 4-margin trim so the teacher/admin can inspect what would have been removed.
                $trimmed = @imagecrop($img, ['x' => $mx, 'y' => $my, 'width' => $trimw, 'height' => $trimh]);
                if ($trimmed) {
                    $trimwout = $targetwidth > 0 ? min($targetwidth, $trimw) : $trimw;
                    $trimscale = $trimwout / max(1, $trimw);
                    $trimhout = max(1, (int)round($trimh * $trimscale));
                    $trimscaled = function_exists('imagescale') ? @imagescale($trimmed, $trimwout, $trimhout) : false;
                    if ($trimscaled) { imagedestroy($trimmed); $trimmed = $trimscaled; }
                    @imagejpeg($trimmed, $debugtrim, self::AI_SENT_JPEG_QUALITY);
                    imagedestroy($trimmed);
                    @chmod($debugtrim, $CFG->filepermissions);
                }

                // Send/use the full color PDF page with selected width; width=0 means keep original size. No crop before AI.
                $sent = function_exists('imagescale') ? @imagescale($img, $sentw, $senth) : false;
                imagedestroy($img);
                if (!$sent) { continue; }
                if (function_exists('imageconvolution')) {
                    @imageconvolution($sent, [[0,-1,0],[-1,5,-1],[0,-1,0]], 1, 0);
                }
                @imagejpeg($sent, $dest, self::AI_SENT_JPEG_QUALITY);
                imagedestroy($sent);
                @chmod($dest, $CFG->filepermissions);
            }
            if (!is_file($dest)) { continue; }
            $out[] = $dest;
            $meta[$page] = [
                'sent_image_id' => 'p' . $page,
                'page' => $page,
                'pdf_size' => ['w' => $pdfw, 'h' => $pdfh],
                'trim_margin' => false,
                'crop_offset' => ['x' => 0, 'y' => 0],
                'crop_size' => ['w' => $pdfw, 'h' => $pdfh],
                'sent_size' => ['w' => $sentw, 'h' => $senth],
                'source_size' => ['w' => $sentw, 'h' => $senth],
                'sent_path' => $dest,
                'debug_trim_path' => is_file($debugtrim) ? $debugtrim : '',
                'scale' => round($scale, 8),
                'target_width' => $targetwidth,
            ];
        }
        return ['images' => $out, 'meta' => $meta];
    }

    protected static function sgk_page_to_pdf_page(int $sgkpage): int {
        return max(1, $sgkpage + self::SGK_TO_PDF_PAGE_OFFSET);
    }

    protected static function normalize_img_size_value($value): array {
        if (is_array($value)) {
            if (isset($value['w']) || isset($value['h']) || isset($value['width']) || isset($value['height'])) {
                return ['w' => max(0, (int)($value['w'] ?? $value['width'] ?? 0)), 'h' => max(0, (int)($value['h'] ?? $value['height'] ?? 0))];
            }
            if (isset($value[0]) && isset($value[1]) && !is_array($value[0]) && !is_array($value[1])) {
                return ['w' => max(0, (int)$value[0]), 'h' => max(0, (int)$value[1])];
            }
            // Unknown nested array/object-like value. Do not cast array to string; it would break AJAX JSON output with PHP warnings.
            return ['w' => 0, 'h' => 0];
        }
        return self::parse_size_pair((string)$value);
    }

    protected static function normalize_img_box_value($value): array {
        if (is_array($value)) {
            $vals = array_values($value);
            if (count($vals) === 4 && !array_filter($vals, 'is_array')) { return array_map('intval', $vals); }
            // New generated-image schema may pass canvas/drop_zone objects here by mistake.
            // Treat unrecognized arrays as no crop box instead of emitting 'Array to string conversion'.
            return [];
        }
        return self::parse_box4((string)$value);
    }

    protected static function img_ref_from_meta(string $id, array $meta): ?array {
        $id = trim((string)($meta['id'] ?? $id));
        if ($id === '') { return null; }
        $rawsource = trim((string)($meta['source'] ?? 'sgk'));
        $url = trim((string)($meta['url'] ?? ''));
        $source = strtolower($rawsource !== '' ? $rawsource : 'sgk');
        if (in_array($source, ['gen', 'generated', 'ai', 'generate'], true)) {
            $source = 'gen';
        } else if (preg_match('#^https?://#i', $rawsource) || in_array($source, ['url', 'web', 'internet', 'box', 'canvas'], true)) {
            $source = 'gen';
        } else if ($source !== 'sgk') {
            $source = 'sgk';
        }
        $box = self::normalize_img_box_value($meta['source_box'] ?? ($meta['box'] ?? []));
        if ($source === 'sgk' && count($box) !== 4) { return null; }
        return [
            'id' => $id,
            'label' => trim((string)($meta['label'] ?? $id)),
            'role' => strtolower((string)($meta['role'] ?? 'inline')),
            'source' => $source,
            'page' => (int)($meta['page'] ?? $meta['page_index'] ?? 0),
            'url' => '',
            'description' => trim((string)($meta['description'] ?? $meta['prompt'] ?? $meta['image_prompt'] ?? '')),
            'source_size' => self::normalize_img_size_value($meta['source_size'] ?? ''),
            'source_box' => $box,
            'canvas_size' => self::normalize_img_size_value($meta['canvas'] ?? $meta['canvas_size'] ?? ['w' => 1000, 'h' => 1000]),
            'pdf_size' => self::normalize_img_size_value($meta['pdf_size'] ?? ''),
            'crop_offset' => [
                'x' => (int)($meta['crop_offset']['x'] ?? 0),
                'y' => (int)($meta['crop_offset']['y'] ?? 0),
            ],
            'scale' => (float)($meta['scale'] ?? 0),
            'sent_image_id' => (string)($meta['sent_image_id'] ?? ''),
            'generated' => is_array($meta['generated'] ?? null) ? (array)$meta['generated'] : [],
            'fileurl' => trim((string)($meta['fileurl'] ?? '')),
        ];
    }

    protected static function image_ref_map_from_question(array $q): array {
        $map = [];
        if (!empty($q['images']) && is_array($q['images'])) {
            foreach ($q['images'] as $key => $meta) {
                if (!is_array($meta)) { continue; }
                $id = is_string($key) ? $key : (string)($meta['id'] ?? '');
                $ref = self::img_ref_from_meta($id, $meta);
                if ($ref) { $map[(string)$ref['id']] = $ref; }
            }
        }
        return $map;
    }
    protected static function sent_meta_for_page(array $sentmeta, int $page): array {
        if ($page <= 0 || !is_array($sentmeta)) { return []; }
        return is_array($sentmeta[$page] ?? null) ? (array)$sentmeta[$page] : [];
    }

    protected static function attach_sent_meta_to_ref(array $ref, array $sentmeta): array {
        if (($ref['source'] ?? 'sgk') !== 'sgk') { return $ref; }
        $page = (int)($ref['page'] ?? 0);
        $m = self::sent_meta_for_page($sentmeta, $page);
        if (!$m) { return $ref; }
        foreach (['pdf_size','crop_offset','crop_size','sent_size','source_size','scale','sent_image_id','sent_path','target_width'] as $k) {
            if (array_key_exists($k, $m)) { $ref[$k] = $m[$k]; }
        }
        return $ref;
    }

    protected static function expand_pixel_box(array $box, int $maxw, int $maxh, float $ratiox = 0.06, float $ratioy = 0.04, int $minpad = 8): array {
        if (count($box) !== 4) { return $box; }
        [$x1, $y1, $x2, $y2] = array_map('floatval', $box);
        $w = max(1.0, $x2 - $x1);
        $h = max(1.0, $y2 - $y1);
        $padx = max($minpad, (int)round($w * $ratiox));
        $pady = max($minpad, (int)round($h * $ratioy));
        return [
            max(0, (int)round($x1 - $padx)),
            max(0, (int)round($y1 - $pady)),
            min($maxw, (int)round($x2 + $padx)),
            min($maxh, (int)round($y2 + $pady)),
        ];
    }

    protected static function expand_pixel_box_right_biased(array $box, int $maxw, int $maxh, float $leftx = 0.00, float $rightx = 0.14, float $ratioy = 0.04, int $minpad = 4): array {
        if (count($box) !== 4) { return $box; }
        [$x1, $y1, $x2, $y2] = array_map('floatval', $box);
        $w = max(1.0, $x2 - $x1);
        $h = max(1.0, $y2 - $y1);
        $padleft = ($leftx <= 0) ? 0 : max($minpad, (int)round($w * $leftx));
        $padright = max($minpad, (int)round($w * $rightx));
        $pady = max($minpad, (int)round($h * $ratioy));
        return [
            max(0, (int)round($x1 - $padleft)),
            max(0, (int)round($y1 - $pady)),
            min($maxw, (int)round($x2 + $padright)),
            min($maxh, (int)round($y2 + $pady)),
        ];
    }

    protected static function map_normalized_box_to_pixels(array $box, array $ref, int $imgw, int $imgh): array {
        if (count($box) !== 4) { return $box; }
        // source_box chuẩn thống nhất: [xmin,ymin,xmax,ymax] trên hệ 0-1000 theo đúng ảnh AI nhìn thấy.
        // Preview/crop có thể dùng ảnh màu cùng kích thước/cache width; tọa độ 0-1000 vẫn map đúng.
        [$xmin, $ymin, $xmax, $ymax] = array_map('floatval', $box);

        // Backward compatibility: if any coordinate is outside 0-1000, treat it as an old pixel box.
        $maxcoord = max($xmin, $ymin, $xmax, $ymax);
        if ($maxcoord > 1000) {
            $sourcew = (int)($ref['pdf_size']['w'] ?? $ref['source_size']['w'] ?? $imgw);
            $sourceh = (int)($ref['pdf_size']['h'] ?? $ref['source_size']['h'] ?? $imgh);
            $mapped = [
                ($xmin * $imgw / max(1, $sourcew)),
                ($ymin * $imgh / max(1, $sourceh)),
                ($xmax * $imgw / max(1, $sourcew)),
                ($ymax * $imgh / max(1, $sourceh)),
            ];
            return self::expand_pixel_box($mapped, $imgw, $imgh);
        }

        if (!empty($ref['_crop_on_sent'])) {
            $mapped = [
                ($xmin / 1000.0) * $imgw,
                ($ymin / 1000.0) * $imgh,
                ($xmax / 1000.0) * $imgw,
                ($ymax / 1000.0) * $imgh,
            ];
            return self::expand_pixel_box_right_biased($mapped, $imgw, $imgh, 0.00, 0.14, 0.04);
        }

        if (($ref['source'] ?? 'sgk') === 'sgk') {
            // Current schema: source_box is [xmin,ymin,xmax,ymax] on a 0-1000 grid
            // relative to the exact full-page image AI saw. The preview/crop source is
            // the same page rendered in COLOR at the same selected width, so map directly
            // to the displayed/cache image dimensions. Do not remap via original PDF size.
            $mapped = [
                ($xmin / 1000.0) * $imgw,
                ($ymin / 1000.0) * $imgh,
                ($xmax / 1000.0) * $imgw,
                ($ymax / 1000.0) * $imgh,
            ];
            return self::expand_pixel_box_right_biased($mapped, $imgw, $imgh, 0.00, 0.08, 0.03);
        }

        $mapped = [
            ($xmin / 1000.0) * $imgw,
            ($ymin / 1000.0) * $imgh,
            ($xmax / 1000.0) * $imgw,
            ($ymax / 1000.0) * $imgh,
        ];
        return self::expand_pixel_box($mapped, $imgw, $imgh);
    }

    protected static function materialize_image_refs(array $questions, array $images, int $pagefrom, int $pageto, int $bookid, int $courseid, int $sectionid, int $homeworkid, bool $persistimages = false, bool $inlinepreview = false, array $sentmeta = []): array {
        $pagemap = [];
        foreach (array_values($images) as $i => $path) {
            $pagemap[$pagefrom + $i] = $path;
        }
        $cache = [];
        foreach ($questions as $idx => $q) {
            if (!is_array($q)) {
                continue;
            }
            $idrefs = self::image_ref_map_from_question($q);
            foreach ($idrefs as $rid => $rmeta) { $idrefs[$rid] = self::attach_sent_meta_to_ref($rmeta, $sentmeta); }
            // Preview mode: keep question text readable by replacing [IMG id] with its label,
            // and render the actual cropped image in a separate preview panel. Do not persist child crops here.
            if ($inlinepreview && $idrefs) {
                $q['_preview_images'] = self::build_preview_image_list($idrefs, $cache, $pagemap, $bookid, $courseid, $sectionid, $homeworkid);
            }
            $replace = function(string $text) use (&$cache, &$pagemap, $bookid, $courseid, $sectionid, $homeworkid, $idrefs, $persistimages, $inlinepreview): string {
                // In preview, marker location displays only the label. The image itself is shown in _preview_images.
                return self::replace_img_markers($text, $cache, $pagemap, $bookid, $courseid, $sectionid, $homeworkid, $idrefs, $persistimages, false);
            };
            if (isset($q['questiontext'])) {
                $q['questiontext'] = $replace((string)$q['questiontext']);
            }
            if (!empty($q['subquestions']) && is_array($q['subquestions'])) {
                foreach ($q['subquestions'] as $si => $sq) {
                    if (!is_array($sq)) {
                        continue;
                    }
                    if (isset($sq['question'])) {
                        $sq['question'] = $replace((string)$sq['question']);
                    }
                    if (isset($sq['answer'])) {
                        $sq['answer'] = $replace((string)$sq['answer']);
                    }
                    $q['subquestions'][$si] = $sq;
                }
            }
            if (!empty($q['choices']) && is_array($q['choices'])) {
                foreach ($q['choices'] as $ci => $choice) {
                    if (is_array($choice) && isset($choice['text'])) {
                        $choice['text'] = $replace((string)$choice['text']);
                        $q['choices'][$ci] = $choice;
                    }
                }
            }
            if (!empty($q['items']) && is_array($q['items'])) {
                foreach ($q['items'] as $ii => $item) {
                    if (is_array($item) && isset($item['content'])) {
                        $item['content'] = $replace((string)$item['content']);
                        $q['items'][$ii] = $item;
                    }
                }
            }
            if (!empty($q['background']) && is_string($q['background'])) {
                $q['background'] = $replace($q['background']);
            }
            if (!empty($q['answers']) && is_array($q['answers'])) {
                foreach ($q['answers'] as $ai => $answer) {
                    if (is_array($answer) && isset($answer['text'])) {
                        $answer['text'] = $replace((string)$answer['text']);
                        $q['answers'][$ai] = $answer;
                    }
                }
            }
            $questions[$idx] = $q;
        }
        return $questions;
    }

    protected static function build_preview_image_list(array $idrefs, array &$cache, array &$pagemap, int $bookid, int $courseid, int $sectionid, int $homeworkid): array {
        $out = [];
        foreach ($idrefs as $id => $ref) {
            if (!is_array($ref)) { continue; }
            $label = trim((string)($ref['label'] ?? $id));
            if ($label === '') { $label = (string)$id; }
            $key = 'previewpanel|' . sha1(json_encode($ref));
            if (!array_key_exists($key, $cache)) {
                try {
                    $cache[$key] = self::materialize_img_ref($ref, $pagemap, $bookid, $courseid, $sectionid, $homeworkid, true);
                } catch (\Throwable $e) {
                    $cache[$key] = '<span class="local-aisgk-img-error" title="' . s($e->getMessage()) . '">[IMG lỗi: ' . s($label) . ']</span>';
                }
            }
            $pageurl = '';
            if (($ref['source'] ?? 'sgk') === 'sgk' && (int)($ref['page'] ?? 0) > 0) {
                $url = new \moodle_url('/local/aisgk/pageimg.php', [
                    'courseid' => $courseid,
                    'bookid' => $bookid,
                    'sectionid' => $sectionid,
                    'page' => (int)$ref['page'],
                ]);
                $pageurl = $url->out(false);
            }
            $out[] = [
                'id' => (string)$id,
                'label' => $label,
                'html' => $cache[$key],
                'source' => (string)($ref['source'] ?? 'sgk'),
                'page' => (int)($ref['page'] ?? 0),
                'source_box' => array_values((array)($ref['source_box'] ?? [])),
                'page_url' => $pageurl,
            ];
        }
        return $out;
    }

    protected static function replace_img_markers(string $text, array &$cache, array &$pagemap, int $bookid, int $courseid, int $sectionid, int $homeworkid, array $idrefs = [], bool $persistimages = false, bool $inlinepreview = false): string {
        if ($text === '' || (strpos($text, '[IMG ') === false)) {
            return $text;
        }
        $newre = '/\[IMG\s+([^\]]+)\]/u';
        $text = preg_replace_callback($newre, function(array $m) use (&$cache, &$pagemap, $bookid, $courseid, $sectionid, $homeworkid, $idrefs, $persistimages, $inlinepreview): string {
            $ref = self::parse_img_marker_attrs((string)$m[1]);
            if (!$ref) {
                $shortid = trim((string)$m[1]);
                $shortid = preg_replace('/\s+.*/', '', $shortid);
                $ref = $idrefs[$shortid] ?? null;
            }
            if (!$ref) { return $m[0]; }
            $key = ($persistimages ? 'persist|' : ($inlinepreview ? 'inline|' : 'label|')) . sha1(json_encode($ref));
            if (!$persistimages && !$inlinepreview) {
                $label = trim((string)($ref['label'] ?? $ref['id'] ?? ''));
                return $label !== '' ? s($label) : $m[0];
            }
            if (!array_key_exists($key, $cache)) {
                try {
                    $cache[$key] = self::materialize_img_ref($ref, $pagemap, $bookid, $courseid, $sectionid, $homeworkid, !$persistimages);
                } catch (\Throwable $e) {
                    $label = (string)($ref['id'] ?? $ref['label'] ?? 'img');
                    $cache[$key] = '<span class="local-aisgk-img-error" title="' . s($e->getMessage()) . '">[IMG lỗi: ' . s($label) . ']</span>';
                }
            }
            return $cache[$key];
        }, $text) ?? $text;

        return $text;
    }

    protected static function parse_img_marker_attrs(string $attrtext): ?array {
        $attrs = [];
        if (preg_match_all('/([a-zA-Z_][a-zA-Z0-9_]*)\s*=\s*("([^"]*)"|\'([^\']*)\'|([^\s\]]+))/u', $attrtext, $matches, PREG_SET_ORDER)) {
            foreach ($matches as $m) {
                $attrs[strtolower($m[1])] = trim((string)($m[3] !== '' ? $m[3] : ($m[4] !== '' ? $m[4] : ($m[5] ?? ''))));
            }
        }
        $box = self::parse_box4((string)($attrs['source_box'] ?? $attrs['box'] ?? ''));
        if (count($box) !== 4) { return null; }
        $source = strtolower((string)($attrs['source'] ?? 'sgk'));
        if (in_array($source, ['gen','generated','ai','generate','box','canvas','internet','url','web'], true)) { $source = 'gen'; }
        if (!in_array($source, ['sgk', 'gen'], true)) { $source = 'sgk'; }
        return [
            'id' => (string)($attrs['id'] ?? $attrs['label'] ?? 'img'),
            'role' => strtolower((string)($attrs['role'] ?? 'inline')),
            'source' => $source,
            'page' => (int)($attrs['page'] ?? $attrs['page_index'] ?? 0),
            'url' => (string)($attrs['url'] ?? ''),
            'source_size' => self::parse_size_pair((string)($attrs['source_size'] ?? '')),
            'source_box' => $box,
            'canvas_size' => self::parse_size_pair((string)($attrs['canvas_size'] ?? '')),
        ];
    }

    protected static function parse_size_pair(string $value): array {
        if (preg_match('/^(\d{1,5})\s*[xX,]\s*(\d{1,5})$/', trim($value), $m)) {
            return ['w' => max(1, (int)$m[1]), 'h' => max(1, (int)$m[2])];
        }
        return ['w' => 0, 'h' => 0];
    }

    protected static function parse_box4(string $value): array {
        $parts = array_map('trim', explode(',', $value));
        if (count($parts) !== 4) { return []; }
        return array_map('intval', $parts);
    }

    protected static function materialize_img_ref(array $ref, array &$pagemap, int $bookid, int $courseid, int $sectionid, int $homeworkid, bool $inlineonly = false): string {
        global $CFG;
        $label = trim((string)($ref['label'] ?? $ref['id'] ?? 'img'));
        if ($label === '') { $label = 'img'; }
        $source = (string)($ref['source'] ?? 'sgk');
        $src = '';
        if ($source === 'gen') {
            return self::materialize_generated_ref($ref, $label, $inlineonly);
        }
        {
            // Preview/crop must use the color SGK page cache. The AI input may be grayscale or optimized,
            // but source_box is 0-1000 relative to the full page, so it maps cleanly to a same-width color cache.
            $page = (int)($ref['page'] ?? 0);
            if ($page <= 0) { throw new \moodle_exception('errorprocessingbook', 'local_aisgk', '', 'IMG thiếu page SGK.'); }
            $viewwidth = (int)($ref['target_width'] ?? $ref['source_size']['w'] ?? 1000);
            $viewwidth = self::normalize_ai_image_width($viewwidth);
            $key = $page . ':w' . $viewwidth . ':color';
            if (empty($pagemap[$key]) || !is_file($pagemap[$key])) {
                $pdfpage = self::sgk_page_to_pdf_page($page);
                $rendered = sgk_processor::render_page_images_cached($bookid, $courseid, $sectionid, $pdfpage, $pdfpage, 180, null, true, $viewwidth);
                if (!empty($rendered[0]) && is_file($rendered[0])) { $pagemap[$key] = $rendered[0]; }
            }
            $src = $pagemap[$key] ?? '';
        }
        if ($src === '' || !is_file($src)) { throw new \moodle_exception('errorprocessingbook', 'local_aisgk', '', 'Không tìm thấy ảnh nguồn cho IMG.'); }
        $info = @getimagesize($src);
        if (!$info || empty($info[0]) || empty($info[1])) { throw new \moodle_exception('errorprocessingbook', 'local_aisgk', '', 'Ảnh nguồn không hợp lệ.'); }
        $pixbox = self::map_normalized_box_to_pixels((array)$ref['source_box'], $ref, (int)$info[0], (int)$info[1]);
        [$left, $top, $right, $bottom] = $pixbox;
        $left = max(0, min((int)$info[0] - 1, (int)$left));
        $top = max(0, min((int)$info[1] - 1, (int)$top));
        $right = max($left + 1, min((int)$info[0], (int)$right));
        $bottom = max($top + 1, min((int)$info[1], (int)$bottom));
        $img = self::image_create_from_file($src);
        if (!$img) { throw new \moodle_exception('errorprocessingbook', 'local_aisgk', '', 'Không mở được ảnh nguồn.'); }
        $cropped = @imagecrop($img, ['x' => $left, 'y' => $top, 'width' => $right - $left, 'height' => $bottom - $top]);
        imagedestroy($img);
        if (!$cropped) { throw new \moodle_exception('errorprocessingbook', 'local_aisgk', '', 'Không crop được IMG.'); }
        $workw = (int)($ref['canvas_size']['w'] ?? 0);
        $workh = (int)($ref['canvas_size']['h'] ?? 0);
        if ($workw > 0 && $workh > 0 && function_exists('imagescale')) {
            $scaled = @imagescale($cropped, $workw, $workh);
            if ($scaled) { imagedestroy($cropped); $cropped = $scaled; }
        }
        $tmpdir = $CFG->dataroot . '/local_aisgk/tmp/homeworkimg/' . $homeworkid;
        if (!is_dir($tmpdir)) { mkdir($tmpdir, $CFG->directorypermissions, true); }
        $safe = preg_replace('/[^a-zA-Z0-9_\-]+/', '_', $label) ?: 'img';
        $filename = $safe . '_' . substr(sha1(json_encode($ref)), 0, 12) . '.png';
        $tmpfile = $tmpdir . '/' . $filename;
        if ($inlineonly) {
            $previewdir = self::preview_img_dir($homeworkid);
            if (!is_dir($previewdir)) { mkdir($previewdir, $CFG->directorypermissions, true); }
            $previewfile = $previewdir . '/' . $filename;
            imagepng($cropped, $previewfile);
            imagedestroy($cropped);
            $url = new \moodle_url('/local/aisgk/previewimg.php', [
                'courseid' => $courseid,
                'homeworkid' => $homeworkid,
                'file' => $filename,
            ]);
            return '<span class="local-aisgk-img-wrap local-aisgk-img-preview"><img src="' . s($url->out(false)) . '" alt="' . s($label) . '" loading="lazy"></span>';
        }
        imagepng($cropped, $tmpfile);
        imagedestroy($cropped);
        return self::store_homework_img_file($tmpfile, $filename, $label, $courseid, $homeworkid);
    }


    protected static function materialize_generated_ref(array $ref, string $label, bool $inlineonly = false): string {
        $canvas = self::normalize_img_size_value($ref['canvas'] ?? $ref['canvas_size'] ?? ['w' => 1000, 'h' => 1000]);
        $w = max(1, (int)($canvas['w'] ?? 1000));
        $h = max(1, (int)($canvas['h'] ?? 1000));
        $generated = is_array($ref['generated'] ?? null) ? (array)$ref['generated'] : [];
        $fileurl = trim((string)($generated['fileurl'] ?? $generated['url'] ?? $ref['fileurl'] ?? ''));
        if ($fileurl !== '') {
            return '<span class="local-aisgk-img-wrap local-aisgk-img-preview local-aisgk-gen-wrap" data-gen-w="' . s((string)$w) . '" data-gen-h="' . s((string)$h) . '"><img src="' . s($fileurl) . '" alt="' . s($label) . '" loading="lazy"></span>';
        }
        $desc = trim((string)($ref['description'] ?? ''));
        $style = 'aspect-ratio:' . s((string)$w) . '/' . s((string)$h) . ';';
        $status = (string)($generated['status'] ?? '');
        $error = trim((string)($generated['error'] ?? ''));
        $body = $error !== '' ? ('Chưa sinh được ảnh: ' . $error) : ($desc !== '' ? $desc : 'Ảnh sẽ được tạo tự động ở bước sau.');
        $statusclass = $status === 'error' ? ' local-aisgk-gen-error' : '';
        return '<span class="local-aisgk-img-wrap local-aisgk-img-preview local-aisgk-gen-wrap' . $statusclass . '" data-gen-w="' . s((string)$w) . '" data-gen-h="' . s((string)$h) . '"><span class="local-aisgk-box-bg" style="' . $style . '"><span class="local-aisgk-box-title">' . s($label) . '</span><small>' . s($body) . '</small></span></span>';
    }

    protected static function preview_img_dir(int $homeworkid): string {
        global $CFG, $USER;
        $base = !empty($CFG->localcachedir) ? $CFG->localcachedir : ($CFG->dataroot . '/localcache');
        $userid = !empty($USER->id) ? (int)$USER->id : 0;
        return $base . '/local_aisgk/previewimg/u' . $userid . '/h' . max(0, $homeworkid);
    }

    protected static function image_create_from_file(string $src) {
        $ext = strtolower(pathinfo($src, PATHINFO_EXTENSION));
        if (($ext === 'jpg' || $ext === 'jpeg') && function_exists('imagecreatefromjpeg')) { return @imagecreatefromjpeg($src); }
        if ($ext === 'webp' && function_exists('imagecreatefromwebp')) { return @imagecreatefromwebp($src); }
        return @imagecreatefrompng($src);
    }


    protected static function store_homework_img_file(string $tmpfile, string $filename, string $label, int $courseid, int $homeworkid): string {
        if (!is_file($tmpfile) || filesize($tmpfile) < 1) { throw new \moodle_exception('errorprocessingbook', 'local_aisgk', '', 'Không lưu được ảnh crop.'); }
        $context = \context_course::instance($courseid);
        $fs = get_file_storage();
        $fileinfo = ['contextid' => $context->id, 'component' => 'local_aisgk', 'filearea' => 'homeworkimg', 'itemid' => $homeworkid, 'filepath' => '/', 'filename' => $filename];
        if ($old = $fs->get_file($context->id, 'local_aisgk', 'homeworkimg', $homeworkid, '/', $filename)) { $old->delete(); }
        $fs->create_file_from_pathname($fileinfo, $tmpfile);
        @unlink($tmpfile);
        $url = \moodle_url::make_pluginfile_url($context->id, 'local_aisgk', 'homeworkimg', $homeworkid, '/', $filename, false)->out(false);
        return '<span class="local-aisgk-img-wrap"><img src="' . s($url) . '" alt="' . s($label) . '" loading="lazy"></span>';
    }

    protected static function crop_homework_image(string $label, int $page, array $box, array &$pagemap, int $bookid, int $courseid, int $sectionid, int $homeworkid): string {
        global $CFG;
        if (empty($pagemap[$page]) || !is_file($pagemap[$page])) {
            $pdfpage = self::sgk_page_to_pdf_page($page);
            $rendered = sgk_processor::render_page_images_cached($bookid, $courseid, $sectionid, $pdfpage, $pdfpage, 180, null, true, 1000);
            if (!empty($rendered[0]) && is_file($rendered[0])) {
                $pagemap[$page] = $rendered[0];
            }
        }
        $src = $pagemap[$page] ?? '';
        if ($src === '' || !is_file($src)) {
            throw new \moodle_exception("errorprocessingbook", "local_aisgk", "", "Không tìm thấy ảnh trang SGK " . $page . " (PDF " . self::sgk_page_to_pdf_page($page) . ")");
        }
        $info = @getimagesize($src);
        if (!$info || empty($info[0]) || empty($info[1])) {
            throw new \moodle_exception('errorprocessingbook', 'local_aisgk', '', 'Ảnh trang không hợp lệ.');
        }
        $width = (int)$info[0];
        $height = (int)$info[1];
        // source_box chuẩn thống nhất: [xmin,ymin,xmax,ymax] trên hệ 0-1000.
        [$xmin, $ymin, $xmax, $ymax] = array_map('intval', $box);
        $left = max(0, min($width - 1, (int)floor($xmin * $width / 1000)));
        $top = max(0, min($height - 1, (int)floor($ymin * $height / 1000)));
        $right = max($left + 1, min($width, (int)ceil($xmax * $width / 1000)));
        $bottom = max($top + 1, min($height, (int)ceil($ymax * $height / 1000)));
        $cropw = $right - $left;
        $croph = $bottom - $top;
        if ($cropw < 5 || $croph < 5) {
            throw new \moodle_exception('errorprocessingbook', 'local_aisgk', '', 'BBox ảnh quá nhỏ.');
        }
        $ext = strtolower(pathinfo($src, PATHINFO_EXTENSION));
        if (($ext === 'jpg' || $ext === 'jpeg') && function_exists('imagecreatefromjpeg')) {
            $img = @imagecreatefromjpeg($src);
        } else if ($ext === 'webp' && function_exists('imagecreatefromwebp')) {
            $img = @imagecreatefromwebp($src);
        } else {
            $img = @imagecreatefrompng($src);
        }
        if (!$img) {
            throw new \moodle_exception('errorprocessingbook', 'local_aisgk', '', 'Không mở được ảnh trang để crop.');
        }
        $cropped = @imagecrop($img, ['x' => $left, 'y' => $top, 'width' => $cropw, 'height' => $croph]);
        imagedestroy($img);
        if (!$cropped) {
            throw new \moodle_exception('errorprocessingbook', 'local_aisgk', '', 'Không crop được ảnh.');
        }
        $tmpdir = $CFG->dataroot . '/local_aisgk/tmp/homeworkimg/' . $homeworkid;
        if (!is_dir($tmpdir)) {
            mkdir($tmpdir, $CFG->directorypermissions, true);
        }
        $safe = preg_replace('/[^a-zA-Z0-9_\-]+/', '_', $label) ?: 'img';
        $filename = $safe . '_p' . $page . '_' . substr(sha1(implode(',', $box)), 0, 10) . '.png';
        $tmpfile = $tmpdir . '/' . $filename;
        imagepng($cropped, $tmpfile);
        imagedestroy($cropped);
        return self::store_homework_img_file($tmpfile, $filename, $label, $courseid, $homeworkid);
    }
    protected static function extract_formulas(string $text): array {
        $lines = preg_split('/\R/u', $text) ?: [];
        $formula = [];
        foreach ($lines as $line) {
            $line = trim($line);
            if ($line === '') {
                continue;
            }
            if (preg_match('/[=+\-×x*\/²³√()]/u', $line) && preg_match('/\d/u', $line)) {
                $formula[] = $line;
            }
        }
        return array_values(array_slice(array_unique($formula), 0, 12));
    }

    protected static function generate_questions_from_images(string $topicname, array $images, int $pagefrom, int $pageto, int $userid = 0, array $options = [], string $bookname = ''): array {
        $ai = ai_service::generate_homework_questions_from_images($topicname, $images, $pagefrom, $pageto, $userid, $options, $bookname);
        if (empty($ai["questions"]) || !is_array($ai["questions"])) {
            if (!empty($ai["rawtext"]) || !empty($ai["parseerror"])) {
                // Vẫn trả dữ liệu về process_job để lưu raw vào draft/textarea cho debug.
                $ai["questions"] = [];
            } else {
                throw new \moodle_exception('errorprocessingbook', 'local_aisgk', '', 'AI không trả về danh sách câu hỏi hợp lệ.');
            }
        }
        self::$lastaiusage = [
            "model" => (string)($ai["model"] ?? ""),
            "tokens" => (int)($ai["tokens"] ?? 0),
            "keysource" => (string)($ai["keysource"] ?? "system"),
            "category" => (string)($ai["category"] ?? "free"),
            "remain_calls" => (int)($ai["usage"]["remain_calls"] ?? 0),
            "api" => ((string)($ai["category"] ?? "free") === "pay") ? "API trả phí" : "API miễn phí/hệ thống",
            "rawtext" => (string)($ai["rawtext"] ?? ""),
        ];
        return $ai;
    }

    protected static function pretty_ai_json(string $rawtext, array $questions): string {
        $json = json_decode(trim($rawtext), true);
        if (!is_array($json) && preg_match('/\{.*\}/s', $rawtext, $m)) {
            $json = json_decode($m[0], true);
        }
        if (!is_array($json)) {
            $json = ['questions' => $questions, 'raw' => $rawtext];
        }
        return json_encode($json, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
    }

    public static function questions_to_text(array $questions): string {
        $out = [];
        foreach ($questions as $index => $q) {
            $out[] = ($index + 1) . '. ' . trim((string)($q['questiontext'] ?? ''));
        }
        return implode("\n\n", $out);
    }

    public static function update_draft(int $homeworkid, string $teacheredited, int $scheduledtime): void {
        homework_repository::update($homeworkid, [
            'teacheredited' => $teacheredited,
            'scheduledtime' => $scheduledtime,
            'status' => 'scheduled',
            'timemodified' => time(),
        ]);
    }

    public static function approve(int $homeworkid): void {
        homework_repository::update($homeworkid, [
            'approvalstatus' => 'approved',
            'status' => 'approved',
            'timemodified' => time(),
        ]);
    }


    public static function approve_and_deliver(int $homeworkid, int $userid = 0): array {
        global $DB;
        $homework = homework_repository::get_by_id($homeworkid);
        if (!$homework) {
            throw new \moodle_exception('invalidparameter');
        }
        if ((int)($homework->cancelled ?? 0) !== 0) {
            throw new \moodle_exception('Không thể duyệt bản nháp đã bị hủy.');
        }
        if (!empty($homework->errormsg)) {
            throw new \moodle_exception('Không thể duyệt vì JSON chưa validate đạt: ' . $homework->errormsg);
        }
        $raw = trim((string)($homework->sourcetext ?: $homework->questiondata));
        if ($raw === '') {
            throw new \moodle_exception('Không thể duyệt vì chưa có JSON câu hỏi.');
        }
        $decoded = json_decode($raw, true);
        if (!is_array($decoded)) {
            throw new \moodle_exception('Không thể duyệt vì JSON không parse được: ' . json_last_error_msg());
        }
        // Nếu đã giao rồi thì không tạo module trùng.
        if ((int)($homework->moodlemoduleid ?? 0) > 0 || (string)($homework->status ?? '') === 'delivered') {
            self::approve($homeworkid);
            return ['message' => 'Bản nháp đã được duyệt trước đó; không tạo BTVN trùng.', 'moodlemoduleid' => (int)($homework->moodlemoduleid ?? 0)];
        }
        self::approve($homeworkid);
        $homework = homework_repository::get_by_id($homeworkid);
        self::deliver_one($homework);
        $homework = homework_repository::get_by_id($homeworkid);
        return ['message' => 'Đã duyệt và tạo BTVN trong Moodle.', 'moodlemoduleid' => (int)($homework->moodlemoduleid ?? 0), 'deliverymessage' => (string)($homework->deliverymessage ?? '')];
    }

    public static function cancel(int $homeworkid): void {
        homework_repository::update($homeworkid, [
            'cancelled' => 1,
            'status' => 'cancelled',
            'timemodified' => time(),
        ]);
    }

    public static function delete_bad_drafts(int $courseid, int $sectionid, string $topicname = ''): int {
        return homework_repository::delete_bad_drafts($courseid, $sectionid, $topicname);
    }

    public static function wipe_course_topic(int $courseid, int $sectionid, string $topicname = ''): array {
        $homeworks = homework_repository::delete_by_course_section_topic($courseid, $sectionid, $topicname);
        $questions = self::delete_moodle_question_bank_items($courseid, $topicname);
        return ['homeworks' => $homeworks, 'questions' => $questions];
    }

    protected static function delete_moodle_question_bank_items(int $courseid, string $topicname = ''): int {
        global $DB;
        $context = \context_course::instance($courseid);
        if (!$DB->get_manager()->table_exists('question_categories') || !$DB->get_manager()->table_exists('question')) {
            return 0;
        }
        $like = $topicname !== '' ? '%' . $DB->sql_like_escape($topicname) . '%' : '%AISGK%';
        $params = ['like1' => $like, 'like2' => $like];
        $catids = $DB->get_fieldset_select('question_categories', 'id', 'contextid = ?', [$context->id]);
        if (!$catids) {
            return 0;
        }
        list($catsql, $catparams) = $DB->get_in_or_equal($catids, SQL_PARAMS_NAMED, 'cat');
        $params = array_merge($params, $catparams);
        if ($DB->get_manager()->table_exists('question_versions') && $DB->get_manager()->table_exists('question_bank_entries')) {
            $sql = "SELECT q.id
                      FROM {question} q
                      JOIN {question_versions} qv ON qv.questionid = q.id
                      JOIN {question_bank_entries} qbe ON qbe.id = qv.questionbankentryid
                     WHERE qbe.questioncategoryid {$catsql}
                       AND (" . $DB->sql_like('q.name', ':like1', false) . " OR " . $DB->sql_like('q.questiontext', ':like2', false) . ")";
            $qids = $DB->get_fieldset_sql($sql, $params);
        } else {
            $where = "category {$catsql} AND (" . $DB->sql_like('name', ':like1', false) . " OR " . $DB->sql_like('questiontext', ':like2', false) . ")";
            $qids = $DB->get_fieldset_select('question', 'id', $where, $params);
        }
        if (!$qids) {
            return 0;
        }
        list($qsql, $qparams) = $DB->get_in_or_equal($qids, SQL_PARAMS_NAMED, 'qid');
        if ($DB->get_manager()->table_exists('question_versions')) {
            $entryids = $DB->get_fieldset_select('question_versions', 'questionbankentryid', 'questionid ' . $qsql, $qparams);
            $DB->delete_records_select('question_versions', 'questionid ' . $qsql, $qparams);
            if ($entryids && $DB->get_manager()->table_exists('question_bank_entries')) {
                $entryids = array_values(array_unique(array_map('intval', $entryids)));
                list($esql, $eparams) = $DB->get_in_or_equal($entryids, SQL_PARAMS_NAMED, 'entry');
                $DB->delete_records_select('question_bank_entries', 'id ' . $esql, $eparams);
            }
        }
        $DB->delete_records_select('question', 'id ' . $qsql, $qparams);
        return count($qids);
    }

    public static function deliver_due(): int {
        $count = 0;
        foreach (homework_repository::find_due_for_delivery(time()) as $homework) {
            self::deliver_one($homework);
            $count++;
        }
        return $count;
    }

    protected static function deliver_one(\stdClass $homework): void {
        global $CFG, $DB;
        require_once($CFG->dirroot . '/course/modlib.php');

        $course = get_course((int)$homework->courseid);
        $sectionrec = $DB->get_record('course_sections', ['id' => (int)$homework->sectionid, 'course' => (int)$homework->courseid], 'id,section', IGNORE_MISSING);
        $sectionnum = $sectionrec ? (int)$sectionrec->section : 0;

        $content = trim((string)$homework->teacheredited);
        // Persist child image crops only at real delivery time. Draft preview only shows labels.
        if (strpos($content, '[IMG ') !== false || $content === '') {
            $preview = self::materialize_homework_images((int)$homework->id, ['persist_images' => true]);
            if ($preview && !empty($preview->previewteacheredited)) {
                $content = (string)$preview->previewteacheredited;
            }
        }
        if ($content === '') {
            $content = trim((string)$homework->sourcetext);
        }
        if ($content === '') {
            $content = get_string('homeworkemptydraftfallback', 'local_aisgk');
        }

        $moduleid = 0;
        $deliverymessage = '';
        try {
            $assignmodule = $DB->get_record('modules', ['name' => 'assign']);
            if ($assignmodule) {
                $moduleinfo = (object)[
                    'course' => (int)$homework->courseid,
                    'section' => $sectionnum,
                    'module' => (int)$assignmodule->id,
                    'modulename' => 'assign',
                    'name' => 'BTVN - ' . $homework->topicname,
                    'intro' => format_text($content, FORMAT_HTML),
                    'introformat' => FORMAT_HTML,
                    'alwaysshowdescription' => 1,
                    'duedate' => max(time() + 3600, (int)$homework->scheduledtime + 86400),
                    'allowsubmissionsfromdate' => (int)$homework->scheduledtime,
                    'cutoffdate' => 0,
                    'gradingduedate' => 0,
                    'grade' => 100,
                    'submissiondrafts' => 0,
                    'sendnotifications' => 0,
                    'sendlatenotifications' => 0,
                    'sendstudentnotifications' => 0,
                    'assignsubmission_onlinetext_enabled' => 1,
                    'assignsubmission_file_enabled' => 0,
                    'visible' => 1,
                ];
                $cm = add_moduleinfo($moduleinfo, $course);
                $moduleid = (int)($cm->coursemodule ?? 0);
                $deliverymessage = 'assign';
            }
        } catch (\Throwable $e) {
            $deliverymessage = 'assign-fallback';
        }

        if (!$moduleid) {
            $labelmodule = $DB->get_record('modules', ['name' => 'label'], '*', MUST_EXIST);
            $moduleinfo = (object)[
                'course' => (int)$homework->courseid,
                'section' => $sectionnum,
                'module' => (int)$labelmodule->id,
                'modulename' => 'label',
                'name' => 'BTVN - ' . $homework->topicname,
                'intro' => format_text($content, FORMAT_HTML),
                'introformat' => FORMAT_HTML,
                'visible' => 1,
            ];
            $cm = add_moduleinfo($moduleinfo, $course);
            $moduleid = (int)($cm->coursemodule ?? 0);
            $deliverymessage = $deliverymessage ?: 'label';
        }

        homework_repository::update((int)$homework->id, [
            'status' => 'delivered',
            'approvalstatus' => $homework->approvalstatus === 'pending' ? 'autoapproved' : $homework->approvalstatus,
            'deliveredtime' => time(),
            'moodlemoduleid' => $moduleid,
            'deliverymessage' => $deliverymessage,
            'timemodified' => time(),
        ]);
    }
}
