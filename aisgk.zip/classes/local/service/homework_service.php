<?php
namespace local_aisgk\local\service;

defined('MOODLE_INTERNAL') || die();

use local_aisgk\book_repository;
use local_aisgk\homework_repository;
use local_aisgk\local\job_manager;
use local_aisgk\local\ocr_runner;
use local_aisgk\local\sgk_processor;
use local_aisgk\local\ai_service;
use local_aisgk\toc_repository;
use local_aisgk\ai_key_manager;

class homework_service {
    /**
     * The SGK page number shown in TOC/AI marker is the printed/book page.
     * In current SGK PDFs, the physical PDF page to render is printed page + 1.
     * Example: SGK page 6 => PDF page 7.
     */
    protected const SGK_TO_PDF_PAGE_OFFSET = 1;

    protected static $lastaiusage = [];
    public static function normalize_title(string $s): string {
        $s = \core_text::strtolower(trim($s));
        $s = preg_replace('/\s+/u', ' ', $s);
        $s = preg_replace('/^[\d\.\-\:]+\s*/u', '', $s);
        return trim($s);
    }

    public static function find_section_match(int $courseid, int $sectionid): ?array {
        global $DB;
        if ($sectionid < 1) {
            return null;
        }
        $sql = "SELECT t.*
                  FROM {local_aisgk_section_toc} m
                  JOIN {local_aisgk_book_toc} t ON t.id = m.tocid
                  JOIN {local_aisgk_books} b ON b.id = t.bookid
                 WHERE m.sectionid = ? AND b.courseid = ?";
        $toc = $DB->get_record_sql($sql, [$sectionid, $courseid]);
        if (!$toc) {
            return null;
        }
        $book = book_repository::get_by_id((int)$toc->bookid);
        if (!$book || (int)$book->courseid !== $courseid) {
            return null;
        }
        return ['book' => $book, 'toc' => $toc];
    }

    public static function find_topic_match(int $courseid, string $topicname): ?array {
        $target = self::normalize_title($topicname);
        if ($target === '') {
            return null;
        }
        foreach (book_repository::get_all_by_courseid($courseid) as $book) {
            $rows = toc_repository::get_by_bookid((int)$book->id);
            foreach ($rows as $row) {
                $name = self::normalize_title((string)$row->tenbai);
                if ($name === '') {
                    continue;
                }
                if ($name === $target || str_contains($target, $name) || str_contains($name, $target)) {
                    return ['book' => $book, 'toc' => $row];
                }
            }
        }
        return null;
    }

    protected static function homework_fingerprint(int $courseid, int $sectionid, string $topicname, int $bookid, int $pagefrom, int $pageto, array $options): string {
        $config = [
            'courseid' => $courseid,
            'sectionid' => $sectionid,
            'topic' => self::normalize_title($topicname),
            'bookid' => $bookid,
            'pagefrom' => $pagefrom,
            'pageto' => $pageto,
            'qtypes' => $options['qtypes'] ?? [],
            'cognitive' => $options['cognitive'] ?? [],
            'distractors' => $options['distractors'] ?? [],
        ];
        return sha1(json_encode($config, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES));
    }

    protected static function find_ready_draft_by_fingerprint(string $fingerprint): ?\stdClass {
        global $DB;
        if ($fingerprint === '' || !$DB->get_manager()->field_exists(new \xmldb_table('local_aisgk_homeworks'), new \xmldb_field('fingerprint'))) { return null; }
        $records = $DB->get_records_select('local_aisgk_homeworks', "fingerprint = ? AND status = 'draft_ready' AND cancelled = 0", [$fingerprint], 'id DESC', '*', 0, 1);
        return $records ? reset($records) : null;
    }
    public static function create_draft_job(int $userid, int $courseid, int $sectionid, string $topicname, int $bookid, int $pagefrom, int $pageto, int $scheduledtime, array $options = []): array {
        global $DB;
        $fingerprint = self::homework_fingerprint($courseid, $sectionid, $topicname, $bookid, $pagefrom, $pageto, $options);
        $resourcekey = 'course:' . $courseid . ':section:' . $sectionid . ':homework:' . $fingerprint;
        if ($existing = job_manager::find_active_by_fingerprint($fingerprint, 'createhomework')) {
            return ['jobid' => (int)$existing->id, 'reused' => true];
        }
        if ($existingdraft = self::find_ready_draft_by_fingerprint($fingerprint)) {
            $jobid = job_manager::create('createhomework', $userid, $resourcekey, [
                'homeworkid' => (int)$existingdraft->id,
                'reuseddraft' => true,
                'options' => $options,
            ], $fingerprint, 80, time(), 'manual');
            job_manager::mark_done($jobid, ['homeworkid' => (int)$existingdraft->id, 'reuseddraft' => true], 'Đã có bản nháp cùng cấu hình, không gọi AI lại.');
            return ['jobid' => $jobid, 'homeworkid' => (int)$existingdraft->id, 'reused' => true, 'draftreused' => true];
        }

        $now = time();
        $homeworkid = homework_repository::create([
            'courseid' => $courseid,
            'sectionid' => $sectionid,
            'topicname' => $topicname,
            'bookid' => $bookid,
            'pagefrom' => $pagefrom,
            'pageto' => $pageto,
            'status' => 'draft_generating',
            'approvalstatus' => 'pending',
            'scheduledtime' => $scheduledtime,
            'deliveredtime' => 0,
            'resourcekey' => $resourcekey,
            'fingerprint' => $fingerprint,
            'source' => 'manual',
            'sourcetext' => '',
            'sourceformula' => json_encode(['options' => $options], JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES),
            'questiondata' => '',
            'teacheredited' => '',
            'moodlemoduleid' => 0,
            'deliverymessage' => '',
            'errormsg' => '',
            'cancelled' => 0,
            'timecreated' => $now,
            'timemodified' => $now,
            'userid' => $userid,
        ]);

        $payload = [
            'homeworkid' => $homeworkid,
            'courseid' => $courseid,
            'sectionid' => $sectionid,
            'topicname' => $topicname,
            'bookid' => $bookid,
            'pagefrom' => $pagefrom,
            'pageto' => $pageto,
            'scheduledtime' => $scheduledtime,
            'fingerprint' => $fingerprint,
            'source' => 'manual',
            'options' => $options,
        ];
        $jobid = job_manager::create('createhomework', $userid, $resourcekey, $payload, $fingerprint, 80, time(), 'manual');
        $DB->update_record('local_aisgk_homeworks', (object)['id' => $homeworkid, 'jobid' => $jobid]);
        return ['jobid' => $jobid, 'homeworkid' => $homeworkid, 'reused' => false];
    }


    /**
     * Render [IMG:...] markers for preview only.
     * IMPORTANT: Do NOT overwrite questiondata/sourcetext with <img>.
     * The JSON/draft must keep [IMG:...] as the editable source of truth so images
     * can be re-cropped after cache/file cleanup or bbox edits.
     */
    public static function materialize_homework_images(int $homeworkid, array $options = []): ?\stdClass {
        $homework = homework_repository::get_by_id($homeworkid);
        if (!$homework) {
            return null;
        }

        $raws = [
            (string)($homework->questiondata ?? ''),
            (string)($homework->sourcetext ?? ''),
        ];
        $decoded = null;
        foreach ($raws as $raw) {
            if ($raw === '' || strpos($raw, '[IMG:') === false) {
                continue;
            }
            $try = json_decode($raw, true);
            if (is_array($try)) {
                $decoded = $try;
                break;
            }
        }
        if (!is_array($decoded)) {
            $homework->previewquestiondata = '';
            $homework->previewteacheredited = '';
            return $homework;
        }

        $questions = $decoded['questions'] ?? $decoded;
        if (!is_array($questions)) {
            $homework->previewquestiondata = '';
            $homework->previewteacheredited = '';
            return $homework;
        }

        $questions = ai_service::normalize_homework_questions(array_values($questions), $options);
        $previewquestions = self::materialize_image_refs($questions, [], (int)$homework->pagefrom, (int)$homework->pageto,
            (int)$homework->bookid, (int)$homework->courseid, (int)$homework->sectionid, $homeworkid);

        $homework->previewquestiondata = json_encode($previewquestions, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
        $homework->previewteacheredited = self::questions_to_text($previewquestions);
        return $homework;
    }
    public static function process_job(\stdClass $job): void {
        global $DB;
        $payload = json_decode((string)$job->payloadjson, true) ?: [];
        $homeworkid = (int)($payload['homeworkid'] ?? 0);
        $homework = homework_repository::get_by_id($homeworkid);
        if (!$homework) {
            throw new \moodle_exception('invalidparameter');
        }

        job_manager::update_progress((int)$job->id, 1, 'start', get_string('stepstart', 'local_aisgk'), 5, get_string('homeworkjobstarting', 'local_aisgk'));

        $bookid = (int)$homework->bookid;
        $pagefrom = max(1, (int)$homework->pagefrom);
        $pageto = max($pagefrom, (int)$homework->pageto);

        job_manager::update_progress((int)$job->id, 2, 'render', get_string('stepscanlesson', 'local_aisgk'), 12,
            'Đang render trang SGK thành ảnh để gửi AI...');
        $book = book_repository::get_by_id($bookid);
        $renderfrom = self::sgk_page_to_pdf_page($pagefrom);
        $renderto = self::sgk_page_to_pdf_page($pageto);
        $images = sgk_processor::render_page_images_cached($bookid, (int)$book->courseid, (int)$homework->sectionid,
            $renderfrom, $renderto, 180, static function(int $done, int $total) use ($job): void {
                $percent = 12 + (int)floor(($done / max(1, $total)) * 28);
                job_manager::update_progress((int)$job->id, 2, 'render', 'Render/cache ảnh trang SGK', $percent,
                    'Đang chuẩn bị ảnh trang SGK... (' . $done . '/' . $total . ')');
            });
        if (!$images) {
            throw new \moodle_exception('bookimagesmissing', 'local_aisgk');
        }

        job_manager::update_progress((int)$job->id, 3, 'generate', get_string('stepcreatehomework', 'local_aisgk'), 55,
            'Đang gửi ảnh trang SGK ' . $pagefrom . '–' . $pageto . ' (PDF ' . $renderfrom . '–' . $renderto . ') cho AI để tạo câu hỏi...');
        $bookname = $book ? (string)($book->name ?: $book->filename) : '';
        $ai = self::generate_questions_from_images($homework->topicname, $images, $pagefrom, $pageto, (int)$job->userid,
            (array)($payload["options"] ?? []), $bookname);
        $questions = (array)($ai['questions'] ?? []);
        $options = (array)($payload['options'] ?? []);
        // Auto job: cho phép validator tự cân lại level nếu AI lệch nhẹ. Luồng JSON thủ công không bật cờ này.
        $options['auto_fix_level'] = true;
        // Keep [IMG:...] markers in saved JSON. Render/crop images only for preview/delivery.
        $parseerror = trim((string)($ai['parseerror'] ?? ''));
        if ($parseerror !== '') {
            $report = [
                'ok' => false,
                'errors' => ['Không phân tích được JSON bài tập AI trả về: ' . $parseerror],
                'summary' => ['qtypes' => [], 'levels' => []],
            ];
        } else {
            $report = ai_service::validate_homework_against_plan($questions, $options);
            if (!empty($report['fixed_questions']) && is_array($report['fixed_questions'])) {
                $questions = $report['fixed_questions'];
            }
        }

        // Phase debug: KHÔNG chặn khi validator báo lỗi. Luôn lưu raw AI + JSON đã normalize
        // để giáo viên thấy kết quả thật và mình có dữ liệu chỉnh prompt/schema/validator.
        if (!empty($ai['model'])) {
            ai_key_manager::mark_model_quality(
                (string)($ai['keytable'] ?? ''),
                (int)($ai['keyid'] ?? 0),
                (string)($ai['model'] ?? ''),
                'homework',
                !empty($report['ok'])
            );
        }
        $debugjson = [
            'questions' => array_values($questions),
            '_debug' => [
                'raw_ai_text' => (string)($ai['rawtext'] ?? ''),
                'normalizedjson' => (string)($ai['normalizedjson'] ?? ai_service::questions_json($questions)),
                'parse_error' => $parseerror,
                'report' => $report,
            ],
        ];
        $rawjson = json_encode($debugjson, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
        if ($rawjson === false) {
            $rawjson = ai_service::questions_json($questions);
        }
        $questiontext = self::questions_to_text($questions);
        $usage = self::$lastaiusage;
        $errormsg = $report['ok'] ? '' : implode(' | ', $report['errors']);

        homework_repository::update($homeworkid, [
            'status' => 'draft_ready',
            'sourcetext' => $rawjson,
            'sourceformula' => json_encode(['options' => $options, 'report' => $report], JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES),
            'questiondata' => json_encode($questions, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES),
            'teacheredited' => $questiontext,
            'errormsg' => $errormsg,
            'timemodified' => time(),
        ]);

        job_manager::update_progress((int)$job->id, 3, 'done', get_string('stepdone', 'local_aisgk'), 95, get_string('homeworkjobdraftready', 'local_aisgk'));
        job_manager::mark_done((int)$job->id, [
            'homeworkid' => $homeworkid,
            'questioncount' => count($questions),
            'usage' => $usage,
            'report' => $report,
            'hasvalidationerrors' => !$report['ok'],
        ], get_string('homeworkjobresult', 'local_aisgk', count($questions)));
    }

    protected static function sgk_page_to_pdf_page(int $sgkpage): int {
        return max(1, $sgkpage + self::SGK_TO_PDF_PAGE_OFFSET);
    }

    protected static function materialize_image_refs(array $questions, array $images, int $pagefrom, int $pageto, int $bookid, int $courseid, int $sectionid, int $homeworkid): array {
        $pagemap = [];
        foreach (array_values($images) as $i => $path) {
            $pagemap[$pagefrom + $i] = $path;
        }
        $cache = [];
        foreach ($questions as $idx => $q) {
            if (!is_array($q)) {
                continue;
            }
            $replace = function(string $text) use (&$cache, &$pagemap, $bookid, $courseid, $sectionid, $homeworkid): string {
                return self::replace_img_markers($text, $cache, $pagemap, $bookid, $courseid, $sectionid, $homeworkid);
            };
            if (isset($q['questiontext'])) {
                $q['questiontext'] = $replace((string)$q['questiontext']);
            }
            if (!empty($q['subquestions']) && is_array($q['subquestions'])) {
                foreach ($q['subquestions'] as $si => $sq) {
                    if (!is_array($sq)) {
                        continue;
                    }
                    if (isset($sq['question'])) {
                        $sq['question'] = $replace((string)$sq['question']);
                    }
                    if (isset($sq['answer'])) {
                        $sq['answer'] = $replace((string)$sq['answer']);
                    }
                    $q['subquestions'][$si] = $sq;
                }
            }
            if (!empty($q['choices']) && is_array($q['choices'])) {
                foreach ($q['choices'] as $ci => $choice) {
                    if (is_array($choice) && isset($choice['text'])) {
                        $choice['text'] = $replace((string)$choice['text']);
                        $q['choices'][$ci] = $choice;
                    }
                }
            }
            if (!empty($q['answers']) && is_array($q['answers'])) {
                foreach ($q['answers'] as $ai => $answer) {
                    if (is_array($answer) && isset($answer['text'])) {
                        $answer['text'] = $replace((string)$answer['text']);
                        $q['answers'][$ai] = $answer;
                    }
                }
            }
            $questions[$idx] = $q;
        }
        return $questions;
    }

    protected static function replace_img_markers(string $text, array &$cache, array &$pagemap, int $bookid, int $courseid, int $sectionid, int $homeworkid): string {
        if ($text === '' || strpos($text, '[IMG:') === false) {
            return $text;
        }
        $re = '/\[IMG:([^|\]]+)\|(\d+)\|(\d{1,4}),(\d{1,4}),(\d{1,4}),(\d{1,4})\]/u';
        return preg_replace_callback($re, function(array $m) use (&$cache, &$pagemap, $bookid, $courseid, $sectionid, $homeworkid): string {
            $label = trim((string)$m[1]);
            $page = (int)$m[2];
            $box = [(int)$m[3], (int)$m[4], (int)$m[5], (int)$m[6]];
            $key = $label . '|' . $page . '|' . implode(',', $box);
            if (!array_key_exists($key, $cache)) {
                try {
                    $cache[$key] = self::crop_homework_image($label, $page, $box, $pagemap, $bookid, $courseid, $sectionid, $homeworkid);
                } catch (\Throwable $e) {
                    $cache[$key] = '<span class="local-aisgk-img-error" title="' . s($e->getMessage()) . '">[IMG lỗi: ' . s($label) . ']</span>';
                }
            }
            return $cache[$key];
        }, $text) ?? $text;
    }

    protected static function crop_homework_image(string $label, int $page, array $box, array &$pagemap, int $bookid, int $courseid, int $sectionid, int $homeworkid): string {
        global $CFG;
        if (empty($pagemap[$page]) || !is_file($pagemap[$page])) {
            $pdfpage = self::sgk_page_to_pdf_page($page);
            $rendered = sgk_processor::render_page_images_cached($bookid, $courseid, $sectionid, $pdfpage, $pdfpage, 180);
            if (!empty($rendered[0]) && is_file($rendered[0])) {
                $pagemap[$page] = $rendered[0];
            }
        }
        $src = $pagemap[$page] ?? '';
        if ($src === '' || !is_file($src)) {
            throw new \moodle_exception("errorprocessingbook", "local_aisgk", "", "Không tìm thấy ảnh trang SGK " . $page . " (PDF " . self::sgk_page_to_pdf_page($page) . ")");
        }
        $info = @getimagesize($src);
        if (!$info || empty($info[0]) || empty($info[1])) {
            throw new \moodle_exception('errorprocessingbook', 'local_aisgk', '', 'Ảnh trang không hợp lệ.');
        }
        $width = (int)$info[0];
        $height = (int)$info[1];
        [$ymin, $xmin, $ymax, $xmax] = array_map('intval', $box);
        $left = max(0, min($width - 1, (int)floor($xmin * $width / 1000)));
        $top = max(0, min($height - 1, (int)floor($ymin * $height / 1000)));
        $right = max($left + 1, min($width, (int)ceil($xmax * $width / 1000)));
        $bottom = max($top + 1, min($height, (int)ceil($ymax * $height / 1000)));
        $cropw = $right - $left;
        $croph = $bottom - $top;
        if ($cropw < 5 || $croph < 5) {
            throw new \moodle_exception('errorprocessingbook', 'local_aisgk', '', 'BBox ảnh quá nhỏ.');
        }
        $ext = strtolower(pathinfo($src, PATHINFO_EXTENSION));
        if (($ext === 'jpg' || $ext === 'jpeg') && function_exists('imagecreatefromjpeg')) {
            $img = @imagecreatefromjpeg($src);
        } else if ($ext === 'webp' && function_exists('imagecreatefromwebp')) {
            $img = @imagecreatefromwebp($src);
        } else {
            $img = @imagecreatefrompng($src);
        }
        if (!$img) {
            throw new \moodle_exception('errorprocessingbook', 'local_aisgk', '', 'Không mở được ảnh trang để crop.');
        }
        $cropped = @imagecrop($img, ['x' => $left, 'y' => $top, 'width' => $cropw, 'height' => $croph]);
        imagedestroy($img);
        if (!$cropped) {
            throw new \moodle_exception('errorprocessingbook', 'local_aisgk', '', 'Không crop được ảnh.');
        }
        $tmpdir = $CFG->dataroot . '/local_aisgk/tmp/homeworkimg/' . $homeworkid;
        if (!is_dir($tmpdir)) {
            mkdir($tmpdir, $CFG->directorypermissions, true);
        }
        $safe = preg_replace('/[^a-zA-Z0-9_\-]+/', '_', $label) ?: 'img';
        $filename = $safe . '_p' . $page . '_' . substr(sha1(implode(',', $box)), 0, 10) . '.png';
        $tmpfile = $tmpdir . '/' . $filename;
        imagepng($cropped, $tmpfile);
        imagedestroy($cropped);
        if (!is_file($tmpfile) || filesize($tmpfile) < 1) {
            throw new \moodle_exception('errorprocessingbook', 'local_aisgk', '', 'Không lưu được ảnh crop.');
        }
        $context = \context_course::instance($courseid);
        $fs = get_file_storage();
        $fileinfo = [
            'contextid' => $context->id,
            'component' => 'local_aisgk',
            'filearea' => 'homeworkimg',
            'itemid' => $homeworkid,
            'filepath' => '/',
            'filename' => $filename,
        ];
        if ($old = $fs->get_file($context->id, 'local_aisgk', 'homeworkimg', $homeworkid, '/', $filename)) {
            $old->delete();
        }
        $fs->create_file_from_pathname($fileinfo, $tmpfile);
        @unlink($tmpfile);
        $url = \moodle_url::make_pluginfile_url($context->id, 'local_aisgk', 'homeworkimg', $homeworkid, '/', $filename, false)->out(false);
        return '<span class="local-aisgk-img-wrap"><img src="' . s($url) . '" alt="' . s($label) . '" loading="lazy"></span>';
    }
    protected static function extract_formulas(string $text): array {
        $lines = preg_split('/\R/u', $text) ?: [];
        $formula = [];
        foreach ($lines as $line) {
            $line = trim($line);
            if ($line === '') {
                continue;
            }
            if (preg_match('/[=+\-×x*\/²³√()]/u', $line) && preg_match('/\d/u', $line)) {
                $formula[] = $line;
            }
        }
        return array_values(array_slice(array_unique($formula), 0, 12));
    }

    protected static function generate_questions_from_images(string $topicname, array $images, int $pagefrom, int $pageto, int $userid = 0, array $options = [], string $bookname = ''): array {
        $ai = ai_service::generate_homework_questions_from_images($topicname, $images, $pagefrom, $pageto, $userid, $options, $bookname);
        if (empty($ai["questions"]) || !is_array($ai["questions"])) {
            if (!empty($ai["rawtext"]) || !empty($ai["parseerror"])) {
                // Vẫn trả dữ liệu về process_job để lưu raw vào draft/textarea cho debug.
                $ai["questions"] = [];
            } else {
                throw new \moodle_exception('errorprocessingbook', 'local_aisgk', '', 'AI không trả về danh sách câu hỏi hợp lệ.');
            }
        }
        self::$lastaiusage = [
            "model" => (string)($ai["model"] ?? ""),
            "tokens" => (int)($ai["tokens"] ?? 0),
            "keysource" => (string)($ai["keysource"] ?? "system"),
            "keytable" => (string)($ai["keytable"] ?? ""),
            "keyid" => (int)($ai["keyid"] ?? 0),
            "category" => (string)($ai["category"] ?? "free"),
            "remain_calls" => (int)($ai["usage"]["remain_calls"] ?? 0),
            "api" => ((string)($ai["category"] ?? "free") === "pay") ? "API trả phí" : "API miễn phí/hệ thống",
            "rawtext" => (string)($ai["rawtext"] ?? ""),
        ];
        return $ai;
    }

    protected static function pretty_ai_json(string $rawtext, array $questions): string {
        $json = json_decode(trim($rawtext), true);
        if (!is_array($json) && preg_match('/\{.*\}/s', $rawtext, $m)) {
            $json = json_decode($m[0], true);
        }
        if (!is_array($json)) {
            $json = ['questions' => $questions, 'raw' => $rawtext];
        }
        return json_encode($json, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
    }

    public static function questions_to_text(array $questions): string {
        $out = [];
        foreach ($questions as $index => $q) {
            $out[] = ($index + 1) . '. ' . trim((string)($q['questiontext'] ?? ''));
        }
        return implode("\n\n", $out);
    }

    public static function update_draft(int $homeworkid, string $teacheredited, int $scheduledtime): void {
        homework_repository::update($homeworkid, [
            'teacheredited' => $teacheredited,
            'scheduledtime' => $scheduledtime,
            'status' => 'scheduled',
            'timemodified' => time(),
        ]);
    }

    public static function approve(int $homeworkid): void {
        homework_repository::update($homeworkid, [
            'approvalstatus' => 'approved',
            'status' => 'approved',
            'timemodified' => time(),
        ]);
    }

    public static function cancel(int $homeworkid): void {
        homework_repository::update($homeworkid, [
            'cancelled' => 1,
            'status' => 'cancelled',
            'timemodified' => time(),
        ]);
    }

    public static function delete_bad_drafts(int $courseid, int $sectionid, string $topicname = ''): int {
        return homework_repository::delete_bad_drafts($courseid, $sectionid, $topicname);
    }

    public static function wipe_course_topic(int $courseid, int $sectionid, string $topicname = ''): array {
        $homeworks = homework_repository::delete_by_course_section_topic($courseid, $sectionid, $topicname);
        $questions = self::delete_moodle_question_bank_items($courseid, $topicname);
        return ['homeworks' => $homeworks, 'questions' => $questions];
    }

    protected static function delete_moodle_question_bank_items(int $courseid, string $topicname = ''): int {
        global $DB;
        $context = \context_course::instance($courseid);
        if (!$DB->get_manager()->table_exists('question_categories') || !$DB->get_manager()->table_exists('question')) {
            return 0;
        }
        $like = $topicname !== '' ? '%' . $DB->sql_like_escape($topicname) . '%' : '%AISGK%';
        $params = ['like1' => $like, 'like2' => $like];
        $catids = $DB->get_fieldset_select('question_categories', 'id', 'contextid = ?', [$context->id]);
        if (!$catids) {
            return 0;
        }
        list($catsql, $catparams) = $DB->get_in_or_equal($catids, SQL_PARAMS_NAMED, 'cat');
        $params = array_merge($params, $catparams);
        if ($DB->get_manager()->table_exists('question_versions') && $DB->get_manager()->table_exists('question_bank_entries')) {
            $sql = "SELECT q.id
                      FROM {question} q
                      JOIN {question_versions} qv ON qv.questionid = q.id
                      JOIN {question_bank_entries} qbe ON qbe.id = qv.questionbankentryid
                     WHERE qbe.questioncategoryid {$catsql}
                       AND (" . $DB->sql_like('q.name', ':like1', false) . " OR " . $DB->sql_like('q.questiontext', ':like2', false) . ")";
            $qids = $DB->get_fieldset_sql($sql, $params);
        } else {
            $where = "category {$catsql} AND (" . $DB->sql_like('name', ':like1', false) . " OR " . $DB->sql_like('questiontext', ':like2', false) . ")";
            $qids = $DB->get_fieldset_select('question', 'id', $where, $params);
        }
        if (!$qids) {
            return 0;
        }
        list($qsql, $qparams) = $DB->get_in_or_equal($qids, SQL_PARAMS_NAMED, 'qid');
        if ($DB->get_manager()->table_exists('question_versions')) {
            $entryids = $DB->get_fieldset_select('question_versions', 'questionbankentryid', 'questionid ' . $qsql, $qparams);
            $DB->delete_records_select('question_versions', 'questionid ' . $qsql, $qparams);
            if ($entryids && $DB->get_manager()->table_exists('question_bank_entries')) {
                $entryids = array_values(array_unique(array_map('intval', $entryids)));
                list($esql, $eparams) = $DB->get_in_or_equal($entryids, SQL_PARAMS_NAMED, 'entry');
                $DB->delete_records_select('question_bank_entries', 'id ' . $esql, $eparams);
            }
        }
        $DB->delete_records_select('question', 'id ' . $qsql, $qparams);
        return count($qids);
    }

    public static function deliver_due(): int {
        $count = 0;
        foreach (homework_repository::find_due_for_delivery(time()) as $homework) {
            self::deliver_one($homework);
            $count++;
        }
        return $count;
    }

    protected static function deliver_one(\stdClass $homework): void {
        global $CFG, $DB;
        require_once($CFG->dirroot . '/course/modlib.php');

        $course = get_course((int)$homework->courseid);
        $modinfo = get_fast_modinfo($course);
        $sectioninfo = $modinfo->get_section_info_by_id((int)$homework->sectionid);
        $sectionnum = $sectioninfo ? (int)$sectioninfo->section : 0;

        $content = trim((string)$homework->teacheredited);
        if ($content === '') {
            $content = trim((string)$homework->sourcetext);
        }
        if ($content === '') {
            $content = get_string('homeworkemptydraftfallback', 'local_aisgk');
        }

        $moduleid = 0;
        $deliverymessage = '';
        try {
            $assignmodule = $DB->get_record('modules', ['name' => 'assign']);
            if ($assignmodule) {
                $moduleinfo = (object)[
                    'course' => (int)$homework->courseid,
                    'section' => $sectionnum,
                    'module' => (int)$assignmodule->id,
                    'modulename' => 'assign',
                    'name' => 'BTVN - ' . $homework->topicname,
                    'intro' => format_text($content, FORMAT_HTML),
                    'introformat' => FORMAT_HTML,
                    'alwaysshowdescription' => 1,
                    'duedate' => max(time() + 3600, (int)$homework->scheduledtime + 86400),
                    'allowsubmissionsfromdate' => (int)$homework->scheduledtime,
                    'cutoffdate' => 0,
                    'gradingduedate' => 0,
                    'grade' => 100,
                    'submissiondrafts' => 0,
                    'sendnotifications' => 0,
                    'sendlatenotifications' => 0,
                    'sendstudentnotifications' => 0,
                    'assignsubmission_onlinetext_enabled' => 1,
                    'assignsubmission_file_enabled' => 0,
                    'visible' => 1,
                ];
                $cm = add_moduleinfo($moduleinfo, $course);
                $moduleid = (int)($cm->coursemodule ?? 0);
                $deliverymessage = 'assign';
            }
        } catch (\Throwable $e) {
            $deliverymessage = 'assign-fallback';
        }

        if (!$moduleid) {
            $labelmodule = $DB->get_record('modules', ['name' => 'label'], '*', MUST_EXIST);
            $moduleinfo = (object)[
                'course' => (int)$homework->courseid,
                'section' => $sectionnum,
                'module' => (int)$labelmodule->id,
                'modulename' => 'label',
                'name' => 'BTVN - ' . $homework->topicname,
                'intro' => format_text($content, FORMAT_HTML),
                'introformat' => FORMAT_HTML,
                'visible' => 1,
            ];
            $cm = add_moduleinfo($moduleinfo, $course);
            $moduleid = (int)($cm->coursemodule ?? 0);
            $deliverymessage = $deliverymessage ?: 'label';
        }

        homework_repository::update((int)$homework->id, [
            'status' => 'delivered',
            'approvalstatus' => $homework->approvalstatus === 'pending' ? 'autoapproved' : $homework->approvalstatus,
            'deliveredtime' => time(),
            'moodlemoduleid' => $moduleid,
            'deliverymessage' => $deliverymessage,
            'timemodified' => time(),
        ]);
    }
}
