<?php
namespace local_aisgk\local\service;

defined('MOODLE_INTERNAL') || die();

use local_aisgk\book_repository;
use local_aisgk\homework_repository;
use local_aisgk\local\job_manager;
use local_aisgk\local\ocr_runner;
use local_aisgk\local\sgk_processor;
use local_aisgk\local\ai_service;
use local_aisgk\toc_repository;

class homework_service {
    protected static $lastaiusage = [];
    public static function normalize_title(string $s): string {
        $s = \core_text::strtolower(trim($s));
        $s = preg_replace('/\s+/u', ' ', $s);
        $s = preg_replace('/^[\d\.\-\:]+\s*/u', '', $s);
        return trim($s);
    }

    public static function find_section_match(int $courseid, int $sectionid): ?array {
        global $DB;
        if ($sectionid < 1) {
            return null;
        }
        $sql = "SELECT t.*
                  FROM {local_aisgk_section_toc} m
                  JOIN {local_aisgk_book_toc} t ON t.id = m.tocid
                  JOIN {local_aisgk_books} b ON b.id = t.bookid
                 WHERE m.sectionid = ? AND b.courseid = ?";
        $toc = $DB->get_record_sql($sql, [$sectionid, $courseid]);
        if (!$toc) {
            return null;
        }
        $book = book_repository::get_by_id((int)$toc->bookid);
        if (!$book || (int)$book->courseid !== $courseid) {
            return null;
        }
        return ['book' => $book, 'toc' => $toc];
    }

    public static function find_topic_match(int $courseid, string $topicname): ?array {
        $target = self::normalize_title($topicname);
        if ($target === '') {
            return null;
        }
        foreach (book_repository::get_all_by_courseid($courseid) as $book) {
            $rows = toc_repository::get_by_bookid((int)$book->id);
            foreach ($rows as $row) {
                $name = self::normalize_title((string)$row->tenbai);
                if ($name === '') {
                    continue;
                }
                if ($name === $target || str_contains($target, $name) || str_contains($name, $target)) {
                    return ['book' => $book, 'toc' => $row];
                }
            }
        }
        return null;
    }

    public static function create_draft_job(int $userid, int $courseid, int $sectionid, string $topicname, int $bookid, int $pagefrom, int $pageto, int $scheduledtime, array $options = []): array {
        global $DB;
        $resourcekey = 'course:' . $courseid . ':section:' . $sectionid . ':homework';
        if ($existing = job_manager::find_active_by_resource($resourcekey, 'createhomework')) {
            return ['jobid' => (int)$existing->id, 'reused' => true];
        }

        $now = time();
        $homeworkid = homework_repository::create([
            'courseid' => $courseid,
            'sectionid' => $sectionid,
            'topicname' => $topicname,
            'bookid' => $bookid,
            'pagefrom' => $pagefrom,
            'pageto' => $pageto,
            'status' => 'draft_generating',
            'approvalstatus' => 'pending',
            'scheduledtime' => $scheduledtime,
            'deliveredtime' => 0,
            'resourcekey' => $resourcekey,
            'sourcetext' => '',
            'sourceformula' => '',
            'questiondata' => '',
            'teacheredited' => '',
            'moodlemoduleid' => 0,
            'deliverymessage' => '',
            'errormsg' => '',
            'cancelled' => 0,
            'timecreated' => $now,
            'timemodified' => $now,
            'userid' => $userid,
        ]);

        $payload = [
            'homeworkid' => $homeworkid,
            'courseid' => $courseid,
            'sectionid' => $sectionid,
            'topicname' => $topicname,
            'bookid' => $bookid,
            'pagefrom' => $pagefrom,
            'pageto' => $pageto,
            'scheduledtime' => $scheduledtime,
                    'options' => $options,
        ];
        $jobid = job_manager::create('createhomework', $userid, $resourcekey, $payload);
        $DB->update_record('local_aisgk_homeworks', (object)['id' => $homeworkid, 'jobid' => $jobid]);
        return ['jobid' => $jobid, 'homeworkid' => $homeworkid, 'reused' => false];
    }

    public static function process_job(\stdClass $job): void {
        global $DB;
        $payload = json_decode((string)$job->payloadjson, true) ?: [];
        $homeworkid = (int)($payload['homeworkid'] ?? 0);
        $homework = homework_repository::get_by_id($homeworkid);
        if (!$homework) {
            throw new \moodle_exception('invalidparameter');
        }

        job_manager::update_progress((int)$job->id, 1, 'start', get_string('stepstart', 'local_aisgk'), 5, get_string('homeworkjobstarting', 'local_aisgk'));

        $bookid = (int)$homework->bookid;
        $pagefrom = max(1, (int)$homework->pagefrom);
        $pageto = max($pagefrom, (int)$homework->pageto);

        job_manager::update_progress((int)$job->id, 2, 'scan', get_string('stepscanlesson', 'local_aisgk'), 12, get_string('homeworkjobrendering', 'local_aisgk'));
        $book = book_repository::get_by_id($bookid);
        sgk_processor::render_toc_images($bookid, $pagefrom, $pageto, 180);
        $images = sgk_processor::get_source_images((int)$book->courseid, $bookid);
        if (!$images) {
            throw new \moodle_exception('bookimagesmissing', 'local_aisgk');
        }

        $texts = [];
        $total = count($images);
        foreach ($images as $index => $image) {
            $percent = 15 + (int)floor((($index + 1) / max(1, $total)) * 55);
            job_manager::update_progress((int)$job->id, 2, 'scan', get_string('stepscanlesson', 'local_aisgk'), $percent,
                get_string('homeworkjobscanningpage', 'local_aisgk', ['current' => $index + 1, 'total' => $total]));
            $texts = array_merge($texts, ocr_runner::ocr_images([$image], 1, 50, 6));
        }
        $sourcetext = trim(implode("\n\n", array_filter($texts)));
        $formula = self::extract_formulas($sourcetext);

        homework_repository::update($homeworkid, [
            'sourcetext' => $sourcetext,
            'sourceformula' => json_encode($formula, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES),
            'timemodified' => time(),
        ]);

        job_manager::update_progress((int)$job->id, 3, 'generate', get_string('stepcreatehomework', 'local_aisgk'), 82, get_string('homeworkjobgenerating', 'local_aisgk'));
        $questions = self::generate_questions($homework->topicname, $sourcetext, $formula, (int)$job->userid, (array)($payload["options"] ?? []));
        $questiontext = self::questions_to_text($questions);
        $usage = self::$lastaiusage;

        homework_repository::update($homeworkid, [
            'status' => 'draft_ready',
            'questiondata' => json_encode($questions, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES),
            'teacheredited' => $questiontext,
            'timemodified' => time(),
        ]);

        job_manager::update_progress((int)$job->id, 3, 'done', get_string('stepdone', 'local_aisgk'), 95, get_string('homeworkjobdraftready', 'local_aisgk'));
        job_manager::mark_done((int)$job->id, [
            'homeworkid' => $homeworkid,
            'questioncount' => count($questions),
            'usage' => $usage,
        ], get_string('homeworkjobresult', 'local_aisgk', count($questions)));
    }

    protected static function extract_formulas(string $text): array {
        $lines = preg_split('/\R/u', $text) ?: [];
        $formula = [];
        foreach ($lines as $line) {
            $line = trim($line);
            if ($line === '') {
                continue;
            }
            if (preg_match('/[=+\-×x*\/²³√()]/u', $line) && preg_match('/\d/u', $line)) {
                $formula[] = $line;
            }
        }
        return array_values(array_slice(array_unique($formula), 0, 12));
    }

    protected static function generate_questions(string $topicname, string $text, array $formula, int $userid = 0, array $options = []): array {
        try {
            $ai = ai_service::generate_homework_questions($topicname, $text, $formula, $userid, $options);
            if (!empty($ai["questions"]) && is_array($ai["questions"])) {
                self::$lastaiusage = [
                    "model" => (string)($ai["model"] ?? ""),
                    "tokens" => (int)($ai["tokens"] ?? 0),
                    "keysource" => (string)($ai["keysource"] ?? "system"),
                    "category" => (string)($ai["category"] ?? "free"),
                    "remain_calls" => (int)($ai["usage"]["remain_calls"] ?? 0),
                ];
                return $ai["questions"];
            }
        } catch (\Throwable $e) {
            debugging("AISGK AI homework fallback: " . $e->getMessage(), DEBUG_DEVELOPER);
        }
        self::$lastaiusage = [];
        $questions = [];
        $clean = preg_replace('/\s+/u', ' ', trim($text));
        $sentences = preg_split('/(?<=[\.\!\?])\s+/u', $clean) ?: [];
        $sentences = array_values(array_filter(array_map('trim', $sentences)));
        $chunks = array_slice($sentences, 0, 4);
        foreach ($chunks as $i => $sentence) {
            $questions[] = [
                'type' => 'shortanswer',
                'name' => 'Câu ' . ($i + 1),
                'questiontext' => 'Dựa vào bài "' . $topicname . '", hãy trình bày ngắn gọn: ' . $sentence,
            ];
        }
        if ($formula) {
            $questions[] = [
                'type' => 'shortanswer',
                'name' => 'Câu ' . (count($questions) + 1),
                'questiontext' => 'Giải thích ý nghĩa hoặc cách sử dụng công thức sau trong bài học: ' . $formula[0],
            ];
        }
        $questions[] = [
            'type' => 'essay',
            'name' => 'Câu ' . (count($questions) + 1),
            'questiontext' => 'Từ nội dung bài "' . $topicname . '", em hãy nêu kiến thức trọng tâm và cho một ví dụ minh họa.',
        ];
        return array_slice($questions, 0, 8);
    }

    public static function questions_to_text(array $questions): string {
        $out = [];
        foreach ($questions as $index => $q) {
            $out[] = ($index + 1) . '. ' . trim((string)($q['questiontext'] ?? ''));
        }
        return implode("\n\n", $out);
    }

    public static function update_draft(int $homeworkid, string $teacheredited, int $scheduledtime): void {
        homework_repository::update($homeworkid, [
            'teacheredited' => $teacheredited,
            'scheduledtime' => $scheduledtime,
            'status' => 'scheduled',
            'timemodified' => time(),
        ]);
    }

    public static function approve(int $homeworkid): void {
        homework_repository::update($homeworkid, [
            'approvalstatus' => 'approved',
            'status' => 'approved',
            'timemodified' => time(),
        ]);
    }

    public static function cancel(int $homeworkid): void {
        homework_repository::update($homeworkid, [
            'cancelled' => 1,
            'status' => 'cancelled',
            'timemodified' => time(),
        ]);
    }

    public static function deliver_due(): int {
        $count = 0;
        foreach (homework_repository::find_due_for_delivery(time()) as $homework) {
            self::deliver_one($homework);
            $count++;
        }
        return $count;
    }

    protected static function deliver_one(\stdClass $homework): void {
        global $CFG, $DB;
        require_once($CFG->dirroot . '/course/modlib.php');

        $course = get_course((int)$homework->courseid);
        $modinfo = get_fast_modinfo($course);
        $sectioninfo = $modinfo->get_section_info_by_id((int)$homework->sectionid);
        $sectionnum = $sectioninfo ? (int)$sectioninfo->section : 0;

        $content = trim((string)$homework->teacheredited);
        if ($content === '') {
            $content = trim((string)$homework->sourcetext);
        }
        if ($content === '') {
            $content = get_string('homeworkemptydraftfallback', 'local_aisgk');
        }

        $moduleid = 0;
        $deliverymessage = '';
        try {
            $assignmodule = $DB->get_record('modules', ['name' => 'assign']);
            if ($assignmodule) {
                $moduleinfo = (object)[
                    'course' => (int)$homework->courseid,
                    'section' => $sectionnum,
                    'module' => (int)$assignmodule->id,
                    'modulename' => 'assign',
                    'name' => 'BTVN - ' . $homework->topicname,
                    'intro' => format_text($content, FORMAT_HTML),
                    'introformat' => FORMAT_HTML,
                    'alwaysshowdescription' => 1,
                    'duedate' => max(time() + 3600, (int)$homework->scheduledtime + 86400),
                    'allowsubmissionsfromdate' => (int)$homework->scheduledtime,
                    'cutoffdate' => 0,
                    'gradingduedate' => 0,
                    'grade' => 100,
                    'submissiondrafts' => 0,
                    'sendnotifications' => 0,
                    'sendlatenotifications' => 0,
                    'sendstudentnotifications' => 0,
                    'assignsubmission_onlinetext_enabled' => 1,
                    'assignsubmission_file_enabled' => 0,
                    'visible' => 1,
                ];
                $cm = add_moduleinfo($moduleinfo, $course);
                $moduleid = (int)($cm->coursemodule ?? 0);
                $deliverymessage = 'assign';
            }
        } catch (\Throwable $e) {
            $deliverymessage = 'assign-fallback';
        }

        if (!$moduleid) {
            $labelmodule = $DB->get_record('modules', ['name' => 'label'], '*', MUST_EXIST);
            $moduleinfo = (object)[
                'course' => (int)$homework->courseid,
                'section' => $sectionnum,
                'module' => (int)$labelmodule->id,
                'modulename' => 'label',
                'name' => 'BTVN - ' . $homework->topicname,
                'intro' => format_text($content, FORMAT_HTML),
                'introformat' => FORMAT_HTML,
                'visible' => 1,
            ];
            $cm = add_moduleinfo($moduleinfo, $course);
            $moduleid = (int)($cm->coursemodule ?? 0);
            $deliverymessage = $deliverymessage ?: 'label';
        }

        homework_repository::update((int)$homework->id, [
            'status' => 'delivered',
            'approvalstatus' => $homework->approvalstatus === 'pending' ? 'autoapproved' : $homework->approvalstatus,
            'deliveredtime' => time(),
            'moodlemoduleid' => $moduleid,
            'deliverymessage' => $deliverymessage,
            'timemodified' => time(),
        ]);
    }
}
