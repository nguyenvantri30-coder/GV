<?php
namespace local_aisgk\local\service;

defined('MOODLE_INTERNAL') || die();

use local_aisgk\book_repository;
use local_aisgk\homework_repository;
use local_aisgk\local\job_manager;
use local_aisgk\local\ocr_runner;
use local_aisgk\local\sgk_processor;
use local_aisgk\local\ai_service;
use local_aisgk\toc_repository;

class homework_service {
    /**
     * The SGK page number shown in TOC/AI marker is the printed/book page.
     * In current SGK PDFs, the physical PDF page to render is printed page + 1.
     * Example: SGK page 6 => PDF page 7.
     */
    protected const SGK_TO_PDF_PAGE_OFFSET = 1;
    protected const AI_SENT_IMAGE_WIDTH = 1000;
    protected const AI_TRIM_MARGIN_RATIO = 0.05;
    protected const AI_SENT_JPEG_QUALITY = 85;
    // Cache optimized images sent to AI for 20 minutes to reduce repeated crop/resize CPU cost.
    protected const AI_SENT_CACHE_TTL = 1200;

    protected static $lastaiusage = [];
    public static function normalize_title(string $s): string {
        $s = \core_text::strtolower(trim($s));
        $s = preg_replace('/\s+/u', ' ', $s);
        $s = preg_replace('/^[\d\.\-\:]+\s*/u', '', $s);
        return trim($s);
    }

    public static function find_section_match(int $courseid, int $sectionid): ?array {
        global $DB;
        if ($sectionid < 1) {
            return null;
        }
        $sql = "SELECT t.*
                  FROM {local_aisgk_section_toc} m
                  JOIN {local_aisgk_book_toc} t ON t.id = m.tocid
                  JOIN {local_aisgk_books} b ON b.id = t.bookid
                 WHERE m.sectionid = ? AND b.courseid = ?";
        $toc = $DB->get_record_sql($sql, [$sectionid, $courseid]);
        if (!$toc) {
            return null;
        }
        $book = book_repository::get_by_id((int)$toc->bookid);
        if (!$book || (int)$book->courseid !== $courseid) {
            return null;
        }
        return ['book' => $book, 'toc' => $toc];
    }

    public static function find_topic_match(int $courseid, string $topicname): ?array {
        $target = self::normalize_title($topicname);
        if ($target === '') {
            return null;
        }
        foreach (book_repository::get_all_by_courseid($courseid) as $book) {
            $rows = toc_repository::get_by_bookid((int)$book->id);
            foreach ($rows as $row) {
                $name = self::normalize_title((string)$row->tenbai);
                if ($name === '') {
                    continue;
                }
                if ($name === $target || str_contains($target, $name) || str_contains($name, $target)) {
                    return ['book' => $book, 'toc' => $row];
                }
            }
        }
        return null;
    }

    protected static function homework_fingerprint(int $courseid, int $sectionid, string $topicname, int $bookid, int $pagefrom, int $pageto, array $options): string {
        $config = [
            'courseid' => $courseid,
            'sectionid' => $sectionid,
            'topic' => self::normalize_title($topicname),
            'bookid' => $bookid,
            'pagefrom' => $pagefrom,
            'pageto' => $pageto,
            'qtypes' => $options['qtypes'] ?? [],
            'cognitive' => $options['cognitive'] ?? [],
            'distractors' => $options['distractors'] ?? [],
        ];
        return sha1(json_encode($config, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES));
    }

    protected static function find_ready_draft_by_fingerprint(string $fingerprint): ?\stdClass {
        global $DB;
        if ($fingerprint === '' || !$DB->get_manager()->field_exists(new \xmldb_table('local_aisgk_homeworks'), new \xmldb_field('fingerprint'))) { return null; }
        $records = $DB->get_records_select('local_aisgk_homeworks', "fingerprint = ? AND status = 'draft_ready' AND cancelled = 0", [$fingerprint], 'id DESC', '*', 0, 1);
        return $records ? reset($records) : null;
    }
    public static function create_draft_job(int $userid, int $courseid, int $sectionid, string $topicname, int $bookid, int $pagefrom, int $pageto, int $scheduledtime, array $options = []): array {
        global $DB;
        $fingerprint = self::homework_fingerprint($courseid, $sectionid, $topicname, $bookid, $pagefrom, $pageto, $options);
        $resourcekey = 'course:' . $courseid . ':section:' . $sectionid . ':homework:' . $fingerprint;
        if ($existing = job_manager::find_active_by_fingerprint($fingerprint, 'createhomework')) {
            return ['jobid' => (int)$existing->id, 'reused' => true];
        }
        if ($existingdraft = self::find_ready_draft_by_fingerprint($fingerprint)) {
            $jobid = job_manager::create('createhomework', $userid, $resourcekey, [
                'homeworkid' => (int)$existingdraft->id,
                'reuseddraft' => true,
                'options' => $options,
            ], $fingerprint, 80, time(), 'manual');
            job_manager::mark_done($jobid, ['homeworkid' => (int)$existingdraft->id, 'reuseddraft' => true], 'Đã có bản nháp cùng cấu hình, không gọi AI lại.');
            return ['jobid' => $jobid, 'homeworkid' => (int)$existingdraft->id, 'reused' => true, 'draftreused' => true];
        }

        $now = time();
        $homeworkid = homework_repository::create([
            'courseid' => $courseid,
            'sectionid' => $sectionid,
            'topicname' => $topicname,
            'bookid' => $bookid,
            'pagefrom' => $pagefrom,
            'pageto' => $pageto,
            'status' => 'draft_generating',
            'approvalstatus' => 'pending',
            'scheduledtime' => $scheduledtime,
            'deliveredtime' => 0,
            'resourcekey' => $resourcekey,
            'fingerprint' => $fingerprint,
            'source' => 'manual',
            'sourcetext' => '',
            'sourceformula' => json_encode(['options' => $options], JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES),
            'questiondata' => '',
            'teacheredited' => '',
            'moodlemoduleid' => 0,
            'deliverymessage' => '',
            'errormsg' => '',
            'cancelled' => 0,
            'timecreated' => $now,
            'timemodified' => $now,
            'userid' => $userid,
        ]);

        $payload = [
            'homeworkid' => $homeworkid,
            'courseid' => $courseid,
            'sectionid' => $sectionid,
            'topicname' => $topicname,
            'bookid' => $bookid,
            'pagefrom' => $pagefrom,
            'pageto' => $pageto,
            'scheduledtime' => $scheduledtime,
            'fingerprint' => $fingerprint,
            'source' => 'manual',
            'options' => $options,
        ];
        $jobid = job_manager::create('createhomework', $userid, $resourcekey, $payload, $fingerprint, 80, time(), 'manual');
        $DB->update_record('local_aisgk_homeworks', (object)['id' => $homeworkid, 'jobid' => $jobid]);
        return ['jobid' => $jobid, 'homeworkid' => $homeworkid, 'reused' => false];
    }


    /**
     * Render short [IMG id] markers for preview only.
     * IMPORTANT: Do NOT overwrite questiondata/sourcetext with <img>.
     * Metadata must live in the per-question images map.
     */
    public static function materialize_homework_images(int $homeworkid, array $options = []): ?\stdClass {
        $homework = homework_repository::get_by_id($homeworkid);
        if (!$homework) {
            return null;
        }

        $raws = [
            (string)($homework->questiondata ?? ''),
            (string)($homework->sourcetext ?? ''),
        ];
        $decoded = null;
        foreach ($raws as $raw) {
            if ($raw === '' || (strpos($raw, '[IMG ') === false)) {
                continue;
            }
            $try = json_decode($raw, true);
            if (is_array($try)) {
                $decoded = $try;
                break;
            }
        }
        if (!is_array($decoded)) {
            $homework->previewquestiondata = '';
            $homework->previewteacheredited = '';
            return $homework;
        }

        $questions = $decoded['questions'] ?? $decoded;
        if (!is_array($questions)) {
            $homework->previewquestiondata = '';
            $homework->previewteacheredited = '';
            return $homework;
        }

        $questions = ai_service::normalize_homework_questions(array_values($questions), $options);
        // Draft/preview mode may crop images inline as data URI for display, but must not persist child crops.
        $persistimages = !empty($options['persist_images']);
        $inlinepreview = !$persistimages && !empty($options['preview_inline_images']);
        $sentmeta = is_array($options['_sent_image_meta'] ?? null) ? (array)$options['_sent_image_meta'] : [];
        $previewquestions = self::materialize_image_refs($questions, [], (int)$homework->pagefrom, (int)$homework->pageto,
            (int)$homework->bookid, (int)$homework->courseid, (int)$homework->sectionid, $homeworkid, $persistimages, $inlinepreview, $sentmeta);

        $homework->previewquestiondata = json_encode($previewquestions, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
        $homework->previewteacheredited = self::questions_to_text($previewquestions);
        return $homework;
    }
    public static function process_job(\stdClass $job): void {
        global $DB;
        $payload = json_decode((string)$job->payloadjson, true) ?: [];
        $homeworkid = (int)($payload['homeworkid'] ?? 0);
        $homework = homework_repository::get_by_id($homeworkid);
        if (!$homework) {
            throw new \moodle_exception('invalidparameter');
        }

        job_manager::update_progress((int)$job->id, 1, 'start', get_string('stepstart', 'local_aisgk'), 5, get_string('homeworkjobstarting', 'local_aisgk'));

        $bookid = (int)$homework->bookid;
        $pagefrom = max(1, (int)$homework->pagefrom);
        $pageto = max($pagefrom, (int)$homework->pageto);

        job_manager::update_progress((int)$job->id, 2, 'render', get_string('stepscanlesson', 'local_aisgk'), 12,
            'Đang render trang SGK thành ảnh để gửi AI...');
        $book = book_repository::get_by_id($bookid);
        $renderfrom = self::sgk_page_to_pdf_page($pagefrom);
        $renderto = self::sgk_page_to_pdf_page($pageto);
        $images = sgk_processor::render_page_images_cached($bookid, (int)$book->courseid, (int)$homework->sectionid,
            $renderfrom, $renderto, 180, static function(int $done, int $total) use ($job): void {
                $percent = 12 + (int)floor(($done / max(1, $total)) * 28);
                job_manager::update_progress((int)$job->id, 2, 'render', 'Render/cache ảnh trang SGK', $percent,
                    'Đang chuẩn bị ảnh trang SGK... (' . $done . '/' . $total . ')');
            });
        if (!$images) {
            throw new \moodle_exception('bookimagesmissing', 'local_aisgk');
        }

        job_manager::update_progress((int)$job->id, 2, 'preprocess', 'Tối ưu ảnh SGK', 45,
            'Đang crop lề và resize ảnh trang SGK về rộng ' . self::AI_SENT_IMAGE_WIDTH . 'px để gửi AI...');
        $prepared = self::prepare_ai_sent_images($images, $pagefrom, (int)$bookid, (int)$book->courseid, (int)$homework->sectionid);
        $aiimages = $prepared['images'];
        $sentmeta = $prepared['meta'];

        job_manager::update_progress((int)$job->id, 3, 'generate', get_string('stepcreatehomework', 'local_aisgk'), 55,
            'Đang gửi ảnh SGK đã tối ưu trang ' . $pagefrom . '–' . $pageto . ' (PDF ' . $renderfrom . '–' . $renderto . ') cho AI để tạo câu hỏi...');
        $bookname = $book ? (string)($book->name ?: $book->filename) : '';
        $options = (array)($payload['options'] ?? []);
        $genoptions = $options;
        $genoptions['_jobid'] = (int)$job->id;
        $genoptions['_sent_image_meta'] = $sentmeta;
        $ai = self::generate_questions_from_images($homework->topicname, $aiimages, $pagefrom, $pageto, (int)$job->userid,
            $genoptions, $bookname);
        $questions = (array)($ai['questions'] ?? []);
        // Keep short [IMG id] markers in saved JSON. Render/crop images only for preview/delivery.
        $parseerror = trim((string)($ai['parseerror'] ?? ''));
        if ($parseerror !== '') {
            $report = [
                'ok' => false,
                'errors' => ['Không phân tích được JSON bài tập AI trả về: ' . $parseerror],
                'summary' => ['qtypes' => [], 'levels' => []],
            ];
        } else {
            $report = ai_service::validate_homework_against_plan($questions, $options);
        }

        // Phase debug: KHÔNG chặn khi validator báo lỗi. Luôn lưu raw AI + JSON đã normalize
        // để giáo viên thấy kết quả thật và mình có dữ liệu chỉnh prompt/schema/validator.
        $debugjson = [
            'questions' => array_values($questions),
            '_debug' => [
                'raw_ai_text' => (string)($ai['rawtext'] ?? ''),
                'normalizedjson' => (string)($ai['normalizedjson'] ?? ai_service::questions_json($questions)),
                'parse_error' => $parseerror,
                'report' => $report,
            ],
        ];
        $rawjson = json_encode($debugjson, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
        if ($rawjson === false) {
            $rawjson = ai_service::questions_json($questions);
        }
        $questiontext = self::questions_to_text($questions);
        $usage = self::$lastaiusage;
        $fixmodel = '';
        $fixtokens = 0;
        if (!empty($ai['autorepair']) && is_array($ai['autorepair'])) {
            $fixmodel = (string)($ai['autorepair']['model'] ?? '');
            $fixtokens = (int)($ai['autorepair']['tokens'] ?? 0);
        }
        $meta = [
            'options' => $options,
            'report' => $report,
            'usage' => $usage,
            'model' => (string)($usage['model'] ?? ''),
            'model_create' => (string)($usage['model'] ?? ''),
            'model_fix' => $fixmodel,
            'tokens_create' => (int)($usage['tokens'] ?? 0),
            'tokens_fix' => $fixtokens,
            '_sent_image_meta' => $sentmeta,
        ];
        $errormsg = $report['ok'] ? '' : implode(' | ', $report['errors']);

        homework_repository::update($homeworkid, [
            'status' => 'draft_ready',
            'sourcetext' => $rawjson,
            'sourceformula' => json_encode($meta, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES),
            'questiondata' => json_encode($questions, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES),
            'teacheredited' => $questiontext,
            'errormsg' => $errormsg,
            'timemodified' => time(),
        ]);

        job_manager::update_progress((int)$job->id, 3, 'done', get_string('stepdone', 'local_aisgk'), 95, get_string('homeworkjobdraftready', 'local_aisgk'));
        job_manager::mark_done((int)$job->id, [
            'homeworkid' => $homeworkid,
            'questioncount' => count($questions),
            'usage' => $usage,
            'report' => $report,
            'hasvalidationerrors' => !$report['ok'],
        ], get_string('homeworkjobresult', 'local_aisgk', count($questions)));
    }

    /**
     * Keep original rendered PDF pages in page_cache, but send optimized copies to AI.
     * The sent image is produced by trimming four margins and resizing width to 1000px.
     * Coordinates returned by AI for source=sgk must be based on this sent image.
     */
    protected static function prepare_ai_sent_images(array $pageimages, int $pagefrom, int $bookid, int $courseid, int $sectionid): array {
        global $CFG;
        $out = [];
        $meta = [];
        $base = rtrim($CFG->dataroot, '/') . '/local_aisgk/ai_sentpages/course_' . $courseid . '/book_' . $bookid . '/section_' . max(0, $sectionid);
        if (!is_dir($base)) { mkdir($base, $CFG->directorypermissions, true); }
        foreach (array_values($pageimages) as $i => $src) {
            $page = $pagefrom + $i;
            if (!is_file($src)) { continue; }
            $info = @getimagesize($src);
            if (!$info || empty($info[0]) || empty($info[1])) { continue; }
            $pdfw = (int)$info[0];
            $pdfh = (int)$info[1];
            $mx = max(0, (int)round($pdfw * self::AI_TRIM_MARGIN_RATIO));
            $my = max(0, (int)round($pdfh * self::AI_TRIM_MARGIN_RATIO));
            $cropw = max(10, $pdfw - 2 * $mx);
            $croph = max(10, $pdfh - 2 * $my);
            if ($cropw < 200 || $croph < 200) { $mx = 0; $my = 0; $cropw = $pdfw; $croph = $pdfh; }
            $sentw = min(self::AI_SENT_IMAGE_WIDTH, $cropw);
            $scale = $sentw / max(1, $cropw);
            $senth = max(1, (int)round($croph * $scale));
            $dest = $base . '/page_' . $page . '_w' . self::AI_SENT_IMAGE_WIDTH . '_m' . (int)round(self::AI_TRIM_MARGIN_RATIO * 100) . '_' . substr(sha1($src . '|' . @filemtime($src)), 0, 10) . '.jpg';
            $cachefresh = is_file($dest) && @filesize($dest) >= 100 && (time() - (int)@filemtime($dest) <= self::AI_SENT_CACHE_TTL);
            if (!$cachefresh) {
                $img = self::image_create_from_file($src);
                if (!$img) { continue; }
                $cropped = @imagecrop($img, ['x' => $mx, 'y' => $my, 'width' => $cropw, 'height' => $croph]);
                imagedestroy($img);
                if (!$cropped) { continue; }
                $scaled = function_exists('imagescale') ? @imagescale($cropped, $sentw, $senth) : false;
                if ($scaled) { imagedestroy($cropped); $cropped = $scaled; }
                if (function_exists('imageconvolution')) {
                    @imageconvolution($cropped, [[0,-1,0],[-1,5,-1],[0,-1,0]], 1, 0);
                }
                @imagejpeg($cropped, $dest, self::AI_SENT_JPEG_QUALITY);
                imagedestroy($cropped);
                @chmod($dest, $CFG->filepermissions);
            }
            if (!is_file($dest)) { continue; }
            $out[] = $dest;
            $meta[$page] = [
                'sent_image_id' => 'p' . $page,
                'page' => $page,
                'pdf_size' => ['w' => $pdfw, 'h' => $pdfh],
                'trim_margin' => true,
                'crop_offset' => ['x' => $mx, 'y' => $my],
                'crop_size' => ['w' => $cropw, 'h' => $croph],
                'sent_size' => ['w' => $sentw, 'h' => $senth],
                'source_size' => ['w' => $sentw, 'h' => $senth],
                // File ảnh thực tế đã crop/resize gửi cho AI. Dùng cho preview/debug để cắt đúng theo hệ tọa độ AI nhìn thấy.
                'sent_path' => $dest,
                'scale' => round($scale, 8),
            ];
        }
        return ['images' => $out, 'meta' => $meta];
    }

    protected static function sgk_page_to_pdf_page(int $sgkpage): int {
        return max(1, $sgkpage + self::SGK_TO_PDF_PAGE_OFFSET);
    }

    protected static function normalize_img_size_value($value): array {
        if (is_array($value)) {
            if (isset($value['w']) || isset($value['h'])) {
                return ['w' => max(0, (int)($value['w'] ?? 0)), 'h' => max(0, (int)($value['h'] ?? 0))];
            }
            if (isset($value[0]) && isset($value[1])) {
                return ['w' => max(0, (int)$value[0]), 'h' => max(0, (int)$value[1])];
            }
        }
        return self::parse_size_pair((string)$value);
    }

    protected static function normalize_img_box_value($value): array {
        if (is_array($value)) {
            $vals = array_values($value);
            if (count($vals) === 4) { return array_map('intval', $vals); }
        }
        return self::parse_box4((string)$value);
    }

    protected static function img_ref_from_meta(string $id, array $meta): ?array {
        $id = trim((string)($meta['id'] ?? $id));
        if ($id === '') { return null; }
        $rawsource = trim((string)($meta['source'] ?? 'sgk'));
        $url = trim((string)($meta['url'] ?? ''));
        if (preg_match('#^https?://#i', $rawsource)) {
            $source = 'internet';
            $url = $rawsource;
        } else {
            $source = strtolower($rawsource !== '' ? $rawsource : 'sgk');
            if ($source === 'url' || $source === 'web') { $source = 'internet'; }
            if (!in_array($source, ['sgk', 'internet'], true)) { $source = 'sgk'; }
        }
        $box = self::normalize_img_box_value($meta['source_box'] ?? ($meta['box'] ?? []));
        if (count($box) !== 4) { return null; }
        return [
            'id' => $id,
            'label' => trim((string)($meta['label'] ?? $id)),
            'role' => strtolower((string)($meta['role'] ?? 'inline')),
            'source' => $source,
            'page' => (int)($meta['page'] ?? $meta['page_index'] ?? 0),
            'url' => $url,
            'source_size' => self::normalize_img_size_value($meta['source_size'] ?? ''),
            'source_box' => $box,
            'canvas_size' => self::normalize_img_size_value($meta['canvas_size'] ?? ''),
            'pdf_size' => self::normalize_img_size_value($meta['pdf_size'] ?? ''),
            'crop_offset' => [
                'x' => (int)($meta['crop_offset']['x'] ?? 0),
                'y' => (int)($meta['crop_offset']['y'] ?? 0),
            ],
            'scale' => (float)($meta['scale'] ?? 0),
            'sent_image_id' => (string)($meta['sent_image_id'] ?? ''),
        ];
    }

    protected static function image_ref_map_from_question(array $q): array {
        $map = [];
        if (!empty($q['images']) && is_array($q['images'])) {
            foreach ($q['images'] as $key => $meta) {
                if (!is_array($meta)) { continue; }
                $id = is_string($key) ? $key : (string)($meta['id'] ?? '');
                $ref = self::img_ref_from_meta($id, $meta);
                if ($ref) { $map[(string)$ref['id']] = $ref; }
            }
        }
        return $map;
    }
    protected static function sent_meta_for_page(array $sentmeta, int $page): array {
        if ($page <= 0 || !is_array($sentmeta)) { return []; }
        return is_array($sentmeta[$page] ?? null) ? (array)$sentmeta[$page] : [];
    }

    protected static function attach_sent_meta_to_ref(array $ref, array $sentmeta): array {
        if (($ref['source'] ?? 'sgk') !== 'sgk') { return $ref; }
        $page = (int)($ref['page'] ?? 0);
        $m = self::sent_meta_for_page($sentmeta, $page);
        if (!$m) { return $ref; }
        foreach (['pdf_size','crop_offset','crop_size','sent_size','source_size','scale','sent_image_id','sent_path'] as $k) {
            if (array_key_exists($k, $m)) { $ref[$k] = $m[$k]; }
        }
        return $ref;
    }

    protected static function expand_pixel_box(array $box, int $maxw, int $maxh, float $ratiox = 0.06, float $ratioy = 0.04, int $minpad = 8): array {
        if (count($box) !== 4) { return $box; }
        [$x1, $y1, $x2, $y2] = array_map('floatval', $box);
        $w = max(1.0, $x2 - $x1);
        $h = max(1.0, $y2 - $y1);
        $padx = max($minpad, (int)round($w * $ratiox));
        $pady = max($minpad, (int)round($h * $ratioy));
        return [
            max(0, (int)round($x1 - $padx)),
            max(0, (int)round($y1 - $pady)),
            min($maxw, (int)round($x2 + $padx)),
            min($maxh, (int)round($y2 + $pady)),
        ];
    }

    protected static function map_normalized_box_to_pixels(array $box, array $ref, int $imgw, int $imgh): array {
        if (count($box) !== 4) { return $box; }
        // source_box chuẩn Gemini-native: [ymin,xmin,ymax,xmax] trên hệ 0-1000 theo ảnh AI nhìn thấy.
        // Với SGK, ảnh AI nhìn thấy là vùng page đã crop lề rồi resize; map về ảnh trang gốc bằng crop_offset + tỉ lệ crop_size/1000.
        [$ymin, $xmin, $ymax, $xmax] = array_map('floatval', $box);

        // Backward compatibility: if any coordinate is outside 0-1000, treat it as an old pixel box.
        $maxcoord = max($xmin, $ymin, $xmax, $ymax);
        if ($maxcoord > 1000) {
            $sourcew = (int)($ref['pdf_size']['w'] ?? $ref['source_size']['w'] ?? $imgw);
            $sourceh = (int)($ref['pdf_size']['h'] ?? $ref['source_size']['h'] ?? $imgh);
            $mapped = [
                ($xmin * $imgw / max(1, $sourcew)),
                ($ymin * $imgh / max(1, $sourceh)),
                ($xmax * $imgw / max(1, $sourcew)),
                ($ymax * $imgh / max(1, $sourceh)),
            ];
            return self::expand_pixel_box($mapped, $imgw, $imgh);
        }

        if (!empty($ref['_crop_on_sent'])) {
            $mapped = [
                ($xmin / 1000.0) * $imgw,
                ($ymin / 1000.0) * $imgh,
                ($xmax / 1000.0) * $imgw,
                ($ymax / 1000.0) * $imgh,
            ];
            return self::expand_pixel_box($mapped, $imgw, $imgh, 0.08, 0.05);
        }

        if (($ref['source'] ?? 'sgk') === 'sgk') {
            $crop = self::normalize_img_size_value($ref['crop_size'] ?? []);
            $offsetx = (int)($ref['crop_offset']['x'] ?? 0);
            $offsety = (int)($ref['crop_offset']['y'] ?? 0);
            $cropw = (int)($crop['w'] ?? 0);
            $croph = (int)($crop['h'] ?? 0);
            if ($cropw <= 0 || $croph <= 0) { $cropw = $imgw; $croph = $imgh; $offsetx = 0; $offsety = 0; }
            $mapped = [
                $offsetx + ($xmin / 1000.0) * $cropw,
                $offsety + ($ymin / 1000.0) * $croph,
                $offsetx + ($xmax / 1000.0) * $cropw,
                $offsety + ($ymax / 1000.0) * $croph,
            ];
            return self::expand_pixel_box($mapped, $imgw, $imgh, 0.12, 0.06);
        }

        $mapped = [
            ($xmin / 1000.0) * $imgw,
            ($ymin / 1000.0) * $imgh,
            ($xmax / 1000.0) * $imgw,
            ($ymax / 1000.0) * $imgh,
        ];
        return self::expand_pixel_box($mapped, $imgw, $imgh);
    }

    protected static function materialize_image_refs(array $questions, array $images, int $pagefrom, int $pageto, int $bookid, int $courseid, int $sectionid, int $homeworkid, bool $persistimages = false, bool $inlinepreview = false, array $sentmeta = []): array {
        $pagemap = [];
        foreach (array_values($images) as $i => $path) {
            $pagemap[$pagefrom + $i] = $path;
        }
        $cache = [];
        foreach ($questions as $idx => $q) {
            if (!is_array($q)) {
                continue;
            }
            $idrefs = self::image_ref_map_from_question($q);
            foreach ($idrefs as $rid => $rmeta) { $idrefs[$rid] = self::attach_sent_meta_to_ref($rmeta, $sentmeta); }
            // Preview mode: keep question text readable by replacing [IMG id] with its label,
            // and render the actual cropped image in a separate preview panel. Do not persist child crops here.
            if ($inlinepreview && $idrefs) {
                $q['_preview_images'] = self::build_preview_image_list($idrefs, $cache, $pagemap, $bookid, $courseid, $sectionid, $homeworkid);
            }
            $replace = function(string $text) use (&$cache, &$pagemap, $bookid, $courseid, $sectionid, $homeworkid, $idrefs, $persistimages, $inlinepreview): string {
                // In preview, marker location displays only the label. The image itself is shown in _preview_images.
                return self::replace_img_markers($text, $cache, $pagemap, $bookid, $courseid, $sectionid, $homeworkid, $idrefs, $persistimages, false);
            };
            if (isset($q['questiontext'])) {
                $q['questiontext'] = $replace((string)$q['questiontext']);
            }
            if (!empty($q['subquestions']) && is_array($q['subquestions'])) {
                foreach ($q['subquestions'] as $si => $sq) {
                    if (!is_array($sq)) {
                        continue;
                    }
                    if (isset($sq['question'])) {
                        $sq['question'] = $replace((string)$sq['question']);
                    }
                    if (isset($sq['answer'])) {
                        $sq['answer'] = $replace((string)$sq['answer']);
                    }
                    $q['subquestions'][$si] = $sq;
                }
            }
            if (!empty($q['choices']) && is_array($q['choices'])) {
                foreach ($q['choices'] as $ci => $choice) {
                    if (is_array($choice) && isset($choice['text'])) {
                        $choice['text'] = $replace((string)$choice['text']);
                        $q['choices'][$ci] = $choice;
                    }
                }
            }
            if (!empty($q['items']) && is_array($q['items'])) {
                foreach ($q['items'] as $ii => $item) {
                    if (is_array($item) && isset($item['content'])) {
                        $item['content'] = $replace((string)$item['content']);
                        $q['items'][$ii] = $item;
                    }
                }
            }
            if (!empty($q['background']) && is_string($q['background'])) {
                $q['background'] = $replace($q['background']);
            }
            if (!empty($q['answers']) && is_array($q['answers'])) {
                foreach ($q['answers'] as $ai => $answer) {
                    if (is_array($answer) && isset($answer['text'])) {
                        $answer['text'] = $replace((string)$answer['text']);
                        $q['answers'][$ai] = $answer;
                    }
                }
            }
            $questions[$idx] = $q;
        }
        return $questions;
    }

    protected static function build_preview_image_list(array $idrefs, array &$cache, array &$pagemap, int $bookid, int $courseid, int $sectionid, int $homeworkid): array {
        $out = [];
        foreach ($idrefs as $id => $ref) {
            if (!is_array($ref)) { continue; }
            $label = trim((string)($ref['label'] ?? $id));
            if ($label === '') { $label = (string)$id; }
            $key = 'previewpanel|' . sha1(json_encode($ref));
            if (!array_key_exists($key, $cache)) {
                try {
                    $cache[$key] = self::materialize_img_ref($ref, $pagemap, $bookid, $courseid, $sectionid, $homeworkid, true);
                } catch (\Throwable $e) {
                    $cache[$key] = '<span class="local-aisgk-img-error" title="' . s($e->getMessage()) . '">[IMG lỗi: ' . s($label) . ']</span>';
                }
            }
            $out[] = [
                'id' => (string)$id,
                'label' => $label,
                'html' => $cache[$key],
            ];
        }
        return $out;
    }

    protected static function replace_img_markers(string $text, array &$cache, array &$pagemap, int $bookid, int $courseid, int $sectionid, int $homeworkid, array $idrefs = [], bool $persistimages = false, bool $inlinepreview = false): string {
        if ($text === '' || (strpos($text, '[IMG ') === false)) {
            return $text;
        }
        $newre = '/\[IMG\s+([^\]]+)\]/u';
        $text = preg_replace_callback($newre, function(array $m) use (&$cache, &$pagemap, $bookid, $courseid, $sectionid, $homeworkid, $idrefs, $persistimages, $inlinepreview): string {
            $ref = self::parse_img_marker_attrs((string)$m[1]);
            if (!$ref) {
                $shortid = trim((string)$m[1]);
                $shortid = preg_replace('/\s+.*/', '', $shortid);
                $ref = $idrefs[$shortid] ?? null;
            }
            if (!$ref) { return $m[0]; }
            $key = ($persistimages ? 'persist|' : ($inlinepreview ? 'inline|' : 'label|')) . sha1(json_encode($ref));
            if (!$persistimages && !$inlinepreview) {
                $label = trim((string)($ref['label'] ?? $ref['id'] ?? ''));
                return $label !== '' ? s($label) : $m[0];
            }
            if (!array_key_exists($key, $cache)) {
                try {
                    $cache[$key] = self::materialize_img_ref($ref, $pagemap, $bookid, $courseid, $sectionid, $homeworkid, !$persistimages);
                } catch (\Throwable $e) {
                    $label = (string)($ref['id'] ?? $ref['label'] ?? 'img');
                    $cache[$key] = '<span class="local-aisgk-img-error" title="' . s($e->getMessage()) . '">[IMG lỗi: ' . s($label) . ']</span>';
                }
            }
            return $cache[$key];
        }, $text) ?? $text;

        return $text;
    }

    protected static function parse_img_marker_attrs(string $attrtext): ?array {
        $attrs = [];
        if (preg_match_all('/([a-zA-Z_][a-zA-Z0-9_]*)\s*=\s*("([^"]*)"|\'([^\']*)\'|([^\s\]]+))/u', $attrtext, $matches, PREG_SET_ORDER)) {
            foreach ($matches as $m) {
                $attrs[strtolower($m[1])] = trim((string)($m[3] !== '' ? $m[3] : ($m[4] !== '' ? $m[4] : ($m[5] ?? ''))));
            }
        }
        $box = self::parse_box4((string)($attrs['source_box'] ?? $attrs['box'] ?? ''));
        if (count($box) !== 4) { return null; }
        $source = strtolower((string)($attrs['source'] ?? 'sgk'));
        if (!in_array($source, ['sgk', 'internet'], true)) { $source = 'sgk'; }
        return [
            'id' => (string)($attrs['id'] ?? $attrs['label'] ?? 'img'),
            'role' => strtolower((string)($attrs['role'] ?? 'inline')),
            'source' => $source,
            'page' => (int)($attrs['page'] ?? $attrs['page_index'] ?? 0),
            'url' => (string)($attrs['url'] ?? ''),
            'source_size' => self::parse_size_pair((string)($attrs['source_size'] ?? '')),
            'source_box' => $box,
            'canvas_size' => self::parse_size_pair((string)($attrs['canvas_size'] ?? '')),
        ];
    }

    protected static function parse_size_pair(string $value): array {
        if (preg_match('/^(\d{1,5})\s*[xX,]\s*(\d{1,5})$/', trim($value), $m)) {
            return ['w' => max(1, (int)$m[1]), 'h' => max(1, (int)$m[2])];
        }
        return ['w' => 0, 'h' => 0];
    }

    protected static function parse_box4(string $value): array {
        $parts = array_map('trim', explode(',', $value));
        if (count($parts) !== 4) { return []; }
        return array_map('intval', $parts);
    }

    protected static function materialize_img_ref(array $ref, array &$pagemap, int $bookid, int $courseid, int $sectionid, int $homeworkid, bool $inlineonly = false): string {
        global $CFG;
        $label = trim((string)($ref['label'] ?? $ref['id'] ?? 'img'));
        if ($label === '') { $label = 'img'; }
        $source = (string)($ref['source'] ?? 'sgk');
        $src = '';
        if ($source === 'internet') {
            $src = self::download_remote_image((string)($ref['url'] ?? ''), $homeworkid, $label);
        } else {
            // Debug/preview theo yêu cầu: nếu còn file ảnh đã gửi AI thì crop trực tiếp trên ảnh này.
            // source_box là hệ 0-1000 theo đúng ảnh AI nhìn thấy, nên cách này giúp xác định AI khoanh đúng hay sai.
            $sentpath = trim((string)($ref['sent_path'] ?? ''));
            if ($sentpath !== '' && is_file($sentpath)) {
                $src = $sentpath;
                $ref['_crop_on_sent'] = 1;
            } else {
                $page = (int)($ref['page'] ?? 0);
                if ($page <= 0) { throw new \moodle_exception('errorprocessingbook', 'local_aisgk', '', 'IMG thiếu page SGK.'); }
                if (empty($pagemap[$page]) || !is_file($pagemap[$page])) {
                    $pdfpage = self::sgk_page_to_pdf_page($page);
                    $rendered = sgk_processor::render_page_images_cached($bookid, $courseid, $sectionid, $pdfpage, $pdfpage, 180);
                    if (!empty($rendered[0]) && is_file($rendered[0])) { $pagemap[$page] = $rendered[0]; }
                }
                $src = $pagemap[$page] ?? '';
            }
        }
        if ($src === '' || !is_file($src)) { throw new \moodle_exception('errorprocessingbook', 'local_aisgk', '', 'Không tìm thấy ảnh nguồn cho IMG.'); }
        $info = @getimagesize($src);
        if (!$info || empty($info[0]) || empty($info[1])) { throw new \moodle_exception('errorprocessingbook', 'local_aisgk', '', 'Ảnh nguồn không hợp lệ.'); }
        $pixbox = self::map_normalized_box_to_pixels((array)$ref['source_box'], $ref, (int)$info[0], (int)$info[1]);
        [$left, $top, $right, $bottom] = $pixbox;
        $left = max(0, min((int)$info[0] - 1, (int)$left));
        $top = max(0, min((int)$info[1] - 1, (int)$top));
        $right = max($left + 1, min((int)$info[0], (int)$right));
        $bottom = max($top + 1, min((int)$info[1], (int)$bottom));
        $img = self::image_create_from_file($src);
        if (!$img) { throw new \moodle_exception('errorprocessingbook', 'local_aisgk', '', 'Không mở được ảnh nguồn.'); }
        $cropped = @imagecrop($img, ['x' => $left, 'y' => $top, 'width' => $right - $left, 'height' => $bottom - $top]);
        imagedestroy($img);
        if (!$cropped) { throw new \moodle_exception('errorprocessingbook', 'local_aisgk', '', 'Không crop được IMG.'); }
        $workw = (int)($ref['canvas_size']['w'] ?? 0);
        $workh = (int)($ref['canvas_size']['h'] ?? 0);
        if ($workw > 0 && $workh > 0 && function_exists('imagescale')) {
            $scaled = @imagescale($cropped, $workw, $workh);
            if ($scaled) { imagedestroy($cropped); $cropped = $scaled; }
        }
        $tmpdir = $CFG->dataroot . '/local_aisgk/tmp/homeworkimg/' . $homeworkid;
        if (!is_dir($tmpdir)) { mkdir($tmpdir, $CFG->directorypermissions, true); }
        $safe = preg_replace('/[^a-zA-Z0-9_\-]+/', '_', $label) ?: 'img';
        $filename = $safe . '_' . substr(sha1(json_encode($ref)), 0, 12) . '.png';
        $tmpfile = $tmpdir . '/' . $filename;
        if ($inlineonly) {
            $previewdir = self::preview_img_dir($homeworkid);
            if (!is_dir($previewdir)) { mkdir($previewdir, $CFG->directorypermissions, true); }
            $previewfile = $previewdir . '/' . $filename;
            imagepng($cropped, $previewfile);
            imagedestroy($cropped);
            $url = new \moodle_url('/local/aisgk/previewimg.php', [
                'courseid' => $courseid,
                'homeworkid' => $homeworkid,
                'file' => $filename,
            ]);
            return '<span class="local-aisgk-img-wrap local-aisgk-img-preview"><img src="' . s($url->out(false)) . '" alt="' . s($label) . '" loading="lazy"></span>';
        }
        imagepng($cropped, $tmpfile);
        imagedestroy($cropped);
        return self::store_homework_img_file($tmpfile, $filename, $label, $courseid, $homeworkid);
    }

    protected static function preview_img_dir(int $homeworkid): string {
        global $CFG, $USER;
        $base = !empty($CFG->localcachedir) ? $CFG->localcachedir : ($CFG->dataroot . '/localcache');
        $userid = !empty($USER->id) ? (int)$USER->id : 0;
        return $base . '/local_aisgk/previewimg/u' . $userid . '/h' . max(0, $homeworkid);
    }

    protected static function image_create_from_file(string $src) {
        $ext = strtolower(pathinfo($src, PATHINFO_EXTENSION));
        if (($ext === 'jpg' || $ext === 'jpeg') && function_exists('imagecreatefromjpeg')) { return @imagecreatefromjpeg($src); }
        if ($ext === 'webp' && function_exists('imagecreatefromwebp')) { return @imagecreatefromwebp($src); }
        return @imagecreatefrompng($src);
    }

    protected static function download_remote_image(string $url, int $homeworkid, string $label): string {
        global $CFG;
        if (!preg_match('#^https?://#i', $url)) { throw new \moodle_exception('errorprocessingbook', 'local_aisgk', '', 'URL ảnh internet không hợp lệ.'); }
        if (preg_match('#example\.com|placeholder#i', $url)) { throw new \moodle_exception('errorprocessingbook', 'local_aisgk', '', 'AI trả URL ảnh giả/placeholder.'); }
        $tmpdir = $CFG->dataroot . '/local_aisgk/tmp/remoteimg/' . $homeworkid;
        if (!is_dir($tmpdir)) { mkdir($tmpdir, $CFG->directorypermissions, true); }
        $ext = strtolower(pathinfo(parse_url($url, PHP_URL_PATH) ?: '', PATHINFO_EXTENSION));
        if (!in_array($ext, ['jpg','jpeg','png','webp'], true)) { $ext = 'img'; }
        $safe = preg_replace('/[^a-zA-Z0-9_\-]+/', '_', $label) ?: 'remote';
        $file = $tmpdir . '/' . $safe . '_' . substr(sha1($url), 0, 12) . '.' . $ext;
        $data = @file_get_contents($url, false, stream_context_create(['http' => ['timeout' => 12, 'follow_location' => 1], 'ssl' => ['verify_peer' => true, 'verify_peer_name' => true]]));
        if ($data === false || strlen($data) < 100) { throw new \moodle_exception('errorprocessingbook', 'local_aisgk', '', 'Không tải được ảnh internet.'); }
        file_put_contents($file, $data);
        return $file;
    }

    protected static function store_homework_img_file(string $tmpfile, string $filename, string $label, int $courseid, int $homeworkid): string {
        if (!is_file($tmpfile) || filesize($tmpfile) < 1) { throw new \moodle_exception('errorprocessingbook', 'local_aisgk', '', 'Không lưu được ảnh crop.'); }
        $context = \context_course::instance($courseid);
        $fs = get_file_storage();
        $fileinfo = ['contextid' => $context->id, 'component' => 'local_aisgk', 'filearea' => 'homeworkimg', 'itemid' => $homeworkid, 'filepath' => '/', 'filename' => $filename];
        if ($old = $fs->get_file($context->id, 'local_aisgk', 'homeworkimg', $homeworkid, '/', $filename)) { $old->delete(); }
        $fs->create_file_from_pathname($fileinfo, $tmpfile);
        @unlink($tmpfile);
        $url = \moodle_url::make_pluginfile_url($context->id, 'local_aisgk', 'homeworkimg', $homeworkid, '/', $filename, false)->out(false);
        return '<span class="local-aisgk-img-wrap"><img src="' . s($url) . '" alt="' . s($label) . '" loading="lazy"></span>';
    }

    protected static function crop_homework_image(string $label, int $page, array $box, array &$pagemap, int $bookid, int $courseid, int $sectionid, int $homeworkid): string {
        global $CFG;
        if (empty($pagemap[$page]) || !is_file($pagemap[$page])) {
            $pdfpage = self::sgk_page_to_pdf_page($page);
            $rendered = sgk_processor::render_page_images_cached($bookid, $courseid, $sectionid, $pdfpage, $pdfpage, 180);
            if (!empty($rendered[0]) && is_file($rendered[0])) {
                $pagemap[$page] = $rendered[0];
            }
        }
        $src = $pagemap[$page] ?? '';
        if ($src === '' || !is_file($src)) {
            throw new \moodle_exception("errorprocessingbook", "local_aisgk", "", "Không tìm thấy ảnh trang SGK " . $page . " (PDF " . self::sgk_page_to_pdf_page($page) . ")");
        }
        $info = @getimagesize($src);
        if (!$info || empty($info[0]) || empty($info[1])) {
            throw new \moodle_exception('errorprocessingbook', 'local_aisgk', '', 'Ảnh trang không hợp lệ.');
        }
        $width = (int)$info[0];
        $height = (int)$info[1];
        // source_box chuẩn Gemini-native: [ymin,xmin,ymax,xmax] trên hệ 0-1000.
        [$ymin, $xmin, $ymax, $xmax] = array_map('intval', $box);
        $left = max(0, min($width - 1, (int)floor($xmin * $width / 1000)));
        $top = max(0, min($height - 1, (int)floor($ymin * $height / 1000)));
        $right = max($left + 1, min($width, (int)ceil($xmax * $width / 1000)));
        $bottom = max($top + 1, min($height, (int)ceil($ymax * $height / 1000)));
        $cropw = $right - $left;
        $croph = $bottom - $top;
        if ($cropw < 5 || $croph < 5) {
            throw new \moodle_exception('errorprocessingbook', 'local_aisgk', '', 'BBox ảnh quá nhỏ.');
        }
        $ext = strtolower(pathinfo($src, PATHINFO_EXTENSION));
        if (($ext === 'jpg' || $ext === 'jpeg') && function_exists('imagecreatefromjpeg')) {
            $img = @imagecreatefromjpeg($src);
        } else if ($ext === 'webp' && function_exists('imagecreatefromwebp')) {
            $img = @imagecreatefromwebp($src);
        } else {
            $img = @imagecreatefrompng($src);
        }
        if (!$img) {
            throw new \moodle_exception('errorprocessingbook', 'local_aisgk', '', 'Không mở được ảnh trang để crop.');
        }
        $cropped = @imagecrop($img, ['x' => $left, 'y' => $top, 'width' => $cropw, 'height' => $croph]);
        imagedestroy($img);
        if (!$cropped) {
            throw new \moodle_exception('errorprocessingbook', 'local_aisgk', '', 'Không crop được ảnh.');
        }
        $tmpdir = $CFG->dataroot . '/local_aisgk/tmp/homeworkimg/' . $homeworkid;
        if (!is_dir($tmpdir)) {
            mkdir($tmpdir, $CFG->directorypermissions, true);
        }
        $safe = preg_replace('/[^a-zA-Z0-9_\-]+/', '_', $label) ?: 'img';
        $filename = $safe . '_p' . $page . '_' . substr(sha1(implode(',', $box)), 0, 10) . '.png';
        $tmpfile = $tmpdir . '/' . $filename;
        imagepng($cropped, $tmpfile);
        imagedestroy($cropped);
        return self::store_homework_img_file($tmpfile, $filename, $label, $courseid, $homeworkid);
    }
    protected static function extract_formulas(string $text): array {
        $lines = preg_split('/\R/u', $text) ?: [];
        $formula = [];
        foreach ($lines as $line) {
            $line = trim($line);
            if ($line === '') {
                continue;
            }
            if (preg_match('/[=+\-×x*\/²³√()]/u', $line) && preg_match('/\d/u', $line)) {
                $formula[] = $line;
            }
        }
        return array_values(array_slice(array_unique($formula), 0, 12));
    }

    protected static function generate_questions_from_images(string $topicname, array $images, int $pagefrom, int $pageto, int $userid = 0, array $options = [], string $bookname = ''): array {
        $ai = ai_service::generate_homework_questions_from_images($topicname, $images, $pagefrom, $pageto, $userid, $options, $bookname);
        if (empty($ai["questions"]) || !is_array($ai["questions"])) {
            if (!empty($ai["rawtext"]) || !empty($ai["parseerror"])) {
                // Vẫn trả dữ liệu về process_job để lưu raw vào draft/textarea cho debug.
                $ai["questions"] = [];
            } else {
                throw new \moodle_exception('errorprocessingbook', 'local_aisgk', '', 'AI không trả về danh sách câu hỏi hợp lệ.');
            }
        }
        self::$lastaiusage = [
            "model" => (string)($ai["model"] ?? ""),
            "tokens" => (int)($ai["tokens"] ?? 0),
            "keysource" => (string)($ai["keysource"] ?? "system"),
            "category" => (string)($ai["category"] ?? "free"),
            "remain_calls" => (int)($ai["usage"]["remain_calls"] ?? 0),
            "api" => ((string)($ai["category"] ?? "free") === "pay") ? "API trả phí" : "API miễn phí/hệ thống",
            "rawtext" => (string)($ai["rawtext"] ?? ""),
        ];
        return $ai;
    }

    protected static function pretty_ai_json(string $rawtext, array $questions): string {
        $json = json_decode(trim($rawtext), true);
        if (!is_array($json) && preg_match('/\{.*\}/s', $rawtext, $m)) {
            $json = json_decode($m[0], true);
        }
        if (!is_array($json)) {
            $json = ['questions' => $questions, 'raw' => $rawtext];
        }
        return json_encode($json, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
    }

    public static function questions_to_text(array $questions): string {
        $out = [];
        foreach ($questions as $index => $q) {
            $out[] = ($index + 1) . '. ' . trim((string)($q['questiontext'] ?? ''));
        }
        return implode("\n\n", $out);
    }

    public static function update_draft(int $homeworkid, string $teacheredited, int $scheduledtime): void {
        homework_repository::update($homeworkid, [
            'teacheredited' => $teacheredited,
            'scheduledtime' => $scheduledtime,
            'status' => 'scheduled',
            'timemodified' => time(),
        ]);
    }

    public static function approve(int $homeworkid): void {
        homework_repository::update($homeworkid, [
            'approvalstatus' => 'approved',
            'status' => 'approved',
            'timemodified' => time(),
        ]);
    }

    public static function cancel(int $homeworkid): void {
        homework_repository::update($homeworkid, [
            'cancelled' => 1,
            'status' => 'cancelled',
            'timemodified' => time(),
        ]);
    }

    public static function delete_bad_drafts(int $courseid, int $sectionid, string $topicname = ''): int {
        return homework_repository::delete_bad_drafts($courseid, $sectionid, $topicname);
    }

    public static function wipe_course_topic(int $courseid, int $sectionid, string $topicname = ''): array {
        $homeworks = homework_repository::delete_by_course_section_topic($courseid, $sectionid, $topicname);
        $questions = self::delete_moodle_question_bank_items($courseid, $topicname);
        return ['homeworks' => $homeworks, 'questions' => $questions];
    }

    protected static function delete_moodle_question_bank_items(int $courseid, string $topicname = ''): int {
        global $DB;
        $context = \context_course::instance($courseid);
        if (!$DB->get_manager()->table_exists('question_categories') || !$DB->get_manager()->table_exists('question')) {
            return 0;
        }
        $like = $topicname !== '' ? '%' . $DB->sql_like_escape($topicname) . '%' : '%AISGK%';
        $params = ['like1' => $like, 'like2' => $like];
        $catids = $DB->get_fieldset_select('question_categories', 'id', 'contextid = ?', [$context->id]);
        if (!$catids) {
            return 0;
        }
        list($catsql, $catparams) = $DB->get_in_or_equal($catids, SQL_PARAMS_NAMED, 'cat');
        $params = array_merge($params, $catparams);
        if ($DB->get_manager()->table_exists('question_versions') && $DB->get_manager()->table_exists('question_bank_entries')) {
            $sql = "SELECT q.id
                      FROM {question} q
                      JOIN {question_versions} qv ON qv.questionid = q.id
                      JOIN {question_bank_entries} qbe ON qbe.id = qv.questionbankentryid
                     WHERE qbe.questioncategoryid {$catsql}
                       AND (" . $DB->sql_like('q.name', ':like1', false) . " OR " . $DB->sql_like('q.questiontext', ':like2', false) . ")";
            $qids = $DB->get_fieldset_sql($sql, $params);
        } else {
            $where = "category {$catsql} AND (" . $DB->sql_like('name', ':like1', false) . " OR " . $DB->sql_like('questiontext', ':like2', false) . ")";
            $qids = $DB->get_fieldset_select('question', 'id', $where, $params);
        }
        if (!$qids) {
            return 0;
        }
        list($qsql, $qparams) = $DB->get_in_or_equal($qids, SQL_PARAMS_NAMED, 'qid');
        if ($DB->get_manager()->table_exists('question_versions')) {
            $entryids = $DB->get_fieldset_select('question_versions', 'questionbankentryid', 'questionid ' . $qsql, $qparams);
            $DB->delete_records_select('question_versions', 'questionid ' . $qsql, $qparams);
            if ($entryids && $DB->get_manager()->table_exists('question_bank_entries')) {
                $entryids = array_values(array_unique(array_map('intval', $entryids)));
                list($esql, $eparams) = $DB->get_in_or_equal($entryids, SQL_PARAMS_NAMED, 'entry');
                $DB->delete_records_select('question_bank_entries', 'id ' . $esql, $eparams);
            }
        }
        $DB->delete_records_select('question', 'id ' . $qsql, $qparams);
        return count($qids);
    }

    public static function deliver_due(): int {
        $count = 0;
        foreach (homework_repository::find_due_for_delivery(time()) as $homework) {
            self::deliver_one($homework);
            $count++;
        }
        return $count;
    }

    protected static function deliver_one(\stdClass $homework): void {
        global $CFG, $DB;
        require_once($CFG->dirroot . '/course/modlib.php');

        $course = get_course((int)$homework->courseid);
        $modinfo = get_fast_modinfo($course);
        $sectioninfo = $modinfo->get_section_info_by_id((int)$homework->sectionid);
        $sectionnum = $sectioninfo ? (int)$sectioninfo->section : 0;

        $content = trim((string)$homework->teacheredited);
        // Persist child image crops only at real delivery time. Draft preview only shows labels.
        if (strpos($content, '[IMG ') !== false || $content === '') {
            $preview = self::materialize_homework_images((int)$homework->id, ['persist_images' => true]);
            if ($preview && !empty($preview->previewteacheredited)) {
                $content = (string)$preview->previewteacheredited;
            }
        }
        if ($content === '') {
            $content = trim((string)$homework->sourcetext);
        }
        if ($content === '') {
            $content = get_string('homeworkemptydraftfallback', 'local_aisgk');
        }

        $moduleid = 0;
        $deliverymessage = '';
        try {
            $assignmodule = $DB->get_record('modules', ['name' => 'assign']);
            if ($assignmodule) {
                $moduleinfo = (object)[
                    'course' => (int)$homework->courseid,
                    'section' => $sectionnum,
                    'module' => (int)$assignmodule->id,
                    'modulename' => 'assign',
                    'name' => 'BTVN - ' . $homework->topicname,
                    'intro' => format_text($content, FORMAT_HTML),
                    'introformat' => FORMAT_HTML,
                    'alwaysshowdescription' => 1,
                    'duedate' => max(time() + 3600, (int)$homework->scheduledtime + 86400),
                    'allowsubmissionsfromdate' => (int)$homework->scheduledtime,
                    'cutoffdate' => 0,
                    'gradingduedate' => 0,
                    'grade' => 100,
                    'submissiondrafts' => 0,
                    'sendnotifications' => 0,
                    'sendlatenotifications' => 0,
                    'sendstudentnotifications' => 0,
                    'assignsubmission_onlinetext_enabled' => 1,
                    'assignsubmission_file_enabled' => 0,
                    'visible' => 1,
                ];
                $cm = add_moduleinfo($moduleinfo, $course);
                $moduleid = (int)($cm->coursemodule ?? 0);
                $deliverymessage = 'assign';
            }
        } catch (\Throwable $e) {
            $deliverymessage = 'assign-fallback';
        }

        if (!$moduleid) {
            $labelmodule = $DB->get_record('modules', ['name' => 'label'], '*', MUST_EXIST);
            $moduleinfo = (object)[
                'course' => (int)$homework->courseid,
                'section' => $sectionnum,
                'module' => (int)$labelmodule->id,
                'modulename' => 'label',
                'name' => 'BTVN - ' . $homework->topicname,
                'intro' => format_text($content, FORMAT_HTML),
                'introformat' => FORMAT_HTML,
                'visible' => 1,
            ];
            $cm = add_moduleinfo($moduleinfo, $course);
            $moduleid = (int)($cm->coursemodule ?? 0);
            $deliverymessage = $deliverymessage ?: 'label';
        }

        homework_repository::update((int)$homework->id, [
            'status' => 'delivered',
            'approvalstatus' => $homework->approvalstatus === 'pending' ? 'autoapproved' : $homework->approvalstatus,
            'deliveredtime' => time(),
            'moodlemoduleid' => $moduleid,
            'deliverymessage' => $deliverymessage,
            'timemodified' => time(),
        ]);
    }
}
