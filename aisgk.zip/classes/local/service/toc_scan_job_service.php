<?php
namespace local_aisgk\local\service;

defined('MOODLE_INTERNAL') || die();

use local_aisgk\book_repository;
use local_aisgk\local\ai_service;
use local_aisgk\local\job_manager;
use local_aisgk\local\sgk_processor;
use local_aisgk\toc_repository;

class toc_scan_job_service {
    protected static $lastusage = [];
    public static function create_job(
        int $userid,
        int $courseid,
        int $bookid,
        string $pagerange
    ): array {
        $book = book_repository::get_by_id($bookid);
        if (!$book || (int)$book->courseid !== $courseid) {
            throw new \invalid_parameter_exception('Invalid book');
        }

        [$pagefrom, $pageto] = self::parse_page_range($pagerange);
        $resourcekey = 'course:' . $courseid . ':book:' . $bookid . ':scan_toc';
        if ($existing = job_manager::find_active_by_resource($resourcekey, 'scan_toc')) {
            return ['jobid' => (int)$existing->id, 'reused' => true];
        }

        $payload = [
            'courseid' => $courseid,
            'bookid' => $bookid,
            'mode' => 'ai',
            'pagerange' => $pagefrom . '-' . $pageto,
            'pagefrom' => $pagefrom,
            'pageto' => $pageto,
        ];

        $jobid = job_manager::create('scan_toc', $userid, $resourcekey, $payload);
        return ['jobid' => $jobid, 'reused' => false];
    }

    public static function process_job(\stdClass $job): void {
        $payload = json_decode((string)$job->payloadjson, true) ?: [];
        $bookid = (int)($payload['bookid'] ?? 0);
        $courseid = (int)($payload['courseid'] ?? 0);
        $mode = 'ai';
        $pagefrom = max(1, (int)($payload['pagefrom'] ?? 5));
        $pageto = max($pagefrom, (int)($payload['pageto'] ?? $pagefrom));

        $book = book_repository::get_by_id($bookid);
        if (!$book || (int)$book->courseid !== $courseid) {
            throw new \invalid_parameter_exception('Invalid book');
        }

        job_manager::update_progress((int)$job->id, 1, 'start', 'Bắt đầu', 5, 'Đã nhận tác vụ quét mục lục.');

        $rows = self::process_ai($job, $book, $bookid, $pagefrom, $pageto);

        $rows = toc_repository::sanitize_rows($rows);
        $rows = toc_repository::calculate_end_pages($rows);
        $jsonrows = self::json_rows($rows, $book);

        $message = 'AI đã trích xuất ' . count($jsonrows) . ' dòng mục lục.';
        $result = ['rows' => $jsonrows, 'mode' => $mode, 'message' => $message];
        if (self::$lastusage) {
            $result['usage'] = self::$lastusage;
            $message .= ' Model: ' . (string)(self::$lastusage['model'] ?? '') . ' | Tokens: ' . (int)(self::$lastusage['tokens'] ?? 0) . ' | Key: ' . ((string)(self::$lastusage['keysource'] ?? 'system') === 'local_aisgk_user_ai_keys' ? 'của tôi' : 'hệ thống') . ' | Loại: ' . (string)(self::$lastusage['category'] ?? 'free') . ' | Còn ~' . (int)(self::$lastusage['remain_calls'] ?? 0) . ' lần gọi';
            $result['message'] = $message;
        }
        job_manager::mark_done((int)$job->id, $result, $message);
    }

    protected static function process_ai(\stdClass $job, \stdClass $book, int $bookid, int $pagefrom, int $pageto): array {
        job_manager::update_progress((int)$job->id, 2, 'render', 'Đang render', 18, 'Đang render trang mục lục để gửi AI...');
        sgk_processor::render_toc_images($bookid, $pagefrom, $pageto, 200);
        $images = sgk_processor::get_source_images((int)$book->courseid, $bookid);
        if (!$images) {
            throw new \moodle_exception('bookimagesmissing', 'local_aisgk');
        }
        job_manager::update_progress((int)$job->id, 3, 'ai', 'Đang gọi AI', 55, 'Đang gọi AI trích xuất mục lục...');
        $competencies = pl3_service::get_by_course((int)$book->courseid, $bookid);
        $lessonanchors = [];
        foreach ($competencies as $comp) {
            $name = trim((string)($comp->lesson_name ?? ''));
            if ($name !== '' && !in_array($name, $lessonanchors, true)) {
                $lessonanchors[] = $name;
            }
        }
        $airesult = ai_service::extract_toc_from_images($images, (int)$job->userid, [
            'bookname' => (string)($book->name ?? ''),
            'bookseries' => (string)($book->bookseries ?? ''),
            'publisher' => (string)($book->publisher ?? ''),
            'description' => (string)($book->description ?? ''),
            'lesson_anchors' => $lessonanchors,
        ]);
        $rows = $airesult['rows'] ?? [];
        $usage = $airesult['usage'] ?? [];
        $msg = 'AI đã trích xuất ' . count($rows) . ' dòng mục lục.';
        $msg .= ' Model: ' . (string)($airesult['model'] ?? '');
        $msg .= ' | Tokens: ' . (int)($airesult['tokens'] ?? 0);
        $msg .= ' | Key: ' . ((string)($airesult['keysource'] ?? 'system') === 'local_aisgk_user_ai_keys' ? 'của tôi' : 'hệ thống');
        $msg .= ' | Loại: ' . (string)($airesult['category'] ?? 'free');
        if (isset($usage['remain_calls'])) {
            $msg .= ' | Còn ~' . (int)$usage['remain_calls'] . ' lần gọi';
        }
        self::$lastusage = [
            'model' => (string)($airesult['model'] ?? ''),
            'tokens' => (int)($airesult['tokens'] ?? 0),
            'keysource' => (string)($airesult['keysource'] ?? 'system'),
            'category' => (string)($airesult['category'] ?? 'free'),
            'remain_calls' => (int)($usage['remain_calls'] ?? 0),
        ];
        job_manager::update_progress((int)$job->id, 3, 'ai_done', 'AI hoàn tất', 88, $msg);

        foreach ($rows as &$row) {
            if (is_array($row)) {
                $row['bookid'] = $bookid;
                $row['bookname'] = (string)($book->name ?: $book->filename);
            }
        }
        unset($row);
        $rows = pl3_service::match_toc_rows((int)$book->courseid, $bookid, $rows);
        return $rows;
    }

    protected static function parse_page_range(string $range): array {
        $range = trim($range);
        if (preg_match('/^(\d+)\s*-\s*(\d+)$/', $range, $m)) {
            $from = (int)$m[1];
            $to = (int)$m[2];
        } else if (preg_match('/^\d+$/', $range)) {
            $from = (int)$range;
            $to = $from;
        } else {
            $from = 0;
            $to = 0;
        }
        if ($from < 1 || $to < $from) {
            throw new \invalid_parameter_exception('TOC page range invalid');
        }
        return [$from, $to];
    }

    protected static function json_rows(array $rows, \stdClass $book): array {
        $out = [];
        foreach ($rows as $row) {
            $bookname = self::row_value($row, 'bookname', '');
            if ($bookname === '') {
                $bookname = (string)($book->name ?: $book->filename);
            }
            $out[] = [
                'bookid' => (string)self::row_value($row, 'bookid', (string)$book->id),
                'bookname' => (string)$bookname,
                'sobai' => (string)self::row_value($row, 'sobai', ''),
                'tenbai' => (string)self::row_value($row, 'tenbai', ''),
                'trang' => (string)self::row_value($row, 'trang', ''),
                'endtrang' => (string)self::row_value($row, 'endtrang', ''),
                'rawline' => (string)self::row_value($row, 'rawline', ''),
                'pl3_order' => (string)self::row_value($row, 'pl3_order', ''),
                'ai_score' => (string)self::row_value($row, 'ai_score', ''),
                'server_score' => (string)self::row_value($row, 'server_score', ''),
                'final_score' => (string)self::row_value($row, 'final_score', ''),
                'match_warning' => (string)self::row_value($row, 'match_warning', ''),
                'match_target' => (string)self::row_value($row, 'match_target', ''),
            ];
        }
        return $out;
    }

    protected static function row_value($row, string $key, $default = '') {
        if (is_array($row)) {
            return $row[$key] ?? $default;
        }
        if (is_object($row)) {
            return $row->{$key} ?? $default;
        }
        return $default;
    }
}
