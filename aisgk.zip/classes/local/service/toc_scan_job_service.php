<?php
namespace local_aisgk\local\service;

defined('MOODLE_INTERNAL') || die();

use local_aisgk\book_repository;
use local_aisgk\local\ai_service;
use local_aisgk\local\job_manager;
use local_aisgk\local\sgk_processor;
use local_aisgk\toc_repository;

class toc_scan_job_service {
    protected static $lastusage = [];
    public static function create_job(
        int $userid,
        int $courseid,
        int $bookid,
        string $mode,
        int $columns,
        int $psm,
        string $pagerange
    ): array {
        $book = book_repository::get_by_id($bookid);
        if (!$book || (int)$book->courseid !== $courseid) {
            throw new \invalid_parameter_exception('Invalid book');
        }

        [$pagefrom, $pageto] = self::parse_page_range($pagerange);
        $mode = in_array($mode, ['ocr', 'advanced', 'ai'], true) ? $mode : 'ocr';
        $columns = ($columns === 2) ? 2 : 1;
        $psm = max(3, min(13, $psm));

        $resourcekey = 'course:' . $courseid . ':book:' . $bookid . ':scan_toc';
        if ($existing = job_manager::find_active_by_resource($resourcekey, 'scan_toc')) {
            return ['jobid' => (int)$existing->id, 'reused' => true];
        }

        $payload = [
            'courseid' => $courseid,
            'bookid' => $bookid,
            'mode' => $mode,
            'columns' => $columns,
            'psm' => $psm,
            'pagerange' => $pagefrom . '-' . $pageto,
            'pagefrom' => $pagefrom,
            'pageto' => $pageto,
        ];

        $jobid = job_manager::create('scan_toc', $userid, $resourcekey, $payload);
        return ['jobid' => $jobid, 'reused' => false];
    }

    public static function process_job(\stdClass $job): void {
        $payload = json_decode((string)$job->payloadjson, true) ?: [];
        $bookid = (int)($payload['bookid'] ?? 0);
        $courseid = (int)($payload['courseid'] ?? 0);
        $mode = (string)($payload['mode'] ?? 'ocr');
        $columns = ((int)($payload['columns'] ?? 1) === 2) ? 2 : 1;
        $psm = max(3, min(13, (int)($payload['psm'] ?? 4)));
        $pagefrom = max(1, (int)($payload['pagefrom'] ?? 5));
        $pageto = max($pagefrom, (int)($payload['pageto'] ?? $pagefrom));

        $book = book_repository::get_by_id($bookid);
        if (!$book || (int)$book->courseid !== $courseid) {
            throw new \invalid_parameter_exception('Invalid book');
        }

        job_manager::update_progress((int)$job->id, 1, 'start', 'Bắt đầu', 5, 'Đã nhận tác vụ quét mục lục.');

        if ($mode === 'ai') {
            $rows = self::process_ai($job, $book, $bookid, $pagefrom, $pageto);
        } else {
            $rows = self::process_ocr($job, $book, $bookid, $columns, $psm, $pagefrom, $pageto, $mode === 'advanced');
        }

        $rows = toc_repository::sanitize_rows($rows);
        $rows = toc_repository::calculate_end_pages($rows);
        $jsonrows = self::json_rows($rows, $book);

        $message = ($mode === 'ai' ? 'AI đã trích xuất ' : 'OCR đã trích xuất ') . count($jsonrows) . ' dòng mục lục.';
        $result = ['rows' => $jsonrows, 'mode' => $mode, 'message' => $message];
        if (self::$lastusage) {
            $result['usage'] = self::$lastusage;
            $message .= ' Model: ' . (string)(self::$lastusage['model'] ?? '') . ' | Tokens: ' . (int)(self::$lastusage['tokens'] ?? 0) . ' | Key: ' . ((string)(self::$lastusage['keysource'] ?? 'system') === 'local_aisgk_user_ai_keys' ? 'của tôi' : 'hệ thống') . ' | Loại: ' . (string)(self::$lastusage['category'] ?? 'free') . ' | Còn ~' . (int)(self::$lastusage['remain_calls'] ?? 0) . ' lần gọi';
            $result['message'] = $message;
        }
        job_manager::mark_done((int)$job->id, $result, $message);
    }

    protected static function process_ocr(\stdClass $job, \stdClass $book, int $bookid, int $columns, int $psm, int $pagefrom, int $pageto, bool $advanced): array {
        job_manager::update_progress((int)$job->id, 2, 'render', 'Đang xử lý', 15, 'Đang render trang mục lục...');
        if ($advanced) {
            $preview = sgk_processor::preview_topic_items_advanced(
                $bookid,
                $columns,
                50,
                $psm,
                $pagefrom,
                $pageto,
                static function(array $progress) use ($job): void {
                    $step = (int)($progress['step'] ?? 2);
                    $base = [1 => 20, 2 => 45, 3 => 72, 4 => 90];
                    $percent = $base[$step] ?? 35;
                    job_manager::update_progress(
                        (int)$job->id,
                        min(3, max(1, $step)),
                        'advanced',
                        'Advanced scan',
                        $percent,
                        (string)($progress['message'] ?? 'Đang Advanced scan...')
                    );
                }
            );
        } else {
            job_manager::update_progress((int)$job->id, 2, 'ocr', 'Đang OCR', 40, 'Đang OCR mục lục...');
            $preview = sgk_processor::preview_topic_items($bookid, $columns, 50, $psm, $pagefrom, $pageto);
        }

        $rows = [];
        foreach (($preview['items'] ?? []) as $item) {
            $rows[] = [
                'bookid' => $bookid,
                'bookname' => (string)($book->name ?: $book->filename),
                'sobai' => $item['lessonno'] ?? '',
                'tenbai' => $item['lessontitle'] ?? '',
                'trang' => $item['startpage'] ?? '',
                'endtrang' => $item['endpage'] ?? '',
                'rawline' => $item['rawocr'] ?? '',
            ];
        }
        job_manager::update_progress((int)$job->id, 3, 'rows', 'Kết quả', 92, 'Đã nhận dạng xong, đang chuẩn hóa dòng mục lục...');
        return $rows;
    }

    protected static function process_ai(\stdClass $job, \stdClass $book, int $bookid, int $pagefrom, int $pageto): array {
        job_manager::update_progress((int)$job->id, 2, 'render', 'Đang render', 18, 'Đang render trang mục lục để gửi AI...');
        sgk_processor::render_toc_images($bookid, $pagefrom, $pageto, 200);
        $images = sgk_processor::get_source_images((int)$book->courseid, $bookid);
        if (!$images) {
            throw new \moodle_exception('bookimagesmissing', 'local_aisgk');
        }
        job_manager::update_progress((int)$job->id, 3, 'ai', 'Đang gọi AI', 55, 'Đang gọi AI trích xuất mục lục...');
        $airesult = ai_service::extract_toc_from_images($images, (int)$job->userid);
        $rows = $airesult['rows'] ?? [];
        $usage = $airesult['usage'] ?? [];
        $msg = 'AI đã trích xuất ' . count($rows) . ' dòng mục lục.';
        $msg .= ' Model: ' . (string)($airesult['model'] ?? '');
        $msg .= ' | Tokens: ' . (int)($airesult['tokens'] ?? 0);
        $msg .= ' | Key: ' . ((string)($airesult['keysource'] ?? 'system') === 'local_aisgk_user_ai_keys' ? 'của tôi' : 'hệ thống');
        $msg .= ' | Loại: ' . (string)($airesult['category'] ?? 'free');
        if (isset($usage['remain_calls'])) {
            $msg .= ' | Còn ~' . (int)$usage['remain_calls'] . ' lần gọi';
        }
        self::$lastusage = [
            'model' => (string)($airesult['model'] ?? ''),
            'tokens' => (int)($airesult['tokens'] ?? 0),
            'keysource' => (string)($airesult['keysource'] ?? 'system'),
            'category' => (string)($airesult['category'] ?? 'free'),
            'remain_calls' => (int)($usage['remain_calls'] ?? 0),
        ];
        job_manager::update_progress((int)$job->id, 3, 'ai_done', 'AI hoàn tất', 88, $msg);

        foreach ($rows as &$row) {
            if (is_array($row)) {
                $row['bookid'] = $bookid;
                $row['bookname'] = (string)($book->name ?: $book->filename);
            }
        }
        unset($row);
        return $rows;
    }

    protected static function parse_page_range(string $range): array {
        $range = trim($range);
        if (preg_match('/^(\d+)\s*-\s*(\d+)$/', $range, $m)) {
            $from = (int)$m[1];
            $to = (int)$m[2];
        } else if (preg_match('/^\d+$/', $range)) {
            $from = (int)$range;
            $to = $from;
        } else {
            $from = 0;
            $to = 0;
        }
        if ($from < 1 || $to < $from) {
            throw new \invalid_parameter_exception('TOC page range invalid');
        }
        return [$from, $to];
    }

    protected static function json_rows(array $rows, \stdClass $book): array {
        $out = [];
        foreach ($rows as $row) {
            $bookname = self::row_value($row, 'bookname', '');
            if ($bookname === '') {
                $bookname = (string)($book->name ?: $book->filename);
            }
            $out[] = [
                'bookid' => (string)self::row_value($row, 'bookid', (string)$book->id),
                'bookname' => (string)$bookname,
                'sobai' => (string)self::row_value($row, 'sobai', ''),
                'tenbai' => (string)self::row_value($row, 'tenbai', ''),
                'trang' => (string)self::row_value($row, 'trang', ''),
                'endtrang' => (string)self::row_value($row, 'endtrang', ''),
                'rawline' => (string)self::row_value($row, 'rawline', ''),
            ];
        }
        return $out;
    }

    protected static function row_value($row, string $key, $default = '') {
        if (is_array($row)) {
            return $row[$key] ?? $default;
        }
        if (is_object($row)) {
            return $row->{$key} ?? $default;
        }
        return $default;
    }
}
