<?php
namespace local_aisgk\local\service;

defined('MOODLE_INTERNAL') || die();

class pl3_service {

    public static function parse_uploaded_pl3(array $uploadedfile, int $courseid, int $bookid = 0): array {
        if (empty($uploadedfile['tmp_name']) || !is_uploaded_file($uploadedfile['tmp_name'])) {
            throw new \moodle_exception('nofile', 'local_aisgk');
        }
        if (!empty($uploadedfile['error']) && (int)$uploadedfile['error'] !== UPLOAD_ERR_OK) {
            throw new \moodle_exception('uploaderrorserver', 'local_aisgk', '', $uploadedfile['error']);
        }
        $filename = clean_param($uploadedfile['name'], PARAM_FILE);
        $ext = strtolower(pathinfo($filename, PATHINFO_EXTENSION));
        if (!in_array($ext, ['docx', 'doc'], true)) {
            throw new \moodle_exception('invalidfiletype', 'local_aisgk', '', 'Chỉ chấp nhận file PL3 .doc hoặc .docx');
        }
        $path = $uploadedfile['tmp_name'];
        if ($ext === 'doc') {
            $path = self::convert_doc_to_docx($path);
        }
        return self::parse_docx($path, $courseid, $bookid);
    }

    protected static function convert_doc_to_docx(string $docpath): string {
        $outdir = make_temp_directory('local_aisgk_pl3');
        $bin = trim((string)@shell_exec('command -v libreoffice || command -v soffice'));
        if ($bin === '') {
            throw new \moodle_exception('invalidfiletype', 'local_aisgk', '', 'Máy chủ chưa có LibreOffice để đọc file .doc. Vui lòng dùng .docx.');
        }
        $cmd = escapeshellcmd($bin) . ' --headless --convert-to docx --outdir ' . escapeshellarg($outdir) . ' ' . escapeshellarg($docpath) . ' 2>&1';
        @shell_exec($cmd);
        $files = glob($outdir . '/*.docx');
        if (!$files) {
            throw new \moodle_exception('invalidfiletype', 'local_aisgk', '', 'Không chuyển được file .doc sang .docx. Vui lòng lưu lại PL3 dưới dạng .docx.');
        }
        return $files[0];
    }

    protected static function parse_docx(string $docxpath, int $courseid, int $bookid = 0): array {
        $zip = new \ZipArchive();
        if ($zip->open($docxpath) !== true) {
            throw new \moodle_exception('invalidfiletype', 'local_aisgk', '', 'Không đọc được file docx.');
        }
        $xml = $zip->getFromName('word/document.xml');
        $zip->close();
        if (!$xml) {
            throw new \moodle_exception('invalidfiletype', 'local_aisgk', '', 'File docx không có word/document.xml.');
        }

        $dom = new \DOMDocument();
        $dom->preserveWhiteSpace = false;
        @$dom->loadXML($xml);
        $xp = new \DOMXPath($dom);
        $xp->registerNamespace('w', 'http://schemas.openxmlformats.org/wordprocessingml/2006/main');

        $pl3tables = self::pl3_table_rows($xp);
        if (!$pl3tables) {
            throw new \moodle_exception('invalidfiletype', 'local_aisgk', '', 'Không tìm thấy bảng PL3 phù hợp trong file.');
        }

        // Flatten all valid PL3 rows first so we can decide semester scope safely.
        // Priority 1: explicit leading paragraph markers: "Học kì 1", "Học kỳ II", "HK2".
        // Priority 2: if no marker exists, split by cumulative periods from column 3.
        $rawrows = [];
        $hasexplicitsemester = false;
        $lessonorder = 0;
        foreach ($pl3tables as $table) {
            $tablesemester = (int)($table['semester_hint'] ?? 0);
            if ($tablesemester > 0) {
                $hasexplicitsemester = true;
            }
            foreach (($table['rows'] ?? []) as $cells) {
                $colcount = count($cells);
                if ($colcount < 7 || $colcount > 9) {
                    continue;
                }
                $lesson = self::clean_text($cells[1] ?? '');
                if ($lesson === '' || self::looks_like_header($lesson)) {
                    continue;
                }
                $yccd = self::clean_text($cells[$colcount - 2] ?? '');
                $nls = self::clean_text($cells[$colcount - 1] ?? '');
                if ($yccd === '' && $nls === '') {
                    continue;
                }
                $lessonorder++;
                $rawrows[] = [
                    'courseid' => $courseid,
                    'bookid' => $bookid,
                    'lesson_order' => $lessonorder,
                    'lesson' => $lesson,
                    'periods' => self::parse_period_count((string)($cells[2] ?? '')),
                    // PL3 column 4 is usually a text cell but often contains the running
                    // lesson/period number. Keep it during import so the HK fallback can
                    // split by the actual teaching timeline instead of by row count.
                    'period_marker_text' => self::clean_text((string)($cells[3] ?? '')),
                    'semester' => $tablesemester,
                    'yccd' => $yccd,
                    'nls' => $nls,
                ];
            }
        }

        if (!$rawrows) {
            throw new \moodle_exception('invalidfiletype', 'local_aisgk', '', 'Không đọc được dòng dữ liệu PL3 phù hợp trong file.');
        }

        if (!$hasexplicitsemester) {
            $splitindex = self::find_semester_split_index_by_period_marker($rawrows);
            if ($splitindex !== null) {
                foreach ($rawrows as $i => $r) {
                    $rawrows[$i]['semester'] = ($i <= $splitindex) ? 1 : 2;
                }
            } else {
                // Last-resort fallback only: use cumulative lesson periods from column 3.
                // Prefer the column-4 marker split above because one PL3 row may span
                // multiple periods, so splitting by row count or running column-3 periods
                // can move the HK boundary to the wrong lesson.
                $totalperiods = 0;
                foreach ($rawrows as $r) {
                    $totalperiods += max(0, (int)($r['periods'] ?? 0));
                }
                if ($totalperiods > 0) {
                    $half = $totalperiods / 2.0;
                    $running = 0;
                    foreach ($rawrows as $i => $r) {
                        $running += max(0, (int)($r['periods'] ?? 0));
                        $rawrows[$i]['semester'] = ($running <= $half) ? 1 : 2;
                    }
                } else {
                    $cut = (int)ceil(count($rawrows) / 2);
                    foreach ($rawrows as $i => $r) {
                        $rawrows[$i]['semester'] = ($i < $cut) ? 1 : 2;
                    }
                }
            }
        } else {
            // Fill missing table markers by carrying the previous explicit semester.
            $lastsemester = 0;
            foreach ($rawrows as $i => $r) {
                if ((int)$r['semester'] > 0) {
                    $lastsemester = (int)$r['semester'];
                } else if ($lastsemester > 0) {
                    $rawrows[$i]['semester'] = $lastsemester;
                }
            }
        }

        $rows = [];
        foreach ($rawrows as $r) {
            $competencies = array_merge(
                self::split_competency_text((string)$r['yccd'], true),
                self::split_competency_text((string)$r['nls'], true)
            );
            $levelcounts = ['nhan_biet' => 0, 'thong_hieu' => 0, 'van_dung' => 0, '' => 0];
            foreach ($competencies as $item) {
                $text = self::clean_text((string)($item['text'] ?? ''));
                if ($text === '') {
                    continue;
                }
                $level = (string)($item['level'] ?? '');
                if (!array_key_exists($level, $levelcounts)) {
                    $level = '';
                }
                $levelcounts[$level]++;
                $rows[] = [
                    'courseid' => $courseid,
                    'bookid' => $bookid,
                    'tocid' => 0,
                    'lesson_order' => (int)$r['lesson_order'],
                    'lesson_name' => self::normalize_lesson_title((string)$r['lesson']),
                    'lesson_periods' => max(0, (int)$r['periods']),
                    'semester' => max(0, (int)$r['semester']),
                    'competency_code' => self::make_code((int)$r['lesson_order'], $level, $levelcounts[$level]),
                    'level' => $level,
                    'competency_text' => $text,
                ];
            }
        }
        return $rows;
    }


    /**
     * Return every PL3-like table, not only the largest one. A valid PL3 data
     * table normally has 7-9 columns; column 1 and 3 are numeric/order-ish,
     * column 2/4/5/6 are text-ish, and the final two columns contain YCCĐ/NLS.
     * This handles PL3 files split into HK1/HK2 tables and teacher-modified
     * templates while still skipping small signature/layout tables.
     *
     * @return array<int,array<int,array<int,string>>>
     */
    /**
     * Return every PL3-like table, not only the largest one, preserving the
     * semester marker immediately before each table when present. A semester
     * marker is accepted only when it starts a paragraph, e.g. "Học kì 1",
     * "Học kỳ II", "HK2".
     *
     * @return array<int,array{semester_hint:int,rows:array<int,array<int,string>>}>
     */
    protected static function pl3_table_rows(\DOMXPath $xp): array {
        $tables = [];
        $currentsemester = 0;
        $body = $xp->query('//w:body')->item(0);
        if (!$body) {
            return [];
        }

        foreach ($body->childNodes as $node) {
            if (!$node instanceof \DOMElement) {
                continue;
            }
            if ($node->localName === 'p') {
                $ptext = self::paragraph_text($xp, $node);
                $detected = self::detect_semester_marker($ptext);
                if ($detected > 0) {
                    $currentsemester = $detected;
                }
                continue;
            }
            if ($node->localName !== 'tbl') {
                continue;
            }

            $rows = [];
            $validdatarows = 0;
            $haspl3headers = false;
            $maxcols = 0;
            $nonempty = 0;

            foreach ($xp->query('./w:tr', $node) as $tr) {
                $cells = [];
                foreach ($xp->query('./w:tc', $tr) as $tc) {
                    $text = self::cell_text($xp, $tc);
                    $cells[] = $text;
                    if (trim($text) !== '') {
                        $nonempty++;
                    }
                }
                if (!$cells) {
                    continue;
                }
                $maxcols = max($maxcols, count($cells));
                $joined = self::remove_accents(implode(' ', $cells));
                if ((strpos($joined, 'bai hoc') !== false || strpos($joined, 'ten bai') !== false)
                        && (strpos($joined, 'yeu cau can dat') !== false || strpos($joined, 'nang luc') !== false)) {
                    $haspl3headers = true;
                }

                if (self::is_pl3_data_row($cells)) {
                    $validdatarows++;
                    $rows[] = $cells;
                }
            }

            if ($maxcols < 7 || $maxcols > 9) {
                continue;
            }
            if ($validdatarows < 2 && !$haspl3headers) {
                continue;
            }
            if ($validdatarows < 1) {
                continue;
            }
            if (($validdatarows * 100 + $nonempty) < 210) {
                continue;
            }
            $tables[] = ['semester_hint' => $currentsemester, 'rows' => $rows];
        }
        return $tables;
    }

    protected static function paragraph_text(\DOMXPath $xp, \DOMNode $p): string {
        $parts = [];
        foreach ($xp->query('.//w:t', $p) as $t) {
            $parts[] = $t->textContent;
        }
        return self::clean_text(implode('', $parts));
    }

    protected static function detect_semester_marker(string $text): int {
        $norm = self::normalize_semester_text($text);
        // Must be at the very beginning of a paragraph after spaces/bullets.
        if (preg_match('/^\s*(?:[-–—•*]+\s*)?(?:hoc\s*k[iy]|hk)\s*[:.\-–—]?\s*(1|2|i|ii)\b/u', $norm, $m)) {
            $v = strtolower($m[1]);
            return ($v === '2' || $v === 'ii') ? 2 : 1;
        }
        return 0;
    }

    protected static function normalize_semester_text(string $text): string {
        $text = mb_strtolower(self::remove_accents($text), 'UTF-8');
        $text = preg_replace('/[^a-z0-9\s:\.\-–—•*]+/u', ' ', $text) ?? $text;
        $text = preg_replace('/\s+/u', ' ', $text) ?? $text;
        return trim($text);
    }

    protected static function parse_period_count(string $text): int {
        $text = self::remove_accents(self::clean_text($text));
        if (preg_match('/\d+/u', $text, $m)) {
            return max(0, (int)$m[0]);
        }
        return 0;
    }

    /**
     * Fallback HK split for PL3 files without explicit HK markers.
     *
     * The correct split is based on total periods from column 3, but the boundary
     * row must be found in column 4 because one lesson row may have more than one
     * period. Column 4 is a text cell in real PL3 files, so extract integers from
     * it and choose the row whose number is closest to total_periods / 2. In normal
     * school PL3s this number is equal to the midpoint or off by one.
     *
     * @param array<int,array<string,mixed>> $rawrows
     * @return int|null zero-based split row index; rows <= index are HK1.
     */
    protected static function find_semester_split_index_by_period_marker(array $rawrows): ?int {
        $totalperiods = 0;
        foreach ($rawrows as $r) {
            $totalperiods += max(0, (int)($r['periods'] ?? 0));
        }
        if ($totalperiods <= 0 || !$rawrows) {
            return null;
        }

        $mid = (int)round($totalperiods / 2);
        if ($mid <= 0) {
            return null;
        }

        $bestindex = null;
        $bestdiff = PHP_INT_MAX;
        foreach ($rawrows as $i => $r) {
            $text = self::remove_accents(self::clean_text((string)($r['period_marker_text'] ?? '')));
            if ($text === '') {
                continue;
            }
            if (!preg_match_all('/\d+/u', $text, $m)) {
                continue;
            }
            foreach ($m[0] as $numtxt) {
                $num = (int)$numtxt;
                if ($num <= 0) {
                    continue;
                }
                $diff = abs($num - $mid);
                if ($diff < $bestdiff) {
                    $bestdiff = $diff;
                    $bestindex = (int)$i;
                }
                // Exact match is the strongest signal; stop searching.
                if ($diff === 0) {
                    return (int)$i;
                }
            }
        }

        // Only trust the text marker when it is equal or off by one. This matches
        // the real PL3 convention and avoids false splits caused by unrelated text
        // numbers in column 4.
        if ($bestindex !== null && $bestdiff <= 1) {
            return $bestindex;
        }
        return null;
    }


    protected static function is_pl3_data_row(array $cells): bool {
        $colcount = count($cells);
        if ($colcount < 7 || $colcount > 9) {
            return false;
        }
        $c1 = self::clean_text((string)($cells[0] ?? ''));
        $c2 = self::clean_text((string)($cells[1] ?? ''));
        $c3 = self::clean_text((string)($cells[2] ?? ''));
        $c4 = self::clean_text((string)($cells[3] ?? ''));
        $c5 = self::clean_text((string)($cells[4] ?? ''));
        $c6 = self::clean_text((string)($cells[5] ?? ''));
        $last1 = self::clean_text((string)($cells[$colcount - 2] ?? ''));
        $last2 = self::clean_text((string)($cells[$colcount - 1] ?? ''));

        if ($c2 === '' || self::looks_like_header($c2)) {
            return false;
        }
        if (!self::looks_numericish($c1) || !self::looks_numericish($c3)) {
            return false;
        }
        // Columns 2,4,5,6 should be text-ish in real rows; at least column 2 and
        // one of 4/5/6 must contain letters to avoid numeric layout tables.
        if (!self::has_letters($c2)) {
            return false;
        }
        if (!self::has_letters($c4 . ' ' . $c5 . ' ' . $c6)) {
            return false;
        }
        // We need something useful in one of the last two columns to save.
        if ($last1 === '' && $last2 === '') {
            return false;
        }
        return true;
    }

    protected static function looks_numericish(string $text): bool {
        $text = trim($text);
        if ($text === '') {
            return false;
        }
        return (bool)preg_match('/\d/u', $text) && !self::has_letters($text);
    }

    protected static function has_letters(string $text): bool {
        return (bool)preg_match('/\p{L}/u', $text);
    }

    protected static function cell_text(\DOMXPath $xp, \DOMNode $tc): string {
        $paras = [];
        foreach ($xp->query('.//w:p', $tc) as $p) {
            $parts = [];
            foreach ($xp->query('.//w:t', $p) as $t) {
                $parts[] = $t->textContent;
            }
            $line = trim(implode('', $parts));
            if ($line !== '') {
                $paras[] = $line;
            }
        }
        return trim(implode("\n", $paras));
    }

    protected static function clean_text(string $text): string {
        $text = html_entity_decode($text, ENT_QUOTES | ENT_HTML5, 'UTF-8');
        $text = preg_replace('/[\x{00A0}\t]+/u', ' ', $text);
        $text = preg_replace('/\r\n|\r/u', "\n", $text);
        $text = preg_replace('/[ ]*\n[ ]*/u', "\n", $text);
        $text = preg_replace('/\n{3,}/u', "\n\n", $text);
        return trim($text);
    }

    protected static function looks_like_header(string $text): bool {
        $norm = \core_text::strtolower(self::remove_accents($text));
        return strpos($norm, 'bai hoc') !== false || strpos($norm, 'yeu cau can dat') !== false || strpos($norm, 'nang luc') !== false;
    }

    /**
     * Split a PL3 YCCĐ/NLS cell into one record per concrete competency.
     *
     * Teachers often type level headings in many formats: "Nhận biết", "Biết",
     * "NB", "Thông hiểu", "Hiểu", "TH", "Vận dụng", "Làm", "VD" and may
     * decorate them with bullets/asterisks. A level heading is only accepted when
     * the keyword appears near the start of a line, so normal content like
     * "Học sinh biết..." in the middle of a sentence is not mistaken for a new
     * level. Empty/missing sections do not create DB rows.
     *
     * @return array<int,array{level:string,text:string}>
     */
    protected static function split_competency_text(string $text, bool $allowlevel = true): array {
        $text = self::clean_text($text);
        if ($text === '') {
            return [];
        }

        $text = self::break_inline_level_markers($text);
        $lines = preg_split('/\n+/u', $text);
        $out = [];
        $currentlevel = '';
        $context = '';

        foreach ($lines as $line) {
            $line = self::clean_text((string)$line);
            if ($line === '') {
                continue;
            }

            $detected = $allowlevel ? self::detect_level_heading($line) : null;
            if ($detected !== null) {
                $currentlevel = $detected['level'];
                $context = '';
                $after = self::clean_item_text((string)$detected['after']);
                // Headings such as "Nhận biết", "NB:" or "Nhận biết (2)" are
                // only section switches. They must not create blank competencies.
                if ($after !== '') {
                    if (self::looks_like_context_line($after)) {
                        $context = $after;
                    } else {
                        $out[] = ['level' => $currentlevel, 'text' => $after];
                    }
                }
                continue;
            }

            $item = self::clean_item_text($line);
            if ($item === '') {
                continue;
            }
            if (self::looks_like_context_line($item)) {
                $context = $item;
                continue;
            }
            if (mb_strlen($item, 'UTF-8') < 6) {
                continue;
            }
            $textout = $context !== '' ? $context . ' ' . $item : $item;
            $out[] = ['level' => $currentlevel, 'text' => $textout];
        }

        // Some NLS cells are one plain line without explicit levels. Keep them as
        // competencies with blank level, but never keep pure section headings.
        if (!$out && $text !== '') {
            $fallback = self::clean_item_text($text);
            if ($fallback !== '' && self::detect_level_heading($fallback) === null) {
                $out[] = ['level' => '', 'text' => $fallback];
            }
        }

        $seen = [];
        $unique = [];
        foreach ($out as $row) {
            $key = ($row['level'] ?? '') . '|' . self::canonical_text($row['text'] ?? '');
            if (isset($seen[$key])) {
                continue;
            }
            $seen[$key] = true;
            $unique[] = ['level' => (string)($row['level'] ?? ''), 'text' => (string)($row['text'] ?? '')];
        }
        return $unique;
    }



    /**
     * Put inline level markers on separate lines before parsing.
     *
     * Many PL3 cells are typed as one paragraph, for example:
     * "NB: ... TH: ... VD: ...". The line-based parser below needs each
     * marker to start a line, so split only clear marker tokens followed by
     * a colon. This avoids mistaking normal words like "biết" inside a
     * sentence for headings.
     */
    protected static function break_inline_level_markers(string $text): string {
        $pattern = '/(?<![\p{L}\p{N}])'
            . '(' 
            . 'nhận\s*biết|nhan\s*biet|biết|biet|nhớ|nho|nb'
            . '|thông\s*hiểu|thong\s*hieu|hiểu|hieu|th'
            . '|vận\s*dụng(?:\s*cao)?|van\s*dung(?:\s*cao)?|làm|lam|thực\s*hiện|thuc\s*hien|vd|vdc'
            . ')'
            . '\s*[:：]/iu';
        $out = preg_replace_callback($pattern, static function(array $m): string {
            return "\n" . trim($m[1]) . ':';
        }, $text);
        return self::clean_text((string)($out ?? $text));
    }

    protected static function detect_level_heading(string $line): ?array {
        $raw = trim($line);
        if ($raw === '') {
            return null;
        }

        // Remove leading decoration only for matching. Keep original line for the
        // trailing content returned to caller.
        $stripped = preg_replace('/^[^\p{L}\p{N}]{0,30}/u', '', $raw);
        if ($stripped === null) {
            $stripped = $raw;
        }

        $patterns = [
            'nhan_biet' => [
                '/^(nhận\s*biết|nhan\s*biet|biết|biet|nhớ|nho|nb)\b/iu',
            ],
            'thong_hieu' => [
                '/^(thông\s*hiểu|thong\s*hieu|hiểu|hieu|th)\b/iu',
            ],
            'van_dung' => [
                '/^(vận\s*dụng(?:\s*cao)?|van\s*dung(?:\s*cao)?|làm|lam|thực\s*hiện|thuc\s*hien|vd|vdc)\b/iu',
            ],
        ];

        foreach ($patterns as $level => $list) {
            foreach ($list as $pattern) {
                if (preg_match($pattern, $stripped, $m, PREG_OFFSET_CAPTURE)) {
                    $kw = $m[1][0];
                    $kwpos = (int)$m[1][1];
                    // Keyword must be near the visual start of the stripped line.
                    if ($kwpos > 20) {
                        continue;
                    }
                    $after = mb_substr($stripped, $kwpos + mb_strlen($kw, 'UTF-8'), null, 'UTF-8');
                    $after = preg_replace('/^\s*(?:\(\s*\d+\s*\))?\s*/u', '', (string)$after);
                    $after = preg_replace('/^[^\p{L}\p{N}]+/u', '', (string)$after);
                    return ['level' => $level, 'after' => self::clean_text((string)$after)];
                }
            }
        }
        return null;
    }

    protected static function clean_item_text(string $line): string {
        $line = self::clean_text($line);
        $line = preg_replace('/^[\s\-*•●–—+!#\.\)\(\[\]]+/u', '', $line);
        $line = preg_replace('/^[a-zA-Z]\s*[\)\.]\s*/u', '', (string)$line);
        $line = preg_replace('/^\d+\s*\)\s*/u', '', (string)$line);
        $line = preg_replace('/^\d+\.(?!\d)\s*/u', '', (string)$line);
        $line = preg_replace('/^\s*(?:\(\s*\d+\s*\))\s*$/u', '', (string)$line);
        return trim((string)$line, " \t\n\r\0\x0B:-–—•*");
    }

    protected static function looks_like_context_line(string $line): bool {
        $line = trim($line);
        if ($line === '') {
            return false;
        }
        if (preg_match('/[:：]$/u', $line) && mb_strlen($line, 'UTF-8') < 120) {
            return true;
        }
        $norm = self::canonical_text($line);
        return in_array($norm, ['trong cac tinh huong cu the co san', 'trong cac tinh huong cu the'], true);
    }

    protected static function canonical_text(string $text): string {
        $text = self::remove_accents($text);
        $text = preg_replace('/[^a-z0-9]+/u', ' ', $text);
        return trim((string)$text);
    }

    protected static function normalize_lesson_title(string $lesson): string {
        $lesson = self::clean_text($lesson);
        $lesson = preg_replace('/^Chủ\s*đề\s*\d+\s*\.?.*?\n/iu', '', $lesson);
        $lesson = preg_replace('/^\s*Bài\s+(\d+)\s*[\.:\-]?\s*/iu', 'Bài $1. ', $lesson);
        $lesson = preg_replace('/\n+/u', ' - ', $lesson);
        return trim($lesson);
    }

    protected static function make_code(int $lessonorder, string $level, int $n): string {
        $suffix = self::level_suffix($level);
        return sprintf('B%03d_%s%03d', max(1, $lessonorder), $suffix, max(1, $n));
    }

    protected static function level_suffix(string $level): string {
        switch ($level) {
            case 'nhan_biet': return 'NB';
            case 'thong_hieu': return 'TH';
            case 'van_dung': return 'VD';
            default: return 'NL';
        }
    }

    protected static function remove_accents(string $text): string {
        if (function_exists('transliterator_transliterate')) {
            $converted = transliterator_transliterate('Any-Latin; Latin-ASCII', $text);
            if ($converted !== false) {
                return $converted;
            }
        }
        $map = [
            'à'=>'a','á'=>'a','ạ'=>'a','ả'=>'a','ã'=>'a','â'=>'a','ầ'=>'a','ấ'=>'a','ậ'=>'a','ẩ'=>'a','ẫ'=>'a','ă'=>'a','ằ'=>'a','ắ'=>'a','ặ'=>'a','ẳ'=>'a','ẵ'=>'a',
            'è'=>'e','é'=>'e','ẹ'=>'e','ẻ'=>'e','ẽ'=>'e','ê'=>'e','ề'=>'e','ế'=>'e','ệ'=>'e','ể'=>'e','ễ'=>'e',
            'ì'=>'i','í'=>'i','ị'=>'i','ỉ'=>'i','ĩ'=>'i','ò'=>'o','ó'=>'o','ọ'=>'o','ỏ'=>'o','õ'=>'o','ô'=>'o','ồ'=>'o','ố'=>'o','ộ'=>'o','ổ'=>'o','ỗ'=>'o','ơ'=>'o','ờ'=>'o','ớ'=>'o','ợ'=>'o','ở'=>'o','ỡ'=>'o',
            'ù'=>'u','ú'=>'u','ụ'=>'u','ủ'=>'u','ũ'=>'u','ư'=>'u','ừ'=>'u','ứ'=>'u','ự'=>'u','ử'=>'u','ữ'=>'u','ỳ'=>'y','ý'=>'y','ỵ'=>'y','ỷ'=>'y','ỹ'=>'y','đ'=>'d'
        ];
        return strtr(mb_strtolower($text, 'UTF-8'), $map);
    }

    public static function save_competencies(int $courseid, int $bookid, array $rows): int {
        global $DB, $USER;
        if (!self::has_nls_catalog()) {
            throw new \moodle_exception('nlscatalogmissing', 'local_aisgk');
        }
        $DB->delete_records('local_aisgk_competencies', ['courseid' => $courseid, 'bookid' => $bookid]);
        $now = time();
        $count = 0;
        foreach ($rows as $row) {
            $lesson = trim((string)($row['lesson_name'] ?? ''));
            $code = trim((string)($row['competency_code'] ?? ''));
            $text = trim((string)($row['competency_text'] ?? ''));
            $level = clean_param((string)($row['level'] ?? ''), PARAM_ALPHANUMEXT);
            if (!in_array($level, ['nhan_biet', 'thong_hieu', 'van_dung'], true)) {
                $level = '';
            }
            if ($lesson === '' || $code === '' || $text === '') {
                continue;
            }
            $rec = new \stdClass();
            $rec->courseid = $courseid;
            $rec->bookid = $bookid;
            $rec->tocid = (int)($row['tocid'] ?? 0);
            $rec->lesson_order = max(1, (int)($row['lesson_order'] ?? 1));
            $rec->lesson_name = $lesson;
            $columns = $DB->get_columns('local_aisgk_competencies');
            if (isset($columns['semester'])) {
                $rec->semester = max(0, (int)($row['semester'] ?? 0));
            }
            if (isset($columns['lesson_periods'])) {
                $rec->lesson_periods = max(0, (int)($row['lesson_periods'] ?? 0));
            }
            $rec->competency_code = clean_param($code, PARAM_TEXT);
            $rec->level = $level;
            $rec->competency_text = clean_param($text, PARAM_TEXT);
            $rec->timecreated = $now;
            $rec->timemodified = $now;
            $rec->usermodified = $USER->id;
            $DB->insert_record('local_aisgk_competencies', $rec);
            $count++;
        }
        return $count;
    }


    protected static function has_nls_catalog(): bool {
        global $DB;
        $candidates = [
            'local_aisgk_nls_indicator_grade',
            'local_aisgk_nls_items',
            'local_aisgk_nls_master',
            'local_alsm_nls_indicator_grade',
            'local_alsm_nls_items',
            'local_alsm_nls_master',
        ];
        foreach ($candidates as $table) {
            try {
                if ($DB->get_manager()->table_exists($table) && $DB->count_records($table) > 0) {
                    return true;
                }
            } catch (\Throwable $e) {
                // Ignore candidate names that are not installed on this site.
            }
        }
        return false;
    }

    public static function delete_competencies(int $courseid, int $bookid = 0): int {
        global $DB;
        if ($bookid > 0) {
            return (int)$DB->delete_records('local_aisgk_competencies', ['courseid' => $courseid, 'bookid' => $bookid]);
        }
        return (int)$DB->delete_records('local_aisgk_competencies', ['courseid' => $courseid]);
    }

    public static function save_competency_groups(int $courseid, int $bookid, array $groups): int {
        $rows = self::expand_group_rows($groups);
        return self::save_competencies($courseid, $bookid, $rows);
    }

    public static function group_rows(array $rows): array {
        $groups = [];
        foreach ($rows as $r) {
            $lessonorder = is_object($r) ? (int)$r->lesson_order : (int)($r['lesson_order'] ?? 0);
            $lessonname = is_object($r) ? (string)$r->lesson_name : (string)($r['lesson_name'] ?? '');
            $level = is_object($r) ? (string)($r->level ?? '') : (string)($r['level'] ?? '');
            $code = is_object($r) ? (string)$r->competency_code : (string)($r['competency_code'] ?? '');
            $text = is_object($r) ? (string)$r->competency_text : (string)($r['competency_text'] ?? '');
            $key = $lessonorder . '|' . $lessonname;
            if (!isset($groups[$key])) {
                $groups[$key] = [
                    'lesson_order' => $lessonorder,
                    'lesson_name' => $lessonname,
                    'codes' => [],
                    'nhan_biet' => [],
                    'thong_hieu' => [],
                    'van_dung' => [],
                    'other' => [],
                ];
            }
            if ($code !== '') {
                $groups[$key]['codes'][] = $code;
            }
            $line = $code !== '' ? ($code . ': ' . $text) : $text;
            if (isset($groups[$key][$level])) {
                $groups[$key][$level][] = $line;
            } else {
                $groups[$key]['other'][] = $line;
            }
        }
        return array_values($groups);
    }

    protected static function expand_group_rows(array $groups): array {
        $rows = [];
        foreach ($groups as $group) {
            if (!is_array($group)) {
                continue;
            }
            $lessonorder = max(1, (int)($group['lesson_order'] ?? 1));
            $lessonname = trim((string)($group['lesson_name'] ?? ''));
            if ($lessonname === '') {
                continue;
            }
            foreach (['nhan_biet', 'thong_hieu', 'van_dung'] as $level) {
                $textblock = (string)($group[$level] ?? '');
                $lines = preg_split('/\n+/u', $textblock);
                $idx = 0;
                foreach ($lines as $line) {
                    $line = trim((string)$line);
                    if ($line === '') {
                        continue;
                    }
                    $idx++;
                    $code = '';
                    $text = $line;
                    if (preg_match('/^([A-Z0-9_\.-]+)\s*[:：-]\s*(.+)$/u', $line, $m)) {
                        $code = trim($m[1]);
                        $text = trim($m[2]);
                    }
                    if ($code === '') {
                        $code = self::make_code($lessonorder, $level, $idx);
                    }
                    if ($text === '') {
                        continue;
                    }
                    $rows[] = [
                        'lesson_order' => $lessonorder,
                        'lesson_name' => $lessonname,
                        'competency_code' => $code,
                        'level' => $level,
                        'competency_text' => $text,
                        'tocid' => 0,
                    ];
                }
            }
        }
        return $rows;
    }

    public static function get_by_course(int $courseid, int $bookid = 0): array {
        global $DB;
        $params = ['courseid' => $courseid];
        $where = 'courseid = :courseid';
        if ($bookid > 0) {
            $where .= ' AND bookid = :bookid';
            $params['bookid'] = $bookid;
        }
        return array_values($DB->get_records_select('local_aisgk_competencies', $where, $params, 'lesson_order ASC, level ASC, id ASC'));
    }

    public static function normalize_match_text(string $text): string {
        $text = mb_strtolower(self::remove_accents($text), 'UTF-8');
        $text = preg_replace('/\b(chuong|chuong trinh|chu de|bai hoc|bai|tiet|phan|trang|sgk)\b/u', ' ', $text) ?? $text;
        $text = preg_replace('/[^a-z0-9]+/u', ' ', $text) ?? $text;
        $text = trim(preg_replace('/\s+/u', ' ', $text) ?? $text);
        return $text;
    }

    public static function similarity(string $a, string $b): float {
        $a = self::normalize_match_text($a);
        $b = self::normalize_match_text($b);
        if ($a === '' || $b === '') {
            return 0.0;
        }
        if ($a === $b) {
            return 1.0;
        }
        similar_text($a, $b, $pct);
        $char = max(0.0, min(1.0, ((float)$pct) / 100.0));
        $ta = array_values(array_unique(array_filter(explode(' ', $a))));
        $tb = array_values(array_unique(array_filter(explode(' ', $b))));
        $ia = array_values(array_intersect($ta, $tb));
        $union = array_unique(array_merge($ta, $tb));
        $jaccard = $union ? (count($ia) / count($union)) : 0.0;
        $containment = min(count($ta), count($tb)) > 0 ? (count($ia) / min(count($ta), count($tb))) : 0.0;
        $substring = (mb_strpos($a, $b) !== false || mb_strpos($b, $a) !== false) ? 0.88 : 0.0;
        $score = max($char, $jaccard, $containment * 0.95, $substring);

        // Penalise different explicit lesson numbers, but keep them useful when equal.
        preg_match_all('/\b\d+\b/u', $a, $ma);
        preg_match_all('/\b\d+\b/u', $b, $mb);
        $na = $ma[0] ?? [];
        $nb = $mb[0] ?? [];
        if ($na && $nb) {
            $common = array_intersect($na, $nb);
            if (!$common) {
                $score = min($score, 0.72);
            } else {
                $score = min(1.0, $score + 0.05);
            }
        }
        return max(0.0, min(1.0, $score));
    }

    protected static function competency_lessons_for_match(int $courseid, int $bookid): array {
        $sets = [];
        if ($bookid > 0) {
            $sets[] = self::get_by_course($courseid, $bookid);
        }
        // PL3 may have been imported before a concrete textbook/file row was chosen,
        // or a user may save an older TOC from a different book row in the same course.
        // Always keep a course-wide fallback so server_score is still computed.
        $sets[] = self::get_by_course($courseid, 0);

        foreach ($sets as $competencies) {
            $lessons = self::lesson_map_from_competencies($competencies);
            if (!$lessons) {
                continue;
            }
            $scoped = self::scope_lessons_for_book($courseid, $bookid, $lessons);
            if ($scoped) {
                return $scoped;
            }
            return $lessons;
        }
        return [];
    }

    /**
     * Lesson anchors sent to AI must use the same scope as server-side matching.
     * This prevents scanning SGK tập 2/HK2 while AI sees PL3 anchors from HK1 first.
     */
    public static function lesson_anchors_for_book(int $courseid, int $bookid): array {
        $lessons = self::competency_lessons_for_match($courseid, $bookid);
        $out = [];
        foreach ($lessons as $lesson) {
            $name = trim((string)($lesson['name'] ?? ''));
            if ($name !== '' && !in_array($name, $out, true)) {
                $out[] = $name;
            }
        }
        return $out;
    }

    protected static function lesson_map_from_competencies(array $competencies): array {
        $lessons = [];
        foreach ($competencies as $comp) {
            $order = (int)($comp->lesson_order ?? 0);
            $name = trim((string)($comp->lesson_name ?? ''));
            if ($order < 1 || $name === '') {
                continue;
            }
            if (!isset($lessons[$order])) {
                $lessons[$order] = [
                    'order' => $order,
                    'name' => $name,
                    'semester' => (int)($comp->semester ?? 0),
                    'periods' => (int)($comp->lesson_periods ?? 0),
                ];
            } else {
                if (empty($lessons[$order]['semester']) && !empty($comp->semester)) {
                    $lessons[$order]['semester'] = (int)$comp->semester;
                }
                if (empty($lessons[$order]['periods']) && !empty($comp->lesson_periods)) {
                    $lessons[$order]['periods'] = (int)$comp->lesson_periods;
                }
            }
        }
        ksort($lessons);
        return $lessons;
    }


    protected static function scope_lessons_for_book(int $courseid, int $bookid, array $lessons): array {
        $scope = self::infer_book_semester_scope($courseid, $bookid);
        if ($scope < 1 || count($lessons) < 2) {
            return $lessons;
        }

        // Prefer explicit semester imported from PL3 marker/table.
        $hassemester = false;
        foreach ($lessons as $lesson) {
            if (!empty($lesson['semester'])) {
                $hassemester = true;
                break;
            }
        }
        if ($hassemester) {
            $scoped = [];
            foreach ($lessons as $order => $lesson) {
                if ((int)($lesson['semester'] ?? 0) === $scope) {
                    $scoped[$order] = $lesson;
                }
            }
            return $scoped ?: $lessons;
        }

        // Fallback: split by cumulative periods from PL3 column 3. If periods are
        // not available (old imports), split by count as the last resort.
        $totalperiods = 0;
        foreach ($lessons as $lesson) {
            $totalperiods += max(0, (int)($lesson['periods'] ?? 0));
        }
        if ($totalperiods > 0) {
            $half = $totalperiods / 2.0;
            $running = 0;
            $scoped = [];
            foreach ($lessons as $order => $lesson) {
                $running += max(0, (int)($lesson['periods'] ?? 0));
                $semester = ($running <= $half) ? 1 : 2;
                if ($semester === $scope) {
                    $scoped[$order] = $lesson;
                }
            }
            return $scoped ?: $lessons;
        }

        $orders = array_keys($lessons);
        $cut = (int)ceil(count($orders) / 2);
        $keep = ($scope === 1) ? array_slice($orders, 0, $cut) : array_slice($orders, $cut);
        $scoped = [];
        foreach ($keep as $order) {
            if (isset($lessons[$order])) {
                $scoped[$order] = $lessons[$order];
            }
        }
        return $scoped ?: $lessons;
    }


    /**
     * Infer SGK tập/học kỳ from selected book. Prefer explicit metadata/name, then
     * fall back to combo order when a course has exactly two textbook records.
     * Returns 1 for tập/HK1, 2 for tập/HK2, 0 when unknown.
     */
    protected static function infer_book_semester_scope(int $courseid, int $bookid): int {
        global $DB;
        if ($bookid < 1) {
            return 0;
        }
        $book = $DB->get_record('local_aisgk_books', ['id' => $bookid]);
        if (!$book) {
            return 0;
        }
        // Use all available text columns of the selected SGK after lowercasing and
        // accent removal. Detect compact forms too: "tập1", "tap1", "tập 1".
        $text = implode(' ', [
            (string)($book->name ?? ''),
            (string)($book->filename ?? ''),
            (string)($book->bookseries ?? ''),
            (string)($book->publisher ?? ''),
            (string)($book->description ?? ''),
        ]);
        $norm = self::remove_accents(mb_strtolower($text, 'UTF-8'));
        $compact = preg_replace('/\s+/u', '', $norm) ?? $norm;
        if (preg_match('/(^|[^a-z0-9])(?:tap|hk|hocky|hocki|quyen)\s*1([^a-z0-9]|$)/u', $norm)
                || preg_match('/(?:tap1|hk1|hocky1|hoc ki1|hocki1|quyen1)/u', $compact)) {
            return 1;
        }
        if (preg_match('/(^|[^a-z0-9])(?:tap|hk|hocky|hocki|quyen)\s*2([^a-z0-9]|$)/u', $norm)
                || preg_match('/(?:tap2|hk2|hocky2|hoc ki2|hocki2|quyen2)/u', $compact)) {
            return 2;
        }

        // If the text does not reveal the part, use SGK id/order within the course.
        $books = array_values($DB->get_records('local_aisgk_books', ['courseid' => $courseid], 'id ASC'));
        if (count($books) >= 2) {
            foreach ($books as $idx => $b) {
                if ((int)$b->id === $bookid) {
                    return $idx === 0 ? 1 : 2;
                }
            }
        }
        return 0;
    }


    public static function match_toc_rows(int $courseid, int $bookid, array $tocrows): array {
        $lessons = self::competency_lessons_for_match($courseid, $bookid);
        $scope = self::infer_book_semester_scope($courseid, $bookid);
        if (!$lessons) {
            foreach ($tocrows as $idx => $row) {
                self::set_toc_match_fields($tocrows[$idx], 0, 0, 0, 0, 'Chưa có dữ liệu PL3 để tính score', '');
            }
            return $tocrows;
        }

        $used = [];
        $indexes = array_keys($tocrows);
        if ($scope === 2) {
            // SGK tập 2/HK2: compare from the bottom upward. This avoids HK2 ending
            // lessons being pulled toward earlier low-similarity PL3 rows. Skip low
            // matches until the first strong anchor (>=90%) is found.
            $indexes = array_reverse($indexes);
        }
        $hk2anchorfound = ($scope !== 2);

        foreach ($indexes as $idx) {
            $row = $tocrows[$idx];
            $title = '';
            if (is_array($row)) {
                $title = trim((string)($row['tenbai'] ?? $row['title'] ?? ''));
                if ($title === '') { $title = trim((string)($row['rawline'] ?? '')); }
                $aiorder = (int)($row['pl3_order'] ?? 0);
                $aiscore = self::score_value($row['ai_score'] ?? 0);
            } else {
                $title = trim((string)($row->tenbai ?? $row->title ?? ''));
                if ($title === '') { $title = trim((string)($row->rawline ?? '')); }
                $aiorder = (int)($row->pl3_order ?? 0);
                $aiscore = self::score_value($row->ai_score ?? 0);
            }

            $available = [];
            foreach ($lessons as $order => $lesson) {
                if (!isset($used[$order])) {
                    $available[$order] = $lesson;
                }
            }
            if ($scope === 2) {
                krsort($available);
            } else {
                ksort($available);
            }

            $bestorder = 0;
            $bestscore = 0.0;
            $besttarget = '';
            $final = 0.0;
            $warning = '';

            if (!$available) {
                $warning = 'Không còn bài PL3 chưa dùng để đối chiếu';
            } else {
                foreach ($available as $order => $lesson) {
                    $score = self::similarity($title, (string)$lesson['name']);
                    if ($score > $bestscore) {
                        $bestscore = $score;
                        $bestorder = (int)$order;
                        $besttarget = (string)$lesson['name'];
                    }
                }
                if ($aiorder > 0 && isset($available[$aiorder])) {
                    $aiserverscore = self::similarity($title, (string)$available[$aiorder]['name']);
                    if ($aiserverscore >= 0.70 || ($aiserverscore >= 0.55 && $aiscore >= 0.80)) {
                        $bestorder = $aiorder;
                        $bestscore = max($bestscore, $aiserverscore);
                        $besttarget = (string)$available[$aiorder]['name'];
                    }
                }

                if ($scope === 2 && !$hk2anchorfound && $bestscore < 0.90) {
                    $warning = 'HK2: bỏ qua dòng khớp thấp trước khi gặp neo >=90%';
                    $bestorder = 0;
                    $final = $bestscore;
                } else {
                    if ($scope === 2 && $bestscore >= 0.90) {
                        $hk2anchorfound = true;
                    }
                    $final = $bestscore;
                    if ($aiscore > 0) {
                        $final = ($bestscore + $aiscore) / 2.0;
                    }
                    if ($bestorder < 1 || $final < 0.55) {
                        $warning = 'Không khớp PL3 chắc chắn';
                        $bestorder = 0;
                    } else if ($final < 0.75) {
                        $warning = 'Khớp PL3 thấp, cần kiểm tra';
                    }
                    if ($bestorder > 0) {
                        $used[$bestorder] = true;
                    }
                }
            }
            self::set_toc_match_fields($tocrows[$idx], $bestorder, $aiscore, $bestscore, $final, $warning, $besttarget);
        }
        return $tocrows;
    }

    protected static function set_toc_match_fields(&$row, int $pl3order, float $aiscore, float $serverscore, float $finalscore, string $warning, string $target): void {
        if (is_array($row)) {
            $row['pl3_order'] = $pl3order;
            $row['ai_score'] = $aiscore;
            $row['server_score'] = $serverscore;
            $row['final_score'] = $finalscore;
            $row['match_warning'] = $warning;
            $row['match_target'] = $target;
        } else {
            $row->pl3_order = $pl3order;
            $row->ai_score = $aiscore;
            $row->server_score = $serverscore;
            $row->final_score = $finalscore;
            $row->match_warning = $warning;
            $row->match_target = $target;
        }
    }


    protected static function score_value($value): float {
        if (!is_numeric($value)) {
            return 0.0;
        }
        $score = (float)$value;
        if ($score > 1) {
            $score = $score / 100.0;
        }
        return max(0.0, min(1.0, $score));
    }

    public static function match_toc_rows_by_context(int $courseid, int $selectedbookid, array $tocrows): array {
        foreach ($tocrows as $idx => $row) {
            $rowbookid = 0;
            if (is_array($row)) {
                $rowbookid = (int)($row['bookid'] ?? 0);
                if ($rowbookid < 1 && $selectedbookid > 0) {
                    $tocrows[$idx]['bookid'] = $selectedbookid;
                }
            } else if (is_object($row)) {
                $rowbookid = (int)($row->bookid ?? 0);
                if ($rowbookid < 1 && $selectedbookid > 0) {
                    $tocrows[$idx]->bookid = $selectedbookid;
                }
            }
        }

        // Use the full course PL3 pool and consume each PL3 lesson once. This keeps
        // Save working the same whether the UI is set to All or a specific textbook.
        return self::match_toc_rows($courseid, 0, $tocrows);
    }

    public static function update_toc_links_for_course(int $courseid, array $savedtocrows): int {
        global $DB;
        $DB->set_field('local_aisgk_competencies', 'tocid', 0, ['courseid' => $courseid]);
        $updated = 0;
        foreach ($savedtocrows as $toc) {
            $tocid = (int)($toc->id ?? 0);
            $pl3order = (int)($toc->pl3_order ?? 0);
            if ($tocid < 1 || $pl3order < 1) {
                continue;
            }
            $updated += $DB->set_field('local_aisgk_competencies', 'tocid', $tocid, [
                'courseid' => $courseid,
                'lesson_order' => $pl3order,
            ]);
        }
        return $updated;
    }

    public static function update_toc_links(int $courseid, int $bookid, array $savedtocrows): int {
        global $DB;
        $DB->set_field('local_aisgk_competencies', 'tocid', 0, ['courseid' => $courseid, 'bookid' => $bookid]);
        if ($bookid > 0) {
            // Also clear course-level PL3 rows, because older imports may have bookid=0.
            $DB->set_field('local_aisgk_competencies', 'tocid', 0, ['courseid' => $courseid, 'bookid' => 0]);
        }
        $updated = 0;
        foreach ($savedtocrows as $toc) {
            $tocid = (int)($toc->id ?? 0);
            $pl3order = (int)($toc->pl3_order ?? 0);
            if ($tocid < 1 || $pl3order < 1) {
                continue;
            }
            $updated += $DB->set_field('local_aisgk_competencies', 'tocid', $tocid, [
                'courseid' => $courseid,
                'bookid' => $bookid,
                'lesson_order' => $pl3order,
            ]);
            if ($bookid > 0) {
                $updated += $DB->set_field('local_aisgk_competencies', 'tocid', $tocid, [
                    'courseid' => $courseid,
                    'bookid' => 0,
                    'lesson_order' => $pl3order,
                ]);
            }
        }
        return $updated;
    }

}
