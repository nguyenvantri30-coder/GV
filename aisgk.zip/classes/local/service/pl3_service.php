<?php
namespace local_aisgk\local\service;

defined('MOODLE_INTERNAL') || die();

class pl3_service {

    public static function parse_uploaded_pl3(array $uploadedfile, int $courseid, int $bookid = 0): array {
        if (empty($uploadedfile['tmp_name']) || !is_uploaded_file($uploadedfile['tmp_name'])) {
            throw new \moodle_exception('nofile', 'local_aisgk');
        }
        if (!empty($uploadedfile['error']) && (int)$uploadedfile['error'] !== UPLOAD_ERR_OK) {
            throw new \moodle_exception('uploaderrorserver', 'local_aisgk', '', $uploadedfile['error']);
        }
        $filename = clean_param($uploadedfile['name'], PARAM_FILE);
        $ext = strtolower(pathinfo($filename, PATHINFO_EXTENSION));
        if (!in_array($ext, ['docx', 'doc'], true)) {
            throw new \moodle_exception('invalidfiletype', 'local_aisgk', '', 'Chỉ chấp nhận file PL3 .doc hoặc .docx');
        }
        $path = $uploadedfile['tmp_name'];
        if ($ext === 'doc') {
            $path = self::convert_doc_to_docx($path);
        }
        return self::parse_docx($path, $courseid, $bookid);
    }

    protected static function convert_doc_to_docx(string $docpath): string {
        $outdir = make_temp_directory('local_aisgk_pl3');
        $bin = trim((string)@shell_exec('command -v libreoffice || command -v soffice'));
        if ($bin === '') {
            throw new \moodle_exception('invalidfiletype', 'local_aisgk', '', 'Máy chủ chưa có LibreOffice để đọc file .doc. Vui lòng dùng .docx.');
        }
        $cmd = escapeshellcmd($bin) . ' --headless --convert-to docx --outdir ' . escapeshellarg($outdir) . ' ' . escapeshellarg($docpath) . ' 2>&1';
        @shell_exec($cmd);
        $files = glob($outdir . '/*.docx');
        if (!$files) {
            throw new \moodle_exception('invalidfiletype', 'local_aisgk', '', 'Không chuyển được file .doc sang .docx. Vui lòng lưu lại PL3 dưới dạng .docx.');
        }
        return $files[0];
    }

    protected static function parse_docx(string $docxpath, int $courseid, int $bookid = 0): array {
        $zip = new \ZipArchive();
        if ($zip->open($docxpath) !== true) {
            throw new \moodle_exception('invalidfiletype', 'local_aisgk', '', 'Không đọc được file docx.');
        }
        $xml = $zip->getFromName('word/document.xml');
        $zip->close();
        if (!$xml) {
            throw new \moodle_exception('invalidfiletype', 'local_aisgk', '', 'File docx không có word/document.xml.');
        }

        $dom = new \DOMDocument();
        $dom->preserveWhiteSpace = false;
        @$dom->loadXML($xml);
        $xp = new \DOMXPath($dom);
        $xp->registerNamespace('w', 'http://schemas.openxmlformats.org/wordprocessingml/2006/main');

        $tablerows = self::largest_table_rows($xp);
        if (!$tablerows) {
            throw new \moodle_exception('invalidfiletype', 'local_aisgk', '', 'Không tìm thấy bảng PL3 phù hợp trong file.');
        }

        $rows = [];
        $lessonorder = 0;
        $lastlesson = '';
        $lastlessonorder = 0;

        foreach ($tablerows as $cells) {
            // PL3 main rows must have exactly the fixed template columns. Rows
            // merged for section/chapter titles usually have fewer cells and must
            // not be parsed as lessons.
            if (count($cells) < 8) {
                continue;
            }
            $lesson = self::clean_text($cells[1] ?? '');
            $yccd = self::clean_text($cells[6] ?? '');
            $nls = self::clean_text($cells[7] ?? '');
            if ($lesson === '' || self::looks_like_header($lesson)) {
                continue;
            }
            if (!preg_match('/\bBài\s*\d+\b/iu', $lesson) && $yccd === '' && $nls === '') {
                continue;
            }
            if ($lesson !== '') {
                $lessonorder++;
                $lastlesson = $lesson;
                $lastlessonorder = $lessonorder;
            } else if ($lastlesson !== '') {
                $lesson = $lastlesson;
                $lessonorder = $lastlessonorder;
            }
            $competencies = array_merge(
                self::split_competency_text($yccd, true),
                self::split_competency_text($nls, true)
            );
            $levelcounts = ['nhan_biet' => 0, 'thong_hieu' => 0, 'van_dung' => 0, '' => 0];
            foreach ($competencies as $item) {
                $text = self::clean_text((string)($item['text'] ?? ''));
                if ($text === '') {
                    continue;
                }
                $level = (string)($item['level'] ?? '');
                if (!array_key_exists($level, $levelcounts)) {
                    $level = '';
                }
                $levelcounts[$level]++;
                $rows[] = [
                    'courseid' => $courseid,
                    'bookid' => $bookid,
                    'tocid' => 0,
                    'lesson_order' => $lessonorder,
                    'lesson_name' => self::normalize_lesson_title($lesson),
                    'competency_code' => self::make_code($lessonorder, $level, $levelcounts[$level]),
                    'level' => $level,
                    'competency_text' => $text,
                ];
            }
        }
        return $rows;
    }

    /**
     * PL3 files usually contain several small layout/signature tables and one large
     * distribution table. Read only the largest table so column indexes 2/7/8 stay
     * aligned with the fixed PL3 template.
     *
     * @return array<int,array<int,string>>
     */
    protected static function largest_table_rows(\DOMXPath $xp): array {
        $bestrows = [];
        $bestscore = -1;
        foreach ($xp->query('//w:tbl') as $tbl) {
            $rows = [];
            $rowcount = 0;
            $maxcols = 0;
            $nonempty = 0;
            $haspl3headers = false;

            foreach ($xp->query('./w:tr', $tbl) as $tr) {
                $cells = [];
                foreach ($xp->query('./w:tc', $tr) as $tc) {
                    $text = self::cell_text($xp, $tc);
                    $cells[] = $text;
                    if (trim($text) !== '') {
                        $nonempty++;
                    }
                }
                if (!$cells) {
                    continue;
                }
                $joined = self::remove_accents(implode(' ', $cells));
                if (strpos($joined, 'bai hoc') !== false && strpos($joined, 'yeu cau can dat') !== false) {
                    $haspl3headers = true;
                }
                $rowcount++;
                $maxcols = max($maxcols, count($cells));
                $rows[] = $cells;
            }

            // The fixed PL3 table has at least 7 columns. Skip small header/footer
            // tables even if they appear before the main table.
            if ($rowcount < 2 || $maxcols < 8) {
                continue;
            }

            $score = ($rowcount * 1000) + ($maxcols * 100) + $nonempty;
            if ($haspl3headers) {
                $score += 1000000;
            }
            if ($score > $bestscore) {
                $bestscore = $score;
                $bestrows = $rows;
            }
        }
        return $bestrows;
    }

    protected static function cell_text(\DOMXPath $xp, \DOMNode $tc): string {
        $paras = [];
        foreach ($xp->query('.//w:p', $tc) as $p) {
            $parts = [];
            foreach ($xp->query('.//w:t', $p) as $t) {
                $parts[] = $t->textContent;
            }
            $line = trim(implode('', $parts));
            if ($line !== '') {
                $paras[] = $line;
            }
        }
        return trim(implode("\n", $paras));
    }

    protected static function clean_text(string $text): string {
        $text = html_entity_decode($text, ENT_QUOTES | ENT_HTML5, 'UTF-8');
        $text = preg_replace('/[\x{00A0}\t]+/u', ' ', $text);
        $text = preg_replace('/\r\n|\r/u', "\n", $text);
        $text = preg_replace('/[ ]*\n[ ]*/u', "\n", $text);
        $text = preg_replace('/\n{3,}/u', "\n\n", $text);
        return trim($text);
    }

    protected static function looks_like_header(string $text): bool {
        $norm = \core_text::strtolower(self::remove_accents($text));
        return strpos($norm, 'bai hoc') !== false || strpos($norm, 'yeu cau can dat') !== false || strpos($norm, 'nang luc') !== false;
    }

    /**
     * Split a PL3 YCCĐ/NLS cell into one record per concrete competency.
     *
     * Teachers often type level headings in many formats: "Nhận biết", "Biết",
     * "NB", "Thông hiểu", "Hiểu", "TH", "Vận dụng", "Làm", "VD" and may
     * decorate them with bullets/asterisks. A level heading is only accepted when
     * the keyword appears near the start of a line, so normal content like
     * "Học sinh biết..." in the middle of a sentence is not mistaken for a new
     * level. Empty/missing sections do not create DB rows.
     *
     * @return array<int,array{level:string,text:string}>
     */
    protected static function split_competency_text(string $text, bool $allowlevel = true): array {
        $text = self::clean_text($text);
        if ($text === '') {
            return [];
        }

        $text = self::break_inline_level_markers($text);
        $lines = preg_split('/\n+/u', $text);
        $out = [];
        $currentlevel = '';
        $context = '';

        foreach ($lines as $line) {
            $line = self::clean_text((string)$line);
            if ($line === '') {
                continue;
            }

            $detected = $allowlevel ? self::detect_level_heading($line) : null;
            if ($detected !== null) {
                $currentlevel = $detected['level'];
                $context = '';
                $after = self::clean_item_text((string)$detected['after']);
                // Headings such as "Nhận biết", "NB:" or "Nhận biết (2)" are
                // only section switches. They must not create blank competencies.
                if ($after !== '') {
                    if (self::looks_like_context_line($after)) {
                        $context = $after;
                    } else {
                        $out[] = ['level' => $currentlevel, 'text' => $after];
                    }
                }
                continue;
            }

            $item = self::clean_item_text($line);
            if ($item === '') {
                continue;
            }
            if (self::looks_like_context_line($item)) {
                $context = $item;
                continue;
            }
            if (mb_strlen($item, 'UTF-8') < 6) {
                continue;
            }
            $textout = $context !== '' ? $context . ' ' . $item : $item;
            $out[] = ['level' => $currentlevel, 'text' => $textout];
        }

        // Some NLS cells are one plain line without explicit levels. Keep them as
        // competencies with blank level, but never keep pure section headings.
        if (!$out && $text !== '') {
            $fallback = self::clean_item_text($text);
            if ($fallback !== '' && self::detect_level_heading($fallback) === null) {
                $out[] = ['level' => '', 'text' => $fallback];
            }
        }

        $seen = [];
        $unique = [];
        foreach ($out as $row) {
            $key = ($row['level'] ?? '') . '|' . self::canonical_text($row['text'] ?? '');
            if (isset($seen[$key])) {
                continue;
            }
            $seen[$key] = true;
            $unique[] = ['level' => (string)($row['level'] ?? ''), 'text' => (string)($row['text'] ?? '')];
        }
        return $unique;
    }



    /**
     * Put inline level markers on separate lines before parsing.
     *
     * Many PL3 cells are typed as one paragraph, for example:
     * "NB: ... TH: ... VD: ...". The line-based parser below needs each
     * marker to start a line, so split only clear marker tokens followed by
     * a colon. This avoids mistaking normal words like "biết" inside a
     * sentence for headings.
     */
    protected static function break_inline_level_markers(string $text): string {
        $pattern = '/(?<![\p{L}\p{N}])'
            . '(' 
            . 'nhận\s*biết|nhan\s*biet|biết|biet|nhớ|nho|nb'
            . '|thông\s*hiểu|thong\s*hieu|hiểu|hieu|th'
            . '|vận\s*dụng(?:\s*cao)?|van\s*dung(?:\s*cao)?|làm|lam|thực\s*hiện|thuc\s*hien|vd|vdc'
            . ')'
            . '\s*[:：]/iu';
        $out = preg_replace_callback($pattern, static function(array $m): string {
            return "\n" . trim($m[1]) . ':';
        }, $text);
        return self::clean_text((string)($out ?? $text));
    }

    protected static function detect_level_heading(string $line): ?array {
        $raw = trim($line);
        if ($raw === '') {
            return null;
        }

        // Remove leading decoration only for matching. Keep original line for the
        // trailing content returned to caller.
        $stripped = preg_replace('/^[^\p{L}\p{N}]{0,30}/u', '', $raw);
        if ($stripped === null) {
            $stripped = $raw;
        }

        $patterns = [
            'nhan_biet' => [
                '/^(nhận\s*biết|nhan\s*biet|biết|biet|nhớ|nho|nb)\b/iu',
            ],
            'thong_hieu' => [
                '/^(thông\s*hiểu|thong\s*hieu|hiểu|hieu|th)\b/iu',
            ],
            'van_dung' => [
                '/^(vận\s*dụng(?:\s*cao)?|van\s*dung(?:\s*cao)?|làm|lam|thực\s*hiện|thuc\s*hien|vd|vdc)\b/iu',
            ],
        ];

        foreach ($patterns as $level => $list) {
            foreach ($list as $pattern) {
                if (preg_match($pattern, $stripped, $m, PREG_OFFSET_CAPTURE)) {
                    $kw = $m[1][0];
                    $kwpos = (int)$m[1][1];
                    // Keyword must be near the visual start of the stripped line.
                    if ($kwpos > 20) {
                        continue;
                    }
                    $after = mb_substr($stripped, $kwpos + mb_strlen($kw, 'UTF-8'), null, 'UTF-8');
                    $after = preg_replace('/^\s*(?:\(\s*\d+\s*\))?\s*/u', '', (string)$after);
                    $after = preg_replace('/^[^\p{L}\p{N}]+/u', '', (string)$after);
                    return ['level' => $level, 'after' => self::clean_text((string)$after)];
                }
            }
        }
        return null;
    }

    protected static function clean_item_text(string $line): string {
        $line = self::clean_text($line);
        $line = preg_replace('/^[\s\-*•●–—+!#\.\)\(\[\]]+/u', '', $line);
        $line = preg_replace('/^[a-zA-Z]\s*[\)\.]\s*/u', '', (string)$line);
        $line = preg_replace('/^\d+\s*\)\s*/u', '', (string)$line);
        $line = preg_replace('/^\d+\.(?!\d)\s*/u', '', (string)$line);
        $line = preg_replace('/^\s*(?:\(\s*\d+\s*\))\s*$/u', '', (string)$line);
        return trim((string)$line, " \t\n\r\0\x0B:-–—•*");
    }

    protected static function looks_like_context_line(string $line): bool {
        $line = trim($line);
        if ($line === '') {
            return false;
        }
        if (preg_match('/[:：]$/u', $line) && mb_strlen($line, 'UTF-8') < 120) {
            return true;
        }
        $norm = self::canonical_text($line);
        return in_array($norm, ['trong cac tinh huong cu the co san', 'trong cac tinh huong cu the'], true);
    }

    protected static function canonical_text(string $text): string {
        $text = self::remove_accents($text);
        $text = preg_replace('/[^a-z0-9]+/u', ' ', $text);
        return trim((string)$text);
    }

    protected static function normalize_lesson_title(string $lesson): string {
        $lesson = self::clean_text($lesson);
        $lesson = preg_replace('/^Chủ\s*đề\s*\d+\s*\.?.*?\n/iu', '', $lesson);
        $lesson = preg_replace('/^\s*Bài\s+(\d+)\s*[\.:\-]?\s*/iu', 'Bài $1. ', $lesson);
        $lesson = preg_replace('/\n+/u', ' - ', $lesson);
        return trim($lesson);
    }

    protected static function make_code(int $lessonorder, string $level, int $n): string {
        $suffix = self::level_suffix($level);
        return sprintf('B%03d_%s%03d', max(1, $lessonorder), $suffix, max(1, $n));
    }

    protected static function level_suffix(string $level): string {
        switch ($level) {
            case 'nhan_biet': return 'NB';
            case 'thong_hieu': return 'TH';
            case 'van_dung': return 'VD';
            default: return 'NL';
        }
    }

    protected static function remove_accents(string $text): string {
        if (function_exists('transliterator_transliterate')) {
            $converted = transliterator_transliterate('Any-Latin; Latin-ASCII', $text);
            if ($converted !== false) {
                return $converted;
            }
        }
        $map = [
            'à'=>'a','á'=>'a','ạ'=>'a','ả'=>'a','ã'=>'a','â'=>'a','ầ'=>'a','ấ'=>'a','ậ'=>'a','ẩ'=>'a','ẫ'=>'a','ă'=>'a','ằ'=>'a','ắ'=>'a','ặ'=>'a','ẳ'=>'a','ẵ'=>'a',
            'è'=>'e','é'=>'e','ẹ'=>'e','ẻ'=>'e','ẽ'=>'e','ê'=>'e','ề'=>'e','ế'=>'e','ệ'=>'e','ể'=>'e','ễ'=>'e',
            'ì'=>'i','í'=>'i','ị'=>'i','ỉ'=>'i','ĩ'=>'i','ò'=>'o','ó'=>'o','ọ'=>'o','ỏ'=>'o','õ'=>'o','ô'=>'o','ồ'=>'o','ố'=>'o','ộ'=>'o','ổ'=>'o','ỗ'=>'o','ơ'=>'o','ờ'=>'o','ớ'=>'o','ợ'=>'o','ở'=>'o','ỡ'=>'o',
            'ù'=>'u','ú'=>'u','ụ'=>'u','ủ'=>'u','ũ'=>'u','ư'=>'u','ừ'=>'u','ứ'=>'u','ự'=>'u','ử'=>'u','ữ'=>'u','ỳ'=>'y','ý'=>'y','ỵ'=>'y','ỷ'=>'y','ỹ'=>'y','đ'=>'d'
        ];
        return strtr(mb_strtolower($text, 'UTF-8'), $map);
    }

    public static function save_competencies(int $courseid, int $bookid, array $rows): int {
        global $DB, $USER;
        $DB->delete_records('local_aisgk_competencies', ['courseid' => $courseid, 'bookid' => $bookid]);
        $now = time();
        $count = 0;
        foreach ($rows as $row) {
            $lesson = trim((string)($row['lesson_name'] ?? ''));
            $code = trim((string)($row['competency_code'] ?? ''));
            $text = trim((string)($row['competency_text'] ?? ''));
            $level = clean_param((string)($row['level'] ?? ''), PARAM_ALPHANUMEXT);
            if (!in_array($level, ['nhan_biet', 'thong_hieu', 'van_dung'], true)) {
                $level = '';
            }
            if ($lesson === '' || $code === '' || $text === '') {
                continue;
            }
            $rec = new \stdClass();
            $rec->courseid = $courseid;
            $rec->bookid = $bookid;
            $rec->tocid = (int)($row['tocid'] ?? 0);
            $rec->lesson_order = max(1, (int)($row['lesson_order'] ?? 1));
            $rec->lesson_name = $lesson;
            $rec->competency_code = clean_param($code, PARAM_TEXT);
            $rec->level = $level;
            $rec->competency_text = clean_param($text, PARAM_TEXT);
            $rec->timecreated = $now;
            $rec->timemodified = $now;
            $rec->usermodified = $USER->id;
            $DB->insert_record('local_aisgk_competencies', $rec);
            $count++;
        }
        return $count;
    }

    public static function save_competency_groups(int $courseid, int $bookid, array $groups): int {
        $rows = self::expand_group_rows($groups);
        return self::save_competencies($courseid, $bookid, $rows);
    }

    public static function group_rows(array $rows): array {
        $groups = [];
        foreach ($rows as $r) {
            $lessonorder = is_object($r) ? (int)$r->lesson_order : (int)($r['lesson_order'] ?? 0);
            $lessonname = is_object($r) ? (string)$r->lesson_name : (string)($r['lesson_name'] ?? '');
            $level = is_object($r) ? (string)($r->level ?? '') : (string)($r['level'] ?? '');
            $code = is_object($r) ? (string)$r->competency_code : (string)($r['competency_code'] ?? '');
            $text = is_object($r) ? (string)$r->competency_text : (string)($r['competency_text'] ?? '');
            $key = $lessonorder . '|' . $lessonname;
            if (!isset($groups[$key])) {
                $groups[$key] = [
                    'lesson_order' => $lessonorder,
                    'lesson_name' => $lessonname,
                    'codes' => [],
                    'nhan_biet' => [],
                    'thong_hieu' => [],
                    'van_dung' => [],
                    'other' => [],
                ];
            }
            if ($code !== '') {
                $groups[$key]['codes'][] = $code;
            }
            $line = $code !== '' ? ($code . ': ' . $text) : $text;
            if (isset($groups[$key][$level])) {
                $groups[$key][$level][] = $line;
            } else {
                $groups[$key]['other'][] = $line;
            }
        }
        return array_values($groups);
    }

    protected static function expand_group_rows(array $groups): array {
        $rows = [];
        foreach ($groups as $group) {
            if (!is_array($group)) {
                continue;
            }
            $lessonorder = max(1, (int)($group['lesson_order'] ?? 1));
            $lessonname = trim((string)($group['lesson_name'] ?? ''));
            if ($lessonname === '') {
                continue;
            }
            foreach (['nhan_biet', 'thong_hieu', 'van_dung'] as $level) {
                $textblock = (string)($group[$level] ?? '');
                $lines = preg_split('/\n+/u', $textblock);
                $idx = 0;
                foreach ($lines as $line) {
                    $line = trim((string)$line);
                    if ($line === '') {
                        continue;
                    }
                    $idx++;
                    $code = '';
                    $text = $line;
                    if (preg_match('/^([A-Z0-9_\.-]+)\s*[:：-]\s*(.+)$/u', $line, $m)) {
                        $code = trim($m[1]);
                        $text = trim($m[2]);
                    }
                    if ($code === '') {
                        $code = self::make_code($lessonorder, $level, $idx);
                    }
                    if ($text === '') {
                        continue;
                    }
                    $rows[] = [
                        'lesson_order' => $lessonorder,
                        'lesson_name' => $lessonname,
                        'competency_code' => $code,
                        'level' => $level,
                        'competency_text' => $text,
                        'tocid' => 0,
                    ];
                }
            }
        }
        return $rows;
    }

    public static function get_by_course(int $courseid, int $bookid = 0): array {
        global $DB;
        $params = ['courseid' => $courseid];
        $where = 'courseid = :courseid';
        if ($bookid > 0) {
            $where .= ' AND bookid = :bookid';
            $params['bookid'] = $bookid;
        }
        return array_values($DB->get_records_select('local_aisgk_competencies', $where, $params, 'lesson_order ASC, level ASC, id ASC'));
    }

    public static function normalize_match_text(string $text): string {
        $text = self::remove_accents($text);
        $text = preg_replace('/\b(chu de|bai|tiet|phan)\b/u', ' ', $text) ?? $text;
        $text = preg_replace('/\d+/u', ' ', $text) ?? $text;
        $text = preg_replace('/[^a-z0-9]+/u', ' ', $text) ?? $text;
        return trim(preg_replace('/\s+/u', ' ', $text) ?? $text);
    }

    public static function similarity(string $a, string $b): float {
        $a = self::normalize_match_text($a);
        $b = self::normalize_match_text($b);
        if ($a === '' || $b === '') {
            return 0.0;
        }
        similar_text($a, $b, $pct);
        $char = max(0.0, min(1.0, ((float)$pct) / 100.0));
        $ta = array_values(array_filter(explode(' ', $a)));
        $tb = array_values(array_filter(explode(' ', $b)));
        $ia = array_intersect($ta, $tb);
        $union = array_unique(array_merge($ta, $tb));
        $token = $union ? (count($ia) / count($union)) : 0.0;
        return max($char, $token);
    }

    protected static function competency_lessons_for_match(int $courseid, int $bookid): array {
        $sets = [];
        if ($bookid > 0) {
            $sets[] = self::get_by_course($courseid, $bookid);
        }
        // PL3 may have been imported before a concrete textbook/file row was chosen,
        // or a user may save an older TOC from a different book row in the same course.
        // Always keep a course-wide fallback so server_score is still computed.
        $sets[] = self::get_by_course($courseid, 0);

        foreach ($sets as $competencies) {
            $lessons = [];
            foreach ($competencies as $comp) {
                $order = (int)($comp->lesson_order ?? 0);
                $name = trim((string)($comp->lesson_name ?? ''));
                if ($order < 1 || $name === '') {
                    continue;
                }
                if (!isset($lessons[$order])) {
                    $lessons[$order] = ['order' => $order, 'name' => $name];
                }
            }
            ksort($lessons);
            if ($lessons) {
                return $lessons;
            }
        }
        return [];
    }

    public static function match_toc_rows(int $courseid, int $bookid, array $tocrows): array {
        $lessons = self::competency_lessons_for_match($courseid, $bookid);
        if (!$lessons) {
            foreach ($tocrows as $idx => $row) {
                if (is_array($tocrows[$idx])) {
                    $tocrows[$idx]['ai_score'] = self::score_value($tocrows[$idx]['ai_score'] ?? 0);
                    $tocrows[$idx]['server_score'] = 0;
                    $tocrows[$idx]['final_score'] = 0;
                    $tocrows[$idx]['match_warning'] = 'Chưa có dữ liệu PL3 để tính score';
                } else {
                    $tocrows[$idx]->ai_score = self::score_value($tocrows[$idx]->ai_score ?? 0);
                    $tocrows[$idx]->server_score = 0;
                    $tocrows[$idx]->final_score = 0;
                    $tocrows[$idx]->match_warning = 'Chưa có dữ liệu PL3 để tính score';
                }
            }
            return $tocrows;
        }
        $used = [];
        foreach ($tocrows as $idx => $row) {
            $title = '';
            if (is_array($row)) {
                $title = trim((string)($row['tenbai'] ?? $row['title'] ?? ''));
                if ($title === '') { $title = trim((string)($row['rawline'] ?? '')); }
                $aiorder = (int)($row['pl3_order'] ?? 0);
                $aiscore = self::score_value($row['ai_score'] ?? 0);
            } else {
                $title = trim((string)($row->tenbai ?? $row->title ?? ''));
                if ($title === '') { $title = trim((string)($row->rawline ?? '')); }
                $aiorder = (int)($row->pl3_order ?? 0);
                $aiscore = self::score_value($row->ai_score ?? 0);
            }
            $bestorder = 0;
            $bestscore = 0.0;
            foreach ($lessons as $order => $lesson) {
                if (isset($used[$order])) {
                    continue;
                }
                $score = self::similarity($title, (string)$lesson['name']);
                if ($score > $bestscore) {
                    $bestscore = $score;
                    $bestorder = (int)$order;
                }
            }
            if ($aiorder > 0 && isset($lessons[$aiorder]) && !isset($used[$aiorder])) {
                $aiserverscore = self::similarity($title, (string)$lessons[$aiorder]['name']);
                if ($aiserverscore >= 0.70 || ($aiserverscore >= 0.55 && $aiscore >= 0.80)) {
                    $bestorder = $aiorder;
                    $bestscore = max($bestscore, $aiserverscore);
                }
            }
            // If AI did not return ai_score, do not treat it as zero.
            // Rule: ai_score > 0 => arithmetic average, otherwise use server score.
            $final = $bestscore;
            if ($aiscore > 0) {
                $final = ($bestscore + $aiscore) / 2.0;
            }
            $warning = '';
            if ($bestorder < 1 || $final < 0.55) {
                $warning = 'Không khớp PL3 chắc chắn';
                $bestorder = 0;
            } else if ($final < 0.75) {
                $warning = 'Khớp PL3 thấp, cần kiểm tra';
            }
            if ($bestorder > 0) {
                $used[$bestorder] = true;
            }
            if (is_array($tocrows[$idx])) {
                $tocrows[$idx]['pl3_order'] = $bestorder;
                $tocrows[$idx]['ai_score'] = $aiscore;
                $tocrows[$idx]['server_score'] = $bestscore;
                $tocrows[$idx]['final_score'] = $final;
                $tocrows[$idx]['match_warning'] = $warning;
            } else {
                $tocrows[$idx]->pl3_order = $bestorder;
                $tocrows[$idx]->ai_score = $aiscore;
                $tocrows[$idx]->server_score = $bestscore;
                $tocrows[$idx]->final_score = $final;
                $tocrows[$idx]->match_warning = $warning;
            }
        }
        return $tocrows;
    }

    protected static function score_value($value): float {
        if (!is_numeric($value)) {
            return 0.0;
        }
        $score = (float)$value;
        if ($score > 1) {
            $score = $score / 100.0;
        }
        return max(0.0, min(1.0, $score));
    }

    public static function update_toc_links(int $courseid, int $bookid, array $savedtocrows): int {
        global $DB;
        $DB->set_field('local_aisgk_competencies', 'tocid', 0, ['courseid' => $courseid, 'bookid' => $bookid]);
        if ($bookid > 0) {
            // Also clear course-level PL3 rows, because older imports may have bookid=0.
            $DB->set_field('local_aisgk_competencies', 'tocid', 0, ['courseid' => $courseid, 'bookid' => 0]);
        }
        $updated = 0;
        foreach ($savedtocrows as $toc) {
            $tocid = (int)($toc->id ?? 0);
            $pl3order = (int)($toc->pl3_order ?? 0);
            if ($tocid < 1 || $pl3order < 1) {
                continue;
            }
            $updated += $DB->set_field('local_aisgk_competencies', 'tocid', $tocid, [
                'courseid' => $courseid,
                'bookid' => $bookid,
                'lesson_order' => $pl3order,
            ]);
            if ($bookid > 0) {
                $updated += $DB->set_field('local_aisgk_competencies', 'tocid', $tocid, [
                    'courseid' => $courseid,
                    'bookid' => 0,
                    'lesson_order' => $pl3order,
                ]);
            }
        }
        return $updated;
    }

}
