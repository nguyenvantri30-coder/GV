<?php
namespace local_aisgk\local\service;

defined('MOODLE_INTERNAL') || die();

use context_course;
use local_aisgk\book_repository;

class book_service {

    public static function delete_book(int $courseid, int $bookid): void {
        global $DB;

        $book = book_repository::get_by_id($bookid);
        if (!$book || (int)$book->courseid !== $courseid) {
            throw new \moodle_exception('invalidrecord', 'error');
        }

        $transaction = $DB->start_delegated_transaction();

        $context = context_course::instance($courseid);
        $fs = get_file_storage();
        $fs->delete_area_files($context->id, 'local_aisgk', 'bookpdf', $bookid);

        $DB->delete_records('local_aisgk_book_toc', ['bookid' => $bookid]);
        $DB->delete_records('local_aisgk_book_toc_draft', ['bookid' => $bookid]);
        if ($DB->get_manager()->table_exists('local_aisgk_competencies')) {
            $DB->delete_records('local_aisgk_competencies', ['bookid' => $bookid]);
        }
        book_repository::delete_book($bookid);
        self::refresh_course_book_scope_descriptions($courseid);

        $transaction->allow_commit();
    }

    public static function update_books_metadata(int $courseid, array $rows): void {
        foreach ($rows as $id => $row) {
            if (!is_array($row)) {
                continue;
            }
            $bookid = (int)($row['id'] ?? $id);
            $book = book_repository::get_by_id($bookid);
            if (!$book || (int)$book->courseid !== $courseid) {
                continue;
            }
            $name = clean_param((string)($row['name'] ?? ''), PARAM_TEXT);
            $bookseries = clean_param((string)($row['bookseries'] ?? ''), PARAM_TEXT);
            $publisher = clean_param((string)($row['publisher'] ?? ''), PARAM_TEXT);
            $description = clean_param((string)($row['description'] ?? ''), PARAM_TEXT);
            book_repository::update_metadata($bookid, $name, $bookseries, $publisher, $description);
        }
        self::refresh_course_book_scope_descriptions($courseid);
    }


    public static function save_or_update_uploaded_book(int $courseid, int $bookid, array $uploadedfile, string $bookname = '', string $bookseries = '', string $publisher = '', string $description = ''): int {
        if (empty($uploadedfile['tmp_name']) || !is_uploaded_file($uploadedfile['tmp_name'])) {
            throw new \moodle_exception('nofile', 'local_aisgk');
        }
        if (!empty($uploadedfile['error']) && (int)$uploadedfile['error'] !== UPLOAD_ERR_OK) {
            throw new \moodle_exception('uploaderrorserver', 'local_aisgk', '', $uploadedfile['error']);
        }

        $filename = clean_param($uploadedfile['name'], PARAM_FILE);
        if (!$filename) {
            throw new \moodle_exception('invalidfilename', 'local_aisgk');
        }
        $ext = strtolower(pathinfo($filename, PATHINFO_EXTENSION));
        if ($ext !== 'pdf') {
            throw new \moodle_exception('onlypdfallowed', 'local_aisgk');
        }

        $name = trim($bookname) !== '' ? trim($bookname) : $filename;
        if (trim($name) === '' || trim($bookseries) === '') {
            throw new \moodle_exception('missingrequiredmetadata', 'local_aisgk');
        }

        if ($bookid > 0) {
            $book = book_repository::get_by_id($bookid);
            if (!$book || (int)$book->courseid !== $courseid) {
                throw new \moodle_exception('invalidrecord', 'error');
            }
            book_repository::update_metadata($bookid, $name, $bookseries, $publisher, $description);
        } else {
            $bookid = book_repository::create_book($courseid, $name, $filename, $bookseries, $publisher, $description);
        }

        $fs = get_file_storage();
        $context = context_course::instance($courseid);
        $fs->delete_area_files($context->id, 'local_aisgk', 'bookpdf', $bookid);
        $fileinfo = [
            'contextid' => $context->id,
            'component' => 'local_aisgk',
            'filearea'  => 'bookpdf',
            'itemid'    => $bookid,
            'filepath'  => '/',
            'filename'  => $filename,
        ];
        $fs->create_file_from_pathname($fileinfo, $uploadedfile['tmp_name']);
        book_repository::update_fileitemid($bookid, $bookid, $filename);
        self::refresh_course_book_scope_descriptions($courseid);
        return (int)$bookid;
    }


    public static function save_uploaded_book(int $courseid, array $uploadedfile, string $bookname = '', string $bookseries = '', string $publisher = '', string $description = ''): int {
        if (empty($uploadedfile['tmp_name']) || !is_uploaded_file($uploadedfile['tmp_name'])) {
            throw new \moodle_exception('nofile', 'local_aisgk');
        }

        $filename = clean_param($uploadedfile['name'], PARAM_FILE);
        if (!$filename) {
            throw new \moodle_exception('invalidfilename', 'local_aisgk');
        }

        $ext = strtolower(pathinfo($filename, PATHINFO_EXTENSION));
        if ($ext !== 'pdf') {
            throw new \moodle_exception('onlypdfallowed', 'local_aisgk');
        }

        $name = trim($bookname) !== '' ? trim($bookname) : $filename;

        // 1) Tạo record sách trước.
        $bookid = book_repository::create_book($courseid, $name, $filename, $bookseries, $publisher, $description);

        // 2) Lưu file vào Moodle file storage với itemid = bookid.
        $fs = get_file_storage();
        $context = context_course::instance($courseid);

        $fileinfo = [
            'contextid' => $context->id,
            'component' => 'local_aisgk',
            'filearea'  => 'bookpdf',
            'itemid'    => $bookid,
            'filepath'  => '/',
            'filename'  => $filename,
        ];

        $fs->delete_area_files($context->id, 'local_aisgk', 'bookpdf', $bookid);
        $fs->create_file_from_pathname($fileinfo, $uploadedfile['tmp_name']);

        // 3) Cập nhật fileitemid trong DB cho khớp với itemid đang dùng.
        book_repository::update_fileitemid($bookid, $bookid, $filename);
        self::refresh_course_book_scope_descriptions($courseid);

        return (int)$bookid;
    }

    /**
     * Maintain an automatic scope hint in the visible additional description.
     * If a course has one PDF, mark it as a full-year/single SGK. If it has
     * multiple PDFs, mark them as Part 1/Part 2 by stable order. This gives both
     * users and the TOC/PL3 matcher a deterministic hint without adding a DB field.
     */
    public static function refresh_course_book_scope_descriptions(int $courseid): void {
        global $DB, $USER;
        $books = array_values($DB->get_records('local_aisgk_books', ['courseid' => $courseid], 'sortorder ASC, id ASC'));
        $count = count($books);
        foreach ($books as $idx => $book) {
            $desc = (string)($book->description ?? '');
            $desc = preg_replace('/\s*\[ALSM_SCOPE:[^\]]+\]\s*/u', ' ', $desc) ?? $desc;
            $desc = trim(preg_replace('/\s+/u', ' ', $desc) ?? $desc);
            if ($count <= 1) {
                $tag = '[ALSM_SCOPE: FULL - Cả năm / 1 SGK]';
            } else {
                $part = $idx + 1;
                $tag = '[ALSM_SCOPE: PART ' . $part . ' - Tập ' . $part . ']';
            }
            $newdesc = trim($desc . ' ' . $tag);
            if ($newdesc !== (string)($book->description ?? '')) {
                $book->description = $newdesc;
                $book->timemodified = time();
                $book->usermodified = $USER->id ?? 0;
                $DB->update_record('local_aisgk_books', $book);
            }
        }
    }
}

