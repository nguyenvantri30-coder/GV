<?php
namespace local_aisgk\local\service;

defined('MOODLE_INTERNAL') || die();

use context_course;
use local_aisgk\book_repository;

class book_service {

    public static function delete_book(int $courseid, int $bookid): void {
        global $DB;

        $book = book_repository::get_by_id($bookid);
        if (!$book || (int)$book->courseid !== $courseid) {
            throw new \moodle_exception('invalidrecord', 'error');
        }

        $transaction = $DB->start_delegated_transaction();

        $context = context_course::instance($courseid);
        $fs = get_file_storage();
        $fs->delete_area_files($context->id, 'local_aisgk', 'bookpdf', $bookid);

        $DB->delete_records('local_aisgk_book_toc', ['bookid' => $bookid]);
        $DB->delete_records('local_aisgk_book_toc_draft', ['bookid' => $bookid]);
        if ($DB->get_manager()->table_exists('local_aisgk_competencies')) {
            $DB->delete_records('local_aisgk_competencies', ['bookid' => $bookid]);
        }
        book_repository::delete_book($bookid);
        self::sync_course_book_scopes($courseid);

        $transaction->allow_commit();
    }

    public static function update_books_metadata(int $courseid, array $rows): void {
        foreach ($rows as $id => $row) {
            if (!is_array($row)) {
                continue;
            }
            $bookid = (int)($row['id'] ?? $id);
            $book = book_repository::get_by_id($bookid);
            if (!$book || (int)$book->courseid !== $courseid) {
                continue;
            }
            $name = clean_param((string)($row['name'] ?? ''), PARAM_TEXT);
            $bookseries = clean_param((string)($row['bookseries'] ?? ''), PARAM_TEXT);
            $publisher = clean_param((string)($row['publisher'] ?? ''), PARAM_TEXT);
            $description = clean_param((string)($row['description'] ?? ''), PARAM_TEXT);
            $bookpart = self::normalize_book_part($row['book_part'] ?? 0);
            if ($bookpart < 1) {
                throw new \moodle_exception('missingbookpart', 'local_aisgk');
            }
            book_repository::update_metadata($bookid, $name, $bookseries, $publisher, $description, $bookpart);
        }
        self::sync_course_book_scopes($courseid);
    }


    public static function save_or_update_uploaded_book(int $courseid, int $bookid, array $uploadedfile, string $bookname = '', string $bookseries = '', string $publisher = '', string $description = '', int $bookpart = 0): int {
        if (empty($uploadedfile['tmp_name']) || !is_uploaded_file($uploadedfile['tmp_name'])) {
            throw new \moodle_exception('nofile', 'local_aisgk');
        }
        if (!empty($uploadedfile['error']) && (int)$uploadedfile['error'] !== UPLOAD_ERR_OK) {
            throw new \moodle_exception('uploaderrorserver', 'local_aisgk', '', $uploadedfile['error']);
        }

        $filename = clean_param($uploadedfile['name'], PARAM_FILE);
        if (!$filename) {
            throw new \moodle_exception('invalidfilename', 'local_aisgk');
        }
        $ext = strtolower(pathinfo($filename, PATHINFO_EXTENSION));
        if ($ext !== 'pdf') {
            throw new \moodle_exception('onlypdfallowed', 'local_aisgk');
        }

        $name = trim($bookname) !== '' ? trim($bookname) : $filename;
        $bookpart = self::normalize_book_part($bookpart);
        if (trim($name) === '' || trim($bookseries) === '' || $bookpart < 1) {
            throw new \moodle_exception($bookpart < 1 ? 'missingbookpart' : 'missingrequiredmetadata', 'local_aisgk');
        }

        if ($bookid > 0) {
            $book = book_repository::get_by_id($bookid);
            if (!$book || (int)$book->courseid !== $courseid) {
                throw new \moodle_exception('invalidrecord', 'error');
            }
            book_repository::update_metadata($bookid, $name, $bookseries, $publisher, $description, $bookpart);
        } else {
            $bookid = book_repository::create_book($courseid, $name, $filename, $bookseries, $publisher, $description, $bookpart);
        }

        $fs = get_file_storage();
        $context = context_course::instance($courseid);
        $fs->delete_area_files($context->id, 'local_aisgk', 'bookpdf', $bookid);
        $fileinfo = [
            'contextid' => $context->id,
            'component' => 'local_aisgk',
            'filearea'  => 'bookpdf',
            'itemid'    => $bookid,
            'filepath'  => '/',
            'filename'  => $filename,
        ];
        $fs->create_file_from_pathname($fileinfo, $uploadedfile['tmp_name']);
        book_repository::update_fileitemid($bookid, $bookid, $filename);
        self::sync_course_book_scopes($courseid);
        return (int)$bookid;
    }


    public static function save_uploaded_book(int $courseid, array $uploadedfile, string $bookname = '', string $bookseries = '', string $publisher = '', string $description = '', int $bookpart = 0): int {
        if (empty($uploadedfile['tmp_name']) || !is_uploaded_file($uploadedfile['tmp_name'])) {
            throw new \moodle_exception('nofile', 'local_aisgk');
        }

        $filename = clean_param($uploadedfile['name'], PARAM_FILE);
        if (!$filename) {
            throw new \moodle_exception('invalidfilename', 'local_aisgk');
        }

        $ext = strtolower(pathinfo($filename, PATHINFO_EXTENSION));
        if ($ext !== 'pdf') {
            throw new \moodle_exception('onlypdfallowed', 'local_aisgk');
        }

        $name = trim($bookname) !== '' ? trim($bookname) : $filename;
        $bookpart = self::normalize_book_part($bookpart);
        if (trim($name) === '' || trim($bookseries) === '' || $bookpart < 1) {
            throw new \moodle_exception($bookpart < 1 ? 'missingbookpart' : 'missingrequiredmetadata', 'local_aisgk');
        }

        // 1) Tạo record sách trước.
        $bookid = book_repository::create_book($courseid, $name, $filename, $bookseries, $publisher, $description, $bookpart);

        // 2) Lưu file vào Moodle file storage với itemid = bookid.
        $fs = get_file_storage();
        $context = context_course::instance($courseid);

        $fileinfo = [
            'contextid' => $context->id,
            'component' => 'local_aisgk',
            'filearea'  => 'bookpdf',
            'itemid'    => $bookid,
            'filepath'  => '/',
            'filename'  => $filename,
        ];

        $fs->delete_area_files($context->id, 'local_aisgk', 'bookpdf', $bookid);
        $fs->create_file_from_pathname($fileinfo, $uploadedfile['tmp_name']);

        // 3) Cập nhật fileitemid trong DB cho khớp với itemid đang dùng.
        book_repository::update_fileitemid($bookid, $bookid, $filename);
        self::sync_course_book_scopes($courseid);

        return (int)$bookid;
    }

    /**
     * Keep persisted SGK part/HK metadata consistent. Part is selected by user
     * in the upload popup; ALSM no longer detects part from title/file text.
     */
    public static function sync_course_book_scopes(int $courseid): void {
        global $DB;
        $books = array_values($DB->get_records('local_aisgk_books', ['courseid' => $courseid], 'sortorder ASC, id ASC'));
        foreach ($books as $book) {
            $part = self::normalize_book_part($book->book_part ?? 0);
            if ($part < 1) {
                continue;
            }
            book_repository::update_scope((int)$book->id, $part, $part, 'user_selected_part');
        }
    }

    public static function refresh_course_book_scope_descriptions(int $courseid): void {
        self::sync_course_book_scopes($courseid);
    }

    public static function normalize_book_part($value): int {
        $v = is_numeric($value) ? (int)$value : 0;
        return in_array($v, [1, 2, 3], true) ? $v : 0;
    }


    public static function course_book_scope_report(int $courseid): string {
        $books = book_repository::get_all_by_courseid($courseid);
        if (!$books) { return 'Chưa có SGK.'; }
        $lines = [];
        foreach ($books as $b) {
            $part = (int)($b->book_part ?? 0);
            $sem = (int)($b->semester_hint ?? 0);
            $label = $part === 1 ? 'Tập 1/HK1' : ($part === 2 ? 'Tập 2/HK2' : ($part === 3 ? 'Cả năm/1 SGK' : 'chưa xác định'));
            $lines[] = ($b->name ?: $b->filename) . ': ' . $label . ' (' . (string)($b->scope_source ?? '') . ')';
        }
        return implode("\n", $lines);
    }
}
