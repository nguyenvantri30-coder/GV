<?php
namespace local_aisgk\local\service;

defined('MOODLE_INTERNAL') || die();

/**
 * Generate background images declared by homework JSON as source="gen".
 *
 * Important design choice:
 * - This service is intentionally independent from the normal text-model/key
 *   selection pipeline. Image generation needs image endpoints/models, not the
 *   homework text fallback list.
 * - For now it is a manual action behind the "Sinh bg" button. The main
 *   homework JSON generation/validation path must remain fast and must not wait
 *   for image generation.
 * - This service only generates background images. Drag item image generation is
 *   deliberately not implemented yet.
 */
class image_generation_service {
    protected const DEFAULT_CANVAS_W = 1000;
    protected const DEFAULT_CANVAS_H = 1000;
    protected const MAX_IMAGES_PER_RUN = 8;

    /**
     * ShopAIKey endpoints.
     */
    protected const SHOPAIKEY_BASE = 'https://api.shopaikey.com';

    /**
     * No hidden default image model. Image generation must use Model Img configured
     * on API key rows via ai_key_manager(feature="img"). This prevents an old
     * hardcoded fallback such as gpt-image-2 from being called when the user did
     * not explicitly configure it.
     */
    protected const IMAGE_ATTEMPTS = [];

    /**
     * Gemini image-native models for free-tier Google AI Studio keys.
     * These are deliberately hardcoded for the manual background-generation flow.
     */
    protected const GEMINI_FREE_IMAGE_MODELS = [
        'gemini-3.1-flash-image-preview',
        'gemini-2.5-flash-image',
    ];

    /**
     * Generate missing background images for questions with images[id].source="gen".
     * Failures are recorded per image under generated.status="error" and do not
     * abort the homework draft.
     */
    public static function generate_backgrounds_for_questions(array $questions, int $userid, int $courseid, int $sectionid, int $homeworkid, array $options = []): array {
        $count = 0;

        foreach ($questions as $qi => $q) {
            if (!is_array($q) || empty($q['images']) || !is_array($q['images'])) {
                continue;
            }

            foreach ($q['images'] as $id => $img) {
                if (!is_array($img)) {
                    continue;
                }

                $source = strtolower(trim((string)($img['source'] ?? '')));
                if (!in_array($source, ['gen', 'generated', 'ai', 'generate'], true)) {
                    continue;
                }

                if (!empty($img['generated']['fileurl']) || !empty($img['generated']['url'])) {
                    continue;
                }

                if ($count >= self::MAX_IMAGES_PER_RUN) {
                    $img['generated'] = [
                        'status' => 'skipped',
                        'error' => 'Đã vượt giới hạn sinh ảnh nền trong một lần chạy.',
                    ];
                    $questions[$qi]['images'][$id] = $img;
                    continue;
                }

                $count++;
                $canvas = self::normalize_canvas($img['canvas'] ?? $img['canvas_size'] ?? null);
                $prompt = self::build_background_prompt($q, (string)$id, $img, $canvas);

                try {
                    $res = self::generate_image($prompt, $canvas, $options + ['userid' => $userid]);
                    $bytes = self::resize_image_bytes($res['bytes'], $canvas['w'], $canvas['h']);
                    $stored = self::store_generated_image($bytes, (string)$id, (string)($img['label'] ?? $id), $courseid, $homeworkid, $canvas, (int)($q['question_no'] ?? $q['no'] ?? 0));

                    $img['source'] = 'gen';
                    $img['canvas'] = ['width' => $canvas['w'], 'height' => $canvas['h']];
                    $img['generated'] = [
                        'status' => 'ready',
                        'fileurl' => $stored['url'],
                        'filename' => $stored['filename'],
                        'width' => $canvas['w'],
                        'height' => $canvas['h'],
                        'api_width' => (int)($res['api_size']['w'] ?? $canvas['w']),
                        'api_height' => (int)($res['api_size']['h'] ?? $canvas['h']),
                        'provider' => (string)($res['provider'] ?? ''),
                        'model' => (string)($res['model'] ?? ''),
                        'keysource' => (string)($res['keysource'] ?? ''),
                        'category' => (string)($res['category'] ?? ''),
                        'prompt' => $prompt,
                    ];
                    $questions[$qi]['images'][$id] = $img;
                } catch (\Throwable $e) {
                    $img['source'] = 'gen';
                    $img['canvas'] = ['width' => $canvas['w'], 'height' => $canvas['h']];
                    $img['generated'] = [
                        'status' => 'error',
                        'error' => mb_substr($e->getMessage(), 0, 1200),
                        'prompt' => $prompt,
                    ];
                    $questions[$qi]['images'][$id] = $img;
                }
            }
        }

        return $questions;
    }

    protected static function normalize_canvas($value): array {
        if (is_array($value)) {
            $w = (int)($value['width'] ?? $value['w'] ?? $value[0] ?? self::DEFAULT_CANVAS_W);
            $h = (int)($value['height'] ?? $value['h'] ?? $value[1] ?? self::DEFAULT_CANVAS_H);
        } else {
            $w = self::DEFAULT_CANVAS_W;
            $h = self::DEFAULT_CANVAS_H;
        }
        $w = max(128, min(2048, $w));
        $h = max(128, min(2048, $h));
        return ['w' => $w, 'h' => $h];
    }

    /**
     * Image APIs such as gpt-image-2 may require dimensions divisible by 16.
     * Keep JSON canvas/coordinates unchanged, but request a padded API size and
     * crop back to the original canvas after download.
     */
    protected static function normalize_api_canvas(array $canvas): array {
        $w = max(16, (int)$canvas['w']);
        $h = max(16, (int)$canvas['h']);
        $w = (int)(ceil($w / 16) * 16);
        $h = (int)(ceil($h / 16) * 16);
        return ['w' => $w, 'h' => $h];
    }

    protected static function build_background_prompt(array $q, string $imageid, array $img, array $canvas): string {
        $qtype = strtolower((string)($q['type'] ?? $q['qtype'] ?? ''));
        $apicanvas = self::normalize_api_canvas($canvas);
        $description = trim((string)($img['description'] ?? $img['prompt'] ?? $img['image_prompt'] ?? $img['label'] ?? $imageid));
        if ($description === '') {
            $description = 'Tạo ảnh nền cho câu hỏi tương tác.';
        }

        $lines = [];
        $lines[] = 'Tạo ảnh phẳng 2D dạng layout kỹ thuật giáo dục, nền trắng sạch.';
        $lines[] = '';
        $lines[] = 'Nội dung:';
        $lines[] = $description;
        $lines[] = '';
        if ($apicanvas['w'] === $canvas['w'] && $apicanvas['h'] === $canvas['h']) {
            $lines[] = 'Kích thước ảnh: ' . $canvas['w'] . 'x' . $canvas['h'] . ' pixel.';
        } else {
            $lines[] = 'Kích thước ảnh: ' . $apicanvas['w'] . 'x' . $apicanvas['h'] . ' pixel.';
            $lines[] = 'Vùng nội dung chính là ' . $canvas['w'] . 'x' . $canvas['h'] . ' pixel ở góc trên trái; phần dư bên phải hoặc bên dưới để trắng hoàn toàn.';
            $lines[] = 'Các tọa độ vùng/placeholder bên dưới tính theo vùng nội dung chính ' . $canvas['w'] . 'x' . $canvas['h'] . ', không tính phần dư.';
        }
        $lines[] = '';
        $lines[] = 'Yêu cầu hiển thị:';
        $lines[] = '- Font sans-serif rõ ràng, dễ đọc.';
        $lines[] = '- Màu đen hoặc màu đậm, tương phản cao trên nền trắng.';
        $lines[] = '- Các thành phần thẳng hàng, rõ ràng, không chồng lấn.';
        $lines[] = '- Không phối cảnh, không bóng đổ, không texture, không watermark, không logo.';
        $lines[] = '- Không thêm chi tiết ngoài yêu cầu.';
        $lines[] = '- Ưu tiên bố cục rõ ràng hơn tính nghệ thuật.';

        if ($qtype === 'ddimageortext') {
            $zones = [];
            foreach (array_values((array)($q['items'] ?? [])) as $item) {
                if (!is_array($item) || empty($item['drop_zone']) || !is_array($item['drop_zone'])) {
                    continue;
                }
                $dz = self::normalize_box_assoc($item['drop_zone']);
                if (!$dz) {
                    continue;
                }
                $zones[] = '- vùng x=' . $dz['left'] . '..' . ($dz['left'] + $dz['width'])
                    . ', y=' . $dz['top'] . '..' . ($dz['top'] + $dz['height']);
            }
            if ($zones) {
                $lines[] = '';
                $lines[] = 'Vẽ các placeholder hình chữ nhật nhỏ, rõ ràng tại các vùng:';
                $lines[] = implode("\n", $zones);
                $lines[] = 'Không ghi sẵn đáp án trong placeholder.';
            }
        } else if ($qtype === 'ddmarker') {
            $zones = [];
            foreach (array_values((array)($q['markers'] ?? [])) as $marker) {
                if (!is_array($marker)) {
                    continue;
                }
                $coords = self::normalize_coords($marker['coords'] ?? []);
                if (!$coords) {
                    continue;
                }
                $zones[] = '- x=' . $coords[0] . '..' . $coords[2] . ', y=' . $coords[1] . '..' . $coords[3];
            }
            if ($zones) {
                $lines[] = '';
                $lines[] = 'Các đối tượng/vùng cần đánh dấu phải nằm đúng hoặc gần đúng các vùng:';
                $lines[] = implode("\n", $zones);
                $lines[] = 'Không hiển thị tọa độ hoặc nhãn đáp án trên ảnh, trừ khi phần Nội dung yêu cầu rõ.';
            }
        }

        $lines[] = '';
        $lines[] = 'Chỉ xuất ảnh.';
        return implode("\n", $lines);
    }

    protected static function normalize_box_assoc(array $box): ?array {
        $left = isset($box['left']) ? (int)$box['left'] : null;
        $top = isset($box['top']) ? (int)$box['top'] : null;
        $width = isset($box['width']) ? (int)$box['width'] : null;
        $height = isset($box['height']) ? (int)$box['height'] : null;
        if ($left === null || $top === null || $width === null || $height === null || $width <= 0 || $height <= 0) {
            return null;
        }
        return ['left' => $left, 'top' => $top, 'width' => $width, 'height' => $height];
    }

    protected static function normalize_coords($coords): ?array {
        if (!is_array($coords)) {
            return null;
        }
        $vals = array_values($coords);
        if (count($vals) < 4) {
            return null;
        }
        return [(int)$vals[0], (int)$vals[1], (int)$vals[2], (int)$vals[3]];
    }


    protected static function configured_image_models_for_record(\stdClass $record, string $provider): array {
        $raw = trim((string)($record->model_img ?? ''));
        $models = [];
        if ($raw !== '') {
            foreach (explode(',', $raw) as $m) {
                $m = trim($m);
                if ($m !== '' && !in_array($m, $models, true)) {
                    $models[] = $m;
                }
            }
        }
        // Never invent a fallback model here. Empty Model Img means this key has
        // no image model configured and must be skipped by the selector.
        return $models;
    }

    protected static function image_model_usable(\stdClass $record, string $model): bool {
        $raw = trim((string)($record->model_img_status ?? ''));
        $map = [];
        if ($raw !== '') {
            $decoded = json_decode($raw, true);
            if (is_array($decoded)) {
                $map = $decoded;
            }
        }
        $st = $map[$model] ?? [];
        if (!is_array($st)) { $st = ['status' => (string)$st]; }
        $status = (string)($st['status'] ?? 'active');
        $until = (int)($st['cooldown_until'] ?? 0);
        if ($status === 'blocked') { return false; }
        if ($status === 'cooldown' && $until > time()) { return false; }
        return true;
    }

    protected static function set_image_model_status(array $keyctx, string $model, string $status, string $error = '', int $cooldownseconds = 0): void {
        global $DB;
        if (empty($DB) || empty($keyctx['table']) || empty($keyctx['record']->id)) { return; }
        try {
            $table = (string)$keyctx['table'];
            $record = $DB->get_record($table, ['id' => (int)$keyctx['record']->id]);
            if (!$record) { return; }
            $models = self::configured_image_models_for_record($record, (string)($record->provider ?? 'google'));
            if (!in_array($model, $models, true)) { $models[] = $model; $record->model_img = trim((string)($record->model_img ?? '')); if ($record->model_img === '') { $record->model_img = implode(',', $models); } }
            $map = [];
            $decoded = json_decode((string)($record->model_img_status ?? ''), true);
            if (is_array($decoded)) { $map = $decoded; }
            $map[$model] = [
                'status' => in_array($status, ['active','cooldown','blocked'], true) ? $status : 'active',
                'cooldown_until' => $cooldownseconds > 0 ? time() + $cooldownseconds : 0,
                'last_error' => mb_substr($error, 0, 1000),
                'last_used' => time(),
            ];
            $record->model_img_status = json_encode($map, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
            $record->last_error = mb_substr($error, 0, 1000);
            $record->last_model = $model;
            $record->timemodified = time();
            $DB->update_record($table, $record);
        } catch (\Throwable $e) {}
    }

    protected static function cooldown_seconds_from_error(string $error): int {
        if (preg_match('/retry in\s+([0-9.]+)s/i', $error, $m)) {
            return max(10, (int)ceil((float)$m[1]) + 2);
        }
        if (stripos($error, '429') !== false || stripos($error, 'rate') !== false || stripos($error, 'quota') !== false) {
            return 60;
        }
        return 0;
    }

    /**
     * Image generation client.
     * Uses the same key/model selector with feature="img".
     * One background generation chooses exactly one available key and the first
     * available model in that key's Model Img priority list. It does not sweep
     * through the whole key pool in a single request.
     */
    protected static function generate_image(string $prompt, array $canvas, array $options = []): array {
        $userid = (int)($options['userid'] ?? 0);
        $apicanvas = self::normalize_api_canvas($canvas);

        // Image generation intentionally does not use a hidden override/default model.
        // All image attempts must come from saved API key rows and their explicit
        // Model Img list, so a model such as gpt-image-2 is never called unless the
        // user configured it in Model Img.

        if (!class_exists('\\local_aisgk\\ai_key_manager')) {
            throw new \moodle_exception('errorprocessingbook', 'local_aisgk', '', 'Thiếu ai_key_manager để chọn key sinh ảnh.');
        }

        $exclude = [];
        $errors = [];
        // Try a small number of keys sequentially. This preserves the free-before-pay
        // selector and Model Img priority, but lets the service move on when the chosen
        // model is proven not to support image output or is in quota/cooldown.
        for ($keytry = 0; $keytry < 6; $keytry++) {
            $key = \local_aisgk\ai_key_manager::get_available_key('img', $exclude, $userid, true, 0);
            if (!$key) {
                break;
            }
            $compound = (string)($key->_source_table ?? 'local_aisgk_ai_keys') . ':' . (int)($key->id ?? 0);
            $exclude[] = $compound;
            $exclude[] = (string)(int)($key->id ?? 0);

            $models = \local_aisgk\ai_key_manager::model_attempts_for_key($key, 'img');
            if (!$models) {
                \local_aisgk\ai_key_manager::release_key($key);
                continue;
            }

            $provider = \local_aisgk\ai_key_manager::provider_for_key($key);
            $apikey = trim((string)($key->api_key ?? ''));

            foreach ($models as $model) {
                $model = trim((string)$model);
                if ($model === '') { continue; }
                if (!\local_aisgk\ai_key_manager::has_image_capability($model)) {
                    \local_aisgk\ai_key_manager::mark_model_blocked($key, $model, 'img', 'Model không có image_output capability.');
                    continue;
                }

                try {
                    if ($provider === 'google') {
                        $bytes = self::call_gemini_free_image($apikey, $model, $prompt, $apicanvas);
                    } else if ($provider === 'shopaikey') {
                        $bytes = self::call_shopaikey_model_image($apikey, $model, $prompt, $apicanvas);
                    } else {
                        throw new \moodle_exception('errorprocessingbook', 'local_aisgk', '', 'Provider không hỗ trợ sinh ảnh: ' . $provider);
                    }

                    if ($bytes === '') {
                        throw new \moodle_exception('errorprocessingbook', 'local_aisgk', '', 'API sinh ảnh không trả bytes.');
                    }

                    \local_aisgk\ai_key_manager::mark_success($key, 0, $model, $userid, 'img');
                    return [
                        'bytes' => $bytes,
                        'provider' => $provider,
                        'model' => $model,
                        'keysource' => (string)($key->_source_table ?? ''),
                        'category' => (string)($key->category_key ?? ''),
                        'api_size' => $apicanvas,
                    ];
                } catch (\Throwable $e) {
                    $err = $e->getMessage();
                    $errors[] = $model . ': ' . $err;
                    self::mark_selected_image_key_error($key, $model, $err);
                    // Continue to the next configured image model/key. Text/SVG/no-inlineData
                    // is treated as a model capability failure, not as a parser fallback.
                    continue;
                }
            }

            \local_aisgk\ai_key_manager::release_key($key);
        }

        $suffix = $errors ? (' Chi tiết: ' . mb_substr(implode(' | ', $errors), 0, 1600)) : '';
        throw new \moodle_exception('errorprocessingbook', 'local_aisgk', '', 'Không có API key/model ảnh khả dụng cho Model Img.' . $suffix);
    }

    protected static function mark_selected_image_key_error(\stdClass $key, string $model, string $error): void {
        if (!class_exists('\\local_aisgk\\ai_key_manager')) {
            return;
        }
        $lower = strtolower($error);
        if (preg_match('/limit\s*:\s*0/i', $error)
            || \local_aisgk\ai_key_manager::is_model_channel_error($error)
            || strpos($lower, 'model not found') !== false
            || strpos($lower, 'unsupported') !== false
            || strpos($lower, 'not supported') !== false
            || strpos($lower, 'không trả inlinedata') !== false
            || strpos($lower, 'khong tra inlinedata') !== false
            || strpos($lower, 'không hỗ trợ image modality') !== false
            || strpos($lower, 'khong ho tro image modality') !== false
            || strpos($lower, 'not return inlinedata') !== false
            || strpos($lower, 'image modality') !== false) {
            \local_aisgk\ai_key_manager::mark_model_blocked($key, $model, 'img', $error);
            return;
        }
        if (strpos($lower, '429') !== false || strpos($lower, 'rate') !== false || strpos($lower, 'retry in') !== false) {
            \local_aisgk\ai_key_manager::mark_429($key, $error, $model, 'img');
            return;
        }
        if (\local_aisgk\ai_key_manager::is_daily_quota_error($error)) {
            \local_aisgk\ai_key_manager::mark_daily_quota($key, $error, $model, 'img');
            return;
        }
        if (\local_aisgk\ai_key_manager::is_balance_error($error)) {
            \local_aisgk\ai_key_manager::mark_daily_quota($key, $error, $model, 'img');
            return;
        }
        \local_aisgk\ai_key_manager::mark_error($key, $error);
    }

    /**
     * Return usable API key records for a provider/category. User keys are tried
     * before system keys; older last_used is tried first to spread free quotas.
     */
    protected static function resolve_api_key_records(string $provider, string $category, int $userid = 0, int $limit = 5): array {
        global $DB;
        if (empty($DB)) {
            return [];
        }

        $out = [];
        $sources = [];
        if ($userid > 0 && $DB->get_manager()->table_exists('local_aisgk_user_ai_keys')) {
            $sources[] = ['table' => 'local_aisgk_user_ai_keys', 'where' => 'userid = ? AND provider = ? AND category_key = ? AND api_key <> ?', 'params' => [$userid, $provider, $category, '']];
        }
        if ($DB->get_manager()->table_exists('local_aisgk_ai_keys')) {
            $sources[] = ['table' => 'local_aisgk_ai_keys', 'where' => 'provider = ? AND category_key = ? AND api_key <> ?', 'params' => [$provider, $category, '']];
        }

        foreach ($sources as $src) {
            try {
                $records = array_values($DB->get_records_select($src['table'], $src['where'], $src['params'], 'last_used ASC, id ASC'));
            } catch (\Throwable $e) {
                continue;
            }
            foreach ($records as $record) {
                if (!self::is_usable_generic_key_record($record, $provider)) {
                    continue;
                }
                $out[] = ['key' => trim((string)$record->api_key), 'table' => $src['table'], 'record' => $record];
                if (count($out) >= $limit) {
                    return $out;
                }
            }
        }
        return $out;
    }

    protected static function is_usable_generic_key_record(\stdClass $record, string $provider): bool {
        $apikey = trim((string)($record->api_key ?? ''));
        if ($apikey === '') {
            return false;
        }
        if (trim((string)($record->provider ?? '')) !== $provider) {
            return false;
        }
        $status = trim((string)($record->status ?? 'active'));
        if ($status === 'blocked') {
            return false;
        }
        if ($status === 'cooldown' && (int)($record->cooldown_until ?? 0) > time()) {
            return false;
        }
        if ((int)($record->daily_reset_at ?? 0) > 0 && (int)($record->daily_reset_at ?? 0) <= time()) {
            // Best effort reset is done by the normal key manager; for image calls,
            // just avoid rejecting stale rows here.
        }
        $dailylimit = (int)($record->daily_limit ?? 0);
        $dailyused = (int)($record->daily_used ?? 0);
        if ($dailylimit > 0 && $dailyused >= $dailylimit) {
            return false;
        }
        if ($provider === 'shopaikey' && isset($record->usage_remaining) && is_numeric($record->usage_remaining) && (float)$record->usage_remaining <= 0 && (int)($record->usage_last_sync ?? 0) > 0) {
            return false;
        }
        return true;
    }

    protected static function mark_key_success(array $keyctx, string $model, int $userid, string $feature): void {
        global $DB;
        if (empty($DB) || empty($keyctx['table']) || empty($keyctx['record']->id)) {
            return;
        }
        try {
            $table = (string)$keyctx['table'];
            $record = $DB->get_record($table, ['id' => (int)$keyctx['record']->id]);
            if (!$record) {
                return;
            }
            $record->daily_used = (int)($record->daily_used ?? 0) + 1;
            $record->total_requests_day = (int)$record->daily_used;
            $record->last_used = time();
            $record->last_error = '';
            $record->last_model = $model;
            $record->last_tokens = max(0, (int)($record->last_tokens ?? 0));
            $record->last_tokens_at = time();
            $record->in_use_by = 0;
            $record->in_use_until = 0;
            $record->timemodified = time();
            $DB->update_record($table, $record);
            if ($table === 'local_aisgk_ai_keys' && class_exists('\\local_aisgk\\ai_key_manager')) {
                \local_aisgk\ai_key_manager::mark_user_call($userid);
            }
        } catch (\Throwable $e) {
            // Non-fatal accounting failure.
        }
    }

    protected static function mark_key_error(array $keyctx, string $model, string $error): void {
        global $DB;
        if (empty($DB) || empty($keyctx['table']) || empty($keyctx['record']->id)) {
            return;
        }
        try {
            $table = (string)$keyctx['table'];
            $record = $DB->get_record($table, ['id' => (int)$keyctx['record']->id]);
            if (!$record) {
                return;
            }
            $record->last_error = mb_substr($model . ': ' . $error, 0, 1000);
            $record->last_model = $model;
            $record->in_use_by = 0;
            $record->in_use_until = 0;
            if (stripos($error, '429') !== false || stripos($error, 'rate') !== false || stripos($error, 'quota') !== false) {
                $record->status = 'cooldown';
                $record->cooldown_until = time() + 300;
            }
            $record->timemodified = time();
            $DB->update_record($table, $record);
        } catch (\Throwable $e) {
            // Non-fatal accounting failure.
        }
    }

    protected static function call_gemini_free_image(string $apikey, string $model, string $prompt, ?array $canvas = null): string {
        if (preg_match('/^imagen[-_]|(^|[-_])imagen[-_]/i', preg_replace('#^models/#', '', trim($model)))) {
            return self::call_google_imagen_predict($apikey, $model, $prompt, is_array($canvas) ? $canvas : []);
        }
        $url = 'https://generativelanguage.googleapis.com/v1beta/models/' . rawurlencode($model) . ':generateContent?key=' . rawurlencode($apikey);
        $payload = [
            'contents' => [
                [
                    'role' => 'user',
                    'parts' => [
                        ['text' => $prompt],
                    ],
                ],
            ],
            'generationConfig' => [
                'responseModalities' => ['IMAGE'],
            ],
        ];
        if (is_array($canvas) && !empty($canvas['w']) && !empty($canvas['h'])) {
            $payload['generationConfig']['imageConfig'] = [
                'imageSize' => ((int)$canvas['w']) . 'x' . ((int)$canvas['h']),
            ];
        }
        $json = self::post_json($url, ['Content-Type: application/json'], $payload, 120);

        // Do not store base64 in homework JSON. It is accepted only as a
        // transport format from Gemini/Nano Banana, decoded immediately, then
        // saved to Moodle file storage as a normal file URL.
        $b64 = self::extract_gemini_inline_b64($json);
        if ($b64 === '') {
            $b64 = self::extract_b64_json($json);
        }
        if ($b64 !== '') {
            $bytes = base64_decode($b64, true);
            if ($bytes !== false && $bytes !== '') {
                return $bytes;
            }
            throw new \moodle_exception('errorprocessingbook', 'local_aisgk', '', 'Gemini trả base64 ảnh không hợp lệ.');
        }

        $imgurl = self::extract_image_url($json);
        if ($imgurl !== '') {
            return self::download_bytes($imgurl);
        }

        throw new \moodle_exception('errorprocessingbook', 'local_aisgk', '', 'Model/API không trả image URL hoặc inlineData image; có thể không hỗ trợ IMAGE modality: ' . mb_substr(json_encode($json, JSON_UNESCAPED_UNICODE), 0, 800));
    }


    protected static function call_google_imagen_predict(string $apikey, string $model, string $prompt, array $canvas = []): string {
        $model = preg_replace('#^models/#', '', trim($model));
        $url = 'https://generativelanguage.googleapis.com/v1beta/models/' . rawurlencode($model) . ':predict?key=' . rawurlencode($apikey);
        $params = [
            'sampleCount' => 1,
        ];
        if (!empty($canvas['w']) && !empty($canvas['h'])) {
            $params['aspectRatio'] = self::google_ratio_for_canvas($canvas);
            // Imagen API accepts 1K/2K instead of arbitrary pixel sizes. We still
            // crop/pad after saving to preserve logical canvas coordinates.
            $params['imageSize'] = '1K';
        }
        $payload = [
            'instances' => [
                ['prompt' => $prompt],
            ],
            'parameters' => $params,
        ];
        $json = self::post_json($url, ['Content-Type: application/json'], $payload, 120);

        $imgurl = self::extract_image_url($json);
        if ($imgurl !== '') {
            return self::download_bytes($imgurl);
        }
        $b64 = self::extract_b64_json($json);
        if ($b64 !== '') {
            $bytes = base64_decode($b64, true);
            if ($bytes !== false && $bytes !== '') {
                return $bytes;
            }
        }
        throw new \moodle_exception('errorprocessingbook', 'local_aisgk', '', 'Google Imagen predict không trả url/base64 ảnh: ' . mb_substr(json_encode($json, JSON_UNESCAPED_UNICODE), 0, 800));
    }

    protected static function extract_gemini_inline_b64(array $json): string {
        $candidates = $json['candidates'] ?? [];
        if (!is_array($candidates)) {
            return '';
        }
        foreach ($candidates as $candidate) {
            $parts = $candidate['content']['parts'] ?? [];
            if (!is_array($parts)) {
                continue;
            }
            foreach ($parts as $part) {
                $inline = $part['inlineData'] ?? $part['inline_data'] ?? null;
                if (is_array($inline) && !empty($inline['data']) && is_string($inline['data'])) {
                    return $inline['data'];
                }
            }
        }
        return '';
    }

    protected static function resolve_api_key(array $options = []): string {
        global $CFG;

        // Disabled by design. Older builds allowed CFG/env ShopAIKey image keys
        // and paired them with a hardcoded gpt-image-2 attempt. That made the
        // plugin call gpt-image-2 even when Model Img did not contain it.
        // Keep the method for compatibility, but never return a hidden key.
        return '';
    }

    /**
     * Find an active ShopAIKey API key already configured in this plugin.
     * Priority:
     * 1. current user's ShopAIKey pay key
     * 2. system ShopAIKey pay key
     * 3. other active ShopAIKey key
     */
    protected static function resolve_api_key_from_tables(int $userid = 0): string {
        global $DB;

        if (empty($DB)) {
            return '';
        }

        $tables = [];
        if ($userid > 0 && $DB->get_manager()->table_exists('local_aisgk_user_ai_keys')) {
            $tables[] = [
                'name' => 'local_aisgk_user_ai_keys',
                'where' => 'userid = ? AND provider = ? AND api_key <> ?',
                'params' => [$userid, 'shopaikey', ''],
            ];
        }
        if ($DB->get_manager()->table_exists('local_aisgk_ai_keys')) {
            $tables[] = [
                'name' => 'local_aisgk_ai_keys',
                'where' => 'provider = ? AND api_key <> ?',
                'params' => ['shopaikey', ''],
            ];
        }

        foreach ($tables as $table) {
            try {
                $records = $DB->get_records_select($table['name'], $table['where'], $table['params'], 'id ASC');
            } catch (\Throwable $e) {
                continue;
            }

            $rows = array_values($records);
            usort($rows, function($a, $b) {
                $ap = ((string)($a->category_key ?? '') === 'pay') ? 0 : 1;
                $bp = ((string)($b->category_key ?? '') === 'pay') ? 0 : 1;
                if ($ap !== $bp) {
                    return $ap <=> $bp;
                }
                return ((int)($a->id ?? 0)) <=> ((int)($b->id ?? 0));
            });

            foreach ($rows as $record) {
                if (!self::is_usable_shopaikey_record($record)) {
                    continue;
                }
                $key = trim((string)($record->api_key ?? ''));
                if ($key !== '') {
                    return $key;
                }
            }
        }

        return '';
    }

    protected static function is_usable_shopaikey_record(\stdClass $record): bool {
        $apikey = trim((string)($record->api_key ?? ''));
        if ($apikey === '') {
            return false;
        }
        if (trim((string)($record->provider ?? '')) !== 'shopaikey') {
            return false;
        }

        $status = trim((string)($record->status ?? 'active'));
        if ($status === 'blocked') {
            return false;
        }
        $cooldownuntil = (int)($record->cooldown_until ?? 0);
        if ($status === 'cooldown' && $cooldownuntil > time()) {
            return false;
        }
        if (isset($record->usage_remaining) && is_numeric($record->usage_remaining) && (float)$record->usage_remaining <= 0) {
            return false;
        }
        $dailylimit = (int)($record->daily_limit ?? 0);
        $dailyused = (int)($record->daily_used ?? 0);
        if ($dailylimit > 0 && $dailyused >= $dailylimit) {
            return false;
        }
        return true;
    }

    protected static function shopaikey_normalize_image_model(string $model): string {
        $m = strtolower(preg_replace('#^models/#', '', trim($model)));
        // ShopAIKey custom Google image endpoint uses product aliases, not upstream
        // Gemini model ids. Keep these mappings provider-local so normal Google
        // API keys can still use native Gemini model names.
        $map = [
            'gemini-2.5-flash-image' => 'nano-banana',
            'gemini-2.5-flash-preview-image' => 'nano-banana',
            'gemini-3.1-flash-image-preview' => 'nano-banana-2',
            'gemini-3-flash-image-preview' => 'nano-banana-2',
            'gemini-3-pro-image-preview' => 'nano-banana-pro',
            'gemini-3-pro-image' => 'nano-banana-pro',
            'nano-banana-pro-preview' => 'nano-banana-pro',
        ];
        return $map[$m] ?? $m;
    }

    protected static function shopaikey_image_family(string $model): string {
        $m = self::shopaikey_normalize_image_model($model);
        if (preg_match('/^nano-banana(?:-2|-pro)?$/', $m)) { return 'google_nano'; }
        if (preg_match('/^(?:dall-e-2|dall-e-3|gpt-image-[0-9](?:\.[0-9])?)$/', $m)) { return 'openai_image'; }
        return '';
    }

    protected static function call_shopaikey_model_image(string $apikey, string $model, string $prompt, array $canvas): string {
        $normalized = self::shopaikey_normalize_image_model($model);
        $family = self::shopaikey_image_family($normalized);

        if ($family === 'google_nano') {
            $attempt = [
                'endpoint' => '/images/google/generations',
                'model' => $normalized,
                'format' => 'jpeg',
                'response_format' => 'url',
                'imageSize' => ($normalized === 'nano-banana') ? '' : '1K',
            ];
            return self::call_shopaikey_google($apikey, $attempt, $prompt, $canvas);
        }

        if ($family === 'openai_image') {
            $attempt = [
                'endpoint' => '/v1/images/generations',
                'model' => $normalized,
                'quality' => (strpos($normalized, 'dall-e-') === 0) ? 'standard' : 'low',
                'background' => 'auto',
                'response_format' => 'url',
                'size' => (strpos($normalized, 'dall-e-') === 0) ? '1024x1024' : 'auto',
            ];
            return self::call_shopaikey_openai($apikey, $attempt, $prompt, $canvas);
        }

        throw new \moodle_exception('errorprocessingbook', 'local_aisgk', '',
            'Model Img không thuộc endpoint sinh ảnh ShopAIKey được hỗ trợ. Dùng nano-banana, nano-banana-2, nano-banana-pro, dall-e-2, dall-e-3, gpt-image-1/1.5/2. Model hiện tại: ' . $model);
    }

    protected static function call_shopaikey_gemini_native(string $apikey, string $model, string $prompt, array $canvas): string {
        $model = preg_replace('#^models/#', '', trim($model));
        $url = self::SHOPAIKEY_BASE . '/v1beta/models/' . rawurlencode($model) . ':generateContent?key=' . rawurlencode($apikey);
        $payload = [
            'contents' => [
                [
                    'role' => 'user',
                    'parts' => [
                        ['text' => $prompt],
                    ],
                ],
            ],
            'generationConfig' => [
                'responseModalities' => ['IMAGE'],
                'imageConfig' => [
                    'imageSize' => ((int)$canvas['w']) . 'x' . ((int)$canvas['h']),
                ],
            ],
        ];
        $json = self::post_json($url, [
            'Content-Type: application/json',
            'Authorization: Bearer ' . $apikey,
        ], $payload, 120);
        $b64 = self::extract_gemini_inline_b64($json);
        if ($b64 !== '') {
            $bytes = base64_decode($b64, true);
            if ($bytes !== false && $bytes !== '') {
                return $bytes;
            }
        }
        $url = self::extract_image_url($json);
        if ($url !== '') {
            return self::download_bytes($url);
        }
        $b64 = self::extract_b64_json($json);
        if ($b64 !== '') {
            $bytes = base64_decode($b64, true);
            if ($bytes !== false && $bytes !== '') {
                return $bytes;
            }
        }
        throw new \moodle_exception('errorprocessingbook', 'local_aisgk', '', 'ShopAIKey Gemini native không trả inlineData/url/b64 image; có thể không hỗ trợ IMAGE modality: ' . mb_substr(json_encode($json, JSON_UNESCAPED_UNICODE), 0, 800));
    }

    protected static function call_shopaikey_google(string $apikey, array $attempt, string $prompt, array $canvas): string {
        $payload = [
            'model' => $attempt['model'],
            'prompt' => $prompt,
            'size' => self::google_ratio_for_canvas($canvas),
            'format' => $attempt['format'] ?? 'jpeg',
            'response_format' => 'url',
            'image_urls' => [],
        ];
        if (!empty($attempt['imageSize'])) {
            $payload['imageSize'] = $attempt['imageSize'];
        }

        $json = self::post_json(self::SHOPAIKEY_BASE . $attempt['endpoint'], [
            'Content-Type: application/json',
            'Authorization: Bearer ' . $apikey,
        ], $payload, 90);

        $url = self::extract_image_url($json);
        if ($url !== '') {
            return self::download_bytes($url);
        }
        $b64 = self::extract_b64_json($json);
        if ($b64 !== '') {
            $bytes = base64_decode($b64, true);
            if ($bytes !== false && $bytes !== '') {
                return $bytes;
            }
        }

        throw new \moodle_exception('errorprocessingbook', 'local_aisgk', '', 'Google image endpoint không trả url/b64_json: ' . mb_substr(json_encode($json, JSON_UNESCAPED_UNICODE), 0, 800));
    }

    protected static function call_shopaikey_openai(string $apikey, array $attempt, string $prompt, array $canvas): string {
        $payload = [
            'model' => $attempt['model'],
            'prompt' => $prompt,
            'n' => 1,
            'size' => $attempt['size'] ?? self::openai_size_for_canvas($canvas),
            'quality' => $attempt['quality'] ?? 'medium',
            'background' => $attempt['background'] ?? 'opaque',
            'response_format' => $attempt['response_format'] ?? 'url',
        ];

        $json = self::post_json(self::SHOPAIKEY_BASE . $attempt['endpoint'], [
            'Content-Type: application/json',
            'Authorization: Bearer ' . $apikey,
        ], $payload, 120);

        $url = self::extract_image_url($json);
        if ($url !== '') {
            return self::download_bytes($url);
        }
        $b64 = self::extract_b64_json($json);
        if ($b64 !== '') {
            $bytes = base64_decode($b64, true);
            if ($bytes !== false && $bytes !== '') {
                return $bytes;
            }
        }

        throw new \moodle_exception('errorprocessingbook', 'local_aisgk', '', 'OpenAI-compatible image endpoint không trả url/b64_json: ' . mb_substr(json_encode($json, JSON_UNESCAPED_UNICODE), 0, 800));
    }

    protected static function extract_image_url(array $json): string {
        $candidates = [
            $json['data'][0]['url'] ?? null,
            $json['data'][0]['image_url'] ?? null,
            $json['url'] ?? null,
            $json['image_url'] ?? null,
            $json['output'][0]['url'] ?? null,
            $json['result']['url'] ?? null,
            $json['images'][0]['url'] ?? null,
            $json['images'][0]['image_url'] ?? null,
            $json['predictions'][0]['url'] ?? null,
            $json['predictions'][0]['gcsUri'] ?? null,
            $json['predictions'][0]['image']['uri'] ?? null,
            $json['generatedImages'][0]['image']['uri'] ?? null,
            $json['generated_images'][0]['image']['uri'] ?? null,
        ];
        foreach ($candidates as $url) {
            if (is_string($url) && preg_match('#^https?://#i', $url)) {
                return $url;
            }
        }
        return '';
    }

    protected static function extract_b64_json(array $json): string {
        $candidates = [
            $json['data'][0]['b64_json'] ?? null,
            $json['b64_json'] ?? null,
            $json['image'] ?? null,
            $json['result']['b64_json'] ?? null,
            $json['images'][0]['b64_json'] ?? null,
            $json['images'][0]['data'] ?? null,
            $json['predictions'][0]['bytesBase64Encoded'] ?? null,
            $json['predictions'][0]['image']['bytesBase64Encoded'] ?? null,
            $json['generatedImages'][0]['image']['imageBytes'] ?? null,
            $json['generated_images'][0]['image']['imageBytes'] ?? null,
            $json['image']['bytesBase64Encoded'] ?? null,
            $json['image']['imageBytes'] ?? null,
        ];
        foreach ($candidates as $b64) {
            if (is_string($b64) && $b64 !== '') {
                if (preg_match('#^data:image/[^;]+;base64,#', $b64)) {
                    $b64 = preg_replace('#^data:image/[^;]+;base64,#', '', $b64);
                }
                return $b64;
            }
        }
        return '';
    }

    protected static function google_ratio_for_canvas(array $canvas): string {
        $w = max(1, (int)$canvas['w']);
        $h = max(1, (int)$canvas['h']);
        $ratio = $w / $h;

        if ($ratio >= 2.2) {
            return '2:1';
        }
        if ($ratio >= 1.55) {
            return '16:9';
        }
        if ($ratio >= 1.20) {
            return '4:3';
        }
        if ($ratio <= 0.45) {
            return '1:2';
        }
        if ($ratio <= 0.65) {
            return '2:3';
        }
        if ($ratio <= 0.85) {
            return '3:4';
        }
        return '1:1';
    }

    protected static function openai_size_for_canvas(array $canvas): string {
        // gpt-image-* endpoints may reject very wide/short custom sizes
        // (minimum pixel budget, max aspect ratio). Use auto and crop/resize
        // the returned image back to JSON canvas after download.
        return 'auto';
    }

    protected static function post_json(string $url, array $headers, array $payload, int $timeout = 120): array {
        $ch = curl_init($url);
        curl_setopt_array($ch, [
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_POST => true,
            CURLOPT_HTTPHEADER => $headers,
            CURLOPT_POSTFIELDS => json_encode($payload, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES),
            CURLOPT_TIMEOUT => $timeout,
            CURLOPT_CONNECTTIMEOUT => 12,
        ]);
        $response = curl_exec($ch);
        $errno = curl_errno($ch);
        $error = curl_error($ch);
        $http = (int)curl_getinfo($ch, CURLINFO_RESPONSE_CODE);
        curl_close($ch);

        if ($errno) {
            throw new \moodle_exception('errorprocessingbook', 'local_aisgk', '', 'Lỗi kết nối API ảnh: ' . $error);
        }

        $json = json_decode((string)$response, true);
        if (!is_array($json)) {
            throw new \moodle_exception('errorprocessingbook', 'local_aisgk', '', 'API ảnh trả dữ liệu không hợp lệ: ' . mb_substr((string)$response, 0, 1000));
        }

        if ($http >= 400 || !empty($json['error'])) {
            $err = $json['error'] ?? [];
            $msg = is_array($err) ? (string)($err['message'] ?? ('HTTP ' . $http)) : (string)$err;
            throw new \moodle_exception('errorprocessingbook', 'local_aisgk', '', 'IMAGE_API_ERROR HTTP ' . $http . ': ' . $msg);
        }

        return $json;
    }

    protected static function download_bytes(string $url): string {
        if (!preg_match('#^https?://#i', $url)) {
            return '';
        }
        $ch = curl_init($url);
        curl_setopt_array($ch, [
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_TIMEOUT => 80,
            CURLOPT_CONNECTTIMEOUT => 10,
            CURLOPT_FOLLOWLOCATION => true,
        ]);
        $bytes = curl_exec($ch);
        $errno = curl_errno($ch);
        $error = curl_error($ch);
        $http = (int)curl_getinfo($ch, CURLINFO_RESPONSE_CODE);
        curl_close($ch);

        if ($errno || $http >= 400 || !is_string($bytes) || $bytes === '') {
            throw new \moodle_exception('errorprocessingbook', 'local_aisgk', '', 'Không tải được ảnh sinh: ' . ($error ?: ('HTTP ' . $http)));
        }
        return $bytes;
    }

    protected static function resize_image_bytes(string $bytes, int $targetw, int $targeth): string {
        if (!function_exists('imagecreatefromstring')) {
            return $bytes;
        }
        $img = @imagecreatefromstring($bytes);
        if (!$img) {
            return $bytes;
        }

        $w = imagesx($img);
        $h = imagesy($img);
        if ($w === $targetw && $h === $targeth) {
            ob_start();
            imagepng($img);
            $out = (string)ob_get_clean();
            imagedestroy($img);
            return $out;
        }

        $dst = imagecreatetruecolor($targetw, $targeth);
        imagesavealpha($dst, true);
        $transparent = imagecolorallocatealpha($dst, 255, 255, 255, 127);
        imagefilledrectangle($dst, 0, 0, $targetw, $targeth, $transparent);

        // Preferred path: API image was generated at a padded size, for example
        // 1008x160 for a 1000x150 logical canvas. Crop the top-left content box
        // back to the original canvas so JSON coordinates remain unchanged.
        if ($w >= $targetw && $h >= $targeth) {
            imagecopy($dst, $img, 0, 0, 0, 0, $targetw, $targeth);
            imagedestroy($img);
            ob_start();
            imagepng($dst);
            $out = (string)ob_get_clean();
            imagedestroy($dst);
            return $out;
        }

        // If a provider ignores requested dimensions and returns a smaller image,
        // place it at top-left without scaling. This preserves the coordinate
        // origin as much as possible. Only the missing area is transparent/blank.
        imagecopy($dst, $img, 0, 0, 0, 0, min($w, $targetw), min($h, $targeth));
        imagedestroy($img);

        ob_start();
        imagepng($dst);
        $out = (string)ob_get_clean();
        imagedestroy($dst);
        return $out;
    }

    protected static function store_generated_image(string $bytes, string $imageid, string $label, int $courseid, int $homeworkid, array $canvas, int $questionno = 0): array {
        global $CFG;

        $context = \context_course::instance($courseid);
        $safeid = preg_replace('/[^a-zA-Z0-9_\-]+/', '_', $imageid) ?: 'bg';
        $qprefix = $questionno > 0 ? ('q' . $questionno . '_') : '';
        $filename = 'gen_' . $qprefix . $safeid . '_' . $canvas['w'] . 'x' . $canvas['h'] . '_' . substr(sha1($bytes), 0, 12) . '.png';
        $tmpdir = $CFG->dataroot . '/local_aisgk/tmp/genimg/' . $homeworkid;
        if (!is_dir($tmpdir)) {
            mkdir($tmpdir, $CFG->directorypermissions, true);
        }
        $tmpfile = $tmpdir . '/' . $filename;
        file_put_contents($tmpfile, $bytes);
        @chmod($tmpfile, $CFG->filepermissions);

        $fs = get_file_storage();
        $fileinfo = [
            'contextid' => $context->id,
            'component' => 'local_aisgk',
            'filearea' => 'homeworkimg',
            'itemid' => $homeworkid,
            'filepath' => '/',
            'filename' => $filename,
        ];
        if ($old = $fs->get_file($context->id, 'local_aisgk', 'homeworkimg', $homeworkid, '/', $filename)) {
            $old->delete();
        }
        $fs->create_file_from_pathname($fileinfo, $tmpfile);
        @unlink($tmpfile);

        $url = \moodle_url::make_pluginfile_url($context->id, 'local_aisgk', 'homeworkimg', $homeworkid, '/', $filename, false)->out(false);
        return ['filename' => $filename, 'url' => $url];
    }
}
