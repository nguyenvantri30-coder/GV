<?php
namespace local_aisgk\local\service;

defined('MOODLE_INTERNAL') || die();

use local_aisgk\ai_key_manager;

/**
 * Generate background images declared by homework JSON as source="gen".
 *
 * This service is deliberately separate from ai_service.php: the homework LLM first
 * produces JSON + layout metadata; this service only materializes generated
 * backgrounds for preview/delivery. It does NOT generate drag item images yet.
 */
class image_generation_service {
    protected const DEFAULT_CANVAS_W = 1000;
    protected const DEFAULT_CANVAS_H = 1000;
    protected const MAX_IMAGES_PER_RUN = 8;

    /**
     * Generate missing background images for questions with images[id].source = "gen".
     * Failures are recorded per image under generated.status="error" and do not abort
     * the homework draft.
     */
    public static function generate_backgrounds_for_questions(array $questions, int $userid, int $courseid, int $sectionid, int $homeworkid, array $options = []): array {
        $preferuser = $userid > 0 && (bool)get_user_preferences('local_aisgk_use_my_api', 0, $userid);
        $count = 0;
        foreach ($questions as $qi => $q) {
            if (!is_array($q) || empty($q['images']) || !is_array($q['images'])) {
                continue;
            }
            foreach ($q['images'] as $id => $img) {
                if (!is_array($img)) { continue; }
                $source = strtolower(trim((string)($img['source'] ?? '')));
                if (!in_array($source, ['gen', 'generated', 'ai', 'generate'], true)) { continue; }
                if (!empty($img['generated']['fileurl']) || !empty($img['generated']['url'])) { continue; }
                if ($count >= self::MAX_IMAGES_PER_RUN) {
                    $img['generated'] = [
                        'status' => 'skipped',
                        'error' => 'Đã vượt giới hạn sinh ảnh nền trong một lần chạy.',
                    ];
                    $questions[$qi]['images'][$id] = $img;
                    continue;
                }
                $count++;
                $canvas = self::normalize_canvas($img['canvas'] ?? $img['canvas_size'] ?? null);
                $prompt = self::build_background_prompt($q, (string)$id, $img, $canvas);
                try {
                    $res = self::generate_image($prompt, $canvas, $userid, $preferuser);
                    $stored = self::store_generated_image($res['bytes'], (string)$id, (string)($img['label'] ?? $id), $courseid, $homeworkid, $canvas);
                    $img['source'] = 'gen';
                    $img['canvas'] = ['width' => $canvas['w'], 'height' => $canvas['h']];
                    $img['generated'] = [
                        'status' => 'ready',
                        'fileurl' => $stored['url'],
                        'filename' => $stored['filename'],
                        'width' => $canvas['w'],
                        'height' => $canvas['h'],
                        'model' => (string)($res['model'] ?? ''),
                        'provider' => (string)($res['provider'] ?? ''),
                        'prompt' => $prompt,
                    ];
                    $questions[$qi]['images'][$id] = $img;
                } catch (\Throwable $e) {
                    $img['source'] = 'gen';
                    $img['canvas'] = ['width' => $canvas['w'], 'height' => $canvas['h']];
                    $img['generated'] = [
                        'status' => 'error',
                        'error' => mb_substr($e->getMessage(), 0, 1000),
                        'prompt' => $prompt,
                    ];
                    $questions[$qi]['images'][$id] = $img;
                }
            }
        }
        return $questions;
    }

    protected static function normalize_canvas($value): array {
        if (is_array($value)) {
            $w = (int)($value['width'] ?? $value['w'] ?? $value[0] ?? self::DEFAULT_CANVAS_W);
            $h = (int)($value['height'] ?? $value['h'] ?? $value[1] ?? self::DEFAULT_CANVAS_H);
        } else {
            $w = self::DEFAULT_CANVAS_W;
            $h = self::DEFAULT_CANVAS_H;
        }
        $w = max(128, min(2048, $w));
        $h = max(128, min(2048, $h));
        return ['w' => $w, 'h' => $h];
    }

    protected static function build_background_prompt(array $q, string $imageid, array $img, array $canvas): string {
        $qtype = strtolower((string)($q['type'] ?? $q['qtype'] ?? ''));
        $description = trim((string)($img['description'] ?? $img['prompt'] ?? $img['image_prompt'] ?? $img['label'] ?? $imageid));
        $label = trim((string)($img['label'] ?? $imageid));
        $lines = [];
        $lines[] = 'Tạo ảnh nền phẳng 2D theo layout kỹ thuật, đúng tỉ lệ canvas ' . $canvas['w'] . 'x' . $canvas['h'] . ' pixel.';
        $lines[] = 'Không tạo ảnh chụp. Không phối cảnh, không bóng đổ, không texture, không watermark, không logo, không trang trí ngoài yêu cầu.';
        $lines[] = 'Nền trắng hoặc nền rất sạch. Ưu tiên độ chính xác bố cục hơn tính thẩm mỹ.';
        $lines[] = 'Các vùng tọa độ, marker, drop_zone nếu được liệt kê bên dưới là ràng buộc bố cục bắt buộc, không phải gợi ý.';
        $lines[] = 'Không tự thay đổi bố cục để đẹp hơn nếu làm lệch tọa độ.';
        $lines[] = 'Các đối tượng cần kéo thả/đánh dấu phải rõ ràng, tách biệt, không chồng lấn.';
        $lines[] = '';
        $lines[] = 'Nội dung ảnh (' . $label . '): ' . ($description !== '' ? $description : 'Tạo ảnh nền cho câu hỏi tương tác.');

        if ($qtype === 'ddimageortext') {
            $lines[] = '';
            $lines[] = 'Đây là ảnh nền cho câu hỏi kéo-thả ddimageortext. Phải vẽ sẵn các vùng trống/placeholder đúng theo drop_zone. Không ghi sẵn đáp án trong placeholder.';
            foreach (array_values((array)($q['items'] ?? [])) as $i => $item) {
                if (!is_array($item) || empty($item['drop_zone']) || !is_array($item['drop_zone'])) { continue; }
                $dz = self::normalize_box_assoc($item['drop_zone']);
                if (!$dz) { continue; }
                $n = $i + 1;
                $lines[] = '- Placeholder ' . $n . ': vùng x=' . $dz['left'] . '..' . ($dz['left'] + $dz['width']) . ', y=' . $dz['top'] . '..' . ($dz['top'] + $dz['height']) . '; vẽ ô trống rõ ràng, không ghi đáp án.';
            }
        } else if ($qtype === 'ddmarker') {
            $lines[] = '';
            $lines[] = 'Đây là ảnh nền cho câu hỏi ddmarker. Không vẽ sẵn nhãn đáp án hoặc khung đáp án trừ khi mô tả ảnh yêu cầu. Tuy nhiên đối tượng/vùng cần đánh dấu phải nằm đúng trong tọa độ tương ứng.';
            foreach (array_values((array)($q['markers'] ?? [])) as $i => $marker) {
                if (!is_array($marker)) { continue; }
                $coords = self::normalize_coords($marker['coords'] ?? []);
                if (!$coords) { continue; }
                $label = trim((string)($marker['label'] ?? ('Marker ' . ($i + 1))));
                $shape = trim((string)($marker['shape'] ?? 'rectangle'));
                $lines[] = '- ' . $label . ' (' . $shape . ') phải tương ứng với vùng x=' . $coords[0] . '..' . $coords[2] . ', y=' . $coords[1] . '..' . $coords[3] . '. Không cần hiển thị dòng tọa độ này trên ảnh.';
            }
        }

        $lines[] = '';
        $lines[] = 'Chỉ xuất ảnh. Không kèm chú thích ngoài ảnh.';
        return implode("\n", $lines);
    }

    protected static function normalize_box_assoc(array $box): ?array {
        $left = isset($box['left']) ? (int)$box['left'] : null;
        $top = isset($box['top']) ? (int)$box['top'] : null;
        $width = isset($box['width']) ? (int)$box['width'] : null;
        $height = isset($box['height']) ? (int)$box['height'] : null;
        if ($left === null || $top === null || $width === null || $height === null || $width <= 0 || $height <= 0) { return null; }
        return ['left' => $left, 'top' => $top, 'width' => $width, 'height' => $height];
    }

    protected static function normalize_coords($coords): ?array {
        if (!is_array($coords)) { return null; }
        $vals = array_values($coords);
        if (count($vals) < 4) { return null; }
        return [(int)$vals[0], (int)$vals[1], (int)$vals[2], (int)$vals[3]];
    }

    protected static function generate_image(string $prompt, array $canvas, int $userid, bool $preferuser): array {
        $attempted = [];
        $last = '';
        for ($try = 0; $try < 30; $try++) {
            $key = ai_key_manager::get_available_key('homework', $attempted, $userid, $preferuser, 0);
            if (!$key) { break; }
            $attempted[] = (string)($key->_source_table ?? 'local_aisgk_ai_keys') . ':' . (int)$key->id;
            $provider = ai_key_manager::provider_for_key($key);
            foreach (ai_key_manager::model_attempts_for_key($key, 'homework') as $model) {
                try {
                    $bytes = ($provider === 'shopaikey')
                        ? self::call_openai_image_compatible($key, $model, $prompt, $canvas)
                        : self::call_google_image($key, $model, $prompt);
                    if ($bytes === '') { throw new \moodle_exception('errorprocessingbook', 'local_aisgk', '', 'API không trả ảnh.'); }
                    $tokens = max(1, (int)ceil(mb_strlen($prompt, 'UTF-8') / 3) + 1200);
                    ai_key_manager::mark_success($key, $tokens, $model, $userid, 'homework');
                    return ['bytes' => self::resize_image_bytes($bytes, $canvas['w'], $canvas['h']), 'provider' => $provider, 'model' => $model];
                } catch (\Throwable $e) {
                    $last = $e->getMessage();
                    if (preg_match('/invalid api key|api key not valid|unauthorized|401/i', $last)) { ai_key_manager::mark_blocked($key, $last); break; }
                    if (preg_match('/429|rate limit|resource exhausted|too many requests|quota/i', $last)) { ai_key_manager::mark_429($key, $last, $model, 'homework'); continue; }
                    // Do not block/cooldown homework text models just because they do not support image output.
                    // Image generation is optional for the draft; record the error on the image instead.
                    ai_key_manager::release_key($key);
                }
            }
        }
        throw new \moodle_exception('errorprocessingbook', 'local_aisgk', '', 'Không sinh được ảnh nền. Lỗi cuối: ' . $last);
    }

    protected static function call_google_image(\stdClass $key, string $model, string $prompt): string {
        $apikey = trim((string)($key->api_key ?? ''));
        if ($apikey === '') { throw new \moodle_exception('errorprocessingbook', 'local_aisgk', '', 'API key rỗng.'); }
        $url = 'https://generativelanguage.googleapis.com/v1beta/models/' . rawurlencode($model) . ':generateContent';
        $payload = [
            'contents' => [[ 'parts' => [[ 'text' => $prompt ]] ]],
            'generationConfig' => [
                'temperature' => 0.05,
                'responseModalities' => ['TEXT', 'IMAGE'],
            ],
        ];
        $json = self::post_json($url, ['Content-Type: application/json', 'X-goog-api-key: ' . $apikey], $payload);
        foreach (($json['candidates'] ?? []) as $cand) {
            foreach (($cand['content']['parts'] ?? []) as $part) {
                $inline = $part['inlineData'] ?? $part['inline_data'] ?? null;
                if (is_array($inline) && !empty($inline['data'])) {
                    $bytes = base64_decode((string)$inline['data'], true);
                    if ($bytes !== false && $bytes !== '') { return $bytes; }
                }
            }
        }
        $text = '';
        foreach (($json['candidates'] ?? []) as $cand) {
            foreach (($cand['content']['parts'] ?? []) as $part) { if (!empty($part['text'])) { $text .= (string)$part['text']; } }
        }
        throw new \moodle_exception('errorprocessingbook', 'local_aisgk', '', 'Model không trả inline image. ' . mb_substr($text, 0, 300));
    }

    protected static function call_openai_image_compatible(\stdClass $key, string $model, string $prompt, array $canvas): string {
        $apikey = trim((string)($key->api_key ?? ''));
        if ($apikey === '') { throw new \moodle_exception('errorprocessingbook', 'local_aisgk', '', 'API key rỗng.'); }
        $url = 'https://api.shopaikey.com/v1/images/generations';
        $payload = [
            'model' => $model,
            'prompt' => $prompt,
            'n' => 1,
            'size' => self::openai_size_for_canvas($canvas),
            'response_format' => 'b64_json',
        ];
        $json = self::post_json($url, ['Content-Type: application/json', 'Authorization: Bearer ' . $apikey], $payload);
        $item = $json['data'][0] ?? null;
        if (is_array($item) && !empty($item['b64_json'])) {
            $bytes = base64_decode((string)$item['b64_json'], true);
            if ($bytes !== false && $bytes !== '') { return $bytes; }
        }
        if (is_array($item) && !empty($item['url'])) {
            return self::download_bytes((string)$item['url']);
        }
        throw new \moodle_exception('errorprocessingbook', 'local_aisgk', '', 'Image API không trả b64_json/url.');
    }

    protected static function openai_size_for_canvas(array $canvas): string {
        $w = max(1, (int)$canvas['w']);
        $h = max(1, (int)$canvas['h']);
        $ratio = $w / $h;
        if ($ratio > 1.25) { return '1536x1024'; }
        if ($ratio < 0.8) { return '1024x1536'; }
        return '1024x1024';
    }

    protected static function post_json(string $url, array $headers, array $payload): array {
        $ch = curl_init($url);
        curl_setopt_array($ch, [
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_POST => true,
            CURLOPT_HTTPHEADER => $headers,
            CURLOPT_POSTFIELDS => json_encode($payload, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES),
            CURLOPT_TIMEOUT => 240,
            CURLOPT_CONNECTTIMEOUT => 15,
        ]);
        $response = curl_exec($ch);
        $errno = curl_errno($ch);
        $error = curl_error($ch);
        $http = (int)curl_getinfo($ch, CURLINFO_RESPONSE_CODE);
        curl_close($ch);
        if ($errno) { throw new \moodle_exception('errorprocessingbook', 'local_aisgk', '', 'Lỗi kết nối API ảnh: ' . $error); }
        $json = json_decode((string)$response, true);
        if (!is_array($json)) { throw new \moodle_exception('errorprocessingbook', 'local_aisgk', '', 'API ảnh trả dữ liệu không hợp lệ: ' . mb_substr((string)$response, 0, 1000)); }
        if ($http >= 400 || !empty($json['error'])) {
            $err = $json['error'] ?? [];
            $msg = is_array($err) ? (string)($err['message'] ?? ('HTTP ' . $http)) : (string)$err;
            throw new \moodle_exception('errorprocessingbook', 'local_aisgk', '', 'IMAGE_API_ERROR: ' . $msg);
        }
        return $json;
    }

    protected static function download_bytes(string $url): string {
        if (!preg_match('#^https?://#i', $url)) { return ''; }
        $ch = curl_init($url);
        curl_setopt_array($ch, [CURLOPT_RETURNTRANSFER => true, CURLOPT_TIMEOUT => 60, CURLOPT_CONNECTTIMEOUT => 10]);
        $bytes = curl_exec($ch);
        $errno = curl_errno($ch);
        $error = curl_error($ch);
        $http = (int)curl_getinfo($ch, CURLINFO_RESPONSE_CODE);
        curl_close($ch);
        if ($errno || $http >= 400 || !is_string($bytes) || $bytes === '') {
            throw new \moodle_exception('errorprocessingbook', 'local_aisgk', '', 'Không tải được ảnh sinh: ' . ($error ?: ('HTTP ' . $http)));
        }
        return $bytes;
    }

    protected static function resize_image_bytes(string $bytes, int $targetw, int $targeth): string {
        if (!function_exists('imagecreatefromstring')) { return $bytes; }
        $img = @imagecreatefromstring($bytes);
        if (!$img) { return $bytes; }
        $w = imagesx($img); $h = imagesy($img);
        if ($w === $targetw && $h === $targeth) {
            ob_start(); imagepng($img); $out = (string)ob_get_clean(); imagedestroy($img); return $out;
        }
        $dst = imagecreatetruecolor($targetw, $targeth);
        $white = imagecolorallocate($dst, 255, 255, 255);
        imagefilledrectangle($dst, 0, 0, $targetw, $targeth, $white);
        imagecopyresampled($dst, $img, 0, 0, 0, 0, $targetw, $targeth, $w, $h);
        imagedestroy($img);
        ob_start(); imagepng($dst); $out = (string)ob_get_clean(); imagedestroy($dst);
        return $out;
    }

    protected static function store_generated_image(string $bytes, string $imageid, string $label, int $courseid, int $homeworkid, array $canvas): array {
        global $CFG;
        $context = \context_course::instance($courseid);
        $safeid = preg_replace('/[^a-zA-Z0-9_\-]+/', '_', $imageid) ?: 'bg';
        $filename = 'gen_' . $safeid . '_' . $canvas['w'] . 'x' . $canvas['h'] . '_' . substr(sha1($bytes), 0, 12) . '.png';
        $tmpdir = $CFG->dataroot . '/local_aisgk/tmp/genimg/' . $homeworkid;
        if (!is_dir($tmpdir)) { mkdir($tmpdir, $CFG->directorypermissions, true); }
        $tmpfile = $tmpdir . '/' . $filename;
        file_put_contents($tmpfile, $bytes);
        @chmod($tmpfile, $CFG->filepermissions);
        $fs = get_file_storage();
        $fileinfo = [
            'contextid' => $context->id,
            'component' => 'local_aisgk',
            'filearea' => 'homeworkimg',
            'itemid' => $homeworkid,
            'filepath' => '/',
            'filename' => $filename,
        ];
        if ($old = $fs->get_file($context->id, 'local_aisgk', 'homeworkimg', $homeworkid, '/', $filename)) { $old->delete(); }
        $fs->create_file_from_pathname($fileinfo, $tmpfile);
        @unlink($tmpfile);
        $url = \moodle_url::make_pluginfile_url($context->id, 'local_aisgk', 'homeworkimg', $homeworkid, '/', $filename, false)->out(false);
        return ['filename' => $filename, 'url' => $url];
    }
}
