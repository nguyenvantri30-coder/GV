<?php
namespace local_aisgk\local\service;

defined('MOODLE_INTERNAL') || die();

/**
 * Generate background images declared by homework JSON as source="gen".
 *
 * Important design choice:
 * - This service is intentionally independent from the normal text-model/key
 *   selection pipeline. Image generation needs image endpoints/models, not the
 *   homework text fallback list.
 * - For now it is a manual action behind the "Sinh bg" button. The main
 *   homework JSON generation/validation path must remain fast and must not wait
 *   for image generation.
 * - This service only generates background images. Drag item image generation is
 *   deliberately not implemented yet.
 */
class image_generation_service {
    protected const DEFAULT_CANVAS_W = 1000;
    protected const DEFAULT_CANVAS_H = 1000;
    protected const MAX_IMAGES_PER_RUN = 8;

    /**
     * ShopAIKey endpoints.
     */
    protected const SHOPAIKEY_BASE = 'https://api.shopaikey.com';

    /**
     * Test model order.
     * 1) nano-banana-2 0.5K: cheap/fast Google image endpoint.
     * 2) gpt-image-1 medium: OpenAI-compatible fallback for tests.
     *
     * This is intentionally hardcoded for the first test phase and does not use
     * ai_key_manager::model_attempts_for_key().
     */
    protected const IMAGE_ATTEMPTS = [
        [
            'provider' => 'shopaikey_google',
            'endpoint' => '/images/google/generations',
            'model' => 'nano-banana-2',
            'imageSize' => '0.5K',
            'format' => 'jpeg',
        ],
        [
            'provider' => 'shopaikey_openai',
            'endpoint' => '/v1/images/generations',
            'model' => 'gpt-image-1',
            'quality' => 'medium',
            'background' => 'opaque',
        ],
    ];

    /**
     * Generate missing background images for questions with images[id].source="gen".
     * Failures are recorded per image under generated.status="error" and do not
     * abort the homework draft.
     */
    public static function generate_backgrounds_for_questions(array $questions, int $userid, int $courseid, int $sectionid, int $homeworkid, array $options = []): array {
        $count = 0;

        foreach ($questions as $qi => $q) {
            if (!is_array($q) || empty($q['images']) || !is_array($q['images'])) {
                continue;
            }

            foreach ($q['images'] as $id => $img) {
                if (!is_array($img)) {
                    continue;
                }

                $source = strtolower(trim((string)($img['source'] ?? '')));
                if (!in_array($source, ['gen', 'generated', 'ai', 'generate'], true)) {
                    continue;
                }

                if (!empty($img['generated']['fileurl']) || !empty($img['generated']['url'])) {
                    continue;
                }

                if ($count >= self::MAX_IMAGES_PER_RUN) {
                    $img['generated'] = [
                        'status' => 'skipped',
                        'error' => 'Đã vượt giới hạn sinh ảnh nền trong một lần chạy.',
                    ];
                    $questions[$qi]['images'][$id] = $img;
                    continue;
                }

                $count++;
                $canvas = self::normalize_canvas($img['canvas'] ?? $img['canvas_size'] ?? null);
                $prompt = self::build_background_prompt($q, (string)$id, $img, $canvas);

                try {
                    $res = self::generate_image($prompt, $canvas, $options + ['userid' => $userid]);
                    $bytes = self::resize_image_bytes($res['bytes'], $canvas['w'], $canvas['h']);
                    $stored = self::store_generated_image($bytes, (string)$id, (string)($img['label'] ?? $id), $courseid, $homeworkid, $canvas);

                    $img['source'] = 'gen';
                    $img['canvas'] = ['width' => $canvas['w'], 'height' => $canvas['h']];
                    $img['generated'] = [
                        'status' => 'ready',
                        'fileurl' => $stored['url'],
                        'filename' => $stored['filename'],
                        'width' => $canvas['w'],
                        'height' => $canvas['h'],
                        'provider' => (string)($res['provider'] ?? ''),
                        'model' => (string)($res['model'] ?? ''),
                        'prompt' => $prompt,
                    ];
                    $questions[$qi]['images'][$id] = $img;
                } catch (\Throwable $e) {
                    $img['source'] = 'gen';
                    $img['canvas'] = ['width' => $canvas['w'], 'height' => $canvas['h']];
                    $img['generated'] = [
                        'status' => 'error',
                        'error' => mb_substr($e->getMessage(), 0, 1200),
                        'prompt' => $prompt,
                    ];
                    $questions[$qi]['images'][$id] = $img;
                }
            }
        }

        return $questions;
    }

    protected static function normalize_canvas($value): array {
        if (is_array($value)) {
            $w = (int)($value['width'] ?? $value['w'] ?? $value[0] ?? self::DEFAULT_CANVAS_W);
            $h = (int)($value['height'] ?? $value['h'] ?? $value[1] ?? self::DEFAULT_CANVAS_H);
        } else {
            $w = self::DEFAULT_CANVAS_W;
            $h = self::DEFAULT_CANVAS_H;
        }
        $w = max(128, min(2048, $w));
        $h = max(128, min(2048, $h));
        return ['w' => $w, 'h' => $h];
    }

    protected static function build_background_prompt(array $q, string $imageid, array $img, array $canvas): string {
        $qtype = strtolower((string)($q['type'] ?? $q['qtype'] ?? ''));
        $description = trim((string)($img['description'] ?? $img['prompt'] ?? $img['image_prompt'] ?? $img['label'] ?? $imageid));
        if ($description === '') {
            $description = 'Tạo ảnh nền cho câu hỏi tương tác.';
        }

        $lines = [];
        $lines[] = 'Tạo ảnh phẳng 2D dạng layout kỹ thuật giáo dục, nền trắng sạch.';
        $lines[] = '';
        $lines[] = 'Nội dung:';
        $lines[] = $description;
        $lines[] = '';
        $lines[] = 'Kích thước ảnh: ' . $canvas['w'] . 'x' . $canvas['h'] . ' pixel.';
        $lines[] = '';
        $lines[] = 'Yêu cầu hiển thị:';
        $lines[] = '- Font sans-serif rõ ràng, dễ đọc.';
        $lines[] = '- Màu đen hoặc màu đậm, tương phản cao trên nền trắng.';
        $lines[] = '- Các thành phần thẳng hàng, rõ ràng, không chồng lấn.';
        $lines[] = '- Không phối cảnh, không bóng đổ, không texture, không watermark, không logo.';
        $lines[] = '- Không thêm chi tiết ngoài yêu cầu.';
        $lines[] = '- Ưu tiên bố cục rõ ràng hơn tính nghệ thuật.';

        if ($qtype === 'ddimageortext') {
            $zones = [];
            foreach (array_values((array)($q['items'] ?? [])) as $item) {
                if (!is_array($item) || empty($item['drop_zone']) || !is_array($item['drop_zone'])) {
                    continue;
                }
                $dz = self::normalize_box_assoc($item['drop_zone']);
                if (!$dz) {
                    continue;
                }
                $zones[] = '- vùng x=' . $dz['left'] . '..' . ($dz['left'] + $dz['width'])
                    . ', y=' . $dz['top'] . '..' . ($dz['top'] + $dz['height']);
            }
            if ($zones) {
                $lines[] = '';
                $lines[] = 'Vẽ các placeholder hình chữ nhật nhỏ, rõ ràng tại các vùng:';
                $lines[] = implode("\n", $zones);
                $lines[] = 'Không ghi sẵn đáp án trong placeholder.';
            }
        } else if ($qtype === 'ddmarker') {
            $zones = [];
            foreach (array_values((array)($q['markers'] ?? [])) as $marker) {
                if (!is_array($marker)) {
                    continue;
                }
                $coords = self::normalize_coords($marker['coords'] ?? []);
                if (!$coords) {
                    continue;
                }
                $zones[] = '- x=' . $coords[0] . '..' . $coords[2] . ', y=' . $coords[1] . '..' . $coords[3];
            }
            if ($zones) {
                $lines[] = '';
                $lines[] = 'Các đối tượng/vùng cần đánh dấu phải nằm đúng hoặc gần đúng các vùng:';
                $lines[] = implode("\n", $zones);
                $lines[] = 'Không hiển thị tọa độ hoặc nhãn đáp án trên ảnh, trừ khi phần Nội dung yêu cầu rõ.';
            }
        }

        $lines[] = '';
        $lines[] = 'Chỉ xuất ảnh.';
        return implode("\n", $lines);
    }

    protected static function normalize_box_assoc(array $box): ?array {
        $left = isset($box['left']) ? (int)$box['left'] : null;
        $top = isset($box['top']) ? (int)$box['top'] : null;
        $width = isset($box['width']) ? (int)$box['width'] : null;
        $height = isset($box['height']) ? (int)$box['height'] : null;
        if ($left === null || $top === null || $width === null || $height === null || $width <= 0 || $height <= 0) {
            return null;
        }
        return ['left' => $left, 'top' => $top, 'width' => $width, 'height' => $height];
    }

    protected static function normalize_coords($coords): ?array {
        if (!is_array($coords)) {
            return null;
        }
        $vals = array_values($coords);
        if (count($vals) < 4) {
            return null;
        }
        return [(int)$vals[0], (int)$vals[1], (int)$vals[2], (int)$vals[3]];
    }

    /**
     * Hardcoded ShopAIKey image generation client.
     */
    protected static function generate_image(string $prompt, array $canvas, array $options = []): array {
        $apikey = self::resolve_api_key($options);
        if ($apikey === '') {
            throw new \moodle_exception('errorprocessingbook', 'local_aisgk', '', 'Chưa cấu hình ShopAIKey API key cho sinh ảnh. Đặt $CFG->local_aisgk_shopaikey_image_key hoặc biến môi trường SHOPAIKEY_IMAGE_KEY.');
        }

        $errors = [];
        foreach (self::IMAGE_ATTEMPTS as $attempt) {
            try {
                if ($attempt['provider'] === 'shopaikey_google') {
                    $bytes = self::call_shopaikey_google($apikey, $attempt, $prompt, $canvas);
                } else {
                    $bytes = self::call_shopaikey_openai($apikey, $attempt, $prompt, $canvas);
                }
                if ($bytes === '') {
                    throw new \moodle_exception('errorprocessingbook', 'local_aisgk', '', 'API sinh ảnh không trả bytes.');
                }
                return [
                    'bytes' => $bytes,
                    'provider' => $attempt['provider'],
                    'model' => $attempt['model'],
                ];
            } catch (\Throwable $e) {
                $errors[] = $attempt['model'] . ': ' . $e->getMessage();
            }
        }

        throw new \moodle_exception('errorprocessingbook', 'local_aisgk', '', 'Không sinh được ảnh nền qua ShopAIKey. ' . implode(' | ', $errors));
    }

    protected static function resolve_api_key(array $options = []): string {
        global $CFG;

        // Explicit override for quick tests.
        if (!empty($options['shopaikey_image_key']) && is_string($options['shopaikey_image_key'])) {
            return trim($options['shopaikey_image_key']);
        }

        // Reuse existing ShopAIKey keys from local_aisgk key tables. This only
        // reads the API key; it does not use the text-model fallback pipeline.
        $userid = isset($options['userid']) ? (int)$options['userid'] : 0;
        $dbkey = self::resolve_api_key_from_tables($userid);
        if ($dbkey !== '') {
            return $dbkey;
        }

        // Backward-compatible fallback for local testing.
        if (!empty($CFG->local_aisgk_shopaikey_image_key)) {
            return trim((string)$CFG->local_aisgk_shopaikey_image_key);
        }
        $env = getenv('SHOPAIKEY_IMAGE_KEY');
        if (is_string($env) && trim($env) !== '') {
            return trim($env);
        }
        return '';
    }

    /**
     * Find an active ShopAIKey API key already configured in this plugin.
     * Priority:
     * 1. current user's ShopAIKey pay key
     * 2. system ShopAIKey pay key
     * 3. other active ShopAIKey key
     */
    protected static function resolve_api_key_from_tables(int $userid = 0): string {
        global $DB;

        if (empty($DB)) {
            return '';
        }

        $tables = [];
        if ($userid > 0 && $DB->get_manager()->table_exists('local_aisgk_user_ai_keys')) {
            $tables[] = [
                'name' => 'local_aisgk_user_ai_keys',
                'where' => 'userid = ? AND provider = ? AND api_key <> ?',
                'params' => [$userid, 'shopaikey', ''],
            ];
        }
        if ($DB->get_manager()->table_exists('local_aisgk_ai_keys')) {
            $tables[] = [
                'name' => 'local_aisgk_ai_keys',
                'where' => 'provider = ? AND api_key <> ?',
                'params' => ['shopaikey', ''],
            ];
        }

        foreach ($tables as $table) {
            try {
                $records = $DB->get_records_select($table['name'], $table['where'], $table['params'], 'id ASC');
            } catch (\Throwable $e) {
                continue;
            }

            $rows = array_values($records);
            usort($rows, function($a, $b) {
                $ap = ((string)($a->category_key ?? '') === 'pay') ? 0 : 1;
                $bp = ((string)($b->category_key ?? '') === 'pay') ? 0 : 1;
                if ($ap !== $bp) {
                    return $ap <=> $bp;
                }
                return ((int)($a->id ?? 0)) <=> ((int)($b->id ?? 0));
            });

            foreach ($rows as $record) {
                if (!self::is_usable_shopaikey_record($record)) {
                    continue;
                }
                $key = trim((string)($record->api_key ?? ''));
                if ($key !== '') {
                    return $key;
                }
            }
        }

        return '';
    }

    protected static function is_usable_shopaikey_record(\stdClass $record): bool {
        $apikey = trim((string)($record->api_key ?? ''));
        if ($apikey === '') {
            return false;
        }
        if (trim((string)($record->provider ?? '')) !== 'shopaikey') {
            return false;
        }

        $status = trim((string)($record->status ?? 'active'));
        if ($status === 'blocked') {
            return false;
        }
        $cooldownuntil = (int)($record->cooldown_until ?? 0);
        if ($status === 'cooldown' && $cooldownuntil > time()) {
            return false;
        }
        if (isset($record->usage_remaining) && is_numeric($record->usage_remaining) && (float)$record->usage_remaining <= 0) {
            return false;
        }
        $dailylimit = (int)($record->daily_limit ?? 0);
        $dailyused = (int)($record->daily_used ?? 0);
        if ($dailylimit > 0 && $dailyused >= $dailylimit) {
            return false;
        }
        return true;
    }

    protected static function call_shopaikey_google(string $apikey, array $attempt, string $prompt, array $canvas): string {
        $payload = [
            'model' => $attempt['model'],
            'prompt' => $prompt,
            'size' => self::google_ratio_for_canvas($canvas),
            'format' => $attempt['format'] ?? 'jpeg',
            'response_format' => 'url',
            'image_urls' => [],
        ];
        if (!empty($attempt['imageSize'])) {
            $payload['imageSize'] = $attempt['imageSize'];
        }

        $json = self::post_json(self::SHOPAIKEY_BASE . $attempt['endpoint'], [
            'Content-Type: application/json',
            'Authorization: Bearer ' . $apikey,
        ], $payload, 90);

        $url = self::extract_image_url($json);
        if ($url !== '') {
            return self::download_bytes($url);
        }
        $b64 = self::extract_b64_json($json);
        if ($b64 !== '') {
            $bytes = base64_decode($b64, true);
            if ($bytes !== false && $bytes !== '') {
                return $bytes;
            }
        }

        throw new \moodle_exception('errorprocessingbook', 'local_aisgk', '', 'Google image endpoint không trả url/b64_json: ' . mb_substr(json_encode($json, JSON_UNESCAPED_UNICODE), 0, 800));
    }

    protected static function call_shopaikey_openai(string $apikey, array $attempt, string $prompt, array $canvas): string {
        $payload = [
            'model' => $attempt['model'],
            'prompt' => $prompt,
            'n' => 1,
            'size' => self::openai_size_for_canvas($canvas),
            'quality' => $attempt['quality'] ?? 'medium',
            'background' => $attempt['background'] ?? 'opaque',
        ];

        $json = self::post_json(self::SHOPAIKEY_BASE . $attempt['endpoint'], [
            'Content-Type: application/json',
            'Authorization: Bearer ' . $apikey,
        ], $payload, 120);

        $url = self::extract_image_url($json);
        if ($url !== '') {
            return self::download_bytes($url);
        }
        $b64 = self::extract_b64_json($json);
        if ($b64 !== '') {
            $bytes = base64_decode($b64, true);
            if ($bytes !== false && $bytes !== '') {
                return $bytes;
            }
        }

        throw new \moodle_exception('errorprocessingbook', 'local_aisgk', '', 'OpenAI-compatible image endpoint không trả url/b64_json: ' . mb_substr(json_encode($json, JSON_UNESCAPED_UNICODE), 0, 800));
    }

    protected static function extract_image_url(array $json): string {
        $candidates = [
            $json['data'][0]['url'] ?? null,
            $json['data'][0]['image_url'] ?? null,
            $json['url'] ?? null,
            $json['image_url'] ?? null,
            $json['output'][0]['url'] ?? null,
            $json['result']['url'] ?? null,
        ];
        foreach ($candidates as $url) {
            if (is_string($url) && preg_match('#^https?://#i', $url)) {
                return $url;
            }
        }
        return '';
    }

    protected static function extract_b64_json(array $json): string {
        $candidates = [
            $json['data'][0]['b64_json'] ?? null,
            $json['b64_json'] ?? null,
            $json['image'] ?? null,
            $json['result']['b64_json'] ?? null,
        ];
        foreach ($candidates as $b64) {
            if (is_string($b64) && $b64 !== '') {
                if (preg_match('#^data:image/[^;]+;base64,#', $b64)) {
                    $b64 = preg_replace('#^data:image/[^;]+;base64,#', '', $b64);
                }
                return $b64;
            }
        }
        return '';
    }

    protected static function google_ratio_for_canvas(array $canvas): string {
        $w = max(1, (int)$canvas['w']);
        $h = max(1, (int)$canvas['h']);
        $ratio = $w / $h;

        if ($ratio >= 2.2) {
            return '2:1';
        }
        if ($ratio >= 1.55) {
            return '16:9';
        }
        if ($ratio >= 1.20) {
            return '4:3';
        }
        if ($ratio <= 0.45) {
            return '1:2';
        }
        if ($ratio <= 0.65) {
            return '2:3';
        }
        if ($ratio <= 0.85) {
            return '3:4';
        }
        return '1:1';
    }

    protected static function openai_size_for_canvas(array $canvas): string {
        $w = max(1, (int)$canvas['w']);
        $h = max(1, (int)$canvas['h']);
        $ratio = $w / $h;

        // ShopAIKey examples show that gpt-image-1 supports auto. Use auto so the
        // provider decides a supported size, then resize locally to canvas.
        if ($ratio > 0) {
            return 'auto';
        }
        return 'auto';
    }

    protected static function post_json(string $url, array $headers, array $payload, int $timeout = 120): array {
        $ch = curl_init($url);
        curl_setopt_array($ch, [
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_POST => true,
            CURLOPT_HTTPHEADER => $headers,
            CURLOPT_POSTFIELDS => json_encode($payload, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES),
            CURLOPT_TIMEOUT => $timeout,
            CURLOPT_CONNECTTIMEOUT => 12,
        ]);
        $response = curl_exec($ch);
        $errno = curl_errno($ch);
        $error = curl_error($ch);
        $http = (int)curl_getinfo($ch, CURLINFO_RESPONSE_CODE);
        curl_close($ch);

        if ($errno) {
            throw new \moodle_exception('errorprocessingbook', 'local_aisgk', '', 'Lỗi kết nối API ảnh: ' . $error);
        }

        $json = json_decode((string)$response, true);
        if (!is_array($json)) {
            throw new \moodle_exception('errorprocessingbook', 'local_aisgk', '', 'API ảnh trả dữ liệu không hợp lệ: ' . mb_substr((string)$response, 0, 1000));
        }

        if ($http >= 400 || !empty($json['error'])) {
            $err = $json['error'] ?? [];
            $msg = is_array($err) ? (string)($err['message'] ?? ('HTTP ' . $http)) : (string)$err;
            throw new \moodle_exception('errorprocessingbook', 'local_aisgk', '', 'IMAGE_API_ERROR HTTP ' . $http . ': ' . $msg);
        }

        return $json;
    }

    protected static function download_bytes(string $url): string {
        if (!preg_match('#^https?://#i', $url)) {
            return '';
        }
        $ch = curl_init($url);
        curl_setopt_array($ch, [
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_TIMEOUT => 80,
            CURLOPT_CONNECTTIMEOUT => 10,
            CURLOPT_FOLLOWLOCATION => true,
        ]);
        $bytes = curl_exec($ch);
        $errno = curl_errno($ch);
        $error = curl_error($ch);
        $http = (int)curl_getinfo($ch, CURLINFO_RESPONSE_CODE);
        curl_close($ch);

        if ($errno || $http >= 400 || !is_string($bytes) || $bytes === '') {
            throw new \moodle_exception('errorprocessingbook', 'local_aisgk', '', 'Không tải được ảnh sinh: ' . ($error ?: ('HTTP ' . $http)));
        }
        return $bytes;
    }

    protected static function resize_image_bytes(string $bytes, int $targetw, int $targeth): string {
        if (!function_exists('imagecreatefromstring')) {
            return $bytes;
        }
        $img = @imagecreatefromstring($bytes);
        if (!$img) {
            return $bytes;
        }

        $w = imagesx($img);
        $h = imagesy($img);
        if ($w === $targetw && $h === $targeth) {
            ob_start();
            imagepng($img);
            $out = (string)ob_get_clean();
            imagedestroy($img);
            return $out;
        }

        $dst = imagecreatetruecolor($targetw, $targeth);
        $white = imagecolorallocate($dst, 255, 255, 255);
        imagefilledrectangle($dst, 0, 0, $targetw, $targeth, $white);
        imagecopyresampled($dst, $img, 0, 0, 0, 0, $targetw, $targeth, $w, $h);
        imagedestroy($img);

        ob_start();
        imagepng($dst);
        $out = (string)ob_get_clean();
        imagedestroy($dst);
        return $out;
    }

    protected static function store_generated_image(string $bytes, string $imageid, string $label, int $courseid, int $homeworkid, array $canvas): array {
        global $CFG;

        $context = \context_course::instance($courseid);
        $safeid = preg_replace('/[^a-zA-Z0-9_\-]+/', '_', $imageid) ?: 'bg';
        $filename = 'gen_' . $safeid . '_' . $canvas['w'] . 'x' . $canvas['h'] . '_' . substr(sha1($bytes), 0, 12) . '.png';
        $tmpdir = $CFG->dataroot . '/local_aisgk/tmp/genimg/' . $homeworkid;
        if (!is_dir($tmpdir)) {
            mkdir($tmpdir, $CFG->directorypermissions, true);
        }
        $tmpfile = $tmpdir . '/' . $filename;
        file_put_contents($tmpfile, $bytes);
        @chmod($tmpfile, $CFG->filepermissions);

        $fs = get_file_storage();
        $fileinfo = [
            'contextid' => $context->id,
            'component' => 'local_aisgk',
            'filearea' => 'homeworkimg',
            'itemid' => $homeworkid,
            'filepath' => '/',
            'filename' => $filename,
        ];
        if ($old = $fs->get_file($context->id, 'local_aisgk', 'homeworkimg', $homeworkid, '/', $filename)) {
            $old->delete();
        }
        $fs->create_file_from_pathname($fileinfo, $tmpfile);
        @unlink($tmpfile);

        $url = \moodle_url::make_pluginfile_url($context->id, 'local_aisgk', 'homeworkimg', $homeworkid, '/', $filename, false)->out(false);
        return ['filename' => $filename, 'url' => $url];
    }
}
