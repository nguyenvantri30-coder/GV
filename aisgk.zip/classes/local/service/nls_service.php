<?php
namespace local_aisgk\local\service;

defined('MOODLE_INTERNAL') || die();

class nls_service {
    public static function stats(): array {
        global $DB;
        $tables = [
            'domain' => 'local_aisgk_nls_domain',
            'component' => 'local_aisgk_nls_component',
            'level_map' => 'local_aisgk_nls_level_map',
            'progression_grade' => 'local_aisgk_nls_progression_grade',
            'indicator_grade' => 'local_aisgk_nls_indicator_grade',
        ];
        $out = [];
        foreach ($tables as $k => $t) {
            $out[$k] = $DB->get_manager()->table_exists($t) ? (int)$DB->count_records($t) : 0;
        }
        $last = $DB->get_manager()->table_exists('local_aisgk_nls_import')
            ? $DB->get_record('local_aisgk_nls_import', [], '*', IGNORE_MULTIPLE)
            : false;
        $out['last'] = $last ?: null;
        return $out;
    }

    public static function import_uploaded_file(array $file): array {
        global $DB, $USER;
        if (empty($file['tmp_name']) || !is_uploaded_file($file['tmp_name'])) {
            throw new \moodle_exception('nofile', 'local_aisgk');
        }
        if (!empty($file['error']) && (int)$file['error'] !== UPLOAD_ERR_OK) {
            throw new \moodle_exception('uploaderrorserver', 'local_aisgk', '', $file['error']);
        }
        $filename = clean_param((string)$file['name'], PARAM_FILE);
        $ext = strtolower(pathinfo($filename, PATHINFO_EXTENSION));
        if ($ext !== 'xlsx' && $ext !== 'csv') {
            throw new \moodle_exception('nlsimportinvalidfile', 'local_aisgk');
        }
        self::ensure_tables_exist();
        $sheets = $ext === 'xlsx' ? self::read_xlsx($file['tmp_name']) : ['nls_indicator_grade' => self::read_csv($file['tmp_name'])];
        $transaction = $DB->start_delegated_transaction();
        foreach (['local_aisgk_nls_indicator_grade','local_aisgk_nls_progression_grade','local_aisgk_nls_level_map','local_aisgk_nls_component','local_aisgk_nls_domain'] as $t) {
            if ($DB->get_manager()->table_exists($t)) { $DB->delete_records($t); }
        }
        $counts = [];
        $counts['domain'] = self::import_sheet($sheets, ['nls_domain','domain'], 'local_aisgk_nls_domain', ['domain_code','domain_name','description']);
        $counts['component'] = self::import_sheet($sheets, ['nls_component','component'], 'local_aisgk_nls_component', ['component_code','domain_code','component_name','component_desc']);
        $counts['level_map'] = self::import_sheet($sheets, ['nls_level_map','level_map'], 'local_aisgk_nls_level_map', ['level_code','level_name','grade_from','grade_to']);
        $counts['progression_grade'] = self::import_sheet($sheets, ['nls_progression_grade','progression_grade'], 'local_aisgk_nls_progression_grade', ['component_code','level_code','grade_from','grade_to','progression_text']);
        $counts['indicator_grade'] = self::import_sheet($sheets, ['nls_indicator_grade','indicator_grade','nls_items','nls_master'], 'local_aisgk_nls_indicator_grade', ['code','canonical_code','component_code','level_code','grade_from','grade_to','indicator_code','indicator_text','short_label','active']);
        if (empty($counts['indicator_grade'])) {
            throw new \moodle_exception('nlsimportnoindicator', 'local_aisgk');
        }
        if ($DB->get_manager()->table_exists('local_aisgk_nls_import')) {
            $DB->delete_records('local_aisgk_nls_import');
            $rec = (object)['filename'=>$filename,'itemcounts'=>json_encode($counts, JSON_UNESCAPED_UNICODE),'timecreated'=>time(),'usermodified'=>$USER->id ?? 0];
            $DB->insert_record('local_aisgk_nls_import', $rec);
        }
        $transaction->allow_commit();
        return $counts;
    }

    protected static function ensure_tables_exist(): void {
        global $DB;
        $needed = ['local_aisgk_nls_indicator_grade'];
        foreach ($needed as $t) {
            if (!$DB->get_manager()->table_exists($t)) {
                throw new \moodle_exception('nlsdbmissing', 'local_aisgk');
            }
        }
    }

    protected static function import_sheet(array $sheets, array $names, string $table, array $allowed): int {
        global $DB;
        if (!$DB->get_manager()->table_exists($table)) { return 0; }
        $rows = [];
        foreach ($names as $name) {
            $key = self::normalize_key($name);
            if (isset($sheets[$key])) { $rows = $sheets[$key]; break; }
        }
        if (!$rows) { return 0; }
        $header = array_map([self::class,'normalize_key'], array_shift($rows));
        $count = 0;
        foreach ($rows as $row) {
            $rec = new \stdClass();
            $has = false;
            foreach ($allowed as $field) {
                $idx = array_search(self::normalize_key($field), $header, true);
                $value = $idx !== false ? trim((string)($row[$idx] ?? '')) : '';
                if (in_array($field, ['grade_from','grade_to','active'], true)) {
                    $value = ($value === '') ? ($field === 'active' ? 1 : 0) : (int)preg_replace('/[^0-9-]/', '', $value);
                } else {
                    $value = clean_param($value, PARAM_TEXT);
                }
                $rec->{$field} = $value;
                if ($value !== '' && $value !== 0) { $has = true; }
            }
            if (!$has) { continue; }
            if ($table === 'local_aisgk_nls_indicator_grade') {
                if (empty($rec->code) && !empty($rec->canonical_code)) { $rec->code = $rec->canonical_code; }
                if (empty($rec->canonical_code) && !empty($rec->code)) { $rec->canonical_code = $rec->code; }
            }
            $rec->timecreated = time();
            $DB->insert_record($table, $rec);
            $count++;
        }
        return $count;
    }

    protected static function read_csv(string $path): array {
        $rows = [];
        if (($h = fopen($path, 'r')) !== false) {
            while (($row = fgetcsv($h)) !== false) { $rows[] = $row; }
            fclose($h);
        }
        return $rows;
    }

    protected static function read_xlsx(string $path): array {
        if (!class_exists('ZipArchive')) { throw new \moodle_exception('nlszipmissing', 'local_aisgk'); }
        $zip = new \ZipArchive();
        if ($zip->open($path) !== true) { throw new \moodle_exception('nlsimportinvalidfile', 'local_aisgk'); }
        $shared = [];
        $ss = $zip->getFromName('xl/sharedStrings.xml');
        if ($ss !== false) {
            $xml = @simplexml_load_string($ss);
            if ($xml) {
                foreach ($xml->si as $si) {
                    $txt = '';
                    if (isset($si->t)) { $txt = (string)$si->t; }
                    else { foreach ($si->r as $r) { $txt .= (string)$r->t; } }
                    $shared[] = $txt;
                }
            }
        }
        $wb = @simplexml_load_string((string)$zip->getFromName('xl/workbook.xml'));
        $rels = @simplexml_load_string((string)$zip->getFromName('xl/_rels/workbook.xml.rels'));
        $relmap = [];
        if ($rels) { foreach ($rels->Relationship as $r) { $relmap[(string)$r['Id']] = (string)$r['Target']; } }
        $out = [];
        if ($wb) {
            $wb->registerXPathNamespace('r', 'http://schemas.openxmlformats.org/officeDocument/2006/relationships');
            foreach ($wb->sheets->sheet as $sheet) {
                $name = self::normalize_key((string)$sheet['name']);
                $attrs = $sheet->attributes('http://schemas.openxmlformats.org/officeDocument/2006/relationships');
                $rid = (string)$attrs['id'];
                $target = $relmap[$rid] ?? '';
                if ($target === '') { continue; }
                $target = str_replace('worksheets/', 'xl/worksheets/', $target);
                if (strpos($target, 'xl/') !== 0) { $target = 'xl/' . ltrim($target, '/'); }
                $sx = @simplexml_load_string((string)$zip->getFromName($target));
                if (!$sx) { continue; }
                $rows = [];
                foreach ($sx->sheetData->row as $xr) {
                    $r = [];
                    foreach ($xr->c as $c) {
                        $ref = (string)$c['r'];
                        $col = self::col_index($ref);
                        while (count($r) < $col) { $r[] = ''; }
                        $v = (string)$c->v;
                        $type = (string)$c['t'];
                        if ($type === 's') { $v = $shared[(int)$v] ?? ''; }
                        if ($type === 'inlineStr' && isset($c->is->t)) { $v = (string)$c->is->t; }
                        $r[$col] = $v;
                    }
                    if (array_filter($r, fn($x)=>trim((string)$x)!=='')) { $rows[] = $r; }
                }
                $out[$name] = $rows;
            }
        }
        $zip->close();
        return $out;
    }

    protected static function col_index(string $ref): int {
        if (!preg_match('/^([A-Z]+)/', $ref, $m)) { return 0; }
        $n = 0;
        foreach (str_split($m[1]) as $ch) { $n = $n * 26 + (ord($ch) - 64); }
        return $n - 1;
    }

    protected static function normalize_key(string $s): string {
        $s = trim(mb_strtolower($s, 'UTF-8'));
        $s = str_replace([' ', '-', '.'], '_', $s);
        $s = preg_replace('/[^a-z0-9_\x{0080}-\x{FFFF}]/u', '', $s) ?? $s;
        return $s;
    }
}
