<?php
namespace local_aisgk\local\service;

defined('MOODLE_INTERNAL') || die();

/**
 * School-year closing backup service for ALSM/local_aisgk.
 *
 * Backup nam cu is archival only:
 *  - export the WHOLE Moodle database, including local_aisgk tables, to SQL;
 *  - export local_aisgk tables to a second SQL file for quick ALSM-only inspection;
 *  - pack Moodle file storage (moodledata/filedir) and ALSM runtime files;
 *  - write a manifest with checksums and restore notes.
 *
 * This service must NOT delete old-year data. Deletion/pruning is deferred to the
 * "Tao nam hoc moi" + "Ke thua du lieu" workflow after the admin chooses what to keep.
 */
class school_year_backup_service {
    private const ALSM_TABLE_PREFIX = 'local_aisgk';

    /** Tables that must never be truncated by ALSM year closing cleanup. */
    private const HARD_PROTECTED_TABLES = [
        // Moodle identities, roles, auth, preferences and core configuration.
        'user', 'user_info_category', 'user_info_data', 'user_info_field', 'user_preferences',
        'role', 'role_allow_assign', 'role_allow_override', 'role_allow_switch', 'role_allow_view',
        'role_capabilities', 'role_context_levels', 'role_names', 'role_assignments',
        'capabilities', 'context', 'config', 'config_log', 'config_plugins', 'modules', 'block',
        'auth_oauth2_linked_login', 'oauth2_access_token', 'oauth2_endpoint', 'oauth2_issuer',
        'oauth2_refresh_token', 'oauth2_system_account', 'external_services', 'external_tokens',

        // ALSM API keys: system and personal. Never delete in any mode.
        'local_aisgk_ai_keys', 'local_aisgk_user_ai_keys',

        // Backup/year registry must be preserved so the admin can still download and audit.
        'local_aisgk_school_year', 'local_aisgk_backup', 'local_aisgk_backup_item',
    ];

    /** ALSM tables that are year/transactional data and may be cleared for a new year. */
    private const ALSM_YEAR_DATA_TABLES = [
        'local_aisgk_books', 'local_aisgk_book_toc', 'local_aisgk_book_toc_draft',
        'local_aisgk_section_toc', 'local_aisgk_jobs', 'local_aisgk_homeworks',
        'local_aisgk_pagecache', 'local_aisgk_user_usage', 'local_aisgk_api_calls',
    ];

    /** Moodle learning/course data tables commonly not reused for a new school year. */
    private const MOODLE_YEAR_DATA_TABLES = [
        'course_modules_completion', 'course_completion_criteria', 'course_completion_crit_compl',
        'course_completions', 'course_sections', 'course_modules', 'course_format_options',
        'course_completion_defaults', 'course',
        'quiz', 'quiz_attempts', 'quiz_grades', 'quiz_slots', 'quiz_sections', 'quiz_feedback',
        'question_usages', 'question_attempts', 'question_attempt_steps', 'question_attempt_step_data',
        'question', 'question_answers', 'question_bank_entries', 'question_categories',
        'question_versions', 'question_references', 'question_set_references',
        'grade_grades', 'grade_items', 'grade_categories', 'grade_outcomes', 'grade_outcomes_courses',
        'enrol', 'user_enrolments', 'groups', 'groups_members', 'groupings', 'groupings_groups',
        'assign', 'assign_submission', 'assign_grades', 'assignfeedback_comments', 'assignsubmission_file',
        'forum', 'forum_discussions', 'forum_posts', 'forum_digests', 'forum_read', 'forum_subscriptions',
        'resource', 'page', 'url', 'book', 'book_chapters', 'label', 'folder',
    ];

    public static function get_or_create_current_school_year(): \stdClass {
        global $DB, $USER;
        $now = time();
        $record = $DB->get_record('local_aisgk_school_year', ['isactive' => 1], '*', IGNORE_MULTIPLE);
        if ($record) {
            return $record;
        }
        $y = (int)date('Y', $now);
        $m = (int)date('n', $now);
        $startyear = ($m >= 8) ? $y : ($y - 1);
        $endyear = $startyear + 1;
        $record = (object)[
            'name' => $startyear . '-' . $endyear,
            'startyear' => $startyear,
            'endyear' => $endyear,
            'timestart' => mktime(0, 0, 0, 8, 1, $startyear),
            'timeend' => mktime(23, 59, 59, 7, 31, $endyear),
            'isactive' => 1,
            'status' => 'active',
            'configjson' => json_encode(['autocreated' => true], JSON_UNESCAPED_UNICODE),
            'timecreated' => $now,
            'timemodified' => $now,
            'usermodified' => (int)$USER->id,
        ];
        $record->id = $DB->insert_record('local_aisgk_school_year', $record);
        return $record;
    }

    /** Create a full database SQL backup for closing the current school year. */
    public static function create_current_year_backup(string $note = ''): \stdClass {
        global $DB, $CFG, $USER;
        require_once($CFG->libdir . '/filelib.php');

        $now = time();
        $year = self::get_or_create_current_school_year();
        $backup = (object)[
            'schoolyearid' => (int)$year->id,
            'backuptype' => 'school_year_full_archive',
            'status' => 'running',
            'title' => 'ALSM full school-year archive ' . $year->name . ' ' . userdate($now, '%Y%m%d-%H%M%S'),
            'description' => $note,
            'filepath' => '',
            'filesize' => 0,
            'checksum' => '',
            'summaryjson' => '',
            'createdby' => (int)$USER->id,
            'timecreated' => $now,
            'timemodified' => $now,
            'finishedat' => 0,
        ];
        $backup->id = $DB->insert_record('local_aisgk_backup', $backup);

        try {
            $dir = make_writable_directory($CFG->dataroot . '/local_aisgk/backups');
            $safeyear = clean_param($year->name, PARAM_FILE);
            $stamp = date('Ymd_His', $now) . '_' . $backup->id;

            $fulldb = $dir . '/moodle_alsm_full_database_' . $safeyear . '_' . $stamp . '.sql';
            $alsmonly = $dir . '/alsm_local_aisgk_only_' . $safeyear . '_' . $stamp . '.sql';
            $manifest = $dir . '/backup_manifest_' . $safeyear . '_' . $stamp . '.json';
            $zipfile = $dir . '/alsm_schoolyear_full_archive_' . $safeyear . '_' . $stamp . '.alb.zip';

            $summary = self::dump_database_to_sql_files((int)$backup->id, $year, $fulldb, $alsmonly);
            $summary['archive'] = [
                'zip' => basename($zipfile),
                'full_database_sql' => basename($fulldb),
                'alsm_only_sql' => basename($alsmonly),
                'moodledata_scope' => [
                    'filedir' => 'moodledata/filedir (question bank files, course files, user uploads)',
                    'local_aisgk' => 'moodledata/local_aisgk except backup archive folder',
                    'volatile_excluded' => ['cache', 'localcache', 'temp', 'sessions', 'trashdir'],
                ],
            ];
            file_put_contents($manifest, json_encode($summary, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE));
            self::zip_backup_files($zipfile, [$fulldb, $alsmonly, $manifest], (int)$backup->id, true);
            clearstatcache(true, $zipfile);
            if (!is_file($zipfile) || !is_readable($zipfile)) {
                throw new \moodle_exception('cannotwritebackup', 'local_aisgk', '', null, 'ZIP archive was not created: ' . $zipfile);
            }

            $zipsize = filesize($zipfile);
            $zipsha1 = sha1_file($zipfile);
            if ($zipsize === false || $zipsha1 === false) {
                throw new \moodle_exception('cannotwritebackup', 'local_aisgk', '', null, 'ZIP archive exists but cannot be read: ' . $zipfile);
            }

            $summary['archive']['zip_size'] = (int)$zipsize;
            $summary['archive']['zip_sha1'] = (string)$zipsha1;

            $backup->status = 'done';
            $backup->filepath = $zipfile;
            $backup->filesize = (int)$zipsize;
            $backup->checksum = (string)$zipsha1;
            $backup->summaryjson = json_encode($summary, JSON_UNESCAPED_UNICODE);
            $backup->timemodified = time();
            $backup->finishedat = time();
            $DB->update_record('local_aisgk_backup', $backup);
        } catch (\Throwable $e) {
            $backup->status = 'failed';
            $backup->summaryjson = json_encode(['error' => $e->getMessage()], JSON_UNESCAPED_UNICODE);
            $backup->timemodified = time();
            $backup->finishedat = time();
            $DB->update_record('local_aisgk_backup', $backup);
            throw $e;
        }
        return $backup;
    }

    public static function get_download_path(int $backupid): string {
        global $DB, $CFG;
        $backup = $DB->get_record('local_aisgk_backup', ['id' => $backupid], '*', MUST_EXIST);
        if ($backup->status !== 'done' || empty($backup->filepath)) {
            throw new \moodle_exception('backupnotready', 'local_aisgk');
        }
        $base = realpath($CFG->dataroot . '/local_aisgk/backups');
        $real = realpath((string)$backup->filepath);
        if (!$base || !$real || strpos($real, $base) !== 0 || !is_readable($real)) {
            throw new \moodle_exception('filenotfound');
        }
        return $real;
    }

    public static function get_latest_backup_progress(int $userid): array {
        global $DB;
        $backup = $DB->get_record_sql(
            'SELECT * FROM {local_aisgk_backup} WHERE createdby = ? ORDER BY timecreated DESC',
            [$userid],
            IGNORE_MULTIPLE
        );
        if (!$backup) {
            return ['hasbackup' => false];
        }
        $lastitem = $DB->get_record_sql(
            'SELECT * FROM {local_aisgk_backup_item} WHERE backupid = ? ORDER BY timecreated DESC, id DESC',
            [(int)$backup->id],
            IGNORE_MULTIPLE
        );
        $itemcount = (int)$DB->count_records('local_aisgk_backup_item', ['backupid' => (int)$backup->id]);
        return [
            'hasbackup' => true,
            'id' => (int)$backup->id,
            'status' => (string)$backup->status,
            'title' => (string)$backup->title,
            'timecreated' => (int)$backup->timecreated,
            'finishedat' => (int)$backup->finishedat,
            'filesize' => (int)$backup->filesize,
            'checksum' => (string)$backup->checksum,
            'itemcount' => $itemcount,
            'lastitem' => $lastitem ? [
                'itemtype' => (string)$lastitem->itemtype,
                'itemkey' => (string)$lastitem->itemkey,
                'recordcount' => (int)$lastitem->recordcount,
                'status' => (string)$lastitem->status,
                'message' => (string)$lastitem->message,
                'timecreated' => (int)$lastitem->timecreated,
            ] : null,
        ];
    }

    /** Build a cleanup preview; no data is deleted. Kept for later inheritance step wiring. */
    public static function cleanup_preview(string $mode): array {
        $tables = self::cleanup_tables_for_mode($mode);
        $preview = [];
        foreach ($tables as $table) {
            if (self::table_exists($table) && !self::is_hard_protected_table($table)) {
                $preview[$table] = self::count_records($table);
            }
        }
        ksort($preview, SORT_NATURAL);
        return $preview;
    }

    /**
     * Destructive cleanup is intentionally disabled here.
     * Backup nam cu must only archive. Deletion belongs to the Ke thua du lieu workflow.
     */
    public static function cleanup_after_backup(int $backupid, string $mode): array {
        throw new \moodle_exception('cleanupdeferredtoinheritance', 'local_aisgk');
    }

    private static function cleanup_tables_for_mode(string $mode): array {
        if ($mode === 'full_reset_protected') {
            return array_values(array_unique(array_merge(self::MOODLE_YEAR_DATA_TABLES, self::ALSM_YEAR_DATA_TABLES)));
        }
        return self::ALSM_YEAR_DATA_TABLES;
    }

    private static function dump_database_to_sql_files(int $backupid, \stdClass $year, string $fulldb, string $alsmonly): array {
        global $CFG;
        $tables = self::get_database_tables();
        sort($tables, SORT_NATURAL);

        $fullfh = fopen($fulldb, 'wb');
        $alsmfh = fopen($alsmonly, 'wb');
        if (!$fullfh || !$alsmfh) {
            throw new \moodle_exception('cannotwritebackup', 'local_aisgk');
        }
        self::write_sql_header($fullfh, $year, 'FULL_MOODLE_DATABASE_INCLUDING_ALSM');
        self::write_sql_header($alsmfh, $year, 'ALSM_LOCAL_AISGK_ONLY');

        $summary = [
            'schema' => 'local_aisgk_school_year_full_archive_v4',
            'schoolyear' => $year->name,
            'generated_at' => time(),
            'plugin' => 'local_aisgk',
            'moodle_release' => $CFG->release ?? '',
            'dbtype' => $CFG->dbtype ?? '',
            'backup_policy' => 'Backup nam cu is archive-only: full Moodle database SQL + ALSM-only SQL + Moodle file storage. It never deletes data. New-year cleanup is deferred to the inheritance workflow.',
            'hard_protected_cleanup_tables' => self::HARD_PROTECTED_TABLES,
            'tables' => [
                'full_database' => ['count' => 0, 'rows' => 0],
                'alsm_only' => ['count' => 0, 'rows' => 0],
            ],
        ];

        foreach ($tables as $table) {
            $rows = self::dump_one_table($fullfh, $table);
            $summary['tables']['full_database']['count']++;
            $summary['tables']['full_database']['rows'] += $rows;
            self::write_item($backupid, 'full_database_table', $table, $rows, $fulldb, 'done', 'Included in full Moodle + ALSM database SQL.');

            if (self::is_alsm_table($table)) {
                $alsmrows = self::dump_one_table($alsmfh, $table);
                $summary['tables']['alsm_only']['count']++;
                $summary['tables']['alsm_only']['rows'] += $alsmrows;
                self::write_item($backupid, 'alsm_only_table', $table, $alsmrows, $alsmonly, 'done', 'Included in ALSM-only SQL extract.');
            }
        }
        self::write_sql_footer($fullfh);
        self::write_sql_footer($alsmfh);
        fclose($fullfh);
        fclose($alsmfh);
        self::write_item($backupid, 'sql_file', 'full_database_sql', 0, $fulldb, 'done', 'Complete Moodle database SQL including local_aisgk.');
        self::write_item($backupid, 'sql_file', 'alsm_only_sql', 0, $alsmonly, 'done', 'Convenience SQL extract for local_aisgk tables only.');
        return $summary;
    }

    private static function dump_one_table($fh, string $table): int {
        global $DB;
        $fulltable = self::full_table_name($table);
        fwrite($fh, "\n-- --------------------------------------------------------\n");
        fwrite($fh, '-- Table `' . $fulltable . "`\n");
        fwrite($fh, "-- --------------------------------------------------------\n\n");
        fwrite($fh, 'DROP TABLE IF EXISTS `' . $fulltable . "`;\n");
        $create = self::get_create_table_sql($fulltable);
        fwrite($fh, $create ? ($create . ";\n\n") : ('-- WARNING: CREATE TABLE statement could not be read for `' . $fulltable . "`.\n\n"));

        $columns = self::get_table_columns($table);
        if (!$columns) {
            return 0;
        }
        $colsql = implode(', ', array_map(static function($c) {
            return '`' . str_replace('`', '``', $c) . '`';
        }, $columns));

        $rs = $DB->get_recordset_sql('SELECT * FROM ' . self::quoted_full_table_name($fulltable));
        $count = 0;
        foreach ($rs as $row) {
            $values = [];
            foreach ($columns as $column) {
                $values[] = self::sql_value($row->{$column} ?? null);
            }
            fwrite($fh, 'INSERT INTO `' . $fulltable . '` (' . $colsql . ') VALUES (' . implode(', ', $values) . ");\n");
            $count++;
            if (($count % 500) === 0) {
                fflush($fh);
            }
        }
        $rs->close();
        fwrite($fh, "\n");
        return $count;
    }

    private static function get_database_tables(): array {
        global $DB;
        if (method_exists($DB, 'get_tables')) {
            return array_values($DB->get_tables(false));
        }
        $prefix = self::db_prefix();
        $records = $DB->get_records_sql('SHOW TABLES');
        $tables = [];
        foreach ($records as $record) {
            $vars = get_object_vars($record);
            $full = reset($vars);
            if (strpos($full, $prefix) === 0) {
                $tables[] = substr($full, strlen($prefix));
            }
        }
        return $tables;
    }

    private static function table_exists(string $table): bool {
        global $DB;
        return $DB->get_manager()->table_exists($table);
    }

    private static function count_records(string $table): int {
        global $DB;
        try {
            if ($table === 'course') {
                return (int)$DB->count_records_select('course', 'id <> 1');
            }
            return (int)$DB->count_records($table);
        } catch (\Throwable $e) {
            return 0;
        }
    }

    private static function delete_table_records(string $table): void {
        global $DB;
        if ($table === 'course') {
            $DB->delete_records_select('course', 'id <> 1');
            return;
        }
        $DB->delete_records($table);
    }

    private static function get_table_columns(string $table): array {
        global $DB;
        $columns = $DB->get_columns($table);
        return array_keys($columns);
    }

    private static function get_create_table_sql(string $fulltable): string {
        global $DB;
        try {
            $record = $DB->get_record_sql('SHOW CREATE TABLE ' . self::quoted_full_table_name($fulltable));
            if (!$record) {
                return '';
            }
            $vars = get_object_vars($record);
            foreach ($vars as $key => $value) {
                if (stripos($key, 'Create Table') !== false || stripos($key, 'create table') !== false) {
                    return (string)$value;
                }
            }
            return (string)end($vars);
        } catch (\Throwable $e) {
            return '';
        }
    }

    private static function write_sql_header($fh, \stdClass $year, string $scope): void {
        global $CFG;
        fwrite($fh, "-- ALSM school-year closing SQL backup\n");
        fwrite($fh, '-- Scope: ' . $scope . "\n");
        fwrite($fh, '-- School year: ' . $year->name . "\n");
        fwrite($fh, '-- Generated: ' . date('c') . "\n");
        fwrite($fh, '-- Moodle release: ' . ($CFG->release ?? '') . "\n");
        fwrite($fh, "SET NAMES utf8mb4;\n");
        fwrite($fh, "SET FOREIGN_KEY_CHECKS=0;\n");
        fwrite($fh, "SET SQL_MODE='NO_AUTO_VALUE_ON_ZERO';\n");
    }

    private static function write_sql_footer($fh): void {
        fwrite($fh, "\nSET FOREIGN_KEY_CHECKS=1;\n");
        fwrite($fh, "-- End of ALSM SQL backup\n");
    }

    private static function zip_backup_files(string $zipfile, array $files, int $backupid, bool $includemoodledata = false): void {
        global $CFG;
        if (!class_exists('ZipArchive')) {
            throw new \moodle_exception('ziparchivemissing', 'local_aisgk');
        }
        $zip = new \ZipArchive();
        $openresult = $zip->open($zipfile, \ZipArchive::CREATE | \ZipArchive::OVERWRITE);
        if ($openresult !== true) {
            throw new \moodle_exception('cannotwritebackup', 'local_aisgk', '', null, 'Cannot open ZIP for writing. ZipArchive code: ' . $openresult);
        }
        foreach ($files as $file) {
            if (!is_file($file) || !is_readable($file)) {
                self::write_item($backupid, 'archive_input_missing', basename((string)$file), 0, (string)$file, 'failed', 'Required archive input file is missing or unreadable.');
                $zip->close();
                throw new \moodle_exception('cannotwritebackup', 'local_aisgk', '', null, 'Required archive input file is missing: ' . $file);
            }
            if (!$zip->addFile($file, 'database/' . basename($file))) {
                self::write_item($backupid, 'archive_input_add_failed', basename($file), 0, $file, 'failed', 'ZipArchive could not add this SQL/manifest file.');
                $zip->close();
                throw new \moodle_exception('cannotwritebackup', 'local_aisgk', '', null, 'Cannot add file to ZIP: ' . $file);
            }
        }
        if ($includemoodledata) {
            self::add_moodledata_to_zip($zip, (int)$backupid);
        }
        if ($zip->close() !== true) {
            self::write_item($backupid, 'archive', basename($zipfile), 0, $zipfile, 'failed', 'ZipArchive failed while closing/finalizing the archive. Check disk space, file permissions and PHP ZipArchive limits.');
            throw new \moodle_exception('cannotwritebackup', 'local_aisgk', '', null, 'ZipArchive failed while closing/finalizing the archive. Check disk space and permissions.');
        }
        clearstatcache(true, $zipfile);
        if (!is_file($zipfile)) {
            self::write_item($backupid, 'archive', basename($zipfile), 0, $zipfile, 'failed', 'ZIP close returned success but the archive file is missing.');
            throw new \moodle_exception('cannotwritebackup', 'local_aisgk', '', null, 'ZIP file is missing after finalize: ' . $zipfile);
        }
        self::write_item($backupid, 'archive', basename($zipfile), (int)filesize($zipfile), $zipfile, 'done', 'ALSM full school-year archive: database SQL, moodledata/filedir, ALSM runtime files and manifest.');
    }

    private static function add_moodledata_to_zip(\ZipArchive $zip, int $backupid): void {
        global $CFG;
        $root = rtrim($CFG->dataroot, DIRECTORY_SEPARATOR);
        $targets = [
            $root . DIRECTORY_SEPARATOR . 'filedir' => 'moodledata/filedir',
            $root . DIRECTORY_SEPARATOR . 'local_aisgk' => 'moodledata/local_aisgk',
        ];
        foreach ($targets as $path => $zipbase) {
            if (!file_exists($path)) {
                self::write_item($backupid, 'moodledata_missing', $zipbase, 0, '', 'skipped', 'Path does not exist on this Moodle server.');
                continue;
            }
            $count = self::add_path_recursive($zip, $path, $zipbase, $root);
            self::write_item($backupid, 'moodledata_path', $zipbase, $count, '', 'done', 'Included Moodle data path in archive.');
        }
    }

    private static function add_path_recursive(\ZipArchive $zip, string $path, string $zipbase, string $dataroot): int {
        $path = rtrim($path, DIRECTORY_SEPARATOR);
        if (is_file($path)) {
            $zip->addFile($path, $zipbase);
            return 1;
        }
        if (!is_dir($path)) {
            return 0;
        }
        $count = 0;
        $iterator = new \RecursiveIteratorIterator(
            new \RecursiveDirectoryIterator($path, \FilesystemIterator::SKIP_DOTS),
            \RecursiveIteratorIterator::SELF_FIRST
        );
        foreach ($iterator as $item) {
            $real = $item->getPathname();
            if (self::is_excluded_moodledata_path($real, $dataroot)) {
                continue;
            }
            $relative = substr($real, strlen($path) + 1);
            $zipname = $zipbase . '/' . str_replace(DIRECTORY_SEPARATOR, '/', $relative);
            if ($item->isDir()) {
                $zip->addEmptyDir($zipname);
            } else if ($item->isFile() && is_readable($real)) {
                if ($zip->addFile($real, $zipname)) {
                    $count++;
                }
            }
        }
        return $count;
    }

    private static function is_excluded_moodledata_path(string $real, string $dataroot): bool {
        $real = str_replace(DIRECTORY_SEPARATOR, '/', $real);
        $root = str_replace(DIRECTORY_SEPARATOR, '/', rtrim($dataroot, DIRECTORY_SEPARATOR));
        $excluded = ['cache', 'localcache', 'temp', 'sessions', 'trashdir'];
        foreach ($excluded as $dir) {
            if (strpos($real, $root . '/' . $dir . '/') === 0 || $real === $root . '/' . $dir) {
                return true;
            }
        }
        // Prevent recursive backup archives from being packed inside new archives.
        if (strpos($real, $root . '/local_aisgk/backups/') === 0) {
            return true;
        }
        return false;
    }

    public static function create_new_school_year_shell(string $name, string $mode): \stdClass {
        global $DB, $USER;
        $name = trim($name);
        if (!preg_match('/^\d{4}-\d{4}$/', $name)) {
            throw new \moodle_exception('invalidschoolyearname', 'local_aisgk');
        }
        [$startyear, $endyear] = array_map('intval', explode('-', $name));
        if ($endyear !== $startyear + 1) {
            throw new \moodle_exception('invalidschoolyearname', 'local_aisgk');
        }
        if (!in_array($mode, ['inherit', 'wipe'], true)) {
            throw new \moodle_exception('invalidmode', 'local_aisgk');
        }
        if ($DB->record_exists('local_aisgk_school_year', ['name' => $name])) {
            throw new \moodle_exception('schoolyearalreadyexists', 'local_aisgk');
        }
        $now = time();
        $old = $DB->get_record('local_aisgk_school_year', ['isactive' => 1], '*', IGNORE_MULTIPLE);
        $config = [
            'created_from_yearid' => $old ? (int)$old->id : 0,
            'transition_mode' => $mode,
            'transition_stage' => $mode === 'inherit' ? 'awaiting_inheritance_selection' : 'awaiting_protected_wipe_confirmation',
            'deferred_cleanup' => true,
            'note' => 'No old-year data is deleted at this step. Inheritance/pruning happens only in the Ke thua du lieu step.',
        ];
        $record = (object)[
            'name' => $name,
            'startyear' => $startyear,
            'endyear' => $endyear,
            'timestart' => mktime(0, 0, 0, 8, 1, $startyear),
            'timeend' => mktime(23, 59, 59, 7, 31, $endyear),
            'isactive' => 0,
            'status' => $mode === 'inherit' ? 'new_pending_inherit' : 'new_pending_wipe',
            'configjson' => json_encode($config, JSON_UNESCAPED_UNICODE),
            'timecreated' => $now,
            'timemodified' => $now,
            'usermodified' => (int)$USER->id,
        ];
        $record->id = $DB->insert_record('local_aisgk_school_year', $record);
        return $record;
    }

    public static function get_inheritance_groups(): array {
        return [
            'nls_catalog' => 'Danh mục NLS chuẩn',
            'ai_config' => 'Cấu hình AI/provider/model',
            'pl3_template' => 'Template PL3',
            'parent_report_config' => 'Cấu hình báo cáo phụ huynh',
            'shared_documents' => 'Tài liệu ALSM dùng chung',
            'subject_grade_class_config' => 'Cấu hình môn/khối/lớp',
            'teachers' => 'Danh sách giáo viên và phân công mẫu',
            'student_transition' => 'Dữ liệu chuyển lớp học sinh/cohort',
            'course_templates' => 'Cấu trúc course mẫu',
            'sgk_materials' => 'SGK/học liệu chuẩn',
            'sgk_toc' => 'TOC SGK',
            'question_bank_templates' => 'Ngân hàng câu hỏi mẫu',
            'course_resources' => 'Tài nguyên course dùng chung',
            'homework_rules' => 'Quy tắc sinh BTVN',
            'competency_rubrics' => 'Rubric/ma trận năng lực',
            'reward_config' => 'Thiết lập thi đua/quỹ thưởng',
        ];
    }

    private static function write_item(int $backupid, string $type, string $key, int $count, string $path, string $status, string $message): void {
        global $DB;
        if ($backupid <= 0 || !$DB->get_manager()->table_exists('local_aisgk_backup_item')) {
            return;
        }
        $item = (object)[
            'backupid' => $backupid,
            'itemtype' => $type,
            'itemkey' => substr($key, 0, 100),
            'sourcetable' => substr($key, 0, 100),
            'rowcount' => $count,
            'filesize' => ($path && is_readable($path)) ? (filesize($path) ?: 0) : 0,
            'checksum' => ($path && is_readable($path)) ? (sha1_file($path) ?: '') : '',
            'status' => $status,
            'message' => $message,
            'timecreated' => time(),
        ];
        $DB->insert_record('local_aisgk_backup_item', $item);
    }

    private static function is_alsm_table(string $table): bool {
        return strpos($table, self::ALSM_TABLE_PREFIX) === 0;
    }

    private static function is_hard_protected_table(string $table): bool {
        if (in_array($table, self::HARD_PROTECTED_TABLES, true)) {
            return true;
        }
        if (strpos($table, 'local_aisgk_ai_key') === 0 || strpos($table, 'local_aisgk_user_ai_key') === 0) {
            return true;
        }
        return false;
    }

    private static function full_table_name(string $table): string {
        return self::db_prefix() . $table;
    }

    private static function db_prefix(): string {
        global $CFG, $DB;
        if (method_exists($DB, 'get_prefix')) {
            return $DB->get_prefix();
        }
        return $CFG->prefix ?? '';
    }

    private static function quoted_full_table_name(string $fulltable): string {
        return '`' . str_replace('`', '``', $fulltable) . '`';
    }

    private static function sql_value($value): string {
        if ($value === null) {
            return 'NULL';
        }
        if (is_bool($value)) {
            return $value ? '1' : '0';
        }
        if (is_int($value) || is_float($value)) {
            return (string)$value;
        }
        $value = (string)$value;
        return "'" . str_replace(["\\", "\0", "\n", "\r", "\x1a", "'"], ["\\\\", "\\0", "\\n", "\\r", "\\Z", "\\'"], $value) . "'";
    }
}
