<?php
namespace local_aisgk\local;

defined('MOODLE_INTERNAL') || die();

use local_aisgk\ai_key_manager;

class ai_service {

    /**
     * Moodle calculated variables use {a}, {x}, ... and must not be wrapped inside MathJax.
     * AI often returns \({a}\), \(\{a}\), or \{a}. Those forms can make MathJax show
     * "Extra close brace or missing open brace" in preview/import. Keep real LaTeX such as
     * \frac{A}{B}, but move Moodle variables back to plain {a} syntax.
     */
    protected static function normalize_moodle_var_latex_conflicts($value) {
        if (is_array($value)) {
            foreach ($value as $k => $v) {
                $value[$k] = self::normalize_moodle_var_latex_conflicts($v);
            }
            return $value;
        }
        if (!is_string($value) || $value === '') {
            return $value;
        }
        $text = $value;
        // \({a}\), \( {a} \), \(\{a}\) -> {a}
        $text = preg_replace('/\\\\\(\s*\\\\?\{([a-zA-Z][a-zA-Z0-9_]*)\}\s*\\\\\)/u', '{$1}', $text) ?? $text;
        // \[ {a} \] -> {a}; rare, but prevents display-math crashes.
        $text = preg_replace('/\\\\\[\s*\\\\?\{([a-zA-Z][a-zA-Z0-9_]*)\}\s*\\\\\]/u', '{$1}', $text) ?? $text;
        // \{a} or \{a\} -> {a}; only for simple Moodle vars, not \frac{...}.
        $text = preg_replace('/\\\\\{([a-zA-Z][a-zA-Z0-9_]*)\\\\?\}/u', '{$1}', $text) ?? $text;
        // Inside inline math, replace only the simple variable token: \(x = \{a}\) -> \(x = {a}\).
        $text = preg_replace_callback('/\\\\\((.*?)\\\\\)/us', static function($m) {
            $inner = preg_replace('/\\\\\{([a-zA-Z][a-zA-Z0-9_]*)\\\\?\}/u', '{$1}', $m[1]) ?? $m[1];
            return '\\(' . $inner . '\\)';
        }, $text) ?? $text;
        return $text;
    }

    protected static function user_prefers_personal_key(int $userid): bool {
        return $userid > 0 && (bool)get_user_preferences('local_aisgk_use_my_api', 0, $userid);
    }

    public static function extract_toc_from_images(array $images, int $userid = 0): array {
        $prompt = 'Trích xuất dữ liệu từ bảng mục lục trong ảnh. Kết quả chỉ xuất JSON hợp lệ dạng {"rows":[{"sobai":"","tenbai":"","trang":""}]}. Giữ nguyên thứ tự, chỉ lấy dòng mục lục thực sự và số trang.';
        $result = self::call('scan', $userid, self::user_prefers_personal_key($userid), $prompt, $images, true);
        $result['rows'] = self::extract_rows(self::response_text($result['response'], $result['provider']));
        unset($result['response']);
        return $result;
    }

    public static function generate_homework_questions(string $topicname, string $text, array $formula, int $userid = 0, array $options = []): array {
        $maxperbatch = max(10, self::homework_max_per_batch($userid));
        if (self::safe_total($options) > $maxperbatch) {
            return self::generate_homework_questions_chunked($topicname, '', 0, 0, $userid, $options, [], $text);
        }
        $total = self::safe_total($options);
        $prompt = self::build_homework_prompt($topicname, '', 0, 0, $total, $options)
        . "\n\nNội dung bài học dạng văn bản:\n" . mb_substr($text, 0, 18000);
        $result = self::call('homework', $userid, self::user_prefers_personal_key($userid), $prompt, [], true);
        $raw = self::response_text($result['response'], $result['provider']);
        $result['rawtext'] = $raw;
        try {
            $result['questions'] = self::extract_questions($raw, $total, $options);
            $result['parseerror'] = '';
        } catch (\Throwable $e) {
            $result['questions'] = [];
            $result['parseerror'] = $e->getMessage();
        }
        $result = self::postprocess_generated_homework($result, $topicname, '', 0, 0, $userid, $options, [], $text);
        $result['normalizedjson'] = self::questions_json($result['questions']);
        unset($result['response']);
        return $result;
    }

    public static function generate_homework_questions_from_images(
        string $topicname,
        array $images,
        int $pagefrom,
        int $pageto,
        int $userid = 0,
        array $options = [],
        string $bookname = ''
    ): array {
        $maxperbatch = max(10, self::homework_max_per_batch($userid));
        if (self::safe_total($options) > $maxperbatch) {
            return self::generate_homework_questions_chunked($topicname, $bookname, $pagefrom, $pageto, $userid, $options, $images, '');
        }
        $total = self::safe_total($options);
        $prompt = self::build_homework_prompt($topicname, $bookname, $pagefrom, $pageto, $total, $options);
        $result = self::call('homework', $userid, self::user_prefers_personal_key($userid), $prompt, $images, true);
        $raw = self::response_text($result['response'], $result['provider']);
        $result['rawtext'] = $raw;
        try {
            $result['questions'] = self::extract_questions($raw, $total, $options);
            $result['parseerror'] = '';
        } catch (\Throwable $e) {
            $result['questions'] = [];
            $result['parseerror'] = $e->getMessage();
        }
        $result = self::postprocess_generated_homework($result, $topicname, $bookname, $pagefrom, $pageto, $userid, $options, $images, '');
        $result['normalizedjson'] = self::questions_json($result['questions']);
        unset($result['response']);
        return $result;
    }

    protected static function generate_homework_questions_chunked(string $topicname, string $bookname, int $pagefrom, int $pageto, int $userid, array $options, array $images = [], string $text = ''): array {
        $batchprofile = self::homework_batch_profile($userid);
        $maxperbatch = max(10, (int)($batchprofile['max'] ?? 10));
        $totalquestions = self::safe_total($options);
        $batches = self::split_homework_options_batches($options, $maxperbatch);
        if ($totalquestions <= $maxperbatch) {
            $single = $options;
            $single['total'] = $totalquestions;
            $batches = [$single];
        }
        $all = [];
        $rawparts = [];
        $parseerrors = [];
        $tokens = 0;
        $models = [];
        $provider = '';
        $category = '';
        $usage = [];
        $keysource = '';
        foreach ($batches as $bi => $batchopts) {
            $batchtotal = self::safe_total($batchopts);
            $prompt = self::build_homework_prompt($topicname, $bookname, $pagefrom, $pageto, $batchtotal, $batchopts);
            if ($text !== '') {
                $prompt .= "\n\nNội dung bài học dạng văn bản:\n" . mb_substr($text, 0, 18000);
            }
            $res = self::call('homework', $userid, self::user_prefers_personal_key($userid), $prompt, $images, true);
            $raw = self::response_text($res['response'], $res['provider']);
            $rawparts[] = "/* batch " . ($bi + 1) . "/" . count($batches) . " */\n" . $raw;
            $tokens += (int)($res['tokens'] ?? 0);
            $provider = $provider ?: (string)($res['provider'] ?? '');
            $category = $category ?: (string)($res['category'] ?? '');
            $usage = $res['usage'] ?? $usage;
            $keysource = $keysource ?: (string)($res['keysource'] ?? '');
            if (!empty($res['model'])) { $models[] = (string)$res['model']; }
            try {
                $qs = self::extract_questions($raw, $batchtotal, $batchopts);
                foreach ($qs as $q) { $all[] = $q; }
            } catch (\Throwable $e) {
                $parseerrors[] = 'Batch ' . ($bi + 1) . ': ' . $e->getMessage();
            }
        }
        foreach ($all as $i => &$q) { if (!isset($q['question_no'])) { $q['question_no'] = $i + 1; } unset($q['name'], $q['qtype']); }
        unset($q);
        $result = [
            'provider' => $provider,
            'model' => implode(', ', array_values(array_unique($models))),
            'tokens' => $tokens,
            'usage' => $usage,
            'keysource' => $keysource,
            'category' => $category,
            'rawtext' => implode("\n\n", $rawparts),
            'questions' => self::normalize_homework_questions($all, $options, self::safe_total($options)),
            'parseerror' => implode(' | ', $parseerrors),
            'chunked' => true,
            'chunks' => count($batches),
            'batch_profile' => $batchprofile,
        ];
        $result = self::postprocess_generated_homework($result, $topicname, $bookname, $pagefrom, $pageto, $userid, $options, $images, $text);
        $result['normalizedjson'] = self::questions_json($result['questions']);
        return $result;
    }

    protected static function has_heavy_img_qtypes(array $options): bool {
        $qtypes = self::active_qtype_counts($options);
        return !empty($qtypes['ddimageortext']) || !empty($qtypes['ddmarker']);
    }
    protected static function homework_batch_profile(int $userid): array {
        // Decide batch size by peeking the key currently selected for homework.
        // free: 10, pay: 15, preview models: at most 10.
        $preferuser = self::user_prefers_personal_key($userid);
        $category = 'free';
        $model = '';
        try {
            $key = ai_key_manager::get_available_key('homework', [], $userid, $preferuser, 0);
            if ($key) {
                $category = strtolower((string)($key->category_key ?? 'free')) === 'pay' ? 'pay' : 'free';
                $models = ai_key_manager::model_attempts_for_key($key, 'homework');
                $model = (string)($models[0] ?? (($key->model_homework ?? '') ?: ''));
                // We only peeked the key to decide batch size; release it immediately.
                ai_key_manager::release_key($key);
            }
        } catch (\Throwable $e) {
            $category = 'free';
            $model = '';
        }
        $max = ($category === 'pay') ? 15 : 10;
        if (stripos($model, 'preview') !== false) {
            $max = min($max, 10);
        }
        return ['category' => $category, 'model' => $model, 'max' => $max];
    }

    protected static function homework_max_per_batch(int $userid): int {
        $profile = self::homework_batch_profile($userid);
        return (int)($profile['max'] ?? 10);
    }

    protected static function split_even_slices(array $items, int $maxpercall): array {
        $total = count($items);
        if ($total === 0) { return [[]]; }
        $maxpercall = max(1, $maxpercall);
        $numbatches = (int)ceil($total / $maxpercall);
        $base = intdiv($total, $numbatches);
        $remainder = $total % $numbatches;
        $out = [];
        $pos = 0;
        for ($i = 0; $i < $numbatches; $i++) {
            $size = $base + ($i < $remainder ? 1 : 0);
            $out[] = array_slice($items, $pos, $size);
            $pos += $size;
        }
        return $out;
    }

    protected static function split_homework_options_batches(array $options, int $maxpercall = 10): array {
        $total = self::safe_total($options);
        $maxpercall = max(1, (int)$maxpercall);
        if ($total <= $maxpercall) { $options['total'] = $total; return [$options]; }

        $qtypes = self::active_qtype_counts($options);
        $levels = self::active_level_counts($options);

        $typeitems = [];
        foreach ($qtypes as $type => $count) {
            for ($i = 0; $i < (int)$count; $i++) { $typeitems[] = (string)$type; }
        }
    $levelitems = [];
    foreach ($levels as $level => $count) {
        for ($i = 0; $i < (int)$count; $i++) { $levelitems[] = (string)$level; }
    }

$typebatches = self::split_even_slices($typeitems, $maxpercall);
$levelbatches = self::split_even_slices($levelitems, $maxpercall);
$out = [];
$numbatches = max(count($typebatches), count($levelbatches));

for ($bi = 0; $bi < $numbatches; $bi++) {
    $tb = $typebatches[$bi] ?? [];
    $lbitems = $levelbatches[$bi] ?? [];
    $qb = [];
    foreach ($tb as $t) { $qb[$t] = ($qb[$t] ?? 0) + 1; }
    $lb = [];
    foreach ($lbitems as $lv) { $lb[$lv] = ($lb[$lv] ?? 0) + 1; }
    $size = count($tb);
    if ($size <= 0) { continue; }
    if (!$lb) { $lb[self::first_allowed_key($levels)] = $size; }
    $bo = $options;
    $bo['qtypes'] = $qb;
    $bo['cognitive'] = $lb;
    $bo['total'] = $size;
    $out[] = $bo;
}
return $out ?: [$options];
}

protected static function postprocess_generated_homework(array $result, string $topicname, string $bookname, int $pagefrom, int $pageto, int $userid, array $options, array $images = [], string $text = ''): array {
    $questions = is_array($result['questions'] ?? null) ? array_values($result['questions']) : [];
    if (!$questions) { return $result; }
    $report = self::validate_homework_against_plan($questions, $options);
    $result['initial_report'] = $report;
    self::record_model_question_score((string)($result['model'] ?? ''), 'homework_create', $questions, $report, $options);
    if (!empty($report['ok'])) { return $result; }

        // DEBUG MODE 2026-05-02:
        // Tạm thời tắt hoàn toàn bước gửi AI sửa lỗi / auto-repair.
        // Khi validate chưa đạt vẫn giữ nguyên questions/rawtext ban đầu để lưu vào draft,
        // giúp debug prompt/schema/validator theo đúng kết quả AI trả về.
    if (!empty($options['_jobid'])) {
        job_manager::update_progress((int)$options['_jobid'], 4, 'validate', 'Validate JSON', 70, 'Validate chưa đạt, bỏ qua AI sửa lỗi và lưu raw để debug.');
    }
    $result['autorepair'] = [
        'attempted' => false,
        'disabled' => true,
        'reason' => 'AUTO_FIX_DISABLED_DEBUG_RAW',
    ];
    return $result;
}

protected static function repair_candidate_indexes(array $questions, array $report, array $options): array {
    $idx = [];
    foreach (($report['errors'] ?? []) as $err) {
        if (preg_match('/Câu\s+(\d+)/u', (string)$err, $m)) {
            $n = (int)$m[1] - 1;
            if ($n >= 0 && $n < count($questions)) { $idx[$n] = true; }
        }
    }
    $allowedtypes = self::active_qtype_counts($options);
    $allowedlevels = self::active_level_counts($options);
    $counts = self::quota_counts($questions);
    $missingtypes = [];
    foreach ($allowedtypes as $t => $need) {
        $miss = (int)$need - (int)($counts['types'][$t] ?? 0);
        for ($i=0; $i<$miss; $i++) { $missingtypes[] = $t; }
    }
$missinglevels = [];
foreach ($allowedlevels as $lv => $need) {
    $miss = (int)$need - (int)($counts['levels'][$lv] ?? 0);
    for ($i=0; $i<$miss; $i++) { $missinglevels[] = $lv; }
}
foreach ($missingtypes as $mt) {
    $surplus = self::find_surplus_question_index($questions, $allowedtypes, $allowedlevels);
    if ($surplus !== null) { $idx[$surplus] = true; }
}
foreach ($missinglevels as $ml) {
    $surplus = self::find_surplus_question_index($questions, $allowedtypes, $allowedlevels);
    if ($surplus !== null) { $idx[$surplus] = true; }
}
return array_values(array_map('intval', array_keys($idx)));
}

protected static function repair_questions_with_ai(array $questions, array $indexes, array $report, string $topicname, string $bookname, int $pagefrom, int $pageto, int $userid, array $options, array $images = [], string $text = ''): array {
    $items = [];
    foreach ($indexes as $idx) {
        if (isset($questions[$idx])) {
            $q = $questions[$idx];
            $q['question_no'] = $idx + 1;
            $items[] = $q;
        }
    }
    if (!$items) { return ['ok' => false, 'reason' => 'Không có câu cần sửa.']; }
    $payload = [
        'topic' => $topicname,
        'options' => $options,
        'errors' => $report['errors'] ?? [],
        'summary' => $report['summary'] ?? [],
        'questions_to_fix' => $items,
    ];
    $prompt = "Bạn sửa các câu hỏi Moodle JSON bị lỗi. Chỉ sửa các câu trong questions_to_fix; giữ question_no để hệ thống ghép lại.\n"
    . "Nếu thiếu type nào, hãy đổi câu thuộc type dư sang type đang thiếu. Nếu thiếu level nào, hãy đổi câu thuộc level dư sang level đang thiếu.\n"
    . "Nếu đủ type và level thì chỉ sửa lỗi cấu trúc của các câu lỗi.\n"
    . "Với gapselect/ddwtos dùng <<1>>, <<2>> trong questiontext; mỗi <<n>> phải có choices group n.\n"
    . "Nếu câu 1 chỗ trống/cặp đơn giản, thêm 1-2 nhiễu trong da_nhieu, không chèn nhiễu vào đáp án chính.\n"
    . "Chỉ trả JSON hợp lệ dạng {\"questions\":[...]} đúng số câu được gửi, không markdown.\n\n"
    . json_encode($payload, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
    if ($text !== '') { $prompt .= "\n\nNgữ liệu bài học:\n" . mb_substr($text, 0, 8000); }
    $res = self::call('homework', $userid, self::user_prefers_personal_key($userid), $prompt, $images, true);
    $raw = self::response_text($res['response'], $res['provider']);
    try {
        $fixed = self::extract_questions($raw, count($items), $options);
        return ['ok' => true, 'questions' => $fixed, 'rawtext' => $raw, 'model' => (string)($res['model'] ?? ''), 'tokens' => (int)($res['tokens'] ?? 0)];
    } catch (\Throwable $e) {
        return ['ok' => false, 'rawtext' => $raw, 'model' => (string)($res['model'] ?? ''), 'tokens' => (int)($res['tokens'] ?? 0), 'error' => $e->getMessage()];
    }
}

public static function fix_homework_errors_with_ai(array $questions, array $report, array $options, int $userid = 0, string $topicname = '', string $bookname = '', int $pagefrom = 0, int $pageto = 0, array $images = [], string $text = ''): array {
    $normalized = self::normalize_homework_questions(array_values($questions), $options);
    $currentreport = $report;
    if (empty($currentreport) || !is_array($currentreport) || !isset($currentreport['errors'])) {
        $currentreport = self::validate_homework_against_plan($normalized, $options);
    }
    if (!empty($currentreport['ok'])) {
        return [
            'ok' => true,
            'questions' => $normalized,
            'report' => $currentreport,
            'rawtext' => '',
            'model' => '',
            'tokens' => 0,
            'message' => 'JSON đã đạt, không cần sửa lỗi.',
        ];
    }
    $indexes = self::repair_candidate_indexes($normalized, $currentreport, $options);
    if (!$indexes) {
        $indexes = array_keys($normalized);
    }
    $fixed = self::repair_questions_with_ai($normalized, $indexes, $currentreport, $topicname, $bookname, $pagefrom, $pageto, $userid, $options, $images, $text);
    if (empty($fixed['ok'])) {
        $fixed['questions'] = $normalized;
        $fixed['report'] = $currentreport;
        return $fixed;
    }
    $replacement = [];
    foreach (array_values((array)($fixed['questions'] ?? [])) as $q) {
        if (!is_array($q)) { continue; }
        $no = (int)($q['question_no'] ?? 0);
        if ($no > 0) { $replacement[$no - 1] = $q; }
    }
    $cursor = 0;
    foreach ($indexes as $idx) {
        if (isset($replacement[$idx])) {
            $normalized[$idx] = $replacement[$idx];
            continue;
        }
        if (isset($fixed['questions'][$cursor]) && is_array($fixed['questions'][$cursor])) {
            $normalized[$idx] = $fixed['questions'][$cursor];
        }
        $cursor++;
    }
    foreach ($normalized as $i => $q) {
        if (!is_array($q)) { $q = []; }
        $q['question_no'] = $i + 1;
        unset($q['name'], $q['qtype']);
        $normalized[$i] = $q;
    }
    $normalized = self::normalize_homework_questions($normalized, $options);
    $newreport = self::validate_homework_against_plan($normalized, $options);
    return [
        'ok' => true,
        'questions' => $normalized,
        'report' => $newreport,
        'rawtext' => (string)($fixed['rawtext'] ?? ''),
        'model' => (string)($fixed['model'] ?? ''),
        'tokens' => (int)($fixed['tokens'] ?? 0),
        'message' => !empty($newreport['ok']) ? 'Đã sửa lỗi và validate đạt.' : 'AI đã sửa một phần, nhưng JSON vẫn chưa đạt validate.',
    ];
}

protected static function level_weight_for_score(string $level): int {
    $level = self::normalize_level($level);
    if ($level === 'van_dung') { return 3; }
    if ($level === 'thong_hieu') { return 2; }
    return 1;
}

protected static function record_model_question_score(string $model, string $phase, array $questions, array $report, array $options): void {
    $model = trim($model);
    if ($model === '' || !$questions) { return; }
    $bad = [];
    foreach (($report['errors'] ?? []) as $err) {
        if (preg_match('/Câu\s+(\d+)/u', (string)$err, $m)) { $bad[(int)$m[1] - 1] = true; }
    }
    $earned = 0; $possible = 0;
    foreach (array_values($questions) as $i => $q) {
        $w = self::level_weight_for_score((string)($q['level'] ?? ''));
        $possible += $w;
        if (empty($bad[$i]) && self::is_valid_by_type(self::normalize_question_shape($q))) { $earned += $w; }
    }
    if ($possible > 0) { ai_key_manager::record_model_score($model, 'homework', $phase, $earned, $possible); }
}
protected static function safe_total(array $options): int {
    $total = (int)($options['total'] ?? 0);
    if ($total <= 0 && !empty($options['qtypes']) && is_array($options['qtypes'])) {
        $total = array_sum(array_map('intval', $options['qtypes']));
    }
    if ($total <= 0 && !empty($options['cognitive']) && is_array($options['cognitive'])) {
        $total = array_sum(array_map('intval', $options['cognitive']));
    }
    return max(1, min(60, $total ?: 8));
}

protected static function sent_image_context_text(array $options): string {
    $meta = $options['_sent_image_meta'] ?? [];
    if (empty($meta) || !is_array($meta)) { return ''; }
    return "Ảnh SGK đính kèm là ảnh nguyên trang màu đã được backend xử lý theo mức resize giáo viên chọn; width=0 nghĩa là giữ nguyên kích thước. KHÔNG crop lề trước khi gửi AI. Với SGK, source_box phải tính theo đúng ảnh nguyên trang đang được cung cấp trong input này, dùng hệ 0-1000 và thứ tự thống nhất [xmin,ymin,xmax,ymax]; backend sẽ tự scale/cắt ảnh thật. Khi dùng hình/bảng/sơ đồ trong SGK, chỉ trả images tối giản gồm label, source=\"sgk\", page, source_box.\n\n";
}


public static function teacher_config_from_options(array $options): array {
    $qtypes = [];
    if (!empty($options['qtypes']) && is_array($options['qtypes'])) {
        foreach ($options['qtypes'] as $type => $count) {
            $ntype = self::normalize_qtype((string)$type);
            $n = (int)$count;
            if ($ntype !== '' && $n > 0) { $qtypes[$ntype] = $n; }
        }
    }
    $levels = [];
    if (!empty($options['cognitive']) && is_array($options['cognitive'])) {
        foreach ($options['cognitive'] as $level => $count) {
            $nlevel = self::normalize_level((string)$level);
            $n = (int)$count;
            if ($nlevel !== '' && $n > 0) { $levels[$nlevel] = $n; }
        }
    }
    $distractors = [];
    $allowed = ['multichoice','matching','gapselect','ddwtos','ddimageortext','ddmarker'];
    if (!empty($options['distractors']) && is_array($options['distractors'])) {
        foreach ($allowed as $type) { $distractors[$type] = !empty($options['distractors'][$type]) ? 1 : 0; }
    } else {
        foreach ($allowed as $type) { $distractors[$type] = 0; }
    }
    return [
        'total' => array_sum($qtypes) ?: self::safe_total($options),
        'qtypes' => $qtypes,
        'cognitive' => $levels,
        'distractors' => $distractors,
    ];
}

public static function build_homework_prompt(string $topicname, string $bookname, int $pagefrom, int $pageto, int $total, array $options): string {
    $source = $bookname !== '' ? "- Sách/SGK: {$bookname}\n" : '';
    $pages = ($pagefrom > 0 && $pageto >= $pagefrom) ? "- Trang: {$pagefrom} → {$pageto}\n" : '';
    $teacherconfig = self::teacher_config_from_options($options);
    $configjson = json_encode($teacherconfig, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
    $imagecontext = self::sent_image_context_text($options);
    $schema = self::active_schema_text($options);
    $allowedtypes = implode(', ', array_keys(self::active_qtype_counts($options)));
    $allowedlevels = implode(', ', array_keys(self::active_level_counts($options)));

    return "Bạn là giáo viên THCS tại Việt Nam am hiểu chương trình GDPT 2018.\n\n"
    . "Nhiệm vụ: tạo bài tập về nhà từ nội dung SGK trong ảnh/nội dung được cung cấp.\n\n"
    . "Nguồn:\n{$source}"
    . "- Tên bài/chủ đề: {$topicname}\n"
    . $pages
    . $imagecontext
    . "TEACHER_CONFIG BẮT BUỘC:\n"
    . "- JSON trả về BẮT BUỘC có TEACHER_CONFIG đúng y nguyên cấu hình cố định dưới đây, không tự sửa số lượng/type/level/nhiễu.\n"
    . "- TEACHER_CONFIG dùng để đối chiếu với QUESTION_PLAN và questions.\n"
    . "TEACHER_CONFIG={$configjson}\n\n"
    . "QUESTION_PLAN BẮT BUỘC:\n"
    . "- JSON trả về phải có QUESTION_PLAN: từng câu, từng type, từng level.\n"
    . "- QUESTION_PLAN phải khớp 100% TEACHER_CONFIG.qtypes và TEACHER_CONFIG.cognitive; questions[i] đi đúng plan[i].\n\n"
    . "- Số câu cần tạo chính xác: {$total}\n\n"
    . "CĂN CỨ NỘI DUNG (BẮT BUỘC):\n"
    . "- Phải tìm và bám sát phần mục tiêu bài học. Phần này thường có tiêu đề: 'Yêu cầu cần đạt', 'Sau bài học này em sẽ...', 'Mục tiêu', hoặc 'Kiến thức và kĩ năng'. Nếu không có tiêu đề rõ ràng, hãy mặc định đó là phần văn bản có tính chất liệt kê (dấu đầu dòng) nằm ngay sau tên bài học: {$topicname}.\n"
    . "- Sử dụng hệ thống bài tập/câu hỏi cuối bài làm mẫu về cấu trúc và độ khó. Câu hỏi AI tạo ra phải có độ khó tương đương hoặc phát triển trực tiếp từ các dạng bài tập này.\n"
    . "- Đây là căn cứ bắt buộc để xác định phạm vi kiến thức; không tạo câu hỏi nằm ngoài các năng lực đã nêu trong 2 phần này.\n"
    . "- Bỏ qua header, footer, số trang, mục lục, watermark và rác quét.\n"
    . "- Level chỉ được viết nhan_biet / thong_hieu / van_dung. CẤM recognize / understand / apply trong JSON trả về.\n"
    . "- RÀNG BUỘC TỐI GIẢN PHƯƠNG ÁN (QUAN TRỌNG):\n"
    . "- Tránh trùng lặp gây mơ hồ. Với matching/gapselect/ddwtos, đáp án đúng được phép trùng khi nhiều vế/chỗ trống/choice.text thật sự có cùng đáp án; backend sẽ xử lý khi đưa vào Moodle.\n"
    . "- Với multichoice/calculatedmulti, các phương án answers không được trùng nội dung.\n"
    . "- Mỗi phần tử trong da_nhieu phải là đáp án gần đúng hoặc sai hoặc dễ hiểu nhầm và không trùng với các đáp án khác trong cùng câu.\n"
    . "- Ngôn ngữ câu hỏi phải phù hợp với ngôn ngữ nội dung bài học trong SGK.\n\n"
    . "RÀNG BUỘC BẮT BUỘC THEO CẤU HÌNH:\n"
    . "- CHỈ được dùng các type sau: {$allowedtypes}.\n"
    . "- CHỈ được dùng các level sau: {$allowedlevels}.\n"
    . "- Chỉ tạo câu hỏi theo đúng qtypes và levels được cung cấp trong options.\n"
    . "- Số câu theo từng type phải đúng với số lượng trong options.qtypes. Type nào = 1 thì chỉ tạo đúng 1 câu type đó.\n"
    . "- Số câu theo từng level phải đúng với số lượng trong options.cognitive.\n"
    . "- name chỉ dùng dạng 'Câu 1', 'Câu 2'... Không thêm tên bài vào name.\n"
    . "- Nếu nội dung SGK không đủ thông tin cho một type được chọn, vẫn chỉ được dùng các type trong danh sách được phép; không tự ý đổi sang type khác.\n\n"
    . "HÌNH ẢNH / BẢNG / SƠ ĐỒ / CÂU HỎI IMG:\n"
    . "- KHÔNG trả base64, data:image hoặc binary/image content trong JSON.\n"
    . "- Nếu Hình/Bảng/Sơ đồ/Câu hỏi cần IMG mà ảnh không có trong SGK thì có thể lấy từ Internet nhưng phải đảm bảo:\n"
    . "+ 1. Mọi trường source nếu là URL phải là link công khai (Public URL, Direct Link). 4 kí tự cuối của link phải là .png/.jpg/jpeg."
    . "+ 2. Tuyệt đối không bịa URL (No hallucinated URLs)." 
    . "+ 3. Nếu ảnh từ Internet, hãy đảm bảo link đó có thuộc tính Header Content-Type: image/... khi truy cập."
    . "+ 4. Phải dùng máy tìm kiếm để tìm ảnh mới phù hợp với câu hỏi đang tạo, tuyệt đối không dùng ảnh trong mô hình huấn luyện.\n"
    . "- Trong questiontext/choices/answers/items chỉ dùng marker ngắn: [IMG h1], [IMG h2], [IMG bg1]... Không nhúng metadata dài trong text.\n"
    . "- Trước khi ước tính source_box, tọa độ đối tượng, hãy tự xác định vùng hình/bảng/sơ đồ trên ảnh đang được cung cấp. KHÔNG cần viết mô tả vị trí vào questiontext và KHÔNG cần trả field location.\n"
    . "- Mọi tọa độ trả về theo hệ lưới chuẩn hóa 0-1000 của chính ảnh AI đang nhìn thấy; [0,0,1000,1000] là toàn bộ ảnh; luôn trả số nguyên, không trả pixel thật."
    . "- Hệ 0–1000 là hệ tọa độ chuẩn hóa riêng từng trục, không phải resize ảnh thành 1000×1000. Không được làm méo ảnh. Với ảnh W×H: x_norm = x_px / W * 1000, y_norm = y_px / H * 1000.\n"
    . "- Thứ tự source_box BẮT BUỘC dùng chuẩn thống nhất: [xmin,ymin,xmax,ymax] (x là chiều ngang trái-phải, y là chiều dọc trên-dưới). KHÔNG dùng pixel thật, KHÔNG dùng [ymin,xmin,ymax,xmax].\n"
    . "- Với hình/bảng/sơ đồ: chỉ lấy phần HÌNH VẼ chính (đường, cạnh, hình học).\n"
    . "- KHÔNG lấy chữ mô tả, tiêu đề, tên hình như 'Hình thang', 'bình hành', 'Hình 1.3' vào source_box.\n"
    . "- KHÔNG lấy văn bản xung quanh source_box.\n"
    . "- Nếu vùng có cả hình và chữ, chỉ giữ phần có đường nét/hình học, bỏ chữ.\n"
    . "- Box phải ôm sát phần hình vẽ chính, không dư bên trái; chỉ nới rất nhẹ nếu cần tránh cắt mất nét hình.\n"
    . "- Schema images chỉ dùng tối thiểu:\n"
    . "  SGK: images:{\"h1\":{\"label\":\"Hình 1.4\",\"source\":\"sgk\",\"page\":12,\"source_box\":[xmin,ymin,xmax,ymax]}}\n"
    . "  Ảnh ngoài: images:{\"h1\":{\"label\":\"ảnh\",\"source\":\"https://.../image.jpg\",\"source_box\":[xmin,ymin,xmax,ymax]}}\n"
    . "- Mỗi câu chỉ dùng question_no, type, level, questiontext và field cần cho type đó; KHÔNG trả name, KHÔNG trả qtype vì backend tự gắn.\n"
    . "- label ưu tiên tên hình đọc được như 'Hình 1.4'; nếu không có thì mô tả rất ngắn; nếu không rõ dùng 'ảnh'.\n"
    . "- Không tự bịa URL, không dùng URL placeholder/example.com. Nếu không chắc ảnh/URL/tọa độ thật thì không tạo câu phụ thuộc hình; diễn đạt lại bằng chữ.\n"
    . "- ddimageortext/ddmarker: vẫn dùng images tối giản cho ảnh nền, items[].drop_zone cho vị trí đáp án đúng; nhiễu để trong da_nhieu hoặc items có drop_zone=null.\n- Mọi drop_zone/coords cũng dùng hệ 0-1000 tương đối trên ảnh nền đã crop bởi source_box; left/top/width/height đều là số nguyên 0-1000, không dùng pixel tuyệt đối.\n- Các drop_zone/coords trong cùng một câu ddimageortext KHÔNG được chồng lấn nhau; nếu nhiều nhãn gần nhau phải tách vùng nhỏ hơn hoặc đặt lệch nhau rõ ràng.\n- KHÔNG tạo ddimageortext/ddmarker nếu đáp án đúng đã hiện sẵn bằng chữ trong ảnh nền. Không dùng vùng ảnh mà bản thân ảnh đã chứa chính xác nội dung item/label cần kéo/thả hoặc marker cần đánh dấu. Không tạo kiểu “kéo nhãn đúng vào vị trí đã có sẵn cùng nhãn”. Nếu học sinh có thể làm đúng chỉ bằng cách nhìn chữ có sẵn trên ảnh mà không cần kiến thức bài học => câu hỏi không hợp lệ.\n- Nếu ảnh SGK không phù hợp, ảnh đã có sẵn đáp án/nhãn/chữ đúng, hoặc không có vùng trống rõ ràng: dùng: “source“:“box“,source_box:[0,0,1000,1000]. Tạo 2–4 vùng phân loại rõ ràng. Tạo câu hỏi dạng phân loại/nhóm kiến thức. Mỗi item/label chỉ có đúng một vị trí đúng. Không dùng item/label đã xuất hiện sẵn trên nền."
    . "NHIỄU / DISTRACTOR THEO CẤU HÌNH:\n"
    . "- Nếu options.distractors[type]=true thì phải sinh nhiễu cho câu hỏi dạng type đó. tối đa 2 phương án nhiễu cho mỗi câu.\n"
    . "- Chỉ multichoice,matching,gapselect,ddwtos,ddimageortext, ddmarker mới được phép có nhiễu"
    . "- Với ddwtos/gapselect/matching: cấu trúc chính CHỈ chứa đáp án/cặp đúng; mọi nhiễu đặt riêng trong da_nhieu. KHÔNG tự chèn nhiễu vào choices/subquestions.\n"
    . "- Nếu gapselect/ddwtos: Không dùng choice quá dài (>8 từ). Nếu chỉ có 1 chỗ trống hoặc matching quá dễ, thêm 1-2 nhiễu trong da_nhieu; tối đa 2 nhiễu/câu.\n"
    . "- multichoice/calculatedmulti: đáp án sai nằm trong answers như chuẩn Moodle; da_nhieu chỉ dùng khi cần ghi nhiễu phụ.\n"
    . "- Mỗi phần tử trong da_nhieu phải là đáp án SAI, không trùng và không tương đương với bất kỳ đáp án đúng/sai/choice/subquestion nào khác trong cùng câu; các phần tử da_nhieu cũng không được trùng nhau hoặc chỉ khác khoảng trắng/ký tự hình thức.\n"
    . "- Nhiễu nên có lý, gần đúng và dễ nhầm; không dùng nhiễu vô nghĩa.\n\n"
    . "CÔNG THỨC / KÝ HIỆU TOÁN, LÝ, HÓA:\n"
    . "- Nếu có công thức hoặc ký hiệu cần render, phải viết bằng LaTeX inline dạng \\( ... \\) hoặc block dạng \\[ ... \\].\n"
    . "- Vì đây là JSON, mọi dấu gạch chéo ngược trong công thức phải escape thành \\\\. Ví dụ viết \"\\\\(S = a \\\\times b\\\\)\" chứ không viết \"\\(S = a \\times b\\)\".\n"
    . "- Không dùng công thức dạng ảnh, không dùng HTML math tự chế, không dùng ký tự lạ làm hỏng JSON.\n"
    . "- Biến Moodle dạng {a}, {x}, {d}, {v} KHÔNG được đặt bên trong LaTeX. ĐÚNG: {x} km/h, x = {a}. SAI: \({x}\), \(x = \{a}\).\n"
    . "RÀNG BUỘC JSON TRẢ VỀ:\n"
    . "- Chỉ trả JSON hợp lệ, không markdown, không giải thích, không thêm text ngoài JSON.\n"
    . "- Tổng số phần tử trong questions phải đúng bằng {$total}. Nếu không thể đảm bảo JSON hợp lệ thì trả đúng: {\"questions\":[]}.\n"
    . "- Tự kiểm tra lại source_box, tọa độ, url, da_nhieu xem đúng yêu cầu chưa.\n\n"
    . "- Cấu trúc chung bắt buộc:\n"
    . "{\"TEACHER_CONFIG\":{$configjson},\"QUESTION_PLAN\":[{\"question_no\":1,\"type\":\"<theo TEACHER_CONFIG.qtypes>\",\"level\":\"nhan_biet|thong_hieu|van_dung\"}],\"questions\":[{\"question_no\":1,\"type\":\"<theo QUESTION_PLAN>\",\"level\":\"<theo QUESTION_PLAN>\",\"questiontext\":\"...\"}]}\n\n"
    . "DANH SÁCH TYPE ĐƯỢC PHÉP VÀ SCHEMA TƯƠNG ỨNG, CHỈ DÙNG CÁC TYPE DƯỚI ĐÂY:\n"
    . $schema
    . "\n BẮT BUỘC TUYỆT ĐỐI PHẢI TUÂN THỦ: Trước khi trả JSON phải liệt kê những vi phạm mà AI dễ mắc, đã mắc, chú ý đến source, source_box, drop_zone, coords. Đưa ra kế hoạch sửa và thực hiện theo kế hoạch. sau đó mới trả JSON.";
}

protected static function active_schema_text(array $options): string {
    $schemas = [
        'multichoice' => '- multichoice: có answers, mỗi phần tử {"text":"...","fraction":...}. Có thể có 1 hoặc nhiều đáp án đúng. Tổng fraction của tất cả đáp án đúng phải bằng 100. Đáp án sai dùng fraction=0. Nên có ít nhất 3 đáp án.',
        'truefalse' => '- truefalse: có answers gồm Đúng và Sai; một đáp án fraction 100, đáp án còn lại 0.',
        'shortanswer' => '- shortanswer: có answers [{"text":"đáp án ngắn","fraction":100}].',
        'numerical' => '- numerical: có answers [{"text":"giá trị số","fraction":100,"tolerance":0}].',
        'matching' => '- matching: BẮT BUỘC type="matching"; phải có subquestions [{"question":"vế trái","answer":"vế phải"}], tối thiểu 2 cặp. Mỗi subquestion phải có answer, KHÔNG để answer rỗng, KHÔNG tách đáp án ra mảng answers riêng. Answer được phép trùng nếu nhiều vế trái có cùng đáp án đúng. Có thể dùng aliases pairs/items/matches nhưng sẽ được normalize về subquestions.',
        'essay' => '- essay: chỉ cần questiontext; có thể thêm responseformat nếu biết.',
        'gapselect' => '- gapselect: questiontext phải có chỗ trống dạng [[1]], [[2]] và có choices [{"group":1,"text":"..."}]. Mỗi placeholder [[n]] bắt buộc có đúng một choice group=n; không được dùng trùng group cho nhiều chỗ trống',
        'ddwtos' => '- ddwtos: BẮT BUỘC type="ddwtos"; questiontext phải có blank Moodle dạng [[1]], [[2]]...; có choices [{"group":1,"text":"từ/cụm từ kéo thả"}]. Nếu AI dùng answers/correct/dragitems thì vẫn phải chuyển thành choices. Mỗi blank [[n]] phải có đúng một choice group=n tương ứng. Choices.text có thể trùng khi cùng một từ/cụm từ được dùng cho nhiều blank; không được trùng gây mơ hồ.',
        'calculated' => '- calculated: BẮT BUỘC questiontext chứa biến Moodle như {a}, {b}, {x}; answers[0].text phải là công thức có biến như "{a}*{b}" hoặc "floor(({b}-1)/{a})*{a}". KHÔNG dùng số cụ thể. Không dùng đáp án số tĩnh. Chỉ dùng hàm phù hợp với khối + lớp + bài học hiện tại theo qui định chương trình giáo dục.',
        'calculatedsimple' => '- calculatedsimple: BẮT BUỘC questiontext chứa biến Moodle như {a}, {b}, {x}; answers[0].text phải là công thức có biến như "{a}*{b}" hoặc "floor(({b}-1)/{a})*{a}". KHÔNG dùng số cụ thể. Không dùng đáp án số tĩnh. Chỉ dùng hàm phù hợp với khối + lớp + bài học hiện tại theo qui định chương trình giáo dục.',
        'calculatedmulti' => '- calculatedmulti: Trắc nghiệm tính toán. BẮT BUỘC questiontext chứa biến Moodle như {a}, {b}; có vars {"a":{"min":1,"max":10,"decimals":0}}; answers tối thiểu 3 đáp án, đúng 1 đáp án fraction=100, các đáp án sai fraction=0. Mỗi answers[].text phải là công thức có biến, ví dụ "{a}*{b}", "{a}+{b}", "floor(({b}-1)/{a})*{a}". KHÔNG dùng đáp án số tĩnh, KHÔNG dùng LaTeX trong answers[].text, KHÔNG dùng dấu = trong công thức đáp án. Chỉ dùng hàm phù hợp với khối + lớp + bài học hiện tại theo qui định chương trình giáo dục.',
        'description' => '- description: nội dung mô tả không tính điểm, chỉ dùng khi giáo viên chọn.',
        'ddimageortext' => '- ddimageortext: Kéo thả chữ hoặc ảnh lên ảnh nền. BẮT BUỘC questiontext chỉ chứa marker ngắn [IMG bg1]; metadata ảnh đặt trong images. Chỉ dùng items[].drop_zone để map đáp án đúng; KHÔNG dùng zones riêng. Ví dụ SGK: images:{"bg1":{"label":"Hình 1.4","source":"sgk","page":12,"source_box":[80,120,920,640]}} (thứ tự [xmin,ymin,xmax,ymax]). Ví dụ URL: source là URL ảnh trực tiếp. Trả items [{"id":"i1","type":"text","content":"...","drop_zone":{"left":120,"top":340,"width":100,"height":30}}]; nhiễu đặt trong da_nhieu hoặc items có drop_zone=null. Không nhúng metadata ảnh dài vào content/questiontext. Các drop_zone phải nằm trong 0-1000, không vượt ảnh và không chồng lấn nhau; nếu vị trí gần nhau hãy giảm width/height hoặc tách top/left rõ ràng. Các item label. Ảnh nền phải có ô trống, vùng trống, sơ đồ chưa ghi nhãn hoặc vùng cần phân loại. Item kéo phải là kiến thức học sinh phải suy luận, không được copy trực tiếp chữ đang hiện trong ảnh. Chỉ dùng ddimageortext khi mỗi vùng drop_zone thực sự yêu cầu học sinh hiểu nội dung để quyết định vị trí.',
        'ddmarker' => '- ddmarker: Đánh dấu vùng trên ảnh. BẮT BUỘC questiontext chỉ chứa marker ngắn [IMG bg1], metadata ảnh đặt trong images. Trả markers/zones theo tọa độ trên ảnh nền hiển thị, ví dụ {"label":"...","shape":"rectangle","coords":[xmin,ymin,xmax,ymax]}. shape chỉ được: rectangle hoặc circle. coords rectangle: [xmin,ymin,xmax,ymax]. coords circle: [center_x,center_y,radius]',
        'random' => '- random: không tạo nội dung câu hỏi cụ thể; chỉ dùng nếu giáo viên chọn rõ.',
    ];
    $active = self::active_qtype_counts($options);
    $lines = [];
    foreach ($active as $type => $count) {
        if (isset($schemas[$type])) {
            $lines[] = $schemas[$type] . ' Số lượng bắt buộc: ' . $count . '.';
        }
    }
    return $lines ? implode("\n", $lines) . "\n" : "- shortanswer: có answers [{\"text\":\"đáp án\",\"fraction\":100}].\n";
}

protected static function active_qtype_counts(array $options): array {
    $qtypes = [];
    if (!empty($options['qtypes']) && is_array($options['qtypes'])) {
        foreach ($options['qtypes'] as $type => $count) {
            $type = self::normalize_qtype((string)$type);
            $count = (int)$count;
            if ($type !== '' && $count > 0) {
                $qtypes[$type] = $count;
            }
        }
    }
    if (!$qtypes) {
        $qtypes['shortanswer'] = self::safe_total($options);
    }
    return $qtypes;
}

protected static function active_level_counts(array $options): array {
    $map = ['recognize' => 'nhan_biet', 'understand' => 'thong_hieu', 'apply' => 'van_dung'];
    $levels = [];
    if (!empty($options['cognitive']) && is_array($options['cognitive'])) {
        foreach ($options['cognitive'] as $level => $count) {
            $level = $map[$level] ?? trim((string)$level);
            $count = (int)$count;
            if ($level !== '' && $count > 0) {
                $levels[$level] = $count;
            }
        }
    }
    if (!$levels) {
        $levels['nhan_biet'] = self::safe_total($options);
    }
    return $levels;
}

protected static function call(string $feature, int $userid, bool $preferuser, string $prompt, array $images, bool $jsonmode): array {
    $attempted = [];
    $last = '';
    for ($try = 0; $try < 30; $try++) {
        $key = ai_key_manager::get_available_key($feature, $attempted, $userid, $preferuser, 0);
        if (!$key) { break; }
        $attempted[] = (string)($key->_source_table ?? 'local_aisgk_ai_keys') . ':' . (int)$key->id;
        $provider = ai_key_manager::provider_for_key($key);
        foreach (ai_key_manager::model_attempts_for_key($key, $feature) as $model) {
            $callkey = clone $key;
            if ($feature === 'homework') { $callkey->model_homework = $model; } else { $callkey->model_scan = $model; }
            try {
                $payload = self::build_payload($provider, $model, $prompt, $images, $jsonmode);
                $tokens = self::count_tokens($callkey, $provider, $model, $payload);
                if (!ai_key_manager::can_use_key($callkey, $tokens)) {
                    $last = 'Key vượt giới hạn RPM/RPD/TPM';
                    continue;
                }
                $response = self::execute($callkey, $provider, $model, $payload);
                $usage = ai_key_manager::mark_success($key, $tokens, $model, $userid, $feature);
                return ['provider'=>$provider,'model'=>$model,'tokens'=>$tokens,'usage'=>$usage,'keysource'=>(string)($callkey->_source_table ?? 'system'),'category'=>(string)($callkey->category_key ?? 'free'),'response'=>$response];
            } catch (\Throwable $e) {
                $last = $e->getMessage();
                if (preg_match('/invalid api key|api key not valid|unauthorized|401/i', $last)) {
                    ai_key_manager::mark_blocked($key, $last);
                    break;
                }
                if (ai_key_manager::is_model_channel_error($last) || preg_match('/unsupported model|model not found|model.*not.*available/i', $last)) {
                    ai_key_manager::mark_model_blocked($key, $model, $feature, $last);
                    continue;
                }
                if (preg_match('/forbidden|permission denied|403/i', $last)) {
                        // 403 can be either key-level permission or model not enabled. Prefer blocking the current model first.
                    ai_key_manager::mark_model_blocked($key, $model, $feature, $last);
                    continue;
                }
                if (preg_match('/429|rate limit|resource exhausted|too many requests|quota/i', $last)) {
                    if (ai_key_manager::is_daily_quota_error($last)) {
                        ai_key_manager::mark_daily_quota($key, $last, $model, $feature);
                    } else {
                        ai_key_manager::mark_429($key, $last, $model, $feature);
                    }
                    continue;
                }
                ai_key_manager::mark_error($key, $last);
            }
        }
    }
    throw new \moodle_exception('errorprocessingbook', 'local_aisgk', '', 'Không có API key khả dụng hoặc key đang cooldown/bị lỗi. Lỗi cuối: ' . $last);
}

protected static function build_payload(string $provider, string $model, string $prompt, array $images, bool $jsonmode): array {
    if ($provider === 'shopaikey') {
        $content = [['type'=>'text','text'=>$prompt]];
        foreach ($images as $image) {
            $url = self::image_data_url($image);
            if ($url !== '') { $content[] = ['type'=>'image_url','image_url'=>['url'=>$url]]; }
        }
        $payload = ['model'=>$model,'messages'=>[['role'=>'user','content'=>$content]],'temperature'=>0.05,'max_tokens'=>20000];
        if ($jsonmode) { $payload['response_format'] = ['type'=>'json_object']; }
        return $payload;
    }
    $parts = [['text'=>$prompt]];
    foreach ($images as $image) {
        $inline = self::inline_image($image);
        if ($inline) { $parts[] = ['inlineData'=>$inline]; }
    }
    $payload = ['contents'=>[['parts'=>$parts]],'generationConfig'=>['temperature'=>0.05,'maxOutputTokens'=>20000]];
    if ($jsonmode) { $payload['generationConfig']['responseMimeType'] = 'application/json'; }
    return $payload;
}

protected static function execute(\stdClass $key, string $provider, string $model, array $payload): array {
    $apikey = trim((string)($key->api_key ?? ''));
    if ($apikey === '') { throw new \moodle_exception('errorprocessingbook', 'local_aisgk', '', 'API key rỗng.'); }
    if ($provider === 'shopaikey') {
        $url = 'https://api.shopaikey.com/v1/chat/completions';
        $headers = ['Content-Type: application/json', 'Authorization: Bearer ' . $apikey];
    } else {
        $url = 'https://generativelanguage.googleapis.com/v1beta/models/' . rawurlencode($model) . ':generateContent';
        $headers = ['Content-Type: application/json', 'X-goog-api-key: ' . $apikey];
    }
    $ch = curl_init($url);
    curl_setopt_array($ch, [CURLOPT_RETURNTRANSFER=>true,CURLOPT_POST=>true,CURLOPT_HTTPHEADER=>$headers,CURLOPT_POSTFIELDS=>json_encode($payload, JSON_UNESCAPED_UNICODE|JSON_UNESCAPED_SLASHES),CURLOPT_TIMEOUT=>180,CURLOPT_CONNECTTIMEOUT=>15]);
    $response = curl_exec($ch);
    $errno = curl_errno($ch);
    $error = curl_error($ch);
    $http = (int)curl_getinfo($ch, CURLINFO_RESPONSE_CODE);
    curl_close($ch);
    if ($errno) { throw new \moodle_exception('errorprocessingbook', 'local_aisgk', '', 'Lỗi kết nối API: ' . $error); }
    $json = json_decode((string)$response, true);
    if (!is_array($json)) { throw new \moodle_exception('errorprocessingbook', 'local_aisgk', '', 'API trả dữ liệu không hợp lệ: ' . mb_substr((string)$response,0,1000)); }
    if ($http >= 400 || !empty($json['error'])) {
        $err = $json['error'] ?? [];
        $msg = is_array($err) ? (string)($err['message'] ?? ('HTTP '.$http)) : (string)$err;
        throw new \moodle_exception('errorprocessingbook', 'local_aisgk', '', 'API_ERROR: ' . $msg);
    }
    return $json;
}

protected static function count_tokens(\stdClass $key, string $provider, string $model, array $payload): int {
    $total = 0;
    foreach (($payload['contents'] ?? []) as $content) {
        foreach (($content['parts'] ?? []) as $part) {
            if (!empty($part['text'])) { $total += (int)ceil(mb_strlen($part['text'], 'UTF-8') / 3); }
            if (!empty($part['inlineData']['data'])) {
                $imgdata = base64_decode($part['inlineData']['data'], true);
                if ($imgdata !== false) {
                    $info = @getimagesizefromstring($imgdata);
                    if ($info && !empty($info[0]) && !empty($info[1])) {
                        $w = (int)$info[0];
                        $h = (int)$info[1];
                        $total += ($w <= 384 && $h <= 384) ? 258 : (max(1, (int)ceil($w / 768)) * max(1, (int)ceil($h / 768)) * 258);
                    } else { $total += 2500; }
                } else { $total += 2500; }
            }
        }
    }
    if ($total <= 0) {
        $raw = json_encode($payload, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
        $total = (int)ceil(strlen($raw) / 4);
    }
    return max(1, (int)$total);
}

protected static function inline_image(string $image): ?array {
    $data = @file_get_contents($image);
    if (!$data) { return null; }
    $ext = strtolower(pathinfo($image, PATHINFO_EXTENSION));
    $mime = ($ext === 'jpg' || $ext === 'jpeg') ? 'image/jpeg' : (($ext === 'webp') ? 'image/webp' : 'image/png');
    return ['mimeType'=>$mime,'data'=>base64_encode($data)];
}

protected static function image_data_url(string $image): string {
    $i = self::inline_image($image);
    return $i ? ('data:' . $i['mimeType'] . ';base64,' . $i['data']) : '';
}

protected static function response_text(array $json, string $provider): string {
    if ($provider === 'shopaikey') {
        $c = $json['choices'][0]['message']['content'] ?? '';
        if (is_array($c)) { return implode("\n", array_map(fn($p)=>(string)($p['text'] ?? ''), $c)); }
        return (string)$c;
    }
    $text = '';
    foreach (($json['candidates'] ?? []) as $cand) {
        foreach (($cand['content']['parts'] ?? []) as $p) {
            if (!empty($p['text'])) { $text .= $p['text']; }
        }
    }
    return $text;
}

protected static function first_balanced_json_slice(string $text): string {
    $len = strlen($text);
    $start = false;
    for ($i = 0; $i < $len; $i++) {
        $ch = $text[$i];
        if ($ch === '{' || $ch === '[') { $start = $i; break; }
    }
    if ($start === false) { return ''; }

    $stack = [];
    $instr = false;
    $esc = false;
    for ($i = $start; $i < $len; $i++) {
        $ch = $text[$i];
        if ($instr) {
            if ($esc) { $esc = false; continue; }
            if ($ch === '\\') { $esc = true; continue; }
            if ($ch === '"') { $instr = false; }
            continue;
        }
        if ($ch === '"') { $instr = true; continue; }
        if ($ch === '{' || $ch === '[') { $stack[] = $ch; continue; }
        if ($ch === '}' || $ch === ']') {
            if (!$stack) { return ''; }
            $open = array_pop($stack);
            if (($open === '{' && $ch !== '}') || ($open === '[' && $ch !== ']')) { return ''; }
            if (!$stack) { return substr($text, $start, $i - $start + 1); }
        }
    }
    return '';
}

protected static function repair_json_latex_slashes(string $text): string {
        // Escape các backslash không hợp lệ trong JSON, thường do LaTeX như \(, \), \{, \}, \in, \notin.
        // Không dùng preg_replace thuần vì dễ sửa nhầm dấu \\ thứ hai trong chuỗi đã escape sẵn (ví dụ \\{).
    $out = '';
    $len = strlen($text);
    $validsimple = '"\\/bfnrt';
    for ($i = 0; $i < $len; $i++) {
        $ch = $text[$i];
        if ($ch !== '\\') {
            $out .= $ch;
            continue;
        }
        $next = $text[$i + 1] ?? '';
        if ($next === 'u') {
            $hex = substr($text, $i + 2, 4);
            if (strlen($hex) === 4 && ctype_xdigit($hex)) {
                $out .= substr($text, $i, 6);
                $i += 5;
            } else {
                $out .= '\\\\';
            }
            continue;
        }
        if ($next !== '' && strpos($validsimple, $next) !== false) {
            $out .= $ch . $next;
            $i++;
        } else {
            $out .= '\\\\';
        }
    }
    return $out;
}
protected static function decode_json_text(string $text, string $label): array {
    if (preg_match('/data:image|base64|image_data/i', $text)) {
        throw new \moodle_exception('errorprocessingbook', 'local_aisgk', '', $label . ': AI không được trả ảnh base64/data:image; chỉ dùng URL hoặc SGK bbox.');
    }
    $clean = trim($text);
    $clean = preg_replace('/^```(?:json)?\s*/i', '', $clean);
    $clean = preg_replace('/\s*```$/', '', $clean);

    $trydecode = static function(string $candidate): ?array {
        $candidate = trim($candidate);
        $json = json_decode($candidate, true);
        if (is_array($json)) {
            return $json;
        }
            // Một số provider/model trả JSON object dưới dạng chuỗi escaped:
            // "{\n  \"questions\": [...]\n}". Khi đó json_decode lần 1 ra string,
            // cần decode thêm lần 2 để lấy object/mảng làm việc bình thường.
        if (is_string($json)) {
            $inner = trim($json);
            $json2 = json_decode($inner, true);
            if (is_array($json2)) {
                return $json2;
            }
            $fixedinner = self::repair_json_latex_slashes($inner);
            $json2 = json_decode($fixedinner, true);
            if (is_array($json2)) {
                return $json2;
            }
        }
        $fixed = self::repair_json_latex_slashes($candidate);
        $json = json_decode($fixed, true);
        if (is_array($json)) {
            return $json;
        }
        if (is_string($json)) {
            $inner = trim($json);
            $json2 = json_decode($inner, true);
            if (is_array($json2)) {
                return $json2;
            }
            $fixedinner = self::repair_json_latex_slashes($inner);
            $json2 = json_decode($fixedinner, true);
            if (is_array($json2)) {
                return $json2;
            }
        }
        return null;
    };

    $json = $trydecode($clean);
    if (!is_array($json)) {
        $slice = self::first_balanced_json_slice($clean);
        if ($slice !== '') {
            $json = $trydecode($slice);
        }
    }
    if (!is_array($json)) {
        $err = json_last_error_msg();
        throw new \moodle_exception('errorprocessingbook', 'local_aisgk', '', $label . ': ' . $err . '. AI có thể đã trả JSON bị cắt ngang hoặc có dấu gạch chéo công thức chưa escape. Đoạn đầu: ' . mb_substr($text, 0, 1200));
    }
    return $json;
}
protected static function extract_rows(string $text): array {
    $json = self::decode_json_text($text, 'Không phân tích được JSON AI trả về');
    $rows = $json['rows'] ?? $json;
    if (!is_array($rows)) { throw new \moodle_exception('errorprocessingbook','local_aisgk','','JSON AI không có rows.'); }
    return $rows;
}

protected static function extract_questions(string $text, int $limit = 12, array $options = []): array {
    $json = self::decode_json_text($text, 'Không phân tích được JSON bài tập AI trả về');
    $questions = $json['questions'] ?? $json;
    if (!is_array($questions)) { throw new \moodle_exception('errorprocessingbook','local_aisgk','','JSON bài tập AI không có questions.'); }
    return self::validate_questions(array_values($questions), $limit, $options);
}

protected static function normalize_level(string $level): string {
    $level = strtolower(trim($level));
    $level = str_replace([' ', '-'], '_', $level);
    $map = [
        'recognize' => 'nhan_biet', 'recognise' => 'nhan_biet', 'nhận_biết' => 'nhan_biet', 'nhanbiet' => 'nhan_biet',
        'understand' => 'thong_hieu', 'thông_hiểu' => 'thong_hieu', 'thonghieu' => 'thong_hieu',
        'apply' => 'van_dung', 'vận_dụng' => 'van_dung', 'vandung' => 'van_dung'
    ];
    return $map[$level] ?? $level;
}

protected static function normalize_qtype(string $type): string {
    $type = strtolower(trim($type));
    $type = str_replace([' ', '-'], '_', $type);
    $map = [
        'multiplechoice' => 'multichoice',
        'multi_choice' => 'multichoice',
        'mcq' => 'multichoice',
        'true_false' => 'truefalse',
        'short_answer' => 'shortanswer',
        'number' => 'numerical',
        'numeric' => 'numerical',
        'match' => 'matching',
        'matches' => 'matching',
        'pairing' => 'matching',
        'pairs' => 'matching',
        'drag_drop_text' => 'ddwtos',
        'dragdroptext' => 'ddwtos',
        'drag_and_drop_text' => 'ddwtos',
        'drag_and_drop_into_text' => 'ddwtos',
        'drop_down' => 'gapselect',
        'dropdown' => 'gapselect',
        'calculated_simple' => 'calculatedsimple',
        'calculated_multi' => 'calculatedmulti',
    ];
    return $map[$type] ?? $type;
}
protected static function parse_img_attr_string(string $attrtext): array {
    $attrs = [];
    if (preg_match_all('/([a-zA-Z_][a-zA-Z0-9_]*)\s*=\s*("([^"]*)"|\'([^\']*)\'|([^\s\]]+))/u', $attrtext, $matches, PREG_SET_ORDER)) {
        foreach ($matches as $m) {
            $value = $m[3] !== '' ? $m[3] : ($m[4] !== '' ? $m[4] : ($m[5] ?? ''));
            $attrs[strtolower($m[1])] = trim((string)$value);
        }
    }
    return $attrs;
}

protected static function parse_size_pair(string $value): array {
    $value = trim($value);
    if (preg_match('/^(\d{1,5})\s*[xX,]\s*(\d{1,5})$/', $value, $m)) {
        return ['w' => max(1, (int)$m[1]), 'h' => max(1, (int)$m[2])];
    }
    return ['w' => 0, 'h' => 0];
}

protected static function parse_box4(string $value): array {
    $parts = array_map('trim', explode(',', $value));
    if (count($parts) !== 4) { return []; }
    return array_map('intval', $parts);
}

protected static function normalize_img_size($value): array {
    if (is_array($value)) {
        if (isset($value['w']) || isset($value['h'])) {
            return ['w' => max(0, (int)($value['w'] ?? 0)), 'h' => max(0, (int)($value['h'] ?? 0))];
        }
        if (isset($value[0]) && isset($value[1])) {
            return ['w' => max(0, (int)$value[0]), 'h' => max(0, (int)$value[1])];
        }
    }
    return self::parse_size_pair((string)$value);
}

protected static function normalize_drop_zone(array $dz): array {
    $left = (int)($dz['left'] ?? $dz['x'] ?? 0);
    $top = (int)($dz['top'] ?? $dz['y'] ?? 0);
    $width = (int)($dz['width'] ?? $dz['w'] ?? 80);
    $height = (int)($dz['height'] ?? $dz['h'] ?? 30);
        // Chuẩn mới: drop_zone là 0-1000 grid trên ảnh nền đã crop. Giữ backward compatibility bằng cách clamp.
    $left = max(0, min(1000, $left));
    $top = max(0, min(1000, $top));
    $width = max(1, min(1000 - $left, $width));
    $height = max(1, min(1000 - $top, $height));
    return ['left' => $left, 'top' => $top, 'width' => $width, 'height' => $height];
}


protected static function repair_drop_zone_overlaps(array $items): array {
    $placed = [];
    foreach ($items as $idx => $item) {
        if (!is_array($item) || !is_array($item['drop_zone'] ?? null)) { continue; }
        $dz = self::normalize_drop_zone($item['drop_zone']);
        $guard = 0;
        while ($guard++ < 40) {
            $changed = false;
            foreach ($placed as $old) {
                $ix = max(0, min($dz['left'] + $dz['width'], $old['left'] + $old['width']) - max($dz['left'], $old['left']));
                $iy = max(0, min($dz['top'] + $dz['height'], $old['top'] + $old['height']) - max($dz['top'], $old['top']));
                $ia = $ix * $iy;
                $ma = min(max(1, $dz['width'] * $dz['height']), max(1, $old['width'] * $old['height']));
                if ($ia > 0 && ($ia / $ma) > 0.60) {
                    $stepx = max(8, (int)ceil($old['width'] * 0.35));
                    $stepy = max(8, (int)ceil($old['height'] * 1.10));
                    if ($dz['left'] + $dz['width'] + $stepx <= 1000) {
                        $dz['left'] += $stepx;
                    } else if ($dz['left'] - $stepx >= 0) {
                        $dz['left'] -= $stepx;
                    } else if ($dz['top'] + $dz['height'] + $stepy <= 1000) {
                        $dz['top'] += $stepy;
                    } else if ($dz['top'] - $stepy >= 0) {
                        $dz['top'] -= $stepy;
                    } else {
                        $dz['width'] = max(1, (int)floor($dz['width'] * 0.80));
                        $dz['height'] = max(1, (int)floor($dz['height'] * 0.80));
                    }
                    $dz = self::normalize_drop_zone($dz);
                    $changed = true;
                    break;
                }
            }
            if (!$changed) { break; }
        }
        $items[$idx]['drop_zone'] = $dz;
        $placed[] = $dz;
    }
    return $items;
}

protected static function normalize_img_box($value): array {
    if (is_array($value)) {
        $vals = array_values($value);
        if (count($vals) === 4) { return array_map('intval', $vals); }
    }
    return self::parse_box4((string)$value);
}

protected static function expand_img_box(array $box, array $size = [], float $ratio = 0.04, int $minpad = 8): array {
    if (count($box) !== 4) { return $box; }
    $w = max(0, (int)$box[2] - (int)$box[0]);
    $h = max(0, (int)$box[3] - (int)$box[1]);
    $padx = max($minpad, (int)round($w * $ratio));
    $pady = max($minpad, (int)round($h * $ratio));
    $x1 = (int)$box[0] - $padx;
    $y1 = (int)$box[1] - $pady;
    $x2 = (int)$box[2] + $padx;
    $y2 = (int)$box[3] + $pady;
    $maxw = (int)($size['w'] ?? 0);
    $maxh = (int)($size['h'] ?? 0);
    if ($maxw > 0) { $x1 = max(0, $x1); $x2 = min($maxw, $x2); }
    if ($maxh > 0) { $y1 = max(0, $y1); $y2 = min($maxh, $y2); }
    return [$x1, $y1, $x2, $y2];
}

protected static function normalize_crop_offset($value): array {
    if (is_array($value)) {
        return ['x' => (int)($value['x'] ?? $value[0] ?? 0), 'y' => (int)($value['y'] ?? $value[1] ?? 0)];
    }
    return ['x' => 0, 'y' => 0];
}

protected static function sent_meta_for_page(array $options, int $page): array {
    $meta = $options['_sent_image_meta'] ?? [];
    if (!is_array($meta) || $page <= 0) { return []; }
    return is_array($meta[$page] ?? null) ? $meta[$page] : [];
}

protected static function image_box_to_original(array $box, array $sentmeta): array {
    if (count($box) !== 4) { return $box; }
    $sent = self::normalize_img_size($sentmeta['sent_size'] ?? $sentmeta['source_size'] ?? []);
    $pdf = self::normalize_img_size($sentmeta['pdf_size'] ?? []);
    $off = self::normalize_crop_offset($sentmeta['crop_offset'] ?? []);
    $scale = (float)($sentmeta['scale'] ?? 0);
    if (($pdf['w'] ?? 0) <= 0 || ($pdf['h'] ?? 0) <= 0) {
        return self::expand_img_box($box, []);
    }
    $maxx = max((int)$box[0], (int)$box[2]);
    $maxy = max((int)$box[1], (int)$box[3]);
    $looks_like_sent = $scale > 0
    && ($sent['w'] ?? 0) > 0 && ($sent['h'] ?? 0) > 0
    && $maxx <= ((int)$sent['w'] + 20)
    && $maxy <= ((int)$sent['h'] + 20)
    && ((int)$sent['w'] < (int)$pdf['w'] || (int)$sent['h'] < (int)$pdf['h'] || ($off['x'] ?? 0) > 0 || ($off['y'] ?? 0) > 0);
    if ($looks_like_sent) {
        $box = [
            (int)round(((int)$box[0] / $scale) + (int)$off['x']),
            (int)round(((int)$box[1] / $scale) + (int)$off['y']),
            (int)round(((int)$box[2] / $scale) + (int)$off['x']),
            (int)round(((int)$box[3] / $scale) + (int)$off['y']),
        ];
    }
    return self::expand_img_box($box, $pdf);
}

protected static function clean_output_image_meta(array $img): array {
    $source = (string)($img['source'] ?? 'sgk');
    $sourceout = ($source !== 'sgk' && !empty($img['url'])) ? trim((string)$img['url']) : $source;
    $out = [
        'label' => trim((string)($img['label'] ?? 'ảnh')),
        'source' => $sourceout,
    ];
    if ($source === 'sgk') {
        $out['page'] = (int)($img['page'] ?? 0);
    } else if ($source === 'box') {
        $out['source'] = 'box';
    }
    $box = self::normalize_img_box($img['source_box'] ?? []);
    if (count($box) === 4) { $out['source_box'] = array_values($box); }
    return $out;
}

protected static function apply_sent_meta_to_image(array $img, array $options): array {
        // Giữ source_box đúng như AI trả về: hệ chuẩn hóa 0-1000 [xmin,ymin,xmax,ymax].
        // Metadata crop/resize được giữ ở backend (_sent_image_meta) và chỉ dùng lúc render/cắt ảnh thật.
        // Không map về pixel ảnh gốc ở bước normalize để tránh double-scale và lệch crop.
    return self::clean_output_image_meta($img);
}

protected static function normalize_image_source_fields($sourcevalue, $urlvalue = ''): array {
    $sourcevalue = trim((string)$sourcevalue);
    $urlvalue = trim((string)$urlvalue);
    if ($sourcevalue !== '' && preg_match('#^https?://#i', $sourcevalue)) {
        return ['source' => 'internet', 'url' => $sourcevalue];
    }
    $source = strtolower($sourcevalue !== '' ? $sourcevalue : 'sgk');
    if ($source === 'url' || $source === 'web') { $source = 'internet'; }
    if ($source === 'box' || $source === 'canvas') { return ['source' => 'box', 'url' => '']; }
    if ($source === 'internet') {
        return ['source' => 'internet', 'url' => $urlvalue];
    }
    return ['source' => 'sgk', 'url' => ''];
}

protected static function img_ref_from_meta(string $id, array $meta): ?array {
    $id = trim((string)($meta['id'] ?? $id));
    if ($id === '') { return null; }
    $srcdata = self::normalize_image_source_fields($meta['source'] ?? 'sgk', $meta['url'] ?? '');
    $source = $srcdata['source'];
    $url = $srcdata['url'];
    $box = self::normalize_img_box($meta['source_box'] ?? ($meta['box'] ?? []));
    if (count($box) !== 4) { return null; }
    return [
        'label' => trim((string)($meta['label'] ?? $id ?: 'ảnh')),
        'id' => $id,
        'role' => strtolower((string)($meta['role'] ?? 'inline')),
        'source' => $source,
        'page' => (int)($meta['page'] ?? $meta['page_index'] ?? 0),
        'url' => $url,
        'source_size' => self::normalize_img_size($meta['source_size'] ?? ''),
        'source_box' => $box,
        'location' => trim((string)($meta['location'] ?? '')),
        'canvas_size' => self::normalize_img_size($meta['canvas_size'] ?? ''),
        'pdf_size' => self::normalize_img_size($meta['pdf_size'] ?? ''),
        'crop_offset' => self::normalize_crop_offset($meta['crop_offset'] ?? []),
        'scale' => (float)($meta['scale'] ?? 0),
        'sent_image_id' => (string)($meta['sent_image_id'] ?? ''),
        'coord' => 'normalized_1000_yxyx',
    ];
}

protected static function extract_img_refs_from_images_field($images): array {
    $refs = [];
    if (!is_array($images)) { return $refs; }
    foreach ($images as $key => $meta) {
        if (!is_array($meta)) { continue; }
        $id = is_string($key) ? $key : (string)($meta['id'] ?? '');
        $ref = self::img_ref_from_meta($id, $meta);
        if ($ref) { $refs[] = $ref; }
    }
    return $refs;
}
protected static function extract_img_refs_new(string $text): array {
    $refs = [];
    if ($text === '' || strpos($text, '[IMG') === false) { return $refs; }
    if (preg_match_all('/\[IMG\s+([^\]]+)\]/u', $text, $matches, PREG_SET_ORDER)) {
        foreach ($matches as $m) {
            $attrs = self::parse_img_attr_string((string)$m[1]);
            $id = trim((string)($attrs['id'] ?? $attrs['label'] ?? 'img'));
            $srcdata = self::normalize_image_source_fields($attrs['source'] ?? 'sgk', $attrs['url'] ?? '');
            $source = $srcdata['source'];
            $url = $srcdata['url'];
            $box = self::parse_box4((string)($attrs['source_box'] ?? $attrs['box'] ?? ''));
            if (count($box) !== 4) { continue; }
            $refs[] = [
                'label' => trim((string)($attrs['label'] ?? $id ?: 'ảnh')),
                'id' => $id,
                'role' => strtolower((string)($attrs['role'] ?? 'inline')),
                'source' => $source,
                'page' => (int)($attrs['page'] ?? $attrs['page_index'] ?? 0),
                'url' => $url,
                'source_size' => self::parse_size_pair((string)($attrs['source_size'] ?? '')),
                'source_box' => $box,
                'canvas_size' => self::parse_size_pair((string)($attrs['canvas_size'] ?? '')),
                'coord' => 'normalized_1000_yxyx',
            ];
        }
    }
    return $refs;
}

protected static function collect_img_refs_from_question(array $q): array {
    $refs = [];
    $add = static function(array $newrefs) use (&$refs): void {
        foreach ($newrefs as $ref) {
            $box = !empty($ref['source_box']) ? $ref['source_box'] : ($ref['box_2d'] ?? []);
            $key = ($ref['coord'] ?? '') . '|' . ($ref['label'] ?? '') . '|' . ($ref['page'] ?? 0) . '|' . implode(',', (array)$box) . '|' . ($ref['url'] ?? '');
            $refs[$key] = $ref;
        }
    };
    $scan = static function(string $text) use ($add): void {
        $add(self::extract_img_refs_new($text));
    };
    $scan((string)($q['questiontext'] ?? ''));
    foreach (($q['subquestions'] ?? []) as $sq) { if (is_array($sq)) { $scan((string)($sq['question'] ?? '')); $scan((string)($sq['answer'] ?? '')); } }
    foreach (($q['choices'] ?? []) as $choice) { if (is_array($choice)) { $scan((string)($choice['text'] ?? '')); } }
    foreach (($q['answers'] ?? []) as $answer) { if (is_array($answer)) { $scan((string)($answer['text'] ?? '')); } }
    foreach (($q['items'] ?? []) as $item) { if (is_array($item)) { $scan((string)($item['content'] ?? '')); $scan((string)($item['image_id'] ?? '')); } }
    if (!empty($q['background']) && is_string($q['background'])) { $scan($q['background']); }
    $add(self::extract_img_refs_from_images_field($q['images'] ?? []));
    return array_values($refs);
}
protected static function image_meta_from_ref(array $ref): ?array {
    $id = trim((string)($ref['id'] ?? $ref['label'] ?? ''));
    if ($id === '') { return null; }
    $srcdata = self::normalize_image_source_fields($ref['source'] ?? 'sgk', $ref['url'] ?? '');
    $source = $srcdata['source'];
    $url = $srcdata['url'];
    $box = !empty($ref['source_box']) ? self::normalize_img_box($ref['source_box']) : self::normalize_img_box($ref['box_2d'] ?? []);
    if (count($box) !== 4) { return null; }
    $source_size = self::normalize_img_size($ref['source_size'] ?? '');
    $canvas_size = self::normalize_img_size($ref['canvas_size'] ?? '');
    if (($source_size['w'] ?? 0) > 0 && ($source_size['h'] ?? 0) > 0) {
        $box = self::expand_img_box($box, $source_size);
    }
    $out = [
        'label' => trim((string)($ref['label'] ?? $id ?: 'ảnh')),
        'role' => strtolower((string)($ref['role'] ?? 'inline')),
        'source' => $source,
        'source_box' => array_values($box),
    ];
    if ($source === 'sgk') {
        $out['page'] = (int)($ref['page'] ?? 0);
    } else {
        $out['source'] = $url !== '' ? $url : $source;
        if (($source_size['w'] ?? 0) > 0 && ($source_size['h'] ?? 0) > 0) {
            $out['source_size'] = ['w' => $source_size['w'], 'h' => $source_size['h']];
        }
    }
    if (($canvas_size['w'] ?? 0) > 0 && ($canvas_size['h'] ?? 0) > 0) {
        $out['canvas_size'] = ['w' => $canvas_size['w'], 'h' => $canvas_size['h']];
    }
    return $out;
}

protected static function normalize_question_images(array $q, array $options = []): array {
    $images = [];
    if (!empty($q['images']) && is_array($q['images'])) {
        foreach ($q['images'] as $key => $meta) {
            if (!is_array($meta)) { continue; }
            $id = is_string($key) ? $key : (string)($meta['id'] ?? $meta['label'] ?? '');
            $ref = self::img_ref_from_meta($id, $meta);
            if ($ref && ($m = self::image_meta_from_ref($ref))) { $images[(string)$ref['id']] = self::apply_sent_meta_to_image($m, $options); }
        }
    }
    if ($images) { $q['images'] = $images; }
    return $q;
}

protected static function normalize_ddimage_question(array $q, array $options = []): array {
    $type = (string)($q['type'] ?? '');
    if (!in_array($type, ['ddimageortext', 'ddmarker'], true)) { return $q; }
    if (!empty($q['images']) && is_array($q['images'])) {
        $cleanimages = [];
        foreach ($q['images'] as $key => $meta) {
            if (!is_array($meta)) { continue; }
            $id = is_string($key) ? $key : (string)($meta['id'] ?? '');
            $id = trim(preg_replace('/[^a-zA-Z0-9_\-]+/', '', $id) ?? '');
            if ($id === '') { $id = 'img' . (count($cleanimages) + 1); }
            $srcdata = self::normalize_image_source_fields($meta['source'] ?? 'sgk', $meta['url'] ?? '');
            $source = $srcdata['source'];
            $url = $srcdata['url'];
            $box = self::normalize_img_box($meta['source_box'] ?? ($meta['box'] ?? []));
            $source_size = self::normalize_img_size($meta['source_size'] ?? '');
            $canvas_size = self::normalize_img_size($meta['canvas_size'] ?? '');
            if ($source === 'sgk') { $url = ''; }
            $cleanimg = [
                'label' => trim((string)($meta['label'] ?? 'ảnh')),
                'role' => strtolower((string)($meta['role'] ?? ($id === 'bg1' ? 'background' : 'inline'))),
                'source' => $source,
                'page' => (int)($meta['page'] ?? $meta['page_index'] ?? 0),
                'url' => $url,
                'source_size' => ['w' => $source_size['w'] ?? 0, 'h' => $source_size['h'] ?? 0],
                'source_box' => count($box) === 4 ? array_values($box) : [],
                'canvas_size' => ['w' => $canvas_size['w'] ?? 0, 'h' => $canvas_size['h'] ?? 0],
            ];
            $cleanimages[$id] = self::apply_sent_meta_to_image($cleanimg, $options);
        }
        $q['images'] = $cleanimages;
    }
    $items = [];
    foreach (($q['items'] ?? []) as $item) {
        if (!is_array($item)) { continue; }
        $id = trim((string)($item['id'] ?? ('i' . (count($items) + 1))));
        $itype = strtolower(trim((string)($item['type'] ?? 'text')));
        if (!in_array($itype, ['text', 'image'], true)) { $itype = 'text'; }
        $clean = ['id' => $id, 'type' => $itype, 'content' => trim((string)($item['content'] ?? $item['text'] ?? $item['label'] ?? ''))];
        if ($itype === 'image') {
            $clean['image_id'] = trim((string)($item['image_id'] ?? $item['img'] ?? $item['image'] ?? ''));
            if ($clean['content'] === '' && $clean['image_id'] !== '') { $clean['content'] = '[IMG ' . $clean['image_id'] . ']'; }
        }
        $dz = $item['drop_zone'] ?? $item['dropzone'] ?? $item['drop'] ?? null;
        if (is_array($dz)) {
            $clean['drop_zone'] = self::normalize_drop_zone($dz);
        } else {
            $clean['drop_zone'] = null;
        }
        $items[$id] = $clean;
    }
    if (!empty($q['zones']) && is_array($q['zones'])) {
        foreach ($q['zones'] as $zone) {
            if (!is_array($zone)) { continue; }
            $itemid = trim((string)($zone['item'] ?? $zone['item_id'] ?? $zone['answer'] ?? ''));
            if ($itemid === '' || empty($items[$itemid])) { continue; }
            $items[$itemid]['drop_zone'] = self::normalize_drop_zone($zone);
        }
        unset($q['zones']);
    }
    if ($items) { $q['items'] = array_values(self::repair_drop_zone_overlaps($items)); }
    if (!empty($q['da_nhieu']) && is_array($q['da_nhieu'])) {
        $extras = [];
        foreach ($q['da_nhieu'] as $d) {
            if (is_array($d)) {
                $extras[] = ['id' => (string)($d['id'] ?? 'd' . (count($extras) + 1)), 'type' => strtolower((string)($d['type'] ?? 'text')) === 'image' ? 'image' : 'text', 'content' => trim((string)($d['content'] ?? $d['text'] ?? $d['label'] ?? '')), 'image_id' => trim((string)($d['image_id'] ?? $d['img'] ?? ''))];
            } else {
                $extras[] = ['id' => 'd' . (count($extras) + 1), 'type' => 'text', 'content' => trim((string)$d)];
            }
        }
        $q['da_nhieu'] = $extras;
    }
    return $q;
}

protected static function normalize_question_shape(array $q): array {
        // Chấp nhận cả type và qtype để không mất dữ liệu AI trả về khi debug.
    $type = self::normalize_qtype((string)($q['type'] ?? $q['qtype'] ?? ''));
    $q['type'] = $type;
    if (isset($q['level'])) {
        $q['level'] = self::normalize_level((string)$q['level']);
    }

    if ($type === 'matching') {
        if (empty($q['subquestions']) || !is_array($q['subquestions'])) {
            foreach (['pairs', 'items', 'matches'] as $alias) {
                if (!empty($q[$alias]) && is_array($q[$alias])) {
                    $q['subquestions'] = $q[$alias];
                    break;
                }
            }
        }
        $subs = [];
        foreach (($q['subquestions'] ?? []) as $row) {
            if (!is_array($row)) { continue; }
            $left = trim((string)($row['question'] ?? $row['left'] ?? $row['prompt'] ?? $row['term'] ?? $row['text'] ?? ''));
            $right = trim((string)($row['answer'] ?? $row['right'] ?? $row['match'] ?? $row['definition'] ?? $row['value'] ?? ''));
                // Giữ cả cặp thiếu dữ liệu để UI/validator chỉ rõ lỗi, không bỏ âm thầm.
            $subs[] = ['question' => $left, 'answer' => $right];
        }
            // Cứu lỗi phổ biến: AI tách đáp án matching ra mảng answers riêng cùng thứ tự.
        if ($subs && !empty($q['answers']) && is_array($q['answers'])) {
            $ansrows = array_values($q['answers']);
            foreach ($subs as $si => $sq) {
                if (trim((string)($sq['answer'] ?? '')) === '' && isset($ansrows[$si]) && is_array($ansrows[$si])) {
                    $subs[$si]['answer'] = trim((string)($ansrows[$si]['answer'] ?? $ansrows[$si]['text'] ?? $ansrows[$si]['right'] ?? $ansrows[$si]['value'] ?? ''));
                }
            }
            unset($q['answers']);
        }
        if (count($subs) < 2 && !empty($q['answers']) && is_array($q['answers'])) {
            foreach ($q['answers'] as $row) {
                if (!is_array($row)) { continue; }
                $left = trim((string)($row['question'] ?? $row['left'] ?? $row['prompt'] ?? $row['term'] ?? ''));
                $right = trim((string)($row['answer'] ?? $row['right'] ?? $row['text'] ?? $row['definition'] ?? ''));
                $subs[] = ['question' => $left, 'answer' => $right];
            }
        }
        if ($subs) {
            $q['subquestions'] = $subs;
        }
        unset($q['pairs'], $q['items'], $q['matches']);
        return $q;
    }

    if (in_array($type, ['gapselect', 'ddwtos'], true)) {
        $text = (string)($q['questiontext'] ?? $q['text'] ?? '');
            // AI phải dùng <<1>>, <<2>> cho placeholder; chỉ đổi dạng này sang [[1]], [[2]].
            // KHÔNG đổi {23}/ {5}, vì đó có thể là LaTeX \frac{23}{5} hoặc biến calculated.
        $text = preg_replace('/<<(\d+)>>/', '[[$1]]', $text);
        $choices = [];
        foreach (($q['choices'] ?? []) as $choice) {
            if (is_array($choice)) {
                $ctext = trim((string)($choice['text'] ?? $choice['answer'] ?? $choice['value'] ?? $choice['label'] ?? ''));
                $group = (int)($choice['group'] ?? 1);
            } else {
                $ctext = trim((string)$choice);
                $group = 1;
            }
            if ($ctext !== '') {
                $choices[] = ['group' => $group > 0 ? $group : 1, 'text' => $ctext];
            }
        }
        if (!empty($q['correct']) && is_array($q['correct'])) {
            foreach ($q['correct'] as $answer) {
                $ctext = is_array($answer) ? trim((string)($answer['text'] ?? $answer['answer'] ?? $answer['value'] ?? '')) : trim((string)$answer);
                if ($ctext !== '') {
                    $choices[] = ['group' => 1, 'text' => $ctext];
                }
            }
        }
        if (!$choices && !empty($q['answers']) && is_array($q['answers'])) {
            foreach ($q['answers'] as $answer) {
                if (is_array($answer)) {
                    $ctext = trim((string)($answer['text'] ?? $answer['answer'] ?? $answer['value'] ?? ''));
                } else {
                    $ctext = trim((string)$answer);
                }
                if ($ctext !== '') {
                    $choices[] = ['group' => 1, 'text' => $ctext];
                }
            }
        }
        if ($choices) {
            $seen = [];
            $cleanchoices = [];
            foreach ($choices as $choice) {
                $key = (int)($choice['group'] ?? 1) . '|' . mb_strtolower($choice['text']);
                if (isset($seen[$key])) { continue; }
                $seen[$key] = true;
                $cleanchoices[] = $choice;
            }
            $q['choices'] = $cleanchoices;
        }
        if (!preg_match('/\[\[\d+\]\]/', $text) && !empty($q['choices'])) {
            $i = 1;
            $text = preg_replace_callback('/_{3,}|\.\.\.+|\[blank\]|\(blank\)|\{blank\}/iu', function() use (&$i) {
                return '[[' . ($i++) . ']]';
            }, $text);
            if (!preg_match('/\[\[\d+\]\]/', $text)) {
                $prefix = trim($text);
                $text = ($prefix !== '' ? $prefix . ' ' : '') . implode(' ', array_map(function($n) { return '[[' . $n . ']]'; }, range(1, min(5, count($q['choices'])))));
            }
        }
        $q['questiontext'] = $text;
        return $q;
    }

    $q = self::normalize_ddimage_question($q);
    return $q;
}

protected static function option_has_distractors(array $options, string $type): bool {
    return !empty($options['distractors']) && is_array($options['distractors']) && !empty($options['distractors'][$type]);
}

protected static function normalize_moodle_variable_placeholders(string $text): string {
        // AI/JSON repair sometimes escapes Moodle calculated placeholders as \{a\}.
        // Keep normal LaTeX set braces like \{1;2;3\}; only unescape single variable names.
    $text = preg_replace('/\\\\\{\s*([a-zA-Z][a-zA-Z0-9_]*)\s*\\\\\}/', '{$1}', $text) ?? $text;
    return $text;
}
protected static function normalize_formula_text(string $text): string {
    $text = trim($text);
    $text = str_replace(['×', '÷', '−', ','], ['*', '/', '-', '.'], $text);
    $text = preg_replace('/^\s*=\s*/', '', $text) ?? $text;
    return trim($text);
}

protected static function apply_distractor_core(array $q, array $options): array {
    $type = (string)($q['type'] ?? '');
    if (!self::option_has_distractors($options, $type)) { return $q; }

    if (in_array($type, ['ddwtos', 'gapselect'], true)) {
        $choices = is_array($q['choices'] ?? null) ? array_values($q['choices']) : [];
        $existing = [];
        $maxgroup = 0;
        foreach ($choices as $c) {
            if (!is_array($c)) { continue; }
            $txt = trim((string)($c['text'] ?? ''));
            if ($txt !== '') { $existing[mb_strtolower($txt)] = true; }
            $maxgroup = max($maxgroup, (int)($c['group'] ?? 0));
        }
        foreach (['da_nhieu', 'distractors', 'extrachoices'] as $field) {
            foreach (($q[$field] ?? []) as $d) {
                $txt = is_array($d) ? trim((string)($d['text'] ?? $d['answer'] ?? $d['value'] ?? '')) : trim((string)$d);
                if ($txt === '') { continue; }
                $key = mb_strtolower($txt);
                if (isset($existing[$key])) { continue; }
                $existing[$key] = true;
                $choices[] = ['group' => ++$maxgroup, 'text' => $txt, 'distractor' => true];
            }
        }
        if ($choices) { $q['choices'] = $choices; }
        unset($q['da_nhieu'], $q['distractors'], $q['extrachoices']);
        return $q;
    }

    if ($type === 'matching') {
        $subs = is_array($q['subquestions'] ?? null) ? array_values($q['subquestions']) : [];
        $existing = [];
        foreach ($subs as $sq) {
            if (is_array($sq)) {
                $txt = trim((string)($sq['answer'] ?? ''));
                if ($txt !== '') { $existing[mb_strtolower($txt)] = true; }
            }
        }
        foreach (['da_nhieu', 'distractors', 'extraanswers'] as $field) {
            foreach (($q[$field] ?? []) as $d) {
                $txt = is_array($d) ? trim((string)($d['text'] ?? $d['answer'] ?? $d['value'] ?? '')) : trim((string)$d);
                if ($txt === '') { continue; }
                $key = mb_strtolower($txt);
                if (isset($existing[$key])) { continue; }
                $existing[$key] = true;
                    // Moodle matching supports extra unmatched answers as distractors.
                    // Keep question empty and mark it so validator does not count it as a real pair.
                $subs[] = ['question' => '', 'answer' => $txt, 'distractor' => true];
            }
        }
        if ($subs) { $q['subquestions'] = $subs; }
        unset($q['da_nhieu'], $q['distractors'], $q['extraanswers']);
    }
    return $q;
}

    /**
     * Chỉ dùng ở bước ghi câu hỏi thật sang Moodle.
     * Không dùng trong normalize/validator/draft vì da_nhieu phải được giữ riêng để AI dễ sinh đúng.
     */
    public static function prepare_distractors_for_moodle(array $q, array $options): array {
        return self::apply_distractor_core($q, $options);
    }

    /**
     * Convert a whole question list to Moodle-ready structures.
     * Draft JSON remains untouched: da_nhieu stays separate until this method is called.
     */
    public static function prepare_questions_for_moodle(array $questions, array $options): array {
        $normalized = self::normalize_homework_questions($questions, $options);
        $out = [];
        foreach ($normalized as $q) {
            if (!is_array($q)) { continue; }
            $out[] = self::prepare_distractors_for_moodle($q, $options);
        }
        return $out;
    }

    protected static function normalize_calculated_question(array $q): array {
        $type = (string)($q['type'] ?? '');
        if (!in_array($type, ['calculated', 'calculatedsimple', 'calculatedmulti'], true)) { return $q; }
        if (isset($q['questiontext'])) {
            $q['questiontext'] = self::normalize_moodle_variable_placeholders((string)$q['questiontext']);
        }
        $vars = [];
        foreach (['vars', 'variables', 'datasets', 'wildcards'] as $alias) {
            if (!empty($q[$alias]) && is_array($q[$alias])) { $vars = $q[$alias]; break; }
        }
        if (empty($vars) && !empty($q['options']['variables']) && is_array($q['options']['variables'])) {
            $vars = $q['options']['variables'];
        }
        if (empty($vars) && !empty($q['dataset_definitions']) && is_array($q['dataset_definitions'])) {
            $vars = $q['dataset_definitions'];
        }
        $cleanvars = [];
        foreach ($vars as $name => $def) {
            if (is_int($name) && is_array($def)) { $name = (string)($def['name'] ?? ''); }
            $name = preg_replace('/[^a-zA-Z0-9_]/', '', (string)$name) ?? '';
            if ($name === '' || !preg_match('/^[a-zA-Z]/', $name)) { continue; }
            $def = is_array($def) ? $def : [];
            $min = (float)($def['min'] ?? $def['minimum'] ?? 1);
            $max = (float)($def['max'] ?? $def['maximum'] ?? 10);
            if ($max <= $min) { $max = $min + 10; }
            $decimals = max(0, min(3, (int)($def['decimals'] ?? $def['decimalplaces'] ?? 0)));
            $cleanvars[$name] = ['min' => $min, 'max' => $max, 'decimals' => $decimals];
        }
        if ($cleanvars) {
            $q['vars'] = $cleanvars;
            unset($q['variables'], $q['datasets'], $q['wildcards'], $q['dataset_definitions']);
            if (isset($q['options']['variables'])) { unset($q['options']['variables']); }
            if (empty($q['options'])) { unset($q['options']); }
        }        if (!empty($q['answers']) && is_array($q['answers'])) {
            $answers = [];
            foreach ($q['answers'] as $a) {
                if (!is_array($a)) { $a = ['text' => (string)$a]; }
                $a['text'] = self::normalize_moodle_variable_placeholders((string)($a['text'] ?? $a['answer'] ?? $a['formula'] ?? ''));
                $a['text'] = self::normalize_formula_text($a['text']);                if (!isset($a['fraction'])) { $a['fraction'] = empty($answers) ? 100 : 0; }
                if (!isset($a['tolerance'])) { $a['tolerance'] = 0; }
                $answers[] = $a;
            }
            $q['answers'] = $answers;
        }
        return $q;
    }

    protected static function allowed_calculated_functions(): array {
        // Whitelist hàm công thức Moodle đủ an toàn cho calculated/calculatedsimple.
        // Prompt vẫn yêu cầu AI chỉ dùng hàm phù hợp khối + lớp + bài học hiện tại.
        return [
            'abs', 'acos', 'acosh', 'asin', 'asinh', 'atan', 'atan2', 'atanh',
            'ceil', 'cos', 'cosh', 'deg2rad', 'exp', 'floor', 'fmod', 'log', 'log10',
            'max', 'min', 'pi', 'pow', 'rad2deg', 'round', 'sin', 'sinh', 'sqrt', 'tan', 'tanh'
        ];
    }

    protected static function formula_validation_errors(string $formula, int $no, string $label): array {
        $errors = [];
        if ($formula === '') { return ['Câu ' . $no . ' ' . $label . ' rỗng.']; }
        if (!preg_match('/\{[a-zA-Z][a-zA-Z0-9_]*\}/', $formula)) {
            $errors[] = 'Câu ' . $no . ' ' . $label . ' phải là công thức có biến Moodle {a}/{b}, không dùng số cố định.';
        }
        if (strpos($formula, '=') !== false || preg_match('/\\[a-zA-Z]+/', $formula) || preg_match('/<[^>]+>/', $formula)) {
            $errors[] = 'Câu ' . $no . ' ' . $label . ' không được chứa dấu =, LaTeX hoặc HTML.';
        }

        $tmp = preg_replace('/\{[a-zA-Z][a-zA-Z0-9_]*\}/', '1', $formula) ?? $formula;
        $funcs = self::allowed_calculated_functions();
        if (preg_match_all('/\b([a-zA-Z_][a-zA-Z0-9_]*)\s*\(/', $tmp, $matches)) {
            foreach ($matches[1] as $fname) {
                if (!in_array(strtolower($fname), $funcs, true)) {
                    $errors[] = 'Câu ' . $no . ' ' . $label . ' dùng hàm không nằm trong whitelist Moodle/an toàn: ' . $fname . '.';
                }
            }
        }
        // Sau khi xác nhận tên hàm whitelist, bỏ tên hàm để kiểm tra ký tự còn lại.
        $pattern = '/\b(' . implode('|', array_map('preg_quote', $funcs)) . ')\s*\(/i';
        $tmp = preg_replace($pattern, '(', $tmp) ?? $tmp;
        // Cho phép dấu phẩy cho hàm min/max/round/pow và số thập phân.
        if (preg_match('/[^0-9\.\+\-\*\/\^\(\)\,\s]/', $tmp)) {
            $errors[] = 'Câu ' . $no . ' ' . $label . ' chứa ký tự không an toàn. Chỉ dùng biến Moodle, số, toán tử + - * / ^ ( ), dấu phẩy và hàm Moodle được phép.';
        }
        return $errors;
    }

    public static function normalize_homework_questions(array $questions, array $options, int $limit = 0): array {
        // Phase debug: luôn đổ dữ liệu AI về JSON đã normalize, kể cả câu còn sai.
        // Không drop, không coerce, không tự sinh câu giả ở bước này; validator sẽ báo lỗi như cũ.
        $max = $limit > 0 ? max(1, min(60, $limit)) : 0;
        $out = [];
        foreach ($questions as $idx => $q) {
            if (!is_array($q)) {
                $q = ['type' => '', 'level' => '', 'name' => 'Câu ' . ($idx + 1), 'questiontext' => trim((string)$q)];
            }
            $q = self::normalize_question_shape($q);
            $q = self::normalize_moodle_var_latex_conflicts($q);
            if (!empty($q['da_nhieu']) && is_array($q['da_nhieu']) && count($q['da_nhieu']) > 2) {
                $q['da_nhieu'] = array_slice($q['da_nhieu'], 0, 2);
            }
            $q['type'] = self::normalize_qtype((string)($q['type'] ?? $q['qtype'] ?? ''));
            $q = self::normalize_calculated_question($q);
            // Giữ da_nhieu tách riêng trong JSON nháp/validator để AI ít sai và giáo viên dễ debug.
            // Chỉ chuyển da_nhieu sang cấu trúc Moodle ở bước ghi câu hỏi thật nếu cần.
            $q['level'] = self::normalize_level((string)($q['level'] ?? ''));
            $q['question_no'] = max(1, (int)($q['question_no'] ?? ($idx + 1)));
            unset($q['qtype'], $q['name']);
            if (isset($q['questiontext'])) {
                $q['questiontext'] = trim((string)$q['questiontext']);
            } else {
                $q['questiontext'] = '';
            }
            $q = self::normalize_question_images($q, $options);
            $out[] = $q;
            if ($max > 0 && count($out) >= $max) {
                break;
            }
        }
        return array_values($out);
    }
    protected static function quota_is_complete(array $questions, array $allowedtypes, array $allowedlevels, int $max): bool {
        $target = min($max, array_sum($allowedtypes), array_sum($allowedlevels));
        if (count($questions) !== $target) { return false; }
        $counts = self::quota_counts($questions);
        foreach ($allowedtypes as $type => $n) { if (($counts['types'][$type] ?? 0) !== (int)$n) { return false; } }
        foreach ($allowedlevels as $level => $n) { if (($counts['levels'][$level] ?? 0) !== (int)$n) { return false; } }
        return true;
    }

    protected static function repair_questions_for_quota(array $selected, array $candidates, array $allowedtypes, array $allowedlevels, int $max): array {
        $target = min($max, array_sum($allowedtypes), array_sum($allowedlevels));
        $pool = array_values(array_merge($candidates, $selected));
        if (!$pool) {
            $pool[] = ['type' => self::first_allowed_key($allowedtypes), 'level' => self::first_allowed_key($allowedlevels), 'questiontext' => 'Nêu một kiến thức chính của bài học.', 'answers' => [['text' => 'Học sinh trả lời theo nội dung bài học.', 'fraction' => 100]]];
        }
        $out = array_values($selected);
        $guard = 0;
        while (!self::quota_is_complete($out, $allowedtypes, $allowedlevels, $target) && count($out) < $target && $guard++ < 200) {
            $counts = self::quota_counts($out);
            $needtype = self::first_missing_key($allowedtypes, $counts['types']);
            $needlevel = self::first_missing_key($allowedlevels, $counts['levels']);
            if ($needtype === '') { $needtype = self::first_allowed_key($allowedtypes); }
            if ($needlevel === '') { $needlevel = self::first_allowed_key($allowedlevels); }
            $base = $pool[($guard - 1) % count($pool)];
            $q = self::coerce_question_to_type($base, $needtype, $needlevel, count($out) + 1);
            if (self::is_valid_by_type($q)) { $out[] = $q; }
        }
        for ($pass = 0; $pass < 100 && !self::quota_is_complete($out, $allowedtypes, $allowedlevels, $target); $pass++) {
            $counts = self::quota_counts($out);
            $needtype = self::first_missing_key($allowedtypes, $counts['types']);
            $needlevel = self::first_missing_key($allowedlevels, $counts['levels']);
            $replace = self::find_surplus_question_index($out, $allowedtypes, $allowedlevels);
            if ($replace === null || ($needtype === '' && $needlevel === '')) { break; }
            $type = $needtype !== '' ? $needtype : (string)$out[$replace]['type'];
            $level = $needlevel !== '' ? $needlevel : (string)$out[$replace]['level'];
            $out[$replace] = self::coerce_question_to_type($out[$replace], $type, $level, $replace + 1);
        }
        return array_values(array_slice($out, 0, $target));
    }

    protected static function quota_counts(array $questions): array {
        $types = [];
        $levels = [];
        foreach ($questions as $q) {
            $t = (string)($q['type'] ?? '');
            $l = (string)($q['level'] ?? '');
            $types[$t] = ($types[$t] ?? 0) + 1;
            $levels[$l] = ($levels[$l] ?? 0) + 1;
        }
        return ['types' => $types, 'levels' => $levels];
    }

    protected static function first_missing_key(array $required, array $used): string {
        foreach ($required as $key => $n) { if (($used[$key] ?? 0) < (int)$n) { return (string)$key; } }
        return '';
    }

    protected static function first_allowed_key(array $allowed): string {
        foreach ($allowed as $key => $n) { if ((int)$n > 0) { return (string)$key; } }
        return '';
    }

    protected static function find_surplus_question_index(array $questions, array $allowedtypes, array $allowedlevels): ?int {
        $counts = self::quota_counts($questions);
        foreach ($questions as $i => $q) {
            $t = (string)($q['type'] ?? '');
            $l = (string)($q['level'] ?? '');
            if (($counts['types'][$t] ?? 0) > ($allowedtypes[$t] ?? 0) || ($counts['levels'][$l] ?? 0) > ($allowedlevels[$l] ?? 0)) { return $i; }
        }
        return null;
    }

    protected static function coerce_question_to_type(array $q, string $type, string $level, int $no): array {
        $q = self::normalize_question_shape($q);
        $q['type'] = $type;
        $q['level'] = $level;
        $text = trim((string)($q['questiontext'] ?? ''));
        if ($text === '') { $text = 'Câu hỏi số ' . $no . ' theo nội dung bài học.'; }
        $answers = self::answer_texts($q);
        if ($type === 'matching') {
            $left1 = self::short_text($text, 80) ?: 'Khái niệm 1';
            $right1 = $answers[0] ?? 'Nội dung phù hợp 1';
            $left2 = $answers[1] ?? 'Khái niệm 2';
            $right2 = $answers[2] ?? ($answers[0] ?? 'Nội dung phù hợp 2');
            $q['questiontext'] = 'Ghép các nội dung tương ứng theo bài học.';
            $q['subquestions'] = [['question' => $left1, 'answer' => $right1], ['question' => $left2, 'answer' => $right2]];
            unset($q['answers'], $q['choices']);
            return $q;
        }
        if (in_array($type, ['gapselect', 'ddwtos'], true)) {
            $choice1 = $answers[0] ?? self::short_text($text, 50) ?: 'nội dung chính';
            $choice2 = $answers[1] ?? 'kiến thức';
            $clean = trim(preg_replace('/\s+/u', ' ', strip_tags($text)) ?: '');
            if ($clean === '') { $clean = 'Hoàn thành nội dung theo bài học'; }
            if (!preg_match('/\[\[\d+\]\]/', $clean)) { $clean = 'Hoàn thành câu sau: [[1]] là một nội dung quan trọng trong bài học.'; }
            $q['questiontext'] = $clean;
            $q['choices'] = [['group' => 1, 'text' => $choice1], ['group' => 1, 'text' => $choice2]];
            unset($q['answers'], $q['subquestions']);
            return $q;
        }
        if (in_array($type, ['multichoice', 'truefalse', 'shortanswer', 'numerical'], true)) {
            if ($type === 'truefalse') {
                $q['answers'] = [['text' => 'Đúng', 'fraction' => 100], ['text' => 'Sai', 'fraction' => 0]];
            } else if ($type === 'numerical') {
                $q['answers'] = [['text' => '1', 'fraction' => 100, 'tolerance' => 0]];
            } else if ($type === 'multichoice') {
                $q['answers'] = [['text' => $answers[0] ?? 'Đáp án đúng', 'fraction' => 100], ['text' => $answers[1] ?? 'Đáp án nhiễu 1', 'fraction' => 0], ['text' => $answers[2] ?? 'Đáp án nhiễu 2', 'fraction' => 0]];
            } else {
                $q['answers'] = [['text' => $answers[0] ?? 'Học sinh trả lời theo nội dung bài học.', 'fraction' => 100]];
            }
            $q['questiontext'] = $text;
            unset($q['choices'], $q['subquestions']);
            return $q;
        }
        if (in_array($type, ['calculated', 'calculatedsimple', 'calculatedmulti'], true)) {
            $q['questiontext'] = preg_match('/\{[a-zA-Z][a-zA-Z0-9_]*\}/', $text) ? $text : ($text . ' Tính giá trị khi chiều dài là {a} và chiều rộng là {b}.');
            $q['answers'] = [['text' => '{a}*{b}', 'fraction' => 100, 'tolerance' => 0]];
            unset($q['choices'], $q['subquestions']);
            return $q;
        }
        $q['questiontext'] = $text;
        return $q;
    }

    protected static function answer_texts(array $q): array {
        $out = [];
        foreach (($q['answers'] ?? []) as $a) {
            $txt = is_array($a) ? trim((string)($a['text'] ?? $a['answer'] ?? $a['value'] ?? '')) : trim((string)$a);
            if ($txt !== '') { $out[] = $txt; }
        }
        foreach (($q['choices'] ?? []) as $a) {
            if (is_array($a)) { $txt = trim((string)($a['text'] ?? $a['answer'] ?? $a['value'] ?? '')); if ($txt !== '') { $out[] = $txt; } }
        }
        foreach (($q['subquestions'] ?? []) as $a) {
            if (is_array($a)) {
                foreach (['question', 'answer', 'left', 'right', 'term', 'definition'] as $k) { $txt = trim((string)($a[$k] ?? '')); if ($txt !== '') { $out[] = $txt; } }
            }
        }
        return array_values(array_unique($out));
    }

    protected static function short_text(string $text, int $limit): string {
        $text = trim(preg_replace('/\s+/u', ' ', strip_tags($text)) ?: '');
        if (function_exists('mb_substr')) { return mb_substr($text, 0, $limit); }
        return substr($text, 0, $limit);
    }
    protected static function select_questions_for_quota(array $candidates, array $allowedtypes, array $allowedlevels, int $max): array {
        $target = min($max, array_sum($allowedtypes), array_sum($allowedlevels));
        $best = [];
        $usedtypes = [];
        $usedlevels = [];
        $remaining = $candidates;
        while (count($best) < $target && $remaining) {
            $bestpos = null;
            $bestscore = -999999;
            foreach ($remaining as $pos => $q) {
                $type = (string)$q['type'];
                $level = (string)$q['level'];
                if (($usedtypes[$type] ?? 0) >= ($allowedtypes[$type] ?? 0)) { continue; }
                if (($usedlevels[$level] ?? 0) >= ($allowedlevels[$level] ?? 0)) { continue; }
                $typeneed = ($allowedtypes[$type] ?? 0) - ($usedtypes[$type] ?? 0);
                $levelneed = ($allowedlevels[$level] ?? 0) - ($usedlevels[$level] ?? 0);
                $score = ($typeneed * 1000) + ($levelneed * 100) - (int)($q['_ai_index'] ?? 0);
                if ($score > $bestscore) { $bestscore = $score; $bestpos = $pos; }
            }
            if ($bestpos === null) { break; }
            $q = $remaining[$bestpos];
            unset($remaining[$bestpos]);
            $type = (string)$q['type'];
            $level = (string)$q['level'];
            $usedtypes[$type] = ($usedtypes[$type] ?? 0) + 1;
            $usedlevels[$level] = ($usedlevels[$level] ?? 0) + 1;
            unset($q['_ai_index']);
            $q['question_no'] = count($best) + 1; unset($q['name'], $q['qtype']);
            $best[] = $q;
        }
        return $best;
    }

    public static function validate_homework_against_plan(array $questions, array $options): array {
        if (!empty($options['_teacher_config']) && is_array($options['_teacher_config'])) {
            $tcopts = $options;
            foreach (['qtypes', 'cognitive', 'distractors', 'total'] as $k) {
                if (isset($options['_teacher_config'][$k])) { $tcopts[$k] = $options['_teacher_config'][$k]; }
            }
            $options = $tcopts;
        }
        $allowedtypes = self::active_qtype_counts($options);
        $allowedlevels = self::active_level_counts($options);
        $summary = ['qtypes' => [], 'levels' => []];
        foreach ($allowedtypes as $type => $count) { $summary['qtypes'][$type] = ['used' => 0, 'required' => (int)$count]; }
        foreach ($allowedlevels as $level => $count) { $summary['levels'][$level] = ['used' => 0, 'required' => (int)$count]; }
        $errors = [];
        foreach (array_values($questions) as $i => $q) {
            $no = $i + 1;
            if (!is_array($q)) { $errors[] = 'Câu ' . $no . ' không phải object JSON.'; continue; }
            $q = self::normalize_question_shape($q);
            $type = self::normalize_qtype((string)($q['type'] ?? ''));
            $level = self::normalize_level((string)($q['level'] ?? ''));
            if (empty($allowedtypes[$type])) { $errors[] = 'Câu ' . $no . ' type ' . ($type ?: '(trống)') . ' ngoài cấu hình.'; continue; }
            if (empty($allowedlevels[$level])) { $errors[] = 'Câu ' . $no . ' level ' . ($level ?: '(trống)') . ' ngoài cấu hình.'; continue; }
            $summary['qtypes'][$type]['used']++;
            $summary['levels'][$level]['used']++;
            if (!empty($options['_question_plan']) && is_array($options['_question_plan'])) {
                $plan = $options['_question_plan'][$i] ?? null;
                if (!is_array($plan)) {
                    $errors[] = 'QUESTION_PLAN thiếu dòng cho Câu ' . $no . '.';
                } else {
                    $ptype = self::normalize_qtype((string)($plan['type'] ?? ''));
                    $plevel = self::normalize_level((string)($plan['level'] ?? ''));
                    if ($ptype !== $type) { $errors[] = 'Câu ' . $no . ' type không khớp QUESTION_PLAN (' . $type . '/' . $ptype . ').'; }
                    if ($plevel !== $level) { $errors[] = 'Câu ' . $no . ' level không khớp QUESTION_PLAN (' . $level . '/' . $plevel . ').'; }
                }
            }
            foreach (self::type_validation_errors($q, $no) as $err) { $errors[] = $err; }
            foreach (self::distractor_validation_errors($q, $no, $options) as $err) { $errors[] = $err; }
            if (in_array($type, ['calculated','calculatedsimple','calculatedmulti'], true)) {
                $answer = '';
                foreach (($q['answers'] ?? []) as $a) { $answer .= ' ' . (is_array($a) ? (string)($a['text'] ?? '') : ''); }
                if (!preg_match('/\{[a-z]/i', (string)($q['questiontext'] ?? '')) || !preg_match('/\{[a-z]/i', $answer)) {
                    $errors[] = 'Câu ' . $no . ' thiếu biến {a}/{b}/{x} trong đề hoặc đáp án.';
                }
            }
        }
        if (!empty($options['_question_plan']) && is_array($options['_question_plan']) && count($options['_question_plan']) !== count($questions)) {
            $errors[] = 'QUESTION_PLAN sai số dòng (' . count($options['_question_plan']) . '/' . count($questions) . ').';
        }
        foreach ($summary['qtypes'] as $type => $v) {
            if ((int)$v['used'] !== (int)$v['required']) { $errors[] = 'Type ' . $type . ' sai số lượng (' . $v['used'] . '/' . $v['required'] . ').'; }
        }
        foreach ($summary['levels'] as $level => $v) {
            if ((int)$v['used'] !== (int)$v['required']) { $errors[] = 'Level ' . $level . ' sai số lượng (' . $v['used'] . '/' . $v['required'] . ').'; }
        }
        return ['ok' => empty($errors), 'errors' => $errors, 'summary' => $summary];
    }

    public static function questions_json(array $questions): string {
        return json_encode(['questions' => array_values($questions)], JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
    }

    protected static function validate_questions(array $questions, int $limit, array $options): array {
        $out = self::normalize_homework_questions($questions, $options, $limit);
        // Không ném lỗi mơ hồ ở đây nữa. Nếu chưa đủ quota, UI validator sẽ chỉ rõ
        // type/level/câu nào thiếu để giáo viên sửa JSON hoặc bấm tạo lại.
        return $out;
    }

    protected static function distractor_validation_errors(array $q, int $no, array $options): array {
        $type = (string)($q['type'] ?? '');
        $d = is_array($options['distractors'] ?? null) ? $options['distractors'] : [];
        if (empty($d[$type])) { return []; }
        if (!in_array($type, ['multichoice','matching','gapselect','ddwtos','ddimageortext','ddmarker'], true)) { return []; }
        if ($type === 'multichoice') {
            $wrong = 0;
            foreach (($q['answers'] ?? []) as $a) { if (is_array($a) && (float)($a['fraction'] ?? 0) <= 0) { $wrong++; } }
            return $wrong > 0 ? [] : ['Câu ' . $no . ' multichoice được bật nhiễu nhưng chưa có đáp án sai fraction=0.'];
        }
        $dn = is_array($q['da_nhieu'] ?? null) ? array_values($q['da_nhieu']) : [];
        $has = false;
        foreach ($dn as $x) {
            if (is_array($x)) {
                $txt = trim((string)($x['text'] ?? $x['answer'] ?? $x['label'] ?? $x['choice'] ?? $x['content'] ?? $x['id'] ?? ''));
                $hascoords = !empty($x['coords']) && is_array($x['coords']);
                $hasdz = !empty($x['drop_zone']) && is_array($x['drop_zone']);
                if ($txt !== '' || $hascoords || $hasdz) { $has = true; break; }
            } else if (trim((string)$x) !== '') {
                $has = true; break;
            }
        }
        return $has ? [] : ['Câu ' . $no . ' ' . $type . ' được bật nhiễu nhưng thiếu da_nhieu.'];
    }

    protected static function type_validation_errors(array $q, int $no): array {
        $type = (string)($q['type'] ?? '');
        $errors = [];
        if ($type === 'multichoice') {
            $answers = is_array($q['answers'] ?? null) ? array_values($q['answers']) : [];
            if (count($answers) < 3) { $errors[] = 'Câu ' . $no . ' multichoice cần tối thiểu 3 đáp án.'; }
            $sumcorrect = 0.0;
            $positive = 0;
            $wrong = 0;
            $seen = [];
            foreach ($answers as $i => $a) {
                if (!is_array($a)) { $errors[] = 'Câu ' . $no . ' multichoice answer #' . ($i + 1) . ' không hợp lệ.'; continue; }
                $txt = trim((string)($a['text'] ?? ''));
                if ($txt === '') { $errors[] = 'Câu ' . $no . ' multichoice answer #' . ($i + 1) . ' thiếu text.'; }
                $key = mb_strtolower(preg_replace('/\s+/u', ' ', $txt));
                if ($key !== '') {
                    if (isset($seen[$key])) { $errors[] = 'Câu ' . $no . ' multichoice có đáp án trùng: ' . $txt; }
                    $seen[$key] = true;
                }
                $fraction = (float)($a['fraction'] ?? 0);
                if ($fraction < 0 || $fraction > 100) { $errors[] = 'Câu ' . $no . ' multichoice fraction phải nằm trong 0..100.'; }
                if ($fraction > 0) { $positive++; $sumcorrect += $fraction; } else { $wrong++; }
            }
            if ($positive < 1) { $errors[] = 'Câu ' . $no . ' multichoice cần ít nhất 1 đáp án đúng fraction > 0.'; }
            if (abs($sumcorrect - 100.0) > 0.01) { $errors[] = 'Câu ' . $no . ' multichoice tổng fraction đáp án đúng phải bằng 100, hiện là ' . $sumcorrect . '.'; }
            if ($wrong < 1) { $errors[] = 'Câu ' . $no . ' multichoice cần ít nhất 1 đáp án sai fraction=0.'; }
            return $errors;
        }
        if ($type === 'matching') {
            $subs = is_array($q['subquestions'] ?? null) ? array_values($q['subquestions']) : [];
            $answers = [];
            $realpairs = 0;
            foreach ($subs as $i => $sq) {
                $left = is_array($sq) ? trim((string)($sq['question'] ?? '')) : '';
                $right = is_array($sq) ? trim((string)($sq['answer'] ?? '')) : '';
                $isdistractor = !empty($sq['distractor']) || ($left === '' && $right !== '');
                if (!$isdistractor && ($left === '' || $right === '')) {
                    $errors[] = 'Câu ' . $no . ' matching cặp #' . ($i + 1) . ' thiếu question hoặc answer.';
                }
                if ($left !== '' && $right !== '') { $realpairs++; }
                if ($right !== '') {
                    // Matching được phép có nhiều vế trái cùng một đáp án đúng.
                    // Backend sẽ gom/xử lý khi đưa vào Moodle; không fail validator vì trùng answer.
                    $key = mb_strtolower($right);
                    $answers[$key] = true;
                }
            }
            if ($realpairs < 2) {
                $errors[] = 'Câu ' . $no . ' matching cần tối thiểu 2 cặp question/answer thật; nhiễu không được tính là cặp đúng.';
            }
            return $errors;
        }
        if (in_array($type, ['gapselect', 'ddwtos'], true)) {
            $text = (string)($q['questiontext'] ?? '');
            preg_match_all('/\[\[(\d+)\]\]/', $text, $m);
            $blanks = array_values(array_unique($m[1] ?? []));
            $choices = is_array($q['choices'] ?? null) ? array_values($q['choices']) : [];
            if (!$blanks) {
                $errors[] = 'Câu ' . $no . ' ' . $type . ' cần questiontext có [[1]], [[2]]...';
            }
            if (!$choices) {
                $errors[] = 'Câu ' . $no . ' ' . $type . ' thiếu choices.';
            }
            foreach ($choices as $i => $choice) {
                $ctext = is_array($choice) ? trim((string)($choice['text'] ?? '')) : '';
                if ($ctext === '') {
                    $errors[] = 'Câu ' . $no . ' ' . $type . ' choice #' . ($i + 1) . ' thiếu text.';
                }
            }
            if ($blanks && $choices && count($choices) < count($blanks)) {
                $errors[] = 'Câu ' . $no . ' ' . $type . ' số choices ít hơn số chỗ trống (' . count($choices) . '/' . count($blanks) . ').';
            }
            return $errors;
        }
        if (in_array($type, ['calculated','calculatedsimple','calculatedmulti'], true)) {
            $q = self::normalize_calculated_question($q);
            $answers = is_array($q['answers'] ?? null) ? array_values($q['answers']) : [];
            if (!$answers) { return ['Câu ' . $no . ' calculated thiếu answers.']; }
            $cerrs = [];
            $questiontext = (string)($q['questiontext'] ?? '');
            if (!preg_match('/\{[a-zA-Z][a-zA-Z0-9_]*\}/', $questiontext)) {
                $cerrs[] = 'Câu ' . $no . ' calculated thiếu biến trong questiontext.';
            }
            $positive = 0; $wrong = 0;
            foreach ($answers as $ai => $a) {
                $formula = self::normalize_formula_text((string)($a['text'] ?? ''));
                foreach (self::formula_validation_errors($formula, $no, 'answer #' . ($ai + 1)) as $err) { $cerrs[] = $err; }
                $fraction = (float)($a['fraction'] ?? 0);
                if ($fraction > 0) { $positive++; } else { $wrong++; }
            }
            if ($type === 'calculatedmulti') {
                if (count($answers) < 3) { $cerrs[] = 'Câu ' . $no . ' calculatedmulti cần tối thiểu 3 đáp án.'; }
                if ($positive !== 1) { $cerrs[] = 'Câu ' . $no . ' calculatedmulti cần đúng 1 đáp án fraction=100.'; }
                if ($wrong < 2) { $cerrs[] = 'Câu ' . $no . ' calculatedmulti cần tối thiểu 2 đáp án nhiễu fraction=0.'; }
            }
            foreach (($q['vars'] ?? []) as $vname => $vdef) {
                if (!is_array($vdef)) { $cerrs[] = 'Câu ' . $no . ' biến {' . $vname . '} thiếu min/max.'; continue; }
                if ((float)($vdef['max'] ?? 0) <= (float)($vdef['min'] ?? 0)) { $cerrs[] = 'Câu ' . $no . ' biến {' . $vname . '} có max <= min.'; }
            }
            return $cerrs;
        }
        if (in_array($type, ['ddimageortext','ddmarker'], true)) {
            $errs = [];
            $encodedq = json_encode($q);
            if (stripos((string)$encodedq, 'base64') !== false || stripos((string)$encodedq, 'data:image') !== false || stripos((string)$encodedq, 'image_data') !== false) {
                $errs[] = 'Câu ' . $no . ' IMG không được chứa base64/data:image/image_data.';
            }
            $text = (string)($q['questiontext'] ?? '');
            $images = is_array($q['images'] ?? null) ? $q['images'] : [];
            if (strpos($text, '[IMG') !== false && !$images) {
                $errs[] = 'Câu ' . $no . ' có marker IMG nhưng thiếu metadata images.';
            }
            foreach ($images as $id => $meta) {
                if (!is_array($meta)) { $errs[] = 'Câu ' . $no . ' images.' . $id . ' không hợp lệ.'; continue; }
                $source = trim((string)($meta['source'] ?? 'sgk'));
                $box = self::normalize_img_box($meta['source_box'] ?? ($meta['box'] ?? []));
                if ($source === '') { $errs[] = 'Câu ' . $no . ' IMG ' . $id . ' thiếu source.'; }
                if (preg_match('#example\.com|placeholder#i', $source)) { $errs[] = 'Câu ' . $no . ' IMG ' . $id . ' dùng URL giả/placeholder.'; }
                if (strtolower($source) !== 'sgk' && strtolower($source) !== 'box' && !preg_match('#^https?://#i', $source)) { $errs[] = 'Câu ' . $no . ' IMG ' . $id . ' source ảnh ngoài phải là URL http/https, sgk hoặc box.'; }
                if (count($box) !== 4) { $errs[] = 'Câu ' . $no . ' IMG ' . $id . ' thiếu source_box [xmin,ymin,xmax,ymax].'; }
                if (count($box) === 4 && ($box[2] <= $box[0] || $box[3] <= $box[1])) { $errs[] = 'Câu ' . $no . ' IMG ' . $id . ' source_box không hợp lệ.'; }
            }
            $items = is_array($q['items'] ?? null) ? array_values($q['items']) : [];
            $okzones = 0;
            foreach ($items as $it) { if (is_array($it) && is_array($it['drop_zone'] ?? null)) { $okzones++; } }
            $bgcanvas = ['w' => 0, 'h' => 0];
            // canvas_size là metadata backend, không bắt AI trả. Nếu không có thì chỉ validate hình dạng drop_zone.
            foreach ($images as $imeta) {
                if (!is_array($imeta)) { continue; }
                $bgcanvas = self::normalize_img_size($imeta['canvas_size'] ?? '');
                if (($bgcanvas['w'] ?? 0) > 0 && ($bgcanvas['h'] ?? 0) > 0) { break; }
            }
            $zones = [];
            foreach ($items as $it) {
                if (!is_array($it) || !is_array($it['drop_zone'] ?? null)) { continue; }
                $dz = $it['drop_zone'];
                $z = [
                    'left' => (int)($dz['left'] ?? $dz['x'] ?? 0),
                    'top' => (int)($dz['top'] ?? $dz['y'] ?? 0),
                    'width' => (int)($dz['width'] ?? $dz['w'] ?? 0),
                    'height' => (int)($dz['height'] ?? $dz['h'] ?? 0),
                    'id' => (string)($it['id'] ?? ''),
                ];
                if ($z['width'] <= 0 || $z['height'] <= 0) { $errs[] = 'Câu ' . $no . ' drop_zone của item ' . $z['id'] . ' thiếu width/height.'; }
                if (($bgcanvas['w'] ?? 0) > 0 && ($bgcanvas['h'] ?? 0) > 0) {
                    if ($z['left'] < 0 || $z['top'] < 0 || $z['left'] + $z['width'] > $bgcanvas['w'] || $z['top'] + $z['height'] > $bgcanvas['h']) { $errs[] = 'Câu ' . $no . ' drop_zone của item ' . $z['id'] . ' vượt canvas_size backend.'; }
                }
                foreach ($zones as $old) {
                    $ix = max(0, min($z['left'] + $z['width'], $old['left'] + $old['width']) - max($z['left'], $old['left']));
                    $iy = max(0, min($z['top'] + $z['height'], $old['top'] + $old['height']) - max($z['top'], $old['top']));
                    $ia = $ix * $iy;
                    $ma = min(max(1, $z['width'] * $z['height']), max(1, $old['width'] * $old['height']));
                    if ($ia > 0 && ($ia / $ma) > 0.60) { $errs[] = 'Câu ' . $no . ' drop_zone của item ' . $z['id'] . ' chồng lấn quá nhiều với item ' . $old['id'] . '.'; }
                }
                $zones[] = $z;
            }
            if ($type === 'ddimageortext' && $okzones < 1) { $errs[] = 'Câu ' . $no . ' ddimageortext cần ít nhất 1 item có drop_zone.'; }
            return $errs;
        }
        return self::is_valid_by_type($q) ? [] : [self::type_validation_error($q, $no)];
    }
    protected static function type_validation_error(array $q, int $no): string {
        $type = (string)($q['type'] ?? '');
        if ($type === 'matching') {
            return 'Câu ' . $no . ' matching cần tối thiểu 2 cặp subquestions question/answer.';
        }
        if (in_array($type, ['gapselect', 'ddwtos'], true)) {
            return 'Câu ' . $no . ' ' . $type . ' cần questiontext có [[1]] và choices hợp lệ.';
        }
        if (in_array($type, ['calculated','calculatedsimple','calculatedmulti'], true)) {
            return 'Câu ' . $no . ' calculated cần biến {a}/{b}/{x} trong đề và công thức đáp án.';
        }
        return 'Câu ' . $no . ' thiếu dữ liệu bắt buộc cho type ' . $type . '.';
    }

    protected static function is_valid_by_type(array $q): bool {
        $type = (string)$q['type'];

        if (in_array($type, ['calculated', 'calculatedsimple', 'calculatedmulti'], true)) {
            if (empty($q['answers']) || !is_array($q['answers'])) {
                return false;
            }
            $questiontext = (string)($q['questiontext'] ?? '');
            $hasquestionvar = (bool)preg_match('/\{[a-zA-Z][a-zA-Z0-9_]*\}/', $questiontext);
            $hasanswervar = false;
            $sum = 0;
            foreach ($q['answers'] as $a) {
                if (!is_array($a) || trim((string)($a['text'] ?? '')) === '') {
                    return false;
                }
                $answertext = (string)$a['text'];
                if (preg_match('/\{[a-zA-Z][a-zA-Z0-9_]*\}/', $answertext)) {
                    $hasanswervar = true;
                }
                $sum += (float)($a['fraction'] ?? 0);
            }
            return $sum > 0 && $hasquestionvar && $hasanswervar;
        }

        if (in_array($type, ['multichoice', 'truefalse', 'shortanswer', 'numerical'], true)) {
            if (empty($q['answers']) || !is_array($q['answers'])) {
                return false;
            }
            $sum = 0.0;
            $positive = 0;
            foreach ($q['answers'] as $a) {
                if (!is_array($a) || trim((string)($a['text'] ?? '')) === '') {
                    return false;
                }
                $fraction = (float)($a['fraction'] ?? 0);
                if ($fraction > 0) { $positive++; $sum += $fraction; }
            }
            if ($type === 'multichoice') { return count($q['answers']) >= 3 && $positive >= 1 && abs($sum - 100.0) <= 0.01; }
            return $sum > 0;
        }
        if ($type === 'matching') {
            if (empty($q['subquestions']) || !is_array($q['subquestions'])) { return false; }
            $realpairs = 0;
            foreach ($q['subquestions'] as $sq) {
                if (!is_array($sq)) { return false; }
                $left = trim((string)($sq['question'] ?? ''));
                $right = trim((string)($sq['answer'] ?? ''));
                if ($left !== '' && $right !== '') { $realpairs++; }
                if ($left === '' && $right === '') { return false; }
            }
            return $realpairs >= 2;
        }
        if (in_array($type, ['gapselect', 'ddwtos'], true)) {
            return !empty($q['choices']) && is_array($q['choices']) && preg_match('/\[\[\d+\]\]/', (string)$q['questiontext']);
        }
        return true;
    }
}
