<?php
namespace local_aisgk\local;

defined('MOODLE_INTERNAL') || die();

use local_aisgk\ai_key_manager;

class ai_service {
    protected static function user_prefers_personal_key(int $userid): bool {
        return $userid > 0 && (bool)get_user_preferences('local_aisgk_use_my_api', 0, $userid);
    }

    public static function extract_toc_from_images(array $images, int $userid = 0): array {
        $prompt = 'Trích xuất dữ liệu từ bảng mục lục trong ảnh. Kết quả chỉ xuất JSON hợp lệ dạng {"rows":[{"sobai":"","tenbai":"","trang":""}]}. Giữ nguyên thứ tự, chỉ lấy dòng mục lục thực sự và số trang.';
        $result = self::call('scan', $userid, self::user_prefers_personal_key($userid), $prompt, $images, true);
        $result['rows'] = self::extract_rows(self::response_text($result['response'], $result['provider']));
        unset($result['response']);
        return $result;
    }

    public static function generate_homework_questions(string $topicname, string $text, array $formula, int $userid = 0, array $options = []): array {
        $total = self::safe_total($options);
        $prompt = self::build_homework_prompt($topicname, '', 0, 0, $total, $options)
            . "\n\nNội dung bài học dạng văn bản:\n" . mb_substr($text, 0, 18000);
        $result = self::call('homework', $userid, self::user_prefers_personal_key($userid), $prompt, [], true);
        $raw = self::response_text($result['response'], $result['provider']);
        $result['rawtext'] = $raw;
        $result['questions'] = self::extract_questions($raw, $total, $options);
        $result['normalizedjson'] = self::questions_json($result['questions']);
        unset($result['response']);
        return $result;
    }

    public static function generate_homework_questions_from_images(
        string $topicname,
        array $images,
        int $pagefrom,
        int $pageto,
        int $userid = 0,
        array $options = [],
        string $bookname = ''
    ): array {
        $total = self::safe_total($options);
        $prompt = self::build_homework_prompt($topicname, $bookname, $pagefrom, $pageto, $total, $options);
        $result = self::call('homework', $userid, self::user_prefers_personal_key($userid), $prompt, $images, true);
        $raw = self::response_text($result['response'], $result['provider']);
        $result['rawtext'] = $raw;
        $result['questions'] = self::extract_questions($raw, $total, $options);
        $result['normalizedjson'] = self::questions_json($result['questions']);
        unset($result['response']);
        return $result;
    }

    protected static function safe_total(array $options): int {
        $total = (int)($options['total'] ?? 0);
        if ($total <= 0 && !empty($options['qtypes']) && is_array($options['qtypes'])) {
            $total = array_sum(array_map('intval', $options['qtypes']));
        }
        if ($total <= 0 && !empty($options['cognitive']) && is_array($options['cognitive'])) {
            $total = array_sum(array_map('intval', $options['cognitive']));
        }
        return max(1, min(60, $total ?: 8));
    }

    protected static function build_homework_prompt(string $topicname, string $bookname, int $pagefrom, int $pageto, int $total, array $options): string {
        $source = $bookname !== '' ? "- Sách/SGK: {$bookname}\n" : '';
        $pages = ($pagefrom > 0 && $pageto >= $pagefrom) ? "- Trang: {$pagefrom} → {$pageto}\n" : '';
        $configjson = json_encode($options, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
        $schema = self::active_schema_text($options);
        $allowedtypes = implode(', ', array_keys(self::active_qtype_counts($options)));
        $allowedlevels = implode(', ', array_keys(self::active_level_counts($options)));

        return "Bạn là giáo viên THCS tại Việt Nam.\n\n"
            . "Nhiệm vụ: tạo bài tập về nhà từ nội dung SGK trong ảnh/nội dung được cung cấp.\n\n"
            . "Nguồn:\n{$source}"
            . "- Tên bài/chủ đề: {$topicname}\n"
            . $pages
            . "QUESTION_PLAN BẮT BUỘC:\n"
            . "- JSON trả về phải có QUESTION_PLAN: từng câu, từng type, từng level.\n"
            . "- QUESTION_PLAN phải khớp 100% quota type/level; questions[i] đi đúng plan[i].\n\n"
            . "- Số câu cần tạo chính xác: {$total}\n\n"
            . "Cấu hình giáo viên gửi lên:\n{$configjson}\n\n"
            . "Yêu cầu nội dung:\n"
            . "- Đọc hiểu trực tiếp nội dung SGK; không suy diễn ngoài SGK.\n"
            . "- Hãy chú trọng đọc phần Mục tiêu bài học / Yêu cầu cần đạt nếu có. Phần này thường nằm trong khung màu, có biểu tượng mục tiêu, hoặc bắt đầu bằng các cụm như 'Sau bài học này em sẽ...', 'Yêu cầu cần đạt', 'Học xong bài này em có thể...'.\n"
            . "- Phần mục tiêu thường nằm ngay dưới tên bài, ở sidebar, hoặc trong khoảng 10 dòng đầu của trang đầu tiên của bài học.\n"
            . "- Chỉ tạo câu hỏi bám sát các năng lực, kiến thức và yêu cầu được nêu trong phần mục tiêu/yêu cầu cần đạt.\n"
            . "- Ưu tiên tham khảo phần bài tập/câu hỏi cuối bài nếu có, vì đây thường là hệ thống câu hỏi tác giả SGK đã định hướng.\n"
            . "- Bỏ qua header, footer, số trang, mục lục, watermark và rác quét.\n"
            . "- Level chỉ được viết nhan_biet / thong_hieu / van_dung. CẤM recognize / understand / apply trong JSON trả về.\n"
            . "- Ngôn ngữ câu hỏi phải phù hợp với ngôn ngữ nội dung bài học trong SGK.\n\n"
            . "RÀNG BUỘC BẮT BUỘC THEO CẤU HÌNH:\n"
            . "- CHỈ được dùng các type sau: {$allowedtypes}.\n"
            . "- CHỈ được dùng các level sau: {$allowedlevels}.\n"
            . "- Tuyệt đối không tạo type có số lượng = 0, không có trong options.qtypes, hoặc không được giáo viên chọn.\n"
            . "- Tuyệt đối không tạo level có số lượng = 0 hoặc không được giáo viên chọn.\n"
            . "- Số câu theo từng type phải đúng với số lượng trong options.qtypes. Type nào = 1 thì chỉ tạo đúng 1 câu type đó.\n"
            . "- Số câu theo từng level phải đúng với số lượng trong options.cognitive.\n"
            . "- name chỉ dùng dạng 'Câu 1', 'Câu 2'... Không thêm tên bài vào name.\n"
            . "- Nếu nội dung SGK không đủ thông tin cho một type được chọn, vẫn chỉ được dùng các type trong danh sách được phép; không tự ý đổi sang type khác.\n\n"
            . "CÔNG THỨC / KÝ HIỆU TOÁN, LÝ, HÓA:\n"
            . "- Nếu có công thức hoặc ký hiệu cần render, phải viết bằng LaTeX inline dạng \\( ... \\) hoặc block dạng \\[ ... \\].\n"
            . "- Vì đây là JSON, mọi dấu gạch chéo ngược trong công thức phải escape thành \\\\. Ví dụ viết \"\\\\(S = a \\\\times b\\\\)\" chứ không viết \"\\(S = a \\times b\\)\".\n"
            . "- Không dùng công thức dạng ảnh, không dùng HTML math tự chế, không dùng ký tự lạ làm hỏng JSON.\n\n"
            . "Chỉ trả JSON hợp lệ, không markdown, không giải thích, không thêm text ngoài JSON.\n"
            . "Tổng số phần tử trong questions phải đúng bằng {$total}. Nếu không thể đảm bảo JSON hợp lệ thì trả đúng: {\"questions\":[]}.\n\n"
            . "Cấu trúc chung bắt buộc:\n"
            . "{\"QUESTION_PLAN\":[{\"question_no\":1,\"type\":\"<theo options.qtypes>\",\"level\":\"nhan_biet|thong_hieu|van_dung\"}],\"questions\":[{\"type\":\"<theo options.qtypes>\",\"level\":\"<theo options.cognitive>\",\"name\":\"Câu 1\",\"questiontext\":\"...\"}]}\n\n"
            . "DANH SÁCH TYPE ĐƯỢC PHÉP VÀ SCHEMA TƯƠNG ỨNG, CHỈ DÙNG CÁC TYPE DƯỚI ĐÂY:\n"
            . $schema;
    }

    protected static function active_schema_text(array $options): string {
        $schemas = [
            'multichoice' => '- multichoice: có answers, mỗi phần tử {"text":"...","fraction":100 hoặc 0}; tổng fraction đáp án đúng bằng 100; nên có ít nhất 3 đáp án.',
            'truefalse' => '- truefalse: có answers gồm Đúng và Sai; một đáp án fraction 100, đáp án còn lại 0.',
            'shortanswer' => '- shortanswer: có answers [{"text":"đáp án ngắn","fraction":100}].',
            'numerical' => '- numerical: có answers [{"text":"giá trị số","fraction":100,"tolerance":0}].',
            'matching' => '- matching: có subquestions [{"question":"...","answer":"..."}], tối thiểu 2 cặp.',
            'essay' => '- essay: chỉ cần questiontext; có thể thêm responseformat nếu biết.',
            'gapselect' => '- gapselect: questiontext phải có chỗ trống dạng [[1]], [[2]] và có choices [{"group":1,"text":"..."}].',
            'ddwtos' => '- ddwtos: questiontext phải có chỗ trống dạng [[1]], [[2]] và có choices [{"group":1,"text":"..."}].',
            'calculated' => '- calculated: BẮT BUỘC questiontext chứa biến Moodle như {a}, {b}, {x}; answers[0].text phải là công thức có biến như "{a}*{b}". KHÔNG dùng số cụ thể. Không dùng đáp án số tĩnh.',
            'calculatedsimple' => '- calculatedsimple: BẮT BUỘC questiontext chứa biến Moodle như {a}, {b}, {x}; answers[0].text phải là công thức có biến như "{a}*{b}". KHÔNG dùng số cụ thể. Không dùng đáp án số tĩnh.',
            'calculatedmulti' => '- calculatedmulti: BẮT BUỘC questiontext chứa biến Moodle như {a}, {b}, {x}; answers phải là công thức có biến như "{a}*{b}". KHÔNG dùng số cụ thể. Không dùng đáp án số tĩnh.',
            'description' => '- description: nội dung mô tả không tính điểm, chỉ dùng khi giáo viên chọn.',
            'ddimageortext' => '- ddimageortext: chỉ dùng nếu có thể mô tả kéo thả bằng text; tránh yêu cầu tọa độ ảnh phức tạp.',
            'ddmarker' => '- ddmarker: chỉ dùng nếu có thể mô tả marker rõ ràng; tránh yêu cầu tọa độ ảnh phức tạp.',
            'random' => '- random: không tạo nội dung câu hỏi cụ thể; chỉ dùng nếu giáo viên chọn rõ.',
        ];
        $active = self::active_qtype_counts($options);
        $lines = [];
        foreach ($active as $type => $count) {
            if (isset($schemas[$type])) {
                $lines[] = $schemas[$type] . ' Số lượng bắt buộc: ' . $count . '.';
            }
        }
        return $lines ? implode("\n", $lines) . "\n" : "- shortanswer: có answers [{\"text\":\"đáp án\",\"fraction\":100}].\n";
    }

    protected static function active_qtype_counts(array $options): array {
        $qtypes = [];
        if (!empty($options['qtypes']) && is_array($options['qtypes'])) {
            foreach ($options['qtypes'] as $type => $count) {
                $type = trim((string)$type);
                $count = (int)$count;
                if ($type !== '' && $count > 0) {
                    $qtypes[$type] = $count;
                }
            }
        }
        if (!$qtypes) {
            $qtypes['shortanswer'] = self::safe_total($options);
        }
        return $qtypes;
    }

    protected static function active_level_counts(array $options): array {
        $map = ['recognize' => 'nhan_biet', 'understand' => 'thong_hieu', 'apply' => 'van_dung'];
        $levels = [];
        if (!empty($options['cognitive']) && is_array($options['cognitive'])) {
            foreach ($options['cognitive'] as $level => $count) {
                $level = $map[$level] ?? trim((string)$level);
                $count = (int)$count;
                if ($level !== '' && $count > 0) {
                    $levels[$level] = $count;
                }
            }
        }
        if (!$levels) {
            $levels['nhan_biet'] = self::safe_total($options);
        }
        return $levels;
    }

    protected static function call(string $feature, int $userid, bool $preferuser, string $prompt, array $images, bool $jsonmode): array {
        $attempted = [];
        $last = '';
        for ($try = 0; $try < 30; $try++) {
            $key = ai_key_manager::get_available_key($feature, $attempted, $userid, $preferuser, 0);
            if (!$key) { break; }
            $attempted[] = (string)($key->_source_table ?? 'local_aisgk_ai_keys') . ':' . (int)$key->id;
            $provider = ai_key_manager::provider_for_key($key);
            foreach (ai_key_manager::model_attempts_for_key($key, $feature) as $model) {
                $callkey = clone $key;
                if ($feature === 'homework') { $callkey->model_homework = $model; } else { $callkey->model_scan = $model; }
                try {
                    $payload = self::build_payload($provider, $model, $prompt, $images, $jsonmode);
                    $tokens = self::count_tokens($callkey, $provider, $model, $payload);
                    if (!ai_key_manager::can_use_key($callkey, $tokens)) {
                        $last = 'Key vượt giới hạn RPM/RPD/TPM';
                        continue;
                    }
                    $response = self::execute($callkey, $provider, $model, $payload);
                    $usage = ai_key_manager::mark_success($callkey, $tokens, $model);
                    return ['provider'=>$provider,'model'=>$model,'tokens'=>$tokens,'usage'=>$usage,'keysource'=>(string)($callkey->_source_table ?? 'system'),'category'=>(string)($callkey->category_key ?? 'free'),'response'=>$response];
                } catch (\Throwable $e) {
                    $last = $e->getMessage();
                    if (preg_match('/invalid api key|api key not valid|forbidden|permission denied|401|403|unauthorized/i', $last)) { ai_key_manager::mark_blocked($key, $last); break; }
                    if (preg_match('/429|rate limit|resource exhausted|quota|too many requests/i', $last)) { ai_key_manager::mark_429($key); break; }
                    ai_key_manager::mark_error($key, $last);
                }
            }
        }
        throw new \moodle_exception('errorprocessingbook', 'local_aisgk', '', 'Không có API key khả dụng hoặc key đang cooldown/bị lỗi. Lỗi cuối: ' . $last);
    }

    protected static function build_payload(string $provider, string $model, string $prompt, array $images, bool $jsonmode): array {
        if ($provider === 'shopaikey') {
            $content = [['type'=>'text','text'=>$prompt]];
            foreach ($images as $image) {
                $url = self::image_data_url($image);
                if ($url !== '') { $content[] = ['type'=>'image_url','image_url'=>['url'=>$url]]; }
            }
            $payload = ['model'=>$model,'messages'=>[['role'=>'user','content'=>$content]],'temperature'=>0.05,'max_tokens'=>12000];
            if ($jsonmode) { $payload['response_format'] = ['type'=>'json_object']; }
            return $payload;
        }
        $parts = [['text'=>$prompt]];
        foreach ($images as $image) {
            $inline = self::inline_image($image);
            if ($inline) { $parts[] = ['inlineData'=>$inline]; }
        }
        $payload = ['contents'=>[['parts'=>$parts]],'generationConfig'=>['temperature'=>0.05,'maxOutputTokens'=>12000]];
        if ($jsonmode) { $payload['generationConfig']['responseMimeType'] = 'application/json'; }
        return $payload;
    }

    protected static function execute(\stdClass $key, string $provider, string $model, array $payload): array {
        $apikey = trim((string)($key->api_key ?? ''));
        if ($apikey === '') { throw new \moodle_exception('errorprocessingbook', 'local_aisgk', '', 'API key rỗng.'); }
        if ($provider === 'shopaikey') {
            $url = 'https://api.shopaikey.com/v1/chat/completions';
            $headers = ['Content-Type: application/json', 'Authorization: Bearer ' . $apikey];
        } else {
            $url = 'https://generativelanguage.googleapis.com/v1beta/models/' . rawurlencode($model) . ':generateContent';
            $headers = ['Content-Type: application/json', 'X-goog-api-key: ' . $apikey];
        }
        $ch = curl_init($url);
        curl_setopt_array($ch, [CURLOPT_RETURNTRANSFER=>true,CURLOPT_POST=>true,CURLOPT_HTTPHEADER=>$headers,CURLOPT_POSTFIELDS=>json_encode($payload, JSON_UNESCAPED_UNICODE|JSON_UNESCAPED_SLASHES),CURLOPT_TIMEOUT=>180,CURLOPT_CONNECTTIMEOUT=>15]);
        $response = curl_exec($ch);
        $errno = curl_errno($ch);
        $error = curl_error($ch);
        $http = (int)curl_getinfo($ch, CURLINFO_RESPONSE_CODE);
        curl_close($ch);
        if ($errno) { throw new \moodle_exception('errorprocessingbook', 'local_aisgk', '', 'Lỗi kết nối API: ' . $error); }
        $json = json_decode((string)$response, true);
        if (!is_array($json)) { throw new \moodle_exception('errorprocessingbook', 'local_aisgk', '', 'API trả dữ liệu không hợp lệ: ' . mb_substr((string)$response,0,1000)); }
        if ($http >= 400 || !empty($json['error'])) {
            $err = $json['error'] ?? [];
            $msg = is_array($err) ? (string)($err['message'] ?? ('HTTP '.$http)) : (string)$err;
            throw new \moodle_exception('errorprocessingbook', 'local_aisgk', '', 'API_ERROR: ' . $msg);
        }
        return $json;
    }

    protected static function count_tokens(\stdClass $key, string $provider, string $model, array $payload): int {
        $total = 0;
        foreach (($payload['contents'] ?? []) as $content) {
            foreach (($content['parts'] ?? []) as $part) {
                if (!empty($part['text'])) { $total += (int)ceil(mb_strlen($part['text'], 'UTF-8') / 3); }
                if (!empty($part['inlineData']['data'])) {
                    $imgdata = base64_decode($part['inlineData']['data'], true);
                    if ($imgdata !== false) {
                        $info = @getimagesizefromstring($imgdata);
                        if ($info && !empty($info[0]) && !empty($info[1])) {
                            $w = (int)$info[0];
                            $h = (int)$info[1];
                            $total += ($w <= 384 && $h <= 384) ? 258 : (max(1, (int)ceil($w / 768)) * max(1, (int)ceil($h / 768)) * 258);
                        } else { $total += 2500; }
                    } else { $total += 2500; }
                }
            }
        }
        if ($total <= 0) {
            $raw = json_encode($payload, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
            $total = (int)ceil(strlen($raw) / 4);
        }
        return max(1, (int)$total);
    }

    protected static function inline_image(string $image): ?array {
        $data = @file_get_contents($image);
        if (!$data) { return null; }
        $ext = strtolower(pathinfo($image, PATHINFO_EXTENSION));
        $mime = ($ext === 'jpg' || $ext === 'jpeg') ? 'image/jpeg' : (($ext === 'webp') ? 'image/webp' : 'image/png');
        return ['mimeType'=>$mime,'data'=>base64_encode($data)];
    }

    protected static function image_data_url(string $image): string {
        $i = self::inline_image($image);
        return $i ? ('data:' . $i['mimeType'] . ';base64,' . $i['data']) : '';
    }

    protected static function response_text(array $json, string $provider): string {
        if ($provider === 'shopaikey') {
            $c = $json['choices'][0]['message']['content'] ?? '';
            if (is_array($c)) { return implode("\n", array_map(fn($p)=>(string)($p['text'] ?? ''), $c)); }
            return (string)$c;
        }
        $text = '';
        foreach (($json['candidates'] ?? []) as $cand) {
            foreach (($cand['content']['parts'] ?? []) as $p) {
                if (!empty($p['text'])) { $text .= $p['text']; }
            }
        }
        return $text;
    }

    protected static function decode_json_text(string $text, string $label): array {
        $clean = trim($text);
        $clean = preg_replace('/^```(?:json)?\s*/i', '', $clean);
        $clean = preg_replace('/\s*```$/', '', $clean);
        $json = json_decode($clean, true);
        if (!is_array($json)) {
            $start = strpos($clean, '{');
            $end = strrpos($clean, '}');
            if ($start !== false && $end !== false && $end > $start) {
                $slice = substr($clean, $start, $end - $start + 1);
                $json = json_decode($slice, true);
            }
        }
        if (!is_array($json)) {
            $err = json_last_error_msg();
            throw new \moodle_exception('errorprocessingbook', 'local_aisgk', '', $label . ': ' . $err . '. AI có thể đã trả JSON bị cắt ngang hoặc có dấu gạch chéo công thức chưa escape. Đoạn đầu: ' . mb_substr($text, 0, 1200));
        }
        return $json;
    }

    protected static function extract_rows(string $text): array {
        $json = self::decode_json_text($text, 'Không phân tích được JSON AI trả về');
        $rows = $json['rows'] ?? $json;
        if (!is_array($rows)) { throw new \moodle_exception('errorprocessingbook','local_aisgk','','JSON AI không có rows.'); }
        return $rows;
    }

    protected static function extract_questions(string $text, int $limit = 12, array $options = []): array {
        $json = self::decode_json_text($text, 'Không phân tích được JSON bài tập AI trả về');
        $questions = $json['questions'] ?? $json;
        if (!is_array($questions)) { throw new \moodle_exception('errorprocessingbook','local_aisgk','','JSON bài tập AI không có questions.'); }
        return self::validate_questions(array_values($questions), $limit, $options);
    }

    protected static function normalize_level(string $level): string {
        $level = strtolower(trim($level));
        $level = str_replace([' ', '-'], '_', $level);
        $map = ['recognize' => 'nhan_biet', 'understand' => 'thong_hieu', 'apply' => 'van_dung'];
        return $map[$level] ?? $level;
    }

    public static function normalize_homework_questions(array $questions, array $options, int $limit = 0): array {
        $allowedtypes = self::active_qtype_counts($options);
        $allowedlevels = self::active_level_counts($options);
        $usedtypes = [];
        $usedlevels = [];
        $out = [];
        $max = $limit > 0 ? max(1, min(60, $limit)) : self::safe_total($options);
        foreach ($questions as $q) {
            if (!is_array($q)) { continue; }
            $type = trim((string)($q['type'] ?? ''));
            $level = self::normalize_level((string)($q['level'] ?? ''));
            if ($type === '' || empty($allowedtypes[$type])) { continue; }
            if ($level === '' || empty($allowedlevels[$level])) { continue; }
            if (($usedtypes[$type] ?? 0) >= $allowedtypes[$type]) { continue; }
            if (($usedlevels[$level] ?? 0) >= $allowedlevels[$level]) { continue; }
            $text = trim((string)($q['questiontext'] ?? ''));
            if ($type !== 'description' && $text === '') { continue; }
            $q['type'] = $type;
            $q['level'] = $level;
            $q['name'] = 'Câu ' . (count($out) + 1);
            $q['questiontext'] = $text;
            if (!self::is_valid_by_type($q)) { continue; }
            $out[] = $q;
            $usedtypes[$type] = ($usedtypes[$type] ?? 0) + 1;
            $usedlevels[$level] = ($usedlevels[$level] ?? 0) + 1;
            if (count($out) >= $max) { break; }
        }
        return $out;
    }

    public static function validate_homework_against_plan(array $questions, array $options): array {
        $allowedtypes = self::active_qtype_counts($options);
        $allowedlevels = self::active_level_counts($options);
        $summary = ['qtypes' => [], 'levels' => []];
        foreach ($allowedtypes as $type => $count) { $summary['qtypes'][$type] = ['used' => 0, 'required' => (int)$count]; }
        foreach ($allowedlevels as $level => $count) { $summary['levels'][$level] = ['used' => 0, 'required' => (int)$count]; }
        $errors = [];
        foreach (array_values($questions) as $i => $q) {
            $no = $i + 1;
            if (!is_array($q)) { $errors[] = 'Câu ' . $no . ' không phải object JSON.'; continue; }
            $type = trim((string)($q['type'] ?? ''));
            $level = self::normalize_level((string)($q['level'] ?? ''));
            if (empty($allowedtypes[$type])) { $errors[] = 'Câu ' . $no . ' type ' . ($type ?: '(trống)') . ' ngoài cấu hình.'; continue; }
            if (empty($allowedlevels[$level])) { $errors[] = 'Câu ' . $no . ' level ' . ($level ?: '(trống)') . ' ngoài cấu hình.'; continue; }
            $summary['qtypes'][$type]['used']++;
            $summary['levels'][$level]['used']++;
            if (!self::is_valid_by_type($q)) { $errors[] = 'Câu ' . $no . ' thiếu dữ liệu bắt buộc cho type ' . $type . '.'; }
            if (in_array($type, ['calculated','calculatedsimple','calculatedmulti'], true)) {
                $answer = '';
                foreach (($q['answers'] ?? []) as $a) { $answer .= ' ' . (is_array($a) ? (string)($a['text'] ?? '') : ''); }
                if (!preg_match('/\{[a-z]/i', (string)($q['questiontext'] ?? '')) || !preg_match('/\{[a-z]/i', $answer)) {
                    $errors[] = 'Câu ' . $no . ' thiếu biến {a}/{b}/{x} trong đề hoặc đáp án.';
                }
            }
        }
        foreach ($summary['qtypes'] as $type => $v) {
            if ((int)$v['used'] !== (int)$v['required']) { $errors[] = 'Type ' . $type . ' sai số lượng (' . $v['used'] . '/' . $v['required'] . ').'; }
        }
        foreach ($summary['levels'] as $level => $v) {
            if ((int)$v['used'] !== (int)$v['required']) { $errors[] = 'Level ' . $level . ' sai số lượng (' . $v['used'] . '/' . $v['required'] . ').'; }
        }
        return ['ok' => empty($errors), 'errors' => $errors, 'summary' => $summary];
    }

    public static function questions_json(array $questions): string {
        return json_encode(['questions' => array_values($questions)], JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
    }

    protected static function validate_questions(array $questions, int $limit, array $options): array {
        $out = self::normalize_homework_questions($questions, $options, $limit);
        if (count($out) < max(1, min(60, $limit))) {
            throw new \moodle_exception('errorprocessingbook', 'local_aisgk', '', 'AI tạo ' . count($questions) . ' câu nhưng chỉ có ' . count($out) . ' câu hợp lệ theo cấu hình. Hãy bấm Tạo lại hoặc giảm số loại câu khó.');
        }
        return $out;
    }

    protected static function is_valid_by_type(array $q): bool {
        $type = (string)$q['type'];

        if (in_array($type, ['calculated', 'calculatedsimple', 'calculatedmulti'], true)) {
            if (empty($q['answers']) || !is_array($q['answers'])) {
                return false;
            }
            $questiontext = (string)($q['questiontext'] ?? '');
            $hasquestionvar = (bool)preg_match('/\{[a-zA-Z][a-zA-Z0-9_]*\}/', $questiontext);
            $hasanswervar = false;
            $sum = 0;
            foreach ($q['answers'] as $a) {
                if (!is_array($a) || trim((string)($a['text'] ?? '')) === '') {
                    return false;
                }
                $answertext = (string)$a['text'];
                if (preg_match('/\{[a-zA-Z][a-zA-Z0-9_]*\}/', $answertext)) {
                    $hasanswervar = true;
                }
                $sum += (float)($a['fraction'] ?? 0);
            }
            return $sum > 0 && $hasquestionvar && $hasanswervar;
        }

        if (in_array($type, ['multichoice', 'truefalse', 'shortanswer', 'numerical'], true)) {
            if (empty($q['answers']) || !is_array($q['answers'])) {
                return false;
            }
            $sum = 0;
            foreach ($q['answers'] as $a) {
                if (!is_array($a) || trim((string)($a['text'] ?? '')) === '') {
                    return false;
                }
                $sum += (float)($a['fraction'] ?? 0);
            }
            return $sum > 0;
        }
        if ($type === 'matching') {
            return !empty($q['subquestions']) && is_array($q['subquestions']) && count($q['subquestions']) >= 2;
        }
        if (in_array($type, ['gapselect', 'ddwtos'], true)) {
            return !empty($q['choices']) && is_array($q['choices']) && preg_match('/\[\[\d+\]\]/', (string)$q['questiontext']);
        }
        return true;
    }
}
