<?php
namespace local_aisgk\local;

defined('MOODLE_INTERNAL') || die();

use local_aisgk\ai_key_manager;

class ai_service {
    protected static function user_prefers_personal_key(int $userid): bool {
        return $userid > 0 && (bool)get_user_preferences('local_aisgk_use_my_api', 0, $userid);
    }

    public static function extract_toc_from_images(array $images, int $userid = 0): array {
        $prompt = 'Trích xuất dữ liệu từ bảng mục lục trong ảnh. Kết quả chỉ xuất JSON hợp lệ dạng {"rows":[{"sobai":"","tenbai":"","trang":""}]}. Giữ nguyên thứ tự, chỉ lấy dòng mục lục thực sự và số trang.';
        $result = self::call('scan', $userid, self::user_prefers_personal_key($userid), $prompt, $images, true);
        $result['rows'] = self::extract_rows(self::response_text($result['response'], $result['provider']));
        unset($result['response']);
        return $result;
    }

    public static function generate_homework_questions(string $topicname, string $text, array $formula, int $userid = 0, array $options = []): array {
        $total = self::requested_total($options);
        $prompt = self::build_homework_prompt($topicname, '', 0, 0, $total, $options)
            . "\n\nNội dung SGK đã trích xuất:\n"
            . mb_substr($text, 0, 18000)
            . "\n\nCông thức/ý chính nếu có: " . json_encode($formula, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
        $result = self::call('homework', $userid, self::user_prefers_personal_key($userid), $prompt, [], true);
        $raw = self::response_text($result['response'], $result['provider']);
        $result['rawtext'] = $raw;
        $result['questions'] = self::extract_questions($raw, $total, $options);
        unset($result['response']);
        return $result;
    }

    public static function generate_homework_questions_from_images(
        string $topicname,
        array $images,
        int $pagefrom,
        int $pageto,
        int $userid = 0,
        array $options = [],
        string $bookname = ''
    ): array {
        $total = self::requested_total($options);
        $prompt = self::build_homework_prompt($topicname, $bookname, $pagefrom, $pageto, $total, $options);
        $result = self::call('homework', $userid, self::user_prefers_personal_key($userid), $prompt, $images, true);
        $raw = self::response_text($result['response'], $result['provider']);
        $result['rawtext'] = $raw;
        $result['questions'] = self::extract_questions($raw, $total, $options);
        unset($result['response']);
        return $result;
    }

    protected static function requested_total(array $options): int {
        $total = (int)($options['total'] ?? 8);
        return max(1, min(60, $total));
    }

    protected static function build_homework_prompt(string $topicname, string $bookname, int $pagefrom, int $pageto, int $total, array $options): string {
        $source = $bookname !== '' ? "- Sách/SGK: {$bookname}\n" : '';
        $pages = ($pagefrom > 0 && $pageto >= $pagefrom) ? "- Trang: {$pagefrom} → {$pageto}\n" : '';
        $configjson = json_encode($options, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
        $schemaText = self::active_qtype_schema_text($options);
        $activeTypes = implode(', ', array_keys(self::allowed_qtype_counts($options, $total)));
        $activeLevels = implode(', ', array_keys(self::allowed_level_counts($options, $total)));

        return "Bạn là giáo viên THCS tại Việt Nam.\n\n"
            . "Nhiệm vụ: tạo bài tập về nhà từ nội dung SGK trong ảnh/nội dung được cung cấp.\n\n"
            . "Nguồn:\n{$source}"
            . "- Tên bài/chủ đề: {$topicname}\n"
            . $pages
            . "- Số câu cần tạo: {$total}\n\n"
            . "Cấu hình giáo viên gửi lên:\n{$configjson}\n\n"
            . "Yêu cầu nội dung:\n"
            . "- Đọc hiểu trực tiếp nội dung SGK; không suy diễn ngoài SGK.\n"
            . "- Hãy chú trọng đọc phần Mục tiêu bài học / Yêu cầu cần đạt nếu có. Phần này thường nằm trong khung màu, có biểu tượng mục tiêu, hoặc bắt đầu bằng các cụm như 'Sau bài học này em sẽ...', 'Yêu cầu cần đạt', 'Học xong bài này em có thể...'.\n"
            . "- Phần mục tiêu thường nằm ngay dưới tên bài, ở sidebar, hoặc trong khoảng 10 dòng đầu của trang đầu tiên của bài học.\n"
            . "- Chỉ tạo câu hỏi bám sát các năng lực, kiến thức và yêu cầu được nêu trong phần mục tiêu/yêu cầu cần đạt.\n"
            . "- Ưu tiên tham khảo phần bài tập/câu hỏi cuối bài nếu có, vì đây thường là hệ thống câu hỏi tác giả SGK đã định hướng.\n"
            . "- Bỏ qua header, footer, số trang, mục lục, watermark và rác quét.\n"
            . "- Ngôn ngữ câu hỏi phải phù hợp với ngôn ngữ nội dung bài học trong SGK.\n\n"
            . "RÀNG BUỘC CỨNG THEO CẤU HÌNH GIÁO VIÊN:\n"
            . "1. Chỉ được dùng các qtype sau: {$activeTypes}.\n"
            . "2. TUYỆT ĐỐI KHÔNG tạo qtype có số lượng = 0, không có trong options.qtypes, hoặc không có trong danh sách được phép.\n"
            . "3. Số câu theo từng qtype phải đúng số lượng trong options.qtypes. Ví dụ type nào = 1 thì chỉ tạo đúng 1 câu type đó.\n"
            . "4. Chỉ được dùng các level sau: {$activeLevels}. Dùng mã: nhan_biet, thong_hieu, van_dung.\n"
            . "5. TUYỆT ĐỐI KHÔNG tạo level có số lượng = 0 hoặc không được giáo viên chọn.\n"
            . "6. Số câu theo từng level phải đúng số lượng trong options.cognitive.\n"
            . "7. Tổng số phần tử trong mảng questions phải bằng chính xác {$total}.\n"
            . "8. name chỉ dùng dạng 'Câu 1', 'Câu 2'... Không thêm tên bài vào name.\n\n"
            . "Quy tắc công thức/kí hiệu để hiển thị được:\n"
            . "- Nếu câu hỏi, đáp án hoặc phản hồi có công thức toán/lý/hóa, hãy viết bằng LaTeX.\n"
            . "- Công thức trong dòng dùng dạng \\( ... \\), công thức riêng dòng dùng dạng \\[ ... \\].\n"
            . "- Không dùng cú pháp markdown, không dùng HTML phức tạp, không dùng kí hiệu Unicode khó render như ²/³ nếu có thể viết bằng LaTeX.\n"
            . "- Ví dụ: \\(S = a \\times b\\), \\(v = \\frac{s}{t}\\), \\(H_2O\\), \\(x^2 + y^2\\).\n\n"
            . "Chỉ trả JSON hợp lệ, không markdown, không giải thích, không thêm text ngoài JSON.\n\n"
            . "Cấu trúc chung bắt buộc:\n"
            . "{\"questions\":[{\"type\":\"<chỉ dùng qtype được phép>\",\"level\":\"<chỉ dùng level được phép>\",\"name\":\"Câu 1\",\"questiontext\":\"...\"}]}\n\n"
            . "DANH SÁCH QTYPE ĐƯỢC PHÉP DÙNG VÀ SCHEMA TƯƠNG ỨNG:\n"
            . $schemaText . "\n\n"
            . "Nếu nội dung SGK không đủ thông tin cho một qtype được chọn, hãy tạo câu đơn giản hơn nhưng vẫn giữ đúng qtype đó; không được tự ý đổi sang qtype ngoài danh sách.\n"
            . "Nếu không thể đảm bảo JSON hợp lệ thì trả đúng: {\"questions\":[]}.";
    }

    protected static function qtype_schema_map(): array {
        return [
            'multichoice' => '- multichoice: có answers, mỗi phần tử {"text":"...","fraction":100 hoặc 0}; tổng fraction đáp án đúng bằng 100.',
            'truefalse' => '- truefalse: có answers gồm đúng và sai; một đáp án fraction 100, đáp án còn lại 0.',
            'shortanswer' => '- shortanswer: có answers [{"text":"đáp án ngắn","fraction":100}].',
            'numerical' => '- numerical: có answers [{"text":"giá trị số hoặc LaTeX nếu cần","fraction":100,"tolerance":0}].',
            'matching' => '- matching: có subquestions [{"question":"...","answer":"..."}], tối thiểu 2 cặp.',
            'essay' => '- essay: chỉ cần questiontext; có thể thêm responseformat nếu biết.',
            'gapselect' => '- gapselect: questiontext phải có chỗ trống dạng [[1]], [[2]] và có choices [{"group":1,"text":"..."}].',
            'ddwtos' => '- ddwtos: questiontext phải có chỗ trống dạng [[1]], [[2]] và có choices [{"group":1,"text":"..."}].',
            'calculated' => '- calculated: có questiontext, answers và công thức rõ ràng; công thức toán phải viết LaTeX trong questiontext nếu hiển thị cho học sinh.',
            'calculatedsimple' => '- calculatedsimple: có questiontext, answers và công thức rõ ràng; công thức toán phải viết LaTeX trong questiontext nếu hiển thị cho học sinh.',
            'calculatedmulti' => '- calculatedmulti: có answers nhiều lựa chọn và công thức rõ ràng; công thức toán phải viết LaTeX trong questiontext nếu hiển thị cho học sinh.',
            'description' => '- description: chỉ dùng khi giáo viên cấu hình, là nội dung mô tả không tính điểm.',
            'ddimageortext' => '- ddimageortext: chỉ dùng khi giáo viên cấu hình; cần questiontext và dữ liệu kéo thả dạng text đơn giản, không tự tạo tọa độ ảnh phức tạp.',
            'ddmarker' => '- ddmarker: chỉ dùng khi giáo viên cấu hình; cần questiontext và marker đơn giản, không tự tạo tọa độ ảnh phức tạp.',
            'random' => '- random: chỉ dùng khi giáo viên cấu hình; mô tả tiêu chí câu hỏi ngẫu nhiên, không tạo nội dung ngoài SGK.',
        ];
    }

    protected static function active_qtype_schema_text(array $options): string {
        $schemas = self::qtype_schema_map();
        $lines = [];
        foreach (array_keys(self::allowed_qtype_counts($options, self::requested_total($options))) as $type) {
            if (isset($schemas[$type])) { $lines[] = $schemas[$type]; }
        }
        return $lines ? implode("\n", $lines) : '- multichoice: có answers, mỗi phần tử {"text":"...","fraction":100 hoặc 0}; tổng fraction đáp án đúng bằng 100.';
    }

    protected static function call(string $feature, int $userid, bool $preferuser, string $prompt, array $images, bool $jsonmode): array {
        $attempted = [];
        $last = '';
        for ($try = 0; $try < 30; $try++) {
            $key = ai_key_manager::get_available_key($feature, $attempted, $userid, $preferuser, 0);
            if (!$key) { break; }
            $attempted[] = (int)$key->id;
            $provider = ai_key_manager::provider_for_key($key);
            foreach (ai_key_manager::model_attempts_for_key($key, $feature) as $model) {
                $callkey = clone $key;
                if ($feature === 'homework') { $callkey->model_homework = $model; } else { $callkey->model_scan = $model; }
                try {
                    $payload = self::build_payload($provider, $model, $prompt, $images, $jsonmode);
                    $tokens = self::count_tokens($callkey, $provider, $model, $payload);
                    if (!ai_key_manager::can_use_key($callkey, $tokens)) {
                        $last = 'Key vượt giới hạn RPM/RPD/TPM';
                        continue;
                    }
                    $response = self::execute($callkey, $provider, $model, $payload);
                    $usage = ai_key_manager::mark_success($callkey, $tokens, $model);
                    return ['provider'=>$provider,'model'=>$model,'tokens'=>$tokens,'usage'=>$usage,'keysource'=>(string)($callkey->_source_table ?? 'system'),'category'=>(string)($callkey->category_key ?? 'free'),'response'=>$response];
                } catch (\Throwable $e) {
                    $last = $e->getMessage();
                    if (preg_match('/invalid api key|api key not valid|forbidden|permission denied|401|403|unauthorized/i', $last)) { ai_key_manager::mark_blocked($key, $last); break; }
                    if (preg_match('/429|rate limit|resource exhausted|quota|too many requests/i', $last)) { ai_key_manager::mark_429($key); break; }
                    ai_key_manager::mark_error($key, $last);
                }
            }
        }
        throw new \moodle_exception('errorprocessingbook', 'local_aisgk', '', 'Không có API key khả dụng hoặc key vượt giới hạn/cooldown. Lỗi cuối: ' . $last);
    }

    protected static function build_payload(string $provider, string $model, string $prompt, array $images, bool $jsonmode): array {
        if ($provider === 'shopaikey') {
            $content = [['type'=>'text','text'=>$prompt]];
            foreach ($images as $image) { $url = self::image_data_url($image); if ($url !== '') { $content[] = ['type'=>'image_url','image_url'=>['url'=>$url]]; } }
            $payload = ['model'=>$model,'messages'=>[['role'=>'user','content'=>$content]],'temperature'=>0.1];
            if ($jsonmode) { $payload['response_format'] = ['type'=>'json_object']; }
            return $payload;
        }
        $parts = [['text'=>$prompt]];
        foreach ($images as $image) { $inline = self::inline_image($image); if ($inline) { $parts[] = ['inlineData'=>$inline]; } }
        $payload = ['contents'=>[['parts'=>$parts]],'generationConfig'=>['temperature'=>0.1]];
        if ($jsonmode) { $payload['generationConfig']['responseMimeType'] = 'application/json'; }
        return $payload;
    }

    protected static function execute(\stdClass $key, string $provider, string $model, array $payload): array {
        $apikey = trim((string)($key->api_key ?? ''));
        if ($apikey === '') { throw new \moodle_exception('errorprocessingbook', 'local_aisgk', '', 'API key rỗng.'); }
        if ($provider === 'shopaikey') {
            $url = 'https://api.shopaikey.com/v1/chat/completions';
            $headers = ['Content-Type: application/json', 'Authorization: Bearer ' . $apikey];
        } else {
            $url = 'https://generativelanguage.googleapis.com/v1beta/models/' . rawurlencode($model) . ':generateContent';
            $headers = ['Content-Type: application/json', 'X-goog-api-key: ' . $apikey];
        }
        $ch = curl_init($url);
        curl_setopt_array($ch, [CURLOPT_RETURNTRANSFER=>true,CURLOPT_POST=>true,CURLOPT_HTTPHEADER=>$headers,CURLOPT_POSTFIELDS=>json_encode($payload, JSON_UNESCAPED_UNICODE|JSON_UNESCAPED_SLASHES),CURLOPT_TIMEOUT=>120,CURLOPT_CONNECTTIMEOUT=>15]);
        $response = curl_exec($ch); $errno = curl_errno($ch); $error = curl_error($ch); $http = (int)curl_getinfo($ch, CURLINFO_RESPONSE_CODE); curl_close($ch);
        if ($errno) { throw new \moodle_exception('errorprocessingbook', 'local_aisgk', '', 'Lỗi kết nối API: ' . $error); }
        $json = json_decode((string)$response, true);
        if (!is_array($json)) { throw new \moodle_exception('errorprocessingbook', 'local_aisgk', '', 'API trả dữ liệu không hợp lệ: ' . mb_substr((string)$response,0,1000)); }
        if ($http >= 400 || !empty($json['error'])) { $err = $json['error'] ?? []; $msg = is_array($err) ? (string)($err['message'] ?? ('HTTP '.$http)) : (string)$err; throw new \moodle_exception('errorprocessingbook', 'local_aisgk', '', 'API_ERROR: ' . $msg); }
        return $json;
    }

    protected static function count_tokens(\stdClass $key, string $provider, string $model, array $payload): int {
        $total = 0;
        foreach (($payload['contents'] ?? []) as $content) {
            foreach (($content['parts'] ?? []) as $part) {
                if (!empty($part['text'])) {
                    $total += (int)ceil(mb_strlen($part['text'], 'UTF-8') / 3);
                }
                if (!empty($part['inlineData']['data'])) {
                    $imgdata = base64_decode($part['inlineData']['data'], true);
                    if ($imgdata !== false) {
                        $info = @getimagesizefromstring($imgdata);
                        if ($info && !empty($info[0]) && !empty($info[1])) {
                            $w = (int)$info[0]; $h = (int)$info[1];
                            $total += ($w <= 384 && $h <= 384) ? 258 : (max(1, (int)ceil($w / 768)) * max(1, (int)ceil($h / 768)) * 258);
                        } else {
                            $total += 2500;
                        }
                    } else {
                        $total += 2500;
                    }
                }
            }
        }
        if ($total <= 0) {
            $raw = json_encode($payload, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
            $total = (int)ceil(strlen($raw) / 4);
        }
        return max(1, (int)$total);
    }

    protected static function inline_image(string $image): ?array { $data = @file_get_contents($image); if (!$data) { return null; } $ext = strtolower(pathinfo($image, PATHINFO_EXTENSION)); $mime = ($ext === 'jpg' || $ext === 'jpeg') ? 'image/jpeg' : (($ext === 'webp') ? 'image/webp' : 'image/png'); return ['mimeType'=>$mime,'data'=>base64_encode($data)]; }
    protected static function image_data_url(string $image): string { $i = self::inline_image($image); return $i ? ('data:' . $i['mimeType'] . ';base64,' . $i['data']) : ''; }

    protected static function response_text(array $json, string $provider): string {
        if ($provider === 'shopaikey') { $c = $json['choices'][0]['message']['content'] ?? ''; if (is_array($c)) { return implode("\n", array_map(fn($p)=>(string)($p['text'] ?? ''), $c)); } return (string)$c; }
        $text = ''; foreach (($json['candidates'] ?? []) as $cand) { foreach (($cand['content']['parts'] ?? []) as $p) { if (!empty($p['text'])) { $text .= $p['text']; } } } return $text;
    }

    protected static function extract_rows(string $text): array {
        $json = self::decode_json_object($text, 'Không phân tích được JSON AI trả về: ');
        $rows = $json['rows'] ?? $json;
        if (!is_array($rows)) {
            throw new \moodle_exception('errorprocessingbook', 'local_aisgk', '', 'JSON AI không có rows.');
        }
        return $rows;
    }

    protected static function extract_questions(string $text, int $limit = 12, array $options = []): array {
        $json = self::decode_json_object($text, 'Không phân tích được JSON bài tập AI trả về: ');
        $questions = $json['questions'] ?? $json;
        if (!is_array($questions)) {
            throw new \moodle_exception('errorprocessingbook', 'local_aisgk', '', 'JSON bài tập AI không có questions.');
        }
        $questions = self::validate_homework_questions($questions, $options, $limit);
        if (!$questions) {
            throw new \moodle_exception('errorprocessingbook', 'local_aisgk', '', 'AI trả về JSON nhưng không có câu hỏi hợp lệ sau khi kiểm tra.');
        }
        return $questions;
    }

    protected static function decode_json_object(string $text, string $messageprefix): array {
        $clean = trim($text);
        $clean = preg_replace('/^```(?:json)?\s*/iu', '', $clean);
        $clean = preg_replace('/\s*```$/u', '', $clean);
        $json = json_decode($clean, true);
        if (!is_array($json) && preg_match('/\{[\s\S]*\}/u', $clean, $m)) {
            $json = json_decode($m[0], true);
        }
        if (!is_array($json)) {
            throw new \moodle_exception('errorprocessingbook', 'local_aisgk', '', $messageprefix . mb_substr($text, 0, 1000));
        }
        return $json;
    }

    protected static function validate_homework_questions(array $questions, array $options, int $limit): array {
        $allowedtypecounts = self::allowed_qtype_counts($options, $limit);
        $allowedtypes = array_keys($allowedtypecounts);
        $allowedlevelcounts = self::allowed_level_counts($options, $limit);
        $usedtypes = [];
        $usedlevels = [];
        $out = [];
        $max = max(1, min(60, $limit));
        foreach ($questions as $q) {
            if (!is_array($q)) { continue; }
            $type = self::normalise_qtype((string)($q['type'] ?? ''), $allowedtypes);
            if ($type === '') { continue; }
            if (($usedtypes[$type] ?? 0) >= ($allowedtypecounts[$type] ?? 0)) { continue; }
            $level = self::select_allowed_level((string)($q['level'] ?? ''), $allowedlevelcounts, $usedlevels);
            if ($level === '') { continue; }
            $questiontext = trim((string)($q['questiontext'] ?? $q['question'] ?? $q['text'] ?? ''));
            if ($questiontext === '' && $type !== 'description') { continue; }
            $item = ['type' => $type, 'level' => $level, 'name' => 'Câu ' . (count($out) + 1), 'questiontext' => $questiontext];
            if (!empty($q['feedback'])) { $item['feedback'] = trim((string)$q['feedback']); }
            if (!self::normalise_question_payload($item, $q)) { continue; }
            $out[] = $item;
            $usedtypes[$type] = ($usedtypes[$type] ?? 0) + 1;
            $usedlevels[$level] = ($usedlevels[$level] ?? 0) + 1;
            if (count($out) >= $max) { break; }
        }
        return $out;
    }

    protected static function allowed_qtype_counts(array $options, int $limit = 12): array {
        $all = ['multichoice', 'truefalse', 'shortanswer', 'numerical', 'matching', 'essay', 'gapselect', 'ddwtos', 'calculated', 'calculatedsimple', 'calculatedmulti', 'description', 'ddimageortext', 'ddmarker', 'random'];
        $qtypes = $options['qtypes'] ?? [];
        $allowed = [];
        if (is_array($qtypes)) {
            foreach ($qtypes as $type => $count) {
                $type = self::normalise_qtype((string)$type, $all);
                $count = (int)$count;
                if ($type !== '' && $count > 0) { $allowed[$type] = ($allowed[$type] ?? 0) + $count; }
            }
        }
        return $allowed ?: ['multichoice' => max(1, min(60, $limit))];
    }

    protected static function allowed_level_counts(array $options, int $limit = 12): array {
        $map = ['recognize' => 'nhan_biet', 'understand' => 'thong_hieu', 'apply' => 'van_dung'];
        $cognitive = $options['cognitive'] ?? [];
        $allowed = [];
        if (is_array($cognitive)) {
            foreach ($cognitive as $key => $count) {
                $count = (int)$count;
                if ($count > 0 && isset($map[$key])) { $allowed[$map[$key]] = ($allowed[$map[$key]] ?? 0) + $count; }
            }
        }
        return $allowed ?: ['nhan_biet' => max(1, min(60, $limit))];
    }

    protected static function select_allowed_level(string $level, array $allowedcounts, array $usedlevels): string {
        $allowed = array_keys($allowedcounts);
        $normalised = self::normalise_level($level, $allowed, 0);
        if ($normalised !== '' && (($usedlevels[$normalised] ?? 0) < ($allowedcounts[$normalised] ?? 0))) {
            return $normalised;
        }
        foreach ($allowedcounts as $candidate => $quota) {
            if (($usedlevels[$candidate] ?? 0) < $quota) { return $candidate; }
        }
        return '';
    }

    protected static function normalise_qtype(string $type, array $allowed): string {
        $type = strtolower(trim($type));
        $aliases = ['multiplechoice' => 'multichoice', 'multiple_choice' => 'multichoice', 'true_false' => 'truefalse', 'short_answer' => 'shortanswer', 'match' => 'matching', 'dragdropintotext' => 'ddwtos', 'drag_drop_into_text' => 'ddwtos'];
        $type = $aliases[$type] ?? $type;
        return in_array($type, $allowed, true) ? $type : '';
    }

    protected static function normalise_level(string $level, array $allowed, int $index): string {
        $level = strtolower(trim($level));
        $level = str_replace([' ', '-', '.'], '_', $level);
        $aliases = ['recognize' => 'nhan_biet', 'remember' => 'nhan_biet', 'nhận_biết' => 'nhan_biet', 'nhanbiet' => 'nhan_biet', 'understand' => 'thong_hieu', 'thông_hiểu' => 'thong_hieu', 'thonghieu' => 'thong_hieu', 'apply' => 'van_dung', 'vận_dụng' => 'van_dung', 'vandung' => 'van_dung'];
        $level = $aliases[$level] ?? $level;
        return in_array($level, $allowed, true) ? $level : $allowed[$index % count($allowed)];
    }

    protected static function normalise_question_payload(array &$item, array $raw): bool {
        switch ($item['type']) {
            case 'multichoice':
                $answers = self::normalise_answers($raw['answers'] ?? $raw['options'] ?? [], true);
                if (count($answers) < 2) { return false; }
                $item['answers'] = $answers;
                return true;
            case 'truefalse':
                $answers = self::normalise_answers($raw['answers'] ?? [], true);
                if (count($answers) < 2) {
                    $correct = $raw['correctanswer'] ?? $raw['answer'] ?? null;
                    $istrue = is_bool($correct) ? $correct : preg_match('/^(true|đúng|dung|1)$/iu', (string)$correct);
                    $answers = [['text' => 'Đúng', 'fraction' => $istrue ? 100 : 0], ['text' => 'Sai', 'fraction' => $istrue ? 0 : 100]];
                }
                $item['answers'] = array_slice($answers, 0, 2);
                return true;
            case 'shortanswer':
            case 'numerical':
            case 'calculated':
            case 'calculatedsimple':
            case 'calculatedmulti':
                $answers = self::normalise_answers($raw['answers'] ?? [], false);
                if (!$answers) {
                    $ans = trim((string)($raw['correctanswer'] ?? $raw['answer'] ?? ''));
                    if ($ans !== '') { $answers[] = ['text' => $ans, 'fraction' => 100]; }
                }
                if (!$answers) { return false; }
                if ($item['type'] === 'numerical' && !isset($answers[0]['tolerance'])) { $answers[0]['tolerance'] = isset($raw['tolerance']) ? (float)$raw['tolerance'] : 0; }
                $item['answers'] = $answers;
                return true;
            case 'matching':
                $subs = $raw['subquestions'] ?? $raw['matches'] ?? [];
                $normalised = [];
                if (is_array($subs)) {
                    foreach ($subs as $sub) {
                        if (!is_array($sub)) { continue; }
                        $question = trim((string)($sub['question'] ?? $sub['prompt'] ?? ''));
                        $answer = trim((string)($sub['answer'] ?? $sub['match'] ?? ''));
                        if ($question !== '' && $answer !== '') { $normalised[] = ['question' => $question, 'answer' => $answer]; }
                    }
                }
                if (count($normalised) < 2) { return false; }
                $item['subquestions'] = $normalised;
                return true;
            case 'gapselect':
            case 'ddwtos':
                $choices = $raw['choices'] ?? $raw['answers'] ?? $raw['options'] ?? [];
                $normalised = [];
                if (is_array($choices)) {
                    foreach ($choices as $choice) {
                        if (is_array($choice)) { $text = trim((string)($choice['text'] ?? $choice['answer'] ?? '')); $group = max(1, (int)($choice['group'] ?? 1)); }
                        else { $text = trim((string)$choice); $group = 1; }
                        if ($text !== '') { $normalised[] = ['group' => $group, 'text' => $text]; }
                    }
                }
                if (!$normalised) { return false; }
                $item['choices'] = $normalised;
                return true;
            case 'essay':
            case 'description':
            case 'ddimageortext':
            case 'ddmarker':
            case 'random':
                return true;
        }
        return true;
    }

    protected static function normalise_answers($answers, bool $forceonecorrect): array {
        $out = [];
        if (is_array($answers)) {
            foreach ($answers as $answer) {
                if (is_array($answer)) { $text = trim((string)($answer['text'] ?? $answer['answer'] ?? $answer['label'] ?? '')); $fraction = (int)($answer['fraction'] ?? (!empty($answer['correct']) ? 100 : 0)); }
                else { $text = trim((string)$answer); $fraction = 0; }
                if ($text !== '') { $out[] = ['text' => $text, 'fraction' => max(0, min(100, $fraction))]; }
            }
        }
        if (!$out) { return []; }
        $sum = array_sum(array_map(static fn($a) => (int)$a['fraction'], $out));
        if ($forceonecorrect && $sum !== 100) {
            $best = 0; $bestscore = -1;
            foreach ($out as $i => $a) { if ((int)$a['fraction'] > $bestscore) { $bestscore = (int)$a['fraction']; $best = $i; } }
            foreach ($out as $i => $a) { $out[$i]['fraction'] = ($i === $best) ? 100 : 0; }
        } else if (!$forceonecorrect && $sum <= 0) {
            $out[0]['fraction'] = 100;
        }
        return $out;
    }
}
