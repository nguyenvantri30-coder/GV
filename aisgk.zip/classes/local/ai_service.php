<?php
namespace local_aisgk\local;

defined('MOODLE_INTERNAL') || die();

use local_aisgk\ai_key_manager;

class ai_service {
    protected static function user_prefers_personal_key(int $userid): bool {
        return $userid > 0 && (bool)get_user_preferences('local_aisgk_use_my_api', 0, $userid);
    }

    public static function extract_toc_from_images(array $images, int $userid = 0): array {
        $prompt = 'Trích xuất dữ liệu từ bảng mục lục trong ảnh. Kết quả chỉ xuất JSON hợp lệ dạng {"rows":[{"sobai":"","tenbai":"","trang":""}]}. Giữ nguyên thứ tự, chỉ lấy dòng mục lục thực sự và số trang.';
        $result = self::call('scan', $userid, self::user_prefers_personal_key($userid), $prompt, $images, true);
        $result['rows'] = self::extract_rows(self::response_text($result['response'], $result['provider']));
        unset($result['response']);
        return $result;
    }

    public static function generate_homework_questions(string $topicname, string $text, array $formula, int $userid = 0): array {
        $prompt = "Bạn là giáo viên Việt Nam. Tạo BTVN từ nội dung SGK.\nTên bài: {$topicname}\nCông thức/ý chính: " . json_encode($formula, JSON_UNESCAPED_UNICODE) . "\nNội dung:\n" . mb_substr($text, 0, 18000) . "\nChỉ trả JSON hợp lệ dạng {\"questions\":[{\"type\":\"shortanswer\",\"name\":\"Câu 1\",\"questiontext\":\"...\"}]}. Tạo 6-8 câu.";
        $result = self::call('homework', $userid, self::user_prefers_personal_key($userid), $prompt, [], true);
        $result['questions'] = self::extract_questions(self::response_text($result['response'], $result['provider']));
        unset($result['response']);
        return $result;
    }

    protected static function call(string $feature, int $userid, bool $preferuser, string $prompt, array $images, bool $jsonmode): array {
        $attempted = [];
        $last = '';
        for ($try = 0; $try < 30; $try++) {
            $key = ai_key_manager::get_available_key($feature, $attempted, $userid, $preferuser, 0);
            if (!$key) { break; }
            $attempted[] = (int)$key->id;
            $provider = ai_key_manager::provider_for_key($key);
            foreach (ai_key_manager::model_attempts_for_key($key, $feature) as $model) {
                $callkey = clone $key;
                if ($feature === 'homework') { $callkey->model_homework = $model; } else { $callkey->model_scan = $model; }
                try {
                    $payload = self::build_payload($provider, $model, $prompt, $images, $jsonmode);
                    $tokens = self::count_tokens($callkey, $provider, $model, $payload);
                    if (!ai_key_manager::can_use_key($callkey, $tokens)) {
                        $last = 'Key vượt giới hạn RPM/RPD/TPM';
                        continue;
                    }
                    $response = self::execute($callkey, $provider, $model, $payload);
                    $usage = ai_key_manager::mark_success($callkey, $tokens, $model);
                    return ['provider'=>$provider,'model'=>$model,'tokens'=>$tokens,'usage'=>$usage,'keysource'=>(string)($callkey->_source_table ?? 'system'),'category'=>(string)($callkey->category_key ?? 'free'),'response'=>$response];
                } catch (\Throwable $e) {
                    $last = $e->getMessage();
                    if (preg_match('/invalid api key|api key not valid|forbidden|permission denied|401|403|unauthorized/i', $last)) { ai_key_manager::mark_blocked($key, $last); break; }
                    if (preg_match('/429|rate limit|resource exhausted|quota|too many requests/i', $last)) { ai_key_manager::mark_429($key); break; }
                    ai_key_manager::mark_error($key, $last);
                }
            }
        }
        throw new \moodle_exception('errorprocessingbook', 'local_aisgk', '', 'Không có API key khả dụng hoặc key vượt giới hạn/cooldown. Lỗi cuối: ' . $last);
    }

    protected static function build_payload(string $provider, string $model, string $prompt, array $images, bool $jsonmode): array {
        if ($provider === 'shopaikey') {
            $content = [['type'=>'text','text'=>$prompt]];
            foreach ($images as $image) { $url = self::image_data_url($image); if ($url !== '') { $content[] = ['type'=>'image_url','image_url'=>['url'=>$url]]; } }
            $payload = ['model'=>$model,'messages'=>[['role'=>'user','content'=>$content]],'temperature'=>0.1];
            if ($jsonmode) { $payload['response_format'] = ['type'=>'json_object']; }
            return $payload;
        }
        $parts = [['text'=>$prompt]];
        foreach ($images as $image) { $inline = self::inline_image($image); if ($inline) { $parts[] = ['inlineData'=>$inline]; } }
        $payload = ['contents'=>[['parts'=>$parts]],'generationConfig'=>['temperature'=>0.1]];
        if ($jsonmode) { $payload['generationConfig']['responseMimeType'] = 'application/json'; }
        return $payload;
    }

    protected static function execute(\stdClass $key, string $provider, string $model, array $payload): array {
        $apikey = trim((string)($key->api_key ?? ''));
        if ($apikey === '') { throw new \moodle_exception('errorprocessingbook', 'local_aisgk', '', 'API key rỗng.'); }
        if ($provider === 'shopaikey') {
            $url = 'https://api.shopaikey.com/v1/chat/completions';
            $headers = ['Content-Type: application/json', 'Authorization: Bearer ' . $apikey];
        } else {
            $url = 'https://generativelanguage.googleapis.com/v1beta/models/' . rawurlencode($model) . ':generateContent';
            $headers = ['Content-Type: application/json', 'X-goog-api-key: ' . $apikey];
        }
        $ch = curl_init($url);
        curl_setopt_array($ch, [CURLOPT_RETURNTRANSFER=>true,CURLOPT_POST=>true,CURLOPT_HTTPHEADER=>$headers,CURLOPT_POSTFIELDS=>json_encode($payload, JSON_UNESCAPED_UNICODE|JSON_UNESCAPED_SLASHES),CURLOPT_TIMEOUT=>120,CURLOPT_CONNECTTIMEOUT=>15]);
        $response = curl_exec($ch); $errno = curl_errno($ch); $error = curl_error($ch); $http = (int)curl_getinfo($ch, CURLINFO_RESPONSE_CODE); curl_close($ch);
        if ($errno) { throw new \moodle_exception('errorprocessingbook', 'local_aisgk', '', 'Lỗi kết nối API: ' . $error); }
        $json = json_decode((string)$response, true);
        if (!is_array($json)) { throw new \moodle_exception('errorprocessingbook', 'local_aisgk', '', 'API trả dữ liệu không hợp lệ: ' . mb_substr((string)$response,0,1000)); }
        if ($http >= 400 || !empty($json['error'])) { $err = $json['error'] ?? []; $msg = is_array($err) ? (string)($err['message'] ?? ('HTTP '.$http)) : (string)$err; throw new \moodle_exception('errorprocessingbook', 'local_aisgk', '', 'API_ERROR: ' . $msg); }
        return $json;
    }

    protected static function count_tokens(\stdClass $key, string $provider, string $model, array $payload): int {
        $estimate = max(1, (int)ceil(strlen(json_encode($payload, JSON_UNESCAPED_UNICODE|JSON_UNESCAPED_SLASHES)) / 4));
        if ($provider !== 'google') { return $estimate; }
        $apikey = trim((string)($key->api_key ?? '')); if ($apikey === '') { return $estimate; }
        $url = 'https://generativelanguage.googleapis.com/v1beta/models/' . rawurlencode($model) . ':countTokens';
        $ch = curl_init($url);
        curl_setopt_array($ch, [CURLOPT_RETURNTRANSFER=>true,CURLOPT_POST=>true,CURLOPT_HTTPHEADER=>['Content-Type: application/json','X-goog-api-key: '.$apikey],CURLOPT_POSTFIELDS=>json_encode($payload, JSON_UNESCAPED_UNICODE|JSON_UNESCAPED_SLASHES),CURLOPT_TIMEOUT=>20,CURLOPT_CONNECTTIMEOUT=>8]);
        $res = curl_exec($ch); $errno = curl_errno($ch); $http = (int)curl_getinfo($ch, CURLINFO_RESPONSE_CODE); curl_close($ch);
        if ($errno || $http >= 400) { return $estimate; }
        $json = json_decode((string)$res, true);
        return max(1, (int)($json['totalTokens'] ?? $estimate));
    }

    protected static function inline_image(string $image): ?array { $data = @file_get_contents($image); if (!$data) { return null; } $ext = strtolower(pathinfo($image, PATHINFO_EXTENSION)); $mime = ($ext === 'jpg' || $ext === 'jpeg') ? 'image/jpeg' : (($ext === 'webp') ? 'image/webp' : 'image/png'); return ['mimeType'=>$mime,'data'=>base64_encode($data)]; }
    protected static function image_data_url(string $image): string { $i = self::inline_image($image); return $i ? ('data:' . $i['mimeType'] . ';base64,' . $i['data']) : ''; }

    protected static function response_text(array $json, string $provider): string {
        if ($provider === 'shopaikey') { $c = $json['choices'][0]['message']['content'] ?? ''; if (is_array($c)) { return implode("\n", array_map(fn($p)=>(string)($p['text'] ?? ''), $c)); } return (string)$c; }
        $text = ''; foreach (($json['candidates'] ?? []) as $cand) { foreach (($cand['content']['parts'] ?? []) as $p) { if (!empty($p['text'])) { $text .= $p['text']; } } } return $text;
    }
    protected static function extract_rows(string $text): array { $json = json_decode(trim($text), true); if (!is_array($json) && preg_match('/\{.*\}/s', $text, $m)) { $json = json_decode($m[0], true); } if (!is_array($json)) { throw new \moodle_exception('errorprocessingbook','local_aisgk','','Không phân tích được JSON AI trả về: '.mb_substr($text,0,1000)); } $rows = $json['rows'] ?? $json; if (!is_array($rows)) { throw new \moodle_exception('errorprocessingbook','local_aisgk','','JSON AI không có rows.'); } return $rows; }
    protected static function extract_questions(string $text): array { $json = json_decode(trim($text), true); if (!is_array($json) && preg_match('/\{.*\}/s', $text, $m)) { $json = json_decode($m[0], true); } if (!is_array($json)) { throw new \moodle_exception('errorprocessingbook','local_aisgk','','Không phân tích được JSON bài tập AI trả về: '.mb_substr($text,0,1000)); } $q = $json['questions'] ?? $json; if (!is_array($q)) { throw new \moodle_exception('errorprocessingbook','local_aisgk','','JSON bài tập AI không có questions.'); } return array_values(array_slice($q,0,12)); }
}
