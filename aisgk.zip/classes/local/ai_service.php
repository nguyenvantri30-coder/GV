<?php
namespace local_aisgk\local;

defined('MOODLE_INTERNAL') || die();

use local_aisgk\ai_key_manager;

class ai_service {
    protected static function user_prefers_personal_key(int $userid): bool {
        return $userid > 0 && (bool)get_user_preferences('local_aisgk_use_my_api', 0, $userid);
    }

    public static function extract_toc_from_images(array $images, int $userid = 0): array {
        $prompt = 'Trích xuất dữ liệu từ bảng mục lục trong ảnh. Kết quả chỉ xuất JSON hợp lệ dạng {"rows":[{"sobai":"","tenbai":"","trang":""}]}. Giữ nguyên thứ tự, chỉ lấy dòng mục lục thực sự và số trang.';
        $result = self::call('scan', $userid, self::user_prefers_personal_key($userid), $prompt, $images, true);
        $result['rows'] = self::extract_rows(self::response_text($result['response'], $result['provider']));
        unset($result['response']);
        return $result;
    }

    public static function generate_homework_questions(string $topicname, string $text, array $formula, int $userid = 0, array $options = []): array {
        $total = self::safe_total($options);
        $prompt = self::build_homework_prompt($topicname, '', 0, 0, $total, $options)
            . "\n\nNội dung bài học dạng văn bản:\n" . mb_substr($text, 0, 18000);
        $result = self::call('homework', $userid, self::user_prefers_personal_key($userid), $prompt, [], true);
        $raw = self::response_text($result['response'], $result['provider']);
        $result['rawtext'] = $raw;
        $result['questions'] = self::extract_questions($raw, $total, $options);
        $result['normalizedjson'] = self::questions_json($result['questions']);
        unset($result['response']);
        return $result;
    }

    public static function generate_homework_questions_from_images(
        string $topicname,
        array $images,
        int $pagefrom,
        int $pageto,
        int $userid = 0,
        array $options = [],
        string $bookname = ''
    ): array {
        $total = self::safe_total($options);
        $prompt = self::build_homework_prompt($topicname, $bookname, $pagefrom, $pageto, $total, $options);
        $result = self::call('homework', $userid, self::user_prefers_personal_key($userid), $prompt, $images, true);
        $raw = self::response_text($result['response'], $result['provider']);
        $result['rawtext'] = $raw;
        $result['questions'] = self::extract_questions($raw, $total, $options);
        $result['normalizedjson'] = self::questions_json($result['questions']);
        unset($result['response']);
        return $result;
    }

    protected static function safe_total(array $options): int {
        $total = (int)($options['total'] ?? 0);
        if ($total <= 0 && !empty($options['qtypes']) && is_array($options['qtypes'])) {
            $total = array_sum(array_map('intval', $options['qtypes']));
        }
        if ($total <= 0 && !empty($options['cognitive']) && is_array($options['cognitive'])) {
            $total = array_sum(array_map('intval', $options['cognitive']));
        }
        return max(1, min(60, $total ?: 8));
    }

    protected static function build_homework_prompt(string $topicname, string $bookname, int $pagefrom, int $pageto, int $total, array $options): string {
        $source = $bookname !== '' ? "- Sách/SGK: {$bookname}\n" : '';
        $pages = ($pagefrom > 0 && $pageto >= $pagefrom) ? "- Trang: {$pagefrom} → {$pageto}\n" : '';
        $configjson = json_encode($options, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
        $schema = self::active_schema_text($options);
        $allowedtypes = implode(', ', array_keys(self::active_qtype_counts($options)));
        $allowedlevels = implode(', ', array_keys(self::active_level_counts($options)));

        return "Bạn là giáo viên THCS tại Việt Nam.\n\n"
            . "Nhiệm vụ: tạo bài tập về nhà từ nội dung SGK trong ảnh/nội dung được cung cấp.\n\n"
            . "Nguồn:\n{$source}"
            . "- Tên bài/chủ đề: {$topicname}\n"
            . $pages
            . "QUESTION_PLAN BẮT BUỘC:\n"
            . "- JSON trả về phải có QUESTION_PLAN: từng câu, từng type, từng level.\n"
            . "- QUESTION_PLAN phải khớp 100% quota type/level; questions[i] đi đúng plan[i].\n\n"
            . "- Số câu cần tạo chính xác: {$total}\n\n"
            . "Cấu hình giáo viên gửi lên:\n{$configjson}\n\n"
            . "Yêu cầu nội dung:\n"
            . "- Đọc hiểu trực tiếp nội dung SGK; không suy diễn ngoài SGK.\n"
            . "- Hãy chú trọng đọc phần Mục tiêu bài học / Yêu cầu cần đạt nếu có. Phần này thường nằm trong khung màu, có biểu tượng mục tiêu, hoặc bắt đầu bằng các cụm như 'Sau bài học này em sẽ...', 'Yêu cầu cần đạt', 'Học xong bài này em có thể...'.\n"
            . "- Phần mục tiêu thường nằm ngay dưới tên bài, ở sidebar, hoặc trong khoảng 10 dòng đầu của trang đầu tiên của bài học.\n"
            . "- Chỉ tạo câu hỏi bám sát các năng lực, kiến thức và yêu cầu được nêu trong phần mục tiêu/yêu cầu cần đạt.\n"
            . "- Ưu tiên tham khảo phần bài tập/câu hỏi cuối bài nếu có, vì đây thường là hệ thống câu hỏi tác giả SGK đã định hướng.\n"
            . "- Bỏ qua header, footer, số trang, mục lục, watermark và rác quét.\n"
            . "- Level chỉ được viết nhan_biet / thong_hieu / van_dung. CẤM recognize / understand / apply trong JSON trả về.\n"
            . "- Ngôn ngữ câu hỏi phải phù hợp với ngôn ngữ nội dung bài học trong SGK.\n\n"
            . "RÀNG BUỘC BẮT BUỘC THEO CẤU HÌNH:\n"
            . "- CHỈ được dùng các type sau: {$allowedtypes}.\n"
            . "- CHỈ được dùng các level sau: {$allowedlevels}.\n"
            . "- Tuyệt đối không tạo type có số lượng = 0, không có trong options.qtypes, hoặc không được giáo viên chọn.\n"
            . "- Tuyệt đối không tạo level có số lượng = 0 hoặc không được giáo viên chọn.\n"
            . "- Số câu theo từng type phải đúng với số lượng trong options.qtypes. Type nào = 1 thì chỉ tạo đúng 1 câu type đó.\n"
            . "- Số câu theo từng level phải đúng với số lượng trong options.cognitive.\n"
            . "- name chỉ dùng dạng 'Câu 1', 'Câu 2'... Không thêm tên bài vào name.\n"
            . "- Nếu nội dung SGK không đủ thông tin cho một type được chọn, vẫn chỉ được dùng các type trong danh sách được phép; không tự ý đổi sang type khác.\n\n"
            . "CÔNG THỨC / KÝ HIỆU TOÁN, LÝ, HÓA:\n"
            . "- Nếu có công thức hoặc ký hiệu cần render, phải viết bằng LaTeX inline dạng \\( ... \\) hoặc block dạng \\[ ... \\].\n"
            . "- Vì đây là JSON, mọi dấu gạch chéo ngược trong công thức phải escape thành \\\\. Ví dụ viết \"\\\\(S = a \\\\times b\\\\)\" chứ không viết \"\\(S = a \\times b\\)\".\n"
            . "- Không dùng công thức dạng ảnh, không dùng HTML math tự chế, không dùng ký tự lạ làm hỏng JSON.\n\n"
            . "Chỉ trả JSON hợp lệ, không markdown, không giải thích, không thêm text ngoài JSON.\n"
            . "Tổng số phần tử trong questions phải đúng bằng {$total}. Nếu không thể đảm bảo JSON hợp lệ thì trả đúng: {\"questions\":[]}.\n\n"
            . "Cấu trúc chung bắt buộc:\n"
            . "{\"QUESTION_PLAN\":[{\"question_no\":1,\"type\":\"<theo options.qtypes>\",\"level\":\"nhan_biet|thong_hieu|van_dung\"}],\"questions\":[{\"type\":\"<theo options.qtypes>\",\"level\":\"<theo options.cognitive>\",\"name\":\"Câu 1\",\"questiontext\":\"...\"}]}\n\n"
            . "DANH SÁCH TYPE ĐƯỢC PHÉP VÀ SCHEMA TƯƠNG ỨNG, CHỈ DÙNG CÁC TYPE DƯỚI ĐÂY:\n"
            . $schema;
    }

    protected static function active_schema_text(array $options): string {
        $schemas = [
            'multichoice' => '- multichoice: có answers, mỗi phần tử {"text":"...","fraction":100 hoặc 0}; tổng fraction đáp án đúng bằng 100; nên có ít nhất 3 đáp án.',
            'truefalse' => '- truefalse: có answers gồm Đúng và Sai; một đáp án fraction 100, đáp án còn lại 0.',
            'shortanswer' => '- shortanswer: có answers [{"text":"đáp án ngắn","fraction":100}].',
            'numerical' => '- numerical: có answers [{"text":"giá trị số","fraction":100,"tolerance":0}].',
	    'matching' => '- matching: BẮT BUỘC type="matching"; có subquestions [{"question":"vế trái","answer":"vế phải"}], tối thiểu 2 cặp. Ưu tiên 3 đến 5 cặp nếu nội dung là trọng tâm bài học; nếu chỉ là ví dụ phụ thì chỉ cần 2–3 cặp. TẤT CẢ answer trong cùng một câu matching PHẢI khác nhau 100%, không được trùng hoặc tương đương quá giống nhau. Nếu có nguy cơ trùng, phải viết lại answer để phân biệt rõ ràng. Có thể dùng aliases pairs/items/matches nhưng sẽ được normalize về subquestions.',
	    'essay' => '- essay: chỉ cần questiontext; có thể thêm responseformat nếu biết.',
            'gapselect' => '- gapselect: questiontext phải có chỗ trống dạng [[1]], [[2]] và có choices [{"group":1,"text":"..."}].',
	    'ddwtos' => '- ddwtos: BẮT BUỘC type="ddwtos"; questiontext phải có blank Moodle dạng [[1]], [[2]]...; có choices [{"group":1,"text":"từ/cụm từ kéo thả"}]. Nếu AI dùng answers/correct/dragitems thì vẫn phải chuyển thành choices. Mỗi blank [[n]] phải có đúng một choice group=n tương ứng. TẤT CẢ choices.text trong cùng một câu ddwtos PHẢI khác nhau 100%, không được trùng hoặc tương đương quá giống nhau. Nếu có nguy cơ trùng, phải viết lại choice text để phân biệt rõ ràng.',
            'calculated' => '- calculated: BẮT BUỘC questiontext chứa biến Moodle như {a}, {b}, {x}; answers[0].text phải là công thức có biến như "{a}*{b}". KHÔNG dùng số cụ thể. Không dùng đáp án số tĩnh.',
            'calculatedsimple' => '- calculatedsimple: BẮT BUỘC questiontext chứa biến Moodle như {a}, {b}, {x}; answers[0].text phải là công thức có biến như "{a}*{b}". KHÔNG dùng số cụ thể. Không dùng đáp án số tĩnh.',
            'calculatedmulti' => '- calculatedmulti: BẮT BUỘC questiontext chứa biến Moodle như {a}, {b}, {x}; answers phải là công thức có biến như "{a}*{b}". KHÔNG dùng số cụ thể. Không dùng đáp án số tĩnh.',
            'description' => '- description: nội dung mô tả không tính điểm, chỉ dùng khi giáo viên chọn.',
            'ddimageortext' => '- ddimageortext: chỉ dùng nếu có thể mô tả kéo thả bằng text; tránh yêu cầu tọa độ ảnh phức tạp.',
            'ddmarker' => '- ddmarker: chỉ dùng nếu có thể mô tả marker rõ ràng; tránh yêu cầu tọa độ ảnh phức tạp.',
            'random' => '- random: không tạo nội dung câu hỏi cụ thể; chỉ dùng nếu giáo viên chọn rõ.',
        ];
        $active = self::active_qtype_counts($options);
        $lines = [];
        foreach ($active as $type => $count) {
            if (isset($schemas[$type])) {
                $lines[] = $schemas[$type] . ' Số lượng bắt buộc: ' . $count . '.';
            }
        }
        return $lines ? implode("\n", $lines) . "\n" : "- shortanswer: có answers [{\"text\":\"đáp án\",\"fraction\":100}].\n";
    }

    protected static function active_qtype_counts(array $options): array {
        $qtypes = [];
        if (!empty($options['qtypes']) && is_array($options['qtypes'])) {
            foreach ($options['qtypes'] as $type => $count) {
                $type = self::normalize_qtype((string)$type);
                $count = (int)$count;
                if ($type !== '' && $count > 0) {
                    $qtypes[$type] = $count;
                }
            }
        }
        if (!$qtypes) {
            $qtypes['shortanswer'] = self::safe_total($options);
        }
        return $qtypes;
    }

    protected static function active_level_counts(array $options): array {
        $map = ['recognize' => 'nhan_biet', 'understand' => 'thong_hieu', 'apply' => 'van_dung'];
        $levels = [];
        if (!empty($options['cognitive']) && is_array($options['cognitive'])) {
            foreach ($options['cognitive'] as $level => $count) {
                $level = $map[$level] ?? trim((string)$level);
                $count = (int)$count;
                if ($level !== '' && $count > 0) {
                    $levels[$level] = $count;
                }
            }
        }
        if (!$levels) {
            $levels['nhan_biet'] = self::safe_total($options);
        }
        return $levels;
    }

    protected static function call(string $feature, int $userid, bool $preferuser, string $prompt, array $images, bool $jsonmode): array {
        $attempted = [];
        $last = '';
        for ($try = 0; $try < 30; $try++) {
            $key = ai_key_manager::get_available_key($feature, $attempted, $userid, $preferuser, 0);
            if (!$key) { break; }
            $attempted[] = (string)($key->_source_table ?? 'local_aisgk_ai_keys') . ':' . (int)$key->id;
            $provider = ai_key_manager::provider_for_key($key);
            foreach (ai_key_manager::model_attempts_for_key($key, $feature) as $model) {
                $callkey = clone $key;
                if ($feature === 'homework') { $callkey->model_homework = $model; } else { $callkey->model_scan = $model; }
                try {
                    $payload = self::build_payload($provider, $model, $prompt, $images, $jsonmode);
                    $tokens = self::count_tokens($callkey, $provider, $model, $payload);
                    if (!ai_key_manager::can_use_key($callkey, $tokens)) {
                        $last = 'Key vượt giới hạn RPM/RPD/TPM';
                        continue;
                    }
                    $response = self::execute($callkey, $provider, $model, $payload);
                    $usage = ai_key_manager::mark_success($key, $tokens, $model, $userid, $feature);
                    return ['provider'=>$provider,'model'=>$model,'tokens'=>$tokens,'usage'=>$usage,'keysource'=>(string)($callkey->_source_table ?? 'system'),'category'=>(string)($callkey->category_key ?? 'free'),'response'=>$response];
                } catch (\Throwable $e) {
                    $last = $e->getMessage();
                    if (preg_match('/invalid api key|api key not valid|unauthorized|401/i', $last)) {
                        ai_key_manager::mark_blocked($key, $last);
                        break;
                    }
                    if (ai_key_manager::is_model_channel_error($last) || preg_match('/unsupported model|model not found|model.*not.*available/i', $last)) {
                        ai_key_manager::mark_model_blocked($key, $model, $feature, $last);
                        continue;
                    }
                    if (preg_match('/forbidden|permission denied|403/i', $last)) {
                        // 403 can be either key-level permission or model not enabled. Prefer blocking the current model first.
                        ai_key_manager::mark_model_blocked($key, $model, $feature, $last);
                        continue;
                    }
                    if (preg_match('/429|rate limit|resource exhausted|too many requests|quota/i', $last)) {
                        if (ai_key_manager::is_daily_quota_error($last)) {
                            ai_key_manager::mark_daily_quota($key, $last, $model, $feature);
                        } else {
                            ai_key_manager::mark_429($key, $last, $model, $feature);
                        }
                        continue;
                    }
                    ai_key_manager::mark_error($key, $last);
                }
            }
        }
        throw new \moodle_exception('errorprocessingbook', 'local_aisgk', '', 'Không có API key khả dụng hoặc key đang cooldown/bị lỗi. Lỗi cuối: ' . $last);
    }

    protected static function build_payload(string $provider, string $model, string $prompt, array $images, bool $jsonmode): array {
        if ($provider === 'shopaikey') {
            $content = [['type'=>'text','text'=>$prompt]];
            foreach ($images as $image) {
                $url = self::image_data_url($image);
                if ($url !== '') { $content[] = ['type'=>'image_url','image_url'=>['url'=>$url]]; }
            }
            $payload = ['model'=>$model,'messages'=>[['role'=>'user','content'=>$content]],'temperature'=>0.05,'max_tokens'=>12000];
            if ($jsonmode) { $payload['response_format'] = ['type'=>'json_object']; }
            return $payload;
        }
        $parts = [['text'=>$prompt]];
        foreach ($images as $image) {
            $inline = self::inline_image($image);
            if ($inline) { $parts[] = ['inlineData'=>$inline]; }
        }
        $payload = ['contents'=>[['parts'=>$parts]],'generationConfig'=>['temperature'=>0.05,'maxOutputTokens'=>12000]];
        if ($jsonmode) { $payload['generationConfig']['responseMimeType'] = 'application/json'; }
        return $payload;
    }

    protected static function execute(\stdClass $key, string $provider, string $model, array $payload): array {
        $apikey = trim((string)($key->api_key ?? ''));
        if ($apikey === '') { throw new \moodle_exception('errorprocessingbook', 'local_aisgk', '', 'API key rỗng.'); }
        if ($provider === 'shopaikey') {
            $url = 'https://api.shopaikey.com/v1/chat/completions';
            $headers = ['Content-Type: application/json', 'Authorization: Bearer ' . $apikey];
        } else {
            $url = 'https://generativelanguage.googleapis.com/v1beta/models/' . rawurlencode($model) . ':generateContent';
            $headers = ['Content-Type: application/json', 'X-goog-api-key: ' . $apikey];
        }
        $ch = curl_init($url);
        curl_setopt_array($ch, [CURLOPT_RETURNTRANSFER=>true,CURLOPT_POST=>true,CURLOPT_HTTPHEADER=>$headers,CURLOPT_POSTFIELDS=>json_encode($payload, JSON_UNESCAPED_UNICODE|JSON_UNESCAPED_SLASHES),CURLOPT_TIMEOUT=>180,CURLOPT_CONNECTTIMEOUT=>15]);
        $response = curl_exec($ch);
        $errno = curl_errno($ch);
        $error = curl_error($ch);
        $http = (int)curl_getinfo($ch, CURLINFO_RESPONSE_CODE);
        curl_close($ch);
        if ($errno) { throw new \moodle_exception('errorprocessingbook', 'local_aisgk', '', 'Lỗi kết nối API: ' . $error); }
        $json = json_decode((string)$response, true);
        if (!is_array($json)) { throw new \moodle_exception('errorprocessingbook', 'local_aisgk', '', 'API trả dữ liệu không hợp lệ: ' . mb_substr((string)$response,0,1000)); }
        if ($http >= 400 || !empty($json['error'])) {
            $err = $json['error'] ?? [];
            $msg = is_array($err) ? (string)($err['message'] ?? ('HTTP '.$http)) : (string)$err;
            throw new \moodle_exception('errorprocessingbook', 'local_aisgk', '', 'API_ERROR: ' . $msg);
        }
        return $json;
    }

    protected static function count_tokens(\stdClass $key, string $provider, string $model, array $payload): int {
        $total = 0;
        foreach (($payload['contents'] ?? []) as $content) {
            foreach (($content['parts'] ?? []) as $part) {
                if (!empty($part['text'])) { $total += (int)ceil(mb_strlen($part['text'], 'UTF-8') / 3); }
                if (!empty($part['inlineData']['data'])) {
                    $imgdata = base64_decode($part['inlineData']['data'], true);
                    if ($imgdata !== false) {
                        $info = @getimagesizefromstring($imgdata);
                        if ($info && !empty($info[0]) && !empty($info[1])) {
                            $w = (int)$info[0];
                            $h = (int)$info[1];
                            $total += ($w <= 384 && $h <= 384) ? 258 : (max(1, (int)ceil($w / 768)) * max(1, (int)ceil($h / 768)) * 258);
                        } else { $total += 2500; }
                    } else { $total += 2500; }
                }
            }
        }
        if ($total <= 0) {
            $raw = json_encode($payload, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
            $total = (int)ceil(strlen($raw) / 4);
        }
        return max(1, (int)$total);
    }

    protected static function inline_image(string $image): ?array {
        $data = @file_get_contents($image);
        if (!$data) { return null; }
        $ext = strtolower(pathinfo($image, PATHINFO_EXTENSION));
        $mime = ($ext === 'jpg' || $ext === 'jpeg') ? 'image/jpeg' : (($ext === 'webp') ? 'image/webp' : 'image/png');
        return ['mimeType'=>$mime,'data'=>base64_encode($data)];
    }

    protected static function image_data_url(string $image): string {
        $i = self::inline_image($image);
        return $i ? ('data:' . $i['mimeType'] . ';base64,' . $i['data']) : '';
    }

    protected static function response_text(array $json, string $provider): string {
        if ($provider === 'shopaikey') {
            $c = $json['choices'][0]['message']['content'] ?? '';
            if (is_array($c)) { return implode("\n", array_map(fn($p)=>(string)($p['text'] ?? ''), $c)); }
            return (string)$c;
        }
        $text = '';
        foreach (($json['candidates'] ?? []) as $cand) {
            foreach (($cand['content']['parts'] ?? []) as $p) {
                if (!empty($p['text'])) { $text .= $p['text']; }
            }
        }
        return $text;
    }

    protected static function decode_json_text(string $text, string $label): array {
        $clean = trim($text);
        $clean = preg_replace('/^```(?:json)?\s*/i', '', $clean);
        $clean = preg_replace('/\s*```$/', '', $clean);
        $json = json_decode($clean, true);
        if (!is_array($json)) {
            $start = strpos($clean, '{');
            $end = strrpos($clean, '}');
            if ($start !== false && $end !== false && $end > $start) {
                $slice = substr($clean, $start, $end - $start + 1);
                $json = json_decode($slice, true);
            }
        }
        if (!is_array($json)) {
            $err = json_last_error_msg();
            throw new \moodle_exception('errorprocessingbook', 'local_aisgk', '', $label . ': ' . $err . '. AI có thể đã trả JSON bị cắt ngang hoặc có dấu gạch chéo công thức chưa escape. Đoạn đầu: ' . mb_substr($text, 0, 1200));
        }
        return $json;
    }

    protected static function extract_rows(string $text): array {
        $json = self::decode_json_text($text, 'Không phân tích được JSON AI trả về');
        $rows = $json['rows'] ?? $json;
        if (!is_array($rows)) { throw new \moodle_exception('errorprocessingbook','local_aisgk','','JSON AI không có rows.'); }
        return $rows;
    }

    protected static function extract_questions(string $text, int $limit = 12, array $options = []): array {
        $json = self::decode_json_text($text, 'Không phân tích được JSON bài tập AI trả về');
        $questions = $json['questions'] ?? $json;
        if (!is_array($questions)) { throw new \moodle_exception('errorprocessingbook','local_aisgk','','JSON bài tập AI không có questions.'); }
        return self::validate_questions(array_values($questions), $limit, $options);
    }

    protected static function normalize_level(string $level): string {
        $level = strtolower(trim($level));
        $level = str_replace([' ', '-'], '_', $level);
        $map = [
            'recognize' => 'nhan_biet', 'recognise' => 'nhan_biet', 'nhận_biết' => 'nhan_biet', 'nhanbiet' => 'nhan_biet',
            'understand' => 'thong_hieu', 'thông_hiểu' => 'thong_hieu', 'thonghieu' => 'thong_hieu',
            'apply' => 'van_dung', 'vận_dụng' => 'van_dung', 'vandung' => 'van_dung'
        ];
        return $map[$level] ?? $level;
    }

    protected static function normalize_qtype(string $type): string {
        $type = strtolower(trim($type));
        $type = str_replace([' ', '-'], '_', $type);
        $map = [
            'multiplechoice' => 'multichoice',
            'multi_choice' => 'multichoice',
            'mcq' => 'multichoice',
            'true_false' => 'truefalse',
            'short_answer' => 'shortanswer',
            'number' => 'numerical',
            'numeric' => 'numerical',
            'match' => 'matching',
            'matches' => 'matching',
            'pairing' => 'matching',
            'pairs' => 'matching',
            'drag_drop_text' => 'ddwtos',
            'dragdroptext' => 'ddwtos',
            'drag_and_drop_text' => 'ddwtos',
            'drag_and_drop_into_text' => 'ddwtos',
            'drop_down' => 'gapselect',
            'dropdown' => 'gapselect',
            'calculated_simple' => 'calculatedsimple',
            'calculated_multi' => 'calculatedmulti',
        ];
        return $map[$type] ?? $type;
    }
    protected static function normalize_question_shape(array $q): array {
        // Chấp nhận cả type và qtype để không mất dữ liệu AI trả về khi debug.
        $type = self::normalize_qtype((string)($q['type'] ?? $q['qtype'] ?? ''));
        $q['type'] = $type;
        if (!isset($q['qtype']) && $type !== '') {
            $q['qtype'] = $type;
        }
        if (isset($q['level'])) {
            $q['level'] = self::normalize_level((string)$q['level']);
        }

        if ($type === 'matching') {
            if (empty($q['subquestions']) || !is_array($q['subquestions'])) {
                foreach (['pairs', 'items', 'matches'] as $alias) {
                    if (!empty($q[$alias]) && is_array($q[$alias])) {
                        $q['subquestions'] = $q[$alias];
                        break;
                    }
                }
            }
            $subs = [];
            foreach (($q['subquestions'] ?? []) as $row) {
                if (!is_array($row)) { continue; }
                $left = trim((string)($row['question'] ?? $row['left'] ?? $row['prompt'] ?? $row['term'] ?? $row['text'] ?? ''));
                $right = trim((string)($row['answer'] ?? $row['right'] ?? $row['match'] ?? $row['definition'] ?? $row['value'] ?? ''));
                // Giữ cả cặp thiếu dữ liệu để UI/validator chỉ rõ lỗi, không bỏ âm thầm.
                $subs[] = ['question' => $left, 'answer' => $right];
            }
            if (count($subs) < 2 && !empty($q['answers']) && is_array($q['answers'])) {
                foreach ($q['answers'] as $row) {
                    if (!is_array($row)) { continue; }
                    $left = trim((string)($row['question'] ?? $row['left'] ?? $row['prompt'] ?? $row['term'] ?? ''));
                    $right = trim((string)($row['answer'] ?? $row['right'] ?? $row['text'] ?? $row['definition'] ?? ''));
                    $subs[] = ['question' => $left, 'answer' => $right];
                }
            }
            if ($subs) {
                $q['subquestions'] = $subs;
            }
            unset($q['pairs'], $q['items'], $q['matches']);
            return $q;
        }

        if (in_array($type, ['gapselect', 'ddwtos'], true)) {
            $text = (string)($q['questiontext'] ?? $q['text'] ?? '');
            // Một số AI trả {1}, {2}; ddwtos Moodle cần [[1]], [[2]].
            $text = preg_replace('/\{(\d+)\}/', '[[$1]]', $text);
            $choices = [];
            foreach (($q['choices'] ?? []) as $choice) {
                if (is_array($choice)) {
                    $ctext = trim((string)($choice['text'] ?? $choice['answer'] ?? $choice['value'] ?? $choice['label'] ?? ''));
                    $group = (int)($choice['group'] ?? 1);
                } else {
                    $ctext = trim((string)$choice);
                    $group = 1;
                }
                if ($ctext !== '') {
                    $choices[] = ['group' => $group > 0 ? $group : 1, 'text' => $ctext];
                }
            }
            if (!empty($q['correct']) && is_array($q['correct'])) {
                foreach ($q['correct'] as $answer) {
                    $ctext = is_array($answer) ? trim((string)($answer['text'] ?? $answer['answer'] ?? $answer['value'] ?? '')) : trim((string)$answer);
                    if ($ctext !== '') {
                        $choices[] = ['group' => 1, 'text' => $ctext];
                    }
                }
            }
            if (!$choices && !empty($q['answers']) && is_array($q['answers'])) {
                foreach ($q['answers'] as $answer) {
                    if (is_array($answer)) {
                        $ctext = trim((string)($answer['text'] ?? $answer['answer'] ?? $answer['value'] ?? ''));
                    } else {
                        $ctext = trim((string)$answer);
                    }
                    if ($ctext !== '') {
                        $choices[] = ['group' => 1, 'text' => $ctext];
                    }
                }
            }
            if ($choices) {
                $seen = [];
                $cleanchoices = [];
                foreach ($choices as $choice) {
                    $key = mb_strtolower($choice['text']);
                    if (isset($seen[$key])) { continue; }
                    $seen[$key] = true;
                    $cleanchoices[] = $choice;
                }
                $q['choices'] = $cleanchoices;
            }
            if (!preg_match('/\[\[\d+\]\]/', $text) && !empty($q['choices'])) {
                $i = 1;
                $text = preg_replace_callback('/_{3,}|\.\.\.+|\[blank\]|\(blank\)|\{blank\}/iu', function() use (&$i) {
                    return '[[' . ($i++) . ']]';
                }, $text);
                if (!preg_match('/\[\[\d+\]\]/', $text)) {
                    $prefix = trim($text);
                    $text = ($prefix !== '' ? $prefix . ' ' : '') . implode(' ', array_map(function($n) { return '[[' . $n . ']]'; }, range(1, min(5, count($q['choices'])))));
                }
            }
            $q['questiontext'] = $text;
            return $q;
        }

        return $q;
    }

    public static function normalize_homework_questions(array $questions, array $options, int $limit = 0): array {
        // Phase debug: luôn đổ dữ liệu AI về JSON đã normalize, kể cả câu còn sai.
        // Không drop, không coerce, không tự sinh câu giả ở bước này; validator sẽ báo lỗi như cũ.
        $max = $limit > 0 ? max(1, min(60, $limit)) : 0;
        $out = [];
        foreach ($questions as $idx => $q) {
            if (!is_array($q)) {
                $q = ['type' => '', 'level' => '', 'name' => 'Câu ' . ($idx + 1), 'questiontext' => trim((string)$q)];
            }
            $q = self::normalize_question_shape($q);
            $q['type'] = self::normalize_qtype((string)($q['type'] ?? $q['qtype'] ?? ''));
            $q['qtype'] = $q['type'];
            $q['level'] = self::normalize_level((string)($q['level'] ?? ''));
            if (empty($q['name'])) {
                $q['name'] = 'Câu ' . ($idx + 1);
            }
            if (isset($q['questiontext'])) {
                $q['questiontext'] = trim((string)$q['questiontext']);
            } else {
                $q['questiontext'] = '';
            }
            $out[] = $q;
            if ($max > 0 && count($out) >= $max) {
                break;
            }
        }
        return array_values($out);
    }
    protected static function quota_is_complete(array $questions, array $allowedtypes, array $allowedlevels, int $max): bool {
        $target = min($max, array_sum($allowedtypes), array_sum($allowedlevels));
        if (count($questions) !== $target) { return false; }
        $counts = self::quota_counts($questions);
        foreach ($allowedtypes as $type => $n) { if (($counts['types'][$type] ?? 0) !== (int)$n) { return false; } }
        foreach ($allowedlevels as $level => $n) { if (($counts['levels'][$level] ?? 0) !== (int)$n) { return false; } }
        return true;
    }

    protected static function repair_questions_for_quota(array $selected, array $candidates, array $allowedtypes, array $allowedlevels, int $max): array {
        $target = min($max, array_sum($allowedtypes), array_sum($allowedlevels));
        $pool = array_values(array_merge($candidates, $selected));
        if (!$pool) {
            $pool[] = ['type' => self::first_allowed_key($allowedtypes), 'level' => self::first_allowed_key($allowedlevels), 'questiontext' => 'Nêu một kiến thức chính của bài học.', 'answers' => [['text' => 'Học sinh trả lời theo nội dung bài học.', 'fraction' => 100]]];
        }
        $out = array_values($selected);
        $guard = 0;
        while (!self::quota_is_complete($out, $allowedtypes, $allowedlevels, $target) && count($out) < $target && $guard++ < 200) {
            $counts = self::quota_counts($out);
            $needtype = self::first_missing_key($allowedtypes, $counts['types']);
            $needlevel = self::first_missing_key($allowedlevels, $counts['levels']);
            if ($needtype === '') { $needtype = self::first_allowed_key($allowedtypes); }
            if ($needlevel === '') { $needlevel = self::first_allowed_key($allowedlevels); }
            $base = $pool[($guard - 1) % count($pool)];
            $q = self::coerce_question_to_type($base, $needtype, $needlevel, count($out) + 1);
            if (self::is_valid_by_type($q)) { $out[] = $q; }
        }
        for ($pass = 0; $pass < 100 && !self::quota_is_complete($out, $allowedtypes, $allowedlevels, $target); $pass++) {
            $counts = self::quota_counts($out);
            $needtype = self::first_missing_key($allowedtypes, $counts['types']);
            $needlevel = self::first_missing_key($allowedlevels, $counts['levels']);
            $replace = self::find_surplus_question_index($out, $allowedtypes, $allowedlevels);
            if ($replace === null || ($needtype === '' && $needlevel === '')) { break; }
            $type = $needtype !== '' ? $needtype : (string)$out[$replace]['type'];
            $level = $needlevel !== '' ? $needlevel : (string)$out[$replace]['level'];
            $out[$replace] = self::coerce_question_to_type($out[$replace], $type, $level, $replace + 1);
        }
        return array_values(array_slice($out, 0, $target));
    }

    protected static function quota_counts(array $questions): array {
        $types = [];
        $levels = [];
        foreach ($questions as $q) {
            $t = (string)($q['type'] ?? '');
            $l = (string)($q['level'] ?? '');
            $types[$t] = ($types[$t] ?? 0) + 1;
            $levels[$l] = ($levels[$l] ?? 0) + 1;
        }
        return ['types' => $types, 'levels' => $levels];
    }

    protected static function first_missing_key(array $required, array $used): string {
        foreach ($required as $key => $n) { if (($used[$key] ?? 0) < (int)$n) { return (string)$key; } }
        return '';
    }

    protected static function first_allowed_key(array $allowed): string {
        foreach ($allowed as $key => $n) { if ((int)$n > 0) { return (string)$key; } }
        return '';
    }

    protected static function find_surplus_question_index(array $questions, array $allowedtypes, array $allowedlevels): ?int {
        $counts = self::quota_counts($questions);
        foreach ($questions as $i => $q) {
            $t = (string)($q['type'] ?? '');
            $l = (string)($q['level'] ?? '');
            if (($counts['types'][$t] ?? 0) > ($allowedtypes[$t] ?? 0) || ($counts['levels'][$l] ?? 0) > ($allowedlevels[$l] ?? 0)) { return $i; }
        }
        return null;
    }

    protected static function coerce_question_to_type(array $q, string $type, string $level, int $no): array {
        $q = self::normalize_question_shape($q);
        $q['type'] = $type;
        $q['level'] = $level;
        $text = trim((string)($q['questiontext'] ?? ''));
        if ($text === '') { $text = 'Câu hỏi số ' . $no . ' theo nội dung bài học.'; }
        $answers = self::answer_texts($q);
        if ($type === 'matching') {
            $left1 = self::short_text($text, 80) ?: 'Khái niệm 1';
            $right1 = $answers[0] ?? 'Nội dung phù hợp 1';
            $left2 = $answers[1] ?? 'Khái niệm 2';
            $right2 = $answers[2] ?? ($answers[0] ?? 'Nội dung phù hợp 2');
            $q['questiontext'] = 'Ghép các nội dung tương ứng theo bài học.';
            $q['subquestions'] = [['question' => $left1, 'answer' => $right1], ['question' => $left2, 'answer' => $right2]];
            unset($q['answers'], $q['choices']);
            return $q;
        }
        if (in_array($type, ['gapselect', 'ddwtos'], true)) {
            $choice1 = $answers[0] ?? self::short_text($text, 50) ?: 'nội dung chính';
            $choice2 = $answers[1] ?? 'kiến thức';
            $clean = trim(preg_replace('/\s+/u', ' ', strip_tags($text)) ?: '');
            if ($clean === '') { $clean = 'Hoàn thành nội dung theo bài học'; }
            if (!preg_match('/\[\[\d+\]\]/', $clean)) { $clean = 'Hoàn thành câu sau: [[1]] là một nội dung quan trọng trong bài học.'; }
            $q['questiontext'] = $clean;
            $q['choices'] = [['group' => 1, 'text' => $choice1], ['group' => 1, 'text' => $choice2]];
            unset($q['answers'], $q['subquestions']);
            return $q;
        }
        if (in_array($type, ['multichoice', 'truefalse', 'shortanswer', 'numerical'], true)) {
            if ($type === 'truefalse') {
                $q['answers'] = [['text' => 'Đúng', 'fraction' => 100], ['text' => 'Sai', 'fraction' => 0]];
            } else if ($type === 'numerical') {
                $q['answers'] = [['text' => '1', 'fraction' => 100, 'tolerance' => 0]];
            } else if ($type === 'multichoice') {
                $q['answers'] = [['text' => $answers[0] ?? 'Đáp án đúng', 'fraction' => 100], ['text' => $answers[1] ?? 'Đáp án nhiễu 1', 'fraction' => 0], ['text' => $answers[2] ?? 'Đáp án nhiễu 2', 'fraction' => 0]];
            } else {
                $q['answers'] = [['text' => $answers[0] ?? 'Học sinh trả lời theo nội dung bài học.', 'fraction' => 100]];
            }
            $q['questiontext'] = $text;
            unset($q['choices'], $q['subquestions']);
            return $q;
        }
        if (in_array($type, ['calculated', 'calculatedsimple', 'calculatedmulti'], true)) {
            $q['questiontext'] = preg_match('/\{[a-zA-Z][a-zA-Z0-9_]*\}/', $text) ? $text : ($text . ' Tính giá trị khi chiều dài là {a} và chiều rộng là {b}.');
            $q['answers'] = [['text' => '{a}*{b}', 'fraction' => 100, 'tolerance' => 0]];
            unset($q['choices'], $q['subquestions']);
            return $q;
        }
        $q['questiontext'] = $text;
        return $q;
    }

    protected static function answer_texts(array $q): array {
        $out = [];
        foreach (($q['answers'] ?? []) as $a) {
            $txt = is_array($a) ? trim((string)($a['text'] ?? $a['answer'] ?? $a['value'] ?? '')) : trim((string)$a);
            if ($txt !== '') { $out[] = $txt; }
        }
        foreach (($q['choices'] ?? []) as $a) {
            if (is_array($a)) { $txt = trim((string)($a['text'] ?? $a['answer'] ?? $a['value'] ?? '')); if ($txt !== '') { $out[] = $txt; } }
        }
        foreach (($q['subquestions'] ?? []) as $a) {
            if (is_array($a)) {
                foreach (['question', 'answer', 'left', 'right', 'term', 'definition'] as $k) { $txt = trim((string)($a[$k] ?? '')); if ($txt !== '') { $out[] = $txt; } }
            }
        }
        return array_values(array_unique($out));
    }

    protected static function short_text(string $text, int $limit): string {
        $text = trim(preg_replace('/\s+/u', ' ', strip_tags($text)) ?: '');
        if (function_exists('mb_substr')) { return mb_substr($text, 0, $limit); }
        return substr($text, 0, $limit);
    }
    protected static function select_questions_for_quota(array $candidates, array $allowedtypes, array $allowedlevels, int $max): array {
        $target = min($max, array_sum($allowedtypes), array_sum($allowedlevels));
        $best = [];
        $usedtypes = [];
        $usedlevels = [];
        $remaining = $candidates;
        while (count($best) < $target && $remaining) {
            $bestpos = null;
            $bestscore = -999999;
            foreach ($remaining as $pos => $q) {
                $type = (string)$q['type'];
                $level = (string)$q['level'];
                if (($usedtypes[$type] ?? 0) >= ($allowedtypes[$type] ?? 0)) { continue; }
                if (($usedlevels[$level] ?? 0) >= ($allowedlevels[$level] ?? 0)) { continue; }
                $typeneed = ($allowedtypes[$type] ?? 0) - ($usedtypes[$type] ?? 0);
                $levelneed = ($allowedlevels[$level] ?? 0) - ($usedlevels[$level] ?? 0);
                $score = ($typeneed * 1000) + ($levelneed * 100) - (int)($q['_ai_index'] ?? 0);
                if ($score > $bestscore) { $bestscore = $score; $bestpos = $pos; }
            }
            if ($bestpos === null) { break; }
            $q = $remaining[$bestpos];
            unset($remaining[$bestpos]);
            $type = (string)$q['type'];
            $level = (string)$q['level'];
            $usedtypes[$type] = ($usedtypes[$type] ?? 0) + 1;
            $usedlevels[$level] = ($usedlevels[$level] ?? 0) + 1;
            unset($q['_ai_index']);
            $q['name'] = 'Câu ' . (count($best) + 1);
            $best[] = $q;
        }
        return $best;
    }

    public static function validate_homework_against_plan(array $questions, array $options): array {
        $allowedtypes = self::active_qtype_counts($options);
        $allowedlevels = self::active_level_counts($options);
        $summary = ['qtypes' => [], 'levels' => []];
        foreach ($allowedtypes as $type => $count) { $summary['qtypes'][$type] = ['used' => 0, 'required' => (int)$count]; }
        foreach ($allowedlevels as $level => $count) { $summary['levels'][$level] = ['used' => 0, 'required' => (int)$count]; }
        $errors = [];
        foreach (array_values($questions) as $i => $q) {
            $no = $i + 1;
            if (!is_array($q)) { $errors[] = 'Câu ' . $no . ' không phải object JSON.'; continue; }
            $q = self::normalize_question_shape($q);
            $type = self::normalize_qtype((string)($q['type'] ?? ''));
            $level = self::normalize_level((string)($q['level'] ?? ''));
            if (empty($allowedtypes[$type])) { $errors[] = 'Câu ' . $no . ' type ' . ($type ?: '(trống)') . ' ngoài cấu hình.'; continue; }
            if (empty($allowedlevels[$level])) { $errors[] = 'Câu ' . $no . ' level ' . ($level ?: '(trống)') . ' ngoài cấu hình.'; continue; }
            $summary['qtypes'][$type]['used']++;
            $summary['levels'][$level]['used']++;
            foreach (self::type_validation_errors($q, $no) as $err) { $errors[] = $err; }
            if (in_array($type, ['calculated','calculatedsimple','calculatedmulti'], true)) {
                $answer = '';
                foreach (($q['answers'] ?? []) as $a) { $answer .= ' ' . (is_array($a) ? (string)($a['text'] ?? '') : ''); }
                if (!preg_match('/\{[a-z]/i', (string)($q['questiontext'] ?? '')) || !preg_match('/\{[a-z]/i', $answer)) {
                    $errors[] = 'Câu ' . $no . ' thiếu biến {a}/{b}/{x} trong đề hoặc đáp án.';
                }
            }
        }
        foreach ($summary['qtypes'] as $type => $v) {
            if ((int)$v['used'] !== (int)$v['required']) { $errors[] = 'Type ' . $type . ' sai số lượng (' . $v['used'] . '/' . $v['required'] . ').'; }
        }
        foreach ($summary['levels'] as $level => $v) {
            if ((int)$v['used'] !== (int)$v['required']) { $errors[] = 'Level ' . $level . ' sai số lượng (' . $v['used'] . '/' . $v['required'] . ').'; }
        }
        return ['ok' => empty($errors), 'errors' => $errors, 'summary' => $summary];
    }

    public static function questions_json(array $questions): string {
        return json_encode(['questions' => array_values($questions)], JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
    }

    protected static function validate_questions(array $questions, int $limit, array $options): array {
        $out = self::normalize_homework_questions($questions, $options, $limit);
        // Không ném lỗi mơ hồ ở đây nữa. Nếu chưa đủ quota, UI validator sẽ chỉ rõ
        // type/level/câu nào thiếu để giáo viên sửa JSON hoặc bấm tạo lại.
        return $out;
    }

    protected static function type_validation_errors(array $q, int $no): array {
        $type = (string)($q['type'] ?? '');
        $errors = [];
        if ($type === 'matching') {
            $subs = is_array($q['subquestions'] ?? null) ? array_values($q['subquestions']) : [];
            if (count($subs) < 2) {
                $errors[] = 'Câu ' . $no . ' matching cần tối thiểu 2 cặp subquestions question/answer.';
            }
            $answers = [];
            foreach ($subs as $i => $sq) {
                $left = is_array($sq) ? trim((string)($sq['question'] ?? '')) : '';
                $right = is_array($sq) ? trim((string)($sq['answer'] ?? '')) : '';
                if ($left === '' || $right === '') {
                    $errors[] = 'Câu ' . $no . ' matching cặp #' . ($i + 1) . ' thiếu question hoặc answer.';
                }
                if ($right !== '') {
                    $key = mb_strtolower($right);
                    if (isset($answers[$key])) {
                        $errors[] = 'Câu ' . $no . ' matching có đáp án trùng: ' . $right . '.';
                    }
                    $answers[$key] = true;
                }
            }
            return $errors;
        }
        if (in_array($type, ['gapselect', 'ddwtos'], true)) {
            $text = (string)($q['questiontext'] ?? '');
            preg_match_all('/\[\[(\d+)\]\]/', $text, $m);
            $blanks = array_values(array_unique($m[1] ?? []));
            $choices = is_array($q['choices'] ?? null) ? array_values($q['choices']) : [];
            if (!$blanks) {
                $errors[] = 'Câu ' . $no . ' ' . $type . ' cần questiontext có [[1]], [[2]]...';
            }
            if (!$choices) {
                $errors[] = 'Câu ' . $no . ' ' . $type . ' thiếu choices.';
            }
            foreach ($choices as $i => $choice) {
                $ctext = is_array($choice) ? trim((string)($choice['text'] ?? '')) : '';
                if ($ctext === '') {
                    $errors[] = 'Câu ' . $no . ' ' . $type . ' choice #' . ($i + 1) . ' thiếu text.';
                }
            }
            if ($blanks && $choices && count($choices) < count($blanks)) {
                $errors[] = 'Câu ' . $no . ' ' . $type . ' số choices ít hơn số chỗ trống (' . count($choices) . '/' . count($blanks) . ').';
            }
            return $errors;
        }
        return self::is_valid_by_type($q) ? [] : [self::type_validation_error($q, $no)];
    }
    protected static function type_validation_error(array $q, int $no): string {
        $type = (string)($q['type'] ?? '');
        if ($type === 'matching') {
            return 'Câu ' . $no . ' matching cần tối thiểu 2 cặp subquestions question/answer.';
        }
        if (in_array($type, ['gapselect', 'ddwtos'], true)) {
            return 'Câu ' . $no . ' ' . $type . ' cần questiontext có [[1]] và choices hợp lệ.';
        }
        if (in_array($type, ['calculated','calculatedsimple','calculatedmulti'], true)) {
            return 'Câu ' . $no . ' calculated cần biến {a}/{b}/{x} trong đề và công thức đáp án.';
        }
        return 'Câu ' . $no . ' thiếu dữ liệu bắt buộc cho type ' . $type . '.';
    }

    protected static function is_valid_by_type(array $q): bool {
        $type = (string)$q['type'];

        if (in_array($type, ['calculated', 'calculatedsimple', 'calculatedmulti'], true)) {
            if (empty($q['answers']) || !is_array($q['answers'])) {
                return false;
            }
            $questiontext = (string)($q['questiontext'] ?? '');
            $hasquestionvar = (bool)preg_match('/\{[a-zA-Z][a-zA-Z0-9_]*\}/', $questiontext);
            $hasanswervar = false;
            $sum = 0;
            foreach ($q['answers'] as $a) {
                if (!is_array($a) || trim((string)($a['text'] ?? '')) === '') {
                    return false;
                }
                $answertext = (string)$a['text'];
                if (preg_match('/\{[a-zA-Z][a-zA-Z0-9_]*\}/', $answertext)) {
                    $hasanswervar = true;
                }
                $sum += (float)($a['fraction'] ?? 0);
            }
            return $sum > 0 && $hasquestionvar && $hasanswervar;
        }

        if (in_array($type, ['multichoice', 'truefalse', 'shortanswer', 'numerical'], true)) {
            if (empty($q['answers']) || !is_array($q['answers'])) {
                return false;
            }
            $sum = 0;
            foreach ($q['answers'] as $a) {
                if (!is_array($a) || trim((string)($a['text'] ?? '')) === '') {
                    return false;
                }
                $sum += (float)($a['fraction'] ?? 0);
            }
            return $sum > 0;
        }
        if ($type === 'matching') {
            if (empty($q['subquestions']) || !is_array($q['subquestions']) || count($q['subquestions']) < 2) {
                return false;
            }
            foreach ($q['subquestions'] as $sq) {
                if (!is_array($sq) || trim((string)($sq['question'] ?? '')) === '' || trim((string)($sq['answer'] ?? '')) === '') {
                    return false;
                }
            }
            return true;
        }
        if (in_array($type, ['gapselect', 'ddwtos'], true)) {
            return !empty($q['choices']) && is_array($q['choices']) && preg_match('/\[\[\d+\]\]/', (string)$q['questiontext']);
        }
        return true;
    }
}
