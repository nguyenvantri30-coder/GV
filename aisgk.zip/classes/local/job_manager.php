<?php
namespace local_aisgk\local;

defined('MOODLE_INTERNAL') || die();

class job_manager {
    public static function create(string $jobtype, int $userid, string $resourcekey, array $payload = []): int {
        global $DB;
        $now = time();
        $record = (object)[
            'jobtype' => $jobtype,
            'status' => 'queued',
            'userid' => $userid,
            'resourcekey' => $resourcekey,
            'payloadjson' => json_encode($payload, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES),
            'resultjson' => '',
            'message' => get_string('jobqueued', 'local_aisgk'),
            'errormsg' => '',
            'stepno' => 1,
            'stepkey' => 'start',
            'steptext' => get_string('stepstart', 'local_aisgk'),
            'progress' => 5,
            'timecreated' => $now,
            'timeupdated' => $now,
            'timestarted' => 0,
            'timefinished' => 0,
        ];
        return (int)$DB->insert_record('local_aisgk_jobs', $record);
    }

    public static function get(int $id): ?\stdClass {
        global $DB;
        $r = $DB->get_record('local_aisgk_jobs', ['id' => $id]);
        return $r ?: null;
    }

    public static function find_active_by_resource(string $resourcekey, ?string $jobtype = null): ?\stdClass {
        global $DB;
        $params = [$resourcekey];
        $sql = "resourcekey = ? AND status IN ('queued','running')";
        if ($jobtype !== null) {
            $sql .= ' AND jobtype = ?';
            $params[] = $jobtype;
        }
        $records = $DB->get_records_select('local_aisgk_jobs', $sql, $params, 'id DESC', '*', 0, 1);
        return $records ? reset($records) : null;
    }

    public static function claim_next(string $jobtype): ?\stdClass {
        global $DB;
        $jobs = $DB->get_records('local_aisgk_jobs', ['jobtype' => $jobtype, 'status' => 'queued'], 'id ASC', '*', 0, 20);
        foreach ($jobs as $job) {
            if (self::find_running_same_resource($job->resourcekey, $job->id)) {
                continue;
            }
            $job->status = 'running';
            $job->timestarted = time();
            $job->timeupdated = time();
            $DB->update_record('local_aisgk_jobs', $job);
            return $job;
        }
        return null;
    }

    protected static function find_running_same_resource(string $resourcekey, int $excludeid): bool {
        global $DB;
        $sql = 'resourcekey = ? AND status = ? AND id <> ?';
        return $DB->record_exists_select('local_aisgk_jobs', $sql, [$resourcekey, 'running', $excludeid]);
    }

    public static function update_progress(int $jobid, int $stepno, string $stepkey, string $steptext, int $progress, string $message = ''): void {
        global $DB;
        $record = (object)[
            'id' => $jobid,
            'stepno' => $stepno,
            'stepkey' => $stepkey,
            'steptext' => $steptext,
            'progress' => max(0, min(100, $progress)),
            'message' => $message,
            'timeupdated' => time(),
        ];
        $DB->update_record('local_aisgk_jobs', $record);
    }

    public static function mark_done(int $jobid, array $result = [], string $message = ''): void {
        global $DB;
        $record = (object)[
            'id' => $jobid,
            'status' => 'done',
            'stepno' => 4,
            'stepkey' => 'result',
            'steptext' => get_string('stepresult', 'local_aisgk'),
            'progress' => 100,
            'message' => $message,
            'resultjson' => json_encode($result, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES),
            'timeupdated' => time(),
            'timefinished' => time(),
        ];
        $DB->update_record('local_aisgk_jobs', $record);
    }

    public static function mark_failed(int $jobid, string $message): void {
        global $DB;
        $record = (object)[
            'id' => $jobid,
            'status' => 'failed',
            'errormsg' => $message,
            'message' => $message,
            'timeupdated' => time(),
            'timefinished' => time(),
        ];
        $DB->update_record('local_aisgk_jobs', $record);
    }
}
