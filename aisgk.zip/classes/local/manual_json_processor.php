<?php
namespace local_aisgk\local;

defined('MOODLE_INTERNAL') || die();

/**
 * Xử lý thô JSON do giáo viên dán từ AI cá nhân trước khi đưa vào normalize/validate nội bộ.
 * Không validate schema Moodle ở đây để tránh đụng độ validator chính.
 */
class manual_json_processor {
    public static function decode(string $raw): array {
        $clean = self::clean($raw);
        $attempts = [];
        foreach ([$clean, self::repair_json_latex_slashes($clean), self::repair_unescaped_inner_quotes(self::repair_json_latex_slashes($clean))] as $candidate) {
            if ($candidate === '' || isset($attempts[$candidate])) { continue; }
            $attempts[$candidate] = true;
            $decoded = json_decode($candidate, true);
            if (is_array($decoded)) {
                return ['decoded' => $decoded, 'text' => $candidate, 'changed' => ($candidate !== $raw)];
            }
            if (is_string($decoded)) {
                $inner = trim($decoded);
                $decoded2 = json_decode($inner, true);
                if (is_array($decoded2)) {
                    return ['decoded' => $decoded2, 'text' => $inner, 'changed' => true];
                }
            }
        }
        $slice = self::first_balanced_json_slice($clean);
        if ($slice !== '' && $slice !== $clean) {
            return self::decode($slice);
        }
        return ['decoded' => null, 'text' => $clean, 'changed' => ($clean !== $raw), 'error' => json_last_error_msg()];
    }

    protected static function clean(string $raw): string {
        $text = trim($raw);
        $text = preg_replace('/^```(?:json)?\s*/iu', '', $text);
        $text = preg_replace('/\s*```$/u', '', $text);
        return trim($text);
    }

    protected static function first_balanced_json_slice(string $text): string {
        $start = -1;
        $open = '';
        $close = '';
        $len = strlen($text);
        for ($i = 0; $i < $len; $i++) {
            if ($text[$i] === '{' || $text[$i] === '[') {
                $start = $i;
                $open = $text[$i];
                $close = $open === '{' ? '}' : ']';
                break;
            }
        }
        if ($start < 0) { return ''; }
        $depth = 0;
        $instring = false;
        $escape = false;
        for ($i = $start; $i < $len; $i++) {
            $ch = $text[$i];
            if ($instring) {
                if ($escape) { $escape = false; continue; }
                if ($ch === '\\') { $escape = true; continue; }
                if ($ch === '"') { $instring = false; }
                continue;
            }
            if ($ch === '"') { $instring = true; continue; }
            if ($ch === $open) { $depth++; }
            if ($ch === $close) {
                $depth--;
                if ($depth === 0) { return substr($text, $start, $i - $start + 1); }
            }
        }
        return substr($text, $start);
    }

    protected static function repair_json_latex_slashes(string $text): string {
        $validsimple = '"\\/bfnrtu';
        $out = '';
        $len = strlen($text);
        for ($i = 0; $i < $len; $i++) {
            $ch = $text[$i];
            if ($ch !== '\\') { $out .= $ch; continue; }
            $next = ($i + 1 < $len) ? $text[$i + 1] : '';
            if ($next !== '' && strpos($validsimple, $next) !== false) {
                $out .= $ch . $next;
                $i++;
            } else {
                $out .= '\\\\';
            }
        }
        return $out;
    }

    protected static function repair_unescaped_inner_quotes(string $text): string {
        $out = '';
        $len = strlen($text);
        $instring = false;
        $escape = false;
        for ($i = 0; $i < $len; $i++) {
            $ch = $text[$i];
            if (!$instring) {
                $out .= $ch;
                if ($ch === '"') { $instring = true; }
                continue;
            }
            if ($escape) {
                $out .= $ch;
                $escape = false;
                continue;
            }
            if ($ch === '\\') {
                $out .= $ch;
                $escape = true;
                continue;
            }
            if ($ch === '"') {
                $j = $i + 1;
                while ($j < $len && preg_match('/\s/u', $text[$j])) { $j++; }
                $next = $j < $len ? $text[$j] : '';
                // Quote đóng chuỗi JSON hợp lệ thường đứng trước :, ,, }, ].
                // Quote trong nội dung như từ "GIA ĐÌNH" thường đứng trước chữ/số nên escape lại.
                if ($next === ':' || $next === ',' || $next === '}' || $next === ']' || $next === '') {
                    $out .= $ch;
                    $instring = false;
                } else {
                    $out .= '\\"';
                }
                continue;
            }
            $out .= $ch;
        }
        return $out;
    }
}
