<?php
namespace local_aisgk\local;

defined('MOODLE_INTERNAL') || die();

use local_aisgk\book_repository;

class sgk_processor {
    public const COMPONENT = 'local_aisgk';
    public const FILEAREA = 'bookpdf';

    protected static function get_book_record(int $bookid): \stdClass {
        $book = book_repository::get_by_id($bookid);
        if (!$book) {
            throw new \moodle_exception('invalidparameter');
        }
        return $book;
    }

    protected static function get_book_file(int $bookid): \stored_file {
        $book = self::get_book_record($bookid);
        $context = \context_course::instance((int)$book->courseid);
        $fs = get_file_storage();
        $files = $fs->get_area_files($context->id, self::COMPONENT, self::FILEAREA, (int)$book->fileitemid, 'itemid, filepath, filename', false);
        foreach ($files as $file) {
            if (!$file->is_directory()) {
                return $file;
            }
        }
        throw new \moodle_exception('bookrequired', 'local_aisgk');
    }

    public static function get_temp_dir(int $courseid, int $bookid): string {
        global $CFG;
        $dir = $CFG->dataroot . '/local_aisgk/tmp/' . $courseid . '/' . $bookid;
        if (!is_dir($dir)) {
            mkdir($dir, $CFG->directorypermissions, true);
        }
        return $dir;
    }

    public static function clear_temp_dir(int $courseid, int $bookid): void {
        $dir = self::get_temp_dir($courseid, $bookid);
        foreach (glob($dir . '/*') ?: [] as $file) {
            @unlink($file);
        }
    }

    protected static function export_pdf_to_temp(int $bookid): string {
        $book = self::get_book_record($bookid);
        $storedfile = self::get_book_file($bookid);
        $dir = self::get_temp_dir((int)$book->courseid, $bookid);
        $pdfpath = $dir . '/book_' . $bookid . '.pdf';
        @unlink($pdfpath);
        $storedfile->copy_content_to($pdfpath);
        if (!is_file($pdfpath) || filesize($pdfpath) < 1) {
            throw new \moodle_exception('errorprocessingbook', 'local_aisgk');
        }
        return $pdfpath;
    }

    public static function get_source_images(int $courseid, int $bookid): array {
        $images = glob(self::get_temp_dir($courseid, $bookid) . '/' . $bookid . '_*.png') ?: [];
        $images = array_values(array_filter($images, static function(string $path): bool {
            return (bool)preg_match('/_\d+\.png$/', $path);
        }));
        natsort($images);
        return array_values($images);
    }

    public static function render_toc_images(int $bookid, int $frompage, int $topage, int $dpi = 200, ?callable $progresscallback = null): array {
        $book = self::get_book_record($bookid);
        if ($frompage < 1 || $topage < $frompage) {
            throw new \invalid_parameter_exception('Khoảng trang không hợp lệ');
        }
        self::clear_temp_dir((int)$book->courseid, $bookid);
        $pdfpath = self::export_pdf_to_temp($bookid);
        $dir = self::get_temp_dir((int)$book->courseid, $bookid);
        return ocr_runner::render_pdf_pages($pdfpath, $dir, $bookid, $frompage, $topage, $dpi, $progresscallback);
    }


    public static function preview_topic_items_advanced(int $bookid, int $columns = 1, int $splitpercent = 50, int $psm = 4, ?int $pagefrom = null, ?int $pageto = null, ?callable $progresscallback = null): array {
        $book = self::get_book_record($bookid);
        $pagefrom = $pagefrom ?: (int)$book->tocfrompage;
        $pageto = $pageto ?: (int)$book->toctopage;

        if ($progresscallback) {
            $progresscallback([
                'step' => 1,
                'status' => 'running',
                'message' => 'Bước 1/4: Render trang mục lục từ PDF...',
            ]);
        }

        self::render_toc_images($bookid, $pagefrom, $pageto, 200, static function(int $done, int $total) use ($progresscallback): void {
            if ($progresscallback) {
                $progresscallback([
                    'step' => 1,
                    'status' => 'running',
                    'message' => 'Bước 1/4: Render trang mục lục từ PDF... (' . $done . '/' . $total . ')',
                ]);
            }
        });

        $images = self::get_source_images((int)$book->courseid, $bookid);
        if (!$images) {
            throw new \moodle_exception('bookimagesmissing', 'local_aisgk');
        }

        if ($progresscallback) {
            $progresscallback([
                'step' => 2,
                'status' => 'running',
                'message' => 'Dò 2 quả núi, xác định khe giữa hai cột... (' . count($images) . ' trang)',
            ]);
        }

        if ($progresscallback) {
            $progresscallback([
                'step' => 3,
                'status' => 'running',
                'message' => 'OCR song song từng nửa trang...',
            ]);
        }

        $texts = ocr_runner::ocr_images($images, $columns, $splitpercent, max(3, min(13, $psm)), 'vie+eng', static function(int $done, int $total) use ($progresscallback): void {
            if ($progresscallback) {
                $progresscallback([
                    'step' => 3,
                    'status' => 'running',
                    'message' => 'OCR song song từng nửa trang... (' . $done . '/' . $total . ')',
                ]);
            }
        });

        if ($progresscallback) {
            $progresscallback([
                'step' => 4,
                'status' => 'running',
                'message' => 'Ghép dòng, lọc Bài/Chương và tính trang...',
            ]);
        }

        $raw = implode("\n\n", $texts);
        $lines = self::normalize_lines($raw);
        $items = self::parse_bai_lines($lines);
        $items = self::calculate_item_end_pages($items);

        if ($progresscallback) {
            $progresscallback([
                'step' => 4,
                'status' => 'done',
                'message' => 'Bước 4/4: Hoàn tất. Tìm được ' . count($items) . ' dòng phù hợp.',
                'itemcount' => count($items),
            ]);
        }

        return [
            'raw' => $raw,
            'content_lines' => $lines,
            'matched_lines' => array_values(array_map(static fn($item) => $item['rawocr'], $items)),
            'items' => $items,
        ];
    }

    public static function preview_topic_items(int $bookid, int $columns = 1, int $splitpercent = 50, int $psm = 4, ?int $pagefrom = null, ?int $pageto = null): array {
        $book = self::get_book_record($bookid);
        $pagefrom = $pagefrom ?: (int)$book->tocfrompage;
        $pageto = $pageto ?: (int)$book->toctopage;
        self::render_toc_images($bookid, $pagefrom, $pageto, 200);
        $images = self::get_source_images((int)$book->courseid, $bookid);
        if (!$images) {
            throw new \moodle_exception('bookimagesmissing', 'local_aisgk');
        }

        $texts = ocr_runner::ocr_images($images, $columns, $splitpercent, max(3, min(13, $psm)));
        $raw = implode("\n\n", $texts);
        $lines = self::normalize_lines($raw);
        $items = self::parse_bai_lines($lines);
        $items = self::calculate_item_end_pages($items);

        return [
            'raw' => $raw,
            'content_lines' => $lines,
            'matched_lines' => array_values(array_map(static fn($item) => $item['rawocr'], $items)),
            'items' => $items,
        ];
    }

    protected static function calculate_item_end_pages(array $items): array {
        $count = count($items);
        for ($i = 0; $i < $count; $i++) {
            $curr = $items[$i]['startpage'] ?? null;
            $next = $items[$i + 1]['startpage'] ?? null;
            if ($curr !== null && $next !== null && $next > $curr) {
                $items[$i]['endpage'] = $next - 1;
            }
        }
        return $items;
    }

    protected static function normalize_lines(string $raw): array {
        $raw = preg_replace("/\r\n|\r/u", "\n", $raw);
        $lines = explode("\n", $raw);
        $lines = array_map(static function(string $line): string {
            $line = preg_replace('/\s+/u', ' ', trim($line));
            $line = preg_replace('/[.…·•]{2,}/u', ' ', $line);
            return trim($line);
        }, $lines);
        $lines = array_values(array_filter($lines, static fn($line) => $line !== ''));
        return self::merge_wrapped_lines($lines);
    }

    protected static function merge_wrapped_lines(array $lines): array {
        $merged = [];
        foreach ($lines as $line) {
            if (!$merged) {
                $merged[] = $line;
                continue;
            }
            $previndex = count($merged) - 1;
            $prev = $merged[$previndex];
            $append = false;
            if (preg_match('/^(và|của|trong|với|theo|ở|cho|về|từ)\b/ui', $line)) {
                $append = true;
            }
            if (preg_match('/^(\d{1,3})$/', $line)) {
                $merged[$previndex] = trim($prev . ' ' . $line);
                continue;
            }
            if ($append) {
                $merged[$previndex] = trim($prev . ' ' . $line);
                continue;
            }
            $merged[] = $line;
        }
        return $merged;
    }

    public static function is_target_line(string $line): bool {
        $line = trim(preg_replace('/\s+/u', ' ', $line));
        if ($line === '') {
            return false;
        }
        if (preg_match('/^(MỤC LỤC|MUC LUC|TRANG|Trang)$/iu', $line)) {
            return false;
        }
        return (bool)preg_match('/^(Bài\s+\d+|Chương\s+[IVX\d]+|CHƯƠNG\s+[IVX\d]+|Luyện tập|Ôn tập|Bài tập cuối chương|Hoạt động)\b/ui', $line);
    }

    public static function parse_bai_lines(array $lines): array {
        $items = [];
        foreach ($lines as $line) {
            if (!self::is_target_line($line)) {
                continue;
            }

            $line = preg_replace('/\s+/u', ' ', trim($line));
            $startpage = null;
            if (preg_match('/\b(\d{1,4})\s*$/u', $line, $m)) {
                $startpage = (int)$m[1];
                $line = trim(preg_replace('/\b\d{1,4}\s*$/u', '', $line));
            }

            $lessonno = null;
            $title = $line;
            if (preg_match('/^Bài\s+(\d+)\.?\s*(.*)$/ui', $line, $m)) {
                $lessonno = (int)$m[1];
                $title = trim($m[2]);
            }

            $items[] = [
                'lessonno' => $lessonno,
                'lessontitle' => $title,
                'startpage' => $startpage,
                'endpage' => null,
                'rawocr' => $line . ($startpage ? ' ' . $startpage : ''),
            ];
        }
        return $items;
    }
}
