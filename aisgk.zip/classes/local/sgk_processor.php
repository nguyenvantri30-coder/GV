<?php
namespace local_aisgk\local;
defined('MOODLE_INTERNAL') || die();
use local_aisgk\book_repository;
class sgk_processor {
    const COMPONENT = 'local_aisgk';
    const FILEAREA = 'bookpdf';
    protected static function debug_log($label, $data): void {
        $file = '/var/www/html/moodle/local/aisgk/ocr_debug.log';
        $out = "===== " . $label . " =====\n";
        if (is_array($data)) {
            foreach ($data as $k => $v) {
                if (is_array($v)) {
                    $out .= $k . ': ' . json_encode($v, JSON_UNESCAPED_UNICODE) . "\n";
                } else {
                    $out .= $v . "\n";
                }
            }
        } else {
            $out .= $data . "\n";
        }
        $out .= "\n";
        file_put_contents($file, $out, FILE_APPEND);
    }
    protected static function get_context_for_book(int $courseid): \context_course {
        return \context_course::instance($courseid);
    }
    protected static function get_book_record(int $bookid): \stdClass {
        $book = book_repository::get_by_id($bookid);
        if (!$book) {
            throw new \moodle_exception('invalidparameter');
        }
        return $book;
    }
    protected static function get_book_file(int $bookid): \stored_file {
        $book = self::get_book_record($bookid);
        $context = self::get_context_for_book((int)$book->courseid);
        $fs = get_file_storage();
        $files = $fs->get_area_files(
            $context->id,
            self::COMPONENT,
            self::FILEAREA,
            (int)$book->fileitemid,
            'itemid, filepath, filename',
            false
        );
        foreach ($files as $file) {
            if (!$file->is_directory()) {
                return $file;
            }
        }
        throw new \moodle_exception('bookrequired', 'local_aisgk');
    }
    public static function get_temp_dir(int $courseid, int $bookid): string {
        global $CFG;
        $dir = $CFG->dataroot . '/local_aisgk/tmp/' . $courseid . '/' . $bookid;
        if (!is_dir($dir)) {
            mkdir($dir, $CFG->directorypermissions, true);
        }
        return $dir;
    }
    public static function clear_temp_dir(int $courseid, int $bookid): void {
        $dir = self::get_temp_dir($courseid, $bookid);
        foreach (['*.png', '*.txt', '*.pdf', '*.log'] as $pattern) {
            foreach (glob($dir . '/' . $pattern) ?: [] as $file) {
                @unlink($file);
            }
        }
    }
    protected static function export_pdf_to_temp(int $bookid): string {
        $book = self::get_book_record($bookid);
        $storedfile = self::get_book_file($bookid);
        $dir = self::get_temp_dir((int)$book->courseid, $bookid);
        $pdfpath = $dir . '/book_' . $bookid . '.pdf';
        if (file_exists($pdfpath)) {
            @unlink($pdfpath);
        }
        $storedfile->copy_content_to($pdfpath);
        if (!file_exists($pdfpath) || filesize($pdfpath) <= 0) {
            throw new \moodle_exception('errorprocessingbook', 'local_aisgk');
        }
        return $pdfpath;
    }
    public static function get_mucluc(int $bookid, int $tutrang, int $dentrang, int $donet = 200): array {
        $book = self::get_book_record($bookid);
        if ($tutrang <= 0 || $dentrang <= 0 || $tutrang > $dentrang) {
            throw new \invalid_parameter_exception('Khoảng trang không hợp lệ');
        }
        $donet = max(72, min(250, $donet));
        self::clear_temp_dir((int)$book->courseid, $bookid);
        $pdfpath = self::export_pdf_to_temp($bookid);
        $dir = self::get_temp_dir((int)$book->courseid, $bookid);
        $index = 1;
        for ($page = $tutrang; $page <= $dentrang; $page++, $index++) {
            $out = $dir . '/' . $bookid . '_' . $index . '.png';
            $tmpdir = escapeshellarg($dir);
            $cmd = sprintf(
                'TMPDIR=%s TEMP=%s TMP=%s /usr/bin/gs -dSAFER -dBATCH -dNOPAUSE -sDEVICE=pnggray -r%d -dFirstPage=%d -dLastPage=%d -sOutputFile=%s %s 2>&1',
                $tmpdir,
                $tmpdir,
                $tmpdir,
                $donet,
                $page,
                $page,
                escapeshellarg($out),
                escapeshellarg($pdfpath)
            );
            exec($cmd, $output, $returnvar);
            if ($returnvar !== 0 || !file_exists($out)) {
                throw new \moodle_exception('errorprocessingbook', 'local_aisgk', '', null, implode("\n", $output));
            }
        }
        return self::get_source_images((int)$book->courseid, $bookid);
    }
    protected static function preprocess_image_for_ocr(string $imagepath): string {
        $outpath = preg_replace('/\.png$/i', '_prep.png', $imagepath);
        $cmd = sprintf(
            '/usr/bin/convert %s -colorspace Gray -auto-level -sharpen 0x0.8 -deskew 40%% %s 2>&1',
            escapeshellarg($imagepath),
            escapeshellarg($outpath)
        );
        exec($cmd, $output, $returnvar);
        if ($returnvar !== 0 || !file_exists($outpath)) {
            throw new \moodle_exception('errorprocessingbook', 'local_aisgk', '', null, implode("\n", $output));
        }
        return $outpath;
    }
    protected static function ocr_one_tesseract(string $imagepath, string $lang = 'vie', int $psm = 3): string {
        $txtbase = preg_replace('/\.png$/i', '', $imagepath);
        $psm = max(3, min(13, (int)$psm));
        $cmd = sprintf(
            '/usr/bin/tesseract %s %s -l %s --psm %d -c preserve_interword_spaces=1 2>&1',
            escapeshellarg($imagepath),
            escapeshellarg($txtbase),
            escapeshellarg('vie+eng'),
            $psm
        );
        exec($cmd, $output, $returnvar);
        if ($returnvar !== 0) {
            throw new \moodle_exception('errorprocessingbook', 'local_aisgk', '', null, implode("\n", $output));
        }
        $txtfile = $txtbase . '.txt';
        return file_exists($txtfile) ? trim((string)file_get_contents($txtfile)) : '';
    }
    protected static function count_nonempty_lines(string $text): int {
        $count = 0;
        foreach (preg_split('/\R/u', $text) as $line) {
            if (trim((string)$line) !== '') {
                $count++;
            }
        }
        return $count;
    }
    public static function ocr_img(int $bookid, string $engine_default = 'tesseract', int $columns = 1, int $splitpercent = 50, int $psm = 3): array {
        $book = self::get_book_record($bookid);
        $images = self::get_source_images((int)$book->courseid, $bookid);
        if (empty($images)) {
            throw new \moodle_exception('bookimagesmissing', 'local_aisgk');
        }
        $results = [];
        foreach ($images as $img) {
            $text = self::ocr_one_image($img, $columns, $splitpercent, 'vie', $psm);
            $linecount = self::count_nonempty_lines($text);
            if ($linecount < 2) {
                $prep = self::preprocess_image_for_ocr($img);
                $preptext = self::ocr_one_image($prep, $columns, $splitpercent, 'vie', $psm);
                if (self::count_nonempty_lines($preptext) >= $linecount) {
                    $text = $preptext;
                }
            }
            $results[] = [
                'file' => basename($img),
                'path' => $img,
                'text' => $text,
            ];
        }
        return [
            'engine' => 'tesseract',
            'files' => $results,
            'joined' => implode("\n\n", array_column($results, 'text')),
        ];
    }
    public static function orc_img(int $bookid, string $engine_default = 'tesseract', int $columns = 1, int $splitpercent = 50, int $psm = 3): array {
        return self::ocr_img($bookid, $engine_default, $columns, $splitpercent, $psm);
    }
    public static function preview_topic_lines(int $bookid, int $tutrang = 4, int $dentrang = 5, int $columns = 1, int $splitpercent = 50, int $psm = 3): array {
        self::get_mucluc($bookid, $tutrang, $dentrang, 200);
        $ocr = self::ocr_img($bookid, 'tesseract', $columns, $splitpercent, $psm);
        $raw = $ocr['joined'];
        self::debug_log('RAW OCR', $raw);
        $normalized = preg_replace("/\r\n|\r/u", "\n", $raw);
        $lines = explode("\n", $normalized);
        self::debug_log('LINES (RAW SPLIT)', $lines);
        $lines = self::merge_wrapped_lines($lines);
        self::debug_log('LINES (AFTER MERGE)', $lines);
        $contentlines = array_values(array_filter(array_map('trim', $lines)));
        $matched = [];
        foreach ($contentlines as $line) {
            if (self::is_target_line($line)) {
                $matched[] = $line;
            }
        }
        self::debug_log('LINES (MATCHED)', $matched);
        return [
            'raw' => $raw,
            'content_lines' => $contentlines,
            'matched_lines' => $matched,
            'preview' => implode("\n", $matched),
        ];
    }
    protected static function merge_wrapped_lines(array $lines): array {
        $lines = array_values(array_filter(array_map(function($line) {
            $line = preg_replace('/\s+/u', ' ', trim((string)$line));
            return $line;
        }, $lines), function($line) {
            return $line !== '';
        }));
        $result = [];
        foreach ($lines as $line) {
            $line = trim((string)$line);
            if ($line === '') {
                continue;
            }
            if (empty($result)) {
                $result[] = $line;
                continue;
            }
            $previndex = count($result) - 1;
            $prev = trim((string)$result[$previndex]);
            $firstchar = null;
            if (preg_match('/\p{L}/u', $line, $m, PREG_OFFSET_CAPTURE)) {
                $offset = $m[0][1];
                $firstchar = mb_substr($line, $offset, 1, 'UTF-8');
            }
            $islowerstart = false;
            $isupperstart = false;
            if ($firstchar !== null) {
                $islowerstart = (
                    mb_strtolower($firstchar, 'UTF-8') === $firstchar &&
                    mb_strtoupper($firstchar, 'UTF-8') !== $firstchar
                );
                $isupperstart = (
                    mb_strtoupper($firstchar, 'UTF-8') === $firstchar &&
                    mb_strtolower($firstchar, 'UTF-8') !== $firstchar
                );
            }
            if ($islowerstart) {
                $result[$previndex] = trim($prev . ' ' . $line);
                continue;
            }
            if (preg_match('/\.\s*$/u', $prev) && $isupperstart) {
                $result[$previndex] = trim($prev . ' ' . $line);
                continue;
            }
            $result[] = $line;
        }
        return $result;
    }
    private static function merge_wrapped_lines_old(array $lines): array {
        $merged = [];
        $buffer = '';
        foreach ($lines as $line) {
            $line = trim((string)$line);
            $line = preg_replace('/\s+/u', ' ', $line);
            if ($line === '') {
                continue;
            }
            if (preg_match('/^(MỤC LỤC|Má»¤C Lá»¤C|Trang|TRANG)$/iu', $line)
                || preg_match('/^[=\-\._\s]+$/u', $line)) {
                continue;
        }
        $startswithupper = (bool)preg_match('/^\p{Lu}/u', $line);
        if ($buffer === '') {
            $buffer = $line;
            continue;
        }
        if ($startswithupper) {
            $merged[] = trim($buffer);
            $buffer = $line;
            continue;
        }
        $buffer .= ' ' . $line;
        $buffer = trim(preg_replace('/\s+/u', ' ', $buffer));
    }
    if ($buffer !== '') {
        $merged[] = trim($buffer);
    }
    return $merged;
}
public static function parse_bai_lines(array $lines): array {
    $items = [];
    foreach ($lines as $line) {
        $line = trim((string)$line);
        if ($line === '') {
            continue;
        }
        $line = preg_replace('/\s+/u', ' ', $line);
        $line = preg_replace('/[.…]{2,}/u', ' ', $line);
        if (!self::is_target_line($line)) {
            continue;
        }
        $lessonno = null;
        $lessontitle = '';
        $startpage = null;
        if (preg_match('/^(?:Bài|BÃ\s*i)\s+(\d+)\.?\s*(.+?)\s+(\d{1,4})\s*$/ui', $line, $m)) {
            $lessonno = (int)$m[1];
            $lessontitle = trim($m[2]);
            $startpage = (int)$m[3];
        } else if (preg_match('/^(?:Bài|BÃ\s*i)\s+(\d+)\.?\s*(.+)$/ui', $line, $m)) {
            $lessonno = (int)$m[1];
            $lessontitle = trim($m[2]);
            $startpage = null;
        } else if (preg_match('/^(Bảng giải thích.+?)\s+(\d{1,4})\s*$/ui', $line, $m)) {
            $lessonno = null;
            $lessontitle = trim($m[1]);
            $startpage = (int)$m[2];
        } else {
            continue;
        }
        $items[] = [
            'lessonno' => $lessonno,
            'lessontitle' => $lessontitle,
            'startpage' => $startpage,
            'endpage' => null,
            'rawocr' => $line,
        ];
    }
    return $items;
}
public static function preview_topic_items(int $bookid, int $columns = 1, int $splitpercent = 50, int $psm = 3): array {
    $book = self::get_book_record($bookid);
    $preview = self::preview_topic_lines(
        $bookid,
        (int)$book->tocfrompage,
        (int)$book->toctopage,
        $columns,
        $splitpercent,
        $psm
    );
    $matched = [];
    foreach ($preview['content_lines'] as $line) {
        if (self::is_target_line($line)) {
            $matched[] = $line;
        }
    }
    $items = self::parse_bai_lines($matched);
    return [
        'raw' => $preview['raw'],
        'content_lines' => $preview['content_lines'],
        'matched_lines' => $matched,
        'items' => $items,
    ];
}
public static function is_target_line(string $line): bool {
    $line = trim(preg_replace('/\s+/u', ' ', $line));
    if ($line === '') {
        return false;
    }
    if (preg_match('/^(MỤC LỤC|Má»¤C Lá»¤C|Trang|TRANG)$/iu', $line)) {
        return false;
    }
    if (preg_match('/^(?:Bài|BÃ\s*i)\s+\d+\b/ui', $line)) {
        return true;
    }
    if (preg_match('/^(?:Bảng giải thích|Báº£ng giáº£i thÃ­ch)\b/ui', $line)) {
        return true;
    }
    return false;
}
    /* =======================
     * ===== 2 COLUMN ========
     * ======================= */
    protected static function normalize_column_options(int $columns, int $splitpercent): array {
        $columns = ($columns === 2) ? 2 : 1;
        $splitpercent = max(20, min(80, $splitpercent));
        return [$columns, $splitpercent];
    }
    protected static function get_source_images(int $courseid, int $bookid): array {
        $dir = self::get_temp_dir($courseid, $bookid);
        $allfiles = glob($dir . '/' . $bookid . '_*.png') ?: [];
        $images = array_values(array_filter($allfiles, function($file) use ($bookid) {
            return preg_match('/\/' . preg_quote((string)$bookid, '/') . '_\d+\.png$/', $file);
        }));
        natsort($images);
        return array_values($images);
    }
    protected static function get_image_dimensions(string $imagepath): array {
        $cmd = sprintf(
            '/usr/bin/identify -format %s %s 2>&1',
            escapeshellarg('%w %h'),
            escapeshellarg($imagepath)
        );
        exec($cmd, $output, $returnvar);
        if ($returnvar !== 0 || empty($output[0])) {
            throw new \moodle_exception('errorprocessingbook', 'local_aisgk', '', null, implode("\n", $output));
        }
        $parts = preg_split('/\s+/', trim((string)$output[0]));
        $width = isset($parts[0]) ? (int)$parts[0] : 0;
        $height = isset($parts[1]) ? (int)$parts[1] : 0;
        if ($width <= 0 || $height <= 0) {
            throw new \moodle_exception('errorprocessingbook', 'local_aisgk', '', null, 'Invalid image size: ' . $imagepath);
        }
        return [$width, $height];
    }
    protected static function crop_image(string $src, string $dest, int $width, int $height, int $x, int $y = 0): void {
        $cmd = sprintf(
            '/usr/bin/convert %s -crop %s +repage %s 2>&1',
            escapeshellarg($src),
            escapeshellarg($width . 'x' . $height . '+' . $x . '+' . $y),
            escapeshellarg($dest)
        );
        exec($cmd, $output, $returnvar);
        if ($returnvar !== 0 || !file_exists($dest) || filesize($dest) <= 0) {
            throw new \moodle_exception('errorprocessingbook', 'local_aisgk', '', null, implode("\n", $output));
        }
    }
    protected static function get_debug_output_dir(): string {
        return '/var/www/html/moodle/local/aisgk';
    }
    protected static function save_debug_crop(string $src, string $name, int $width, int $height, int $x, int $y = 0): void {
        if ($width < 1 || $height < 1) {
            return;
        }
        $dest = self::get_debug_output_dir() . '/' . $name;
        self::crop_image($src, $dest, $width, $height, $x, $y);
    }
    protected static function ocr_one_tesseract_exact(string $imagepath, string $lang = 'vie+eng', int $psm = 6, string $whitelist = ''): string {
        $txtbase = preg_replace('/\.png$/i', '', $imagepath) . '_ocr';
        $psm = max(3, min(13, (int)$psm));
        $extra = ' -c preserve_interword_spaces=1';
        if ($whitelist !== '') {
            $extra .= ' -c tessedit_char_whitelist=' . escapeshellarg($whitelist);
        }
        $cmd = sprintf(
            '/usr/bin/tesseract %s %s -l %s --psm %d%s 2>&1',
            escapeshellarg($imagepath),
            escapeshellarg($txtbase),
            escapeshellarg($lang),
            $psm,
            $extra
        );
        exec($cmd, $output, $returnvar);
        if ($returnvar !== 0) {
            throw new \moodle_exception('errorprocessingbook', 'local_aisgk', '', null, implode("\n", $output));
        }
        $txtfile = $txtbase . '.txt';
        return file_exists($txtfile) ? trim((string)file_get_contents($txtfile)) : '';
    }
    protected static function preprocess_image_for_ocr_2col(string $imagepath, string $suffix = 'prep2'): string {
        $outpath = preg_replace('/\.png$/i', '_' . $suffix . '.png', $imagepath);
        $cmd = sprintf(
            '/usr/bin/convert %s -colorspace Gray -gaussian-blur 0x0.35 -auto-threshold OTSU -despeckle %s 2>&1',
            escapeshellarg($imagepath),
            escapeshellarg($outpath)
        );
        exec($cmd, $output, $returnvar);
        if ($returnvar !== 0 || !file_exists($outpath)) {
            $fallbackcmd = sprintf(
                '/usr/bin/convert %s -colorspace Gray -gaussian-blur 0x0.35 -threshold 55%% -despeckle %s 2>&1',
                escapeshellarg($imagepath),
                escapeshellarg($outpath)
            );
            exec($fallbackcmd, $output2, $returnvar2);
            if ($returnvar2 !== 0 || !file_exists($outpath)) {
                throw new \moodle_exception('errorprocessingbook', 'local_aisgk', '', null, implode("\n", array_merge($output, $output2 ?? [])));
            }
        }
        return $outpath;
    }
    protected static function preprocess_image_for_ocr_2col_title_light(string $imagepath, string $suffix = 'titlelight'): string {
        $outpath = preg_replace('/\.png$/i', '_' . $suffix . '.png', $imagepath);
        $cmd = sprintf(
            '/usr/bin/convert %s -colorspace Gray -density 300 -resize 220%% -auto-level -sharpen 0x1.0 -deskew 40%% %s 2>&1',
            escapeshellarg($imagepath),
            escapeshellarg($outpath)
        );
        exec($cmd, $output, $returnvar);
        if ($returnvar !== 0 || !file_exists($outpath)) {
            throw new \moodle_exception('errorprocessingbook', 'local_aisgk', '', null, implode("\n", $output));
        }
        return $outpath;
    }
    protected static function preprocess_image_for_ocr_2col_page_strong(string $imagepath, string $suffix = 'pagestrong'): string {
        $outpath = preg_replace('/\.png$/i', '_' . $suffix . '.png', $imagepath);
        $cmd = sprintf(
            '/usr/bin/convert %s -colorspace Gray -density 300 -resize 320%% -auto-level -contrast-stretch 1%%x1%% -sharpen 0x1.1 -threshold 60%% -despeckle %s 2>&1',
            escapeshellarg($imagepath),
            escapeshellarg($outpath)
        );
        exec($cmd, $output, $returnvar);
        if ($returnvar !== 0 || !file_exists($outpath)) {
            throw new \moodle_exception('errorprocessingbook', 'local_aisgk', '', null, implode("\n", $output));
        }
        return $outpath;
    }
    protected static function extract_title_entries_with_fallback_2col(string $titleimg, int $titlepsm = 6, string $halfname = 'l'): array {
        $variants = [];
        $prepMain = self::preprocess_image_for_ocr_2col($titleimg, $halfname . '1_prep2');
        $variants[] = $prepMain;
        $prepLight = self::preprocess_image_for_ocr_2col_title_light($titleimg, $halfname . '1_light');
        $variants[] = $prepLight;
        @copy($prepMain, self::get_debug_output_dir() . '/' . $halfname . '1_prep2_debug.png');
        @copy($prepLight, self::get_debug_output_dir() . '/' . $halfname . '1_light_debug.png');
        foreach ($variants as $variant) {
            $titleentries = self::ocr_one_tesseract_tsv_exact($variant, 'vie+eng', $titlepsm);
            $titleentries = self::extract_toc_region_entry_2col($titleentries);
            $titleentries = self::merge_wrapped_line_entries_2col($titleentries);
            $titleentries = self::filter_title_entry_lines_2col($titleentries);
	    $titleentries = self::merge_indented_title_entries_2col($titleentries);
            if (!empty($titleentries)) {
                return $titleentries;
            }
        }
        return [];
    }
    protected static function extract_page_entries_with_fallback_2col_old(string $pageimg, int $pagepsm = 6, string $halfname = 'l'): array {
    $variants = [];

    $prepMain = self::preprocess_image_for_ocr_2col($pageimg, $halfname . '2_prep2');

    // Nếu vùng page tối / nhiều nền màu thì invert trước khi OCR.
    if (self::page_region_should_invert_2col($pageimg)) {
        $prepMain = self::preprocess_image_for_ocr_2col_page_invert($pageimg, $halfname . '2_inv');
    }

    $variants[] = $prepMain;

    $prepStrong = self::preprocess_image_for_ocr_2col_page_strong($pageimg, $halfname . '2_strong');
    $variants[] = $prepStrong;

    // File debug cuối cùng thực sự đem đi OCR.
    @copy($prepMain, self::get_debug_output_dir() . '/' . $halfname . '2_debug.png');
    @copy($prepStrong, self::get_debug_output_dir() . '/' . $halfname . '2_strong_debug.png');

    $best = [];
    foreach ($variants as $variant) {
        $pageentries = self::ocr_one_tesseract_tsv_exact($variant, 'eng', $pagepsm, '0123456789OolIsSBZT+');
        $pageentries = self::filter_page_entry_lines_2col($pageentries);

        if (count($pageentries) > count($best)) {
            $best = $pageentries;
        }

        if (count($pageentries) >= 2) {
            return $pageentries;
        }
    }

    return $best;
}
   //hàm thêm mới để invert
protected static function page_region_should_invert_2col(string $imagepath): bool {
    $cmd = sprintf(
        '/usr/bin/convert %s -colorspace Gray -resize 20%% -threshold 80%% -format "%%[fx:mean]" info: 2>&1',
        escapeshellarg($imagepath)
    );
    exec($cmd, $out, $ret);

    if ($ret !== 0 || empty($out[0])) {
        return false;
    }

    $whiteRatio = (float)trim((string)$out[0]);

    return $whiteRatio < 0.55;
}

protected static function preprocess_image_for_ocr_2col_page_invert(string $imagepath, string $suffix = 'pageinv'): string {
    $outpath = preg_replace('/\.png$/i', '_' . $suffix . '.png', $imagepath);

    $cmd = sprintf(
        '/usr/bin/convert %s -colorspace Gray -negate %s 2>&1',
        escapeshellarg($imagepath),
        escapeshellarg($outpath)
    );
    exec($cmd, $output, $returnvar);

    if ($returnvar !== 0 || !file_exists($outpath)) {
        throw new \moodle_exception('errorprocessingbook', 'local_aisgk', '', null, implode("\n", $output));
    }

    return $outpath;
}
//------------
protected static function extract_real_page_band_by_two_peaks_2col(string $imagepath, string $suffix = 'pageband', bool $demtrang = false): string {
    [$fullwidth, $fullheight] = self::get_image_dimensions($imagepath);

    $n = 2;
    $matdo = self::lay_mat_do_rut_gon($imagepath, $n, $demtrang);
    $cums = self::tim_cac_cum_toa_do($matdo, 4, 3);

    if (empty($cums)) {
        return $imagepath;
    }

    $mid = (int)floor(count($matdo) * 0.55);

    $cums = array_values(array_filter($cums, function($cum) use ($mid) {
        $center = (int)floor(($cum['x1'] + $cum['x2']) / 2);
        return $center >= $mid;
    }));

    if (empty($cums)) {
        return $imagepath;
    }

    usort($cums, function($a, $b) {
        $ca = ($a['x1'] + $a['x2']) / 2;
        $cb = ($b['x1'] + $b['x2']) / 2;
        return $cb <=> $ca;
    });

    $best = $cums[0];

    $x1 = max(0, $best['x1'] * $n - 3);
    $x2 = min($fullwidth - 1, ($best['x2'] + 1) * $n + 3);
    $w = max(1, $x2 - $x1);

    $dest = preg_replace('/\.png$/i', '_' . $suffix . '.png', $imagepath);
    self::crop_image($imagepath, $dest, $w, $fullheight, $x1, 0);

    @copy($dest, self::get_debug_output_dir() . '/' . $suffix . '_debug.png');

    return $dest;
}
//-------------
protected static function extract_page_entries_with_fallback_2col(string $pageimg, int $pagepsm = 6, string $halfname = 'l'): array {
    $variants = [];
    $workimg = $pageimg;

    // Nếu là kiểu nền đậm / số trắng thì:
    // 1) bóc dải số trang thật bằng 2 quả núi trong chính l2/r2
    // 2) rồi mới invert dải đó
    // TEST HARDCODE
if (true) {
    $workimg = self::extract_real_page_band_by_two_peaks_2col($pageimg, $halfname . '2_band',true);
    $prepMain = self::preprocess_image_for_ocr_2col_page_invert($workimg, $halfname . '2_inv');

    @copy($workimg, self::get_debug_output_dir() . '/' . $halfname . '2_band_debug.png');
    @copy($prepMain, self::get_debug_output_dir() . '/' . $halfname . '2_inv_debug.png');
}
///end bắt buộc làm
    if (self::page_region_should_invert_2col($pageimg)) {
    $workimg = self::extract_real_page_band_by_two_peaks_2col($pageimg, $halfname . '2_band', true);
    $prepMain = self::preprocess_image_for_ocr_2col_page_invert($workimg, $halfname . '2_inv');
} else {
    $workimg = self::extract_real_page_band_by_two_peaks_2col($pageimg, $halfname . '2_band', false);
    $prepMain = self::preprocess_image_for_ocr_2col($workimg, $halfname . '2_prep2');
}

    $variants[] = $prepMain;

    $prepStrong = self::preprocess_image_for_ocr_2col_page_strong($workimg, $halfname . '2_strong');
    $variants[] = $prepStrong;
    @copy($prepStrong, self::get_debug_output_dir() . '/' . $halfname . '2_strong_debug.png');

    $best = [];
    foreach ($variants as $variant) {
        $pageentries = self::ocr_one_tesseract_tsv_exact($variant, 'eng', $pagepsm, '0123456789OolIsSBZT+');
        $pageentries = self::filter_page_entry_lines_2col($pageentries);

        if (count($pageentries) > count($best)) {
            $best = $pageentries;
        }
    }

    return $best;
}
////-------------
    protected static function ocr_one_tesseract_tsv_exact(string $imagepath, string $lang = 'vie+eng', int $psm = 6, string $whitelist = ''): array {
        $base = preg_replace('/\.png$/i', '', $imagepath) . '_ocr_tsv';
        $psm = max(3, min(13, (int)$psm));
        $extra = ' -c preserve_interword_spaces=1';
        if ($whitelist !== '') {
            $extra .= ' -c tessedit_char_whitelist=' . escapeshellarg($whitelist);
        }
        $cmd = sprintf(
            '/usr/bin/tesseract %s %s -l %s --psm %d tsv%s 2>&1',
            escapeshellarg($imagepath),
            escapeshellarg($base),
            escapeshellarg($lang),
            $psm,
            $extra
        );
        exec($cmd, $output, $returnvar);
        if ($returnvar !== 0) {
            throw new \moodle_exception('errorprocessingbook', 'local_aisgk', '', null, implode("\n", $output));
        }
        $tsvfile = $base . '.tsv';
        if (!file_exists($tsvfile)) {
            return [];
        }
        $lines = file($tsvfile, FILE_IGNORE_NEW_LINES);
        if (!$lines || count($lines) < 2) {
            return [];
        }
        $entries = [];
        $groups = [];
        foreach (array_slice($lines, 1) as $line) {
            $cols = str_getcsv($line, "\t");
            if (count($cols) < 12) {
                continue;
            }
            if ((int)$cols[0] !== 5) {
                continue;
            }
            $text = trim((string)$cols[11]);
            if ($text === '') {
                continue;
            }
            $page = (int)$cols[1];
            $block = (int)$cols[2];
            $par = (int)$cols[3];
            $lineNum = (int)$cols[4];
            $left = (int)$cols[6];
            $top = (int)$cols[7];
            $width = (int)$cols[8];
            $height = (int)$cols[9];
            $key = $page . ':' . $block . ':' . $par . ':' . $lineNum;
            if (!isset($groups[$key])) {
                $groups[$key] = [
                    'parts' => [],
                    'left' => $left,
                    'top' => $top,
                    'right' => $left + $width,
                    'bottom' => $top + $height,
                ];
            }
            $groups[$key]['parts'][] = ['left' => $left, 'text' => $text];
            $groups[$key]['left'] = min($groups[$key]['left'], $left);
            $groups[$key]['top'] = min($groups[$key]['top'], $top);
            $groups[$key]['right'] = max($groups[$key]['right'], $left + $width);
            $groups[$key]['bottom'] = max($groups[$key]['bottom'], $top + $height);
        }
        foreach ($groups as $group) {
            usort($group['parts'], function($a, $b) {
                return $a['left'] <=> $b['left'];
            });
            $text = trim(implode(' ', array_map(function($p) {
                return $p['text'];
            }, $group['parts'])));
            $text = preg_replace('/\s+/u', ' ', $text);
            if ($text === '') {
                continue;
            }
            $entries[] = [
                'text' => $text,
                'y' => (int)round(($group['top'] + $group['bottom']) / 2),
                'top' => (int)$group['top'],
                'bottom' => (int)$group['bottom'],
                'left' => (int)$group['left'],
            ];
        }
        usort($entries, function($a, $b) {
            if ($a['y'] === $b['y']) {
                return $a['left'] <=> $b['left'];
            }
            return $a['y'] <=> $b['y'];
        });
        return array_values($entries);
    }
    protected static function normalize_line_entries_2col(array $entries): array {
        $out = [];
        foreach ($entries as $entry) {
            $text = trim((string)($entry['text'] ?? ''));
            $text = preg_replace('/\s+/u', ' ', $text);
            if ($text === '') {
                continue;
            }
            $entry['text'] = $text;
            $out[] = $entry;
        }
        return array_values($out);
    }
    protected static function is_probably_new_toc_item_2col(string $text): bool {
        $text = trim(preg_replace('/\s+/u', ' ', $text));
        if ($text === '') {
            return false;
        }
        return (bool)preg_match(
            '/^\s*(bài\s*\d+|bai\s*\d+|chương\b|chuong\b|chủ\s*đề\b|chu\s*de\b|phần\b|phan\b|luyện\s*tập\b|luyen\s*tap\b|bài\s*tập\s*cuối\s*chương\b|bai\s*tap\s*cuoi\s*chuong\b|t[âaă]m\s*thiệp\b|tam\s*thiep\b|vẽ\s*hình\b|ve\s*hinh\b|geogebra\b|sử\s*dụng\s*máy\s*tính\b|su\s*dung\s*may\s*tinh\b|bảng\s*tra\s*cứu\b|bang\s*tra\s*cuu\b|bảng\s*giải\s*thích\b|bang\s*giai\s*thich\b)/ui',
            $text
        );
    }
    protected static function title_line_looks_incomplete_2col(string $text): bool {
        $text = trim(preg_replace('/\s+/u', ' ', $text));
        if ($text === '') {
            return false;
        }
        $last3 = mb_substr($text, max(0, mb_strlen($text, 'UTF-8') - 3), null, 'UTF-8');
        if (mb_strpos($last3, '.', 0, 'UTF-8') === false) {
            return false;
        }
        $tokens = preg_split('/\s+/u', $text) ?: [];
        if (empty($tokens)) {
            return false;
        }
        $last = end($tokens);
        $clean = preg_replace('/[^\p{L}\p{N}\.]/u', '', (string)$last);
        $clean = trim((string)$clean);
        if ($clean === '' || $clean === '.') {
            return false;
        }
        if (preg_match('/^[IVXLivxl]+\.?$/u', $clean)) {
            return false;
        }
        $lettersOnly = preg_replace('/[^\p{L}\p{N}]/u', '', $clean);
        return mb_strlen((string)$lettersOnly, 'UTF-8') === 1;
    }
    protected static function merge_wrapped_line_entries_2col(array $entries): array {
        $entries = self::normalize_line_entries_2col($entries);
        if (empty($entries)) {
            return [];
        }
        $result = [];
        foreach ($entries as $entry) {
            if (empty($result)) {
                $result[] = $entry;
                continue;
            }
            $previndex = count($result) - 1;
            $prev = $result[$previndex];
            $prevtext = (string)$prev['text'];
            $currtext = (string)$entry['text'];
            $firstchar = null;
            if (preg_match('/\p{L}/u', $currtext, $m, PREG_OFFSET_CAPTURE)) {
                $offset = $m[0][1];
                $firstchar = mb_substr($currtext, $offset, 1, 'UTF-8');
            }
            $islowerstart = false;
            if ($firstchar !== null) {
                $islowerstart = (
                    mb_strtolower($firstchar, 'UTF-8') === $firstchar &&
                    mb_strtoupper($firstchar, 'UTF-8') !== $firstchar
                );
            }
            $closeY = abs((int)$entry['top'] - (int)$prev['bottom']) <= 18 ||
            abs((int)$entry['y'] - (int)$prev['y']) <= 10;
            $currisnewitem = self::is_probably_new_toc_item_2col($currtext);
            // ❗ Nếu dòng mới là item thật → KHÔNG merge
            if ($currisnewitem) {
                $result[] = $entry;
                continue;
            }
            $previncomplete = self::title_line_looks_incomplete_2col($prevtext);
            $shouldmerge = false;
            if ($islowerstart && !$currisnewitem) {
                $shouldmerge = true;
            } else if ($previncomplete && !$currisnewitem && $closeY) {
                $shouldmerge = true;
            }
            if ($shouldmerge) {
                $result[$previndex]['text'] = trim($prevtext . ' ' . $currtext);
                $result[$previndex]['bottom'] = max((int)$prev['bottom'], (int)$entry['bottom']);
                $result[$previndex]['y'] = (int)round(((int)$result[$previndex]['top'] + (int)$result[$previndex]['bottom']) / 2);
                continue;
            }
            $result[] = $entry;
        }
        return array_values($result);
    }
    protected static function extract_toc_region_entry_2col(array $entries): array {
        $entries = self::normalize_line_entries_2col($entries);
        $startindex = null;
        foreach ($entries as $i => $entry) {
            $n = mb_strtolower((string)$entry['text'], 'UTF-8');
            $n = preg_replace('/\s+/u', ' ', $n);
            $n = trim($n);
            if ($startindex === null && preg_match('/\b(bài|bai)\s*[1l]\b/u', $n)) {
                $startindex = $i;
                break;
            }
        }
        if ($startindex === null) {
            return $entries;
        }
        return array_slice($entries, $startindex);
    }
//------------
    protected static function filter_title_entry_lines_2col(array $entries): array {
        $out = [];
        foreach ($entries as $entry) {
            $line = trim((string)($entry['text'] ?? ''));
            $line = preg_replace('/\s+/u', ' ', $line);
            if ($line === '') {
                continue;
            }

            if (self::is_all_uppercase_line($line)) {
                continue;
            }

            $isnewitem = (
                preg_match('/^\s*(bài|bai)\s*\d+\b/ui', $line) ||
                preg_match('/^\s*(chương|chuong)\b/ui', $line) ||
                preg_match('/^\s*(chủ\s*đề|chu\s*de)\b/ui', $line) ||
                preg_match('/^\s*(luyện\s*tập|luyen\s*tap)\b/ui', $line) ||
                preg_match('/^\s*(bài\s*tập|bai\s*tap)\b/ui', $line) ||
                preg_match('/^\s*(t[âaă]m\s*thiệp|tam\s*thiep)\b/ui', $line) ||
                preg_match('/^\s*(vẽ\s*hình|ve\s*hinh)\b/ui', $line) ||
                preg_match('/^\s*(geogebra)\b/ui', $line) ||
                preg_match('/^\s*(sử\s*dụng\s*máy\s*tính|su\s*dung\s*may\s*tinh)\b/ui', $line) ||
                preg_match('/^\s*(bảng\s*tra\s*cứu|bang\s*tra\s*cuu)\b/ui', $line) ||
                preg_match('/^\s*(bảng\s*giải\s*thích|bang\s*giai\s*thich)\b/ui', $line)
            );

            if ($isnewitem) {
                $entry['text'] = $line;
                $out[] = $entry;
                continue;
            }

            if (empty($out)) {
                continue;
            }

            $lastidx = count($out) - 1;
            $prevtext = (string)$out[$lastidx]['text'];
            $dy = abs((int)$entry['top'] - (int)$out[$lastidx]['bottom']);
            $previncomplete = self::title_line_looks_incomplete_2col($prevtext);

            $firstchar = null;
            if (preg_match('/\p{L}/u', $line, $m, PREG_OFFSET_CAPTURE)) {
                $offset = $m[0][1];
                $firstchar = mb_substr($line, $offset, 1, 'UTF-8');
            }

            $islowerstart = false;
            if ($firstchar !== null) {
                $islowerstart = (
                    mb_strtolower($firstchar, 'UTF-8') === $firstchar &&
                    mb_strtoupper($firstchar, 'UTF-8') !== $firstchar
                );
            }

            $iscontinuation = false;
            if ($dy <= 20 && $previncomplete) {
                $iscontinuation = true;
            } else if ($dy <= 12 && $islowerstart) {
                $iscontinuation = true;
            }

            if ($iscontinuation) {
                $out[$lastidx]['text'] = trim($out[$lastidx]['text'] . ' ' . $line);
                $out[$lastidx]['bottom'] = max((int)$out[$lastidx]['bottom'], (int)$entry['bottom']);
                $out[$lastidx]['y'] = (int)round(((int)$out[$lastidx]['top'] + (int)$out[$lastidx]['bottom']) / 2);
            }
        }
        return array_values($out);
}
protected static function filter_page_entry_lines_2col(array $entries): array {
    $out = [];
    foreach ($entries as $entry) {
        $text = trim((string)($entry['text'] ?? ''));
        if ($text === '') {
            continue;
        }
        // 🔥 FIX 1: loại rác mép trái
        if (isset($entry['left']) && $entry['left'] < 3) {
            continue;
        }
        if (preg_match_all('/[0-9OolIsSBZT\+]{1,4}/u', $text, $m)) {
            $best = null;
            foreach ($m[0] as $token) {
                $page = self::normalize_page_token_2col($token);
                if ($page !== null) {
                    $best = $page;
                }
            }
            if ($best !== null) {
                $entry['page'] = $best;
                $out[] = $entry;
            }
        }
    }
    return array_values($out);
}
//--------------
protected static function pair_title_page_entries_by_y_2col(array $titleentries, array $pageentries, int $ytolerance = 20): array {
    $pairs = [];
    $used = [];

    foreach ($titleentries as $title) {
        $bestidx = null;
        $bestdelta = null;
        $titley = (int)($title['y'] ?? 0);

        foreach ($pageentries as $idx => $pageentry) {
            if (isset($used[$idx])) {
                continue;
            }

            $pagey = (int)($pageentry['y'] ?? 0);
            $delta = abs($titley - $pagey);

            if ($delta <= $ytolerance && ($bestdelta === null || $delta < $bestdelta)) {
                $bestdelta = $delta;
                $bestidx = $idx;
            }
        }

        $page = null;
        if ($bestidx !== null) {
            $page = $pageentries[$bestidx]['page'] ?? null;
            $used[$bestidx] = true;
        }

        $pairs[] = [
            'text' => (string)($title['text'] ?? ''),
            'y' => $titley,
            'page' => $page,
        ];
    }

    return $pairs;
}
//-------------------
protected static function process_half_2col(string $titleimg, string $pageimg, int $titlepsm = 6, int $pagepsm = 6, string $halfname = 'l'): array {
    $titleentries = self::extract_title_entries_with_fallback_2col($titleimg, $titlepsm, $halfname);
    $pageentries = self::extract_page_entries_with_fallback_2col($pageimg, $pagepsm, $halfname);
    self::debug_log(strtoupper($halfname) . '1 TITLE ENTRIES', $titleentries);
    self::debug_log(strtoupper($halfname) . '2 PAGE ENTRIES', $pageentries);
    $pairs = self::pair_title_page_entries_by_y_2col($titleentries, $pageentries, 50);
    self::debug_log(strtoupper($halfname) . ' PAIRED BY Y', $pairs);
    return [
        'title_entries' => $titleentries,
        'page_entries' => $pageentries,
        'pairs' => $pairs,
        'title_lines' => array_values(array_map(function($x) { return $x['text']; }, $titleentries)),
        'page_lines' => array_values(array_map(function($x) { return $x['page']; }, $pageentries)),
    ];
}
protected static function lay_mat_do_rut_gon(string $path_anh, int $n = 4, bool $demtrang = false): array {
    $tile = (1 / $n) * 100;
    $cmd = sprintf(
        '/usr/bin/convert %s -thumbnail %d%% -colorspace Gray -scale x1! txt:-',
        escapeshellarg($path_anh),
        $tile
    );

    exec($cmd, $output);

    $matdo = [];
    foreach ($output as $line) {
        if (preg_match('/\(\s*(\d+)\s*\)/', $line, $m)) {
            $gray = (int)$m[1];

            if ($demtrang) {
                // trắng cao điểm, đen thấp điểm
                $matdo[] = $gray;
            } else {
                // đen cao điểm, trắng thấp điểm
                $matdo[] = 255 - $gray;
            }
        }
    }

    return $matdo;
}

protected static function tim_cac_cum_toa_do(array $matdo, int $nguongpixel = 5, int $khoangcachnghi = 10): array {
    $caccum = [];
    $batdau = null;
    $socottrang = 0;
    foreach ($matdo as $x => $giatri) {
        if ($giatri > $nguongpixel) {
            if ($batdau === null) {
                $batdau = $x;
            }
            $socottrang = 0;
        } else if ($batdau !== null) {
            $socottrang++;
            if ($socottrang >= $khoangcachnghi) {
                $caccum[] = ['x1' => $batdau, 'x2' => $x - $socottrang];
                $batdau = null;
                $socottrang = 0;
            }
        }
    }
    if ($batdau !== null) {
        $caccum[] = ['x1' => $batdau, 'x2' => count($matdo) - 1];
    }
    return $caccum;
}
protected static function chon_hai_cum_lon_nhat(array $cums): array {
    if (empty($cums)) {
        return [];
    }
    usort($cums, function($a, $b) {
        $wa = ($a['x2'] - $a['x1']);
        $wb = ($b['x2'] - $b['x1']);
        return $wb <=> $wa;
    });
    $cums = array_slice($cums, 0, min(2, count($cums)));
    usort($cums, function($a, $b) {
        return $a['x1'] <=> $b['x1'];
    });
    return array_values($cums);
}
protected static function chon_hai_nua_trang_theo_vi_tri(array $cums, int $tongcot): array {
    if (empty($cums)) {
        return [];
    }
    $mid = (int)floor($tongcot / 2);
    $left = [];
    $right = [];
    foreach ($cums as $cum) {
        $center = (int)floor(($cum['x1'] + $cum['x2']) / 2);
        if ($center < $mid) {
            $left[] = $cum;
        } else {
            $right[] = $cum;
        }
    }
    $pickbest = function(array $arr): ?array {
        if (empty($arr)) {
            return null;
        }
        usort($arr, function($a, $b) {
            $wa = $a['x2'] - $a['x1'];
            $wb = $b['x2'] - $b['x1'];
            return $wb <=> $wa;
        });
        return $arr[0];
    };
    $bestleft = $pickbest($left);
    $bestright = $pickbest($right);
    if ($bestleft && $bestright) {
        return [$bestleft, $bestright];
    }
    return self::chon_hai_cum_lon_nhat($cums);
}
protected static function chon_hai_cum_con_trong_nua(array $matdo, array $nua, int $n): array {
    $vungdulieu = array_slice($matdo, $nua['x1'], $nua['x2'] - $nua['x1'] + 1);
    $cumcon = self::tim_cac_cum_toa_do($vungdulieu, 5, 8);
    $cumcon = self::chon_hai_cum_lon_nhat($cumcon);
    if (count($cumcon) >= 2) {
        $a = $cumcon[0];
        $b = $cumcon[1];
        $x1a = ($a['x1'] + $nua['x1']) * $n;
        $x2a = ($a['x2'] + $nua['x1']) * $n;
        $x1b = ($b['x1'] + $nua['x1']) * $n;
        $x2b = ($b['x2'] + $nua['x1']) * $n;
        return [
            ['x' => max(0, $x1a - 6), 'w' => max(1, ($x2a - $x1a) + 12)],
            ['x' => max(0, $x1b - 6), 'w' => max(1, ($x2b - $x1b) + 12)],
        ];
    }
    $x1 = $nua['x1'] * $n;
    $x2 = ($nua['x2'] + 1) * $n;
    $w = max(1, $x2 - $x1);
    $w1 = (int)floor($w * 0.82);
    $w2 = $w - $w1;
    return [
        ['x' => $x1, 'w' => max(1, $w1)],
        ['x' => $x1 + $w1, 'w' => max(1, $w2)],
    ];
}
protected static function xac_dinh_toa_do_2_qua_nui(string $path_anh, int $n = 4): array {
    [$fullwidth, $fullheight] = self::get_image_dimensions($path_anh);
    $matdonho = self::lay_mat_do_rut_gon($path_anh, $n);
    $cactoancuc = self::tim_cac_cum_toa_do($matdonho, 5, 30);
    $cacnuatrang = self::chon_hai_nua_trang_theo_vi_tri($cactoancuc, count($matdonho));
    if (count($cacnuatrang) < 2) {
        $leftwidth = (int)floor($fullwidth * 0.5);
        $rightwidth = $fullwidth - $leftwidth;
        $l = ['x' => 0, 'w' => max(1, $leftwidth)];
        $r = ['x' => $leftwidth, 'w' => max(1, $rightwidth)];
        $l1w = (int)floor($l['w'] * 0.82);
        $l2w = $l['w'] - $l1w;
        $r1w = (int)floor($r['w'] * 0.70);
        $r2w = $r['w'] - $r1w;
        $l1 = ['x' => $l['x'], 'w' => max(1, $l1w)];
        $l2 = ['x' => $l['x'] + $l1w, 'w' => max(1, $l2w)];
        $r1 = ['x' => $r['x'], 'w' => max(1, $r1w)];
        $r2 = ['x' => $r['x'] + $r1w, 'w' => max(1, $r2w)];
    } else {
        $leftnua = $cacnuatrang[0];
        $rightnua = $cacnuatrang[1];
        $l = [
            'x' => max(0, $leftnua['x1'] * $n - 8),
            'w' => max(1, (($leftnua['x2'] - $leftnua['x1'] + 1) * $n) + 16),
        ];
        $r = [
            'x' => max(0, $rightnua['x1'] * $n - 8),
            'w' => max(1, (($rightnua['x2'] - $rightnua['x1'] + 1) * $n) + 16),
        ];
        $lparts = self::chon_hai_cum_con_trong_nua($matdonho, $leftnua, $n);
        $rparts = self::chon_hai_cum_con_trong_nua($matdonho, $rightnua, $n);
        $fallbackParts = function(array $half, float $titleRatio): array {
            $w1 = (int)floor($half['w'] * $titleRatio);
            $w2 = $half['w'] - $w1;
            return [
                ['x' => $half['x'], 'w' => max(1, $w1)],
                ['x' => $half['x'] + $w1, 'w' => max(1, $w2)],
            ];
        };
        if (count($lparts) < 2 || $lparts[0]['w'] < 20 || $lparts[1]['w'] < 10) {
            $lparts = $fallbackParts($l, 0.82);
        }
        if (count($rparts) < 2 || $rparts[0]['w'] < 20 || $rparts[1]['w'] < 10) {
            $rparts = $fallbackParts($r, 0.70);
        }
        $l1 = $lparts[0];
        $l2 = $lparts[1];
        $r1 = $rparts[0];
        $r2 = $rparts[1];
    }
    $fix = function(array $region) use ($fullwidth) {
        $region['x'] = max(0, min((int)$region['x'], $fullwidth - 1));
        $region['w'] = max(1, min((int)$region['w'], $fullwidth - $region['x']));
        return $region;
    };
    $l = $fix($l);
    $r = $fix($r);
    $l1 = $fix($l1);
    $l2 = $fix($l2);
    $r1 = $fix($r1);
    $r2 = $fix($r2);
    return compact('l', 'l1', 'l2', 'r', 'r1', 'r2');
}
protected static function cat_theo_toa_do_2col(string $imagepath): array {
    [$fullwidth, $fullheight] = self::get_image_dimensions($imagepath);
    $regions = self::xac_dinh_toa_do_2_qua_nui($imagepath, 4);
    self::debug_log('2COL REGIONS RAW', $regions);
    $tmp = [];
    foreach ($regions as $name => $region) {
        $base = tempnam(sys_get_temp_dir(), 'aisgk_' . $name . '_');
        $dest = $base . '.png';
        self::crop_image($imagepath, $dest, (int)$region['w'], $fullheight, (int)$region['x'], 0);
        $tmp[$name] = $dest;
        @copy($dest, self::get_debug_output_dir() . '/' . $name . '_debug.png');
    }
    self::debug_log('2COL REGIONS', $regions);
    return $tmp;
}
protected static function split_text_lines(string $text): array {
    $normalized = preg_replace("/\r\n|\r/u", "\n", (string)$text);
    $lines = explode("\n", $normalized);
    return array_values(array_filter(array_map('trim', $lines), function($line) {
        return $line !== '';
    }));
}
protected static function normalize_for_filter(string $line): string {
    $line = trim($line);
    $line = preg_replace('/\s+/u', ' ', $line);
    return $line;
}
protected static function is_all_uppercase_line(string $line): bool {
    $letters = preg_replace('/[^\p{L}]+/u', '', $line);
    if ($letters === '') {
        return false;
    }
    return mb_strtoupper($letters, 'UTF-8') === $letters;
}
//----------------
protected static function merge_indented_title_entries_2col(array $entries): array {
    $entries = self::normalize_line_entries_2col($entries);
    if (count($entries) < 2) {
        return $entries;
    }

    $baselefts = [];
    foreach ($entries as $entry) {
        $text = trim((string)($entry['text'] ?? ''));
        $left = (int)($entry['left'] ?? 0);

        if ($text === '') {
            continue;
        }

        if (self::is_probably_new_toc_item_2col($text)) {
            $baselefts[] = $left;
        }
    }

    if (empty($baselefts)) {
        return $entries;
    }

    sort($baselefts);
    $mid = (int)floor(count($baselefts) / 2);
    $avgleft = $baselefts[$mid]; // dùng median cho ổn định hơn average

    $result = [];
    foreach ($entries as $entry) {
        $text = trim((string)($entry['text'] ?? ''));
        $left = (int)($entry['left'] ?? 0);

        if (empty($result)) {
            $result[] = $entry;
            continue;
        }

        $lastidx = count($result) - 1;
        $prev = $result[$lastidx];
        $prevtext = trim((string)($prev['text'] ?? ''));

        $dy = abs((int)$entry['top'] - (int)$prev['bottom']);
        $isnewitem = self::is_probably_new_toc_item_2col($text);

        $isindentedcontinuation = (
            !$isnewitem &&
            $left >= ($avgleft + 25) &&
            $dy <= 22
        );

        if ($isindentedcontinuation) {
            $result[$lastidx]['text'] = trim($prevtext . ' ' . $text);
            $result[$lastidx]['bottom'] = max((int)$prev['bottom'], (int)$entry['bottom']);
            $result[$lastidx]['y'] = (int)round(((int)$result[$lastidx]['top'] + (int)$result[$lastidx]['bottom']) / 2);
            continue;
        }

        $result[] = $entry;
    }

    return array_values($result);
}
//-------------------
protected static function merge_wrapped_lines_2col(array $lines): array {
    $rawlines = array_values(array_filter(array_map(function($line) {
        return trim((string)$line);
    }, $lines), function($line) {
        return $line !== '';
    }));
    $result = [];
    foreach ($rawlines as $rawline) {
        $line = trim((string)$rawline);
        if ($line === '') {
            continue;
        }
        if (empty($result)) {
            $result[] = $line;
            continue;
        }
        $previndex = count($result) - 1;
        $prevraw = trim((string)$result[$previndex]);
        $prev = self::normalize_for_filter($prevraw);
        $curr = self::normalize_for_filter($line);
        $firstchar = null;
        if (preg_match('/\p{L}/u', $curr, $m, PREG_OFFSET_CAPTURE)) {
            $offset = $m[0][1];
            $firstchar = mb_substr($curr, $offset, 1, 'UTF-8');
        }
        $islowerstart = false;
        $isupperstart = false;
        if ($firstchar !== null) {
            $islowerstart = (
                mb_strtolower($firstchar, 'UTF-8') === $firstchar &&
                mb_strtoupper($firstchar, 'UTF-8') !== $firstchar
            );
            $isupperstart = (
                mb_strtoupper($firstchar, 'UTF-8') === $firstchar &&
                mb_strtolower($firstchar, 'UTF-8') !== $firstchar
            );
        }
        if ($islowerstart) {
            $result[$previndex] = trim($prevraw . ' ' . $line);
            continue;
        }
        if (preg_match('/\.\s*$/u', trim($prev)) && $isupperstart) {
            $result[$previndex] = trim($prevraw . ' ' . $line);
            continue;
        }
        $result[] = $line;
    }
    return $result;
}
protected static function filter_title_lines_2col(array $lines): array {
    $out = [];
    foreach ($lines as $raw) {
        $line = self::normalize_for_filter((string)$raw);
        if ($line === '') {
            continue;
        }
        if (self::is_all_uppercase_line($line)) {
            continue;
        }
        if (preg_match('/^\s*(bài|bai)\s*\d+\b/ui', $line) ||
            preg_match('/^\s*(chương|chuong)\b/ui', $line) ||
            preg_match('/^\s*(chủ\s*đề|chu\s*de)\b/ui', $line) ||
            preg_match('/^\s*(luyện\s*tập|luyen\s*tap|bài\s*tập|bai\s*tap)\b/ui', $line)) {
            $out[] = $line;
    }
}
return array_values($out);
}
protected static function filter_page_lines_2col(array $lines): array {
    $out = [];
    foreach ($lines as $line) {
        $line = trim((string)$line);
        if ($line === '') {
            continue;
        }
        if (preg_match_all('/[0-9OolIsSBZT\+]{1,4}/u', $line, $m)) {
            foreach ($m[0] as $token) {
                $page = self::normalize_page_token_2col($token);
                if ($page !== null) {
                    $out[] = $page;
                }
            }
        }
    }
    return array_values($out);
}
protected static function extract_toc_region_2col(array $lines): array {
    $lines = array_values(array_filter(array_map('trim', $lines), function($line) {
        return $line !== '';
    }));
    $startindex = null;
    foreach ($lines as $i => $line) {
        $n = mb_strtolower((string)$line, 'UTF-8');
        $n = preg_replace('/\s+/u', ' ', $n);
        $n = trim($n);
        if (preg_match('/\b(bài|bai)\s*[1l]\b/u', $n)) {
            $startindex = $i;
            break;
        }
    }
    if ($startindex === null) {
        return $lines;
    }
    return array_slice($lines, $startindex);
}
//---------------
protected static function normalize_page_token_2col(?string $token): ?int {
    $token = trim((string)$token);
    if ($token === '') {
        return null;
    }
    $token = preg_replace('/^[^\pL\pN\+\-]+|[^\pL\pN\+\-]+$/u', '', $token);
    $token = preg_replace('/\s+/u', '', $token);
    if ($token === '') {
        return null;
    }
    if (preg_match('/^\d{1,4}$/', $token)) {
        return (int)$token;
    }
    $mapped = strtr($token, [
        'O' => '0', 'o' => '0',
        'I' => '1', 'l' => '1',
        'S' => '5', 's' => '5',
        'B' => '8',
        'Z' => '2',
        'T' => '7', 't' => '7',
        '+' => '7',
    ]);
    if (preg_match('/^\d{1,4}$/', $mapped)) {
        return (int)$mapped;
    }
    return null;
}
protected static function parse_title_line_2col(string $line): ?array {
    $line = trim((string)$line);
    if ($line === '') {
        return null;
    }

    $line = preg_replace('/\s+/u', ' ', $line);
    $raw = mb_substr($line, 0, 255);

    // Ký tự đầu tiên phải là chữ hoa.
    if (!preg_match('/^\p{Lu}/u', $line)) {
        return null;
    }

    // Loại các mục không tính là bài:
    // Chương <La Mã>, Chủ đề <La Mã>, Phần <La Mã>
    if (preg_match('/^(chương|chuong|chủ\s*đề|chu\s*de|phần|phan)\s+[IVXLCDM]+\b/ui', $line)) {
        return null;
    }

    $lessonno = null;
    $lessontitle = $line;

    // Nếu có mẫu "Bài 12. ..." thì tách số bài.
    if (preg_match('/^(?:Bài|Bai|bài|bai)\s+(\d+)\.?\s*(.+)$/ui', $line, $m)) {
        $lessonno = (int)$m[1];
        $lessontitle = trim($m[2], " \t\n\r\0\x0B.-_|");
    }

    return [
        'lessonno' => $lessonno,
        'lessontitle' => $lessontitle,
        'startpage' => null,
        'endpage' => null,
        'rawocr' => $raw,

        'sobai' => $lessonno,
        'tenbai' => $lessontitle,
        'trang' => null,
        'raw' => $raw,
    ];
}
//--------------------
protected static function combine_title_page_lines_2col(array $titlelines, array $pages): array {
    $items = [];
    $count = count($titlelines);
    for ($i = 0; $i < $count; $i++) {
        $parsed = self::parse_title_line_2col($titlelines[$i]);
        if (!$parsed) {
            continue;
        }
        $parsed['startpage'] = $pages[$i] ?? null;
        $parsed['trang'] = $pages[$i] ?? null;
        $items[] = $parsed;
    }
    return array_values($items);
}
protected static function ocr_title_lines_2col(array $parts, int $psm = 6): array {
    $texts = [];
    foreach ($parts as $img) {
        $prep = self::preprocess_image_for_ocr_2col($img, 'title_prep2');
        $texts[] = self::ocr_one_tesseract_exact($prep, 'vie+eng', $psm);
    }
    $raw = implode("\n", $texts);
    $lines = self::split_text_lines($raw);
    $lines = self::extract_toc_region_2col($lines);
    $lines = self::merge_wrapped_lines_2col($lines);
    $lines = self::filter_title_lines_2col($lines);
    self::debug_log('2COL TITLE RAW', $raw);
    self::debug_log('2COL TITLE LINES', $lines);
    return $lines;
}
protected static function ocr_page_lines_2col(array $parts): array {
    $texts = [];
    foreach ($parts as $img) {
        $prep = self::preprocess_image_for_ocr_2col($img, 'page_prep2');
        $texts[] = self::ocr_one_tesseract_exact($prep, 'eng', 6, '0123456789OolIsSBZT+');
    }
    $raw = implode("\n", $texts);
    $lines = self::split_text_lines($raw);
    $pages = self::filter_page_lines_2col($lines);
    self::debug_log('2COL PAGE RAW', $raw);
    self::debug_log('2COL PAGE TOKENS', $pages);
    return $pages;
}
protected static function split_image_columns(string $imagepath, int $splitpercent): array {
    $parts = self::cat_theo_toa_do_2col($imagepath);
    return [$parts['l'], $parts['r']];
}
protected static function ocr_one_image_2col(string $imagepath, int $psm = 6): string {
    $parts = self::cat_theo_toa_do_2col($imagepath);
    $left = self::process_half_2col($parts['l1'], $parts['l2'], $psm, 6, 'l');
    $right = self::process_half_2col($parts['r1'], $parts['r2'], $psm, 6, 'r');
    $titlelines = array_merge($left['title_lines'], $right['title_lines']);
    $pages = array_merge(
        array_map(function($x) { return $x['page']; }, $left['pairs']),
        array_map(function($x) { return $x['page']; }, $right['pairs'])
    );
    $items = self::combine_title_page_lines_2col($titlelines, $pages);
    foreach ($parts as $path) {
        if (file_exists($path)) {
            @unlink($path);
        }
    }
    $lines = [];
    foreach ($items as $item) {
	if ($item['sobai'] !== null) {
	    $line = 'Bài ' . $item['sobai'] . '. ' . $item['tenbai'];
	} else {
	    $line = $item['tenbai'];
	}
        if ($item['trang'] !== null) {
            $line .= ' ' . $item['trang'];
        }
        $lines[] = $line;
    }
    return trim(implode("\n", $lines));
}
public static function preview_topic_items_2col(int $bookid, int $columns = 2, int $splitpercent = 50, int $psm = 6): array {
    $book = self::get_book_record($bookid);
    self::get_mucluc($bookid, (int)$book->tocfrompage, (int)$book->toctopage, 200);
    $images = self::get_source_images((int)$book->courseid, $bookid);
    if (empty($images)) {
        throw new \moodle_exception('bookimagesmissing', 'local_aisgk');
    }
    $alltitlelines = [];
    $allpages = [];
    $allitems = [];
    $debughalves = [];
    foreach ($images as $img) {
        $parts = self::cat_theo_toa_do_2col($img);
        $left = self::process_half_2col($parts['l1'], $parts['l2'], $psm, 6, 'l');
        $right = self::process_half_2col($parts['r1'], $parts['r2'], $psm, 6, 'r');
        $titlelines = array_merge($left['title_lines'], $right['title_lines']);
        $pages = array_merge(
            array_map(function($x) { return $x['page']; }, $left['pairs']),
            array_map(function($x) { return $x['page']; }, $right['pairs'])
        );
        $items = self::combine_title_page_lines_2col($titlelines, $pages);
        $alltitlelines = array_merge($alltitlelines, $titlelines);
        $allpages = array_merge($allpages, $pages);
        $allitems = array_merge($allitems, $items);
        $debughalves[] = [
            'image' => basename($img),
            'left_pairs' => $left['pairs'],
            'right_pairs' => $right['pairs'],
        ];
        foreach ($parts as $path) {
            if (file_exists($path)) {
                @unlink($path);
            }
        }
    }
    self::debug_log('2COL COMBINED TITLES', $alltitlelines);
    self::debug_log('2COL COMBINED PAGES', $allpages);
    self::debug_log('2COL ITEMS', $allitems);
    self::debug_log('2COL HALVES PAIRED', $debughalves);
return [
    'raw' => implode("\n", array_map(function($item) {
        $line = '';

        if (isset($item['sobai']) && $item['sobai'] !== null) {
            $line = 'Bài ' . $item['sobai'] . '. ' . ($item['tenbai'] ?? '');
        } else {
            $line = (string)($item['tenbai'] ?? '');
        }

        if (isset($item['trang']) && $item['trang'] !== null) {
            $line .= ' ' . $item['trang'];
        }

        return trim($line);
    }, $allitems)),
    'content_lines' => $alltitlelines,
    'toc_lines' => $alltitlelines,
    'matched_lines' => $alltitlelines,
    'page_lines' => $allpages,
    'items' => $allitems,
    'preview' => implode("\n", array_map(function($item) {
        $line = '';

        if (isset($item['sobai']) && $item['sobai'] !== null) {
            $line = 'Bài ' . $item['sobai'] . '. ' . ($item['tenbai'] ?? '');
        } else {
            $line = (string)($item['tenbai'] ?? '');
        }

        if (isset($item['trang']) && $item['trang'] !== null) {
            $line .= ' ' . $item['trang'];
        }

        return trim($line);
    }, $allitems)),
    ];
}
protected static function ocr_one_image(string $imagepath, int $columns = 1, int $splitpercent = 50, string $lang = 'vie', int $psm = 3): string {
    [$columns, $splitpercent] = self::normalize_column_options($columns, $splitpercent);
    if ($columns !== 2) {
        return self::ocr_one_tesseract($imagepath, $lang, $psm);
    }
    return self::ocr_one_image_2col($imagepath, max(6, (int)$psm));
}
}
