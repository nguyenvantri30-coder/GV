<?php
namespace local_aisgk\local;

defined('MOODLE_INTERNAL') || die();

use local_aisgk\book_repository;

class sgk_processor {
    public const COMPONENT = 'local_aisgk';
    public const FILEAREA = 'bookpdf';

    protected static function get_book_record(int $bookid): \stdClass {
        $book = book_repository::get_by_id($bookid);
        if (!$book) {
            throw new \moodle_exception('invalidparameter');
        }
        return $book;
    }

    protected static function get_book_file(int $bookid): \stored_file {
        $book = self::get_book_record($bookid);
        $context = \context_course::instance((int)$book->courseid);
        $fs = get_file_storage();
        $files = $fs->get_area_files($context->id, self::COMPONENT, self::FILEAREA, (int)$book->fileitemid, 'itemid, filepath, filename', false);
        foreach ($files as $file) {
            if (!$file->is_directory()) {
                return $file;
            }
        }
        throw new \moodle_exception('bookrequired', 'local_aisgk');
    }

    public static function get_temp_dir(int $courseid, int $bookid): string {
        global $CFG;
        $dir = $CFG->dataroot . '/local_aisgk/tmp/' . $courseid . '/' . $bookid;
        if (!is_dir($dir)) {
            mkdir($dir, $CFG->directorypermissions, true);
        }
        return $dir;
    }

    public static function clear_temp_dir(int $courseid, int $bookid): void {
        $dir = self::get_temp_dir($courseid, $bookid);
        foreach (glob($dir . '/*') ?: [] as $file) {
            @unlink($file);
        }
    }

    protected static function export_pdf_to_temp(int $bookid): string {
        $book = self::get_book_record($bookid);
        $storedfile = self::get_book_file($bookid);
        $dir = self::get_temp_dir((int)$book->courseid, $bookid);
        $pdfpath = $dir . '/book_' . $bookid . '.pdf';
        @unlink($pdfpath);
        $storedfile->copy_content_to($pdfpath);
        if (!is_file($pdfpath) || filesize($pdfpath) < 1) {
            throw new \moodle_exception('errorprocessingbook', 'local_aisgk');
        }
        return $pdfpath;
    }

    public static function get_source_images(int $courseid, int $bookid): array {
        $images = glob(self::get_temp_dir($courseid, $bookid) . '/' . $bookid . '_*.png') ?: [];
        $images = array_values(array_filter($images, static function(string $path): bool {
            return (bool)preg_match('/_\d+\.png$/', $path);
        }));
        natsort($images);
        return array_values($images);
    }

    public static function render_toc_images(int $bookid, int $frompage, int $topage, int $dpi = 200, ?callable $progresscallback = null): array {
        $book = self::get_book_record($bookid);
        if ($frompage < 1 || $topage < $frompage) {
            throw new \invalid_parameter_exception('Khoảng trang không hợp lệ');
        }
        self::clear_temp_dir((int)$book->courseid, $bookid);
        $pdfpath = self::export_pdf_to_temp($bookid);
        $dir = self::get_temp_dir((int)$book->courseid, $bookid);
        return ocr_runner::render_pdf_pages($pdfpath, $dir, $bookid, $frompage, $topage, $dpi, $progresscallback);
    }


    public static function render_page_images_cached(int $bookid, int $courseid, int $sectionid, int $frompage, int $topage, int $dpi = 180, ?callable $progresscallback = null, bool $color = false, int $cachewidth = 1000): array {
        global $CFG;
        $book = self::get_book_record($bookid);
        $courseid = $courseid > 0 ? $courseid : (int)$book->courseid;
        $sectionid = max(0, $sectionid);
        $cachewidth = max(0, (int)$cachewidth);
        if ($frompage < 1 || $topage < $frompage) {
            throw new \invalid_parameter_exception('Khoảng trang không hợp lệ');
        }

        $total = $topage - $frompage + 1;
        $done = 0;
        $images = [];
        $pdfpath = null;
        $tmpdir = self::get_temp_dir($courseid, $bookid) . '/pagecache_' . time() . '_' . random_int(1000, 9999);

        for ($page = $frompage; $page <= $topage; $page++) {
            if (!$color) {
                $cached = page_cache::get_valid_cached_path($courseid, $sectionid, $bookid, $page, $dpi);
                if ($cached !== null) {
                    $images[] = $cached;
                    $done++;
                    if ($progresscallback) { $progresscallback($done, $total); }
                    continue;
                }
            } else {
                $rel = 'local_aisgk/pagecache_color_v2/course_' . $courseid . '/book_' . $bookid . '/section_' . $sectionid . '/page_' . $page . '_color_w' . $cachewidth . '_dpi' . $dpi . '.jpg';
                $dest = rtrim($CFG->dataroot, '/') . '/' . $rel;
                if (is_file($dest) && filesize($dest) > 100) {
                    @touch($dest);
                    $images[] = $dest;
                    $done++;
                    if ($progresscallback) { $progresscallback($done, $total); }
                    continue;
                }
            }

            if ($pdfpath === null) { $pdfpath = self::export_pdf_to_temp($bookid); }
            if (!is_dir($tmpdir)) { mkdir($tmpdir, $CFG->directorypermissions, true); }
            foreach (glob($tmpdir . '/*') ?: [] as $old) { @unlink($old); }
            $rendered = ocr_runner::render_pdf_pages($pdfpath, $tmpdir, $bookid, $page, $page, $dpi, null, $color);
            $src = $rendered[0] ?? '';
            if ($src === '' || !is_file($src)) { throw new \moodle_exception('bookimagesmissing', 'local_aisgk'); }

            if ($color) {
                $rel = 'local_aisgk/pagecache_color_v2/course_' . $courseid . '/book_' . $bookid . '/section_' . $sectionid . '/page_' . $page . '_color_w' . $cachewidth . '_dpi' . $dpi . '.jpg';
                $dest = rtrim($CFG->dataroot, '/') . '/' . $rel;
                $dir = dirname($dest);
                if (!is_dir($dir)) { mkdir($dir, $CFG->directorypermissions, true); }
                if (!page_cache::save_resized_jpeg($src, $dest, $cachewidth)) {
                    throw new \moodle_exception('errorprocessingbook', 'local_aisgk', '', 'Không lưu được cache ảnh màu trang SGK.');
                }
                @chmod($dest, $CFG->filepermissions);
                $images[] = $dest;
            } else {
                $images[] = page_cache::store_rendered_file($courseid, $sectionid, $bookid, $page, $dpi, $src);
            }
            $done++;
            if ($progresscallback) { $progresscallback($done, $total); }
        }
        foreach (glob($tmpdir . '/*') ?: [] as $old) { @unlink($old); }
        @rmdir($tmpdir);
        return $images;
    }
}
