<?php
namespace local_aisgk\local;

defined('MOODLE_INTERNAL') || die();

class command_runner {
    public static function run(string $command, ?string $cwd = null): array {
        $descriptor = [
            0 => ['pipe', 'r'],
            1 => ['pipe', 'w'],
            2 => ['pipe', 'w'],
        ];

        $process = proc_open($command, $descriptor, $pipes, $cwd);
        if (!is_resource($process)) {
            throw new \moodle_exception('errorprocessingbook', 'local_aisgk', '', null, 'Không thể chạy tiến trình hệ thống.');
        }

        fclose($pipes[0]);
        $stdout = stream_get_contents($pipes[1]);
        $stderr = stream_get_contents($pipes[2]);
        fclose($pipes[1]);
        fclose($pipes[2]);

        $code = proc_close($process);
        return [
            'code' => (int)$code,
            'stdout' => trim((string)$stdout),
            'stderr' => trim((string)$stderr),
            'output' => trim(trim((string)$stdout) . "\n" . trim((string)$stderr)),
        ];
    }
}
