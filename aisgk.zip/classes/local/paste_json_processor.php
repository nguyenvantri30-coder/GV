<?php
namespace local_aisgk\local;

defined('MOODLE_INTERNAL') || die();

class paste_json_processor {
    protected static function strip_fences(string $text): string {
        $text = trim($text);
        $text = preg_replace('/^```(?:json)?\s*/i', '', $text);
        $text = preg_replace('/\s*```$/', '', $text);
        return trim($text);
    }

    protected static function extract_json_candidate(string $text): string {
        $text = self::strip_fences($text);
        $len = strlen($text);
        $start = false;
        for ($i = 0; $i < $len; $i++) {
            if ($text[$i] === '{' || $text[$i] === '[') { $start = $i; break; }
        }
        if ($start === false) { return $text; }
        $stack = [];
        $instr = false;
        $esc = false;
        for ($i = $start; $i < $len; $i++) {
            $ch = $text[$i];
            if ($instr) {
                if ($esc) { $esc = false; continue; }
                if ($ch === '\\') { $esc = true; continue; }
                if ($ch === '"') { $instr = false; }
                continue;
            }
            if ($ch === '"') { $instr = true; continue; }
            if ($ch === '{' || $ch === '[') { $stack[] = $ch; continue; }
            if ($ch === '}' || $ch === ']') {
                if (!$stack) { break; }
                $open = array_pop($stack);
                if (($open === '{' && $ch !== '}') || ($open === '[' && $ch !== ']')) { break; }
                if (!$stack) { return substr($text, $start, $i - $start + 1); }
            }
        }
        return substr($text, $start);
    }

    protected static function repair_slashes(string $text): string {
        return preg_replace('/\\\\(?!["\\\\\/bfnrtu])/', '\\\\\\\\', $text);
    }

    protected static function decode(string $raw): array {
        $candidate = self::extract_json_candidate($raw);
        $try = [$candidate, self::repair_slashes($candidate)];
        foreach ($try as $text) {
            $json = json_decode($text, true);
            if (is_array($json)) { return $json; }
            if (is_string($json)) {
                $json2 = json_decode(trim($json), true);
                if (is_array($json2)) { return $json2; }
                $json2 = json_decode(self::repair_slashes(trim($json)), true);
                if (is_array($json2)) { return $json2; }
            }
        }
        throw new \moodle_exception('JSON paste lỗi: ' . json_last_error_msg());
    }

    protected static function normalize_qtype(string $type): string {
        $t = strtolower(trim($type));
        $map = [
            'multiplechoice' => 'multichoice', 'multi_choice' => 'multichoice', 'mcq' => 'multichoice',
            'true_false' => 'truefalse', 'short_answer' => 'shortanswer', 'number' => 'numerical',
            'gap_select' => 'gapselect', 'dragdroptext' => 'ddwtos', 'drag_and_drop_into_text' => 'ddwtos',
        ];
        return $map[$t] ?? $t;
    }

    protected static function normalize_level(string $level): string {
        $l = strtolower(trim($level));
        $map = [
            'recognize' => 'nhan_biet', 'nhận biết' => 'nhan_biet', 'nhan biet' => 'nhan_biet', 'nhan_biet' => 'nhan_biet',
            'understand' => 'thong_hieu', 'thông hiểu' => 'thong_hieu', 'thong hieu' => 'thong_hieu', 'thong_hieu' => 'thong_hieu',
            'apply' => 'van_dung', 'vận dụng' => 'van_dung', 'van dung' => 'van_dung', 'van_dung' => 'van_dung',
        ];
        return $map[$l] ?? $l;
    }

    protected static function normalize_counts(array $in, string $kind): array {
        $out = [];
        foreach ($in as $k => $v) {
            $key = $kind === 'level' ? self::normalize_level((string)$k) : self::normalize_qtype((string)$k);
            $n = (int)$v;
            if ($key !== '' && $n > 0) { $out[$key] = $n; }
        }
        return $out;
    }

    protected static function infer_teacher_config(array $root, array $fallbackoptions, array $questions): array {
        $tc = is_array($root['TEACHER_CONFIG'] ?? null) ? $root['TEACHER_CONFIG'] : (is_array($root['teacher_config'] ?? null) ? $root['teacher_config'] : []);
        if (!$tc) { $tc = ai_service::teacher_config_from_options($fallbackoptions); }
        $qtypes = self::normalize_counts(is_array($tc['qtypes'] ?? null) ? $tc['qtypes'] : ($fallbackoptions['qtypes'] ?? []), 'type');
        $levels = self::normalize_counts(is_array($tc['cognitive'] ?? null) ? $tc['cognitive'] : (is_array($tc['levels'] ?? null) ? $tc['levels'] : ($fallbackoptions['cognitive'] ?? [])), 'level');
        if (!$qtypes || !$levels) {
            foreach ($questions as $q) {
                if (!is_array($q)) { continue; }
                $t = self::normalize_qtype((string)($q['type'] ?? $q['qtype'] ?? ''));
                $l = self::normalize_level((string)($q['level'] ?? ''));
                if ($t !== '') { $qtypes[$t] = ($qtypes[$t] ?? 0) + 1; }
                if ($l !== '') { $levels[$l] = ($levels[$l] ?? 0) + 1; }
            }
        }
        $allowed = ['multichoice','matching','gapselect','ddwtos','ddimageortext','ddmarker'];
        $din = is_array($tc['distractors'] ?? null) ? $tc['distractors'] : ($fallbackoptions['distractors'] ?? []);
        $distractors = [];
        foreach ($allowed as $type) { $distractors[$type] = !empty($din[$type]) ? 1 : 0; }
        return ['total' => array_sum($qtypes), 'qtypes' => $qtypes, 'cognitive' => $levels, 'distractors' => $distractors];
    }

    protected static function normalize_plan($plan): array {
        $out = [];
        if (!is_array($plan)) { return $out; }
        foreach (array_values($plan) as $i => $row) {
            if (!is_array($row)) { continue; }
            $out[] = [
                'question_no' => (int)($row['question_no'] ?? ($i + 1)),
                'type' => self::normalize_qtype((string)($row['type'] ?? $row['qtype'] ?? '')),
                'level' => self::normalize_level((string)($row['level'] ?? '')),
            ];
        }
        return $out;
    }

    public static function process(string $raw, array $fallbackoptions): array {
        $root = self::decode($raw);
        $questions = [];
        if (isset($root['questions']) && is_array($root['questions'])) {
            $questions = array_values($root['questions']);
        } else if (array_is_list($root)) {
            $questions = array_values($root);
        }
        $teacherconfig = self::infer_teacher_config($root, $fallbackoptions, $questions);
        $plan = self::normalize_plan($root['QUESTION_PLAN'] ?? ($root['question_plan'] ?? []));
        $options = $fallbackoptions;
        $options['qtypes'] = $teacherconfig['qtypes'];
        $options['cognitive'] = $teacherconfig['cognitive'];
        $options['total'] = $teacherconfig['total'];
        $options['distractors'] = $teacherconfig['distractors'];
        $options['_teacher_config'] = $teacherconfig;
        if ($plan) { $options['_question_plan'] = $plan; }
        $normalized = ai_service::normalize_homework_questions($questions, $options);
        foreach ($normalized as $i => $q) { $normalized[$i]['question_no'] = $i + 1; unset($normalized[$i]['name'], $normalized[$i]['qtype']); }
        $report = ai_service::validate_homework_against_plan($normalized, $options);
        $payload = ['TEACHER_CONFIG' => $teacherconfig, 'QUESTION_PLAN' => $plan, 'questions' => array_values($normalized)];
        return [
            'teacher_config' => $teacherconfig,
            'question_plan' => $plan,
            'questions' => array_values($normalized),
            'options' => $options,
            'report' => $report,
            'normalizedjson' => json_encode($payload, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES),
        ];
    }
}
