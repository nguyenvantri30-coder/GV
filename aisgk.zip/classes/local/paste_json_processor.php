<?php
namespace local_aisgk\local;

defined('MOODLE_INTERNAL') || die();

class paste_json_processor {
    protected static function strip_fences(string $text): string {
        $text = trim($text);
        $text = preg_replace('/^```(?:json)?\s*/i', '', $text);
        $text = preg_replace('/\s*```$/', '', $text);
        return trim($text);
    }

    protected static function extract_json_candidate(string $text): string {
        $text = self::strip_fences($text);
        $len = strlen($text);
        $start = false;
        for ($i = 0; $i < $len; $i++) {
            if ($text[$i] === '{' || $text[$i] === '[') { $start = $i; break; }
        }
        if ($start === false) { return $text; }
        $stack = [];
        $instr = false;
        $esc = false;
        for ($i = $start; $i < $len; $i++) {
            $ch = $text[$i];
            if ($instr) {
                if ($esc) { $esc = false; continue; }
                if ($ch === '\\') { $esc = true; continue; }
                if ($ch === '"') { $instr = false; }
                continue;
            }
            if ($ch === '"') { $instr = true; continue; }
            if ($ch === '{' || $ch === '[') { $stack[] = $ch; continue; }
            if ($ch === '}' || $ch === ']') {
                if (!$stack) { break; }
                $open = array_pop($stack);
                if (($open === '{' && $ch !== '}') || ($open === '[' && $ch !== ']')) { break; }
                if (!$stack) { return substr($text, $start, $i - $start + 1); }
            }
        }
        return substr($text, $start);
    }

    protected static function repair_slashes(string $text): string {
        // Legacy wrapper: dùng bộ sửa tổng quát theo trạng thái chuỗi JSON.
        return self::repair_latex_backslashes($text);
    }

    protected static function is_hex4(string $s): bool {
        return (bool)preg_match('/^[0-9a-fA-F]{4}$/', $s);
    }

    protected static function repair_latex_backslashes(string $text): string {
        // Chỉ sửa bên trong JSON string. Mục tiêu: giữ escape JSON thật
        // (\", \\, \/, \u1234, \n, \t...) nhưng biến LaTeX raw như
        // \(, \), \in, \notin, \times, \frac, \begin, \rangle... thành JSON-safe.
        $out = '';
        $len = strlen($text);
        $instr = false;
        $i = 0;
        while ($i < $len) {
            $ch = $text[$i];
            if (!$instr) {
                if ($ch === '"') { $instr = true; }
                $out .= $ch;
                $i++;
                continue;
            }
            if ($ch === '"') {
                $instr = false;
                $out .= $ch;
                $i++;
                continue;
            }
            if ($ch !== '\\') {
                $out .= $ch;
                $i++;
                continue;
            }

            $next = ($i + 1 < $len) ? $text[$i + 1] : '';
            $after = ($i + 2 < $len) ? $text[$i + 2] : '';

            if ($next === '') {
                $out .= '\\\\';
                $i++;
                continue;
            }

            // Escape JSON chắc chắn hợp lệ, giữ nguyên.
            if ($next === '"' || $next === '\\' || $next === '/') {
                $out .= '\\' . $next;
                $i += 2;
                continue;
            }
            if ($next === 'u' && $i + 5 < $len && self::is_hex4(substr($text, $i + 2, 4))) {
                $out .= substr($text, $i, 6);
                $i += 6;
                continue;
            }

            // Các escape JSON một ký tự: chỉ giữ nếu thật sự là escape điều khiển ngắn.
            // Nếu sau n/t/r/b/f/u còn chữ cái thì gần như chắc là lệnh LaTeX: \notin, \times,
            // \rangle, \begin, \frac... => phải escape dấu backslash.
            if (strpos('ntrbf', $next) !== false && $after !== '' && !preg_match('/[A-Za-z]/', $after)) {
                $out .= '\\' . $next;
                $i += 2;
                continue;
            }

            // Còn lại coi là backslash LaTeX/raw cần nhân đôi để json_decode không nuốt mất.
            $out .= '\\\\' . $next;
            $i += 2;
        }
        return $out;
    }

    protected static function repair_inner_quotes(string $text): string {
        // Sửa lỗi phổ biến khi AI đặt dấu " bên trong chuỗi nhưng không escape, ví dụ:
        // "questiontext": "...: "Phần tử 3 thuộc tập hợp \(A\)".",
        // Quy tắc: khi đang ở trong string, dấu " chỉ được xem là đóng chuỗi nếu ký tự
        // không trắng tiếp theo là :, ,, }, ], hoặc hết chuỗi. Ngược lại escape thành \".
        $out = '';
        $len = strlen($text);
        $instr = false;
        for ($i = 0; $i < $len; $i++) {
            $ch = $text[$i];
            if (!$instr) {
                if ($ch === '"') { $instr = true; }
                $out .= $ch;
                continue;
            }
            if ($ch === '\\') {
                // Không coi backslash raw là escape ở bước quote repair, vì LaTeX như \( hoặc
                // \notin không phải escape JSON hợp lệ. Copy cả cụm, bước sau sẽ sửa backslash.
                $out .= $ch;
                continue;
            }
            if ($ch === '"') {
                $j = $i + 1;
                while ($j < $len && preg_match('/\s/', $text[$j])) { $j++; }
                $next = $j < $len ? $text[$j] : '';
                if ($next === ':' || $next === ',' || $next === '}' || $next === ']' || $next === '') {
                    $instr = false;
                    $out .= $ch;
                } else {
                    $out .= '\\"';
                }
                continue;
            }
            $out .= $ch;
        }
        return $out;
    }

    protected static function decode(string $raw): array {
        $candidate = self::extract_json_candidate($raw);
        $qfixed = self::repair_inner_quotes($candidate);
        $try = [
            $candidate,
            self::repair_latex_backslashes($candidate),
            $qfixed,
            self::repair_latex_backslashes($qfixed),
        ];
        $try = array_values(array_unique($try));
        $last = '';
        foreach ($try as $text) {
            $json = json_decode($text, true);
            if (is_array($json)) { return $json; }
            $last = json_last_error_msg();
            if (is_string($json)) {
                $inner = trim($json);
                $json2 = json_decode($inner, true);
                if (is_array($json2)) { return $json2; }
                $last = json_last_error_msg();
                $json2 = json_decode(self::repair_latex_backslashes(self::repair_inner_quotes($inner)), true);
                if (is_array($json2)) { return $json2; }
                $last = json_last_error_msg();
            }
        }
        throw new \moodle_exception('JSON paste lỗi: ' . ($last ?: json_last_error_msg()));
    }

    protected static function normalize_qtype(string $type): string {
        $t = strtolower(trim($type));
        $map = [
            'multiplechoice' => 'multichoice', 'multi_choice' => 'multichoice', 'mcq' => 'multichoice',
            'true_false' => 'truefalse', 'short_answer' => 'shortanswer', 'number' => 'numerical',
            'gap_select' => 'gapselect', 'dragdroptext' => 'ddwtos', 'drag_and_drop_into_text' => 'ddwtos',
        ];
        return $map[$t] ?? $t;
    }

    protected static function normalize_level(string $level): string {
        $l = strtolower(trim($level));
        $map = [
            'recognize' => 'nhan_biet', 'nhận biết' => 'nhan_biet', 'nhan biet' => 'nhan_biet', 'nhan_biet' => 'nhan_biet',
            'understand' => 'thong_hieu', 'thông hiểu' => 'thong_hieu', 'thong hieu' => 'thong_hieu', 'thong_hieu' => 'thong_hieu',
            'apply' => 'van_dung', 'vận dụng' => 'van_dung', 'van dung' => 'van_dung', 'van_dung' => 'van_dung',
        ];
        return $map[$l] ?? $l;
    }

    protected static function normalize_counts(array $in, string $kind): array {
        $out = [];
        foreach ($in as $k => $v) {
            $key = $kind === 'level' ? self::normalize_level((string)$k) : self::normalize_qtype((string)$k);
            $n = (int)$v;
            if ($key !== '' && $n > 0) { $out[$key] = $n; }
        }
        return $out;
    }

    protected static function infer_teacher_config(array $root, array $fallbackoptions, array $questions): array {
        $tc = is_array($root['TEACHER_CONFIG'] ?? null) ? $root['TEACHER_CONFIG'] : (is_array($root['teacher_config'] ?? null) ? $root['teacher_config'] : []);
        if (!$tc) { $tc = ai_service::teacher_config_from_options($fallbackoptions); }
        $qtypes = self::normalize_counts(is_array($tc['qtypes'] ?? null) ? $tc['qtypes'] : ($fallbackoptions['qtypes'] ?? []), 'type');
        $levels = self::normalize_counts(is_array($tc['cognitive'] ?? null) ? $tc['cognitive'] : (is_array($tc['levels'] ?? null) ? $tc['levels'] : ($fallbackoptions['cognitive'] ?? [])), 'level');
        if (!$qtypes || !$levels) {
            foreach ($questions as $q) {
                if (!is_array($q)) { continue; }
                $t = self::normalize_qtype((string)($q['type'] ?? $q['qtype'] ?? ''));
                $l = self::normalize_level((string)($q['level'] ?? ''));
                if ($t !== '') { $qtypes[$t] = ($qtypes[$t] ?? 0) + 1; }
                if ($l !== '') { $levels[$l] = ($levels[$l] ?? 0) + 1; }
            }
        }
        $allowed = ['multichoice','matching','gapselect','ddwtos','ddimageortext','ddmarker'];
        $din = is_array($tc['distractors'] ?? null) ? $tc['distractors'] : ($fallbackoptions['distractors'] ?? []);
        $distractors = [];
        foreach ($allowed as $type) { $distractors[$type] = !empty($din[$type]) ? 1 : 0; }
        return ['total' => array_sum($qtypes), 'qtypes' => $qtypes, 'cognitive' => $levels, 'distractors' => $distractors];
    }

    protected static function normalize_plan($plan): array {
        $out = [];
        if (!is_array($plan)) { return $out; }
        foreach (array_values($plan) as $i => $row) {
            if (!is_array($row)) { continue; }
            $out[] = [
                'question_no' => (int)($row['question_no'] ?? ($i + 1)),
                'type' => self::normalize_qtype((string)($row['type'] ?? $row['qtype'] ?? '')),
                'level' => self::normalize_level((string)($row['level'] ?? '')),
            ];
        }
        return $out;
    }


    protected static function normalize_pageimg_sources_in_questions(array $questions): array {
        foreach ($questions as $qi => $q) {
            if (!is_array($q) || empty($q['images']) || !is_array($q['images'])) {
                continue;
            }
            foreach ($q['images'] as $id => $meta) {
                if (!is_array($meta)) { continue; }
                $source = trim((string)($meta['source'] ?? ''));
                if ($source !== '' && preg_match('#/local/aisgk/pageimg\.php\?([^"\']+)#i', $source, $m)) {
                    $query = html_entity_decode($m[1], ENT_QUOTES | ENT_HTML5, 'UTF-8');
                    parse_str($query, $params);
                    if (!empty($params['page'])) {
                        $meta['source'] = 'sgk';
                        $meta['page'] = (int)$params['page'];
                        unset($meta['url']);
                        if (!empty($params['width']) && empty($meta['target_width'])) {
                            $meta['target_width'] = (int)$params['width'];
                        }
                    }
                }
                $q['images'][$id] = $meta;
            }
            $questions[$qi] = $q;
        }
        return $questions;
    }

    public static function process(string $raw, array $fallbackoptions): array {
        $root = self::decode($raw);
        $questions = [];
        if (isset($root['questions']) && is_array($root['questions'])) {
            $questions = array_values($root['questions']);
        } else if (array_is_list($root)) {
            $questions = array_values($root);
        }
        $questions = self::normalize_pageimg_sources_in_questions($questions);
        $teacherconfig = self::infer_teacher_config($root, $fallbackoptions, $questions);
        $plan = self::normalize_plan($root['QUESTION_PLAN'] ?? ($root['question_plan'] ?? []));
        $options = $fallbackoptions;
        $options['qtypes'] = $teacherconfig['qtypes'];
        $options['cognitive'] = $teacherconfig['cognitive'];
        $options['total'] = $teacherconfig['total'];
        $options['distractors'] = $teacherconfig['distractors'];
        $options['_teacher_config'] = $teacherconfig;
        if ($plan) { $options['_question_plan'] = $plan; }
        $normalized = ai_service::normalize_homework_questions($questions, $options);
        foreach ($normalized as $i => $q) { $normalized[$i]['question_no'] = $i + 1; unset($normalized[$i]['name'], $normalized[$i]['qtype']); }
        $report = ai_service::validate_homework_against_plan($normalized, $options);
        $payload = ['TEACHER_CONFIG' => $teacherconfig, 'QUESTION_PLAN' => $plan, 'questions' => array_values($normalized)];
        return [
            'teacher_config' => $teacherconfig,
            'question_plan' => $plan,
            'questions' => array_values($normalized),
            'options' => $options,
            'report' => $report,
            'normalizedjson' => json_encode($payload, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES),
        ];
    }
}
