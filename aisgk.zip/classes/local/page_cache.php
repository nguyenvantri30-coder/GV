<?php
namespace local_aisgk\local;

defined('MOODLE_INTERNAL') || die();

/**
 * Cache rendered SGK page images so repeated homework generations do not
 * render the same PDF page again and again.
 */
class page_cache {
    public const TABLE = 'local_aisgk_pagecache';
    public const RELROOT = 'local_aisgk/pagecache';
    public const TTL = 86400; // 1 day: only keep resized temporary AI/page images.

    public static function relative_path(int $courseid, int $bookid, int $sectionid, int $pageno, int $dpi): string {
        return self::RELROOT . '/course_' . $courseid . '/book_' . $bookid . '/section_' . $sectionid . '/page_' . $pageno . '_w1000_dpi' . $dpi . '.jpg';
    }

    public static function absolute_path(string $relativepath): string {
        global $CFG;
        $relativepath = ltrim(str_replace(['..', '\\'], ['', '/'], $relativepath), '/');
        return rtrim($CFG->dataroot, '/') . '/' . $relativepath;
    }

    public static function get_valid_cached_path(int $courseid, int $sectionid, int $bookid, int $pageno, int $dpi): ?string {
        global $DB;
        if (!$DB->get_manager()->table_exists(self::TABLE)) {
            return null;
        }
        $params = [
            'courseid' => $courseid,
            'sectionid' => $sectionid,
            'bookid' => $bookid,
            'pageno' => $pageno,
            'dpi' => $dpi,
        ];
        $rec = $DB->get_record(self::TABLE, $params);
        if (!$rec || empty($rec->filepath)) {
            return null;
        }
        $path = self::absolute_path((string)$rec->filepath);
        if (!is_file($path) || filesize($path) < 1) {
            $DB->delete_records(self::TABLE, ['id' => (int)$rec->id]);
            return null;
        }
        $DB->update_record(self::TABLE, (object)[
            'id' => (int)$rec->id,
            'lastused' => time(),
            'timemodified' => time(),
        ]);
        return $path;
    }

    public static function store_rendered_file(int $courseid, int $sectionid, int $bookid, int $pageno, int $dpi, string $sourcefile): string {
        global $DB, $CFG;
        $rel = self::relative_path($courseid, $bookid, $sectionid, $pageno, $dpi);
        $dest = self::absolute_path($rel);
        $dir = dirname($dest);
        if (!is_dir($dir)) {
            mkdir($dir, $CFG->directorypermissions, true);
        }
        if (!self::save_resized_jpeg($sourcefile, $dest, 1000)) {
            throw new \moodle_exception('errorprocessingbook', 'local_aisgk', '', 'Không lưu được cache ảnh trang SGK đã resize.');
        }
        @chmod($dest, $CFG->filepermissions);

        if ($DB->get_manager()->table_exists(self::TABLE)) {
            $now = time();
            $params = [
                'courseid' => $courseid,
                'sectionid' => $sectionid,
                'bookid' => $bookid,
                'pageno' => $pageno,
                'dpi' => $dpi,
            ];
            $rec = $DB->get_record(self::TABLE, $params);
            $data = (object)($params + [
                'filepath' => $rel,
                'filesize' => filesize($dest) ?: 0,
                'timemodified' => $now,
                'lastused' => $now,
            ]);
            if ($rec) {
                $data->id = (int)$rec->id;
                $DB->update_record(self::TABLE, $data);
            } else {
                $data->timecreated = $now;
                $DB->insert_record(self::TABLE, $data);
            }
        }
        return $dest;
    }


    public static function save_resized_jpeg(string $sourcefile, string $dest, int $targetw = 1000): bool {
        if (!is_file($sourcefile)) { return false; }
        $info = @getimagesize($sourcefile);
        if (!$info || empty($info[0]) || empty($info[1])) { return false; }
        $src = null;
        $ext = strtolower(pathinfo($sourcefile, PATHINFO_EXTENSION));
        if (($ext === 'jpg' || $ext === 'jpeg') && function_exists('imagecreatefromjpeg')) {
            $src = @imagecreatefromjpeg($sourcefile);
        } else if ($ext === 'webp' && function_exists('imagecreatefromwebp')) {
            $src = @imagecreatefromwebp($sourcefile);
        } else if (function_exists('imagecreatefrompng')) {
            $src = @imagecreatefrompng($sourcefile);
        }
        if (!$src) { return false; }
        $w = (int)$info[0];
        $h = (int)$info[1];
        $neww = $targetw > 0 ? min(max(1, $targetw), $w) : $w;
        $newh = max(1, (int)round($h * ($neww / max(1, $w))));
        $out = function_exists('imagescale') ? @imagescale($src, $neww, $newh) : false;
        imagedestroy($src);
        if (!$out) { return false; }
        if (function_exists('imageconvolution')) {
            @imageconvolution($out, [[0,-1,0],[-1,5,-1],[0,-1,0]], 1, 0);
        }
        $ok = @imagejpeg($out, $dest, 85);
        imagedestroy($out);
        return (bool)$ok;
    }

    public static function cleanup(int $ttl = self::TTL): array {
        global $DB;
        $deleted = 0;
        $bytes = 0;
        if (!$DB->get_manager()->table_exists(self::TABLE)) {
            return ['deleted' => 0, 'bytes' => 0];
        }
        $cutoff = time() - max(3600, $ttl);
        $records = $DB->get_records_select(self::TABLE, 'lastused < ?', [$cutoff]);
        foreach ($records as $rec) {
            $path = self::absolute_path((string)$rec->filepath);
            if (is_file($path)) {
                $bytes += filesize($path) ?: 0;
                @unlink($path);
            }
            $DB->delete_records(self::TABLE, ['id' => (int)$rec->id]);
            $deleted++;
        }
        return ['deleted' => $deleted, 'bytes' => $bytes];
    }
}
