<?php
namespace local_aisgk\local;

defined('MOODLE_INTERNAL') || die();

/**
 * Cache rendered SGK page images so repeated homework generations do not
 * render the same PDF page again and again.
 */
class page_cache {
    public const TABLE = 'local_aisgk_pagecache';
    public const RELROOT = 'local_aisgk/pagecache';
    public const TTL = 604800; // 7 days.

    public static function relative_path(int $courseid, int $bookid, int $sectionid, int $pageno, int $dpi): string {
        return self::RELROOT . '/course_' . $courseid . '/book_' . $bookid . '/section_' . $sectionid . '/page_' . $pageno . '_dpi' . $dpi . '.png';
    }

    public static function absolute_path(string $relativepath): string {
        global $CFG;
        $relativepath = ltrim(str_replace(['..', '\\'], ['', '/'], $relativepath), '/');
        return rtrim($CFG->dataroot, '/') . '/' . $relativepath;
    }

    public static function get_valid_cached_path(int $courseid, int $sectionid, int $bookid, int $pageno, int $dpi): ?string {
        global $DB;
        if (!$DB->get_manager()->table_exists(self::TABLE)) {
            return null;
        }
        $params = [
            'courseid' => $courseid,
            'sectionid' => $sectionid,
            'bookid' => $bookid,
            'pageno' => $pageno,
            'dpi' => $dpi,
        ];
        $rec = $DB->get_record(self::TABLE, $params);
        if (!$rec || empty($rec->filepath)) {
            return null;
        }
        $path = self::absolute_path((string)$rec->filepath);
        if (!is_file($path) || filesize($path) < 1) {
            $DB->delete_records(self::TABLE, ['id' => (int)$rec->id]);
            return null;
        }
        $DB->update_record(self::TABLE, (object)[
            'id' => (int)$rec->id,
            'lastused' => time(),
            'timemodified' => time(),
        ]);
        return $path;
    }

    public static function store_rendered_file(int $courseid, int $sectionid, int $bookid, int $pageno, int $dpi, string $sourcefile): string {
        global $DB, $CFG;
        $rel = self::relative_path($courseid, $bookid, $sectionid, $pageno, $dpi);
        $dest = self::absolute_path($rel);
        $dir = dirname($dest);
        if (!is_dir($dir)) {
            mkdir($dir, $CFG->directorypermissions, true);
        }
        if (!@copy($sourcefile, $dest)) {
            throw new \moodle_exception('errorprocessingbook', 'local_aisgk', '', 'Không lưu được cache ảnh trang SGK.');
        }
        @chmod($dest, $CFG->filepermissions);

        if ($DB->get_manager()->table_exists(self::TABLE)) {
            $now = time();
            $params = [
                'courseid' => $courseid,
                'sectionid' => $sectionid,
                'bookid' => $bookid,
                'pageno' => $pageno,
                'dpi' => $dpi,
            ];
            $rec = $DB->get_record(self::TABLE, $params);
            $data = (object)($params + [
                'filepath' => $rel,
                'filesize' => filesize($dest) ?: 0,
                'timemodified' => $now,
                'lastused' => $now,
            ]);
            if ($rec) {
                $data->id = (int)$rec->id;
                $DB->update_record(self::TABLE, $data);
            } else {
                $data->timecreated = $now;
                $DB->insert_record(self::TABLE, $data);
            }
        }
        return $dest;
    }

    public static function cleanup(int $ttl = self::TTL): array {
        global $DB;
        $deleted = 0;
        $bytes = 0;
        if (!$DB->get_manager()->table_exists(self::TABLE)) {
            return ['deleted' => 0, 'bytes' => 0];
        }
        $cutoff = time() - max(3600, $ttl);
        $records = $DB->get_records_select(self::TABLE, 'lastused < ?', [$cutoff]);
        foreach ($records as $rec) {
            $path = self::absolute_path((string)$rec->filepath);
            if (is_file($path)) {
                $bytes += filesize($path) ?: 0;
                @unlink($path);
            }
            $DB->delete_records(self::TABLE, ['id' => (int)$rec->id]);
            $deleted++;
        }
        return ['deleted' => $deleted, 'bytes' => $bytes];
    }
}
