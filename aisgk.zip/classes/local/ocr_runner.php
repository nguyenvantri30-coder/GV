<?php
namespace local_aisgk\local;

defined('MOODLE_INTERNAL') || die();

class ocr_runner {
    protected const GS = '/usr/bin/gs';
    protected const CONVERT = '/usr/bin/convert';
    protected const TESSERACT = '/usr/bin/tesseract';
    protected const IDENTIFY = '/usr/bin/identify';

    public static function get_parallelism(): int {
        $cpu = 1;
        if (function_exists('shell_exec')) {
            $out = @shell_exec('nproc 2>/dev/null');
            if (is_string($out) && trim($out) !== '' && ctype_digit(trim($out))) {
                $cpu = max(1, (int)trim($out));
            }
        }
        return max(1, min(4, $cpu));
    }

    public static function render_pdf_pages(string $pdfpath, string $dir, int $bookid, int $frompage, int $topage, int $dpi = 200): array {
        $jobs = [];
        $index = 1;
        for ($page = $frompage; $page <= $topage; $page++, $index++) {
            $outfile = $dir . '/' . $bookid . '_' . $index . '.png';
            $command = sprintf(
                'TMPDIR=%1$s TEMP=%1$s TMP=%1$s %2$s -dSAFER -dBATCH -dNOPAUSE -sDEVICE=pnggray -r%3$d -dFirstPage=%4$d -dLastPage=%4$d -sOutputFile=%5$s %6$s',
                escapeshellarg($dir),
                escapeshellarg(self::GS),
                $dpi,
                $page,
                escapeshellarg($outfile),
                escapeshellarg($pdfpath)
            );
            $jobs[] = ['command' => $command, 'expect' => $outfile];
        }
        self::run_job_batch($jobs, $dir, self::get_parallelism());

        $files = [];
        foreach ($jobs as $job) {
            $files[] = $job['expect'];
        }
        return $files;
    }

    public static function preprocess_image(string $imagepath): string {
        $outpath = preg_replace('/\.png$/i', '_prep.png', $imagepath);
        $command = sprintf(
            '%s %s -colorspace Gray -auto-level -deskew 40%% -sharpen 0x0.7 -threshold 58%% %s',
            escapeshellarg(self::CONVERT),
            escapeshellarg($imagepath),
            escapeshellarg($outpath)
        );
        $result = command_runner::run($command);
        if ($result['code'] !== 0 || !is_file($outpath)) {
            throw new \moodle_exception('errorprocessingbook', 'local_aisgk', '', null, $result['output']);
        }
        return $outpath;
    }

    public static function get_image_size(string $imagepath): array {
        $command = sprintf('%s -format %s %s', escapeshellarg(self::IDENTIFY), escapeshellarg('%w %h'), escapeshellarg($imagepath));
        $result = command_runner::run($command);
        if ($result['code'] !== 0 || $result['stdout'] === '') {
            throw new \moodle_exception('errorprocessingbook', 'local_aisgk', '', null, $result['output']);
        }
        [$width, $height] = array_map('intval', preg_split('/\s+/', trim($result['stdout'])));
        if ($width < 1 || $height < 1) {
            throw new \moodle_exception('errorprocessingbook', 'local_aisgk', '', null, 'Không đọc được kích thước ảnh OCR.');
        }
        return [$width, $height];
    }

    public static function crop_columns(string $imagepath, int $splitpercent): array {
        [$width, $height] = self::get_image_size($imagepath);
        $splitx = (int)floor($width * max(20, min(80, $splitpercent)) / 100);
        $left = preg_replace('/\.png$/i', '_l.png', $imagepath);
        $right = preg_replace('/\.png$/i', '_r.png', $imagepath);

        $jobs = [
            [
                'command' => sprintf('%s %s -crop %s +repage %s', escapeshellarg(self::CONVERT), escapeshellarg($imagepath), escapeshellarg($splitx . 'x' . $height . '+0+0'), escapeshellarg($left)),
                'expect' => $left,
            ],
            [
                'command' => sprintf('%s %s -crop %s +repage %s', escapeshellarg(self::CONVERT), escapeshellarg($imagepath), escapeshellarg(($width - $splitx) . 'x' . $height . '+' . $splitx . '+0'), escapeshellarg($right)),
                'expect' => $right,
            ],
        ];
        self::run_job_batch($jobs, dirname($imagepath), 2);
        return [$left, $right];
    }

    public static function ocr_images(array $images, int $columns = 1, int $splitpercent = 50, int $psm = 4, string $lang = 'vie+eng'): array {
        $jobs = [];
        $ordered = [];

        foreach ($images as $image) {
            if ((int)$columns === 2) {
                [$left, $right] = self::crop_columns($image, $splitpercent);
                foreach ([$left, $right] as $part) {
                    $prepared = self::preprocess_image($part);
                    $base = preg_replace('/\.png$/i', '', $prepared);
                    $jobs[] = [
                        'command' => sprintf('%s %s %s -l %s --psm %d -c preserve_interword_spaces=1', escapeshellarg(self::TESSERACT), escapeshellarg($prepared), escapeshellarg($base), escapeshellarg($lang), $psm),
                        'expect' => $base . '.txt',
                    ];
                    $ordered[] = $base . '.txt';
                }
            } else {
                $prepared = self::preprocess_image($image);
                $base = preg_replace('/\.png$/i', '', $prepared);
                $jobs[] = [
                    'command' => sprintf('%s %s %s -l %s --psm %d -c preserve_interword_spaces=1', escapeshellarg(self::TESSERACT), escapeshellarg($prepared), escapeshellarg($base), escapeshellarg($lang), $psm),
                    'expect' => $base . '.txt',
                ];
                $ordered[] = $base . '.txt';
            }
        }

        self::run_job_batch($jobs, null, self::get_parallelism());

        $texts = [];
        foreach ($ordered as $txtfile) {
            $texts[] = is_file($txtfile) ? trim((string)file_get_contents($txtfile)) : '';
        }
        return $texts;
    }

    protected static function run_job_batch(array $jobs, ?string $cwd, int $parallelism): void {
        if (empty($jobs)) {
            return;
        }

        $parallelism = max(1, $parallelism);
        foreach (array_chunk($jobs, $parallelism) as $chunk) {
            $procs = [];
            foreach ($chunk as $idx => $job) {
                $descriptor = [0 => ['pipe', 'r'], 1 => ['pipe', 'w'], 2 => ['pipe', 'w']];
                $proc = proc_open($job['command'], $descriptor, $pipes, $cwd);
                if (!is_resource($proc)) {
                    throw new \moodle_exception('errorprocessingbook', 'local_aisgk', '', null, 'Không thể khởi tạo tiến trình OCR.');
                }
                fclose($pipes[0]);
                $procs[$idx] = ['proc' => $proc, 'pipes' => $pipes, 'expect' => $job['expect']];
            }

            foreach ($procs as $procinfo) {
                $stdout = stream_get_contents($procinfo['pipes'][1]);
                $stderr = stream_get_contents($procinfo['pipes'][2]);
                fclose($procinfo['pipes'][1]);
                fclose($procinfo['pipes'][2]);
                $code = proc_close($procinfo['proc']);
                if ($code !== 0 || !is_file($procinfo['expect'])) {
                    $output = trim(trim((string)$stdout) . "\n" . trim((string)$stderr));
                    throw new \moodle_exception('errorprocessingbook', 'local_aisgk', '', null, $output);
                }
            }
        }
    }
}
