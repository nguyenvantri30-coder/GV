<?php
namespace local_aisgk\local;

defined('MOODLE_INTERNAL') || die();

class ocr_runner {
    protected const GS = '/usr/bin/gs';
    protected const CONVERT = '/usr/bin/convert';
    protected const IDENTIFY = '/usr/bin/identify';

    public static function get_parallelism(): int {
        $cpu = 1;
        if (function_exists('shell_exec')) {
            $out = @shell_exec('nproc 2>/dev/null');
            if (is_string($out) && trim($out) !== '' && ctype_digit(trim($out))) {
                $cpu = max(1, (int)trim($out));
            }
        }
        return max(1, min(4, $cpu));
    }

    public static function render_pdf_pages(string $pdfpath, string $dir, int $bookid, int $frompage, int $topage, int $dpi = 200, ?callable $progresscallback = null, bool $color = false): array {
        $jobs = [];
        $index = 1;
        for ($page = $frompage; $page <= $topage; $page++, $index++) {
            $outfile = $dir . '/' . $bookid . '_' . $index . '.png';
            $device = $color ? 'png16m' : 'pnggray';
            $command = sprintf(
                'TMPDIR=%1$s TEMP=%1$s TMP=%1$s %2$s -dSAFER -dBATCH -dNOPAUSE -sDEVICE=%7$s -r%3$d -dFirstPage=%4$d -dLastPage=%4$d -sOutputFile=%5$s %6$s',
                escapeshellarg($dir),
                escapeshellarg(self::GS),
                $dpi,
                $page,
                escapeshellarg($outfile),
                escapeshellarg($pdfpath),
                $device
            );
            $jobs[] = ['command' => $command, 'expect' => $outfile];
        }
        self::run_job_batch($jobs, $dir, self::get_parallelism(), $progresscallback);

        $files = [];
        foreach ($jobs as $job) {
            $files[] = $job['expect'];
        }
        return $files;
    }

    protected static function run_job_batch(array $jobs, ?string $cwd, int $parallelism, ?callable $progresscallback = null): void {
        if (empty($jobs)) {
            return;
        }

        $parallelism = max(1, $parallelism);
        $completed = 0;
        $total = count($jobs);

        foreach (array_chunk($jobs, $parallelism) as $chunk) {
            $procs = [];
            foreach ($chunk as $idx => $job) {
                $descriptor = [0 => ['pipe', 'r'], 1 => ['pipe', 'w'], 2 => ['pipe', 'w']];
                $proc = proc_open($job['command'], $descriptor, $pipes, $cwd);
                if (!is_resource($proc)) {
                    throw new \moodle_exception('errorprocessingbook', 'local_aisgk', '', null, 'Không thể khởi tạo tiến trình xử lý ảnh.');
                }
                fclose($pipes[0]);
                $procs[$idx] = ['proc' => $proc, 'pipes' => $pipes, 'expect' => $job['expect']];
            }

            foreach ($procs as $procinfo) {
                $stdout = stream_get_contents($procinfo['pipes'][1]);
                $stderr = stream_get_contents($procinfo['pipes'][2]);
                fclose($procinfo['pipes'][1]);
                fclose($procinfo['pipes'][2]);
                $code = proc_close($procinfo['proc']);
                if ($code !== 0 || !is_file($procinfo['expect'])) {
                    $output = trim(trim((string)$stdout) . "\n" . trim((string)$stderr));
                    throw new \moodle_exception('errorprocessingbook', 'local_aisgk', '', null, $output);
                }
                $completed++;
                if ($progresscallback) {
                    $progresscallback($completed, $total);
                }
            }
        }
    }
}
