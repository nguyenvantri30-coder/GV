<?php
namespace local_aisgk\local;

defined('MOODLE_INTERNAL') || die();

/**
 * Production validator for AI SGK homework question JSON.
 *
 * Scope:
 * - Validate Moodle-compatible question structures after AI JSON has been parsed.
 * - Keep da_nhieu as a separate distractor layer; never count it as core answers.
 * - Optionally rebalance cognitive levels for auto-generated AI output only.
 */
class question_validator {
    public static function validate(array $questions, array $options, array $context = []): array {
        $questions = self::normalize_questions($questions, $options, $context);
        if (!empty($context['auto_fix_level']) || !empty($options['auto_fix_level'])) {
            $questions = self::rebalance_levels_if_safe($questions, $options);
        }

        $requiredtypes = self::active_qtype_counts($options);
        $requiredlevels = self::active_level_counts($options);
        $summary = ['qtypes' => [], 'levels' => []];
        foreach ($requiredtypes as $type => $count) {
            $summary['qtypes'][$type] = ['used' => 0, 'required' => (int)$count];
        }
        foreach ($requiredlevels as $level => $count) {
            $summary['levels'][$level] = ['used' => 0, 'required' => (int)$count];
        }

        $errors = [];
        foreach (array_values($questions) as $i => $q) {
            $no = $i + 1;
            if (!is_array($q)) {
                $errors[] = 'Câu ' . $no . ' không phải object JSON.';
                continue;
            }
            $type = self::normalize_qtype((string)($q['type'] ?? $q['qtype'] ?? ''));
            $level = self::normalize_level((string)($q['level'] ?? ''));
            if ($type === '' || empty($requiredtypes[$type])) {
                $errors[] = 'Câu ' . $no . ' type ' . ($type ?: '(trống)') . ' ngoài cấu hình.';
            } else {
                $summary['qtypes'][$type]['used']++;
            }
            if ($level === '' || empty($requiredlevels[$level])) {
                $errors[] = 'Câu ' . $no . ' level ' . ($level ?: '(trống)') . ' ngoài cấu hình.';
            } else {
                $summary['levels'][$level]['used']++;
            }
            foreach (self::validate_one($q, $no) as $err) {
                $errors[] = $err;
            }
        }

        foreach ($summary['qtypes'] as $type => $v) {
            if ((int)$v['used'] !== (int)$v['required']) {
                $errors[] = 'Type ' . $type . ' sai số lượng (' . $v['used'] . '/' . $v['required'] . ').';
            }
        }
        foreach ($summary['levels'] as $level => $v) {
            if ((int)$v['used'] !== (int)$v['required']) {
                $errors[] = 'Level ' . $level . ' sai số lượng (' . $v['used'] . '/' . $v['required'] . ').';
            }
        }

        return [
            'ok' => empty($errors),
            'errors' => $errors,
            'summary' => $summary,
            'fixed_questions' => array_values($questions),
            'auto_fix_level' => !empty($context['auto_fix_level']) || !empty($options['auto_fix_level']),
        ];
    }

    public static function normalize_questions(array $questions, array $options = [], array $context = []): array {
        $out = [];
        foreach (array_values($questions) as $i => $q) {
            if (!is_array($q)) {
                $q = ['questiontext' => trim((string)$q)];
            }
            $type = self::normalize_qtype((string)($q['type'] ?? $q['qtype'] ?? ''));
            $q['type'] = $type;
            $q['qtype'] = $type;
            $q['level'] = self::normalize_level((string)($q['level'] ?? ''));
            if (empty($q['name'])) {
                $q['name'] = 'Câu ' . ($i + 1);
            }
            $q['questiontext'] = self::normalize_placeholders((string)($q['questiontext'] ?? ''));

            if ($type === 'multichoice') {
                $q['answers'] = self::normalize_answers($q['answers'] ?? []);
                $correct = 0;
                foreach ($q['answers'] as $a) {
                    if ((float)($a['fraction'] ?? 0) > 0) { $correct++; }
                }
                if (!isset($q['single'])) {
                    $q['single'] = $correct <= 1 ? 1 : 0;
                }
            } else if ($type === 'matching') {
                $q['subquestions'] = self::normalize_subquestions($q['subquestions'] ?? $q['pairs'] ?? $q['items'] ?? $q['matches'] ?? []);
            } else if (in_array($type, ['gapselect', 'ddwtos'], true)) {
                $q['choices'] = self::normalize_drag_choices($q['choices'] ?? $q['answers'] ?? $q['dragitems'] ?? [], $q['questiontext']);
            } else if (in_array($type, ['truefalse', 'shortanswer', 'numerical', 'calculated', 'calculatedsimple', 'calculatedmulti'], true)) {
                $q['answers'] = self::normalize_answers($q['answers'] ?? []);
            }

            if (isset($q['da_nhieu'])) {
                $q['da_nhieu'] = self::normalize_distractors($q['da_nhieu']);
            }
            $out[] = $q;
        }
        if (!empty($context['auto_fix_level']) || !empty($options['auto_fix_level'])) {
            $out = self::rebalance_levels_if_safe($out, $options);
        }
        return array_values($out);
    }

    public static function validate_one(array $q, int $no): array {
        $type = self::normalize_qtype((string)($q['type'] ?? $q['qtype'] ?? ''));
        switch ($type) {
            case 'multichoice': return self::validate_multichoice($q, $no);
            case 'matching': return self::validate_matching($q, $no);
            case 'gapselect': return self::validate_drag($q, $no, 'gapselect');
            case 'ddwtos': return self::validate_drag($q, $no, 'ddwtos');
            case 'truefalse': return self::validate_truefalse($q, $no);
            case 'shortanswer': return self::validate_simple_answer($q, $no, 'shortanswer');
            case 'numerical': return self::validate_simple_answer($q, $no, 'numerical');
            case 'calculated':
            case 'calculatedsimple':
            case 'calculatedmulti': return self::validate_calculated($q, $no, $type);
            case 'essay': return trim((string)($q['questiontext'] ?? '')) === '' ? ['Câu ' . $no . ' essay thiếu questiontext.'] : [];
            case 'description': return trim((string)($q['questiontext'] ?? '')) === '' ? ['Câu ' . $no . ' description thiếu questiontext.'] : [];
            default: return ['Câu ' . $no . ' thiếu hoặc sai type.'];
        }
    }

    protected static function validate_multichoice(array $q, int $no): array {
        $errors = [];
        if (trim((string)($q['questiontext'] ?? '')) === '') { $errors[] = 'Câu ' . $no . ' multichoice thiếu questiontext.'; }
        $answers = is_array($q['answers'] ?? null) ? array_values($q['answers']) : [];
        if (count($answers) < 2) { $errors[] = 'Câu ' . $no . ' multichoice cần tối thiểu 2 đáp án.'; return $errors; }
        $correct = 0; $sum = 0.0;
        foreach ($answers as $i => $a) {
            if (!is_array($a) || trim((string)($a['text'] ?? '')) === '') {
                $errors[] = 'Câu ' . $no . ' multichoice answer #' . ($i + 1) . ' thiếu text.';
                continue;
            }
            $frac = (float)($a['fraction'] ?? 0);
            if ($frac > 0) { $correct++; $sum += $frac; }
        }
        $single = !empty($q['single']) && (string)$q['single'] !== '0' && $q['single'] !== false;
        if ($single) {
            if ($correct !== 1) { $errors[] = 'Câu ' . $no . ' multichoice dạng 1 lựa chọn cần đúng 1 đáp án fraction > 0.'; }
        } else {
            if ($correct < 2) { $errors[] = 'Câu ' . $no . ' multichoice dạng checkbox cần tối thiểu 2 đáp án đúng.'; }
            if (abs($sum - 100.0) > 0.01) { $errors[] = 'Câu ' . $no . ' multichoice checkbox tổng fraction đáp án đúng phải bằng 100.'; }
        }
        return $errors;
    }

    protected static function validate_matching(array $q, int $no): array {
        $subs = is_array($q['subquestions'] ?? null) ? array_values($q['subquestions']) : [];
        $errors = [];
        $realpairs = 0; $answers = [];
        foreach ($subs as $i => $sq) {
            $left = is_array($sq) ? trim((string)($sq['question'] ?? '')) : '';
            $right = is_array($sq) ? trim((string)($sq['answer'] ?? '')) : '';
            $isdistractor = is_array($sq) && (!empty($sq['distractor']) || ($left === '' && $right !== ''));
            if (!$isdistractor && ($left === '' || $right === '')) {
                $errors[] = 'Câu ' . $no . ' matching cặp #' . ($i + 1) . ' thiếu question hoặc answer.';
            }
            if (!$isdistractor && $left !== '' && $right !== '') { $realpairs++; }
            if (!$isdistractor && $right !== '') {
                $key = self::key($right);
                if (isset($answers[$key])) { $errors[] = 'Câu ' . $no . ' matching có answer trùng: ' . $right . '.'; }
                $answers[$key] = true;
            }
        }
        if ($realpairs < 2) { $errors[] = 'Câu ' . $no . ' matching cần tối thiểu 2 cặp question/answer thật; da_nhieu không được tính là cặp đúng.'; }
        return $errors;
    }

    protected static function validate_drag(array $q, int $no, string $type): array {
        $errors = [];
        $text = (string)($q['questiontext'] ?? '');
        preg_match_all('/\[\[(\d+)\]\]/', $text, $m);
        $slots = array_values(array_unique(array_map('intval', $m[1] ?? [])));
        sort($slots);
        $choices = is_array($q['choices'] ?? null) ? array_values($q['choices']) : [];
        if (!$slots) { $errors[] = 'Câu ' . $no . ' ' . $type . ' cần questiontext có [[1]], [[2]]... (AI dùng <<1>>, <<2>> trước khi normalize).'; }
        if (!$choices) { $errors[] = 'Câu ' . $no . ' ' . $type . ' thiếu choices.'; }
        $bygroup = [];
        foreach ($choices as $i => $choice) {
            if (!is_array($choice)) { $errors[] = 'Câu ' . $no . ' ' . $type . ' choice #' . ($i + 1) . ' không phải object.'; continue; }
            $gid = (int)($choice['group'] ?? 0);
            $ctext = trim((string)($choice['text'] ?? ''));
            if ($gid <= 0) { $errors[] = 'Câu ' . $no . ' ' . $type . ' choice #' . ($i + 1) . ' thiếu group > 0.'; }
            if ($ctext === '') { $errors[] = 'Câu ' . $no . ' ' . $type . ' choice #' . ($i + 1) . ' thiếu text.'; }
            if ($gid > 0 && $ctext !== '' && empty($choice['distractor'])) { $bygroup[$gid][] = $ctext; }
        }
        foreach ($slots as $gid) {
            if (empty($bygroup[$gid])) { $errors[] = 'Câu ' . $no . ' ' . $type . ' thiếu choice đúng cho group ' . $gid . '.'; }
            if (!empty($bygroup[$gid]) && count($bygroup[$gid]) > 1) { $errors[] = 'Câu ' . $no . ' ' . $type . ' group ' . $gid . ' có nhiều hơn 1 choice chính; nhiễu phải để ở da_nhieu.'; }
        }
        foreach (array_keys($bygroup) as $gid) {
            if ($slots && !in_array((int)$gid, $slots, true)) { $errors[] = 'Câu ' . $no . ' ' . $type . ' có choice group ' . $gid . ' nhưng questiontext không có [[' . $gid . ']].'; }
        }
        return $errors;
    }

    protected static function validate_truefalse(array $q, int $no): array {
        $errors = self::validate_simple_answer($q, $no, 'truefalse');
        $answers = is_array($q['answers'] ?? null) ? array_values($q['answers']) : [];
        if (count($answers) !== 2) { $errors[] = 'Câu ' . $no . ' truefalse cần đúng 2 đáp án Đúng/Sai.'; }
        return $errors;
    }

    protected static function validate_simple_answer(array $q, int $no, string $type): array {
        $errors = [];
        if (trim((string)($q['questiontext'] ?? '')) === '') { $errors[] = 'Câu ' . $no . ' ' . $type . ' thiếu questiontext.'; }
        $answers = is_array($q['answers'] ?? null) ? array_values($q['answers']) : [];
        if (!$answers) { $errors[] = 'Câu ' . $no . ' ' . $type . ' thiếu answers.'; return $errors; }
        $positive = 0;
        foreach ($answers as $i => $a) {
            if (!is_array($a) || trim((string)($a['text'] ?? '')) === '') { $errors[] = 'Câu ' . $no . ' ' . $type . ' answer #' . ($i + 1) . ' thiếu text.'; }
            if ((float)($a['fraction'] ?? 0) > 0) { $positive++; }
        }
        if ($positive < 1) { $errors[] = 'Câu ' . $no . ' ' . $type . ' cần ít nhất 1 đáp án fraction > 0.'; }
        return $errors;
    }

    protected static function validate_calculated(array $q, int $no, string $type): array {
        $errors = self::validate_simple_answer($q, $no, $type);
        $questiontext = (string)($q['questiontext'] ?? '');
        if (!preg_match('/\{[a-zA-Z][a-zA-Z0-9_]*\}/', $questiontext)) { $errors[] = 'Câu ' . $no . ' ' . $type . ' thiếu biến Moodle {a}/{b}/{x} trong questiontext.'; }
        foreach (($q['answers'] ?? []) as $i => $a) {
            $txt = is_array($a) ? (string)($a['text'] ?? '') : '';
            if (!preg_match('/\{[a-zA-Z][a-zA-Z0-9_]*\}/', $txt)) { $errors[] = 'Câu ' . $no . ' ' . $type . ' answer #' . ($i + 1) . ' phải là công thức có biến Moodle.'; }
        }
        return array_values(array_unique($errors));
    }

    public static function rebalance_levels_if_safe(array $questions, array $options): array {
        $required = self::active_level_counts($options);
        if (!$required || !$questions) { return $questions; }
        $totalrequired = array_sum($required);
        if (count($questions) !== $totalrequired) { return $questions; }
        $used = [];
        foreach ($questions as $q) { $l = self::normalize_level((string)($q['level'] ?? '')); $used[$l] = ($used[$l] ?? 0) + 1; }
        $missing = [];
        foreach ($required as $level => $n) { for ($i = ($used[$level] ?? 0); $i < (int)$n; $i++) { $missing[] = $level; } }
        if (!$missing) { return $questions; }
        foreach ($questions as $idx => $q) {
            if (!$missing) { break; }
            $level = self::normalize_level((string)($q['level'] ?? ''));
            if (($used[$level] ?? 0) > ($required[$level] ?? 0)) {
                $newlevel = array_shift($missing);
                $questions[$idx]['level'] = $newlevel;
                $used[$level]--;
                $used[$newlevel] = ($used[$newlevel] ?? 0) + 1;
            }
        }
        return $questions;
    }

    protected static function normalize_answers($answers): array {
        $out = [];
        foreach (is_array($answers) ? $answers : [] as $i => $a) {
            if (!is_array($a)) { $a = ['text' => (string)$a]; }
            $text = trim((string)($a['text'] ?? $a['answer'] ?? $a['value'] ?? ''));
            if ($text === '') { continue; }
            $out[] = ['text' => self::normalize_placeholders($text), 'fraction' => isset($a['fraction']) ? (float)$a['fraction'] : ($i === 0 ? 100 : 0)] + array_diff_key($a, ['text'=>1,'answer'=>1,'value'=>1,'fraction'=>1]);
        }
        return $out;
    }

    protected static function normalize_subquestions($subs): array {
        $out = [];
        foreach (is_array($subs) ? $subs : [] as $sq) {
            if (!is_array($sq)) { continue; }
            $left = trim((string)($sq['question'] ?? $sq['left'] ?? $sq['term'] ?? ''));
            $right = trim((string)($sq['answer'] ?? $sq['right'] ?? $sq['definition'] ?? ''));
            if ($left === '' && $right === '') { continue; }
            $item = ['question' => self::normalize_placeholders($left), 'answer' => self::normalize_placeholders($right)];
            if (!empty($sq['distractor'])) { $item['distractor'] = 1; }
            $out[] = $item;
        }
        return $out;
    }

    protected static function normalize_drag_choices($choices, string $questiontext): array {
        $out = [];
        $seen = [];
        foreach (is_array($choices) ? $choices : [] as $i => $choice) {
            if (!is_array($choice)) { $choice = ['text' => (string)$choice]; }
            $text = trim((string)($choice['text'] ?? $choice['answer'] ?? $choice['value'] ?? ''));
            if ($text === '') { continue; }
            $gid = (int)($choice['group'] ?? $choice['slot'] ?? $choice['blank'] ?? ($i + 1));
            $key = $gid . '|' . self::key($text); // important: do not dedupe same text across different groups.
            if (isset($seen[$key])) { continue; }
            $seen[$key] = true;
            $out[] = ['group' => $gid, 'text' => self::normalize_placeholders($text)] + array_diff_key($choice, ['group'=>1,'slot'=>1,'blank'=>1,'text'=>1,'answer'=>1,'value'=>1]);
        }
        usort($out, static function($a, $b) { return ((int)($a['group'] ?? 0)) <=> ((int)($b['group'] ?? 0)); });
        return $out;
    }

    protected static function normalize_distractors($items): array {
        $out = [];
        foreach (is_array($items) ? $items : [] as $item) {
            $text = is_array($item) ? trim((string)($item['text'] ?? $item['answer'] ?? $item['value'] ?? '')) : trim((string)$item);
            if ($text !== '') { $out[] = self::normalize_placeholders($text); }
        }
        return array_values(array_unique($out));
    }

    protected static function normalize_placeholders(string $text): string {
        return preg_replace('/<<(\d+)>>/', '[[\\1]]', $text) ?? $text;
    }

    protected static function key(string $text): string {
        $text = trim(preg_replace('/\s+/u', ' ', $text) ?? $text);
        return function_exists('mb_strtolower') ? mb_strtolower($text) : strtolower($text);
    }

    protected static function normalize_qtype(string $type): string {
        $type = strtolower(trim($type));
        $map = [
            'multiplechoice' => 'multichoice', 'multi_choice' => 'multichoice', 'mcq' => 'multichoice',
            'match' => 'matching', 'matchingquestion' => 'matching',
            'dragdroptext' => 'ddwtos', 'dragtext' => 'ddwtos', 'drag_and_drop_text' => 'ddwtos',
            'selectmissingwords' => 'gapselect', 'select_missing_words' => 'gapselect',
            'calculated_simple' => 'calculatedsimple', 'calculated_multi' => 'calculatedmulti',
        ];
        return $map[$type] ?? $type;
    }

    protected static function normalize_level(string $level): string {
        $level = strtolower(trim($level));
        $map = [
            'recognize' => 'nhan_biet', 'nhận biết' => 'nhan_biet', 'nhan biet' => 'nhan_biet', 'nb' => 'nhan_biet',
            'understand' => 'thong_hieu', 'thông hiểu' => 'thong_hieu', 'thong hieu' => 'thong_hieu', 'th' => 'thong_hieu',
            'apply' => 'van_dung', 'vận dụng' => 'van_dung', 'van dung' => 'van_dung', 'vd' => 'van_dung',
        ];
        return $map[$level] ?? $level;
    }

    protected static function active_qtype_counts(array $options): array {
        $out = [];
        foreach (($options['qtypes'] ?? []) as $type => $count) {
            $type = self::normalize_qtype((string)$type); $count = (int)$count;
            if ($type !== '' && $count > 0) { $out[$type] = $count; }
        }
        if (!$out) { $out['shortanswer'] = max(1, (int)($options['total'] ?? 1)); }
        return $out;
    }

    protected static function active_level_counts(array $options): array {
        $out = [];
        foreach (($options['cognitive'] ?? []) as $level => $count) {
            $level = self::normalize_level((string)$level); $count = (int)$count;
            if ($level !== '' && $count > 0) { $out[$level] = $count; }
        }
        if (!$out) { $out['nhan_biet'] = max(1, (int)($options['total'] ?? 1)); }
        return $out;
    }
}
