<?php
namespace local_aisgk;

defined('MOODLE_INTERNAL') || die();

class toc_repository {
    public static function get_by_bookid(int $bookid): array {
        global $DB;
        return array_values($DB->get_records('local_aisgk_book_toc', ['bookid' => $bookid], 'sortorder ASC, id ASC'));
    }

    public static function get_draft_by_bookid(int $bookid): array {
        global $DB;
        return array_values($DB->get_records('local_aisgk_book_toc_draft', ['bookid' => $bookid], 'sortorder ASC, id ASC'));
    }

    public static function get_by_courseid(int $courseid): array {
        return self::get_course_rows('local_aisgk_book_toc', $courseid);
    }

    public static function get_draft_by_courseid(int $courseid): array {
        return self::get_course_rows('local_aisgk_book_toc_draft', $courseid);
    }

    protected static function get_course_rows(string $table, int $courseid): array {
        global $DB;
        $sql = "SELECT t.*, b.name AS bookname, b.filename AS bookfilename
                  FROM {" . $table . "} t
                  JOIN {local_aisgk_books} b ON b.id = t.bookid
                 WHERE b.courseid = ?
              ORDER BY b.sortorder ASC, b.id ASC, t.sortorder ASC, t.id ASC";
        return array_values($DB->get_records_sql($sql, [$courseid]));
    }

    public static function replace_book_toc(int $bookid, array $rows): void {
        self::replace_rows('local_aisgk_book_toc', $bookid, $rows);
    }

    public static function replace_book_toc_draft(int $bookid, array $rows): void {
        self::replace_rows('local_aisgk_book_toc_draft', $bookid, $rows);
    }

    public static function replace_course_toc(int $courseid, array $rows): void {
        self::replace_course_rows('local_aisgk_book_toc', $courseid, $rows);
    }

    public static function replace_course_toc_draft(int $courseid, array $rows): void {
        self::replace_course_rows('local_aisgk_book_toc_draft', $courseid, $rows);
    }

    protected static function replace_course_rows(string $table, int $courseid, array $rows): void {
        global $DB;
        $bookids = $DB->get_fieldset_select('local_aisgk_books', 'id', 'courseid = ?', [$courseid]);
        if (!$bookids) {
            return;
        }
        $allowed = array_fill_keys(array_map('intval', $bookids), true);
        $grouped = [];
        foreach ($rows as $row) {
            $rowbookid = (int)self::row_value($row, 'bookid', 0);
            if ($rowbookid > 0 && isset($allowed[$rowbookid])) {
                $grouped[$rowbookid][] = $row;
            }
        }
        foreach ($bookids as $bookid) {
            self::replace_rows($table, (int)$bookid, $grouped[(int)$bookid] ?? []);
        }
    }

    protected static function row_value($row, string $key, $default = null) {
        if (is_array($row)) {
            return $row[$key] ?? $default;
        }
        if (is_object($row)) {
            return $row->{$key} ?? $default;
        }
        return $default;
    }


    protected static function normalize_score($value): float {
        if ($value === null || $value === '') {
            return 0.0;
        }
        if (!is_numeric($value)) {
            return 0.0;
        }
        $score = (float)$value;
        if ($score > 1) {
            $score = $score / 100.0;
        }
        return max(0.0, min(1.0, $score));
    }

    protected static function replace_rows(string $table, int $bookid, array $rows): void {
        global $DB, $USER;

        $transaction = $DB->start_delegated_transaction();
        $DB->delete_records($table, ['bookid' => $bookid]);

        $now = time();
        $sortorder = 1;
        foreach ($rows as $row) {
            $sobai = trim((string)self::row_value($row, 'sobai', ''));
            $tenbai = trim((string)self::row_value($row, 'tenbai', ''));
            $trang = self::normalize_page(self::row_value($row, 'trang', null));
            $endtrang = self::normalize_page(self::row_value($row, 'endtrang', null));
            $rawline = trim((string)self::row_value($row, 'rawline', ''));
            $pl3order = max(0, (int)self::row_value($row, 'pl3_order', 0));
            $aiscore = self::normalize_score(self::row_value($row, 'ai_score', 0));
            $serverscore = self::normalize_score(self::row_value($row, 'server_score', 0));
            $finalscore = self::normalize_score(self::row_value($row, 'final_score', 0));
            $matchwarning = trim((string)self::row_value($row, 'match_warning', ''));
            $matchtarget = trim((string)self::row_value($row, 'match_target', ''));

            if ($sobai === '' && $tenbai === '' && $trang === null && $endtrang === null && $rawline === '') {
                continue;
            }

            $record = new \stdClass();
            $record->bookid = $bookid;
            $record->sobai = is_numeric($sobai) ? (int)$sobai : 0;
            $record->tenbai = $tenbai;
            $record->trang = $trang;
            $record->endtrang = $endtrang;
            $record->sortorder = $sortorder++;
            $record->ismanual = 1;
            $record->rawline = $rawline;
            $record->pl3_order = $pl3order;
            $record->ai_score = $aiscore;
            $record->server_score = $serverscore;
            $record->final_score = $finalscore;
            $record->match_warning = $matchwarning;
            $record->match_target = $matchtarget;
            $record->timecreated = $now;
            $record->timemodified = $now;
            $record->usermodified = $USER->id;
            $DB->insert_record($table, $record);
        }

        $transaction->allow_commit();
    }

    public static function delete_course_toc_and_draft(int $courseid): void {
        global $DB;
        $bookids = $DB->get_fieldset_select('local_aisgk_books', 'id', 'courseid = ?', [$courseid]);
        if (!$bookids) {
            return;
        }
        [$insql, $params] = $DB->get_in_or_equal($bookids, SQL_PARAMS_QM);
        $DB->delete_records_select('local_aisgk_book_toc', 'bookid ' . $insql, $params);
        $DB->delete_records_select('local_aisgk_book_toc_draft', 'bookid ' . $insql, $params);
        foreach ($bookids as $bookid) {
            $book = $DB->get_record('local_aisgk_books', ['id' => (int)$bookid]);
            if ($book) {
                $book->scanstatus = 'idle';
                $book->scanmessage = '';
                $book->lastscanitemcount = 0;
                $book->timemodified = time();
                $DB->update_record('local_aisgk_books', $book);
            }
        }
    }

    public static function calculate_end_pages(array $rows): array {
        $rows = self::sanitize_rows($rows);
        $count = count($rows);
        for ($i = 0; $i < $count; $i++) {
            $currentend = self::normalize_page($rows[$i]['endtrang'] ?? null);
            $currentstart = self::normalize_page($rows[$i]['trang'] ?? null);
            if ($currentend !== null) {
                $rows[$i]['endtrang'] = $currentend;
                continue;
            }
            $nextstart = null;
            for ($j = $i + 1; $j < $count; $j++) {
                if ((int)($rows[$j]['bookid'] ?? 0) !== (int)($rows[$i]['bookid'] ?? 0)) {
                    continue;
                }
                $candidate = self::normalize_page($rows[$j]['trang'] ?? null);
                if ($candidate !== null) {
                    $nextstart = $candidate;
                    break;
                }
            }
            if ($currentstart !== null && $nextstart !== null && $nextstart > $currentstart) {
                $rows[$i]['endtrang'] = $nextstart - 1;
            } else {
                $rows[$i]['endtrang'] = $currentend;
            }
        }
        return $rows;
    }

    public static function sanitize_rows(array $rows): array {
        $out = [];
        foreach ($rows as $row) {
            $tenbai = trim((string)self::row_value($row, 'tenbai', ''));
            $rawline = trim((string)self::row_value($row, 'rawline', ''));
            //$haystack = mb_strtolower($tenbai . ' ' . $rawline, 'UTF-8');

            $clean = [
                'bookid' => (int)self::row_value($row, 'bookid', 0),
                'sobai' => trim((string)self::row_value($row, 'sobai', '')),
                'tenbai' => $tenbai,
                'trang' => self::row_value($row, 'trang', ''),
                'endtrang' => self::row_value($row, 'endtrang', ''),
                'rawline' => $rawline,
                'pl3_order' => max(0, (int)self::row_value($row, 'pl3_order', 0)),
                'ai_score' => self::normalize_score(self::row_value($row, 'ai_score', 0)),
                'server_score' => self::normalize_score(self::row_value($row, 'server_score', 0)),
                'final_score' => self::normalize_score(self::row_value($row, 'final_score', 0)),
                'match_warning' => trim((string)self::row_value($row, 'match_warning', '')),
                'match_target' => trim((string)self::row_value($row, 'match_target', '')),
            ];
            if (trim($clean['sobai'] . $clean['tenbai'] . (string)$clean['trang'] . (string)$clean['endtrang'] . $clean['rawline']) === '') {
                continue;
            }
            if (self::is_non_lesson_toc_row($clean)) {
                continue;
            }
            $out[] = $clean;
        }
        return $out;
    }

    protected static function is_non_lesson_toc_row(array $row): bool {
        $title = trim((string)($row['tenbai'] ?? ''));
        $rawline = trim((string)($row['rawline'] ?? ''));
        $sobai = trim((string)($row['sobai'] ?? ''));
        $text = self::ascii_lower($title . ' ' . $rawline);
        $titleascii = self::ascii_lower($title);
        $sobaiascii = self::ascii_lower($sobai);

        if ($titleascii === '' && $text === '') {
            return false;
        }

        // Keep explicit lesson rows even if the lesson title contains words like "Phần" or "Chủ đề".
        if (preg_match('/^(bai|lesson)\s*[0-9ivxlcdm]+\b/u', $titleascii)
            || preg_match('/^(bai|lesson)\s*[0-9ivxlcdm]+\b/u', $sobaiascii)
            || preg_match('/^[0-9]+$/u', $sobaiascii)) {
            return false;
        }

        // Only drop rows that are certainly non-lesson technical/front-matter rows.
        // Do NOT drop Chương/Phần/Chủ đề/Ôn tập/Luyện tập automatically: many SGK and PL3
        // use these as real learning units with their own start pages.
        if (in_array($titleascii, ['muc luc', 'loi noi dau', 'huong dan su dung sach', 'phu luc'], true)) {
            return true;
        }
        if (preg_match('/^(trang|page)\s*\d*$/u', $titleascii)) {
            return true;
        }
        if (preg_match('/^\d{1,4}$/u', $titleascii)) {
            return true;
        }
        return false;
    }

    protected static function ascii_lower(string $text): string {
        $text = mb_strtolower(trim($text), 'UTF-8');
        $map = [
            'à'=>'a','á'=>'a','ạ'=>'a','ả'=>'a','ã'=>'a','â'=>'a','ầ'=>'a','ấ'=>'a','ậ'=>'a','ẩ'=>'a','ẫ'=>'a','ă'=>'a','ằ'=>'a','ắ'=>'a','ặ'=>'a','ẳ'=>'a','ẵ'=>'a',
            'è'=>'e','é'=>'e','ẹ'=>'e','ẻ'=>'e','ẽ'=>'e','ê'=>'e','ề'=>'e','ế'=>'e','ệ'=>'e','ể'=>'e','ễ'=>'e',
            'ì'=>'i','í'=>'i','ị'=>'i','ỉ'=>'i','ĩ'=>'i',
            'ò'=>'o','ó'=>'o','ọ'=>'o','ỏ'=>'o','õ'=>'o','ô'=>'o','ồ'=>'o','ố'=>'o','ộ'=>'o','ổ'=>'o','ỗ'=>'o','ơ'=>'o','ờ'=>'o','ớ'=>'o','ợ'=>'o','ở'=>'o','ỡ'=>'o',
            'ù'=>'u','ú'=>'u','ụ'=>'u','ủ'=>'u','ũ'=>'u','ư'=>'u','ừ'=>'u','ứ'=>'u','ự'=>'u','ử'=>'u','ữ'=>'u',
            'ỳ'=>'y','ý'=>'y','ỵ'=>'y','ỷ'=>'y','ỹ'=>'y','đ'=>'d'
        ];
        return strtr($text, $map);
    }

    protected static function normalize_page($value): ?int {
        if ($value === null || $value === '') {
            return null;
        }
        if (!is_numeric($value)) {
            return null;
        }
        $page = (int)$value;
        return $page > 0 ? $page : null;
    }
}
