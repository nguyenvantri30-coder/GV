<?php
namespace local_aisgk;

defined('MOODLE_INTERNAL') || die();

class toc_repository {
    public static function get_by_bookid(int $bookid): array {
        global $DB;
        return array_values($DB->get_records('local_aisgk_book_toc', ['bookid' => $bookid], 'sortorder ASC, id ASC'));
    }

    public static function replace_book_toc(int $bookid, array $rows): void {
        global $DB, $USER;

        $transaction = $DB->start_delegated_transaction();
        $DB->delete_records('local_aisgk_book_toc', ['bookid' => $bookid]);

        $now = time();
        $sortorder = 1;
        foreach ($rows as $row) {
            $sobai = isset($row['sobai']) ? trim((string)$row['sobai']) : '';
            $tenbai = isset($row['tenbai']) ? trim((string)$row['tenbai']) : '';
            $trang = self::normalize_page($row['trang'] ?? null);
            $endtrang = self::normalize_page($row['endtrang'] ?? null);
            $rawline = isset($row['rawline']) ? trim((string)$row['rawline']) : '';

            if ($sobai === '' && $tenbai === '' && $trang === null && $endtrang === null && $rawline === '') {
                continue;
            }

            $record = new \stdClass();
            $record->bookid = $bookid;
            $record->sobai = is_numeric($sobai) ? (int)$sobai : 0;
            $record->tenbai = $tenbai;
            $record->trang = $trang;
            $record->endtrang = $endtrang;
            $record->sortorder = $sortorder++;
            $record->ismanual = 1;
            $record->rawline = $rawline;
            $record->timecreated = $now;
            $record->timemodified = $now;
            $record->usermodified = $USER->id;
            $DB->insert_record('local_aisgk_book_toc', $record);
        }

        $transaction->allow_commit();
    }

    public static function calculate_end_pages(array $rows): array {
        $count = count($rows);
        for ($i = 0; $i < $count; $i++) {
            $current = $rows[$i];
            $currentend = self::normalize_page($current['endtrang'] ?? null);
            $currentstart = self::normalize_page($current['trang'] ?? null);
            if ($currentend !== null) {
                $rows[$i]['endtrang'] = $currentend;
                continue;
            }
            $nextstart = null;
            for ($j = $i + 1; $j < $count; $j++) {
                $candidate = self::normalize_page($rows[$j]['trang'] ?? null);
                if ($candidate !== null) {
                    $nextstart = $candidate;
                    break;
                }
            }
            if ($currentstart !== null && $nextstart !== null && $nextstart > $currentstart) {
                $rows[$i]['endtrang'] = $nextstart - 1;
            } else {
                $rows[$i]['endtrang'] = $currentend;
            }
        }
        return $rows;
    }

    protected static function normalize_page($value): ?int {
        if ($value === null || $value === '') {
            return null;
        }
        if (!is_numeric($value)) {
            return null;
        }
        $page = (int)$value;
        return $page > 0 ? $page : null;
    }
}
