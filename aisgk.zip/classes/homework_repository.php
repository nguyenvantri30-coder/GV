<?php
namespace local_aisgk;

defined('MOODLE_INTERNAL') || die();

class homework_repository {
    public static function create(array $data): int {
        global $DB;
        $record = (object)$data;
        return (int)$DB->insert_record('local_aisgk_homeworks', $record);
    }

    public static function update(
        int $id,
        array $data
    ): void {
        global $DB;
        $record = (object)$data;
        $record->id = $id;
        $DB->update_record('local_aisgk_homeworks', $record);
    }

    public static function get_by_id(int $id): ?\stdClass {
        global $DB;
        $r = $DB->get_record('local_aisgk_homeworks', ['id' => $id]);
        return $r ?: null;
    }

    public static function find_active_by_resource(string $resourcekey): ?\stdClass {
        global $DB;
        $sql = "resourcekey = ? AND status IN ('draft_generating','draft_ready','approved','scheduled')";
        $records = $DB->get_records_select('local_aisgk_homeworks', $sql, [$resourcekey], 'id DESC', '*', 0, 1);
        return $records ? reset($records) : null;
    }

    public static function find_recent_drafts(int $courseid, int $sectionid, int $limit = 20): array {
        global $DB;
        $sql = "courseid = ? AND sectionid = ? AND cancelled = 0 AND status IN ('draft_ready','scheduled','approved')";
        return array_values($DB->get_records_select('local_aisgk_homeworks', $sql, [$courseid, $sectionid], 'timemodified DESC, id DESC', '*', 0, $limit));
    }

    public static function find_latest_ready(int $courseid, int $sectionid): ?\stdClass {
        $rows = self::find_recent_drafts($courseid, $sectionid, 1);
        return $rows ? $rows[0] : null;
    }

    public static function find_due_for_delivery(int $now): array {
        global $DB;
        $sql = "status IN ('draft_ready','approved','scheduled') AND cancelled = 0 AND deliveredtime = 0 AND scheduledtime > 0 AND scheduledtime <= ?";
        return array_values($DB->get_records_select('local_aisgk_homeworks', $sql, [$now], 'scheduledtime ASC, id ASC'));
    }
}
