<?php
namespace local_aisgk;

defined('MOODLE_INTERNAL') || die();

class aikey_repository {
    public static function get_all(): array {
        global $DB;
        self::refresh_runtime_statuses('local_aisgk_ai_keys');
        return array_values($DB->get_records('local_aisgk_ai_keys', null, 'id ASC'));
    }

    public static function get_by_id(int $id): ?\stdClass {
        global $DB;
        $record = $DB->get_record('local_aisgk_ai_keys', ['id' => $id]);
        return $record ?: null;
    }

    public static function save_rows(array $rows): array {
        global $DB, $USER;
        $transaction = $DB->start_delegated_transaction();
        $existingids = $DB->get_fieldset_select('local_aisgk_ai_keys', 'id', '1 = 1');
        $seenids = [];
        $now = time();
        foreach ($rows as $row) {
            $record = self::normalize_row($row, $now, (int)$USER->id);
            if (!empty($row['id']) && is_numeric($row['id']) && $DB->record_exists('local_aisgk_ai_keys', ['id' => (int)$row['id']])) {
                $record->id = (int)$row['id'];
                $current = $DB->get_record('local_aisgk_ai_keys', ['id' => $record->id], '*', MUST_EXIST);
                $record->timecreated = (int)$current->timecreated;
                if ($record->model_img === '') { $record->model_img = (string)($current->model_img ?? ''); }
                // Preserve counters; they are maintained by ai_key_manager, not by the edit table.
                foreach (['last_model','last_tokens','last_tokens_at','usage_remaining','usage_last_sync','daily_used','daily_reset_at','in_use_by','in_use_until','models_cache_json','models_cache_at'] as $f) {
                    if (isset($current->$f)) {
                        $record->$f = $current->$f;
                    }
                }
                $DB->update_record('local_aisgk_ai_keys', $record);
                $seenids[] = $record->id;
            } else {
                $newid = (int)$DB->insert_record('local_aisgk_ai_keys', $record);
                $seenids[] = $newid;
            }
        }
        $todelete = array_diff(array_map('intval', $existingids), array_map('intval', $seenids));
        if ($todelete) {
            [$insql, $params] = $DB->get_in_or_equal($todelete, SQL_PARAMS_QM);
            $DB->delete_records_select('local_aisgk_ai_keys', 'id ' . $insql, $params);
        }
        $transaction->allow_commit();
        return self::get_all();
    }

    public static function sync_usage_remaining_for_pay_keys(): void {
        global $DB;
        $keys = $DB->get_records('local_aisgk_ai_keys', ['category_key' => 'pay'], 'id ASC');
        foreach ($keys as $key) {
            self::sync_usage_remaining_for_key($key, 'local_aisgk_ai_keys');
        }
        self::refresh_runtime_statuses('local_aisgk_ai_keys');
    }

    public static function sync_usage_remaining_for_user_pay_keys(int $userid): void {
        global $DB;
        if (!$DB->get_manager()->table_exists('local_aisgk_user_ai_keys')) {
            return;
        }
        $keys = $DB->get_records('local_aisgk_user_ai_keys', ['userid' => $userid, 'category_key' => 'pay'], 'id ASC');
        foreach ($keys as $key) {
            self::sync_usage_remaining_for_key($key, 'local_aisgk_user_ai_keys');
        }
        self::refresh_runtime_statuses('local_aisgk_user_ai_keys', $userid);
    }


    public static function refresh_runtime_statuses(string $table = 'local_aisgk_ai_keys', int $userid = 0): void {
        global $DB;
        if (!$DB->get_manager()->table_exists($table)) {
            return;
        }
        $where = '1=1';
        $params = [];
        if ($userid > 0 && $DB->get_manager()->field_exists($table, 'userid')) {
            $where = 'userid = ?';
            $params[] = $userid;
        }
        $rows = $DB->get_records_select($table, $where, $params, 'id ASC');
        $now = time();
        $today = (int)date('Ymd');
        foreach ($rows as $row) {
            $changed = false;

            // Reset per-day counters lazily when the admin opens the table or when code asks for rows.
            if (empty($row->daily_reset_at) || (int)date('Ymd', (int)$row->daily_reset_at) !== $today) {
                $row->daily_used = 0;
                $row->total_requests_day = 0;
                $row->daily_reset_at = $now;
                $changed = true;
            }

            $status = (string)($row->status ?? 'active');
            $cooldownuntil = (int)($row->cooldown_until ?? 0);
            $last_error = (string)($row->last_error ?? '');
            $quotaerror = class_exists('local_aisgk\ai_key_manager') && ai_key_manager::is_daily_quota_error($last_error);

            // Expired key cooldown becomes active again. Clear stale quota text so the next refresh does not re-cooldown it.
            if ($status === 'cooldown' && $cooldownuntil > 0 && $cooldownuntil <= $now) {
                $row->status = 'active';
                $row->cooldown_until = 0;
                if ($quotaerror || stripos($last_error, 'Daily quota reached') !== false) {
                    $row->last_error = '';
                    $last_error = '';
                    $quotaerror = false;
                }
                $changed = true;
            }

            // Refresh model JSON status for Text and Img.
            foreach (['model_homework' => 'model_homework_status', 'model_img' => 'model_img_status'] as $modelfield => $statusfield) {
                $refreshed = self::refresh_model_status_json((string)($row->$modelfield ?? ''), (string)($row->$statusfield ?? ''), $now);
                if ($refreshed !== (string)($row->$statusfield ?? '')) {
                    $row->$statusfield = $refreshed;
                    $changed = true;
                }
            }

            $daily_limit = (int)($row->daily_limit ?? 0);
            $daily_used = (int)($row->daily_used ?? 0);
            $islocaldailyfull = ($daily_limit > 0 && $daily_used >= $daily_limit);
            $ispayempty = ((string)($row->category_key ?? '') === 'pay'
                && (string)($row->provider ?? '') === 'shopaikey'
                && isset($row->usage_remaining)
                && is_numeric($row->usage_remaining)
                && (float)$row->usage_remaining <= 0
                && (int)($row->usage_last_sync ?? 0) > 0);

            if (($quotaerror || $islocaldailyfull || $ispayempty) && (string)($row->status ?? 'active') !== 'blocked') {
                $row->status = 'cooldown';
                if ((int)($row->cooldown_until ?? 0) <= $now) {
                    $row->cooldown_until = self::tomorrow_reset_time();
                }
                if ((string)($row->last_error ?? '') === '') {
                    $row->last_error = $ispayempty ? 'ShopAIKey: hết credit/quota' : 'Daily quota reached';
                }
                $changed = true;
            }

            if ($changed) {
                $row->timemodified = $now;
                $DB->update_record($table, $row);
            }
        }
    }

    protected static function refresh_model_status_json(string $modelsraw, string $statusjson, int $now): string {
        $models = [];
        foreach (explode(',', $modelsraw) as $model) {
            $model = trim($model);
            if ($model !== '' && !in_array($model, $models, true)) {
                $models[] = $model;
            }
        }
        if (!$models) {
            return '';
        }
        $old = [];
        $decoded = json_decode(trim($statusjson), true);
        if (is_array($decoded)) {
            $old = $decoded;
        }
        $out = [];
        foreach ($models as $model) {
            $state = $old[$model] ?? [];
            if (!is_array($state)) {
                $state = ['status' => (string)$state];
            }
            $status = (string)($state['status'] ?? 'active');
            if (!in_array($status, ['active', 'cooldown', 'blocked'], true)) {
                $status = 'active';
            }
            $until = max(0, (int)($state['cooldown_until'] ?? 0));
            $err = mb_substr((string)($state['last_error'] ?? ''), 0, 1000);
            $lastused = max(0, (int)($state['last_used'] ?? 0));
            $isquota = class_exists('local_aisgk\ai_key_manager') && ai_key_manager::is_daily_quota_error($err);

            if ($status === 'cooldown' && $until > 0 && $until <= $now) {
                $status = 'active';
                $until = 0;
                if ($isquota) {
                    $err = '';
                    $isquota = false;
                }
            } else if ($status === 'active' && $isquota && $lastused > 0 && (int)date('Ymd', $lastused) === (int)date('Ymd', $now)) {
                // Defensive repair for old rows that kept quota text but stored status=active.
                $status = 'cooldown';
                $until = self::tomorrow_reset_time();
            } else if ($status === 'active' && $isquota && $lastused > 0 && (int)date('Ymd', $lastused) !== (int)date('Ymd', $now)) {
                $err = '';
            }

            $out[$model] = [
                'status' => $status,
                'cooldown_until' => $until,
                'last_error' => $err,
                'last_used' => $lastused,
            ];
        }
        return json_encode($out, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
    }

    protected static function tomorrow_reset_time(): int {
        return strtotime('tomorrow 00:05') ?: (time() + DAYSECS);
    }

    public static function sync_usage_remaining_for_key(\stdClass $key, string $table = 'local_aisgk_ai_keys'): void {
        global $DB;
        $id = (int)($key->id ?? 0);
        if ($id <= 0 || trim((string)($key->category_key ?? '')) !== 'pay' || trim((string)($key->provider ?? '')) !== 'shopaikey') {
            return;
        }
        $apikey = trim((string)($key->api_key ?? ''));
        if ($apikey === '') {
            return;
        }
        $url = 'https://api.shopaikey.com/usage?apiKey=' . urlencode($apikey);
        $ch = curl_init($url);
        curl_setopt_array($ch, [CURLOPT_RETURNTRANSFER => true, CURLOPT_TIMEOUT => 8, CURLOPT_CONNECTTIMEOUT => 5, CURLOPT_HTTPHEADER => ['Accept: application/json']]);
        $response = curl_exec($ch);
        $errno = curl_errno($ch);
        $httpcode = (int)curl_getinfo($ch, CURLINFO_RESPONSE_CODE);
        curl_close($ch);
        if ($errno || !is_string($response) || trim($response) === '' || $httpcode >= 400) {
            return;
        }
        $decoded = json_decode($response, true);
        if (!is_array($decoded)) {
            return;
        }
        $remaining = self::find_remaining_value($decoded);
        if ($remaining === null) {
            return;
        }
        $current = $DB->get_record($table, ['id' => $id]);
        if (!$current) {
            return;
        }
        $current->usage_remaining = $remaining;
        $current->usage_last_sync = time();
        $DB->update_record($table, $current);
    }

    protected static function find_remaining_value(array $decoded): ?float {
        foreach (['remaining', 'usage_remaining', 'balance', 'credit_remaining'] as $field) {
            if (array_key_exists($field, $decoded) && is_numeric($decoded[$field])) {
                return (float)$decoded[$field];
            }
        }
        if (isset($decoded['data']) && is_array($decoded['data'])) {
            return self::find_remaining_value($decoded['data']);
        }
        return null;
    }

    public static function normalize_row(array $row, int $now, int $userid): \stdClass {
        $record = new \stdClass();
        $record->gmail_account = trim((string)($row['gmail_account'] ?? ''));
        $record->api_key = trim((string)($row['api_key'] ?? ''));
        $status = trim((string)($row['status'] ?? 'active'));
        $record->status = in_array($status, ['active', 'cooldown', 'blocked'], true) ? $status : 'active';
        $record->last_used = self::normalize_timestamp($row['last_used'] ?? 0);
        $record->request_count_minute = 0;
        $record->total_requests_day = max(0, (int)($row['daily_used'] ?? 0));
        $record->proxy_info = trim((string)($row['proxy_info'] ?? ''));
        $category = trim((string)($row['category_key'] ?? 'free'));
        $record->category_key = in_array($category, ['free', 'pay'], true) ? $category : 'free';
        $provider = trim((string)($row['provider'] ?? ($record->category_key === 'pay' ? 'shopaikey' : 'google')));
        $record->provider = in_array($provider, ['google', 'shopaikey'], true) ? $provider : ($record->category_key === 'pay' ? 'shopaikey' : 'google');
        $record->model_homework = trim((string)($row['model_homework'] ?? ''));
        $record->model_img = trim((string)($row['model_img'] ?? ''));
        $record->model_homework_status = ai_key_manager::normalize_model_status_json($record->model_homework, (string)($row['model_homework_status'] ?? ''));
        $record->model_img_status = ai_key_manager::normalize_model_status_json($record->model_img, (string)($row['model_img_status'] ?? ''));
        $record->models_cache_json = (string)($row['models_cache_json'] ?? '');
        $record->models_cache_at = self::normalize_timestamp($row['models_cache_at'] ?? 0);
        $record->cooldown_until = max(0, (int)($row['cooldown_until'] ?? 0));
        $record->last_error = trim((string)($row['last_error'] ?? ''));
        $record->usage_remaining = (float)($row['usage_remaining'] ?? 0);
        $record->usage_last_sync = self::normalize_timestamp($row['usage_last_sync'] ?? 0);
        $record->last_model = trim((string)($row['last_model'] ?? ''));
        $record->last_tokens = max(0, (int)($row['last_tokens'] ?? 0));
        $record->last_tokens_at = self::normalize_timestamp($row['last_tokens_at'] ?? 0);
        $record->daily_limit = max(0, (int)($row['daily_limit'] ?? (($record->category_key === 'pay') ? 100 : 0)));
        $record->daily_used = max(0, (int)($row['daily_used'] ?? 0));
        $record->daily_reset_at = self::normalize_timestamp($row['daily_reset_at'] ?? 0);
        $record->in_use_by = max(0, (int)($row['in_use_by'] ?? 0));
        $record->in_use_until = self::normalize_timestamp($row['in_use_until'] ?? 0);
        $record->timemodified = $now;
        $record->usermodified = $userid;
        $record->timecreated = $now;
        return $record;
    }

    protected static function normalize_timestamp($value): int {
        if ($value === null || $value === '') {
            return 0;
        }
        if (is_numeric($value)) {
            return max(0, (int)$value);
        }
        $timestamp = strtotime((string)$value);
        return $timestamp ? (int)$timestamp : 0;
    }
}
