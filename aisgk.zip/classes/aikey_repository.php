<?php
namespace local_aisgk;

defined('MOODLE_INTERNAL') || die();

class aikey_repository {
    public static function get_all(): array {
        global $DB;
        return array_values($DB->get_records('local_aisgk_ai_keys', null, 'id ASC'));
    }

    public static function get_by_id(int $id): ?\stdClass {
        global $DB;
        $record = $DB->get_record('local_aisgk_ai_keys', ['id' => $id]);
        return $record ?: null;
    }

    public static function save_rows(array $rows): array {
        global $DB, $USER;

        $transaction = $DB->start_delegated_transaction();
        $existingids = $DB->get_fieldset_select('local_aisgk_ai_keys', 'id', '1 = 1');
        $seenids = [];
        $now = time();

        foreach ($rows as $row) {
            $record = self::normalize_row($row, $now, (int)$USER->id);
            if (!empty($row['id']) && is_numeric($row['id'])) {
                $record->id = (int)$row['id'];
                $seenids[] = $record->id;
                if ($DB->record_exists('local_aisgk_ai_keys', ['id' => $record->id])) {
                    $current = $DB->get_record('local_aisgk_ai_keys', ['id' => $record->id], '*', MUST_EXIST);
                    $record->timecreated = (int)$current->timecreated;
                    $DB->update_record('local_aisgk_ai_keys', $record);
                } else {
                    unset($record->id);
                    $newid = (int)$DB->insert_record('local_aisgk_ai_keys', $record);
                    $seenids[] = $newid;
                }
            } else {
                $newid = (int)$DB->insert_record('local_aisgk_ai_keys', $record);
                $seenids[] = $newid;
            }
        }

        $todelete = array_diff(array_map('intval', $existingids), array_map('intval', $seenids));
        if ($todelete) {
            [$insql, $params] = $DB->get_in_or_equal($todelete, SQL_PARAMS_QM);
            $DB->delete_records_select('local_aisgk_ai_keys', 'id ' . $insql, $params);
        }

        $transaction->allow_commit();
        return self::get_all();
    }

    protected static function normalize_row(array $row, int $now, int $userid): \stdClass {
        $record = new \stdClass();
        $record->gmail_account = trim((string)($row['gmail_account'] ?? ''));
        $record->api_key = trim((string)($row['api_key'] ?? ''));
        $status = trim((string)($row['status'] ?? 'active'));
        if (!in_array($status, ['active', 'cooldown', 'blocked'], true)) {
            $status = 'active';
        }
        $record->status = $status;
        $record->last_used = self::normalize_timestamp($row['last_used'] ?? 0);
        $record->request_count_minute = max(0, (int)($row['request_count_minute'] ?? 0));
        $record->total_requests_day = max(0, (int)($row['total_requests_day'] ?? 0));
        $record->proxy_info = trim((string)($row['proxy_info'] ?? ''));
        $category = trim((string)($row['category_key'] ?? 'free'));
        if (!in_array($category, ['free', 'pay'], true)) {
            $category = 'free';
        }
        $record->category_key = $category;
        $record->timemodified = $now;
        $record->usermodified = $userid;
        $record->timecreated = $now;
        return $record;
    }

    protected static function normalize_timestamp($value): int {
        if ($value === null || $value === '') {
            return 0;
        }
        if (is_numeric($value)) {
            return max(0, (int)$value);
        }
        $timestamp = strtotime((string)$value);
        return $timestamp ? (int)$timestamp : 0;
    }
}
