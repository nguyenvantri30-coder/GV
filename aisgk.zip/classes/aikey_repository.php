<?php
namespace local_aisgk;

defined('MOODLE_INTERNAL') || die();

class aikey_repository {
    public static function get_all(): array {
        global $DB;
        return array_values($DB->get_records('local_aisgk_ai_keys', null, 'id ASC'));
    }

    public static function get_by_id(int $id): ?\stdClass {
        global $DB;
        $record = $DB->get_record('local_aisgk_ai_keys', ['id' => $id]);
        return $record ?: null;
    }

    public static function save_rows(array $rows): array {
        global $DB, $USER;
        $transaction = $DB->start_delegated_transaction();
        $existingids = $DB->get_fieldset_select('local_aisgk_ai_keys', 'id', '1 = 1');
        $seenids = [];
        $now = time();
        foreach ($rows as $row) {
            $record = self::normalize_row($row, $now, (int)$USER->id);
            if (!empty($row['id']) && is_numeric($row['id']) && $DB->record_exists('local_aisgk_ai_keys', ['id' => (int)$row['id']])) {
                $record->id = (int)$row['id'];
                $current = $DB->get_record('local_aisgk_ai_keys', ['id' => $record->id], '*', MUST_EXIST);
                $record->timecreated = (int)$current->timecreated;
                if ($record->model_scan === '') { $record->model_scan = (string)($current->model_scan ?? ''); }
                if ($record->model_homework === '') { $record->model_homework = (string)($current->model_homework ?? ''); }
                // Preserve counters; they are maintained by ai_key_manager, not by the edit table.
                foreach (['used_rpm','used_rpd','used_tpm','minute_bucket','day_bucket','last_model','last_tokens','last_tokens_at','remain_calls_est','usage_remaining','usage_last_sync'] as $f) {
                    if (isset($current->$f)) {
                        $record->$f = $current->$f;
                    }
                }
                $DB->update_record('local_aisgk_ai_keys', $record);
                $seenids[] = $record->id;
            } else {
                $newid = (int)$DB->insert_record('local_aisgk_ai_keys', $record);
                $seenids[] = $newid;
            }
        }
        $todelete = array_diff(array_map('intval', $existingids), array_map('intval', $seenids));
        if ($todelete) {
            [$insql, $params] = $DB->get_in_or_equal($todelete, SQL_PARAMS_QM);
            $DB->delete_records_select('local_aisgk_ai_keys', 'id ' . $insql, $params);
        }
        $transaction->allow_commit();
        return self::get_all();
    }

    public static function sync_usage_remaining_for_pay_keys(): void {
        global $DB;
        $keys = $DB->get_records('local_aisgk_ai_keys', ['category_key' => 'pay'], 'id ASC');
        foreach ($keys as $key) {
            self::sync_usage_remaining_for_key($key, 'local_aisgk_ai_keys');
        }
    }

    public static function sync_usage_remaining_for_user_pay_keys(int $userid): void {
        global $DB;
        if (!$DB->get_manager()->table_exists('local_aisgk_user_ai_keys')) {
            return;
        }
        $keys = $DB->get_records('local_aisgk_user_ai_keys', ['userid' => $userid, 'category_key' => 'pay'], 'id ASC');
        foreach ($keys as $key) {
            self::sync_usage_remaining_for_key($key, 'local_aisgk_user_ai_keys');
        }
    }

    public static function sync_usage_remaining_for_key(\stdClass $key, string $table = 'local_aisgk_ai_keys'): void {
        global $DB;
        $id = (int)($key->id ?? 0);
        if ($id <= 0 || trim((string)($key->category_key ?? '')) !== 'pay' || trim((string)($key->provider ?? '')) !== 'shopaikey') {
            return;
        }
        $apikey = trim((string)($key->api_key ?? ''));
        if ($apikey === '') {
            return;
        }
        $url = 'https://api.shopaikey.com/usage?apiKey=' . urlencode($apikey);
        $ch = curl_init($url);
        curl_setopt_array($ch, [CURLOPT_RETURNTRANSFER => true, CURLOPT_TIMEOUT => 8, CURLOPT_CONNECTTIMEOUT => 5, CURLOPT_HTTPHEADER => ['Accept: application/json']]);
        $response = curl_exec($ch);
        $errno = curl_errno($ch);
        $httpcode = (int)curl_getinfo($ch, CURLINFO_RESPONSE_CODE);
        curl_close($ch);
        if ($errno || !is_string($response) || trim($response) === '' || $httpcode >= 400) {
            return;
        }
        $decoded = json_decode($response, true);
        if (!is_array($decoded)) {
            return;
        }
        $remaining = self::find_remaining_value($decoded);
        if ($remaining === null) {
            return;
        }
        $current = $DB->get_record($table, ['id' => $id]);
        if (!$current) {
            return;
        }
        $current->usage_remaining = $remaining;
        $current->usage_last_sync = time();
        $DB->update_record($table, $current);
    }

    protected static function find_remaining_value(array $decoded): ?float {
        foreach (['remaining', 'usage_remaining', 'balance', 'credit_remaining'] as $field) {
            if (array_key_exists($field, $decoded) && is_numeric($decoded[$field])) {
                return (float)$decoded[$field];
            }
        }
        if (isset($decoded['data']) && is_array($decoded['data'])) {
            return self::find_remaining_value($decoded['data']);
        }
        return null;
    }

    public static function normalize_row(array $row, int $now, int $userid): \stdClass {
        $record = new \stdClass();
        $record->gmail_account = trim((string)($row['gmail_account'] ?? ''));
        $record->api_key = trim((string)($row['api_key'] ?? ''));
        $status = trim((string)($row['status'] ?? 'active'));
        $record->status = in_array($status, ['active', 'cooldown', 'blocked'], true) ? $status : 'active';
        $record->last_used = self::normalize_timestamp($row['last_used'] ?? 0);
        $record->request_count_minute = max(0, (int)($row['used_rpm'] ?? $row['request_count_minute'] ?? 0));
        $record->total_requests_day = max(0, (int)($row['used_rpd'] ?? $row['total_requests_day'] ?? 0));
        $record->proxy_info = trim((string)($row['proxy_info'] ?? ''));
        $category = trim((string)($row['category_key'] ?? 'free'));
        $record->category_key = in_array($category, ['free', 'pay'], true) ? $category : 'free';
        $provider = trim((string)($row['provider'] ?? ($record->category_key === 'pay' ? 'shopaikey' : 'google')));
        $record->provider = in_array($provider, ['google', 'shopaikey'], true) ? $provider : ($record->category_key === 'pay' ? 'shopaikey' : 'google');
        $record->model_scan = trim((string)($row['model_scan'] ?? ''));
        $record->model_homework = trim((string)($row['model_homework'] ?? ''));
        $record->cooldown_until = max(0, (int)($row['cooldown_until'] ?? 0));
        $record->minute_bucket = max(0, (int)($row['minute_bucket'] ?? 0));
        $record->day_bucket = max(0, (int)($row['day_bucket'] ?? 0));
        $record->last_error = trim((string)($row['last_error'] ?? ''));
        $record->usage_remaining = (float)($row['usage_remaining'] ?? 0);
        $record->usage_last_sync = self::normalize_timestamp($row['usage_last_sync'] ?? 0);
        $record->limit_rpm = max(0, (int)($row['limit_rpm'] ?? 8));
        $record->limit_rpd = max(0, (int)($row['limit_rpd'] ?? 200));
        $record->limit_tpm = max(0, (int)($row['limit_tpm'] ?? 200000));
        $record->used_rpm = max(0, (int)($row['used_rpm'] ?? 0));
        $record->used_rpd = max(0, (int)($row['used_rpd'] ?? 0));
        $record->used_tpm = max(0, (int)($row['used_tpm'] ?? 0));
        $record->last_model = trim((string)($row['last_model'] ?? ''));
        $record->last_tokens = max(0, (int)($row['last_tokens'] ?? 0));
        $record->last_tokens_at = self::normalize_timestamp($row['last_tokens_at'] ?? 0);
        $record->remain_calls_est = max(0, (int)($row['remain_calls_est'] ?? 0));
        $record->timemodified = $now;
        $record->usermodified = $userid;
        $record->timecreated = $now;
        return $record;
    }

    protected static function normalize_timestamp($value): int {
        if ($value === null || $value === '') {
            return 0;
        }
        if (is_numeric($value)) {
            return max(0, (int)$value);
        }
        $timestamp = strtotime((string)$value);
        return $timestamp ? (int)$timestamp : 0;
    }
}
