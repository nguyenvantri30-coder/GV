<?php
namespace local_aisgk;

defined('MOODLE_INTERNAL') || die();

class aikey_repository {
    public static function get_all(): array {
        global $DB;
        return array_values($DB->get_records('local_aisgk_ai_keys', null, 'id ASC'));
    }

    public static function get_by_id(int $id): ?\stdClass {
        global $DB;
        $record = $DB->get_record('local_aisgk_ai_keys', ['id' => $id]);
        return $record ?: null;
    }

    public static function save_rows(array $rows): array {
        global $DB, $USER;

        $transaction = $DB->start_delegated_transaction();
        $existingids = $DB->get_fieldset_select('local_aisgk_ai_keys', 'id', '1 = 1');
        $seenids = [];
        $now = time();

        foreach ($rows as $row) {
            $record = self::normalize_row($row, $now, (int)$USER->id);
            if (!empty($row['id']) && is_numeric($row['id'])) {
                $record->id = (int)$row['id'];
                $seenids[] = $record->id;
                if ($DB->record_exists('local_aisgk_ai_keys', ['id' => $record->id])) {
                    $current = $DB->get_record('local_aisgk_ai_keys', ['id' => $record->id], '*', MUST_EXIST);
                    $record->timecreated = (int)$current->timecreated;
                    // preserve runtime fields if UI did not provide them.
                    foreach (['cooldown_until','minute_bucket','day_bucket','last_error','usage_remaining','usage_last_sync'] as $f) {
                        if (!property_exists($record, $f)) {
                            $record->$f = (int)($current->$f ?? 0);
                        }
                    }
                    $DB->update_record('local_aisgk_ai_keys', $record);
                } else {
                    unset($record->id);
                    $newid = (int)$DB->insert_record('local_aisgk_ai_keys', $record);
                    $seenids[] = $newid;
                }
            } else {
                $newid = (int)$DB->insert_record('local_aisgk_ai_keys', $record);
                $seenids[] = $newid;
            }
        }

        $todelete = array_diff(array_map('intval', $existingids), array_map('intval', $seenids));
        if ($todelete) {
            [$insql, $params] = $DB->get_in_or_equal($todelete, SQL_PARAMS_QM);
            $DB->delete_records_select('local_aisgk_ai_keys', 'id ' . $insql, $params);
        }

        $transaction->allow_commit();
        return self::get_all();
    }

    public static function sync_usage_remaining_for_pay_keys(): void {
        global $DB;
        $keys = $DB->get_records('local_aisgk_ai_keys', ['category_key' => 'pay'], 'id ASC');
        foreach ($keys as $key) {
            $provider = trim((string)($key->provider ?? ''));
            if ($provider !== 'shopaikey') {
                continue;
            }
            $apikey = trim((string)($key->api_key ?? ''));
            if ($apikey === '') {
                continue;
            }
            $url = 'https://api.shopaikey.com/usage?apiKey=' . urlencode($apikey);
            $ch = curl_init($url);
            curl_setopt_array($ch, [
                CURLOPT_RETURNTRANSFER => true,
                CURLOPT_TIMEOUT => 20,
                CURLOPT_HTTPHEADER => ['Accept: application/json'],
            ]);
            $response = curl_exec($ch);
            $errno = curl_errno($ch);
            $httpcode = (int)curl_getinfo($ch, CURLINFO_RESPONSE_CODE);
            curl_close($ch);
            if ($errno || !is_string($response) || trim($response) === '' || $httpcode >= 400) {
                continue;
            }
            $decoded = json_decode($response, true);
            if (!is_array($decoded) || !array_key_exists('remaining', $decoded)) {
                continue;
            }
            $key->usage_remaining = (float)$decoded['remaining'];
            $key->usage_last_sync = time();
            $DB->update_record('local_aisgk_ai_keys', $key);
        }
    }

    protected static function normalize_row(array $row, int $now, int $userid): \stdClass {
        $record = new \stdClass();
        $record->gmail_account = trim((string)($row['gmail_account'] ?? ''));
        $record->api_key = trim((string)($row['api_key'] ?? ''));
        $status = trim((string)($row['status'] ?? 'active'));
        if (!in_array($status, ['active', 'cooldown', 'blocked'], true)) {
            $status = 'active';
        }
        $record->status = $status;
        $record->last_used = self::normalize_timestamp($row['last_used'] ?? 0);
        $record->request_count_minute = max(0, (int)($row['request_count_minute'] ?? 0));
        $record->total_requests_day = max(0, (int)($row['total_requests_day'] ?? 0));
        $record->proxy_info = trim((string)($row['proxy_info'] ?? ''));
        $category = trim((string)($row['category_key'] ?? 'free'));
        if (!in_array($category, ['free', 'pay'], true)) {
            $category = 'free';
        }
        $record->category_key = $category;
        $provider = trim((string)($row['provider'] ?? ($category === 'pay' ? 'shopaikey' : 'google')));
        if (!in_array($provider, ['google', 'shopaikey'], true)) {
            $provider = $category === 'pay' ? 'shopaikey' : 'google';
        }
        $record->provider = $provider;
        $record->model_scan = trim((string)($row['model_scan'] ?? ''));
        $record->model_homework = trim((string)($row['model_homework'] ?? ''));
        $record->cooldown_until = max(0, (int)($row['cooldown_until'] ?? 0));
        $record->minute_bucket = max(0, (int)($row['minute_bucket'] ?? 0));
        $record->day_bucket = max(0, (int)($row['day_bucket'] ?? 0));
        $record->last_error = trim((string)($row['last_error'] ?? ''));
        $record->usage_remaining = (float)($row['usage_remaining'] ?? 0);
        $record->usage_last_sync = self::normalize_timestamp($row['usage_last_sync'] ?? 0);
        $record->timemodified = $now;
        $record->usermodified = $userid;
        $record->timecreated = $now;
        return $record;
    }

    protected static function normalize_timestamp($value): int {
        if ($value === null || $value === '') {
            return 0;
        }
        if (is_numeric($value)) {
            return max(0, (int)$value);
        }
        $timestamp = strtotime((string)$value);
        return $timestamp ? (int)$timestamp : 0;
    }
}
