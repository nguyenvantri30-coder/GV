<?php
$string['pluginname'] = 'AI SGK';
$string['uploadbook'] = 'Tải SGK';
$string['replacebook'] = 'Tải SGK';
$string['createtopic'] = 'Tạo Chủ đề';
$string['createhomework'] = 'Tạo BTVN';
$string['createtopichomework'] = 'Tạo BTVN';
$string['uploadbookmodaltitle'] = 'Tải sách giáo khoa PDF';
$string['createtopicmodaltitle'] = 'Tạo Chủ đề';
$string['createhomeworkmodaltitle'] = 'Tạo BTVN';
$string['nofile'] = 'Bạn chưa chọn file.';
$string['invalidfiletype'] = 'Chỉ được tải lên file PDF.';
$string['savechanges'] = 'Lưu';
$string['cancel'] = 'Hủy';
$string['bookuploaded'] = 'Đã lưu SGK thành công.';
$string['bookreplaced'] = 'Đã thay SGK thành công.';
$string['managebooks'] = 'Quản lý SGK';
$string['viewbooks'] = 'Xem SGK';
$string['createtopic_desc'] = 'Cho phép tạo chủ đề ở cấp khóa học.';
$string['createhomework_desc'] = 'Cho phép tạo BTVN ở từng topic.';
$string['managebooks_desc'] = 'Cho phép tải và thay SGK của khóa học.';
$string['viewbooks_desc'] = 'Cho phép xem SGK của khóa học.';
$string['bookrequired'] = 'Khóa học chưa có SGK. Hãy tải SGK trước.';
$string['sectionnotfound'] = 'Không tìm thấy topic.';
$string['section'] = 'Topic';
$string['topicstubdesc'] = 'Đây là trang Tạo Chủ đề ở cấp khóa học. Sau này sẽ nối với luồng tạo topic/bài học.';
$string['homeworkstubdesc'] = 'Đây là trang tạo BTVN theo topic. Sau này sẽ nối vào logic AI sinh câu hỏi.';
$string['createtopicforcourse'] = 'Tạo Chủ đề cho khóa học';
$string['createhomeworkforsection'] = 'Tạo BTVN cho topic';


$string['uploadbookhelp'] = 'Chỉ chấp nhận file PDF. Mỗi khóa học có thể có nhiều SGK.';
$string['bookname'] = 'Tên sách';
$string['bookname_help'] = 'Ví dụ: Toán 6 - Tập 1, Toán 6 - Tập 2.';
$string['topicmanagerdesc'] = 'Chọn từng sách để nhập, chỉnh sửa và lưu mục lục. Dữ liệu này sẽ dùng lại cho tạo chủ đề và tạo BTVN.';
$string['bookselect'] = 'Chọn sách';
$string['viewchange'] = 'Xem';
$string['booklabel'] = 'Sách';
$string['tocpageslabel'] = 'Trang quét mục lục';
$string['sobai'] = 'Số bài';
$string['tenbai'] = 'Tên bài';
$string['trangbatdau'] = 'Trang bắt đầu';
$string['trangketthuc'] = 'Trang kết thúc';
$string['rawline'] = 'OCR gốc';
$string['tocsaved'] = 'Đã lưu mục lục.';
$string['endtrangautohelp'] = 'Nếu để trống trang kết thúc, hệ thống sẽ tự tính bằng trang bắt đầu của bài tiếp theo trừ đi 1 khi lưu.';
$string['reloadtoc'] = 'Tải lại';

$string['scantoc'] = 'Quét mục lục';
$string['tocscanned'] = 'Đã quét mục lục và lưu %d dòng bài.';
$string['bookimagesmissing'] = 'Chưa có ảnh mục lục để OCR. Hãy quét lại.';
$string['errorprocessingbook'] = 'Lỗi xử lý SGK: {$a}';

$string['uploadlimitnote'] = 'Nếu PDF lớn không tải được, hãy tăng giới hạn ở Nginx, PHP và Moodle Site upload limit.';
$string['tocscanincludespecial'] = 'Quét sẽ giữ các dòng Bài, Luyện tập, Ôn tập.';

$string['missingcourseid'] = 'Thiếu id khóa học. Hãy mở popup Tải SGK từ đúng trang khóa học.';
$string['onlypdfallowed'] = 'Chỉ cho phép upload file PDF.';
$string['uploaderrorserver'] = 'Upload lỗi từ phía máy chủ. Mã lỗi: {$a}';
$string['existingbooks'] = 'Các SGK hiện có của khóa học';
$string['nobooksincourse'] = 'Khóa học hiện chưa có SGK nào.';
$string['booknameplaceholder'] = 'Ví dụ: Toán 6 - Tập 1';
$string['filename'] = 'Tên file';
$string['tocfrompage'] = 'Từ trang';
$string['toctopage'] = 'Đến trang';
$string['tocscanincludespecial'] = 'Quét mục lục sẽ giữ các dòng có Bài, Luyện tập, Ôn tập.';
