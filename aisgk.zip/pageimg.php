<?php

define('NO_DEBUG_DISPLAY', true);
require('../../config.php');

use local_aisgk\book_repository;
use local_aisgk\local\sgk_processor;

$courseid = required_param('courseid', PARAM_INT);
$bookid = required_param('bookid', PARAM_INT);
$sectionid = optional_param('sectionid', 0, PARAM_INT);
$sgkpage = required_param('page', PARAM_INT);

require_login($courseid);
$context = context_course::instance($courseid);
require_capability('local/aisgk:createhomework', $context);

$book = book_repository::get_by_id($bookid);
if (!$book || (int)$book->courseid !== (int)$courseid) {
    http_response_code(404);
    exit('booknotfound');
}

$pdfpage = max(1, $sgkpage + 1); // same SGK -> PDF offset used by homework image rendering.
try {
    $paths = sgk_processor::render_page_images_cached($bookid, $courseid, $sectionid, $pdfpage, $pdfpage, 180);
    $path = $paths[0] ?? '';
    if ($path === '' || !is_file($path)) {
        http_response_code(404);
        exit('filenotfound');
    }
    $mime = preg_match('/\.jpe?g$/i', $path) ? 'image/jpeg' : 'image/png';
    send_file($path, basename($path), 0, 0, false, false, $mime);
} catch (Throwable $e) {
    http_response_code(500);
    exit('pageimageerror');
}
