<?php

define('NO_DEBUG_DISPLAY', true);
require('../../config.php');

use local_aisgk\book_repository;
use local_aisgk\local\sgk_processor;
use local_aisgk\local\service\homework_service;

$courseid = required_param('courseid', PARAM_INT);
$bookid = required_param('bookid', PARAM_INT);
$sectionid = optional_param('sectionid', 0, PARAM_INT);
$sgkpage = required_param('page', PARAM_INT);
$width = optional_param('width', 0, PARAM_INT);

require_login($courseid);
$context = context_course::instance($courseid);
require_capability('local/aisgk:createhomework', $context);

$book = book_repository::get_by_id($bookid);
if (!$book || (int)$book->courseid !== (int)$courseid) {
    http_response_code(404);
    exit('booknotfound');
}

function local_aisgk_pageimg_resized_cache(string $src, int $courseid, int $sectionid, int $bookid, int $sgkpage, int $width): string {
    global $CFG;
    $width = homework_service::normalize_ai_image_width($width);
    if ($width <= 0) { return $src; }
    $info = @getimagesize($src);
    if (!$info || empty($info[0]) || empty($info[1])) { return $src; }
    $srcw = (int)$info[0];
    $srch = (int)$info[1];
    $targetw = min($width, $srcw);
    if ($targetw <= 0 || $targetw === $srcw) { return $src; }
    $dir = rtrim($CFG->dataroot, '/') . '/local_aisgk/pageview/course_' . $courseid . '/section_' . max(0, $sectionid) . '/book_' . $bookid . '/w' . $width;
    if (!is_dir($dir)) { mkdir($dir, $CFG->directorypermissions, true); }
    $hash = substr(sha1($src . '|' . @filemtime($src) . '|pageview|' . $width), 0, 12);
    $dest = $dir . '/sgk_' . $sgkpage . '_' . $hash . '.jpg';
    if (is_file($dest) && @filesize($dest) > 100) { return $dest; }
    $ext = strtolower(pathinfo($src, PATHINFO_EXTENSION));
    if (($ext === 'jpg' || $ext === 'jpeg') && function_exists('imagecreatefromjpeg')) { $img = @imagecreatefromjpeg($src); }
    else if ($ext === 'webp' && function_exists('imagecreatefromwebp')) { $img = @imagecreatefromwebp($src); }
    else { $img = @imagecreatefrompng($src); }
    if (!$img) { return $src; }
    $targeth = max(1, (int)round($srch * ($targetw / max(1, $srcw))));
    $scaled = function_exists('imagescale') ? @imagescale($img, $targetw, $targeth) : false;
    imagedestroy($img);
    if (!$scaled) { return $src; }
    @imagejpeg($scaled, $dest, 90);
    imagedestroy($scaled);
    @chmod($dest, $CFG->filepermissions);
    return is_file($dest) ? $dest : $src;
}

$pdfpage = max(1, $sgkpage + 1); // same SGK -> PDF offset used by homework image rendering.
try {
    // Page viewer/crop must use color page cache. Width=0 means keep original rendered size.
    $paths = sgk_processor::render_page_images_cached($bookid, $courseid, $sectionid, $pdfpage, $pdfpage, 180, null, true, $width);
    $path = $paths[0] ?? '';
    if ($path === '' || !is_file($path)) {
        http_response_code(404);
        exit('filenotfound');
    }
    $mime = preg_match('/\.jpe?g$/i', $path) ? 'image/jpeg' : 'image/png';
    send_file($path, basename($path), 0, 0, false, false, $mime);
} catch (Throwable $e) {
    http_response_code(500);
    exit('pageimageerror');
}
