<?php
defined('MOODLE_INTERNAL') || die();

use local_aisgk\book_repository;

function local_aisgk_extend_navigation_course(navigation_node $parentnode, stdClass $course, context_course $context) {
    if (has_capability('local/aisgk:managebooks', $context)) {
        $uploadurl = new moodle_url('/local/aisgk/upload.php', ['id' => $course->id]);

        $parentnode->add(
            get_string('uploadbook', 'local_aisgk'),
            $uploadurl,
            navigation_node::TYPE_SETTING,
            null,
            'local_aisgk_upload'
        );
    }

    if (has_capability('local/aisgk:createtopic', $context)) {
        $topicurl = new moodle_url('/local/aisgk/topic.php', ['id' => $course->id]);

        $parentnode->add(
            get_string('createtopic', 'local_aisgk'),
            $topicurl,
            navigation_node::TYPE_SETTING,
            null,
            'local_aisgk_createtopic'
        );
    }
}

function local_aisgk_before_standard_top_of_body_html(): string {
    global $PAGE, $COURSE;

    if (during_initial_install()) {
        return '';
    }

    $portalhtml = local_aisgk_render_alsm_primary_nav_link();

    if (empty($PAGE) || empty($COURSE) || empty($COURSE->id) || (int)$COURSE->id === SITEID) {
        return $portalhtml;
    }

    $url = $PAGE->url ? $PAGE->url->out(false) : '';
    $iscourseview = (strpos($url, '/course/view.php') !== false);
    if (!$iscourseview) {
        return '';
    }

    $context = context_course::instance($COURSE->id);

    $canmanagebook = has_capability('local/aisgk:managebooks', $context);
    $cancreatetopic = has_capability('local/aisgk:createtopic', $context);
    $cancreatehw = has_capability('local/aisgk:createhomework', $context);
    $canmanageaikeys = is_siteadmin();

    if (!$canmanagebook && !$cancreatetopic && !$cancreatehw && !$canmanageaikeys) {
        return '';
    }

    $PAGE->requires->strings_for_js([
        'uploadbook',
        'replacebook',
        'createtopic',
        'createtopichomework',
        'uploadbookmodaltitle',
        'createtopicmodaltitle',
        'createhomeworkmodaltitle',
        'aikeyslabel',
        'aikeysmodaltitle',
        'myapilabel'
    ], 'local_aisgk');

    $hasbook = book_repository::course_has_book((int)$COURSE->id);

    $PAGE->requires->js_call_amd('local_aisgk/courseheader', 'init', [[
        'courseid' => (int)$COURSE->id,
        'hasbook' => $hasbook,
        'canmanagebook' => $canmanagebook,
        'cancreatetopic' => $cancreatetopic,
        'uploadurl' => (new moodle_url('/local/aisgk/upload.php', ['id' => $COURSE->id]))->out(false),
        'topicurl' => (new moodle_url('/local/aisgk/topic.php', ['id' => $COURSE->id]))->out(false),
        'aikeysurl' => (new moodle_url('/local/aisgk/aikeys.php', ['id' => $COURSE->id]))->out(false),
        'myapiurl' => (new moodle_url('/local/aisgk/myapi.php', ['id' => $COURSE->id]))->out(false),
        'myapiprefurl' => (new moodle_url('/local/aisgk/myapi_ajax.php', ['id' => $COURSE->id, 'op' => 'preference', 'sesskey' => sesskey()]))->out(false),
        'uploadlabel' => get_string('uploadbook', 'local_aisgk'),
        'replacelabel' => get_string('replacebook', 'local_aisgk'),
        'topiclabel' => get_string('createtopic', 'local_aisgk'),
        'aikeyslabel' => get_string('aikeyslabel', 'local_aisgk'),
        'myapilabel' => get_string('myapilabel', 'local_aisgk'),
        'usemyapichecklabel' => get_string('usemyapichecklabel', 'local_aisgk'),
        'uploadtitle' => get_string('uploadbook', 'local_aisgk') . ': ' . format_string($COURSE->fullname),
	'topictitle' => get_string('createtopic', 'local_aisgk') . ': ' . format_string($COURSE->fullname),
        'canaikeys' => $canmanageaikeys,
        'aikeystitle' => get_string('aikeysmodaltitle', 'local_aisgk'),
        'myapititle' => get_string('myapilabel', 'local_aisgk'),
        'usemyapi' => (bool)get_user_preferences('local_aisgk_use_my_api', 0),
    ]]);

    $PAGE->requires->js_call_amd('local_aisgk/topicbuttons', 'init', [[
        'courseid' => (int)$COURSE->id,
        'cancreatehw' => $cancreatehw,
        'basehomeworkurl' => (new moodle_url('/local/aisgk/homework.php', ['id' => $COURSE->id]))->out(false),
        'buttonlabel' => get_string('createtopichomework', 'local_aisgk'),
        'homeworktitle' => get_string('createhomeworkmodaltitle', 'local_aisgk'),
    ]]);

    return $portalhtml;
}

/**
 * Render a small self-contained script that inserts ALSM into Moodle primary navigation.
 *
 * Moodle themes differ: extend_navigation() may appear only in the drawer/flat nav,
 * while Boost based themes use the primary nav. This script makes the shortcut visible
 * near Home/Dashboard/My courses/Site administration without editing Moodle core/theme.
 */
function local_aisgk_render_alsm_primary_nav_link(): string {
    if (!isloggedin() || isguestuser()) {
        return '';
    }

    $url = (new moodle_url('/local/aisgk/index.php'))->out(false);
    $label = get_string('alsmshortname', 'local_aisgk');
    $current = optional_param('local_aisgk_disable_portalnav', 0, PARAM_BOOL);
    if ($current) {
        return '';
    }

    $jsonurl = json_encode($url);
    $jsonlabel = json_encode($label);

    return <<<HTML
<script>
(function() {
    var url = {$jsonurl};
    var label = {$jsonlabel};

    function makeItem() {
        var li = document.createElement('li');
        li.className = 'nav-item local-aisgk-primary-alsm-item';

        var a = document.createElement('a');
        a.id = 'local-aisgk-primary-alsm';
        a.className = 'nav-link';
        a.href = url;
        a.textContent = label;
        a.setAttribute('data-key', 'local_aisgk_portal');

        li.appendChild(a);
        return li;
    }

    function findNav() {
        return document.querySelector('.primary-navigation .navigation') ||
               document.querySelector('nav.moremenu ul.nav') ||
               document.querySelector('.navbar .primary-navigation ul.nav') ||
               document.querySelector('#moremenu-0');
    }

    function insertPortalLink() {
        if (document.getElementById('local-aisgk-primary-alsm')) {
            return;
        }

        var nav = findNav();
        if (!nav) {
            return;
        }

        var item = makeItem();
        var links = nav.querySelectorAll('a');
        var inserted = false;
        for (var i = 0; i < links.length; i++) {
            var text = (links[i].textContent || '').trim().toLowerCase();
            if (text === 'site administration' || text === 'quản trị hệ thống' || text === 'quản trị trang') {
                var parent = links[i].closest('li') || links[i].parentNode;
                if (parent && parent.parentNode) {
                    parent.parentNode.insertBefore(item, parent.nextSibling);
                    inserted = true;
                    break;
                }
            }
        }

        if (!inserted) {
            nav.appendChild(item);
        }
    }

    if (document.readyState === 'loading') {
        document.addEventListener('DOMContentLoaded', insertPortalLink);
    } else {
        insertPortalLink();
    }

    // Boost may render/reflow moremenu shortly after load. Retry lightly.
    window.setTimeout(insertPortalLink, 500);
    window.setTimeout(insertPortalLink, 1500);
})();
</script>
<style>
.local-aisgk-primary-alsm-item .nav-link {
    font-weight: 700;
    color: #0f6cbf !important;
}
.local-aisgk-primary-alsm-item .nav-link:hover,
.local-aisgk-primary-alsm-item .nav-link:focus {
    color: #0b4f8a !important;
}
</style>
HTML;
}

/**
 * Serve cropped homework images stored by local_aisgk.
 */
function local_aisgk_pluginfile($course, $cm, $context, $filearea, $args, $forcedownload, array $options = []) {
    if ($filearea !== 'homeworkimg') {
        return false;
    }
    if ($context->contextlevel !== CONTEXT_COURSE) {
        return false;
    }
    require_login($course);
    if (empty($args)) {
        return false;
    }
    $itemid = (int)array_shift($args);
    $filename = array_pop($args);
    if ($filename === null || $filename === '') {
        return false;
    }
    $filepath = '/' . ($args ? implode('/', $args) . '/' : '');
    $fs = get_file_storage();
    $file = $fs->get_file($context->id, 'local_aisgk', 'homeworkimg', $itemid, $filepath, $filename);
    if (!$file || $file->is_directory()) {
        return false;
    }
    send_stored_file($file, 0, 0, $forcedownload, $options);
}

/**
 * Add a quick ALSM entry to the site navigation for logged-in users.
 */
function local_aisgk_extend_navigation(global_navigation $navigation) {
    if (during_initial_install() || !isloggedin() || isguestuser()) {
        return;
    }

    $node = navigation_node::create(
        get_string('alsmshortname', 'local_aisgk'),
        new moodle_url('/local/aisgk/index.php'),
        navigation_node::TYPE_CUSTOM,
        null,
        'local_aisgk_portal',
        new pix_icon('i/dashboard', '')
    );
    $node->showinflatnavigation = true;
    $navigation->add_node($node);
}
