<?php
defined('MOODLE_INTERNAL') || die();

use local_aisgk\book_repository;

function local_aisgk_extend_navigation_course(navigation_node $parentnode, stdClass $course, context_course $context) {
    if (has_capability('local/aisgk:managebooks', $context)) {
        $uploadurl = new moodle_url('/local/aisgk/upload.php', ['id' => $course->id]);

        $parentnode->add(
            get_string('uploadbook', 'local_aisgk'),
            $uploadurl,
            navigation_node::TYPE_SETTING,
            null,
            'local_aisgk_upload'
        );
    }

    if (has_capability('local/aisgk:createtopic', $context)) {
        $topicurl = new moodle_url('/local/aisgk/topic.php', ['id' => $course->id]);

        $parentnode->add(
            get_string('createtopic', 'local_aisgk'),
            $topicurl,
            navigation_node::TYPE_SETTING,
            null,
            'local_aisgk_createtopic'
        );
    }
}


/**
 * Moodle themes do not all render local extend_navigation nodes in the top menu.
 * These callbacks deliberately inject a tiny JS enhancer from several standard
 * output points so ALSM is visible in Boost/Classic/custom themes without
 * editing core or theme files.
 */
function local_aisgk_before_standard_html_head(): string {
    return local_aisgk_render_alsm_primary_nav_link();
}

function local_aisgk_before_footer(): string {
    return local_aisgk_render_alsm_primary_nav_link();
}

function local_aisgk_before_http_headers(): void {
    global $PAGE;
    if (during_initial_install() || !isloggedin() || isguestuser()) {
        return;
    }
    $url = (new moodle_url('/local/aisgk/index.php'))->out(false);
    $label = get_string('alsmshortname', 'local_aisgk');
    $code = local_aisgk_get_alsm_nav_js($url, $label);
    $PAGE->requires->js_init_code($code);
}

function local_aisgk_before_standard_top_of_body_html(): string {
    global $PAGE, $COURSE;

    if (during_initial_install()) {
        return '';
    }

    $portalhtml = local_aisgk_render_alsm_primary_nav_link();

    if (empty($PAGE) || empty($COURSE) || empty($COURSE->id) || (int)$COURSE->id === SITEID) {
        return $portalhtml;
    }

    $url = $PAGE->url ? $PAGE->url->out(false) : '';
    $iscourseview = (strpos($url, '/course/view.php') !== false);
    if (!$iscourseview) {
        return '';
    }

    $context = context_course::instance($COURSE->id);

    $canmanagebook = has_capability('local/aisgk:managebooks', $context);
    $cancreatetopic = has_capability('local/aisgk:createtopic', $context);
    $cancreatehw = has_capability('local/aisgk:createhomework', $context);
    $canmanageaikeys = is_siteadmin();

    if (!$canmanagebook && !$cancreatetopic && !$cancreatehw && !$canmanageaikeys) {
        return '';
    }

    $PAGE->requires->strings_for_js([
        'uploadbook',
        'replacebook',
        'createtopic',
        'createtopichomework',
        'uploadbookmodaltitle',
        'createtopicmodaltitle',
        'createhomeworkmodaltitle',
        'aikeyslabel',
        'aikeysmodaltitle',
        'myapilabel'
    ], 'local_aisgk');

    $hasbook = book_repository::course_has_book((int)$COURSE->id);
    $alsmscope = \local_aisgk\local\service\pl3_service::course_scope_status((int)$COURSE->id);
    $topicenabled = $cancreatetopic && !empty($alsmscope['ok']);

    $PAGE->requires->js_call_amd('local_aisgk/courseheader', 'init', [[
        'courseid' => (int)$COURSE->id,
        'hasbook' => $hasbook,
        'canmanagebook' => $canmanagebook,
        'cancreatetopic' => $cancreatetopic,
        'topicenabled' => $topicenabled,
        'scopemessage' => (string)($alsmscope['message'] ?? ''),
        'uploadurl' => (new moodle_url('/local/aisgk/upload.php', ['id' => $COURSE->id]))->out(false),
        'topicurl' => (new moodle_url('/local/aisgk/topic.php', ['id' => $COURSE->id]))->out(false),
        'aikeysurl' => (new moodle_url('/local/aisgk/aikeys.php', ['id' => $COURSE->id]))->out(false),
        'myapiurl' => (new moodle_url('/local/aisgk/myapi.php', ['id' => $COURSE->id]))->out(false),
        'myapiprefurl' => (new moodle_url('/local/aisgk/myapi_ajax.php', ['id' => $COURSE->id, 'op' => 'preference', 'sesskey' => sesskey()]))->out(false),
        'uploadlabel' => get_string('uploadbook', 'local_aisgk'),
        'replacelabel' => get_string('replacebook', 'local_aisgk'),
        'topiclabel' => get_string('createtopic', 'local_aisgk'),
        'aikeyslabel' => get_string('aikeyslabel', 'local_aisgk'),
        'myapilabel' => get_string('myapilabel', 'local_aisgk'),
        'usemyapichecklabel' => get_string('usemyapichecklabel', 'local_aisgk'),
        'uploadtitle' => get_string('uploadbook', 'local_aisgk') . ': ' . format_string($COURSE->fullname),
	'topictitle' => get_string('createtopic', 'local_aisgk') . ': ' . format_string($COURSE->fullname),
        'canaikeys' => $canmanageaikeys,
        'aikeystitle' => get_string('aikeysmodaltitle', 'local_aisgk'),
        'myapititle' => get_string('myapilabel', 'local_aisgk'),
        'usemyapi' => (bool)get_user_preferences('local_aisgk_use_my_api', 0),
    ]]);

    $PAGE->requires->js_call_amd('local_aisgk/topicbuttons', 'init', [[
        'courseid' => (int)$COURSE->id,
        'cancreatehw' => $cancreatehw,
        'homeworkenabled' => !empty($alsmscope['ok']),
        'scopemessage' => (string)($alsmscope['message'] ?? ''),
        'basehomeworkurl' => (new moodle_url('/local/aisgk/homework.php', ['id' => $COURSE->id]))->out(false),
        'buttonlabel' => get_string('createtopichomework', 'local_aisgk'),
        'homeworktitle' => get_string('createhomeworkmodaltitle', 'local_aisgk'),
    ]]);

    return $portalhtml;
}

/**
 * Render a small self-contained script that inserts ALSM into Moodle primary navigation.
 *
 * Moodle themes differ: extend_navigation() may appear only in the drawer/flat nav,
 * while Boost based themes use the primary nav. This script makes the shortcut visible
 * near Home/Dashboard/My courses/Site administration without editing Moodle core/theme.
 */
function local_aisgk_render_alsm_primary_nav_link(): string {
    if (during_initial_install() || !isloggedin() || isguestuser()) {
        return '';
    }

    $url = (new moodle_url('/local/aisgk/index.php'))->out(false);
    $label = get_string('alsmshortname', 'local_aisgk');
    if (optional_param('local_aisgk_disable_portalnav', 0, PARAM_BOOL)) {
        return '';
    }

    $code = local_aisgk_get_alsm_nav_js($url, $label);
    return "<script>\n" . $code . "\n</script>\n" . local_aisgk_get_alsm_nav_css();
}

function local_aisgk_get_alsm_nav_css(): string {
    return <<<HTML
<style>
#local-aisgk-primary-alsm.local-aisgk-alsm-link,
.local-aisgk-primary-alsm-item > a,
a.local-aisgk-alsm-link {
    font-weight: 700 !important;
    color: #0f6cbf !important;
}
#local-aisgk-primary-alsm:hover,
.local-aisgk-primary-alsm-item > a:hover,
a.local-aisgk-alsm-link:hover {
    color: #084b86 !important;
}
.local-aisgk-floating-alsm,
.local-aisgk-floating-alsm-mobile {
    position: fixed;
    z-index: 1050;
    background: #0f6cbf;
    color: #fff !important;
    padding: 8px 16px;
    border-radius: 999px;
    font-weight: 700;
    box-shadow: 0 4px 12px rgba(0,0,0,.16);
    text-decoration: none !important;
}
/* Floating ALSM shortcuts are mobile-only. Desktop must use the normal top navigation link. */
.local-aisgk-floating-alsm,
.local-aisgk-primary-alsm-floating,
.local-aisgk-floating-alsm-mobile {
    display: none !important;
    right: 12px;
    bottom: 14px;
}
@media (max-width: 768px) {
    .local-aisgk-floating-alsm,
    .local-aisgk-primary-alsm-floating,
    .local-aisgk-floating-alsm-mobile {
        display: inline-flex !important;
        align-items: center;
        gap: 6px;
    }
}
</style>
HTML;
}

function local_aisgk_get_alsm_nav_js(string $url, string $label): string {
    $jsonurl = json_encode($url);
    $jsonlabel = json_encode($label);
    return <<<JS
(function() {
    var url = {$jsonurl};
    var label = {$jsonlabel};
    var id = 'local-aisgk-primary-alsm';

    function norm(s) {
        return (s || '').replace(/\s+/g, ' ').trim().toLowerCase();
    }

    function makeLi() {
        var li = document.createElement('li');
        li.className = 'nav-item local-aisgk-primary-alsm-item';
        var a = document.createElement('a');
        a.id = id;
        a.className = 'nav-link local-aisgk-alsm-link';
        a.href = url;
        a.textContent = label;
        a.setAttribute('data-key', 'local_aisgk_portal');
        li.appendChild(a);
        return li;
    }

    function navCandidates() {
        var selectors = [
            'header .primary-navigation .moremenu ul.nav',
            'header .primary-navigation ul.nav',
            'header nav.moremenu ul.nav',
            '.primary-navigation .moremenu ul.nav',
            '.primary-navigation ul.nav',
            'nav.moremenu ul.nav',
            'header .navbar-nav',
            '.navbar .navbar-nav',
            'ul.navbar-nav',
            '.moremenu ul.nav',
            'ul.nav.more-nav',
            '[data-region="drawer"] .list-group',
            '#nav-drawer .list-group',
            '.drawer .list-group',
            '.drawercontent .list-group',
            '.mobile-primary-nav ul',
            '.navbar-collapse ul.navbar-nav',
            'ul.nav'
        ];
        var out = [];
        selectors.forEach(function(sel) {
            document.querySelectorAll(sel).forEach(function(n) {
                if (out.indexOf(n) === -1 && n.querySelectorAll('a').length) {
                    out.push(n);
                }
            });
        });
        return out;
    }

    function isSiteAdminLink(a) {
        var t = norm(a.textContent);
        var href = a.getAttribute('href') || '';
        return t === 'site administration' ||
               t === 'quản trị hệ thống' ||
               t === 'quản trị trang' ||
               href.indexOf('/admin/search.php') !== -1;
    }

    function insertIntoNav(nav) {
        if (!nav || document.getElementById(id)) {
            return true;
        }
        var item = makeLi();
        var links = Array.prototype.slice.call(nav.querySelectorAll('a'));
        for (var i = 0; i < links.length; i++) {
            if (isSiteAdminLink(links[i])) {
                var parent = links[i].closest('li') || links[i].parentNode;
                if (parent && parent.parentNode) {
                    parent.parentNode.insertBefore(item, parent.nextSibling);
                    return true;
                }
            }
        }
        nav.appendChild(item);
        return true;
    }

    function fallbackButton() {
        var fid = id + '-floating';
        var existing = document.getElementById(fid);

        // On desktop the ALSM entry belongs in Moodle's top navigation only.
        // Do not leave a floating shortcut over modals/popups.
        if (window.innerWidth > 768) {
            if (existing) { existing.remove(); }
            return;
        }

        if (document.getElementById(id) || existing) {
            return;
        }
        var a = document.createElement('a');
        a.id = fid;
        a.className = 'local-aisgk-floating-alsm local-aisgk-primary-alsm-floating';
        a.href = url;
        a.textContent = label;
        document.body.appendChild(a);
    }

    function mobileShortcut() {
        var mid = id + '-mobile';
        var existing = document.getElementById(mid);
        if (window.innerWidth > 768) {
            if (existing) { existing.remove(); }
            return;
        }
        if (existing) { return; }
        var a = document.createElement('a');
        a.id = mid;
        a.className = 'local-aisgk-floating-alsm-mobile';
        a.href = url;
        a.textContent = label;
        document.body.appendChild(a);
    }

    function ensureLink() {
        if (document.getElementById(id)) {
            return true;
        }
        var navs = navCandidates();
        for (var i = 0; i < navs.length; i++) {
            if (insertIntoNav(navs[i])) {
                var f = document.getElementById(id + '-floating');
                if (f) { f.remove(); }
                return true;
            }
        }
        return false;
    }

    function run() {
        if (!ensureLink()) {
            fallbackButton();
        }
        mobileShortcut();
    }

    if (document.readyState === 'loading') {
        document.addEventListener('DOMContentLoaded', run);
    } else {
        run();
    }
    [250, 750, 1500, 3000, 5000].forEach(function(ms) { window.setTimeout(run, ms); });
    window.addEventListener('resize', run);
    try {
        var obs = new MutationObserver(function() { run(); });
        obs.observe(document.documentElement, {childList: true, subtree: true});
        window.setTimeout(function(){ obs.disconnect(); }, 10000);
    } catch (e) {}
})();
JS;
}

/**
 * Serve cropped homework images stored by local_aisgk.
 */
function local_aisgk_pluginfile($course, $cm, $context, $filearea, $args, $forcedownload, array $options = []) {
    if ($filearea !== 'homeworkimg') {
        return false;
    }
    if ($context->contextlevel !== CONTEXT_COURSE) {
        return false;
    }
    require_login($course);
    if (empty($args)) {
        return false;
    }
    $itemid = (int)array_shift($args);
    $filename = array_pop($args);
    if ($filename === null || $filename === '') {
        return false;
    }
    $filepath = '/' . ($args ? implode('/', $args) . '/' : '');
    $fs = get_file_storage();
    $file = $fs->get_file($context->id, 'local_aisgk', 'homeworkimg', $itemid, $filepath, $filename);
    if (!$file || $file->is_directory()) {
        return false;
    }
    send_stored_file($file, 0, 0, $forcedownload, $options);
}

/**
 * Add a quick ALSM entry to the site navigation for logged-in users.
 */
function local_aisgk_extend_navigation(global_navigation $navigation) {
    if (during_initial_install() || !isloggedin() || isguestuser()) {
        return;
    }

    $node = navigation_node::create(
        get_string('alsmshortname', 'local_aisgk'),
        new moodle_url('/local/aisgk/index.php'),
        navigation_node::TYPE_CUSTOM,
        null,
        'local_aisgk_portal',
        new pix_icon('i/dashboard', '')
    );
    $node->showinflatnavigation = true;
    $navigation->add_node($node);
}
