<?php
defined('MOODLE_INTERNAL') || die();

use local_aisgk\book_repository;

function local_aisgk_extend_navigation_course(navigation_node $parentnode, stdClass $course, context_course $context) {
    if (has_capability('local/aisgk:managebooks', $context)) {
        $uploadurl = new moodle_url('/local/aisgk/upload.php', ['id' => $course->id]);

        $parentnode->add(
            get_string('uploadbook', 'local_aisgk'),
            $uploadurl,
            navigation_node::TYPE_SETTING,
            null,
            'local_aisgk_upload'
        );
    }

    if (has_capability('local/aisgk:createtopic', $context)) {
        $topicurl = new moodle_url('/local/aisgk/topic.php', ['id' => $course->id]);

        $parentnode->add(
            get_string('createtopic', 'local_aisgk'),
            $topicurl,
            navigation_node::TYPE_SETTING,
            null,
            'local_aisgk_createtopic'
        );
    }
}

function local_aisgk_before_standard_top_of_body_html(): string {
    global $PAGE, $COURSE;

    if (during_initial_install()) {
        return '';
    }

    if (empty($PAGE) || empty($COURSE) || empty($COURSE->id) || (int)$COURSE->id === SITEID) {
        return '';
    }

    $url = $PAGE->url ? $PAGE->url->out(false) : '';
    $iscourseview = (strpos($url, '/course/view.php') !== false);
    if (!$iscourseview) {
        return '';
    }

    $context = context_course::instance($COURSE->id);

    $canmanagebook = has_capability('local/aisgk:managebooks', $context);
    $cancreatetopic = has_capability('local/aisgk:createtopic', $context);
    $cancreatehw = has_capability('local/aisgk:createhomework', $context);

    if (!$canmanagebook && !$cancreatetopic && !$cancreatehw) {
        return '';
    }

    $PAGE->requires->strings_for_js([
        'uploadbook',
        'replacebook',
        'createtopic',
        'createtopichomework',
        'uploadbookmodaltitle',
        'createtopicmodaltitle',
        'createhomeworkmodaltitle'
    ], 'local_aisgk');

    $hasbook = book_repository::course_has_book((int)$COURSE->id);

    $PAGE->requires->js_call_amd('local_aisgk/courseheader', 'init', [[
        'courseid' => (int)$COURSE->id,
        'hasbook' => $hasbook,
        'canmanagebook' => $canmanagebook,
        'cancreatetopic' => $cancreatetopic,
        'uploadurl' => (new moodle_url('/local/aisgk/upload.php', ['id' => $COURSE->id]))->out(false),
        'topicurl' => (new moodle_url('/local/aisgk/topic.php', ['id' => $COURSE->id]))->out(false),
        'uploadlabel' => get_string('uploadbook', 'local_aisgk'),
        'replacelabel' => get_string('replacebook', 'local_aisgk'),
        'topiclabel' => get_string('createtopic', 'local_aisgk'),
        'uploadtitle' => get_string('uploadbook', 'local_aisgk') . ': ' . format_string($COURSE->fullname),
	'topictitle' => get_string('createtopic', 'local_aisgk') . ': ' . format_string($COURSE->fullname),
    ]]);

    $PAGE->requires->js_call_amd('local_aisgk/topicbuttons', 'init', [[
        'courseid' => (int)$COURSE->id,
        'cancreatehw' => $cancreatehw,
        'basehomeworkurl' => (new moodle_url('/local/aisgk/homework.php', ['id' => $COURSE->id]))->out(false),
        'buttonlabel' => get_string('createtopichomework', 'local_aisgk'),
        'homeworktitle' => get_string('createhomeworkmodaltitle', 'local_aisgk'),
    ]]);

    return '';
}
