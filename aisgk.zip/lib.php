<?php
defined('MOODLE_INTERNAL') || die();

use local_aisgk\book_repository;

function local_aisgk_extend_navigation_course(navigation_node $parentnode, stdClass $course, context_course $context) {
    if (has_capability('local/aisgk:managebooks', $context)) {
        $uploadurl = new moodle_url('/local/aisgk/upload.php', ['id' => $course->id]);

        $parentnode->add(
            get_string('uploadbook', 'local_aisgk'),
            $uploadurl,
            navigation_node::TYPE_SETTING,
            null,
            'local_aisgk_upload'
        );
    }

    if (has_capability('local/aisgk:createtopic', $context)) {
        $topicurl = new moodle_url('/local/aisgk/topic.php', ['id' => $course->id]);

        $parentnode->add(
            get_string('createtopic', 'local_aisgk'),
            $topicurl,
            navigation_node::TYPE_SETTING,
            null,
            'local_aisgk_createtopic'
        );
    }
}

function local_aisgk_before_standard_top_of_body_html(): string {
    global $PAGE, $COURSE;

    if (during_initial_install()) {
        return '';
    }

    if (empty($PAGE) || empty($COURSE) || empty($COURSE->id) || (int)$COURSE->id === SITEID) {
        return '';
    }

    $url = $PAGE->url ? $PAGE->url->out(false) : '';
    $iscourseview = (strpos($url, '/course/view.php') !== false);
    if (!$iscourseview) {
        return '';
    }

    $context = context_course::instance($COURSE->id);

    $canmanagebook = has_capability('local/aisgk:managebooks', $context);
    $cancreatetopic = has_capability('local/aisgk:createtopic', $context);
    $cancreatehw = has_capability('local/aisgk:createhomework', $context);
    $canmanageaikeys = is_siteadmin();

    if (!$canmanagebook && !$cancreatetopic && !$cancreatehw && !$canmanageaikeys) {
        return '';
    }

    $PAGE->requires->strings_for_js([
        'uploadbook',
        'replacebook',
        'createtopic',
        'createtopichomework',
        'uploadbookmodaltitle',
        'createtopicmodaltitle',
        'createhomeworkmodaltitle',
        'aikeyslabel',
        'aikeysmodaltitle',
        'myapilabel'
    ], 'local_aisgk');

    $hasbook = book_repository::course_has_book((int)$COURSE->id);

    $PAGE->requires->js_call_amd('local_aisgk/courseheader', 'init', [[
        'courseid' => (int)$COURSE->id,
        'hasbook' => $hasbook,
        'canmanagebook' => $canmanagebook,
        'cancreatetopic' => $cancreatetopic,
        'uploadurl' => (new moodle_url('/local/aisgk/upload.php', ['id' => $COURSE->id]))->out(false),
        'topicurl' => (new moodle_url('/local/aisgk/topic.php', ['id' => $COURSE->id]))->out(false),
        'aikeysurl' => (new moodle_url('/local/aisgk/aikeys.php', ['id' => $COURSE->id]))->out(false),
        'myapiurl' => (new moodle_url('/local/aisgk/myapi.php', ['id' => $COURSE->id]))->out(false),
        'myapiprefurl' => (new moodle_url('/local/aisgk/myapi_ajax.php', ['id' => $COURSE->id, 'op' => 'preference', 'sesskey' => sesskey()]))->out(false),
        'uploadlabel' => get_string('uploadbook', 'local_aisgk'),
        'replacelabel' => get_string('replacebook', 'local_aisgk'),
        'topiclabel' => get_string('createtopic', 'local_aisgk'),
        'aikeyslabel' => get_string('aikeyslabel', 'local_aisgk'),
        'myapilabel' => get_string('myapilabel', 'local_aisgk'),
        'usemyapichecklabel' => get_string('usemyapichecklabel', 'local_aisgk'),
        'uploadtitle' => get_string('uploadbook', 'local_aisgk') . ': ' . format_string($COURSE->fullname),
	'topictitle' => get_string('createtopic', 'local_aisgk') . ': ' . format_string($COURSE->fullname),
        'canaikeys' => $canmanageaikeys,
        'aikeystitle' => get_string('aikeysmodaltitle', 'local_aisgk'),
        'myapititle' => get_string('myapilabel', 'local_aisgk'),
        'usemyapi' => (bool)get_user_preferences('local_aisgk_use_my_api', 0),
    ]]);

    $PAGE->requires->js_call_amd('local_aisgk/topicbuttons', 'init', [[
        'courseid' => (int)$COURSE->id,
        'cancreatehw' => $cancreatehw,
        'basehomeworkurl' => (new moodle_url('/local/aisgk/homework.php', ['id' => $COURSE->id]))->out(false),
        'buttonlabel' => get_string('createtopichomework', 'local_aisgk'),
        'homeworktitle' => get_string('createhomeworkmodaltitle', 'local_aisgk'),
    ]]);

    return '';
}

/**
 * Serve cropped homework images stored by local_aisgk.
 */
function local_aisgk_pluginfile($course, $cm, $context, $filearea, $args, $forcedownload, array $options = []) {
    if ($filearea !== 'homeworkimg') {
        return false;
    }
    if ($context->contextlevel !== CONTEXT_COURSE) {
        return false;
    }
    require_login($course);
    if (empty($args)) {
        return false;
    }
    $itemid = (int)array_shift($args);
    $filename = array_pop($args);
    if ($filename === null || $filename === '') {
        return false;
    }
    $filepath = '/' . ($args ? implode('/', $args) . '/' : '');
    $fs = get_file_storage();
    $file = $fs->get_file($context->id, 'local_aisgk', 'homeworkimg', $itemid, $filepath, $filename);
    if (!$file || $file->is_directory()) {
        return false;
    }
    send_stored_file($file, 0, 0, $forcedownload, $options);
}
