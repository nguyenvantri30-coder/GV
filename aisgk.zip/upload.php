<style>

.local-aisgk-dialog-backdrop{position:fixed;inset:0;z-index:10050;background:rgba(15,23,42,.24);display:flex;align-items:center;justify-content:center;padding:12px}
.local-aisgk-dialog{width:min(360px,92vw);background:#fff;border:1px solid #cbd5e1;border-radius:12px;box-shadow:0 16px 42px rgba(15,23,42,.26);padding:12px}
.local-aisgk-dialog-title{font-weight:700;font-size:14px;margin-bottom:6px;color:#0f172a}
.local-aisgk-dialog-body{font-size:13px;line-height:1.4;color:#334155;white-space:pre-wrap;max-height:45vh;overflow:auto}
.local-aisgk-dialog-actions{display:flex;gap:6px;justify-content:flex-end;margin-top:10px}
.local-aisgk-dialog-actions .btn,.local-aisgk-dialog-actions button{padding:5px 10px!important;font-size:12px!important;line-height:1.2!important;border-radius:8px!important;min-height:auto!important}
.local-aisgk-dialog-confirm{border-color:#fca5a5}
.local-aisgk-msgbox{position:fixed;top:14px;right:14px;z-index:10050;background:#fff;border:1px solid #cbd5e1;border-radius:10px;box-shadow:0 8px 24px rgba(15,23,42,.18);padding:8px 12px;max-width:340px;font-size:13px;line-height:1.35}

</style>
<?php
require('../../config.php');

use local_aisgk\book_repository;
use local_aisgk\local\service\book_service;

$courseid = optional_param('id', 0, PARAM_INT);
if (!$courseid) {
    throw new moodle_exception('missingcourseid', 'local_aisgk');
}
$course = get_course($courseid);
require_login($course);
$context = context_course::instance($courseid);
require_capability('local/aisgk:managebooks', $context);

$PAGE->set_context($context);
$PAGE->set_url('/local/aisgk/upload.php', ['id' => $courseid]);
$PAGE->set_pagelayout('embedded');
$PAGE->set_title(get_string('uploadbook', 'local_aisgk') . ': ' . format_string($course->fullname));

$books = book_repository::get_all_by_courseid($courseid);
$message = '';
$messagetype = 'success';

if (data_submitted() && confirm_sesskey()) {
    try {
        $action = optional_param('action', 'upload', PARAM_ALPHA);
        if ($action === 'delete') {
            $bookid = required_param('bookid', PARAM_INT);
            book_service::delete_book($courseid, $bookid);
            $books = book_repository::get_all_by_courseid($courseid);
            $message = get_string('bookdeleted', 'local_aisgk');
        } else {
            if (empty($_FILES['bookpdf']) || empty($_FILES['bookpdf']['name'])) {
                throw new moodle_exception('nofile', 'local_aisgk');
            }
            if (!empty($_FILES['bookpdf']['error']) && (int)$_FILES['bookpdf']['error'] !== UPLOAD_ERR_OK) {
                throw new moodle_exception('uploaderrorserver', 'local_aisgk', '', $_FILES['bookpdf']['error']);
            }
            $bookname = trim(optional_param('bookname', '', PARAM_TEXT));
            book_service::save_uploaded_book($courseid, $_FILES['bookpdf'], $bookname);
            $books = book_repository::get_all_by_courseid($courseid);
            $message = get_string('bookuploaded', 'local_aisgk');
        }
    } catch (Throwable $e) {
        $message = $e->getMessage();
        $messagetype = 'error';
    }
}

echo $OUTPUT->header();
?>
<style>
.local-aisgk-upload-wrap {padding: 14px; font-size:13px; width:100%; max-width:100%; box-sizing:border-box; overflow-x:hidden;}
.local-aisgk-upload-head {display:flex; justify-content:space-between; align-items:center; margin-bottom:12px; gap:12px;}
.local-aisgk-upload-head h3 {margin:0; font-size:15px; line-height:1.15;}
.local-aisgk-softpill {display:inline-flex; align-items:center; border-radius:999px; background:#eff6ff; color:#1d4ed8; padding:4px 10px; font-size:12px; flex:0 0 auto;}
.local-aisgk-upload-form, .local-aisgk-existing {border:1px solid #d0d7de; border-radius:8px; padding:12px; background:#fff; margin-bottom:14px; max-width:100%; box-sizing:border-box;}
.local-aisgk-upload-toprow {display:flex; align-items:center; gap:8px; flex-wrap:wrap;}
.local-aisgk-upload-field {display:flex; align-items:center; gap:8px; margin:0; flex-wrap:wrap; width:100%;}
.local-aisgk-upload-field label {display:block; font-weight:600; margin:0; white-space:nowrap;}
.local-aisgk-upload-file {flex:1 1 auto; min-width:280px;}
.local-aisgk-upload-name {flex:1 1 420px; min-width:320px;}
.local-aisgk-upload-file input[type="file"] {width:auto; max-width:100%; height:34px; padding:4px 8px; border:1px solid #cbd5e1; border-radius:7px; background:#fff;}
.local-aisgk-upload-name input[type="text"], #id_bookname {width:min(380px,100%); box-sizing:border-box; height:34px; padding:5px 9px; border:1px solid #cbd5e1; border-radius:7px;}
.local-aisgk-upload-submit {margin-top:0; height:34px; display:inline-flex; align-items:center; justify-content:center; padding:0 14px; border-radius:7px;}
.local-aisgk-existing-tablewrap {width:100%; max-width:100%; overflow-x:auto; -webkit-overflow-scrolling:touch;}
.local-aisgk-existing table {width:max-content; min-width:100%; border-collapse:collapse;}
.local-aisgk-existing th, .local-aisgk-existing td {border:1px solid #e5e7eb; padding:6px 8px; text-align:left; vertical-align:middle;}
.local-aisgk-existing th {background:#f8f9fa;}
.local-aisgk-delete-cell {width:82px; text-align:center;}
.local-aisgk-delete-form {margin:0; display:inline;}
.local-aisgk-delete-btn {display:inline-flex; align-items:center; justify-content:center; width:30px; height:30px; padding:0; border:1px solid #dc3545; border-radius:6px; background:#fff; color:#dc3545; font-size:18px; line-height:1; cursor:pointer;}
.local-aisgk-delete-btn:hover, .local-aisgk-delete-btn:focus {background:#fff5f5; text-decoration:none;}
@media (max-width: 992px) { .local-aisgk-upload-form, .local-aisgk-existing {padding:10px;} .local-aisgk-upload-submit {width:100%;} }
@media (max-width: 768px) {
    .local-aisgk-upload-wrap {padding: 12px;}
    .local-aisgk-upload-toprow {flex-direction:column; align-items:stretch; gap:10px;}
    .local-aisgk-upload-field {align-items:stretch; flex-direction:column; gap:4px;}
    .local-aisgk-upload-file, .local-aisgk-upload-name {min-width:0; flex:1 1 auto;}
    .local-aisgk-upload-file input[type="file"] {width:100%;}
}
</style>
<div class="local-aisgk-upload-wrap"><div class="local-aisgk-upload-head"><span class="local-aisgk-softpill">PDF</span></div>
    <?php if ($message !== ''): ?>
        <div class="alert alert-<?php echo $messagetype === 'success' ? 'success' : 'danger'; ?>"><?php echo s($message); ?></div>
    <?php endif; ?>
    <form class="local-aisgk-upload-form" method="post" enctype="multipart/form-data">
        <input type="hidden" name="sesskey" value="<?php echo sesskey(); ?>">
        <input type="hidden" name="action" value="upload">
        <div class="local-aisgk-upload-toprow">
            <div class="local-aisgk-upload-field local-aisgk-upload-file">
                <input type="text" id="id_bookname" name="bookname" placeholder="<?php echo s(get_string('booknameplaceholder', 'local_aisgk')); ?>">
		<input type="file" id="id_bookpdf" name="bookpdf" accept=".pdf,application/pdf" required>
		 <button type="submit" class="btn btn-primary local-aisgk-upload-submit"><?php echo s(get_string('uploadbook', 'local_aisgk')); ?></button>
            </div>

        </div>
    </form>
    <div class="local-aisgk-existing">
        <h4><?php echo s(get_string('existingbooks', 'local_aisgk')); ?></h4>
        <?php if (!$books): ?>
            <div><?php echo s(get_string('nobooksincourse', 'local_aisgk')); ?></div>
        <?php else: ?>
            <div class="local-aisgk-existing-tablewrap">
            <table>
                <thead><tr><th>#</th><th><?php echo s(get_string('bookname', 'local_aisgk')); ?></th><th><?php echo s(get_string('filename', 'local_aisgk')); ?></th><th><?php echo s(get_string('tocfrompage', 'local_aisgk')); ?></th><th><?php echo s(get_string('toctopage', 'local_aisgk')); ?></th><th class="local-aisgk-delete-cell"><?php echo s(get_string('delete', 'core')); ?></th></tr></thead>
                <tbody>
                <?php foreach ($books as $idx => $book): ?>
                    <tr><td><?php echo $idx + 1; ?></td><td><?php echo s($book->name ?: $book->filename); ?></td><td><?php echo s($book->filename); ?></td><td><?php echo (int)$book->tocfrompage; ?></td><td><?php echo (int)$book->toctopage; ?></td><td class="local-aisgk-delete-cell"><form method="post" class="local-aisgk-delete-form" data-confirm="<?php echo s(get_string('confirmdeletebook', 'local_aisgk')); ?>"><input type="hidden" name="sesskey" value="<?php echo sesskey(); ?>"><input type="hidden" name="action" value="delete"><input type="hidden" name="bookid" value="<?php echo (int)$book->id; ?>"><button type="submit" class="local-aisgk-delete-btn" title="<?php echo s(get_string('deletebook', 'local_aisgk')); ?>" aria-label="<?php echo s(get_string('deletebook', 'local_aisgk')); ?>">×</button></form></td></tr>
                <?php endforeach; ?>
                </tbody>
            </table>
            </div>
        <?php endif; ?>
    </div>
</div>
<?php
echo $OUTPUT->footer();
