<?php
require('../../config.php');

use local_aisgk\book_repository;
use local_aisgk\local\service\book_service;

$courseid = optional_param('id', 0, PARAM_INT);
if (!$courseid) {
    throw new moodle_exception('missingcourseid', 'local_aisgk');
}
$course = get_course($courseid);
require_login($course);
$context = context_course::instance($courseid);
require_capability('local/aisgk:managebooks', $context);

$PAGE->set_context($context);
$PAGE->set_url('/local/aisgk/upload.php', ['id' => $courseid]);
$PAGE->set_pagelayout('embedded');
$PAGE->set_title(get_string('uploadbook', 'local_aisgk'));

$books = book_repository::get_all_by_courseid($courseid);
$message = '';
$messagetype = 'success';

if (data_submitted() && confirm_sesskey()) {
    try {
        if (empty($_FILES['bookpdf']) || empty($_FILES['bookpdf']['name'])) {
            throw new moodle_exception('nofile', 'local_aisgk');
        }
        if (!empty($_FILES['bookpdf']['error']) && (int)$_FILES['bookpdf']['error'] !== UPLOAD_ERR_OK) {
            throw new moodle_exception('uploaderrorserver', 'local_aisgk', '', $_FILES['bookpdf']['error']);
        }
        $bookname = trim(optional_param('bookname', '', PARAM_TEXT));
        book_service::save_uploaded_book($courseid, $_FILES['bookpdf'], $bookname);
        $books = book_repository::get_all_by_courseid($courseid);
        $message = get_string('bookuploaded', 'local_aisgk');
    } catch (Throwable $e) {
        $message = $e->getMessage();
        $messagetype = 'error';
    }
}

echo $OUTPUT->header();
?>
<style>
.local-aisgk-upload-wrap {padding: 12px;}
.local-aisgk-upload-form, .local-aisgk-existing {border:1px solid #d0d7de; border-radius:8px; padding:12px; background:#fff; margin-bottom:14px;}
.local-aisgk-upload-form .frow {margin-bottom:10px;}
.local-aisgk-upload-form label {display:block; font-weight:600; margin-bottom:4px;}
.local-aisgk-upload-form input[type="text"], .local-aisgk-upload-form input[type="file"] {width:100%; box-sizing:border-box;}
.local-aisgk-existing table {width:100%; border-collapse:collapse;}
.local-aisgk-existing th, .local-aisgk-existing td {border:1px solid #e5e7eb; padding:6px 8px; text-align:left;}
.local-aisgk-existing th {background:#f8f9fa;}
</style>
<div class="local-aisgk-upload-wrap">
    <?php if ($message !== ''): ?>
        <div class="alert alert-<?php echo $messagetype === 'success' ? 'success' : 'danger'; ?>"><?php echo s($message); ?></div>
    <?php endif; ?>
    <form class="local-aisgk-upload-form" method="post" enctype="multipart/form-data">
        <input type="hidden" name="sesskey" value="<?php echo sesskey(); ?>">
        <div class="frow">
            <label for="id_bookname"><?php echo s(get_string('bookname', 'local_aisgk')); ?></label>
            <input type="text" id="id_bookname" name="bookname" placeholder="<?php echo s(get_string('booknameplaceholder', 'local_aisgk')); ?>">
        </div>
        <div class="frow">
            <label for="id_bookpdf"><?php echo s(get_string('uploadbook', 'local_aisgk')); ?></label>
            <input type="file" id="id_bookpdf" name="bookpdf" accept=".pdf,application/pdf" required>
            <div class="text-muted small"><?php echo s(get_string('uploadlimitnote', 'local_aisgk')); ?></div>
        </div>
        <button type="submit" class="btn btn-primary"><?php echo s(get_string('uploadbook', 'local_aisgk')); ?></button>
    </form>
    <div class="local-aisgk-existing">
        <h4><?php echo s(get_string('existingbooks', 'local_aisgk')); ?></h4>
        <?php if (!$books): ?>
            <div><?php echo s(get_string('nobooksincourse', 'local_aisgk')); ?></div>
        <?php else: ?>
            <table>
                <thead><tr><th>#</th><th><?php echo s(get_string('bookname', 'local_aisgk')); ?></th><th><?php echo s(get_string('filename', 'local_aisgk')); ?></th><th><?php echo s(get_string('tocfrompage', 'local_aisgk')); ?></th><th><?php echo s(get_string('toctopage', 'local_aisgk')); ?></th></tr></thead>
                <tbody>
                <?php foreach ($books as $idx => $book): ?>
                    <tr><td><?php echo $idx + 1; ?></td><td><?php echo s($book->name ?: $book->filename); ?></td><td><?php echo s($book->filename); ?></td><td><?php echo (int)$book->tocfrompage; ?></td><td><?php echo (int)$book->toctopage; ?></td></tr>
                <?php endforeach; ?>
                </tbody>
            </table>
        <?php endif; ?>
    </div>
</div>
<?php
echo $OUTPUT->footer();
