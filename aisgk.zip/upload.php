<?php
require('../../config.php');

$localaisgkmodal = optional_param('modal', 0, PARAM_BOOL);
function local_aisgk_modal_page_open($title = '') {
    global $OUTPUT, $localaisgkmodal;
    if ($localaisgkmodal) {
        echo '<!doctype html><html><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>' . s($title) . '</title><style>html,body{margin:0!important;padding:0!important;background:#fff!important;overflow:hidden;font-family:Arial,Helvetica,sans-serif}.modal-clean-wrap{padding:10px;box-sizing:border-box;width:100%;height:100vh;overflow:auto}.btn,.local-aisgk-modal .btn,button,input[type=submit]{display:inline-flex!important;align-items:center!important;justify-content:center!important;height:34px!important;line-height:1!important;padding:0 12px!important;box-sizing:border-box!important;vertical-align:middle!important}table{border-collapse:collapse}.muted{color:#64748b}.table-responsive{overflow:auto}</style></head><body><div class="modal-clean-wrap">';
    } else {
        local_aisgk_modal_page_open($PAGE->title ?? '');
    }
}
function local_aisgk_modal_page_close() {
    global $OUTPUT, $localaisgkmodal;
    if ($localaisgkmodal) {
        echo '</div></body></html>';
    } else {
        local_aisgk_modal_page_close();
    }
}


use local_aisgk\book_repository;
use local_aisgk\local\service\book_service;
use local_aisgk\local\service\pl3_service;

$courseid = optional_param('id', 0, PARAM_INT);
if (!$courseid) {
    throw new moodle_exception('missingcourseid', 'local_aisgk');
}
$course = get_course($courseid);
require_login($course);
$context = context_course::instance($courseid);
require_capability('local/aisgk:managebooks', $context);

$PAGE->set_context($context);
$PAGE->set_url('/local/aisgk/upload.php', ['id' => $courseid]);
$PAGE->set_pagelayout('embedded');
$PAGE->set_title(get_string('uploadbook', 'local_aisgk') . ': ' . format_string($course->fullname));

$books = book_repository::get_all_by_courseid($courseid);
$message = '';
$messagetype = 'success';
$activeTab = optional_param('tab', 'sgk', PARAM_ALPHA);
$previewrows = [];
$previewbookid = 0;

if (data_submitted() && confirm_sesskey()) {
    try {
        $action = optional_param('action', 'upload', PARAM_ALPHANUMEXT);
        if ($action === 'savebooks') {
            $deletebookid = optional_param('deletebookid', 0, PARAM_INT);
            if ($deletebookid > 0) {
                book_service::delete_book($courseid, $deletebookid);
            } else {
                $bookrows = $_POST['books'] ?? [];
                book_service::update_books_metadata($courseid, is_array($bookrows) ? $bookrows : []);
                $message = 'Đã lưu SGK. Kết quả xác định Tập/HK:\n' . book_service::course_book_scope_report($courseid);
                $messagetype = 'success';
            }
            $books = book_repository::get_all_by_courseid($courseid);
            $activeTab = 'sgk';
        } else if ($action === 'uploadrow') {
            $rowkey = optional_param('uploadrowkey', '', PARAM_RAW_TRIMMED);
            if ($rowkey === '') {
                throw new moodle_exception('invalidrecord', 'error');
            }
            $bookrows = $_POST['books'] ?? [];
            $row = (is_array($bookrows) && isset($bookrows[$rowkey]) && is_array($bookrows[$rowkey])) ? $bookrows[$rowkey] : [];
            $bookid = (int)($row['id'] ?? 0);
            $bookname = clean_param((string)($row['name'] ?? ''), PARAM_TEXT);
            $bookseries = clean_param((string)($row['bookseries'] ?? ''), PARAM_TEXT);
            $publisher = clean_param((string)($row['publisher'] ?? ''), PARAM_TEXT);
            $description = clean_param((string)($row['description'] ?? ''), PARAM_TEXT);
            $bookpart = (int)($row['book_part'] ?? 0);
            if (empty($_FILES['bookpdf']) || empty($_FILES['bookpdf']['name'])) {
                throw new moodle_exception('nofile', 'local_aisgk');
            }
            book_service::save_or_update_uploaded_book($courseid, $bookid, $_FILES['bookpdf'], $bookname, $bookseries, $publisher, $description, $bookpart);
            $message = 'Đã upload SGK. Kết quả xác định Tập/HK:\n' . book_service::course_book_scope_report($courseid);
            $messagetype = 'success';
            $books = book_repository::get_all_by_courseid($courseid);
            $activeTab = 'sgk';
        } else if ($action === 'previewpl3') {
            $previewbookid = optional_param('pl3bookid', 0, PARAM_INT);
            $previewrows = pl3_service::parse_uploaded_pl3($_FILES['pl3file'] ?? [], $courseid, $previewbookid);
            $activeTab = 'pl3';
        } else if ($action === 'savepl3') {
            $previewbookid = optional_param('pl3bookid', 0, PARAM_INT);
            // Moodle clean_param() cannot process nested arrays. Read the grouped
            // PL3 preview rows from $_POST and sanitize fields in pl3_service.
            $groups = $_POST['groups'] ?? [];
            $count = pl3_service::save_competency_groups($courseid, $previewbookid, is_array($groups) ? $groups : []);
            $st = pl3_service::scope_status($courseid, $previewbookid);
            $message = 'Đã lưu ' . $count . ' dòng năng lực. Kết quả detect PL3: ' . ($st['pl3_split'] ? 'đã xác định HK1/HK2' : 'chưa xác định HK1/HK2') . '. ' . ($st['message'] ?? '');
            $messagetype = empty($st['pl3_split']) ? 'error' : 'success';
            $activeTab = 'pl3';
        } else if ($action === 'deletepl3') {
            $previewbookid = optional_param('pl3bookid', 0, PARAM_INT);
            pl3_service::delete_competencies($courseid, $previewbookid);
            $previewrows = [];
            $activeTab = 'pl3';
        } else {
            if (empty($_FILES['bookpdf']) || empty($_FILES['bookpdf']['name'])) {
                throw new moodle_exception('nofile', 'local_aisgk');
            }
            if (!empty($_FILES['bookpdf']['error']) && (int)$_FILES['bookpdf']['error'] !== UPLOAD_ERR_OK) {
                throw new moodle_exception('uploaderrorserver', 'local_aisgk', '', $_FILES['bookpdf']['error']);
            }
            $bookname = trim(optional_param('bookname', '', PARAM_TEXT));
            $bookseries = trim(optional_param('bookseries', '', PARAM_TEXT));
            $publisher = trim(optional_param('publisher', '', PARAM_TEXT));
            $description = trim(optional_param('description', '', PARAM_TEXT));
            $bookpart = optional_param('book_part', 0, PARAM_INT);
            book_service::save_uploaded_book($courseid, $_FILES['bookpdf'], $bookname, $bookseries, $publisher, $description, $bookpart);
            $books = book_repository::get_all_by_courseid($courseid);
            $activeTab = 'sgk';
        }
    } catch (Throwable $e) {
        $message = $e->getMessage();
        $messagetype = 'error';
    }
}

$selectedpl3bookid = $previewbookid ?: optional_param('pl3bookid', 0, PARAM_INT);
$existingcompetencies = pl3_service::get_by_course($courseid, $selectedpl3bookid);

$bookoptions = [0 => get_string('allbooksincourse', 'local_aisgk')];
foreach ($books as $b) {
    $bookoptions[(int)$b->id] = ($b->name ?: $b->filename) . ' #' . (int)$b->id;
}

function local_aisgk_pl3_book_select(array $bookoptions, int $selected): string {
    $html = '<select name="pl3bookid" class="local-aisgk-input local-aisgk-pl3-book-select">';
    foreach ($bookoptions as $id => $label) {
        $html .= '<option value="' . (int)$id . '"' . ((int)$id === $selected ? ' selected' : '') . '>' . s($label) . '</option>';
    }
    $html .= '</select>';
    return $html;
}

function local_aisgk_book_part_select(string $name, int $selected): string {
    $opts = [0 => 'Chọn tập', 1 => 'Tập 1 / HK1', 2 => 'Tập 2 / HK2', 3 => 'Cả năm / 1 SGK'];
    $html = '<select class="local-aisgk-input local-aisgk-bookpart local-aisgk-required-part" name="' . s($name) . '">';
    foreach ($opts as $value => $label) {
        $html .= '<option value="' . (int)$value . '"' . ((int)$selected === (int)$value ? ' selected' : '') . '>' . s($label) . '</option>';
    }
    $html .= '</select>';
    return $html;
}

function local_aisgk_render_competency_table(array $rows, int $bookid, string $mode = 'preview'): void {
    if (!$rows) {
        echo '<div class="local-aisgk-muted">' . s(get_string('nopl3rows', 'local_aisgk')) . '</div>';
        return;
    }
    $groups = pl3_service::group_rows($rows);
    echo '<div class="local-aisgk-pl3-tablewrap"><table class="local-aisgk-pl3-table local-aisgk-pl3-grouped">';
    echo '<thead><tr><th>#</th><th>' . s(get_string('orderlabel', 'local_aisgk')) . '</th><th>' . s(get_string('lessonname', 'local_aisgk')) . '</th><th>' . s(get_string('competencycode', 'local_aisgk')) . '</th><th>NB</th><th>TH</th><th>VD</th></tr></thead><tbody>';
    foreach ($groups as $i => $g) {
        $lessonorder = (int)($g['lesson_order'] ?? 0);
        $lessonname = (string)($g['lesson_name'] ?? '');
        $semester = (int)($g['semester'] ?? 0);
        $lessonperiods = (int)($g['lesson_periods'] ?? 0);
        $codes = implode(', ', array_values(array_unique(array_filter($g['codes'] ?? []))));
        $nb = implode("\n", $g['nhan_biet'] ?? []);
        $th = implode("\n", $g['thong_hieu'] ?? []);
        $vd = implode("\n", $g['van_dung'] ?? []);
        echo '<tr>';
        echo '<td>' . ($i + 1) . '</td>';
        echo '<td><input name="groups[' . $i . '][lesson_order]" value="' . s($lessonorder) . '" class="local-aisgk-input local-aisgk-small"><input type="hidden" name="groups[' . $i . '][semester]" value="' . s($semester) . '"><input type="hidden" name="groups[' . $i . '][lesson_periods]" value="' . s($lessonperiods) . '"></td>';
        echo '<td><textarea name="groups[' . $i . '][lesson_name]" class="local-aisgk-input local-aisgk-lesson" rows="3">' . s($lessonname) . '</textarea></td>';
        echo '<td><textarea class="local-aisgk-input local-aisgk-codes" rows="5" readonly>' . s($codes) . '</textarea></td>';
        echo '<td><textarea name="groups[' . $i . '][nhan_biet]" class="local-aisgk-input local-aisgk-leveltext" rows="6">' . s($nb) . '</textarea></td>';
        echo '<td><textarea name="groups[' . $i . '][thong_hieu]" class="local-aisgk-input local-aisgk-leveltext" rows="6">' . s($th) . '</textarea></td>';
        echo '<td><textarea name="groups[' . $i . '][van_dung]" class="local-aisgk-input local-aisgk-leveltext" rows="6">' . s($vd) . '</textarea></td>';
        echo '</tr>';
    }
    echo '</tbody></table></div>';
}

local_aisgk_modal_page_open($PAGE->title ?? '');
?>
<style>
.local-aisgk-upload-wrap {padding:10px; font-size:13px; width:100%; max-width:100%; box-sizing:border-box; overflow-x:hidden;}
.local-aisgk-tabs {display:flex; gap:6px; border-bottom:1px solid #cbd5e1; margin-bottom:8px;}
.local-aisgk-tab {border:1px solid #cbd5e1; border-bottom:0; border-radius:8px 8px 0 0; background:#e2e8f0; padding:7px 14px; font-weight:700; color:#334155; text-decoration:none;}
.local-aisgk-tab:hover {text-decoration:none; background:#cbd5e1; color:#0f172a;}
.local-aisgk-tab.active {background:#2563eb; color:#fff; border-color:#1d4ed8; box-shadow:0 -1px 0 #1d4ed8 inset;}
.local-aisgk-tabpanel {display:none;}
.local-aisgk-tabpanel.active {display:block;}
.local-aisgk-upload-form, .local-aisgk-existing, .local-aisgk-pl3box {border:1px solid #d0d7de; border-radius:8px; padding:8px; background:#fff; margin-bottom:8px; max-width:100%; box-sizing:border-box;}
.local-aisgk-upload-form h4, .local-aisgk-existing h4, .local-aisgk-pl3box h4 {margin:0 0 7px; font-size:15px;}
.local-aisgk-grid {display:grid; grid-template-columns: 1fr 1fr; gap:8px; align-items:end;}
.local-aisgk-grid .full {grid-column:1 / -1;}
.local-aisgk-field label {display:block; font-weight:600; margin-bottom:3px;}
.local-aisgk-input, .local-aisgk-field input[type="text"], .local-aisgk-field input[type="file"], .local-aisgk-field textarea, .local-aisgk-field select {width:100%; box-sizing:border-box; border:1px solid #cbd5e1; border-radius:7px; padding:5px 7px; min-height:32px; background:#fff;}
.local-aisgk-actions {display:flex; justify-content:flex-end; gap:8px; margin-top:8px;}
.local-aisgk-existing-tablewrap {width:100%; max-width:100%; overflow:auto; -webkit-overflow-scrolling:touch;}
.local-aisgk-pl3-tablewrap {width:100%; max-width:100%; max-height:360px; overflow:auto; -webkit-overflow-scrolling:touch; border:1px solid #e5e7eb; border-radius:7px;}
.local-aisgk-pl3-table thead th {position:sticky; top:0; z-index:2;}
.local-aisgk-pl3box .local-aisgk-help-inline {margin-top:5px; color:#64748b; font-size:12px;}
.local-aisgk-existing table, .local-aisgk-pl3-table {width:max-content; min-width:100%; border-collapse:collapse;}
.local-aisgk-existing th, .local-aisgk-existing td, .local-aisgk-pl3-table th, .local-aisgk-pl3-table td {border:1px solid #e5e7eb; padding:4px 6px; text-align:left; vertical-align:top;}
.local-aisgk-existing th, .local-aisgk-pl3-table th {background:#f8f9fa;}
.local-aisgk-small {width:62px!important; min-width:62px;}
.local-aisgk-lesson {width:230px!important; min-width:230px;}
.local-aisgk-bookname {width:180px!important; min-width:180px;}
.local-aisgk-bookmeta {width:150px!important; min-width:150px;}
.local-aisgk-bookdesc {width:220px!important; min-width:220px;}
.local-aisgk-codes {width:150px!important; min-width:150px; color:#475569; background:#f8fafc;}
.local-aisgk-leveltext {width:250px!important; min-width:250px;}
.local-aisgk-muted {color:#64748b; font-size:12px;}
.local-aisgk-help {background:#f8fafc; border:1px dashed #cbd5e1; padding:7px 9px; border-radius:8px; color:#475569; margin-bottom:8px;}
.local-aisgk-delete-cell {width:70px; text-align:center;}
.local-aisgk-delete-btn {display:inline-flex; align-items:center; justify-content:center; width:28px; height:28px; padding:0; border:1px solid #dc3545; border-radius:6px; background:#fff; color:#dc3545; font-size:17px; line-height:1; cursor:pointer;}
.local-aisgk-delete-btn:hover, .local-aisgk-delete-btn:focus {background:#fff5f5; text-decoration:none;}
.local-aisgk-dialog-backdrop{position:fixed;inset:0;z-index:10000;background:rgba(15,23,42,.28);display:flex;align-items:center;justify-content:center;padding:18px}.local-aisgk-dialog{background:#fff;border-radius:12px;box-shadow:0 12px 36px rgba(15,23,42,.28);max-width:520px;width:min(520px,100%);border:1px solid #cbd5e1}.local-aisgk-dialog-title{font-weight:700;padding:12px 16px;border-bottom:1px solid #e2e8f0}.local-aisgk-dialog-body{padding:14px 16px;white-space:pre-wrap;max-height:50vh;overflow:auto}.local-aisgk-dialog-actions{display:flex;justify-content:flex-end;gap:8px;padding:10px 16px;border-top:1px solid #e2e8f0}

.local-aisgk-sgkbox {padding:7px;}
.local-aisgk-sgk-tablewrap {max-height:310px; overflow:auto; border:1px solid #e5e7eb; border-radius:7px;}
.local-aisgk-sgk-table thead th {position:sticky; top:0; z-index:2; background:#f8fafc;}
.local-aisgk-sgk-table th, .local-aisgk-sgk-table td {white-space:nowrap;}
.local-aisgk-add-col, .local-aisgk-upload-col {text-align:center; width:54px; min-width:54px;}
.local-aisgk-add-row-btn {display:inline-flex; align-items:center; justify-content:center; width:28px; height:28px; padding:0; border:1px solid #2563eb; border-radius:6px; background:#eff6ff; color:#1d4ed8; font-weight:800; cursor:pointer;}
.local-aisgk-add-row-btn:hover {background:#dbeafe;}
.local-aisgk-up-btn {padding:3px 8px; min-height:28px;}
.local-aisgk-filename-cell {max-width:170px; min-width:130px; white-space:normal!important; word-break:break-word;}
.local-aisgk-bookname {width:155px!important; min-width:155px;}
.local-aisgk-bookmeta {width:130px!important; min-width:130px;}
.local-aisgk-bookdesc {width:180px!important; min-width:180px;}
.local-aisgk-lesson {width:145px!important; min-width:145px; white-space:normal; resize:vertical; line-height:1.25;}
.local-aisgk-pl3-tablewrap {max-height:330px;}

@media (max-width: 768px) {.local-aisgk-grid {grid-template-columns:1fr;} .local-aisgk-actions {justify-content:stretch; flex-direction:column;} }

.local-aisgk-pl3-titlebar {display:flex; align-items:center; justify-content:space-between; gap:10px; margin:0 0 8px;}
.local-aisgk-pl3-titlebar h4 {margin:0; font-size:15px;}
.local-aisgk-pl3-upload-form {margin:0; display:flex; align-items:center; gap:6px;}
.local-aisgk-hidden-file {display:none !important;}
.local-aisgk-pl3-saved-form {margin-top:0;}
</style>
<div class="local-aisgk-upload-wrap">
    <?php if ($message !== ''): ?>
        <div class="local-aisgk-upload-error" data-type="<?php echo s($messagetype); ?>" data-message="<?php echo s($message); ?>"></div>
    <?php endif; ?>

    <div class="local-aisgk-tabs" role="tablist">
        <a href="#" class="local-aisgk-tab <?php echo $activeTab === 'sgk' ? 'active' : ''; ?>" data-tab="sgk"><?php echo s(get_string('sgktab', 'local_aisgk')); ?></a>
        <a href="#" class="local-aisgk-tab <?php echo $activeTab === 'pl3' ? 'active' : ''; ?>" data-tab="pl3"><?php echo s(get_string('pl3tab', 'local_aisgk')); ?></a>
    </div>

    <div class="local-aisgk-tabpanel <?php echo $activeTab === 'sgk' ? 'active' : ''; ?>" id="local-aisgk-tab-sgk">
        <div class="local-aisgk-existing local-aisgk-sgkbox">
            <h4><?php echo s(get_string('sgktab', 'local_aisgk')); ?></h4>
            <form method="post" enctype="multipart/form-data" class="local-aisgk-books-form">
                <input type="hidden" name="sesskey" value="<?php echo sesskey(); ?>">
                <input type="hidden" name="action" value="savebooks" class="local-aisgk-books-action">
                <input type="hidden" name="tab" value="sgk">
                <input type="hidden" name="uploadrowkey" value="" class="local-aisgk-upload-rowkey">
                <input type="file" name="bookpdf" accept=".pdf,application/pdf" class="local-aisgk-row-file" style="display:none">
                <div class="local-aisgk-existing-tablewrap local-aisgk-sgk-tablewrap"><table class="local-aisgk-sgk-table">
                    <thead><tr>
                        <th>#</th>
                        <th class="local-aisgk-add-col">+</th>
                        <th class="local-aisgk-upload-col"><?php echo s(get_string('uploadlabel', 'local_aisgk')); ?></th>
                        <th><?php echo s(get_string('filename', 'local_aisgk')); ?></th>
                        <th><?php echo s(get_string('bookname', 'local_aisgk')); ?></th>
                        <th><?php echo s(get_string('bookpart', 'local_aisgk')); ?></th>
                        <th><?php echo s(get_string('bookseries', 'local_aisgk')); ?></th>
                        <th><?php echo s(get_string('publisher', 'local_aisgk')); ?></th>
                        <th><?php echo s(get_string('bookdescription', 'local_aisgk')); ?></th>
                        <th class="local-aisgk-delete-cell"><?php echo s(get_string('delete', 'core')); ?></th>
                    </tr></thead>
                    <tbody class="local-aisgk-sgk-tbody">
                    <?php foreach ($books as $idx => $book): $rowkey = 'book_' . (int)$book->id; ?>
                        <tr class="local-aisgk-sgk-row" data-rowkey="<?php echo s($rowkey); ?>">
                            <td class="local-aisgk-row-no"><?php echo $idx + 1; ?><input type="hidden" name="books[<?php echo s($rowkey); ?>][id]" value="<?php echo (int)$book->id; ?>"></td>
                            <td class="local-aisgk-add-col"><button type="button" class="local-aisgk-add-row-btn" title="Thêm dòng">+</button></td>
                            <td class="local-aisgk-upload-col"><button type="button" class="btn btn-secondary btn-sm local-aisgk-up-btn">Up</button></td>
                            <td class="local-aisgk-filename-cell"><?php echo s($book->filename); ?></td>
                            <td><input class="local-aisgk-input local-aisgk-bookname" name="books[<?php echo s($rowkey); ?>][name]" value="<?php echo s($book->name ?: $book->filename); ?>" placeholder="Tên sách"></td>
                            <td><?php echo local_aisgk_book_part_select('books[' . $rowkey . '][book_part]', (int)($book->book_part ?? 0)); ?></td>
                            <td><input class="local-aisgk-input local-aisgk-bookmeta local-aisgk-required-series" name="books[<?php echo s($rowkey); ?>][bookseries]" value="<?php echo s($book->bookseries ?? ''); ?>" placeholder="Bộ sách"></td>
                            <td><input class="local-aisgk-input local-aisgk-bookmeta" name="books[<?php echo s($rowkey); ?>][publisher]" value="<?php echo s($book->publisher ?? ''); ?>" placeholder="NXB"></td>
                            <td><input class="local-aisgk-input local-aisgk-bookdesc" name="books[<?php echo s($rowkey); ?>][description]" value="<?php echo s($book->description ?? ''); ?>" placeholder="Ghi chú"></td>
                            <td class="local-aisgk-delete-cell"><button type="submit" name="deletebookid" value="<?php echo (int)$book->id; ?>" class="local-aisgk-delete-btn" data-confirm="<?php echo s(get_string('confirmdeletebook', 'local_aisgk')); ?>" title="<?php echo s(get_string('deletebook', 'local_aisgk')); ?>" aria-label="<?php echo s(get_string('deletebook', 'local_aisgk')); ?>">×</button></td>
                        </tr>
                    <?php endforeach; ?>
                    <?php $newkey = 'new_' . time(); ?>
                        <tr class="local-aisgk-sgk-row local-aisgk-new-row" data-rowkey="<?php echo s($newkey); ?>">
                            <td class="local-aisgk-row-no"><?php echo count($books) + 1; ?><input type="hidden" name="books[<?php echo s($newkey); ?>][id]" value="0"></td>
                            <td class="local-aisgk-add-col"><button type="button" class="local-aisgk-add-row-btn" title="Thêm dòng">+</button></td>
                            <td class="local-aisgk-upload-col"><button type="button" class="btn btn-secondary btn-sm local-aisgk-up-btn">Up</button></td>
                            <td class="local-aisgk-filename-cell local-aisgk-muted">Chưa upload</td>
                            <td><input class="local-aisgk-input local-aisgk-bookname" name="books[<?php echo s($newkey); ?>][name]" value="" placeholder="Tên sách"></td>
                            <td><?php echo local_aisgk_book_part_select('books[' . $newkey . '][book_part]', 0); ?></td>
                            <td><input class="local-aisgk-input local-aisgk-bookmeta local-aisgk-required-series" name="books[<?php echo s($newkey); ?>][bookseries]" value="" placeholder="Bộ sách"></td>
                            <td><input class="local-aisgk-input local-aisgk-bookmeta" name="books[<?php echo s($newkey); ?>][publisher]" value="" placeholder="NXB"></td>
                            <td><input class="local-aisgk-input local-aisgk-bookdesc" name="books[<?php echo s($newkey); ?>][description]" value="" placeholder="Ghi chú"></td>
                            <td class="local-aisgk-delete-cell"><button type="button" class="local-aisgk-delete-btn local-aisgk-remove-new-row" title="Xóa dòng" aria-label="Xóa dòng">×</button></td>
                        </tr>
                    </tbody>
                </table></div>
                <div class="local-aisgk-actions"><button type="submit" class="btn btn-primary"><?php echo s(get_string('savechanges', 'core')); ?></button></div>
            </form>
        </div>
    </div>

    <div class="local-aisgk-tabpanel <?php echo $activeTab === 'pl3' ? 'active' : ''; ?>" id="local-aisgk-tab-pl3">
        <?php $pl3tooltip = get_string('pl3uptooltip', 'local_aisgk'); ?>
        <div class="local-aisgk-pl3-titlebar">
            <h4><?php echo s(get_string('currentpl3', 'local_aisgk')); ?></h4>
            <form class="local-aisgk-pl3-upload-form" method="post" enctype="multipart/form-data">
                <input type="hidden" name="sesskey" value="<?php echo sesskey(); ?>">
                <input type="hidden" name="action" value="previewpl3">
                <input type="hidden" name="tab" value="pl3">
                <input type="hidden" name="pl3bookid" value="0">
                <input type="file" id="id_pl3file" name="pl3file" class="local-aisgk-hidden-file" accept=".doc,.docx,application/msword,application/vnd.openxmlformats-officedocument.wordprocessingml.document" required>
                <button type="button" class="btn btn-secondary btn-sm local-aisgk-up-pl3-btn" title="<?php echo s($pl3tooltip); ?>"><?php echo s(get_string('uppl3', 'local_aisgk')); ?></button>
            </form>
            <form class="local-aisgk-pl3-delete-form" method="post">
                <input type="hidden" name="sesskey" value="<?php echo sesskey(); ?>">
                <input type="hidden" name="action" value="deletepl3">
                <input type="hidden" name="tab" value="pl3">
                <input type="hidden" name="pl3bookid" value="<?php echo (int)$selectedpl3bookid; ?>">
                <button type="submit" class="btn btn-danger btn-sm local-aisgk-delete-pl3-btn"><?php echo s(get_string('deletepl3', 'local_aisgk')); ?></button>
            </form>
        </div>

        <?php if ($previewrows): ?>
            <form class="local-aisgk-pl3box" method="post">
                <input type="hidden" name="sesskey" value="<?php echo sesskey(); ?>">
                <input type="hidden" name="action" value="savepl3">
                <input type="hidden" name="tab" value="pl3">
                <input type="hidden" name="pl3bookid" value="<?php echo (int)$previewbookid; ?>">
                <h4><?php echo s(get_string('pl3preview', 'local_aisgk')); ?></h4>
                <?php local_aisgk_render_competency_table($previewrows, $previewbookid, 'preview'); ?>
                <div class="local-aisgk-actions"><button type="submit" class="btn btn-primary"><?php echo s(get_string('savepl3', 'local_aisgk')); ?></button></div>
            </form>
        <?php endif; ?>

        <form class="local-aisgk-pl3box local-aisgk-pl3-saved-form" method="post">
            <input type="hidden" name="sesskey" value="<?php echo sesskey(); ?>">
            <input type="hidden" name="action" value="savepl3">
            <input type="hidden" name="tab" value="pl3">
            <input type="hidden" name="pl3bookid" value="<?php echo (int)$selectedpl3bookid; ?>">
            <?php local_aisgk_render_competency_table($existingcompetencies, $selectedpl3bookid, 'existing'); ?>
            <?php if ($existingcompetencies): ?>
                <div class="local-aisgk-actions"><button type="submit" class="btn btn-primary"><?php echo s(get_string('savechanges', 'core')); ?></button></div>
            <?php endif; ?>
        </form>
    </div>
</div>
<script>
(function(){
    function localAisgkDialog(options) {
        options = options || {};
        return new Promise(function(resolve) {
            try {
                var old = document.querySelector('.local-aisgk-dialog-backdrop');
                if (old) { old.remove(); }
                var mode = options.mode || 'message';
                var backdrop = document.createElement('div');
                backdrop.className = 'local-aisgk-dialog-backdrop';
                var box = document.createElement('div');
                box.className = 'local-aisgk-dialog local-aisgk-dialog-' + mode;
                var title = document.createElement('div');
                title.className = 'local-aisgk-dialog-title';
                title.textContent = options.title || (mode === 'confirm' ? 'Xác nhận' : 'Thông báo');
                var body = document.createElement('div');
                body.className = 'local-aisgk-dialog-body';
                body.textContent = String(options.message || '');
                var actions = document.createElement('div');
                actions.className = 'local-aisgk-dialog-actions';
                if (mode === 'confirm') {
                    var cancel = document.createElement('button');
                    cancel.type = 'button'; cancel.className = 'btn btn-secondary'; cancel.textContent = options.cancelText || 'Hủy';
                    cancel.onclick = function(){ backdrop.remove(); resolve(false); };
                    var ok = document.createElement('button');
                    ok.type = 'button'; ok.className = 'btn btn-danger'; ok.textContent = options.okText || 'Đồng ý';
                    ok.onclick = function(){ backdrop.remove(); resolve(true); };
                    actions.appendChild(cancel); actions.appendChild(ok);
                } else {
                    var close = document.createElement('button');
                    close.type = 'button'; close.className = 'btn btn-primary'; close.textContent = options.okText || 'OK';
                    close.onclick = function(){ backdrop.remove(); resolve(true); };
                    actions.appendChild(close);
                }
                box.appendChild(title); box.appendChild(body); box.appendChild(actions); backdrop.appendChild(box); document.body.appendChild(backdrop);
            } catch(e) {
                if ((options.mode || 'message') === 'confirm') { resolve(window.confirm(options.message || '')); }
                else { try { window.alert(options.message || ''); } catch(_e) {} resolve(true); }
            }
        });
    }
    window.localAisgkMsgBox = window.localAisgkMsgBox || function(msg, type){ return localAisgkDialog({mode:'message', message:msg, title:(type === 'err' ? 'Lỗi' : 'Thông báo')}); };
    window.localAisgkConfirm = window.localAisgkConfirm || function(msg, title){ return localAisgkDialog({mode:'confirm', message:msg, title:title || 'Xác nhận', okText:'Tiếp tục', cancelText:'Hủy'}); };
    var err = document.querySelector('.local-aisgk-upload-error');
    if (err && err.getAttribute('data-message')) { window.localAisgkMsgBox(err.getAttribute('data-message'), err.getAttribute('data-type') === 'error' ? 'err' : 'ok'); }
    const tabs = document.querySelectorAll('.local-aisgk-tab');
    const panels = {sgk: document.getElementById('local-aisgk-tab-sgk'), pl3: document.getElementById('local-aisgk-tab-pl3')};
    tabs.forEach(tab => tab.addEventListener('click', function(e){
        e.preventDefault();
        const key = this.getAttribute('data-tab');
        tabs.forEach(t => t.classList.toggle('active', t === this));
        Object.keys(panels).forEach(k => panels[k].classList.toggle('active', k === key));
    }));

    document.querySelectorAll('.local-aisgk-pl3-upload-form').forEach(function(form){
        var input = form.querySelector('input[type="file"]');
        var btn = form.querySelector('.local-aisgk-up-pl3-btn');
        if (btn && input) {
            btn.addEventListener('click', function(){ input.click(); });
        }
        if (input) {
            input.addEventListener('change', function(){
                if (input.files && input.files.length) {
                    form.submit();
                }
            });
        }
    });
    document.querySelectorAll('.local-aisgk-pl3-delete-form').forEach(function(form){
        form.addEventListener('submit', function(e){
            e.preventDefault();
            var msg = <?php echo json_encode(get_string('deletepl3confirm', 'local_aisgk')); ?>;
            window.localAisgkConfirm(msg, <?php echo json_encode(get_string('deletepl3', 'local_aisgk')); ?>).then(function(ok){
                if (ok) { form.submit(); }
            });
        });
    });

    var booksForm = document.querySelector('.local-aisgk-books-form');
    var sgkTbody = document.querySelector('.local-aisgk-sgk-tbody');
    var rowFile = booksForm ? booksForm.querySelector('.local-aisgk-row-file') : null;
    var currentUploadRow = null;
    function renumberSgkRows(){
        if (!sgkTbody) { return; }
        sgkTbody.querySelectorAll('.local-aisgk-sgk-row').forEach(function(row, i){
            var cell = row.querySelector('.local-aisgk-row-no');
            if (cell && cell.firstChild) { cell.firstChild.nodeValue = String(i + 1); }
        });
    }
    function makeNewSgkRow(){
        var key = 'new_' + Date.now() + '_' + Math.floor(Math.random() * 10000);
        var tr = document.createElement('tr');
        tr.className = 'local-aisgk-sgk-row local-aisgk-new-row';
        tr.setAttribute('data-rowkey', key);
        tr.innerHTML = '<td class="local-aisgk-row-no">0<input type="hidden" name="books[' + key + '][id]" value="0"></td>' +
            '<td class="local-aisgk-add-col"><button type="button" class="local-aisgk-add-row-btn" title="Thêm dòng">+</button></td>' +
            '<td class="local-aisgk-upload-col"><button type="button" class="btn btn-secondary btn-sm local-aisgk-up-btn">Up</button></td>' +
            '<td class="local-aisgk-filename-cell local-aisgk-muted">Chưa upload</td>' +
            '<td><input class="local-aisgk-input local-aisgk-bookname" name="books[' + key + '][name]" value="" placeholder="Tên sách"></td>' +
            '<td><select class="local-aisgk-input local-aisgk-bookpart local-aisgk-required-part" name="books[' + key + '][book_part]"><option value="0">Chọn tập</option><option value="1">Tập 1 / HK1</option><option value="2">Tập 2 / HK2</option><option value="3">Cả năm / 1 SGK</option></select></td>' +
            '<td><input class="local-aisgk-input local-aisgk-bookmeta local-aisgk-required-series" name="books[' + key + '][bookseries]" value="" placeholder="Bộ sách"></td>' +
            '<td><input class="local-aisgk-input local-aisgk-bookmeta" name="books[' + key + '][publisher]" value="" placeholder="NXB"></td>' +
            '<td><input class="local-aisgk-input local-aisgk-bookdesc" name="books[' + key + '][description]" value="" placeholder="Ghi chú"></td>' +
            '<td class="local-aisgk-delete-cell"><button type="button" class="local-aisgk-delete-btn local-aisgk-remove-new-row" title="Xóa dòng" aria-label="Xóa dòng">×</button></td>';
        return tr;
    }
    if (sgkTbody) {
        sgkTbody.addEventListener('click', function(e){
            var add = e.target.closest('.local-aisgk-add-row-btn');
            if (add) {
                e.preventDefault();
                var row = add.closest('.local-aisgk-sgk-row');
                var newrow = makeNewSgkRow();
                if (row && row.nextSibling) { sgkTbody.insertBefore(newrow, row.nextSibling); }
                else { sgkTbody.appendChild(newrow); }
                renumberSgkRows();
                return;
            }
            var remove = e.target.closest('.local-aisgk-remove-new-row');
            if (remove) {
                e.preventDefault();
                var r = remove.closest('.local-aisgk-sgk-row');
                if (r) { r.remove(); renumberSgkRows(); }
                return;
            }
            var up = e.target.closest('.local-aisgk-up-btn');
            if (up) {
                e.preventDefault();
                var urow = up.closest('.local-aisgk-sgk-row');
                if (!urow || !booksForm || !rowFile) { return; }
                var name = (urow.querySelector('.local-aisgk-bookname') || {}).value || '';
                var series = (urow.querySelector('.local-aisgk-required-series') || {}).value || '';
                var part = (urow.querySelector('.local-aisgk-required-part') || {}).value || '0';
                if (!name.trim() || !series.trim() || part === '0') {
                    window.localAisgkMsgBox('Vui lòng nhập đủ Tên sách và Bộ sách trước khi upload file SGK.', 'err');
                    return;
                }
                currentUploadRow = urow.getAttribute('data-rowkey') || '';
                rowFile.value = '';
                rowFile.click();
            }
        });
    }
    if (rowFile && booksForm) {
        rowFile.addEventListener('change', function(){
            if (rowFile.files && rowFile.files.length && currentUploadRow) {
                var action = booksForm.querySelector('.local-aisgk-books-action');
                var key = booksForm.querySelector('.local-aisgk-upload-rowkey');
                if (action) { action.value = 'uploadrow'; }
                if (key) { key.value = currentUploadRow; }
                booksForm.submit();
            }
        });
        booksForm.addEventListener('submit', function(e){
            var action = booksForm.querySelector('.local-aisgk-books-action');
            if (action && action.value !== 'uploadrow') { action.value = 'savebooks'; }
        });
    }
    document.querySelectorAll('.local-aisgk-delete-btn[data-confirm]').forEach(function(btn){
        btn.addEventListener('click', function(e){
            e.preventDefault();
            const form = btn.closest('form');
            const msg = btn.getAttribute('data-confirm') || 'Delete?';
            window.localAisgkConfirm(msg, 'Xác nhận').then(function(ok){
                if (ok && form) {
                    var hidden = document.createElement('input');
                    hidden.type = 'hidden'; hidden.name = btn.name; hidden.value = btn.value;
                    form.appendChild(hidden); form.submit();
                }
            });
        });
    });
})();
</script>
<?php
local_aisgk_modal_page_close();
