<?php
require('../../config.php');

use local_aisgk\book_repository;
use local_aisgk\local\service\book_service;

$courseid = optional_param('id', 0, PARAM_INT);
if (!$courseid) {
    throw new moodle_exception(
        'missingcourseid',
        'local_aisgk',
        '',
        null,
        'Thiếu id khóa học. Hãy mở popup Tải SGK từ đúng trang khóa học.'
    );
}

$course = get_course($courseid);
require_login($course);

$context = context_course::instance($courseid);
require_capability('local/aisgk:managebooks', $context);

$PAGE->set_context($context);
$PAGE->set_url('/local/aisgk/upload.php', ['id' => $courseid]);
$PAGE->set_pagelayout('embedded');
$PAGE->set_title(get_string('uploadbook', 'local_aisgk'));

$repo = new book_repository();
$books = $repo->get_all_by_courseid($courseid);

$message = '';
$messagetype = 'success';

if ($_SERVER['REQUEST_METHOD'] === 'POST' && confirm_sesskey()) {
    $bookname = trim(optional_param('bookname', '', PARAM_TEXT));

    if (empty($_FILES['bookpdf']) || empty($_FILES['bookpdf']['name'])) {
        $message = get_string('nofile', 'local_aisgk');
        $messagetype = 'error';
    } else {
        $uploadedfile = $_FILES['bookpdf'];

        $ext = strtolower(pathinfo($uploadedfile['name'], PATHINFO_EXTENSION));
        if ($ext !== 'pdf') {
            $message = get_string('onlypdfallowed', 'local_aisgk');
            $messagetype = 'error';
        } else if (!empty($uploadedfile['error']) && (int)$uploadedfile['error'] !== UPLOAD_ERR_OK) {
            $message = get_string('uploaderrorserver', 'local_aisgk', $uploadedfile['error']);
            $messagetype = 'error';
        } else {
            try {
                book_service::save_uploaded_book($courseid, $uploadedfile, $bookname);
                $message = get_string('bookuploaded', 'local_aisgk');
                $messagetype = 'success';
                $books = $repo->get_all_by_courseid($courseid);
            } catch (Throwable $e) {
                $message = $e->getMessage();
                $messagetype = 'error';
            }
        }
    }
}

echo $OUTPUT->header();
?>
<style>
.local-aisgk-upload-wrap {
    padding: 12px;
}
.local-aisgk-upload-form {
    border: 1px solid #d0d7de;
    border-radius: 8px;
    padding: 12px;
    background: #fff;
    margin-bottom: 14px;
}
.local-aisgk-upload-form .frow {
    margin-bottom: 10px;
}
.local-aisgk-upload-form label {
    display: block;
    font-weight: 600;
    margin-bottom: 4px;
}
.local-aisgk-upload-form input[type="text"],
.local-aisgk-upload-form input[type="file"] {
    width: 100%;
    max-width: 100%;
    box-sizing: border-box;
}
.local-aisgk-upload-form input[type="text"] {
    height: 34px;
    padding: 6px 8px;
}
.local-aisgk-upload-form .actions {
    margin-top: 10px;
}
.local-aisgk-upload-form .btn {
    min-height: 34px;
}
.local-aisgk-existing {
    border: 1px solid #d0d7de;
    border-radius: 8px;
    padding: 12px;
    background: #fff;
}
.local-aisgk-existing h4 {
    margin: 0 0 10px 0;
    font-size: 16px;
}
.local-aisgk-existing table {
    width: 100%;
    border-collapse: collapse;
}
.local-aisgk-existing th,
.local-aisgk-existing td {
    border: 1px solid #e5e7eb;
    padding: 6px 8px;
    text-align: left;
    vertical-align: top;
    font-size: 13px;
}
.local-aisgk-existing th {
    background: #f8f9fa;
}
.local-aisgk-note {
    font-size: 12px;
    color: #555;
    margin-top: 6px;
}
.local-aisgk-msg {
    margin-bottom: 12px;
}
</style>

<div class="local-aisgk-upload-wrap">
    <?php if ($message !== ''): ?>
        <div class="alert alert-<?php echo $messagetype === 'success' ? 'success' : 'danger'; ?> local-aisgk-msg">
            <?php echo s($message); ?>
        </div>
    <?php endif; ?>

    <form class="local-aisgk-upload-form" method="post" enctype="multipart/form-data">
        <input type="hidden" name="id" value="<?php echo (int)$courseid; ?>">
        <input type="hidden" name="sesskey" value="<?php echo sesskey(); ?>">

        <div class="frow">
            <label for="id_bookname"><?php echo get_string('bookname', 'local_aisgk'); ?></label>
            <input type="text" id="id_bookname" name="bookname" placeholder="<?php echo s(get_string('booknameplaceholder', 'local_aisgk')); ?>">
        </div>

        <div class="frow">
            <label for="id_bookpdf"><?php echo get_string('uploadbook', 'local_aisgk'); ?></label>
            <input type="file" id="id_bookpdf" name="bookpdf" accept=".pdf,application/pdf" required>
            <div class="local-aisgk-note"><?php echo s(get_string('uploadlimitnote', 'local_aisgk')); ?></div>
        </div>

        <div class="actions">
            <button type="submit" class="btn btn-primary"><?php echo get_string('uploadbook', 'local_aisgk'); ?></button>
        </div>
    </form>

    <div class="local-aisgk-existing">
        <h4><?php echo s(get_string('existingbooks', 'local_aisgk')); ?></h4>

        <?php if (empty($books)): ?>
            <div><?php echo s(get_string('nobooksincourse', 'local_aisgk')); ?></div>
        <?php else: ?>
            <table>
                <thead>
                    <tr>
                        <th style="width:56px;">#</th>
                        <th><?php echo s(get_string('bookname', 'local_aisgk')); ?></th>
                        <th><?php echo s(get_string('filename', 'local_aisgk')); ?></th>
                        <th style="width:110px;"><?php echo s(get_string('tocfrompage', 'local_aisgk')); ?></th>
                        <th style="width:110px;"><?php echo s(get_string('toctopage', 'local_aisgk')); ?></th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach ($books as $idx => $book): ?>
                        <tr>
                            <td><?php echo (int)($idx + 1); ?></td>
                            <td><?php echo s($book->name ?: $book->filename); ?></td>
                            <td><?php echo s($book->filename); ?></td>
                            <td><?php echo (int)$book->tocfrompage; ?></td>
                            <td><?php echo (int)$book->toctopage; ?></td>
                        </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        <?php endif; ?>
    </div>
</div>

<?php
echo $OUTPUT->footer();
