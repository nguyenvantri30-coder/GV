<?php
require_once(__DIR__ . '/../../config.php');

$context = context_system::instance();
$PAGE->set_context($context);
require_login();
require_capability('moodle/site:config', $context);

require_once($CFG->libdir . '/adminlib.php');

use local_aisgk\local\service\school_year_backup_service;

$action = optional_param('action', '', PARAM_ALPHAEXT);
$message = '';
$error = '';
$summary = null;

if ($action === 'resetall' && confirm_sesskey()) {
    try {
        $summary = school_year_backup_service::execute_total_test_reset_keep_api_core();
        $message = get_string('resetalldone', 'local_aisgk', (object)[
            'tables' => count($summary['cleared_tables'] ?? []),
            'files' => (int)($summary['deleted_files'] ?? 0),
        ]);
    } catch (Throwable $e) {
        $error = $e->getMessage();
    }
}

$PAGE->set_url(new moodle_url('/local/aisgk/year_reset_all.php'));
$PAGE->set_title(get_string('resetalltitle', 'local_aisgk'));
$PAGE->set_heading(get_string('resetalltitle', 'local_aisgk'));
$PAGE->set_pagelayout('standard');

echo $OUTPUT->header();
if ($message) {
    echo $OUTPUT->notification($message, 'notifysuccess');
}
if ($error) {
    echo $OUTPUT->notification($error, 'notifyproblem');
}

$style = '.aisgk-reset-wrap{max-width:980px}.aisgk-reset-grid{display:grid;grid-template-columns:1fr;gap:10px}.aisgk-reset-box{border:1px solid #d1d5db;border-radius:10px;padding:12px;background:#fff}.aisgk-reset-box h3{font-size:1rem;margin:0 0 8px}.aisgk-reset-list{margin:0;padding-left:18px}.aisgk-reset-line{border:0;border-top:2px solid #111;margin:12px 0}.aisgk-danger-note{font-weight:600;color:#991b1b}.aisgk-summary{font-size:.92rem;max-height:220px;overflow:auto;background:#f8fafc;border:1px solid #e5e7eb;border-radius:8px;padding:8px}';
echo html_writer::tag('style', $style);

echo html_writer::start_tag('div', ['class' => 'aisgk-reset-wrap']);
echo html_writer::tag('p', get_string('resetallshortdesc', 'local_aisgk'), ['class' => 'aisgk-danger-note']);

echo html_writer::start_tag('div', ['class' => 'aisgk-reset-grid']);

echo html_writer::start_tag('div', ['class' => 'aisgk-reset-box']);
echo html_writer::tag('h3', get_string('resetallgroupmoodle', 'local_aisgk'));
echo html_writer::alist([
    get_string('resetallmoodlecourses', 'local_aisgk'),
    get_string('resetallmoodlelearning', 'local_aisgk'),
    get_string('resetallmoodlefiles', 'local_aisgk'),
], ['class' => 'aisgk-reset-list']);
echo html_writer::end_tag('div');

echo html_writer::empty_tag('hr', ['class' => 'aisgk-reset-line']);

echo html_writer::start_tag('div', ['class' => 'aisgk-reset-box']);
echo html_writer::tag('h3', get_string('resetallgroupalsm', 'local_aisgk'));
echo html_writer::alist([
    get_string('resetallalsmdata', 'local_aisgk'),
    get_string('resetallalsmcache', 'local_aisgk'),
    get_string('resetallschoolyearrecords', 'local_aisgk'),
], ['class' => 'aisgk-reset-list']);
echo html_writer::end_tag('div');

echo html_writer::empty_tag('hr', ['class' => 'aisgk-reset-line']);

echo html_writer::start_tag('div', ['class' => 'aisgk-reset-box']);
echo html_writer::tag('h3', get_string('resetallgroupprotected', 'local_aisgk'));
echo html_writer::alist([
    get_string('resetallkeepapikeys', 'local_aisgk'),
    get_string('resetallkeepcore', 'local_aisgk'),
], ['class' => 'aisgk-reset-list']);
echo html_writer::end_tag('div');

echo html_writer::end_tag('div');

echo html_writer::start_tag('form', ['method' => 'post', 'action' => $PAGE->url->out(false), 'class' => 'mt-3', 'onsubmit' => "return confirm('Xóa dữ liệu Moodle + ALSM + moodledata dùng cho test. Không xóa bảng. Tiếp tục?');"]);
echo html_writer::empty_tag('input', ['type' => 'hidden', 'name' => 'sesskey', 'value' => sesskey()]);
echo html_writer::empty_tag('input', ['type' => 'hidden', 'name' => 'action', 'value' => 'resetall']);
echo html_writer::tag('button', get_string('resetallbutton', 'local_aisgk'), ['type' => 'submit', 'class' => 'btn btn-danger']);
echo ' ' . html_writer::link(new moodle_url('/local/aisgk/index.php'), get_string('back'), ['class' => 'btn btn-secondary']);
echo html_writer::end_tag('form');

if ($summary) {
    echo html_writer::tag('h3', get_string('resetallsummary', 'local_aisgk'), ['class' => 'h5 mt-3']);
    $lines = [];
    $lines[] = 'deleted_courses: ' . (int)($summary['deleted_courses'] ?? 0);
    $lines[] = 'cleared_tables: ' . count($summary['cleared_tables'] ?? []);
    $lines[] = 'deleted_files: ' . (int)($summary['deleted_files'] ?? 0);
    if (!empty($summary['skipped_tables'])) {
        $lines[] = 'skipped: ' . implode(', ', array_slice($summary['skipped_tables'], 0, 80));
    }
    echo html_writer::tag('pre', s(implode("\n", $lines)), ['class' => 'aisgk-summary']);
}

echo html_writer::end_tag('div');
echo $OUTPUT->footer();
