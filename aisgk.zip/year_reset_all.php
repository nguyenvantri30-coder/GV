<?php
require_once(__DIR__ . '/../../config.php');

$context = context_system::instance();
$PAGE->set_context($context);
require_login();
require_capability('moodle/site:config', $context);

use local_aisgk\local\service\school_year_backup_service;

$action = optional_param('action', '', PARAM_ALPHAEXT);

if ($action === 'resetall' && confirm_sesskey()) {
    @ignore_user_abort(true);
    @set_time_limit(0);
    try {
        $summary = school_year_backup_service::execute_total_test_reset_delete_all_data();
        $tables = count($summary['cleared_tables'] ?? []);
        $files = (int)($summary['deleted_files'] ?? 0);
        $skipped = count($summary['skipped_tables'] ?? []);
        header('Content-Type: text/html; charset=utf-8');
        echo '<!doctype html><html><head><meta charset="utf-8"><title>Reset toàn bộ</title>';
        echo '<style>body{font-family:Arial,sans-serif;margin:28px;line-height:1.45}.box{max-width:620px;border:1px solid #ddd;border-radius:10px;padding:16px}.ok{color:#166534;font-weight:700}.warn{color:#991b1b}.muted{color:#666}</style>';
        echo '</head><body><div class="box"><div class="ok">Đã reset toàn bộ.</div>';
        echo '<p>Đã xóa dữ liệu trong <b>' . (int)$tables . '</b> bảng và <b>' . (int)$files . '</b> file/thư mục. Không xóa cấu trúc bảng.</p>';
        if ($skipped > 0) {
            echo '<p class="warn">Có ' . (int)$skipped . ' bảng không xóa được. Xem log server để kiểm tra.</p>';
        }
        echo '<p class="muted">Sau reset, cần khởi tạo/cấu hình lại dữ liệu nền nếu Moodle yêu cầu.</p>';
        echo '</div></body></html>';
    } catch (Throwable $e) {
        header('Content-Type: text/html; charset=utf-8');
        echo '<!doctype html><html><head><meta charset="utf-8"><title>Reset lỗi</title></head><body>';
        echo '<h3>Reset lỗi</h3><pre>' . s($e->getMessage()) . '</pre></body></html>';
    }
    exit;
}

$PAGE->set_url(new moodle_url('/local/aisgk/year_reset_all.php'));
$PAGE->set_title('Reset toàn bộ');
$PAGE->set_heading('Reset toàn bộ');
$PAGE->set_pagelayout('standard');

echo $OUTPUT->header();

$style = '.aisgk-msg-mask{position:fixed;inset:0;background:rgba(15,23,42,.48);display:flex;align-items:center;justify-content:center;z-index:250000;padding:16px}.aisgk-msgbox{width:min(440px,94vw);background:#fff;border-radius:12px;border:1px solid #e5e7eb;box-shadow:0 20px 55px rgba(15,23,42,.28);overflow:hidden}.aisgk-msg-hd{padding:11px 14px;border-bottom:1px solid #e5e7eb;font-weight:700}.aisgk-msg-bd{padding:14px;line-height:1.45}.aisgk-danger{color:#991b1b;font-weight:700}.aisgk-msg-ft{padding:11px 14px;border-top:1px solid #e5e7eb;display:flex;justify-content:flex-end;gap:8px;background:#f8fafc}';
echo html_writer::tag('style', $style);

echo html_writer::start_tag('form', ['id' => 'aisgk-reset-form', 'method' => 'post', 'action' => $PAGE->url->out(false)]);
echo html_writer::empty_tag('input', ['type' => 'hidden', 'name' => 'sesskey', 'value' => sesskey()]);
echo html_writer::empty_tag('input', ['type' => 'hidden', 'name' => 'action', 'value' => 'resetall']);
echo html_writer::end_tag('form');

echo '<div class="aisgk-msg-mask" id="aisgk-reset-mask"><div class="aisgk-msgbox" role="dialog" aria-modal="true"><div class="aisgk-msg-hd">Xác nhận reset toàn bộ</div><div class="aisgk-msg-bd"><p class="aisgk-danger">Xóa sạch dữ liệu Moodle + ALSM + moodledata.</p><p>Không xóa cấu trúc bảng. Thao tác này không thể hoàn tác nếu chưa có backup.</p></div><div class="aisgk-msg-ft"><a class="btn btn-secondary" href="' . (new moodle_url('/local/aisgk/index.php'))->out(false) . '">Hủy</a><button type="button" class="btn btn-danger" id="aisgk-reset-ok">OK</button></div></div></div>';

echo "<script>(function(){var f=document.getElementById('aisgk-reset-form'),ok=document.getElementById('aisgk-reset-ok');if(ok)ok.onclick=function(){ok.disabled=true;ok.textContent='Đang reset...';f.submit();};})();</script>";

echo $OUTPUT->footer();
