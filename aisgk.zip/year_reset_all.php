<?php
require_once(__DIR__ . '/../../config.php');

$context = context_system::instance();
$PAGE->set_context($context);
require_login();
require_capability('moodle/site:config', $context);

use local_aisgk\local\service\school_year_backup_service;

$action = optional_param('action', '', PARAM_ALPHAEXT);
$ajax = optional_param('ajax', 0, PARAM_BOOL);

if ($action === 'resetall' && confirm_sesskey()) {
    @ignore_user_abort(true);
    @set_time_limit(0);
    try {
        if (class_exists('\\core\\session\\manager')) {
            \core\session\manager::write_close();
        }
        $summary = school_year_backup_service::execute_total_test_reset_delete_all_data();
        $tables = count($summary['cleared_tables'] ?? []);
        $files = (int)($summary['deleted_files'] ?? 0);
        $skipped = count($summary['skipped_tables'] ?? []);
        if ($ajax) {
            header('Content-Type: application/json; charset=utf-8');
            echo json_encode(['ok' => true, 'tables' => $tables, 'files' => $files, 'skipped' => $skipped], JSON_UNESCAPED_UNICODE);
            exit;
        }
        redirect(new moodle_url('/local/aisgk/index.php'), 'Đã reset toàn bộ.', null, \core\output\notification::NOTIFY_SUCCESS);
    } catch (Throwable $e) {
        if ($ajax) {
            header('Content-Type: application/json; charset=utf-8');
            echo json_encode(['ok' => false, 'error' => $e->getMessage()], JSON_UNESCAPED_UNICODE);
            exit;
        }
        throw $e;
    }
}

// Fallback if someone opens this endpoint directly. The normal UI opens a modal from the ALSM portal.
$PAGE->set_url(new moodle_url('/local/aisgk/year_reset_all.php'));
$PAGE->set_title('Reset toàn bộ');
$PAGE->set_heading('');
$PAGE->set_pagelayout('standard');

echo $OUTPUT->header();
echo html_writer::div('Mở mục Reset toàn bộ từ trang ALSM để xác nhận bằng popup.', 'alert alert-info');
echo html_writer::link(new moodle_url('/local/aisgk/index.php'), 'Quay lại ALSM', ['class' => 'btn btn-primary']);
echo $OUTPUT->footer();
