<?php
require_once(__DIR__ . '/../../config.php');

$context = context_system::instance();
$PAGE->set_context($context);
require_login();
require_capability('moodle/site:config', $context);

use local_aisgk\local\service\school_year_backup_service;

$action = optional_param('action', '', PARAM_ALPHAEXT);

if ($action === 'resetall' && confirm_sesskey()) {
    @ignore_user_abort(true);
    @set_time_limit(0);
    try {
        $summary = school_year_backup_service::execute_total_test_reset_delete_all_data();
        $tables = count($summary['cleared_tables'] ?? []);
        $files = (int)($summary['deleted_files'] ?? 0);
        $skipped = count($summary['skipped_tables'] ?? []);
        header('Content-Type: text/html; charset=utf-8');
        echo '<!doctype html><html><head><meta charset="utf-8"><title>Reset toàn bộ</title>';
        echo '<style>body{font-family:Arial,sans-serif;margin:32px;line-height:1.45}.box{max-width:720px;border:1px solid #ddd;border-radius:10px;padding:18px}.ok{color:#166534;font-weight:700}.warn{color:#991b1b}.muted{color:#666}</style>';
        echo '</head><body><div class="box"><div class="ok">Đã reset toàn bộ dữ liệu.</div>';
        echo '<p>Đã xóa dữ liệu trong <b>' . (int)$tables . '</b> bảng và <b>' . (int)$files . '</b> file/thư mục trong moodledata. Không xóa cấu trúc bảng.</p>';
        if ($skipped > 0) {
            echo '<p class="warn">Có ' . (int)$skipped . ' bảng không xóa được. Xem log PHP/server để kiểm tra.</p>';
        }
        echo '<p class="muted">Sau thao tác này Moodle có thể yêu cầu khôi phục/cài lại dữ liệu nền vì reset không giữ lại user, role, config hay API key.</p>';
        echo '</div></body></html>';
    } catch (Throwable $e) {
        header('Content-Type: text/html; charset=utf-8');
        echo '<!doctype html><html><head><meta charset="utf-8"><title>Reset lỗi</title></head><body>';
        echo '<h3>Reset lỗi</h3><pre>' . s($e->getMessage()) . '</pre></body></html>';
    }
    exit;
}

$PAGE->set_url(new moodle_url('/local/aisgk/year_reset_all.php'));
$PAGE->set_title('Reset toàn bộ');
$PAGE->set_heading('Reset toàn bộ');
$PAGE->set_pagelayout('standard');

echo $OUTPUT->header();

$style = '.aisgk-reset-wrap{max-width:760px}.aisgk-reset-card{border:1px solid #e5e7eb;border-radius:10px;background:#fff;padding:14px}.aisgk-reset-card p{margin:.25rem 0}.aisgk-danger{color:#991b1b;font-weight:700}.aisgk-reset-modal-mask{position:fixed;inset:0;background:rgba(15,23,42,.48);display:none;align-items:center;justify-content:center;z-index:99999;padding:16px}.aisgk-reset-modal{width:min(520px,94vw);background:#fff;border-radius:12px;border:1px solid #e5e7eb;box-shadow:0 20px 55px rgba(15,23,42,.28);overflow:hidden}.aisgk-reset-hd{padding:12px 14px;border-bottom:1px solid #e5e7eb;font-weight:700}.aisgk-reset-bd{padding:14px;line-height:1.45}.aisgk-reset-ft{padding:12px 14px;border-top:1px solid #e5e7eb;display:flex;justify-content:flex-end;gap:8px;background:#f8fafc}';
echo html_writer::tag('style', $style);

echo html_writer::start_tag('div', ['class' => 'aisgk-reset-wrap']);
echo html_writer::start_tag('div', ['class' => 'aisgk-reset-card']);
echo html_writer::tag('p', 'Xóa toàn bộ dữ liệu Moodle + ALSM + moodledata.', ['class' => 'aisgk-danger']);
echo html_writer::tag('p', 'Không xóa bảng/schema. Không giữ API key, user, role hay cấu hình.');
echo html_writer::tag('button', 'Reset toàn bộ', ['type' => 'button', 'class' => 'btn btn-danger mt-2', 'id' => 'aisgk-reset-open']);
echo ' ' . html_writer::link(new moodle_url('/local/aisgk/index.php'), get_string('back'), ['class' => 'btn btn-secondary mt-2']);
echo html_writer::end_tag('div');
echo html_writer::end_tag('div');

echo html_writer::start_tag('form', ['id' => 'aisgk-reset-form', 'method' => 'post', 'action' => $PAGE->url->out(false)]);
echo html_writer::empty_tag('input', ['type' => 'hidden', 'name' => 'sesskey', 'value' => sesskey()]);
echo html_writer::empty_tag('input', ['type' => 'hidden', 'name' => 'action', 'value' => 'resetall']);
echo html_writer::end_tag('form');

echo '<div class="aisgk-reset-modal-mask" id="aisgk-reset-mask"><div class="aisgk-reset-modal"><div class="aisgk-reset-hd">Xác nhận reset toàn bộ</div><div class="aisgk-reset-bd"><p class="aisgk-danger">Thao tác này sẽ xóa sạch dữ liệu trong toàn bộ bảng và moodledata.</p><p>Không xóa cấu trúc bảng, nhưng Moodle có thể không còn đăng nhập/chạy bình thường nếu chưa khôi phục dữ liệu nền.</p></div><div class="aisgk-reset-ft"><button type="button" class="btn btn-secondary" id="aisgk-reset-cancel">Hủy</button><button type="button" class="btn btn-danger" id="aisgk-reset-ok">OK, reset ngay</button></div></div></div>';

echo "<script>(function(){var m=document.getElementById('aisgk-reset-mask'),f=document.getElementById('aisgk-reset-form'),o=document.getElementById('aisgk-reset-open'),c=document.getElementById('aisgk-reset-cancel'),ok=document.getElementById('aisgk-reset-ok');if(o)o.onclick=function(){m.style.display='flex';};if(c)c.onclick=function(){m.style.display='none';};if(ok)ok.onclick=function(){ok.disabled=true;ok.textContent='Đang reset...';f.submit();};})();</script>";

echo $OUTPUT->footer();
