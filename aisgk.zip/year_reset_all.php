<?php
require_once(__DIR__ . '/../../config.php');

$localaisgkmodal = optional_param('modal', 0, PARAM_BOOL);
function local_aisgk_modal_page_open($title = '') {
    global $OUTPUT, $localaisgkmodal;
    if ($localaisgkmodal) {
        echo '<!doctype html><html><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>' . s($title) . '</title><style>html,body{margin:0!important;padding:0!important;background:#fff!important;overflow:hidden;font-family:Arial,Helvetica,sans-serif}.modal-clean-wrap{padding:10px;box-sizing:border-box;width:100%;height:100vh;overflow:auto}.btn,.local-aisgk-modal .btn,button,input[type=submit]{display:inline-flex!important;align-items:center!important;justify-content:center!important;height:34px!important;line-height:1!important;padding:0 12px!important;box-sizing:border-box!important;vertical-align:middle!important}table{border-collapse:collapse}.muted{color:#64748b}.table-responsive{overflow:auto}</style></head><body><div class="modal-clean-wrap">';
    } else {
        local_aisgk_modal_page_open($PAGE->title ?? '');
    }
}
function local_aisgk_modal_page_close() {
    global $OUTPUT, $localaisgkmodal;
    if ($localaisgkmodal) {
        echo '</div></body></html>';
    } else {
        local_aisgk_modal_page_close();
    }
}


$context = context_system::instance();
$PAGE->set_context($context);
require_login();
require_capability('moodle/site:config', $context);

use local_aisgk\local\service\school_year_backup_service;

$action = optional_param('action', '', PARAM_ALPHAEXT);
$ajax = optional_param('ajax', 0, PARAM_BOOL);

if ($action === 'resetall' && confirm_sesskey()) {
    @ignore_user_abort(true);
    @set_time_limit(0);
    try {
        if (class_exists('\\core\\session\\manager')) {
            \core\session\manager::write_close();
        }
        $summary = school_year_backup_service::execute_total_test_reset_delete_all_data();
        $tables = count($summary['cleared_tables'] ?? []);
        $files = (int)($summary['deleted_files'] ?? 0);
        $skipped = count($summary['skipped_tables'] ?? []);
        if ($ajax) {
            header('Content-Type: application/json; charset=utf-8');
            echo json_encode(['ok' => true, 'tables' => $tables, 'files' => $files, 'skipped' => $skipped], JSON_UNESCAPED_UNICODE);
            exit;
        }
        redirect(new moodle_url('/local/aisgk/index.php'), 'Đã reset toàn bộ.', null, \core\output\notification::NOTIFY_SUCCESS);
    } catch (Throwable $e) {
        if ($ajax) {
            header('Content-Type: application/json; charset=utf-8');
            echo json_encode(['ok' => false, 'error' => $e->getMessage()], JSON_UNESCAPED_UNICODE);
            exit;
        }
        throw $e;
    }
}

// Fallback if someone opens this endpoint directly. The normal UI opens a modal from the ALSM portal.
$PAGE->set_url(new moodle_url('/local/aisgk/year_reset_all.php'));
$PAGE->set_title('Reset toàn bộ');
$PAGE->set_heading('');
$PAGE->set_pagelayout('standard');

local_aisgk_modal_page_open($PAGE->title ?? '');
echo html_writer::div('Mở mục Reset toàn bộ từ trang ALSM để xác nhận bằng popup.', 'alert alert-info');
echo html_writer::link(new moodle_url('/local/aisgk/index.php'), 'Quay lại ALSM', ['class' => 'btn btn-primary']);
local_aisgk_modal_page_close();
