<?php
require_once(__DIR__ . '/../../../config.php');

$localaisgkmodal = optional_param('modal', 0, PARAM_BOOL);
function local_aisgk_modal_page_open($title = '') {
    global $OUTPUT, $localaisgkmodal;
    if ($localaisgkmodal) {
        echo '<!doctype html><html><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>' . s($title) . '</title><style>html,body{margin:0!important;padding:0!important;background:#fff!important;overflow:hidden;font-family:Arial,Helvetica,sans-serif}.modal-clean-wrap{padding:10px;box-sizing:border-box;width:100%;height:100vh;overflow:auto}.btn,button,input[type=submit]{display:inline-flex!important;align-items:center!important;justify-content:center!important;height:34px!important;line-height:1!important;padding:0 12px!important;box-sizing:border-box!important;vertical-align:middle!important}.table-responsive{overflow:auto}.muted{color:#64748b}</style></head><body><div class="modal-clean-wrap">';
    } else {
        echo $OUTPUT->header();
    }
}
function local_aisgk_modal_page_close() {
    global $OUTPUT, $localaisgkmodal;
    if ($localaisgkmodal) {
        echo '</div></body></html>';
    } else {
        echo $OUTPUT->footer();
    }
}


use local_aisgk\local\service\nls_service;

require_login();
$context = context_system::instance();
require_capability('local/aisgk:managenls', $context);
$PAGE->set_context($context);
$PAGE->set_url(new moodle_url('/local/aisgk/nls/index.php'));
$PAGE->set_title(get_string('alsm_danh_muc_nls_chuan', 'local_aisgk'));
$PAGE->set_heading(get_string('alsm_danh_muc_nls_chuan', 'local_aisgk'));
$PAGE->set_pagelayout('standard');

$message = '';
$messagetype = 'success';
if (data_submitted() && confirm_sesskey()) {
    try {
        $action = optional_param('action', '', PARAM_ALPHANUMEXT);
        if ($action === 'importnls') {
            $counts = nls_service::import_uploaded_file($_FILES['nlsfile'] ?? []);
            $message = get_string('nlsimportdone', 'local_aisgk', json_encode($counts, JSON_UNESCAPED_UNICODE));
        }
    } catch (Throwable $e) {
        $message = $e->getMessage();
        $messagetype = 'error';
    }
}
$stats = nls_service::stats();

local_aisgk_modal_page_open($PAGE->title ?? '');
?>
<style>
.local-aisgk-nls-wrap{max-width:980px;margin:0 auto;padding:16px}.local-aisgk-card{background:#fff;border:1px solid #dbe3ef;border-radius:14px;box-shadow:0 8px 24px rgba(15,23,42,.08);padding:18px;margin-bottom:14px}.local-aisgk-grid{display:grid;grid-template-columns:repeat(5,minmax(120px,1fr));gap:10px}.local-aisgk-stat{border:1px solid #e2e8f0;border-radius:12px;padding:12px;background:#f8fafc;text-align:center}.local-aisgk-stat b{display:block;font-size:24px;color:#0f172a}.local-aisgk-actions{display:flex;gap:8px;align-items:center;flex-wrap:wrap}.local-aisgk-alert{border-radius:10px;padding:10px 12px;margin-bottom:12px}.local-aisgk-alert.success{background:#ecfdf5;border:1px solid #bbf7d0}.local-aisgk-alert.error{background:#fff1f2;border:1px solid #fecdd3}.local-aisgk-file{border:1px solid #cbd5e1;border-radius:8px;padding:8px;background:#fff}@media(max-width:760px){.local-aisgk-grid{grid-template-columns:1fr 1fr}.local-aisgk-actions{flex-direction:column;align-items:stretch}}
</style>
<div class="local-aisgk-nls-wrap">
    <?php if ($message !== ''): ?><div class="local-aisgk-alert <?php echo s($messagetype); ?>"><?php echo s($message); ?></div><?php endif; ?>
    <div class="local-aisgk-card">
        <h2><?php echo s(get_string('alsm_danh_muc_nls_chuan', 'local_aisgk')); ?></h2>
        <p><?php echo s(get_string('nlsimporthelp', 'local_aisgk')); ?></p>
        <form method="post" enctype="multipart/form-data" class="local-aisgk-actions">
            <input type="hidden" name="sesskey" value="<?php echo sesskey(); ?>">
            <input type="hidden" name="action" value="importnls">
            <input type="file" name="nlsfile" class="local-aisgk-file" accept=".xlsx,.csv,application/vnd.openxmlformats-officedocument.spreadsheetml.sheet,text/csv" required>
            <button type="submit" class="btn btn-primary"><?php echo s(get_string('nlsimportbutton', 'local_aisgk')); ?></button>
            <a class="btn btn-secondary" href="<?php echo (new moodle_url('/local/aisgk/index.php'))->out(false); ?>"><?php echo s(get_string('alsm_quay_lai_alsm_toan_truong', 'local_aisgk')); ?></a>
        </form>
    </div>
    <div class="local-aisgk-card">
        <h3><?php echo s(get_string('nlsimportstatus', 'local_aisgk')); ?></h3>
        <div class="local-aisgk-grid">
            <div class="local-aisgk-stat"><b><?php echo (int)$stats['domain']; ?></b>Miền</div>
            <div class="local-aisgk-stat"><b><?php echo (int)$stats['component']; ?></b>NL thành phần</div>
            <div class="local-aisgk-stat"><b><?php echo (int)$stats['level_map']; ?></b>Mức/khối</div>
            <div class="local-aisgk-stat"><b><?php echo (int)$stats['progression_grade']; ?></b>Tiến trình</div>
            <div class="local-aisgk-stat"><b><?php echo (int)$stats['indicator_grade']; ?></b>Mã chỉ báo</div>
        </div>
        <?php if (!empty($stats['last'])): ?>
            <p style="margin-top:12px">File gần nhất: <b><?php echo s($stats['last']->filename); ?></b>, <?php echo userdate((int)$stats['last']->timecreated); ?></p>
        <?php endif; ?>
    </div>
</div>
<?php local_aisgk_modal_page_close();
