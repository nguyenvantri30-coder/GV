/* eslint-disable no-tabs */
define(['jquery', 'core/modal_factory'], function($, ModalFactory) {
    var clamp = function(value, min, max) {
        return Math.max(min, Math.min(max, value));
    };

    var px = function(value) {
        return String(Math.round(value)) + 'px';
    };

    var open = async function(config) {
        config = config || {};

        var title = config.title || '';
        var url = config.url || '';

        var iframe = $('<iframe>', {
            src: url,
            title: title,
            css: {
                width: '100%',
                height: '100%',
                border: '0',
                display: 'block',
                background: '#fff'
            }
        });

        var modal = await ModalFactory.create({
            title: title,
            body: iframe,
            large: false
        });

        modal.show();

        var root = modal.getRoot();
        var dialog = root.find('.modal-dialog');
        var content = root.find('.modal-content');
        var header = root.find('.modal-header');
        var body = modal.getBody();

        root.find('.modal-dialog').removeClass('modal-lg');
        root.find('.modal-content, .modal-header, .modal-dialog').css({
            outline: 'none',
            boxShadow: 'none'
        });

        var resizeHandle = $('<div class="local-aisgk-resize-handle" aria-hidden="true"></div>');
        content.append(resizeHandle);

        var state = {
            left: Math.round(window.innerWidth * 0.04),
            top: Math.round(window.innerHeight * 0.04),
            width: Math.round(window.innerWidth * 0.70),
            height: Math.round(window.innerHeight * 0.88),
            minWidth: 760,
            minHeight: 420,
            dragging: false,
            resizing: false,
            startX: 0,
            startY: 0,
            startLeft: 0,
            startTop: 0,
            startWidth: 0,
            startHeight: 0
        };

        var applyLayout = function() {
            var maxWidth = Math.max(state.minWidth, window.innerWidth - 24);
            var maxHeight = Math.max(state.minHeight, window.innerHeight - 24);

            state.width = clamp(state.width, state.minWidth, maxWidth);
            state.height = clamp(state.height, state.minHeight, maxHeight);
            state.left = clamp(state.left, 0, Math.max(0, window.innerWidth - state.width));
            state.top = clamp(state.top, 0, Math.max(0, window.innerHeight - state.height));

            dialog.css({
                position: 'fixed',
                left: px(state.left),
                top: px(state.top),
                width: px(state.width),
                maxWidth: 'none',
                margin: '0',
                transform: 'none',
                pointerEvents: 'auto'
            });

            if (dialog[0]) {
                dialog[0].style.setProperty('width', px(state.width), 'important');
                dialog[0].style.setProperty('max-width', 'none', 'important');
            }

            content.css({
                position: 'relative',
                width: '100%',
                height: px(state.height),
                minWidth: px(state.minWidth),
                minHeight: px(state.minHeight),
                overflow: 'hidden',
                boxSizing: 'border-box',
                border: '1px solid #cfd7e3',
                borderRadius: '8px',
                background: '#fff',
                resize: 'none',
                outline: 'none',
                boxShadow: 'none'
            });

            header.css({
                cursor: 'move',
                userSelect: 'none',
                outline: 'none',
                boxShadow: 'none'
            });

            body.css({
                padding: '0',
                overflow: 'hidden',
                height: px(state.height - (header.outerHeight() || 56))
            });

            iframe.css({
                width: '100%',
                height: '100%',
                border: '0',
                display: 'block'
            });

            resizeHandle.css({
                position: 'absolute',
                right: '0',
                bottom: '0',
                width: '18px',
                height: '18px',
                cursor: 'nwse-resize',
                zIndex: '5',
		background:
   'linear-gradient(135deg, transparent 0, transparent 45%, ' +
   '#94a3b8 45%, #94a3b8 55%, transparent 55%, transparent 100%)'
            });
        };

        applyLayout();

        header.on('mousedown', function(e) {
            if ($(e.target).closest('button, .close, [data-action="hide"]').length) {
                return;
            }

            state.dragging = true;
            state.startX = e.clientX;
            state.startY = e.clientY;
            state.startLeft = state.left;
            state.startTop = state.top;

            e.preventDefault();
        });

        resizeHandle.on('mousedown', function(e) {
            state.resizing = true;
            state.startX = e.clientX;
            state.startY = e.clientY;
            state.startWidth = state.width;
            state.startHeight = state.height;

            e.preventDefault();
            e.stopPropagation();
        });

        $(document).on('mousemove.localAisgkModal', function(e) {
            if (state.dragging) {
                state.left = state.startLeft + (e.clientX - state.startX);
                state.top = state.startTop + (e.clientY - state.startY);
                applyLayout();
                return;
            }

            if (state.resizing) {
                state.width = state.startWidth + (e.clientX - state.startX);
                state.height = state.startHeight + (e.clientY - state.startY);
                applyLayout();
            }
        });

        $(document).on('mouseup.localAisgkModal', function() {
            state.dragging = false;
            state.resizing = false;
        });

        $(window).on('resize.localAisgkModal', function() {
            applyLayout();
        });

        root.on('hidden.bs.modal', function() {
            $(document).off('.localAisgkModal');
            $(window).off('.localAisgkModal');
        });
    };

    return {
        open: open
    };
});
