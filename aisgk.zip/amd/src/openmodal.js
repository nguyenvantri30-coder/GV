/* eslint-disable no-tabs */
define(['jquery', 'core/modal_factory'], function($, ModalFactory) {
    var clamp = function(value, min, max) {
        return Math.max(min, Math.min(max, value));
    };

    var px = function(value) {
        return String(Math.round(value)) + 'px';
    };

    var open = async function(config) {
        config = config || {};

        var title = config.title || '';
        var url = config.url || '';

        var iframe = $('<iframe>', {
            src: url,
            title: title,
            css: {
                width: '100%',
                height: '100%',
                border: '0',
                display: 'block',
                background: '#fff'
            }
        });

        var modal = await ModalFactory.create({
            title: title,
            body: iframe,
            large: false
        });

        modal.show();

        var root = modal.getRoot();
        // Keep ALSM iframe modals above role preview bars, image previews and other debug overlays.
        root.css('z-index', 250000);
        try { $('.modal-backdrop').last().css('z-index', 249990); } catch (e) {}
        var dialog = root.find('.modal-dialog');
        var content = root.find('.modal-content');
        var header = root.find('.modal-header');
        var body = modal.getBody();

        root.find('.modal-dialog').removeClass('modal-lg');
        root.find('.modal-content, .modal-header, .modal-dialog').css({
            outline: 'none',
            boxShadow: 'none'
        });

        var resizeHandle = $('<div class="local-aisgk-resize-handle" aria-hidden="true"></div>');
        content.append(resizeHandle);

        var isCompactViewport = function() {
            return window.innerWidth <= 992;
        };

        var isTouchLikeViewport = function() {
            return window.matchMedia && window.matchMedia('(pointer: coarse)').matches;
        };

        var state = {
            left: Math.round(window.innerWidth * 0.05),
            top: Math.round(window.innerHeight * 0.04),
            width: Math.round(window.innerWidth * 0.90),
            height: Math.round(window.innerHeight * 0.88),
            minWidth: 320,
            minHeight: 320,
            dragging: false,
            resizing: false,
            startX: 0,
            startY: 0,
            startLeft: 0,
            startTop: 0,
            startWidth: 0,
            startHeight: 0
        };

        var applyLayout = function() {
            var compact = isCompactViewport();
            var touchLike = isTouchLikeViewport();
            var viewportGap = compact ? 8 : 24;
            var minWidth = compact ? Math.max(280, window.innerWidth - 12) : 760;
            var minHeight = compact ? Math.max(280, Math.round(window.innerHeight * 0.70)) : 420;
            var targetWidth = compact ? Math.round(window.innerWidth * 0.90) : Math.round(window.innerWidth * 0.90);
            var targetHeight = compact ? Math.round(window.innerHeight * 0.90) : Math.round(window.innerHeight * 0.88);
            var maxWidth = Math.max(minWidth, window.innerWidth - viewportGap);
            var maxHeight = Math.max(minHeight, window.innerHeight - viewportGap);

            state.minWidth = minWidth;
            state.minHeight = minHeight;

            if (compact) {
                state.width = targetWidth;
                state.height = targetHeight;
                state.left = Math.max(0, Math.round((window.innerWidth - state.width) / 2));
                state.top = Math.max(0, Math.round((window.innerHeight - state.height) / 2));
            }

            state.width = clamp(state.width, minWidth, maxWidth);
            state.height = clamp(state.height, minHeight, maxHeight);
            state.left = clamp(state.left, 0, Math.max(0, window.innerWidth - state.width));
            state.top = clamp(state.top, 0, Math.max(0, window.innerHeight - state.height));

            dialog.css({
                position: 'fixed',
                left: px(state.left),
                top: px(state.top),
                width: px(state.width),
                maxWidth: 'none',
                margin: '0',
                transform: 'none',
                pointerEvents: 'auto'
            });

            if (dialog[0]) {
                dialog[0].style.setProperty('width', px(state.width), 'important');
                dialog[0].style.setProperty('max-width', 'none', 'important');
            }

            content.css({
                position: 'relative',
                width: '100%',
                height: px(state.height),
                minWidth: px(state.minWidth),
                minHeight: px(state.minHeight),
                overflow: 'hidden',
                boxSizing: 'border-box',
                border: '1px solid #cfd7e3',
                borderRadius: '8px',
                background: '#fff',
                resize: 'none',
                outline: 'none',
                boxShadow: 'none'
            });

            header.css({
                cursor: compact && touchLike ? 'default' : 'move',
                userSelect: 'none',
                outline: 'none',
                boxShadow: 'none',
                minHeight: '23px',
                paddingTop: '4px',
                paddingBottom: '4px',
                alignItems: 'center'
            });

            body.css({
                padding: '0',
                overflow: 'hidden',
                height: px(state.height - (header.outerHeight() || 56))
            });

            iframe.css({
                width: '100%',
                height: '100%',
                border: '0',
                display: 'block'
            });

            resizeHandle.css({
                position: 'absolute',
                right: '0',
                bottom: '0',
                width: touchLike ? '0' : '18px',
                height: touchLike ? '0' : '18px',
                cursor: touchLike ? 'default' : 'nwse-resize',
                zIndex: '5',
                display: touchLike ? 'none' : 'block',
                background:
                    'linear-gradient(135deg, transparent 0, transparent 45%, ' +
                    '#94a3b8 45%, #94a3b8 55%, transparent 55%, transparent 100%)'
            });
        };

        applyLayout();

        header.on('mousedown', function(e) {
            if (isTouchLikeViewport() || isCompactViewport()) {
                return;
            }

            if ($(e.target).closest('button, .close, [data-action="hide"]').length) {
                return;
            }

            state.dragging = true;
            state.startX = e.clientX;
            state.startY = e.clientY;
            state.startLeft = state.left;
            state.startTop = state.top;

            e.preventDefault();
        });

        resizeHandle.on('mousedown', function(e) {
            if (isTouchLikeViewport() || isCompactViewport()) {
                return;
            }

            state.resizing = true;
            state.startX = e.clientX;
            state.startY = e.clientY;
            state.startWidth = state.width;
            state.startHeight = state.height;

            e.preventDefault();
            e.stopPropagation();
        });

        $(document).on('mousemove.localAisgkModal', function(e) {
            if (state.dragging) {
                state.left = state.startLeft + (e.clientX - state.startX);
                state.top = state.startTop + (e.clientY - state.startY);
                applyLayout();
                return;
            }

            if (state.resizing) {
                state.width = state.startWidth + (e.clientX - state.startX);
                state.height = state.startHeight + (e.clientY - state.startY);
                applyLayout();
            }
        });

        $(document).on('mouseup.localAisgkModal', function() {
            state.dragging = false;
            state.resizing = false;
        });

        $(window).on('resize.localAisgkModal', function() {
            applyLayout();
        });

        root.on('hidden.bs.modal', function() {
            $(document).off('.localAisgkModal');
            $(window).off('.localAisgkModal');
        });
    };

    return {
        open: open
    };
});
