const buildUrl = (baseUrl, sectionId) => {
    const sep = baseUrl.includes('?') ? '&' : '?';
    return `${baseUrl}${sep}sectionid=${sectionId}`;
};

const sectionSelectors = [
    '[data-for="section"][data-id]',
    'li.section[data-id]',
    'li.course-section[data-id]',
    '.course-section[data-id]',
    'section[data-id][id^="section-"]'
];

const findSectionNodes = () => {
    const found = [];
    const seen = new Set();
    sectionSelectors.forEach((selector) => {
        document.querySelectorAll(selector).forEach((node) => {
            const key = node.getAttribute('data-id') || node.id;
            if (!key || seen.has(key)) {
                return;
            }
            seen.add(key);
            found.push(node);
        });
    });
    return found;
};

const injectButtonIntoSection = (sectionNode, config) => {
    if (!config.cancreatehw || sectionNode.querySelector('.local-aisgk-topic-homework')) {
        return;
    }

    const sectionId = sectionNode.getAttribute('data-id');
    if (!sectionId) {
        return;
    }

    const actionTargets = [
        '[data-region="sectionbadges"]',
        '[data-region="section-actions"]',
        '.section_action_menu',
        '.actions',
        '.section-actions',
        '.course-section-header'
    ];

    const titleTargets = [
        '[data-for="section_title"]',
        '[data-for="sectionname"]',
        '[data-for="sectioninfo"] .sectionname',
        '.sectionname',
        '.content .sectionname',
        'h3',
        'h4'
    ];

    let titleAnchor = null;
    for (const selector of titleTargets) {
        titleAnchor = sectionNode.querySelector(selector);
        if (titleAnchor) {
            break;
        }
    }

    if (!titleAnchor) {
        return;
    }

    const wrap = document.createElement('span');
    wrap.className = 'local-aisgk-topic-homework';

    const btn = document.createElement('button');
btn.type = 'button';
btn.className = 'btn btn-sm btn-outline-primary';
btn.textContent = config.buttonlabel;

btn.addEventListener('click', (e) => {
    e.preventDefault();

    let topicname = '';
    const section = btn.closest('li.section, .course-section, [data-sectionid]');

    if (section) {
        const titleEl = section.querySelector(
            '.sectionname, .course-section-header .sectionname, .course-section-header h3, .section-title, h3'
        );
        if (titleEl) {
            topicname = titleEl.textContent.replace(/\s+/g, ' ').trim();
        }
    }

    require(['local_aisgk/openmodal'], function(modal) {
        modal.open({
            title: (config.homeworktitle || 'Tạo BTVN') + (topicname ? ': ' + topicname : ''),
            url: buildUrl(config.basehomeworkurl, sectionId) + (topicname ? '&topicname=' + encodeURIComponent(topicname) : ''),
            height: 620
        });
    });
});

wrap.appendChild(btn);

    let actionAnchor = null;
    for (const selector of actionTargets) {
        actionAnchor = sectionNode.querySelector(selector);
        if (actionAnchor && actionAnchor.parentNode) {
            actionAnchor.parentNode.insertBefore(wrap, actionAnchor);
            return;
        }
    }

    if (titleAnchor.parentNode) {
        titleAnchor.parentNode.appendChild(wrap);
    }
};

const scanSections = (config) => {
    findSectionNodes().forEach((sectionNode) => injectButtonIntoSection(sectionNode, config));
};

export const init = (config) => {
    scanSections(config);
    [300, 1000, 2200, 4500].forEach((delay) => {
        window.setTimeout(() => scanSections(config), delay);
    });
};


window.localAisgkMsgBox=function(msg){
 var old=document.querySelector('.local-aisgk-msgbox');
 if(old){old.remove();}
 var d=document.createElement('div');
 d.className='local-aisgk-msgbox';
 d.innerHTML=msg;
 document.body.appendChild(d);
 setTimeout(function(){
   d.style.opacity='0';
   setTimeout(function(){if(d.parentNode)d.parentNode.removeChild(d);},300);
 },2500);
};
