const WRAP_CLASS = 'local-aisgk-topic-homework';

const buildUrl = (baseUrl, sectionId) => {
    const sep = baseUrl.includes('?') ? '&' : '?';
    return `${baseUrl}${sep}sectionid=${sectionId}`;
};

const findSections = () => {
    const selectors = [
        '[data-for="section"][data-id]',
        'li[id^="section-"][id!="section-0"]',
        '.course-section[data-id]',
        '.section.main[data-id]'
    ];

    const nodes = [];
    selectors.forEach((selector) => {
        document.querySelectorAll(selector).forEach((node) => {
            if (!nodes.includes(node)) {
                nodes.push(node);
            }
        });
    });

    return nodes;
};

const getSectionId = (sectionNode) => {
    return sectionNode.getAttribute('data-id') ||
        sectionNode.getAttribute('data-sectionid') ||
        (sectionNode.id || '').replace(/^section-/, '');
};

const findAnchor = (sectionNode) => {
    const infoTargets = [
        '[data-for="sectioninfo"]',
        '.content .sectionname',
        '.sectionname',
        'h3',
        'h4'
    ];

    for (const selector of infoTargets) {
        const anchor = sectionNode.querySelector(selector);
        if (anchor) {
            return anchor;
        }
    }

    return null;
};

const injectButtonIntoSection = (sectionNode, config) => {
    if (!config.cancreatehw) {
        return;
    }

    if (sectionNode.querySelector(`.${WRAP_CLASS}`)) {
        return;
    }

    const sectionId = getSectionId(sectionNode);
    if (!sectionId || sectionId === '0') {
        return;
    }

    const anchor = findAnchor(sectionNode);
    if (!anchor) {
        return;
    }

    const wrap = document.createElement('div');
    wrap.className = `${WRAP_CLASS} mt-2`;

    const btn = document.createElement('button');
    btn.type = 'button';
    btn.className = 'btn btn-sm btn-outline-primary';
    btn.textContent = config.buttonlabel;

    btn.addEventListener('click', (e) => {
        e.preventDefault();
        require(['local_aisgk/openmodal', 'core/str'], function(modal, Str) {
            Str.get_string('createhomeworkmodaltitle', 'local_aisgk').then(function(title) {
                modal.open({
                    title: title,
                    url: buildUrl(config.basehomeworkurl, sectionId),
                    height: 560
                });
            });
        });
    });

    wrap.appendChild(btn);
    anchor.parentNode.appendChild(wrap);
};

const scanSections = (config) => {
    findSections().forEach((sectionNode) => {
        injectButtonIntoSection(sectionNode, config);
    });
};

export const init = (config) => {
    const delays = [0, 400, 1200, 2500, 5000];
    delays.forEach((delay) => {
        window.setTimeout(() => {
            scanSections(config);
        }, delay);
    });

    document.addEventListener('DOMContentLoaded', () => scanSections(config), {once: true});
    window.addEventListener('load', () => scanSections(config), {once: true});
};
