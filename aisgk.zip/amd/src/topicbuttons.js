const WRAP_CLASS = 'local-aisgk-topic-homework';

const buildUrl = (baseUrl, sectionId) => {
    const sep = baseUrl.includes('?') ? '&' : '?';
    return `${baseUrl}${sep}sectionid=${sectionId}`;
};

const getSectionId = (sectionNode) => {
    return sectionNode.getAttribute('data-id') ||
        sectionNode.getAttribute('data-sectionid') ||
        (sectionNode.id || '').replace(/^section-/, '');
};

const findSectionNodes = () => {
    const selectors = [
        '[data-for="section"][data-id]',
        'li[id^="section-"]',
        '.course-section[data-id]',
        '.section.main[data-id]',
        '.course-content-item[data-id]'
    ];

    const nodes = [];
    selectors.forEach((selector) => {
        document.querySelectorAll(selector).forEach((node) => {
            if (!nodes.includes(node)) {
                nodes.push(node);
            }
        });
    });
    return nodes;
};

const findAnchor = (sectionNode) => {
    const selectors = [
        '[data-for="sectioninfo"]',
        '.content .sectionname',
        '.sectionname',
        '.section-title',
        '.course-section-header',
        'h3',
        'h4'
    ];

    for (const selector of selectors) {
        const node = sectionNode.querySelector(selector);
        if (node) {
            return node;
        }
    }

    return sectionNode.firstElementChild || sectionNode;
};

const injectButtonIntoSection = (sectionNode, config) => {
    if (!config.cancreatehw || sectionNode.querySelector(`.${WRAP_CLASS}`)) {
        return;
    }

    const sectionId = getSectionId(sectionNode);
    if (!sectionId || sectionId === '0') {
        return;
    }

    const anchor = findAnchor(sectionNode);
    if (!anchor) {
        return;
    }

    const wrap = document.createElement('div');
    wrap.className = `${WRAP_CLASS} mt-2`;

    const btn = document.createElement('button');
    btn.type = 'button';
    btn.className = 'btn btn-sm btn-outline-primary';
    btn.textContent = config.buttonlabel;
    btn.addEventListener('click', (e) => {
        e.preventDefault();
        require(['local_aisgk/openmodal', 'core/str'], function(modal, Str) {
            Str.get_string('createhomeworkmodaltitle', 'local_aisgk').then(function(title) {
                modal.open({
                    title: title,
                    url: buildUrl(config.basehomeworkurl, sectionId)
                });
            });
        });
    });

    wrap.appendChild(btn);

    if (anchor.matches('h3, h4, .sectionname, .section-title')) {
        anchor.insertAdjacentElement('afterend', wrap);
    } else if (anchor.parentNode) {
        anchor.parentNode.appendChild(wrap);
    } else {
        sectionNode.prepend(wrap);
    }
};

const scanSections = (config) => {
    findSectionNodes().forEach((sectionNode) => injectButtonIntoSection(sectionNode, config));
};

export const init = (config) => {
    const run = () => scanSections(config);

    run();
    window.setTimeout(run, 300);
    window.setTimeout(run, 1200);
    window.setTimeout(run, 2500);
    document.addEventListener('DOMContentLoaded', run);
    window.addEventListener('load', run);

    const observer = new MutationObserver(() => {
        run();
    });

    observer.observe(document.body, {
        childList: true,
        subtree: true,
    });
};
