const buildUrl = (baseUrl, sectionId) => {
    const sep = baseUrl.includes('?') ? '&' : '?';
    return `${baseUrl}${sep}sectionid=${sectionId}`;
};

const injectButtonIntoSection = (sectionNode, config) => {
    if (!config.cancreatehw) {
        return;
    }

    if (sectionNode.querySelector('.local-aisgk-topic-homework')) {
        return;
    }

    const sectionId = sectionNode.getAttribute('data-id');
    if (!sectionId) {
        return;
    }

    const infoTargets = [
        '[data-for="sectioninfo"]',
        '.content .sectionname',
        '.sectionname',
        'h3',
        'h4',
    ];

    let anchor = null;
    for (const selector of infoTargets) {
        anchor = sectionNode.querySelector(selector);
        if (anchor) {
            break;
        }
    }

    if (!anchor) {
        return;
    }

    const wrap = document.createElement('div');
    wrap.className = 'local-aisgk-topic-homework mt-2';

    const btn = document.createElement('button');
    btn.type = 'button';
    btn.className = 'btn btn-sm btn-outline-primary';
    btn.textContent = config.buttonlabel;

    btn.addEventListener('click', (e) => {
        e.preventDefault();
        require(['local_aisgk/openmodal', 'core/str'], function(modal, Str) {
            Str.get_string('createhomeworkmodaltitle', 'local_aisgk').then(function(title) {
                modal.open({
                    title: title,
                    url: buildUrl(config.basehomeworkurl, sectionId),
                    height: 560
                });
            });
        });
    });

    wrap.appendChild(btn);

    if (anchor.parentNode) {
        anchor.parentNode.appendChild(wrap);
    }
};

const scanSections = (config) => {
    const sections = document.querySelectorAll('[data-for="section"][data-id]');
    sections.forEach((sectionNode) => {
        injectButtonIntoSection(sectionNode, config);
    });
};

export const init = (config) => {
    scanSections(config);

    const observer = new // removed MutationObserver(() => {
        scanSections(config);
    });

    observer.observe(document.body, {
        childList: true,
        subtree: true,
    });
};
