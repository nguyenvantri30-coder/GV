const getString = (key, fallback) => new Promise((resolve) => {
    require(['core/str'], function(Str) {
        Str.get_string(key, 'local_aisgk').then(resolve).catch(() => resolve(fallback || key));
    });
});
const openModalByKey = (titleKey, url) => {
    require(['local_aisgk/openmodal'], function(modal) {
        getString(titleKey, titleKey).then((title) => modal.open({title: title, url: url, height: 620}));
    });
};
const localUrl = (path, params) => {
    const url = new URL(M.cfg.wwwroot + '/local/aisgk/' + path);
    Object.keys(params || {}).forEach((key) => url.searchParams.set(key, params[key]));
    return url.toString();
};
const ensureHeaderButtons = (config) => {
    if (document.querySelector('.local-aisgk-course-actions')) { return true; }
    const headingSelectors = ['#page-header .page-header-headings h1','#page-header .page-header-headings','.page-header-headings h1','.page-header-headings','.page-context-header h1','.page-context-header','header#page-header h1','#topofscroll','#region-main h1'];
    let anchor = null;
    for (const selector of headingSelectors) { anchor = document.querySelector(selector); if (anchor) { break; } }
    if (!anchor) { return false; }

    const wrap = document.createElement('div');
    wrap.className = 'local-aisgk-course-actions';
    const courseid = parseInt(config.courseid, 10) || 0;

    if (config.canmanagebook) {
        const uploadBtn = document.createElement('button');
        uploadBtn.type = 'button';
        uploadBtn.className = 'btn btn-sm btn-primary';
        getString(config.hasbook ? 'replacebook' : 'uploadbook', config.hasbook ? 'Thay SGK' : 'Tải SGK').then((s) => { uploadBtn.textContent = s; });
        uploadBtn.addEventListener('click', (e) => {
            e.preventDefault();
            openModalByKey('uploadbookmodaltitle', localUrl('upload.php', {id: courseid}));
        });
        wrap.appendChild(uploadBtn);
    }

    if (config.cancreatetopic) {
        const topicBtn = document.createElement('button');
        topicBtn.type = 'button';
        topicBtn.className = 'btn btn-sm btn-secondary';
        getString('createtopic', 'Tạo chủ đề').then((s) => { topicBtn.textContent = s; });
        if (config.topicenabled === false) {
            topicBtn.disabled = true;
            topicBtn.title = config.scopemessage || 'Chưa đủ điều kiện tạo chủ đề';
        }
        topicBtn.addEventListener('click', (e) => {
            e.preventDefault();
            if (topicBtn.disabled) { window.alert(topicBtn.title || 'Chưa đủ điều kiện'); return; }
            openModalByKey('createtopicmodaltitle', localUrl('topic.php', {id: courseid}));
        });
        wrap.appendChild(topicBtn);
    }

    if (config.canaikeys) {
        const aiKeysBtn = document.createElement('button');
        aiKeysBtn.type = 'button';
        aiKeysBtn.className = 'btn btn-sm btn-outline-secondary';
        getString('aikeyslabel', 'API key').then((s) => { aiKeysBtn.textContent = s; });
        aiKeysBtn.addEventListener('click', (e) => {
            e.preventDefault();
            openModalByKey('aikeysmodaltitle', localUrl('aikeys.php', {id: courseid}));
        });
        wrap.appendChild(aiKeysBtn);
    }

    const myApiBtn = document.createElement('button');
    myApiBtn.type = 'button';
    myApiBtn.className = 'btn btn-sm btn-outline-primary';
    getString('myapilabel', 'API của tôi').then((s) => { myApiBtn.textContent = s; });
    myApiBtn.addEventListener('click', (e) => {
        e.preventDefault();
        openModalByKey('myapilabel', localUrl('myapi.php', {id: courseid}));
    });
    wrap.appendChild(myApiBtn);

    const apiLabel = document.createElement('label');
    apiLabel.className = 'local-aisgk-usemyapi';
    apiLabel.style.display = 'inline-flex';
    apiLabel.style.alignItems = 'center';
    apiLabel.style.gap = '4px';
    apiLabel.style.margin = '0 0 0 4px';
    const apiCheck = document.createElement('input');
    apiCheck.type = 'checkbox';
    apiCheck.checked = !!config.usemyapi;
    apiCheck.addEventListener('change', () => {
        fetch(localUrl('myapi_ajax.php', {id: courseid, op: 'preference', sesskey: M.cfg.sesskey}), {
            method: 'POST', headers: {'Content-Type': 'application/json'}, body: JSON.stringify({enabled: apiCheck.checked ? 1 : 0})
        }).catch(() => {});
    });
    apiLabel.appendChild(apiCheck);
    getString('usemyapichecklabel', 'Dùng API của tôi').then((s) => apiLabel.appendChild(document.createTextNode(s)));
    wrap.appendChild(apiLabel);

    const host = anchor.matches && anchor.matches('h1') ? anchor.parentNode : anchor;
    if (host && host.appendChild) { host.appendChild(wrap); return true; }
    anchor.after(wrap);
    return true;
};
const init = (config) => {
    ensureHeaderButtons(config);
    [250, 800, 1800, 3200].forEach((delay) => { window.setTimeout(() => ensureHeaderButtons(config), delay); });
};
export { init };
