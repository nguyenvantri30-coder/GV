const ROOT_CLASS = 'local-aisgk-course-actions';

const requireModal = (titlekey, configkey) => {
    return (e, config) => {
        e.preventDefault();
        require(['local_aisgk/openmodal', 'core/str'], function(modal, Str) {
            Str.get_string(titlekey, 'local_aisgk').then(function(title) {
                modal.open({
                    title: title,
                    url: config[configkey]
                });
            });
        });
    };
};

const buildButtons = (config) => {
    const wrap = document.createElement('div');
    wrap.className = ROOT_CLASS;

    if (config.canmanagebook) {
        const uploadBtn = document.createElement('button');
        uploadBtn.type = 'button';
        uploadBtn.className = 'btn btn-sm btn-primary';
        uploadBtn.textContent = config.uploadlabel;
        uploadBtn.addEventListener('click', (e) => requireModal('uploadbookmodaltitle', 'uploadurl')(e, config));
        wrap.appendChild(uploadBtn);
    }

    if (config.cancreatetopic) {
        const topicBtn = document.createElement('button');
        topicBtn.type = 'button';
        topicBtn.className = 'btn btn-sm btn-secondary';
        topicBtn.textContent = config.topiclabel;
        topicBtn.addEventListener('click', (e) => requireModal('createtopicmodaltitle', 'topicurl')(e, config));
        wrap.appendChild(topicBtn);
    }

    return wrap;
};

const getTargets = () => {
    const selectors = [
        '#page-header .page-header-headings',
        '#page-header .page-context-header',
        '#page-header .d-flex.align-items-center',
        '#page-header .w-100',
        '#page-header',
        '#topofscroll',
        '#region-main > .card-body',
        '#region-main',
        'body'
    ];

    const targets = [];
    selectors.forEach((selector) => {
        const node = document.querySelector(selector);
        if (node && !targets.includes(node)) {
            targets.push(node);
        }
    });
    return targets;
};

const inject = (config) => {
    if (document.querySelector(`.${ROOT_CLASS}`)) {
        return true;
    }

    const targets = getTargets();
    if (!targets.length) {
        return false;
    }

    const wrap = buildButtons(config);
    const primaryTarget = targets[0];

    const title = primaryTarget.querySelector('h1');
    if (title && title.parentNode) {
        title.insertAdjacentElement('afterend', wrap);
    } else {
        primaryTarget.prepend(wrap);
    }

    return true;
};

export const init = (config) => {
    const tryInject = () => inject(config);

    tryInject();
    window.setTimeout(tryInject, 300);
    window.setTimeout(tryInject, 1200);
    window.setTimeout(tryInject, 2500);

    document.addEventListener('DOMContentLoaded', tryInject);
    window.addEventListener('load', tryInject);

    const observer = new MutationObserver(() => {
        tryInject();
    });

    observer.observe(document.body, {
        childList: true,
        subtree: true,
    });
};
