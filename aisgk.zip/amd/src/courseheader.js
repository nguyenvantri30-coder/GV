const ROOT_CLASS = 'local-aisgk-course-actions';

const openModal = (titlekey, url, height) => {
    require(['local_aisgk/openmodal', 'core/str'], function(modal, Str) {
        Str.get_string(titlekey, 'local_aisgk').then(function(title) {
            modal.open({title: title, url: url, height: height});
        });
    });
};

const findHeaderTarget = () => {
    const selectors = [
        '#page-header .page-header-headings h1',
        '.page-header-headings h1',
        '.page-context-header h1',
        'header#page-header h1',
        '#page-header h1',
        '#region-main h1'
    ];

    for (const selector of selectors) {
        const node = document.querySelector(selector);
        if (node) {
            return node;
        }
    }

    return null;
};

const inject = (config) => {
    if (document.querySelector(`.${ROOT_CLASS}`)) {
        return true;
    }

    const titleNode = findHeaderTarget();
    if (!titleNode) {
        return false;
    }

    const wrap = document.createElement('span');
    wrap.className = `${ROOT_CLASS} ms-3`;

    if (config.canmanagebook) {
        const uploadBtn = document.createElement('button');
        uploadBtn.type = 'button';
        uploadBtn.className = 'btn btn-sm btn-primary';
        uploadBtn.textContent = config.uploadlabel;
        uploadBtn.addEventListener('click', (e) => {
            e.preventDefault();
            openModal('uploadbookmodaltitle', config.uploadurl, 360);
        });
        wrap.appendChild(uploadBtn);
    }

    if (config.cancreatetopic) {
        const topicBtn = document.createElement('button');
        topicBtn.type = 'button';
        topicBtn.className = 'btn btn-sm btn-secondary';
        topicBtn.textContent = config.topiclabel;
        topicBtn.addEventListener('click', (e) => {
            e.preventDefault();
            openModal('createtopicmodaltitle', config.topicurl, 520);
        });
        wrap.appendChild(topicBtn);
    }

    titleNode.appendChild(wrap);
    return true;
};

export const init = (config) => {
    const delays = [0, 300, 1000, 2000, 4000];
    delays.forEach((delay) => {
        window.setTimeout(() => {
            inject(config);
        }, delay);
    });

    document.addEventListener('DOMContentLoaded', () => inject(config), {once: true});
    window.addEventListener('load', () => inject(config), {once: true});
};
