const ensureHeaderButtons = (config) => {
    if (document.querySelector('.local-aisgk-course-actions')) {
        return true;
    }

    const headingSelectors = [
        '#page-header .page-header-headings h1',
        '#page-header .page-header-headings',
        '.page-header-headings h1',
        '.page-header-headings',
        '.page-context-header h1',
        '.page-context-header',
        'header#page-header h1',
        '#topofscroll',
        '#region-main h1'
    ];

    let anchor = null;
    for (const selector of headingSelectors) {
        anchor = document.querySelector(selector);
        if (anchor) {
            break;
        }
    }

    if (!anchor) {
        return false;
    }

    const wrap = document.createElement('div');
    wrap.className = 'local-aisgk-course-actions';

    const openModal = (titlekey, url) => {
        require(['local_aisgk/openmodal', 'core/str'], function(modal, Str) {
            Str.get_string(titlekey, 'local_aisgk').then(function(title) {
                modal.open({title: title, url: url, height: 620});
            });
        });
    };

    if (config.canmanagebook) {
        const uploadBtn = document.createElement('button');
        uploadBtn.type = 'button';
        uploadBtn.className = 'btn btn-sm btn-primary';
        uploadBtn.textContent = config.hasbook ? (config.replacelabel || config.uploadlabel) : config.uploadlabel;
        uploadBtn.addEventListener('click', (e) => {
            e.preventDefault();
            openModal('uploadbookmodaltitle', config.uploadurl);
        });
        wrap.appendChild(uploadBtn);
    }

    if (config.cancreatetopic) {
        const topicBtn = document.createElement('button');
        topicBtn.type = 'button';
        topicBtn.className = 'btn btn-sm btn-secondary';
        topicBtn.textContent = config.topiclabel;
        topicBtn.addEventListener('click', (e) => {
            e.preventDefault();
            openModal('createtopicmodaltitle', config.topicurl);
        });
        wrap.appendChild(topicBtn);
    }

    const host = anchor.matches && anchor.matches('h1') ? anchor.parentNode : anchor;
    if (host && host.appendChild) {
        host.appendChild(wrap);
        return true;
    }

    anchor.after(wrap);
    return true;
};

export const init = (config) => {
    ensureHeaderButtons(config);
    [250, 800, 1800, 3200].forEach((delay) => {
        window.setTimeout(() => ensureHeaderButtons(config), delay);
    });
};
