const strCache = {};
const applyDefaultStrings = (config) => {
    config.uploadlabel = config.uploadlabel || 'Tải SGK';
    config.replacelabel = config.replacelabel || 'Thay SGK';
    config.topiclabel = config.topiclabel || 'Tạo chủ đề';
    config.aikeyslabel = config.aikeyslabel || 'API hệ thống';
    config.myapilabel = config.myapilabel || 'API của tôi';
    config.usemyapichecklabel = config.usemyapichecklabel || 'Dùng API của tôi';
    config.uploadtitle = config.uploadtitle || config.uploadlabel;
    config.topictitle = config.topictitle || config.topiclabel;
    config.aikeystitle = config.aikeystitle || config.aikeyslabel;
    config.myapititle = config.myapititle || config.myapilabel;
};

const ensureHeaderButtons = (config) => {
    applyDefaultStrings(config);
    if (document.querySelector('.local-aisgk-course-actions')) {
        return true;
    }

    const headingSelectors = [
        '#page-header .page-header-headings h1',
        '#page-header .page-header-headings',
        '.page-header-headings h1',
        '.page-header-headings',
        '.page-context-header h1',
        '.page-context-header',
        'header#page-header h1',
        '#topofscroll',
        '#region-main h1'
    ];

    let anchor = null;
    for (const selector of headingSelectors) {
        anchor = document.querySelector(selector);
        if (anchor) {
            break;
        }
    }

    if (!anchor) {
        return false;
    }

    const wrap = document.createElement('div');
    wrap.className = 'local-aisgk-course-actions';

    const openModal = (title, url, isLiteral) => {
        require(['local_aisgk/openmodal', 'core/str'], function(modal, Str) {
            if (isLiteral) {
                modal.open({title: title, url: url, height: 620});
                return;
            }

            Str.get_string(title, 'local_aisgk').then(function(resolvedTitle) {
                modal.open({title: resolvedTitle, url: url, height: 620});
            });
        });
    };

    if (config.canmanagebook) {
        const uploadBtn = document.createElement('button');
        uploadBtn.type = 'button';
        uploadBtn.className = 'btn btn-sm btn-primary';
        uploadBtn.textContent = config.hasbook ? (config.replacelabel || config.uploadlabel) : config.uploadlabel;
        if (config.uploadenabled === false) {
            uploadBtn.disabled = true;
            uploadBtn.title = 'Bạn chưa có quyền tải/thay SGK.';
        }
        uploadBtn.addEventListener('click', (e) => {
            e.preventDefault();
            if (uploadBtn.disabled) { window.alert(uploadBtn.title || 'Chưa đủ điều kiện'); return; }
            openModal(config.uploadtitle || 'uploadbookmodaltitle', config.uploadurl, !!config.uploadtitle);
        });
        wrap.appendChild(uploadBtn);
    }

    if (config.cancreatetopic) {
        const topicBtn = document.createElement('button');
        topicBtn.type = 'button';
        topicBtn.className = 'btn btn-sm btn-secondary';
        topicBtn.textContent = config.topiclabel;
        if (config.topicenabled === false) {
            topicBtn.disabled = true;
            topicBtn.title = config.scopemessage || 'Chưa đủ điều kiện tạo chủ đề';
        }
        topicBtn.addEventListener('click', (e) => {
            e.preventDefault();
            if (topicBtn.disabled) { window.alert(topicBtn.title || 'Chưa đủ điều kiện'); return; }
            openModal(config.topictitle, config.topicurl, true);
        });
        wrap.appendChild(topicBtn);
    }

    if (config.canaikeys) {
        const aiKeysBtn = document.createElement('button');
        aiKeysBtn.type = 'button';
        aiKeysBtn.className = 'btn btn-sm btn-outline-secondary';
        aiKeysBtn.textContent = config.aikeyslabel;
        aiKeysBtn.addEventListener('click', (e) => {
            e.preventDefault();
            openModal(config.aikeystitle, config.aikeysurl, true);
        });
        wrap.appendChild(aiKeysBtn);
    }

    if (config.myapiurl) {
        const myApiBtn = document.createElement('button');
        myApiBtn.type = 'button';
        myApiBtn.className = 'btn btn-sm btn-outline-primary';
        myApiBtn.textContent = config.myapilabel || 'API của tôi';
        myApiBtn.addEventListener('click', (e) => {
            e.preventDefault();
            openModal(config.myapititle || 'API của tôi', config.myapiurl, true);
        });
        wrap.appendChild(myApiBtn);

        const apiLabel = document.createElement('label');
        apiLabel.className = 'local-aisgk-usemyapi';
        apiLabel.style.display = 'inline-flex';
        apiLabel.style.alignItems = 'center';
        apiLabel.style.gap = '4px';
        apiLabel.style.margin = '0 0 0 4px';
        const apiCheck = document.createElement('input');
        apiCheck.type = 'checkbox';
        apiCheck.checked = !!config.usemyapi;
        apiCheck.addEventListener('change', () => {
            fetch(config.myapiprefurl, {
                method: 'POST',
                headers: {'Content-Type': 'application/json'},
                body: JSON.stringify({enabled: apiCheck.checked ? 1 : 0})
            }).catch(() => {});
        });
        apiLabel.appendChild(apiCheck);
        apiLabel.appendChild(document.createTextNode(config.usemyapichecklabel || 'Dùng API của tôi'));
        wrap.appendChild(apiLabel);
    }

    const host = anchor.matches && anchor.matches('h1') ? anchor.parentNode : anchor;
    if (host && host.appendChild) {
        host.appendChild(wrap);
        return true;
    }

    anchor.after(wrap);
    return true;
};

const bindMoreMenuModals = (config) => {
    if (window.localAisgkCourseHeaderMoreBound) {
        return;
    }
    window.localAisgkCourseHeaderMoreBound = true;

    const matchAction = (link) => {
        if (!link || !link.href) {
            return null;
        }
        const href = link.getAttribute('href') || '';
        const key = link.getAttribute('data-key') || link.id || '';
        if (href.includes('/local/aisgk/upload.php') || key.includes('local_aisgk_upload')) {
            return {title: config.uploadtitle || config.uploadlabel || 'Tải SGK', url: href};
        }
        if (href.includes('/local/aisgk/topic.php') || key.includes('local_aisgk_createtopic')) {
            return {title: config.topictitle || config.topiclabel || 'Tạo chủ đề', url: href};
        }
        if (href.includes('/local/aisgk/aikeys.php')) {
            return {title: config.aikeystitle || config.aikeyslabel || 'API hệ thống', url: href};
        }
        if (href.includes('/local/aisgk/myapi.php')) {
            return {title: config.myapititle || config.myapilabel || 'API của tôi', url: href};
        }
        return null;
    };

    document.addEventListener('click', (e) => {
        const link = e.target && e.target.closest ? e.target.closest('a') : null;
        const action = matchAction(link);
        if (!action) {
            return;
        }
        e.preventDefault();
        require(['local_aisgk/openmodal'], function(modal) {
            modal.open({title: action.title, url: action.url, height: 620});
        });
    }, true);
};

export const init = (config) => {
    bindMoreMenuModals(config);
    ensureHeaderButtons(config);
    [250, 800, 1800, 3200].forEach((delay) => {
        window.setTimeout(() => ensureHeaderButtons(config), delay);
    });
};
