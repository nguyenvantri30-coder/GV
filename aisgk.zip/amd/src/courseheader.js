const ensureHeaderButtons = (config) => {
    if (document.querySelector('.local-aisgk-course-actions')) {
        return true;
    }

    const headingSelectors = [
        '#page-header .page-header-headings h1',
        '#page-header .page-header-headings',
        '.page-header-headings h1',
        '.page-header-headings',
        '.page-context-header h1',
        '.page-context-header',
        'header#page-header h1',
        '#topofscroll',
        '#region-main h1'
    ];

    let anchor = null;
    for (const selector of headingSelectors) {
        anchor = document.querySelector(selector);
        if (anchor) {
            break;
        }
    }

    if (!anchor) {
        return false;
    }

    const wrap = document.createElement('div');
    wrap.className = 'local-aisgk-course-actions';

    const openModal = (title, url, isLiteral) => {
        require(['local_aisgk/openmodal', 'core/str'], function(modal, Str) {
            if (isLiteral) {
                modal.open({title: title, url: url, height: 620});
                return;
            }

            Str.get_string(title, 'local_aisgk').then(function(resolvedTitle) {
                modal.open({title: resolvedTitle, url: url, height: 620});
            });
        });
    };

    const postMyApiPref = (enabled) => {
        if (!config.myaikeysajaxurl || !window.M || !M.cfg || !M.cfg.sesskey) {
            return;
        }
        fetch(config.myaikeysajaxurl + '&op=setpref&sesskey=' + encodeURIComponent(M.cfg.sesskey), {
            method: 'POST',
            headers: {'Content-Type': 'application/json'},
            body: JSON.stringify({enabled: enabled ? 1 : 0})
        }).catch(() => {});
    };

    if (config.canmanagebook) {
        const uploadBtn = document.createElement('button');
        uploadBtn.type = 'button';
        uploadBtn.className = 'btn btn-sm btn-primary';
        uploadBtn.textContent = config.hasbook ? (config.replacelabel || config.uploadlabel) : config.uploadlabel;
        uploadBtn.addEventListener('click', (e) => {
            e.preventDefault();
            openModal(config.uploadtitle || 'uploadbookmodaltitle', config.uploadurl, !!config.uploadtitle);
        });
        wrap.appendChild(uploadBtn);
    }

    if (config.cancreatetopic) {
        const topicBtn = document.createElement('button');
        topicBtn.type = 'button';
        topicBtn.className = 'btn btn-sm btn-secondary';
        topicBtn.textContent = config.topiclabel;
        topicBtn.addEventListener('click', (e) => {
            e.preventDefault();
            openModal(config.topictitle, config.topicurl, true);
        });
        wrap.appendChild(topicBtn);
    }

    if (config.canaikeys) {
        const aiKeysBtn = document.createElement('button');
        aiKeysBtn.type = 'button';
        aiKeysBtn.className = 'btn btn-sm btn-outline-secondary';
        aiKeysBtn.textContent = config.aikeyslabel;
        aiKeysBtn.addEventListener('click', (e) => {
            e.preventDefault();
            openModal(config.aikeystitle, config.aikeysurl, true);
        });
        wrap.appendChild(aiKeysBtn);
    }

    if (config.canmyai) {
        const myAiBtn = document.createElement('button');
        myAiBtn.type = 'button';
        myAiBtn.className = 'btn btn-sm btn-outline-secondary';
        myAiBtn.textContent = config.myaikeyslabel || 'API của tôi';
        myAiBtn.addEventListener('click', (e) => {
            e.preventDefault();
            openModal(config.myaikeystitle || 'API của tôi', config.myaikeysurl, true);
        });
        wrap.appendChild(myAiBtn);

        const label = document.createElement('label');
        label.className = 'local-aisgk-myapi-toggle';
        label.style.marginLeft = '8px';
        label.style.display = 'inline-flex';
        label.style.alignItems = 'center';
        label.style.gap = '4px';
        label.style.fontSize = '13px';

        const checkbox = document.createElement('input');
        checkbox.type = 'checkbox';
        checkbox.checked = !!config.usemyapi;
        checkbox.addEventListener('change', () => postMyApiPref(checkbox.checked));

        label.appendChild(checkbox);
        label.appendChild(document.createTextNode('Dùng API của tôi'));
        wrap.appendChild(label);
    }

    const host = anchor.matches && anchor.matches('h1') ? anchor.parentNode : anchor;
    if (host && host.appendChild) {
        host.appendChild(wrap);
        return true;
    }

    anchor.after(wrap);
    return true;
};

export const init = (config) => {
    ensureHeaderButtons(config);
    [250, 800, 1800, 3200].forEach((delay) => {
        window.setTimeout(() => ensureHeaderButtons(config), delay);
    });
};
