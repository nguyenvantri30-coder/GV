<?php
require('../../config.php');

$courseid = required_param('id', PARAM_INT);
$course = get_course($courseid);
require_login($course);
$context = context_course::instance($courseid);
require_capability('local/aisgk:createhomework', $context);
$PAGE->set_context($context);
$PAGE->set_url('/local/aisgk/myapi.php', ['id' => $courseid]);
$PAGE->set_pagelayout('embedded');
$PAGE->set_title(get_string('myapilabel', 'local_aisgk'));

global $DB, $USER;
\local_aisgk\aikey_repository::sync_usage_remaining_for_user_pay_keys((int)$USER->id);
$rows = $DB->get_records('local_aisgk_user_ai_keys', ['userid' => (int)$USER->id], 'id ASC');
if (!$rows) {
    $rows = [(object)['id'=>0,'gmail_account'=>'','api_key'=>'','category_key'=>'free','provider'=>'google','model_homework'=>'gemini-2.5-flash-lite','model_img'=>'','status'=>'active','daily_limit'=>0,'daily_used'=>0,'last_model'=>'','last_error'=>'','usage_remaining'=>0]];
}
echo $OUTPUT->header();
?>
<style>
html,body{background:#fff;height:100%;overflow:hidden}.shell{height:90vh;padding:10px;display:flex;flex-direction:column;gap:8px;font-size:13px}.toolbar{display:flex;gap:8px;align-items:center;flex-wrap:wrap}.grid{flex:1;overflow:auto;border:1px solid #cfd7e3;border-radius:8px}.btn{height:34px;padding:0 12px;border:1px solid #cbd5e1;border-radius:6px;background:#fff;cursor:pointer}.primary{background:#2563eb;color:#fff;border-color:#2563eb}.pill{background:#eef2ff;color:#3730a3;border-radius:999px;padding:6px 10px}.muted{font-size:11px;color:#667085}table{border-collapse:collapse;width:max-content;min-width:100%}th,td{border-bottom:1px solid #e5e7eb;padding:6px;background:#fff;vertical-align:middle}th{position:sticky;top:0;background:#f8fafc;z-index:2}input,select{width:100%;height:30px;border:1px solid #cbd5e1;border-radius:4px;padding:3px 5px;box-sizing:border-box}.modelcell{min-width:220px}.statcell{min-width:82px;text-align:center}.modelstates{display:flex;gap:4px;justify-content:center;flex-wrap:wrap}.mstate{display:inline-flex;align-items:center;justify-content:center;width:20px;height:20px;border-radius:999px;font-weight:bold;font-size:12px;line-height:20px}.mb-active{background:#dcfce7;color:#166534}.mb-cooldown{background:#fef3c7;color:#92400e}.mb-blocked{background:#fee2e2;color:#991b1b}.mb-unknown{background:#e5e7eb;color:#374151}.n{width:54px;text-align:center}.act{width:46px}.wide{width:220px}.key{width:280px}.small{width:100px}.err{width:300px}.x{width:28px;height:28px}.check{display:flex;align-items:center;gap:6px}.testmodel.probe-ok{background:#16a34a!important;color:#fff!important;border-color:#15803d!important}.testmodel.probe-partial{background:#bbf7d0!important;color:#166534!important;border-color:#4ade80!important}.testmodel.probe-warn{background:#fef3c7!important;color:#92400e!important;border-color:#fcd34d!important}.testmodel.probe-bad{background:#fee2e2!important;color:#991b1b!important;border-color:#fecaca!important}.testmodel.probe-unknown{background:#fff!important;color:#334155!important;border-color:#cbd5e1!important}

.local-aisgk-modal-mask{position:fixed;inset:0;background:rgba(15,23,42,.42);display:flex;align-items:center;justify-content:center;z-index:99999;padding:16px}.local-aisgk-modal{width:min(700px,96vw);max-height:82vh;background:#fff;border-radius:12px;box-shadow:0 18px 50px rgba(15,23,42,.24);display:flex;flex-direction:column;overflow:hidden;border:1px solid #e5e7eb}.local-aisgk-modal-hd{padding:9px 14px;border-bottom:1px solid #e5e7eb;background:#f8fafc}.local-aisgk-modal-title{font-weight:700;font-size:14px;color:#0f172a;line-height:1.2}.local-aisgk-modal-sub{font-size:11px;color:#64748b;margin-top:2px;line-height:1.25}.local-aisgk-modal-bd{padding:10px 14px;overflow:hidden;display:flex;flex-direction:column;gap:8px;min-height:0}.local-aisgk-modal-ft{padding:9px 14px;border-top:1px solid #e5e7eb;background:#f8fafc;display:flex;gap:8px;justify-content:flex-end;align-items:center;flex-wrap:nowrap}.local-aisgk-modal-ft .btn{height:30px;padding:0 10px;white-space:nowrap}.local-aisgk-model-list{display:flex;flex-direction:column;gap:5px;max-height:48vh;overflow-y:auto;overflow-x:hidden;border:1px solid #e5e7eb;border-radius:10px;padding:7px;background:#fff}.local-aisgk-model-row{display:flex;align-items:center;gap:7px;padding:6px 8px;border:1px solid #e5e7eb;border-radius:8px;background:#fff;cursor:pointer;min-height:30px}.local-aisgk-model-row:hover{background:#f8fafc}.local-aisgk-model-row.selected{border-color:#2563eb;background:#eff6ff}.local-aisgk-order-badge{min-width:22px;height:22px;border-radius:999px;background:#e5e7eb;color:#334155;display:inline-flex;align-items:center;justify-content:center;font-size:11px;font-weight:700;flex:0 0 auto}.local-aisgk-model-row.selected .local-aisgk-order-badge{background:#2563eb;color:#fff}.local-aisgk-model-name{font-family:ui-monospace,SFMono-Regular,Menlo,Monaco,Consolas,monospace;font-size:12px;color:#111827;word-break:break-all;line-height:1.25}.local-aisgk-selected-line{border:1px solid #dbe4ef;background:#f8fafc;border-radius:8px;padding:7px 9px;font-family:ui-monospace,SFMono-Regular,Menlo,Monaco,Consolas,monospace;font-size:11px;color:#334155;white-space:nowrap;text-overflow:ellipsis}.local-aisgk-note{font-size:11px;color:#64748b;line-height:1.25}.local-aisgk-btn-primary{background:#2563eb!important;color:#fff!important;border-color:#2563eb!important}.local-aisgk-btn-danger{background:#fff1f2!important;color:#be123c!important;border-color:#fecdd3!important}
</style>
<div class="shell">
  <div class="toolbar">
    <button class="btn primary" id="save">Lưu</button>
    <button class="btn" id="restore">Tải lại</button>
    <label class="check"><input type="checkbox" id="usemine" <?php echo get_user_preferences('local_aisgk_use_my_api',0) ? 'checked' : ''; ?>> Dùng API của tôi trước</label>
    <span class="pill" id="status">✓ Sẵn sàng</span>
    <span class="muted">Nếu API cá nhân không dùng được, hệ thống sẽ tự chuyển sang API hệ thống. Model có thể nhập nhiều giá trị, phân cách bằng dấu phẩy.</span>
  </div>
  <div class="grid"><table id="tbl"><thead><tr><th class="n">#</th><th class="act">+</th><th class="wide">Gmail</th><th class="key">API Key</th><th class="small">Category</th><th class="small">Provider</th><th class="wide">Model Text</th><th class="statcell">Status Text</th><th class="wide">Model Img</th><th class="statcell">Status Img</th><th class="small">Status</th><th class="small">Daily limit</th><th class="small">Daily used</th><th class="wide">Last model</th><th class="small">Remain</th><th class="err">Last error</th><th class="act">×</th></tr></thead><tbody>
<?php $i=0; foreach ($rows as $r): $i++; ?>
<tr><td class="n"><?php echo $i; ?></td><td><button class="x add" type="button">+</button></td><td><input type="hidden" class="id" value="<?php echo (int)$r->id; ?>"><input class="gmail" value="<?php echo s($r->gmail_account ?? ''); ?>"></td><td><input class="apikey" value="<?php echo s($r->api_key ?? ''); ?>"></td><td><select class="cat"><option value="free" <?php echo (($r->category_key ?? 'free')==='free')?'selected':''; ?>>free</option><option value="pay" <?php echo (($r->category_key ?? '')==='pay')?'selected':''; ?>>pay</option></select></td><td><select class="provider"><option value="google" <?php echo (($r->provider ?? 'google')==='google')?'selected':''; ?>>google</option><option value="shopaikey" <?php echo (($r->provider ?? '')==='shopaikey')?'selected':''; ?>>shopaikey</option></select></td><td class="modelcell"><div style="display:flex;gap:4px"><input class="modelhw" value="<?php echo s($r->model_homework ?? 'gemini-2.5-flash-lite'); ?>"><button class="x pickmodels" data-target="homework" title="Lấy/chọn model" type="button">▾</button><button class="x testmodel" data-target="homework" title="Xác minh lại Model Text" type="button">✓</button></div><input type="hidden" class="modelhwstatus" value="<?php echo s($r->model_homework_status ?? ''); ?>"></td><td class="statcell"><div class="modelstates hwbadges"></div></td><td class="modelcell"><div style="display:flex;gap:4px"><input class="modelimg" value="<?php echo s($r->model_img ?? ''); ?>"><button class="x pickmodels" data-target="img" title="Lấy/chọn model" type="button">▾</button><button class="x testmodel" data-target="img" title="Xác minh lại model Img" type="button">✓</button></div><input type="hidden" class="modelimgstatus" value="<?php echo s($r->model_img_status ?? ''); ?>"></td><td class="statcell"><div class="modelstates imgbadges"></div></td><td><select class="keystatus"><option value="active" <?php echo (($r->status ?? 'active')==='active')?'selected':''; ?>>active</option><option value="cooldown" <?php echo (($r->status ?? '')==='cooldown')?'selected':''; ?>>cooldown</option><option value="blocked" <?php echo (($r->status ?? '')==='blocked')?'selected':''; ?>>blocked</option></select></td><td><input type="number" min="0" class="dailylimit" value="<?php echo (int)($r->daily_limit ?? (($r->category_key ?? 'free') === 'pay' ? 100 : 0)); ?>"></td><td><input readonly class="dailyused" value="<?php echo (int)($r->daily_used ?? 0); ?>"></td><td><input readonly class="lastmodel" value="<?php echo s($r->last_model ?? ''); ?>"></td><td><input readonly class="remain" value="<?php echo s((string)($r->usage_remaining ?? '0')); ?>"></td><td><input class="lasterror" value="<?php echo s($r->last_error ?? ''); ?>"></td><td><button class="x del" type="button">×</button></td></tr>
<?php endforeach; ?>
</tbody></table></div>
</div>
<script>
(function(){
const ajax=<?php echo json_encode((new moodle_url('/local/aisgk/myapi_ajax.php',['id'=>$courseid]))->out(false)); ?>, sess=<?php echo json_encode(sesskey()); ?>, tbody=document.querySelector('#tbl tbody'), st=document.getElementById('status');
const esc=s=>String(s||'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#039;'}[c]));
function modelList(v){return String(v||'').split(',').map(x=>x.trim()).filter((x,i,a)=>x&&a.indexOf(x)===i)}
function statusMap(v){try{let o=JSON.parse(v||'{}');return o&&typeof o==='object'?o:{}}catch(e){return {}}}
function badgeTitle(model,st){let t=model+' - '+(st.status||'active');if(st.last_error)t+=' - '+st.last_error;if(st.status==='cooldown'&&st.cooldown_until){let r=Math.max(0,parseInt(st.cooldown_until,10)-Math.floor(Date.now()/1000));t+=' - còn '+r+'s'}return t}
function statusLetter(status){return status==='blocked'?'b':(status==='cooldown'?'c':(status==='unknown'?'?':'a'))}
function quotaText(s){return /daily|rpd|quota|limit exceeded|resource exhausted|hết credit|hết quota/i.test(String(s||''))}
function renderModelBadges(inp,hidden,box,tr){let map=statusMap(hidden.value),html='',ks=(tr&&tr.querySelector('.keystatus')?tr.querySelector('.keystatus').value:'active'),err=(tr&&tr.querySelector('.lasterror')?tr.querySelector('.lasterror').value:''),remain=parseFloat(tr&&tr.querySelector('.remain')?tr.querySelector('.remain').value:'0'),cat=(tr&&tr.querySelector('.cat')?tr.querySelector('.cat').value:''),prov=(tr&&tr.querySelector('.provider')?tr.querySelector('.provider').value:'');modelList(inp.value).forEach(m=>{let st=map[m]||{status:'unknown',last_error:''}; if(st.status==='active'&&quotaText(st.last_error)){st={...st,status:'cooldown'}} if((cat==='pay'&&prov==='shopaikey'&&!isNaN(remain)&&remain<=0&&tr.querySelector('.remain').value!=='')&&st.status!=='blocked'){st={...st,status:'cooldown',last_error:st.last_error||err||'ShopAIKey: hết credit/quota'}} if((ks==='cooldown'||ks==='blocked')&&st.status!=='blocked'){st={...st,status:ks,last_error:err||st.last_error||''}} let status=st.status||'unknown', cls=status==='blocked'?'mb-blocked':(status==='cooldown'?'mb-cooldown':(status==='unknown'?'mb-unknown':'mb-active'));html+='<span class="mstate '+cls+'" title="'+esc(badgeTitle(m,st))+'">'+statusLetter(status)+'</span>'});box.innerHTML=html}
function refreshRowBadges(tr){renderModelBadges(tr.querySelector('.modelhw'),tr.querySelector('.modelhwstatus'),tr.querySelector('.hwbadges'),tr);renderModelBadges(tr.querySelector('.modelimg'),tr.querySelector('.modelimgstatus'),tr.querySelector('.imgbadges'),tr)}
function refreshBadges(){[...tbody.querySelectorAll('tr')].forEach(refreshRowBadges)}
function renum(){[...tbody.querySelectorAll('tr')].forEach((tr,i)=>tr.children[0].textContent=i+1)}
function row(r={}){let tr=document.createElement('tr');tr.innerHTML='<td class="n"></td><td><button class="x add" type="button">+</button></td><td><input type="hidden" class="id" value="'+esc(r.id||'')+'"><input class="gmail" value="'+esc(r.gmail_account||'')+'"></td><td><input class="apikey" value="'+esc(r.api_key||'')+'"></td><td><select class="cat"><option value="free">free</option><option value="pay">pay</option></select></td><td><select class="provider"><option value="google">google</option><option value="shopaikey">shopaikey</option></select></td><td class="modelcell"><div style="display:flex;gap:4px"><input class="modelhw" value="'+esc(r.model_homework||'gemini-2.5-flash-lite')+'"><button class="x pickmodels" data-target="homework" title="Lấy/chọn model" type="button">▾</button><button class="x testmodel" data-target="homework" title="Xác minh lại Model Text" type="button">✓</button></div><input type="hidden" class="modelhwstatus" value="'+esc(r.model_homework_status||'')+'"></td><td class="statcell"><div class="modelstates hwbadges"></div></td><td class="modelcell"><div style="display:flex;gap:4px"><input class="modelimg" value="'+esc(r.model_img||'')+'"><button class="x pickmodels" data-target="img" title="Lấy/chọn model" type="button">▾</button><button class="x testmodel" data-target="img" title="Xác minh lại model Img" type="button">✓</button></div><input type="hidden" class="modelimgstatus" value="'+esc(r.model_img_status||'')+'"></td><td class="statcell"><div class="modelstates imgbadges"></div></td><td><select class="keystatus"><option value="active">active</option><option value="cooldown">cooldown</option><option value="blocked">blocked</option></select></td><td><input type="number" min="0" class="dailylimit" value="'+esc(r.daily_limit||0)+'"></td><td><input readonly class="dailyused" value="'+esc(r.daily_used||0)+'"></td><td><input readonly class="lastmodel" value="'+esc(r.last_model||'')+'"></td><td><input readonly class="remain" value="'+esc(r.usage_remaining||0)+'"></td><td><input class="lasterror" value="'+esc(r.last_error||'')+'"></td><td><button class="x del" type="button">×</button></td>'; tr.querySelector('.cat').value=r.category_key||'free'; tr.querySelector('.provider').value=r.provider||'google'; tr.querySelector('.keystatus').value=r.status||'active'; refreshRowBadges(tr); return tr;}
function rows(){return [...tbody.querySelectorAll('tr')].map(tr=>({id:tr.querySelector('.id').value,gmail_account:tr.querySelector('.gmail').value.trim(),api_key:tr.querySelector('.apikey').value.trim(),category_key:tr.querySelector('.cat').value,provider:tr.querySelector('.provider').value,model_homework:tr.querySelector('.modelhw').value.trim(),model_img:tr.querySelector('.modelimg').value.trim(),model_homework_status:tr.querySelector('.modelhwstatus').value,model_img_status:tr.querySelector('.modelimgstatus').value,status:tr.querySelector('.keystatus').value,daily_limit:tr.querySelector('.dailylimit').value,last_error:tr.querySelector('.lasterror').value.trim()})).filter(r=>r.gmail_account||r.api_key||r.model_homework||r.model_img||r.last_error)}
async function post(op,data){let res=await fetch(ajax+'&op='+encodeURIComponent(op)+'&sesskey='+encodeURIComponent(sess),{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify(data||{})});let txt=await res.text(),j;try{j=JSON.parse(txt)}catch(e){}if(!res.ok||!j||j.ok===false)throw new Error((j&&j.error)||txt||'Yêu cầu thất bại');return j}
function render(rs){loadCapabilitiesFromRows(rs||[]);tbody.innerHTML='';(rs&&rs.length?rs:[{}]).forEach(r=>tbody.appendChild(row(r)));renum();refreshBadges();updateAllCheckButtons();st.textContent='✓ Xong'}
tbody.addEventListener('input',e=>{if(['modelhw','modelimg','remain','lasterror'].some(c=>e.target.classList.contains(c)))refreshRowBadges(e.target.closest('tr'))});
tbody.addEventListener('change',e=>{if(['keystatus','cat','provider'].some(c=>e.target.classList.contains(c)))refreshRowBadges(e.target.closest('tr'))});


function showMessageBox(message,title){
    return new Promise(resolve=>{
        const mask=document.createElement('div');
        mask.className='local-aisgk-modal-mask';
        mask.innerHTML='<div class="local-aisgk-modal" style="max-width:min(860px,94vw);max-height:84vh;display:flex;flex-direction:column;overflow:hidden"><div class="local-aisgk-modal-hd" style="flex:0 0 auto;background:#fff;z-index:1;border-bottom:1px solid #e5e7eb"><div class="local-aisgk-modal-title">'+esc(title||'Thông báo')+'</div></div><div class="local-aisgk-modal-bd" style="white-space:pre-wrap;line-height:1.45;min-height:0;max-height:64vh;overflow-y:scroll;overflow-x:auto;font-family:ui-monospace,SFMono-Regular,Menlo,Consolas,monospace;font-size:12px;background:#f8fafc;border:1px solid #e5e7eb;border-radius:6px;margin:10px;padding:10px">'+esc(message||'')+'</div><div class="local-aisgk-modal-ft" style="flex:0 0 auto"><button type="button" class="btn local-aisgk-btn-primary">Đóng</button></div></div>';
        document.body.appendChild(mask);
        const close=()=>{mask.remove();resolve();};
        mask.querySelector('button').onclick=close;
        mask.addEventListener('click',e=>{if(e.target===mask)close();});
    });
}
function showModelPickerDialog(opts){
    opts=opts||{};
    const list=(opts.list||[]).slice();
    const recommended=modelList(opts.recommended||'').filter(m=>list.includes(m));
    let selected=modelList(opts.current||'').filter(m=>list.includes(m));
    if(!selected.length && recommended.length) selected=recommended.slice();
    return new Promise(resolve=>{
        const mask=document.createElement('div');
        mask.className='local-aisgk-modal-mask';
        const title=opts.title||'Chọn model';
        const subtitle=opts.subtitle||'Chọn theo thứ tự ưu tiên. Model chọn trước sẽ được gọi trước.';
        mask.innerHTML='<div class="local-aisgk-modal"><div class="local-aisgk-modal-hd"><div class="local-aisgk-modal-title">'+esc(title)+'</div><div class="local-aisgk-modal-sub">'+esc(subtitle)+'</div></div><div class="local-aisgk-modal-bd"><div class="local-aisgk-selected-line"></div><div class="local-aisgk-model-list"></div><div class="local-aisgk-note">Bấm model để chọn/bỏ chọn. Thứ tự bấm là thứ tự ưu tiên.</div></div><div class="local-aisgk-modal-ft"><button type="button" class="btn use-rec">Dùng khuyến nghị</button><button type="button" class="btn clear-sel">Bỏ chọn</button><button type="button" class="btn cancel">Hủy</button><button type="button" class="btn local-aisgk-btn-primary save">Lưu</button></div></div>';
        document.body.appendChild(mask);
        const listbox=mask.querySelector('.local-aisgk-model-list');
        const selectedLine=mask.querySelector('.local-aisgk-selected-line');
        function syncSelectedLine(){selectedLine.textContent=selected.length?selected.join(','):'Chưa chọn model';}
        function renderList(){
            listbox.innerHTML='';
            list.forEach(m=>{
                const idx=selected.indexOf(m);
                const row=document.createElement('div');
                row.className='local-aisgk-model-row'+(idx>=0?' selected':'');
                row.innerHTML='<span class="local-aisgk-order-badge">'+(idx>=0?idx+1:'')+'</span><span class="local-aisgk-model-name">'+esc(m)+'</span>';
                row.onclick=()=>{
                    const i=selected.indexOf(m);
                    if(i>=0) selected.splice(i,1); else selected.push(m);
                    syncSelectedLine(); renderList();
                };
                listbox.appendChild(row);
            });
        }
        function close(val){mask.remove();resolve(val);}
        mask.querySelector('.use-rec').onclick=()=>{selected=(recommended.length?recommended:list).slice();syncSelectedLine();renderList();};
        mask.querySelector('.clear-sel').onclick=()=>{selected=[];syncSelectedLine();renderList();};
        mask.querySelector('.cancel').onclick=()=>close(null);
        mask.querySelector('.save').onclick=()=>close(selected.join(','));
        mask.addEventListener('click',e=>{if(e.target===mask)close(null);});
        syncSelectedLine(); renderList();
    });
}

function inputForTarget(tr,target){return target==='img'?tr.querySelector('.modelimg'):tr.querySelector('.modelhw')}

const capabilityCache={};
function clearCapabilityCache(){Object.keys(capabilityCache).forEach(k=>delete capabilityCache[k]);}
function capKey(provider,model){return String(provider||'google').toLowerCase()+'||'+String(model||'').trim().toLowerCase()}
function capNeeded(target){return target==='img'?'image_output':'text_output'}
function rememberProbeResult(probe){
    probe=probe||{};
    let provider=String(probe.provider||'').toLowerCase(), model=String(probe.model||'').trim();
    if(!provider||!model)return;
    let key=capKey(provider,model), old=capabilityCache[key]||{};
    capabilityCache[key]={
        provider:provider,
        model:model,
        text_output:!!(probe.text_output||old.text_output),
        image_output:!!(probe.image_output||old.image_output),
        image_transport:probe.image_transport||old.image_transport||'',
        checked_at:probe.checked_at||old.checked_at||Math.floor(Date.now()/1000),
        source:probe.source||old.source||'probe',
        last_ok:probe.ok!==undefined?!!probe.ok:!!old.last_ok,
        last_error_kind:probe.error_kind||old.last_error_kind||'',
        last_message:probe.message||old.last_message||''
    };
}
function loadCapabilitiesFromRows(rs){
    clearCapabilityCache();
    (rs||[]).forEach(r=>{
        let provider=String(r.provider||'google').toLowerCase();
        let raw=String(r.models_cache_json||'').trim();
        if(!raw)return;
        try{
            let cache=JSON.parse(raw);
            let caps=cache&&cache.capabilities&&typeof cache.capabilities==='object'?cache.capabilities:{};
            Object.keys(caps).forEach(model=>{
                let e=caps[model]||{};
                let p=String(e.provider||provider||'google').toLowerCase();
                let key=capKey(p,model), old=capabilityCache[key]||{};
                capabilityCache[key]={
                    provider:p,
                    model:model,
                    text_output:!!(e.text_output||old.text_output),
                    image_output:!!(e.image_output||old.image_output),
                    image_transport:e.image_transport||old.image_transport||'',
                    checked_at:e.checked_at||old.checked_at||0,
                    source:e.source||old.source||'db_cache',
                    last_ok:e.last_ok!==undefined?!!e.last_ok:!!old.last_ok,
                    last_error_kind:e.last_error_kind||old.last_error_kind||'',
                    last_message:e.last_message||old.last_message||''
                };
            });
        }catch(e){}
    });
}
function targetButtonForRow(tr,target){
    return tr.querySelector('.testmodel[data-target="'+target+'"]');
}
function statusMapForTarget(tr,target){
    let hidden=target==='img'?tr.querySelector('.modelimgstatus'):tr.querySelector('.modelhwstatus');
    return hidden?statusMap(hidden.value):{};
}
function updateCheckButtonState(tr,target){
    let btn=targetButtonForRow(tr,target); if(!btn)return;
    btn.classList.remove('probe-ok','probe-partial','probe-warn','probe-bad','probe-unknown');
    let provider=(tr.querySelector('.provider')?tr.querySelector('.provider').value:'google');
    let models=modelList(inputForTarget(tr,target).value);
    if(!models.length){btn.classList.add('probe-unknown');btn.title='Chưa có model để test';return;}
    let need=capNeeded(target), verified=[], missing=[], transports=[];
    models.forEach(m=>{
        let entry=capabilityCache[capKey(provider,m)];
        if(entry&&entry[need]){
            verified.push(m);
            if(target==='img'&&entry.image_transport)transports.push(m+': '+entry.image_transport);
        }else{
            missing.push(m);
        }
    });
    if(verified.length===models.length){
        btn.classList.add('probe-ok');
        btn.title='Đã xác minh toàn bộ model cho '+target+(transports.length?' ('+transports.join('; ')+')':'');
    }else if(verified.length>0){
        btn.classList.add('probe-partial');
        btn.title='Đã xác minh '+verified.length+'/'+models.length+': '+verified.join(', ')+(missing.length?' | Chưa xác minh: '+missing.join(', '):'');
    }else{
        btn.classList.add('probe-bad');
        btn.title='Chưa có model nào trong ô này được xác minh capability cho '+target;
    }
}
function updateAllCheckButtons(){
    [...tbody.querySelectorAll('tr')].forEach(tr=>['homework','img'].forEach(t=>updateCheckButtonState(tr,t)));
}

async function testModels(tr,target){
    let key=tr.querySelector('.apikey').value.trim(), provider=tr.querySelector('.provider').value;
    let id=parseInt(tr.querySelector('.id').value||'0',10)||0;
    let models=modelList(inputForTarget(tr,target).value);
    if(!key){await showMessageBox('Chưa nhập API key','Thiếu API key');return}
    if(!models.length){await showMessageBox('Chưa nhập model để test','Thiếu model');return}
    let group=target==='img'?'img':'homework';
    let lines=[];
    if(!id){lines.push('⚠ Dòng key này chưa có ID DB. Kết quả vẫn hiển thị nhưng chưa lưu cache DB; hãy bấm Lưu rồi test lại nếu muốn lưu.');}
    st.textContent='Đang test '+models.length+' model...';
    let batch=null;
    try{
        batch=await post('probemodels',{id:id,api_key:key,provider:provider,models:models,feature:group,force:1});
    }catch(e){
        // Fallback giữ tương thích nếu server cũ chưa có op=probemodels.
        batch={results:[]};
        for(let i=0;i<models.length;i++){
            let m=models[i];
            try{batch.results.push(await post('probemodel',{id:id,api_key:key,provider:provider,model:m,feature:group,force:1}));}
            catch(ex){batch.results.push({probe:{model:m,provider:provider,feature:group,ok:false,error_kind:'error',message:ex.message},saved:false,status_updates:{}});}
        }
    }
    (batch.results||[]).forEach(j=>{
        let r=j.probe||{};
        if(j.status_updates){
            
            if(j.status_updates.model_homework_status!==undefined)tr.querySelector('.modelhwstatus').value=j.status_updates.model_homework_status||'';
            if(j.status_updates.model_img_status!==undefined)tr.querySelector('.modelimgstatus').value=j.status_updates.model_img_status||'';
            if(j.status_updates.last_error!==undefined)tr.querySelector('.lasterror').value=j.status_updates.last_error||'';
            refreshRowBadges(tr);
        }
        rememberProbeResult(r);
        updateAllCheckButtons();
        let icon=r.ok?'✅':(r.error_kind==='quota'||r.error_kind==='cooldown'?'⏳':(r.error_kind==='blocked'?'⛔':'⚠️'));
        let caps=[];
        if(r.text_output)caps.push('text_output');
        if(r.image_output)caps.push('image_output');
        if(r.image_transport)caps.push('transport='+r.image_transport);
        if(!caps.length)caps.push('no_capability_confirmed');
        let flags=[];
        flags.push(r.source||'');
        if(r.skipped)flags.push('bỏ qua probe');
        if(r.error_kind)flags.push(r.error_kind);
        flags.push(j.saved?'đã lưu DB':'chưa lưu DB');
        lines.push(icon+' '+(r.model||'')+' → '+caps.join(' + ')+' | '+flags.filter(Boolean).join(' | '));
        if(r.message)lines.push('   '+r.message);
    });
    st.textContent='✓ Test xong';
    await showMessageBox(lines.join('\n'),'Kết quả test capability');
}


async function chooseModels(tr,target){
    let key=tr.querySelector('.apikey').value.trim(), provider=tr.querySelector('.provider').value;
    if(!key){await showMessageBox('Chưa nhập API key','Thiếu API key');return}
    st.textContent='Đang lấy danh sách model...';
    let j=await post('models',{api_key:key,provider:provider});
    let group=target==='img'?'img':'homework';
    let list=(j.models&&j.models[group])?j.models[group]:[];
    let rec=(j.recommended&&j.recommended[group])?j.recommended[group]:'';
    if(!list.length){await showMessageBox('Không tìm thấy model phù hợp cho '+group,'Không có model');st.textContent='Không có model';return}
    let label=group==='img'?'Model Img':'Model Text';
    let val=await showModelPickerDialog({
        title:'Chọn '+label,
        subtitle:'Chọn model theo thứ tự ưu tiên. Model chọn trước sẽ được hệ thống gọi trước.',
        list:list,
        recommended:rec,
        current:inputForTarget(tr,target).value
    });
    if(val===null){st.textContent='Đã hủy';return}
    val=modelList(val).join(',');
    if(val){ inputForTarget(tr,target).value=val; refreshRowBadges(tr); updateAllCheckButtons(); st.textContent='✓ Đã chọn '+label; }
}


tbody.addEventListener('click',async e=>{if(e.target.classList.contains('pickmodels')){try{await chooseModels(e.target.closest('tr'),e.target.dataset.target||'img')}catch(err){st.textContent='Lỗi: '+err.message} return;} if(e.target.classList.contains('testmodel')){try{await testModels(e.target.closest('tr'),e.target.dataset.target||'img')}catch(err){st.textContent='Lỗi: '+err.message} return;} if(e.target.classList.contains('add')){e.target.closest('tr').after(row({}));renum();updateAllCheckButtons()} if(e.target.classList.contains('del')){e.target.closest('tr').remove(); if(!tbody.children.length)tbody.appendChild(row({})); renum();updateAllCheckButtons()}});
document.getElementById('save').onclick=async()=>{try{st.textContent='Đang lưu';let j=await post('save',{rows:rows()});render(j.rows)}catch(e){st.textContent='Lỗi: '+e.message}};

const initialRows=<?php echo json_encode(array_map(function($r){return ['provider'=>(string)($r->provider ?? 'google'),'models_cache_json'=>(string)($r->models_cache_json ?? ''),'models_cache_at'=>(int)($r->models_cache_at ?? 0)];}, array_values($rows)), JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES); ?>;
loadCapabilitiesFromRows(initialRows||[]);
updateAllCheckButtons();
refreshBadges();
document.getElementById('restore').onclick=async()=>{try{st.textContent='Đang tải';let j=await post('restore',{});render(j.rows);document.getElementById('usemine').checked=!!j.enabled}catch(e){st.textContent='Lỗi: '+e.message}};
document.getElementById('usemine').onchange=async e=>{try{await post('preference',{enabled:e.target.checked?1:0});st.textContent=e.target.checked?'Sẽ ưu tiên API của tôi':'Sẽ dùng API hệ thống trước'}catch(err){st.textContent='Lỗi: '+err.message}};
})();
</script>
<?php echo $OUTPUT->footer();
