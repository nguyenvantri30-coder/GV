<?php
require('../../config.php');

$courseid = required_param('id', PARAM_INT);
$course = get_course($courseid);
require_login($course);
$context = context_course::instance($courseid);
require_capability('local/aisgk:createhomework', $context);
$PAGE->set_context($context);
$PAGE->set_url('/local/aisgk/myapi.php', ['id' => $courseid]);
$PAGE->set_pagelayout('embedded');
$PAGE->set_title('API của tôi');

global $DB, $USER;
\local_aisgk\aikey_repository::sync_usage_remaining_for_user_pay_keys((int)$USER->id);
$rows = $DB->get_records('local_aisgk_user_ai_keys', ['userid' => (int)$USER->id], 'id ASC');
if (!$rows) {
    $rows = [(object)['id'=>0,'gmail_account'=>'','api_key'=>'','category_key'=>'free','provider'=>'google','model_scan'=>'gemini-flash-latest','model_homework'=>'gemini-flash-latest','status'=>'active','limit_rpm'=>8,'limit_rpd'=>200,'limit_tpm'=>200000,'used_rpm'=>0,'used_rpd'=>0,'used_tpm'=>0,'last_model'=>'','last_tokens'=>0,'remain_calls_est'=>0,'last_error'=>'','usage_remaining'=>0]];
}
function local_aisgk_myapi_dt($t) { return ((int)$t > 0) ? userdate((int)$t, '%Y-%m-%dT%H:%M') : ''; }
echo $OUTPUT->header();
?>
<style>
html,body{background:#fff;height:100%;overflow:hidden}.shell{height:90vh;padding:10px;display:flex;flex-direction:column;gap:8px;font-size:13px}.toolbar{display:flex;gap:8px;align-items:center;flex-wrap:wrap}.grid{flex:1;overflow:auto;border:1px solid #cfd7e3;border-radius:8px}.btn{height:34px;padding:0 12px;border:1px solid #cbd5e1;border-radius:6px;background:#fff;cursor:pointer}.primary{background:#2563eb;color:#fff;border-color:#2563eb}.pill{background:#eef2ff;color:#3730a3;border-radius:999px;padding:6px 10px}table{border-collapse:collapse;width:max-content;min-width:100%}th,td{border-bottom:1px solid #e5e7eb;padding:6px;background:#fff}th{position:sticky;top:0;background:#f8fafc}input,select{width:100%;height:30px;border:1px solid #cbd5e1;border-radius:4px;padding:3px 5px;box-sizing:border-box}.muted{font-size:11px;color:#667085}.small{width:70px}.wide{width:220px}.key{width:280px}.num{width:90px}.x{width:28px;height:28px}.check{display:flex;align-items:center;gap:6px}
</style>
<div class="shell">
  <div class="toolbar">
    <button class="btn primary" id="save">Save</button>
    <button class="btn" id="restore">Restore</button>
    <label class="check"><input type="checkbox" id="usemine" <?php echo get_user_preferences('local_aisgk_use_my_api',0) ? 'checked' : ''; ?>> Dùng API của tôi</label>
    <span class="pill" id="status">✓ Ready</span>
    <span class="muted">Remain chỉ đồng bộ khi mở/restore popup; quota dùng Limit RPM/RPD/TPM.</span>
  </div>
  <div class="grid"><table id="tbl"><thead><tr><th>#</th><th>+</th><th class="wide">Gmail</th><th class="key">API Key</th><th>Category</th><th>Provider</th><th class="wide">Model Scan</th><th class="wide">Model Homework</th><th>Status</th><th class="num">RPM limit</th><th class="num">RPD limit</th><th class="num">TPM limit</th><th class="num">Used RPM</th><th class="num">Used RPD</th><th class="num">Used TPM</th><th>Last model</th><th>Last tokens</th><th>~ Calls</th><th>Remain</th><th class="wide">Last error</th><th>×</th></tr></thead><tbody>
<?php $i=0; foreach ($rows as $r): $i++; ?>
<tr><td><?php echo $i; ?></td><td><button class="x add" type="button">+</button></td><td><input type="hidden" class="id" value="<?php echo (int)$r->id; ?>"><input class="gmail" value="<?php echo s($r->gmail_account ?? ''); ?>"></td><td><input class="apikey" value="<?php echo s($r->api_key ?? ''); ?>"></td><td><select class="cat"><option value="free" <?php echo (($r->category_key ?? 'free')==='free')?'selected':''; ?>>free</option><option value="pay" <?php echo (($r->category_key ?? '')==='pay')?'selected':''; ?>>pay</option></select></td><td><select class="provider"><option value="google" <?php echo (($r->provider ?? 'google')==='google')?'selected':''; ?>>google</option><option value="shopaikey" <?php echo (($r->provider ?? '')==='shopaikey')?'selected':''; ?>>shopaikey</option></select></td><td><input class="modelscan" value="<?php echo s($r->model_scan ?? 'gemini-flash-latest'); ?>"></td><td><input class="modelhw" value="<?php echo s($r->model_homework ?? 'gemini-flash-latest'); ?>"></td><td><select class="status"><option value="active" <?php echo (($r->status ?? 'active')==='active')?'selected':''; ?>>active</option><option value="cooldown" <?php echo (($r->status ?? '')==='cooldown')?'selected':''; ?>>cooldown</option><option value="blocked" <?php echo (($r->status ?? '')==='blocked')?'selected':''; ?>>blocked</option></select></td><td><input type="number" class="limitrpm" value="<?php echo (int)($r->limit_rpm ?? 8); ?>"></td><td><input type="number" class="limitrpd" value="<?php echo (int)($r->limit_rpd ?? 200); ?>"></td><td><input type="number" class="limittpm" value="<?php echo (int)($r->limit_tpm ?? 200000); ?>"></td><td><input readonly class="usedrpm" value="<?php echo (int)($r->used_rpm ?? 0); ?>"></td><td><input readonly class="usedrpd" value="<?php echo (int)($r->used_rpd ?? 0); ?>"></td><td><input readonly class="usedtpm" value="<?php echo (int)($r->used_tpm ?? 0); ?>"></td><td><input readonly class="lastmodel" value="<?php echo s($r->last_model ?? ''); ?>"></td><td><input readonly class="lasttokens" value="<?php echo (int)($r->last_tokens ?? 0); ?>"></td><td><input readonly class="calls" value="<?php echo (int)($r->remain_calls_est ?? 0); ?>"></td><td><input readonly class="remain" value="<?php echo s((string)($r->usage_remaining ?? '0')); ?>"></td><td><input class="lasterror" value="<?php echo s($r->last_error ?? ''); ?>"></td><td><button class="x del" type="button">×</button></td></tr>
<?php endforeach; ?>
</tbody></table></div>
</div>
<script>
(function(){
const ajax=<?php echo json_encode((new moodle_url('/local/aisgk/myapi_ajax.php',['id'=>$courseid]))->out(false)); ?>, sess=<?php echo json_encode(sesskey()); ?>, tbody=document.querySelector('#tbl tbody'), st=document.getElementById('status');
const esc=s=>String(s||'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#039;'}[c]));
function renum(){[...tbody.querySelectorAll('tr')].forEach((tr,i)=>tr.children[0].textContent=i+1)}
function row(r={}){let tr=document.createElement('tr');tr.innerHTML='<td></td><td><button class="x add" type="button">+</button></td><td><input type="hidden" class="id" value="'+esc(r.id||'')+'"><input class="gmail" value="'+esc(r.gmail_account||'')+'"></td><td><input class="apikey" value="'+esc(r.api_key||'')+'"></td><td><select class="cat"><option value="free">free</option><option value="pay">pay</option></select></td><td><select class="provider"><option value="google">google</option><option value="shopaikey">shopaikey</option></select></td><td><input class="modelscan" value="'+esc(r.model_scan||'gemini-flash-latest')+'"></td><td><input class="modelhw" value="'+esc(r.model_homework||'gemini-flash-latest')+'"></td><td><select class="status"><option value="active">active</option><option value="cooldown">cooldown</option><option value="blocked">blocked</option></select></td><td><input type="number" class="limitrpm" value="'+esc(r.limit_rpm||8)+'"></td><td><input type="number" class="limitrpd" value="'+esc(r.limit_rpd||200)+'"></td><td><input type="number" class="limittpm" value="'+esc(r.limit_tpm||200000)+'"></td><td><input readonly class="usedrpm" value="'+esc(r.used_rpm||0)+'"></td><td><input readonly class="usedrpd" value="'+esc(r.used_rpd||0)+'"></td><td><input readonly class="usedtpm" value="'+esc(r.used_tpm||0)+'"></td><td><input readonly class="lastmodel" value="'+esc(r.last_model||'')+'"></td><td><input readonly class="lasttokens" value="'+esc(r.last_tokens||0)+'"></td><td><input readonly class="calls" value="'+esc(r.remain_calls_est||0)+'"></td><td><input readonly class="remain" value="'+esc(r.usage_remaining||0)+'"></td><td><input class="lasterror" value="'+esc(r.last_error||'')+'"></td><td><button class="x del" type="button">×</button></td>'; tr.querySelector('.cat').value=r.category_key||'free'; tr.querySelector('.provider').value=r.provider||'google'; tr.querySelector('.status').value=r.status||'active'; return tr;}
function rows(){return [...tbody.querySelectorAll('tr')].map(tr=>({id:tr.querySelector('.id').value,gmail_account:tr.querySelector('.gmail').value.trim(),api_key:tr.querySelector('.apikey').value.trim(),category_key:tr.querySelector('.cat').value,provider:tr.querySelector('.provider').value,model_scan:tr.querySelector('.modelscan').value.trim(),model_homework:tr.querySelector('.modelhw').value.trim(),status:tr.querySelector('.status').value,limit_rpm:tr.querySelector('.limitrpm').value,limit_rpd:tr.querySelector('.limitrpd').value,limit_tpm:tr.querySelector('.limittpm').value,last_error:tr.querySelector('.lasterror').value.trim()})).filter(r=>r.gmail_account||r.api_key||r.model_scan||r.model_homework||r.last_error)}
async function post(op,data){let res=await fetch(ajax+'&op='+encodeURIComponent(op)+'&sesskey='+encodeURIComponent(sess),{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify(data||{})});let txt=await res.text(),j;try{j=JSON.parse(txt)}catch(e){}if(!res.ok||!j||j.ok===false)throw new Error((j&&j.error)||txt||'Request failed');return j}
function render(rs){tbody.innerHTML='';(rs&&rs.length?rs:[{}]).forEach(r=>tbody.appendChild(row(r)));renum();st.textContent='✓ Done'}
tbody.addEventListener('click',e=>{if(e.target.classList.contains('add')){e.target.closest('tr').after(row({}));renum()} if(e.target.classList.contains('del')){e.target.closest('tr').remove(); if(!tbody.children.length)tbody.appendChild(row({})); renum()}});
document.getElementById('save').onclick=async()=>{try{st.textContent='Saving';let j=await post('save',{rows:rows()});render(j.rows)}catch(e){st.textContent='Failed: '+e.message}};
document.getElementById('restore').onclick=async()=>{try{st.textContent='Loading';let j=await post('restore',{});render(j.rows);document.getElementById('usemine').checked=!!j.enabled}catch(e){st.textContent='Failed: '+e.message}};
document.getElementById('usemine').onchange=async e=>{try{await post('preference',{enabled:e.target.checked?1:0});st.textContent=e.target.checked?'Đang dùng API của tôi':'Đang dùng API hệ thống'}catch(err){st.textContent='Failed: '+err.message}};
})();
</script>
<?php echo $OUTPUT->footer();
