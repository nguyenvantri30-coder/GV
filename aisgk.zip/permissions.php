<?php
// ALSM role/capability permission management.
require_once(__DIR__ . '/../../config.php');

$localaisgkmodal = optional_param('modal', 0, PARAM_BOOL);
function local_aisgk_modal_page_open($title = '') {
    global $OUTPUT, $localaisgkmodal;
    if ($localaisgkmodal) {
        echo '<!doctype html><html><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>' . s($title) . '</title><style>html,body{margin:0!important;padding:0!important;background:#fff!important;overflow:hidden;font-family:Arial,Helvetica,sans-serif}.modal-clean-wrap{padding:10px;box-sizing:border-box;width:100%;height:100vh;overflow:auto}.btn,.local-aisgk-modal .btn,button,input[type=submit]{display:inline-flex!important;align-items:center!important;justify-content:center!important;height:34px!important;line-height:1!important;padding:0 12px!important;box-sizing:border-box!important;vertical-align:middle!important}table{border-collapse:collapse}.muted{color:#64748b}.table-responsive{overflow:auto}</style></head><body><div class="modal-clean-wrap">';
    } else {
        local_aisgk_modal_page_open($PAGE->title ?? '');
    }
}
function local_aisgk_modal_page_close() {
    global $OUTPUT, $localaisgkmodal;
    if ($localaisgkmodal) {
        echo '</div></body></html>';
    } else {
        local_aisgk_modal_page_close();
    }
}

require_once($CFG->libdir . '/adminlib.php');
require_once($CFG->libdir . '/accesslib.php');

global $DB, $USER;

$context = context_system::instance();
require_login();
require_capability('moodle/site:config', $context);

$PAGE->set_context($context);
$PAGE->set_url(new moodle_url('/local/aisgk/permissions.php'));
$PAGE->set_title('Phân quyền');
$PAGE->set_heading('');
$PAGE->set_pagelayout('admin');
$PAGE->set_cacheable(false);

$action = optional_param('action', '', PARAM_ALPHA);

function local_aisgk_perm_caps(): array {
    global $DB;
    $records = $DB->get_records_select('capabilities', $DB->sql_like('name', ':prefix', false), ['prefix' => 'local/aisgk:%'], 'name ASC');
    if ($records) {
        $caps = [];
        foreach ($records as $record) {
            if (!empty($record->name)) {
                $caps[] = (string)$record->name;
            }
        }
        return $caps;
    }
    $accessfile = __DIR__ . '/db/access.php';
    $capabilities = [];
    if (is_readable($accessfile)) {
        include($accessfile);
        if (is_array($capabilities)) {
            return array_keys($capabilities);
        }
    }
    return [];
}

function local_aisgk_perm_roles(): array {
    global $DB;
    return array_values($DB->get_records('role', null, 'sortorder ASC, shortname ASC'));
}

function local_aisgk_perm_get(int $roleid, string $capability, context_system $context): int {
    global $DB;
    $record = $DB->get_record('role_capabilities', [
        'roleid' => $roleid,
        'contextid' => $context->id,
        'capability' => $capability,
    ], 'permission', IGNORE_MISSING);
    return $record ? (int)$record->permission : CAP_INHERIT;
}

function local_aisgk_perm_label(int $permission): string {
    switch ($permission) {
        case CAP_ALLOW:
            return 'Cho phép';
        case CAP_PREVENT:
            return 'Chặn';
        case CAP_PROHIBIT:
            return 'Cấm tuyệt đối';
        case CAP_INHERIT:
        default:
            return 'Kế thừa';
    }
}

function local_aisgk_perm_parse($value): int {
    $value = trim((string)$value);
    $lower = core_text::strtolower($value);
    if ($value === (string)CAP_ALLOW || in_array($lower, ['allow', 'cho phép', 'cho phep'], true)) {
        return CAP_ALLOW;
    }
    if ($value === (string)CAP_PREVENT || in_array($lower, ['prevent', 'chặn', 'chan'], true)) {
        return CAP_PREVENT;
    }
    if ($value === (string)CAP_PROHIBIT || in_array($lower, ['prohibit', 'cấm tuyệt đối', 'cam tuyet doi'], true)) {
        return CAP_PROHIBIT;
    }
    return CAP_INHERIT;
}

function local_aisgk_perm_cell($value): string {
    return (string)($value ?? '');
}

function local_aisgk_perm_xlsx_col(int $index): string {
    $name = '';
    while ($index >= 0) {
        $name = chr(65 + ($index % 26)) . $name;
        $index = intdiv($index, 26) - 1;
    }
    return $name;
}

function local_aisgk_perm_xlsx_xml($value): string {
    return htmlspecialchars((string)($value ?? ''), ENT_XML1 | ENT_COMPAT, 'UTF-8');
}

function local_aisgk_perm_xlsx_export_rows(array $rows, string $filename): void {
    $tmp = make_temp_directory('local_aisgk') . '/' . uniqid('perm_', true) . '.xlsx';
    $zip = new ZipArchive();
    if ($zip->open($tmp, ZipArchive::CREATE | ZipArchive::OVERWRITE) !== true) {
        throw new moodle_exception('Không tạo được file Excel tạm.');
    }
    $zip->addFromString('[Content_Types].xml', '<?xml version="1.0" encoding="UTF-8" standalone="yes"?>'
        . '<Types xmlns="http://schemas.openxmlformats.org/package/2006/content-types">'
        . '<Default Extension="rels" ContentType="application/vnd.openxmlformats-package.relationships+xml"/>'
        . '<Default Extension="xml" ContentType="application/xml"/>'
        . '<Override PartName="/xl/workbook.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet.main+xml"/>'
        . '<Override PartName="/xl/worksheets/sheet1.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.worksheet+xml"/>'
        . '</Types>');
    $zip->addFromString('_rels/.rels', '<?xml version="1.0" encoding="UTF-8" standalone="yes"?>'
        . '<Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships">'
        . '<Relationship Id="rId1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/officeDocument" Target="xl/workbook.xml"/>'
        . '</Relationships>');
    $zip->addFromString('xl/_rels/workbook.xml.rels', '<?xml version="1.0" encoding="UTF-8" standalone="yes"?>'
        . '<Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships">'
        . '<Relationship Id="rId1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/worksheet" Target="worksheets/sheet1.xml"/>'
        . '</Relationships>');
    $zip->addFromString('xl/workbook.xml', '<?xml version="1.0" encoding="UTF-8" standalone="yes"?>'
        . '<workbook xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main" xmlns:r="http://schemas.openxmlformats.org/officeDocument/2006/relationships">'
        . '<sheets><sheet name="Sheet1" sheetId="1" r:id="rId1"/></sheets></workbook>');
    $sheet = '<?xml version="1.0" encoding="UTF-8" standalone="yes"?>'
        . '<worksheet xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main"><sheetData>';
    foreach ($rows as $r => $row) {
        $rn = $r + 1;
        $sheet .= '<row r="' . $rn . '">';
        foreach (array_values($row) as $c => $value) {
            $ref = local_aisgk_perm_xlsx_col($c) . $rn;
            $sheet .= '<c r="' . $ref . '" t="inlineStr"><is><t xml:space="preserve">' . local_aisgk_perm_xlsx_xml($value) . '</t></is></c>';
        }
        $sheet .= '</row>';
    }
    $sheet .= '</sheetData></worksheet>';
    $zip->addFromString('xl/worksheets/sheet1.xml', $sheet);
    if (!$zip->close() || !is_file($tmp) || filesize($tmp) < 1000) {
        @unlink($tmp);
        throw new moodle_exception('Không đóng gói được file Excel.');
    }
    while (ob_get_level()) { @ob_end_clean(); }
    header('Content-Type: application/vnd.openxmlformats-officedocument.spreadsheetml.sheet');
    header('Content-Disposition: attachment; filename="' . $filename . '"');
    header('Content-Length: ' . filesize($tmp));
    header('Cache-Control: no-store, no-cache, must-revalidate, max-age=0');
    readfile($tmp);
    @unlink($tmp);
    exit;
}

function local_aisgk_perm_export(array $roles, array $caps, context_system $context): void {
    $rows = [['role_shortname', 'role_name']];
    foreach ($caps as $cap) {
        $rows[0][] = $cap;
    }
    foreach ($roles as $role) {
        $line = [$role->shortname, role_get_name($role, $context)];
        foreach ($caps as $cap) {
            $line[] = local_aisgk_perm_label(local_aisgk_perm_get((int)$role->id, $cap, $context));
        }
        $rows[] = $line;
    }
    local_aisgk_perm_xlsx_export_rows($rows, 'alsm_permissions_' . date('Ymd_His') . '.xlsx');
}

function local_aisgk_perm_xlsx_shared_strings(ZipArchive $zip): array {
    $xml = $zip->getFromName('xl/sharedStrings.xml');
    if ($xml === false) {
        return [];
    }
    $sx = simplexml_load_string($xml);
    if (!$sx) {
        return [];
    }
    $out = [];
    foreach ($sx->si as $si) {
        if (isset($si->t)) {
            $out[] = (string)$si->t;
        } else {
            $text = '';
            foreach ($si->r as $r) {
                $text .= (string)$r->t;
            }
            $out[] = $text;
        }
    }
    return $out;
}

function local_aisgk_perm_xlsx_cell_text($cell, array $shared): string {
    $attrs = $cell->attributes();
    $type = isset($attrs['t']) ? (string)$attrs['t'] : '';
    if ($type === 'inlineStr') {
        return isset($cell->is->t) ? (string)$cell->is->t : '';
    }
    $v = isset($cell->v) ? (string)$cell->v : '';
    if ($type === 's') {
        return $shared[(int)$v] ?? '';
    }
    return $v;
}

function local_aisgk_perm_parse_xlsx(string $path): array {
    $zip = new ZipArchive();
    if ($zip->open($path) !== true) {
        return [];
    }
    $xml = $zip->getFromName('xl/worksheets/sheet1.xml');
    if ($xml === false) {
        $zip->close();
        return [];
    }
    $shared = local_aisgk_perm_xlsx_shared_strings($zip);
    $zip->close();
    $sx = simplexml_load_string($xml);
    if (!$sx) {
        return [];
    }
    $rows = [];
    foreach ($sx->sheetData->row as $row) {
        $line = [];
        foreach ($row->c as $cell) {
            $line[] = trim(local_aisgk_perm_xlsx_cell_text($cell, $shared));
        }
        $rows[] = $line;
    }
    return $rows;
}

function local_aisgk_perm_parse_csv(string $path): array {
    $rows = [];
    $fh = fopen($path, 'rb');
    if (!$fh) {
        return [];
    }
    while (($row = fgetcsv($fh)) !== false) {
        if ($row) {
            $rows[] = array_map('trim', array_map('strval', $row));
        }
    }
    fclose($fh);
    return $rows;
}

function local_aisgk_perm_import(string $path, array $caps, context_system $context): int {
    global $DB;
    $ext = strtolower(pathinfo((string)($_FILES['permfile']['name'] ?? ''), PATHINFO_EXTENSION));
    if ($ext === 'csv') {
        $rows = local_aisgk_perm_parse_csv($path);
    } else if ($ext === 'xlsx') {
        $rows = local_aisgk_perm_parse_xlsx($path);
    } else {
        throw new moodle_exception('Chỉ hỗ trợ file .xlsx hoặc .csv.');
    }
    if (count($rows) < 2) {
        throw new moodle_exception('File phân quyền không có dữ liệu.');
    }
    $headers = array_map('trim', array_shift($rows));
    $capindexes = [];
    $capset = array_flip($caps);
    foreach ($headers as $idx => $header) {
        if (isset($capset[$header])) {
            $capindexes[$idx] = $header;
        }
    }
    if (!$capindexes) {
        throw new moodle_exception('File không đúng cấu trúc phân quyền ALSM.');
    }
    $roles = $DB->get_records('role', null, '', 'id,shortname');
    $rolesbyshortname = [];
    foreach ($roles as $role) {
        $rolesbyshortname[$role->shortname] = (int)$role->id;
    }
    $count = 0;
    foreach ($rows as $row) {
        $shortname = trim((string)($row[0] ?? ''));
        if ($shortname === '' || !isset($rolesbyshortname[$shortname])) {
            continue;
        }
        $roleid = $rolesbyshortname[$shortname];
        foreach ($capindexes as $idx => $cap) {
            $permission = local_aisgk_perm_parse($row[$idx] ?? '');
            role_change_permission($roleid, $context, $cap, $permission);
            $count++;
        }
    }
    return $count;
}

function local_aisgk_perm_apply_defaults(array $caps, context_system $context): int {
    global $DB;
    $map = [
        'manager' => ['*'],
        'editingteacher' => ['local/aisgk:managebooks', 'local/aisgk:createtopic', 'local/aisgk:createhomework', 'local/aisgk:viewbooks'],
        'teacher' => ['local/aisgk:viewbooks'],
        'student' => ['local/aisgk:viewbooks'],
    ];
    $roles = $DB->get_records('role', null, '', 'id,shortname');
    $capset = array_flip($caps);
    $count = 0;
    foreach ($roles as $role) {
        if (!array_key_exists($role->shortname, $map)) {
            continue;
        }
        $allowed = $map[$role->shortname];
        foreach ($caps as $cap) {
            $permission = (in_array('*', $allowed, true) || in_array($cap, $allowed, true)) ? CAP_ALLOW : CAP_INHERIT;
            role_change_permission((int)$role->id, $context, $cap, $permission);
            $count++;
        }
    }
    // Site admin is not controlled through role_capabilities; it always has permissions.
    return $count;
}

$roles = local_aisgk_perm_roles();
$caps = local_aisgk_perm_caps();

if ($action === 'export') {
    require_sesskey();
    local_aisgk_perm_export($roles, $caps, $context);
}

if ($action === 'import') {
    require_sesskey();
    if (empty($_FILES['permfile']['tmp_name']) || !is_uploaded_file($_FILES['permfile']['tmp_name'])) {
        redirect(new moodle_url('/local/aisgk/permissions.php'), 'Chưa chọn file Excel.', null, \core\output\notification::NOTIFY_ERROR);
    }
    try {
        $count = local_aisgk_perm_import($_FILES['permfile']['tmp_name'], $caps, $context);
        redirect(new moodle_url('/local/aisgk/permissions.php'), 'Đã nhập phân quyền: ' . $count . ' ô quyền.', null, \core\output\notification::NOTIFY_SUCCESS);
    } catch (Throwable $e) {
        redirect(new moodle_url('/local/aisgk/permissions.php'), 'Lỗi nhập phân quyền: ' . $e->getMessage(), null, \core\output\notification::NOTIFY_ERROR);
    }
}

if ($action === 'save') {
    require_sesskey();
    $perm = optional_param_array('perm', [], PARAM_RAW);
    $saved = 0;
    foreach ($perm as $roleid => $items) {
        $roleid = (int)$roleid;
        if ($roleid <= 0 || !is_array($items)) {
            continue;
        }
        foreach ($items as $cap => $value) {
            if (!in_array($cap, $caps, true)) {
                continue;
            }
            role_change_permission($roleid, $context, $cap, local_aisgk_perm_parse($value));
            $saved++;
        }
    }
    redirect(new moodle_url('/local/aisgk/permissions.php'), 'Đã lưu phân quyền: ' . $saved . ' ô quyền.', null, \core\output\notification::NOTIFY_SUCCESS);
}

if ($action === 'defaults') {
    require_sesskey();
    $count = local_aisgk_perm_apply_defaults($caps, $context);
    redirect(new moodle_url('/local/aisgk/permissions.php'), 'Đã khôi phục quyền mặc định: ' . $count . ' ô quyền.', null, \core\output\notification::NOTIFY_SUCCESS);
}

local_aisgk_modal_page_open($PAGE->title ?? '');
echo html_writer::tag('h2', 'Phân quyền');
echo html_writer::tag('p', 'Quản lý nhanh quyền ALSM theo vai trò. Có thể xuất Excel trước khi reset và nhập lại sau khi cần.', ['class' => 'muted']);

$exporturl = new moodle_url('/local/aisgk/permissions.php', ['action' => 'export', 'sesskey' => sesskey()]);
$defaultsurl = new moodle_url('/local/aisgk/permissions.php', ['action' => 'defaults', 'sesskey' => sesskey()]);
echo html_writer::start_div('mb-3 d-flex flex-wrap align-items-center', ['style' => 'gap:8px']);
echo html_writer::link($exporturl, 'Xuất Excel', ['class' => 'btn btn-secondary']);
echo html_writer::link($defaultsurl, 'Khôi phục mặc định', ['class' => 'btn btn-outline-secondary', 'onclick' => "return confirm('Áp lại quyền mặc định ALSM?');"]);
echo html_writer::start_tag('form', ['method' => 'post', 'enctype' => 'multipart/form-data', 'action' => (new moodle_url('/local/aisgk/permissions.php'))->out(false), 'class' => 'd-inline-flex align-items-center local-aisgk-auto-import-form', 'style' => 'gap:6px;margin:0', 'data-confirm' => 'Nhập Excel sẽ áp lại cấu hình phân quyền. Tiếp tục?']);
echo html_writer::empty_tag('input', ['type' => 'hidden', 'name' => 'sesskey', 'value' => sesskey()]);
echo html_writer::empty_tag('input', ['type' => 'hidden', 'name' => 'action', 'value' => 'import']);
echo html_writer::empty_tag('input', ['type' => 'file', 'name' => 'permfile', 'accept' => '.xlsx,.csv', 'required' => 'required', 'style' => 'display:none']);
echo html_writer::tag('button', 'Nhập Excel', ['type' => 'button', 'class' => 'btn btn-primary local-aisgk-import-pick']);
echo html_writer::end_tag('form');
echo html_writer::end_div();

echo html_writer::script("
(function(){
  document.querySelectorAll('.local-aisgk-auto-import-form').forEach(function(form){
    var input=form.querySelector('input[type=\"file\"]');
    var btn=form.querySelector('.local-aisgk-import-pick');
    if(!input||!btn){return;}
    btn.addEventListener('click',function(){input.click();});
    input.addEventListener('change',function(){
      if(input.files&&input.files.length){
        var msg=form.getAttribute('data-confirm')||'Nhập file này?';
        if(confirm(msg)){form.submit();}else{input.value='';}
      }
    });
  });
})();
");

if (!$caps) {
    echo $OUTPUT->notification('Chưa tìm thấy capability local/aisgk.', \core\output\notification::NOTIFY_WARNING);
    local_aisgk_modal_page_close();
    exit;
}

echo html_writer::start_tag('form', ['method' => 'post', 'action' => (new moodle_url('/local/aisgk/permissions.php'))->out(false)]);
echo html_writer::empty_tag('input', ['type' => 'hidden', 'name' => 'sesskey', 'value' => sesskey()]);
echo html_writer::empty_tag('input', ['type' => 'hidden', 'name' => 'action', 'value' => 'save']);
echo html_writer::start_div('table-responsive');
echo html_writer::start_tag('table', ['class' => 'generaltable table table-sm', 'style' => 'font-size:13px']);
echo html_writer::start_tag('thead') . html_writer::start_tag('tr');
echo html_writer::tag('th', 'Vai trò');
foreach ($caps as $cap) {
    echo html_writer::tag('th', s(str_replace('local/aisgk:', '', $cap)));
}
echo html_writer::end_tag('tr') . html_writer::end_tag('thead');
echo html_writer::start_tag('tbody');
$options = [
    (string)CAP_INHERIT => 'Kế thừa',
    (string)CAP_ALLOW => 'Cho phép',
    (string)CAP_PREVENT => 'Chặn',
    (string)CAP_PROHIBIT => 'Cấm',
];
foreach ($roles as $role) {
    echo html_writer::start_tag('tr');
    echo html_writer::tag('th', s(role_get_name($role, $context)) . html_writer::tag('div', s($role->shortname), ['class' => 'small text-muted']));
    foreach ($caps as $cap) {
        $current = (string)local_aisgk_perm_get((int)$role->id, $cap, $context);
        $name = 'perm[' . (int)$role->id . '][' . s($cap) . ']';
        echo html_writer::start_tag('td');
        echo html_writer::select($options, $name, $current, false, ['class' => 'custom-select form-control form-control-sm', 'style' => 'min-width:96px']);
        echo html_writer::end_tag('td');
    }
    echo html_writer::end_tag('tr');
}
echo html_writer::end_tag('tbody');
echo html_writer::end_tag('table');
echo html_writer::end_div();
echo html_writer::empty_tag('input', ['type' => 'submit', 'value' => 'Lưu phân quyền', 'class' => 'btn btn-primary']);
echo html_writer::end_tag('form');

local_aisgk_modal_page_close();
