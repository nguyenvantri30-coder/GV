<?php
// ALSM role/capability permission management.
require_once(__DIR__ . '/../../config.php');
require_once($CFG->libdir . '/adminlib.php');
require_once($CFG->libdir . '/accesslib.php');

global $DB, $USER;

$context = context_system::instance();
require_login();
require_capability('moodle/site:config', $context);

$PAGE->set_context($context);
$PAGE->set_url(new moodle_url('/local/aisgk/permissions.php'));
$PAGE->set_title('Phân quyền');
$PAGE->set_heading('');
$PAGE->set_pagelayout('admin');
$PAGE->set_cacheable(false);

$action = optional_param('action', '', PARAM_ALPHA);

function local_aisgk_perm_caps(): array {
    global $DB;
    $records = $DB->get_records_select('capabilities', $DB->sql_like('name', ':prefix', false), ['prefix' => 'local/aisgk:%'], 'name ASC');
    if ($records) {
        return array_keys($records);
    }
    $accessfile = __DIR__ . '/db/access.php';
    $capabilities = [];
    if (is_readable($accessfile)) {
        include($accessfile);
        if (is_array($capabilities)) {
            return array_keys($capabilities);
        }
    }
    return [];
}

function local_aisgk_perm_roles(): array {
    global $DB;
    return array_values($DB->get_records('role', null, 'sortorder ASC, shortname ASC'));
}

function local_aisgk_perm_get(int $roleid, string $capability, context_system $context): int {
    global $DB;
    $record = $DB->get_record('role_capabilities', [
        'roleid' => $roleid,
        'contextid' => $context->id,
        'capability' => $capability,
    ], 'permission', IGNORE_MISSING);
    return $record ? (int)$record->permission : CAP_INHERIT;
}

function local_aisgk_perm_label(int $permission): string {
    switch ($permission) {
        case CAP_ALLOW:
            return 'Cho phép';
        case CAP_PREVENT:
            return 'Chặn';
        case CAP_PROHIBIT:
            return 'Cấm tuyệt đối';
        case CAP_INHERIT:
        default:
            return 'Kế thừa';
    }
}

function local_aisgk_perm_parse($value): int {
    $value = trim((string)$value);
    $lower = core_text::strtolower($value);
    if ($value === (string)CAP_ALLOW || in_array($lower, ['allow', 'cho phép', 'cho phep'], true)) {
        return CAP_ALLOW;
    }
    if ($value === (string)CAP_PREVENT || in_array($lower, ['prevent', 'chặn', 'chan'], true)) {
        return CAP_PREVENT;
    }
    if ($value === (string)CAP_PROHIBIT || in_array($lower, ['prohibit', 'cấm tuyệt đối', 'cam tuyet doi'], true)) {
        return CAP_PROHIBIT;
    }
    return CAP_INHERIT;
}

function local_aisgk_perm_cell($value): string {
    return htmlspecialchars((string)($value ?? ''), ENT_QUOTES | ENT_SUBSTITUTE, 'UTF-8');
}

function local_aisgk_perm_export(array $roles, array $caps, context_system $context): void {
    $filename = 'alsm_permissions_' . date('Ymd_His') . '.xls';
    @header('Content-Type: application/vnd.ms-excel; charset=utf-8');
    @header('Content-Disposition: attachment; filename="' . $filename . '"');
    @header('Cache-Control: no-store, no-cache, must-revalidate, max-age=0');
    echo "\xEF\xBB\xBF";
    echo '<html><head><meta charset="utf-8"><style>td,th{mso-number-format:"\\@";}</style></head><body>';
    echo '<table border="1" data-alsm-table="permissions">';
    echo '<thead><tr><th>role_shortname</th><th>role_name</th>';
    foreach ($caps as $cap) {
        echo '<th>' . local_aisgk_perm_cell($cap) . '</th>';
    }
    echo '</tr></thead><tbody>';
    foreach ($roles as $role) {
        echo '<tr><td>' . local_aisgk_perm_cell($role->shortname) . '</td><td>' . local_aisgk_perm_cell(role_get_name($role, $context)) . '</td>';
        foreach ($caps as $cap) {
            echo '<td>' . local_aisgk_perm_cell(local_aisgk_perm_label(local_aisgk_perm_get((int)$role->id, $cap, $context))) . '</td>';
        }
        echo '</tr>';
    }
    echo '</tbody></table></body></html>';
    exit;
}

function local_aisgk_perm_parse_html_table(string $content): array {
    $content = preg_replace('/^\xEF\xBB\xBF/', '', $content);
    $rows = [];
    libxml_use_internal_errors(true);
    $dom = new DOMDocument();
    if (!$dom->loadHTML('<?xml encoding="utf-8" ?>' . $content)) {
        return [];
    }
    foreach ($dom->getElementsByTagName('tr') as $tr) {
        $cells = [];
        foreach (['th', 'td'] as $tag) {
            foreach ($tr->getElementsByTagName($tag) as $cell) {
                $cells[] = trim(html_entity_decode($cell->textContent, ENT_QUOTES | ENT_SUBSTITUTE, 'UTF-8'));
            }
            if ($cells) {
                break;
            }
        }
        if ($cells) {
            $rows[] = $cells;
        }
    }
    libxml_clear_errors();
    return $rows;
}

function local_aisgk_perm_parse_csv(string $path): array {
    $rows = [];
    $fh = fopen($path, 'rb');
    if (!$fh) {
        return [];
    }
    while (($row = fgetcsv($fh)) !== false) {
        if ($row) {
            $rows[] = array_map('trim', array_map('strval', $row));
        }
    }
    fclose($fh);
    return $rows;
}

function local_aisgk_perm_import(string $path, array $caps, context_system $context): int {
    global $DB;
    $ext = strtolower(pathinfo((string)($_FILES['permfile']['name'] ?? ''), PATHINFO_EXTENSION));
    $rows = ($ext === 'csv') ? local_aisgk_perm_parse_csv($path) : local_aisgk_perm_parse_html_table((string)file_get_contents($path));
    if (count($rows) < 2) {
        throw new moodle_exception('File phân quyền không có dữ liệu.');
    }
    $headers = array_map('trim', array_shift($rows));
    $capindexes = [];
    $capset = array_flip($caps);
    foreach ($headers as $idx => $header) {
        if (isset($capset[$header])) {
            $capindexes[$idx] = $header;
        }
    }
    if (!$capindexes) {
        throw new moodle_exception('File không đúng cấu trúc phân quyền ALSM.');
    }
    $roles = $DB->get_records('role', null, '', 'id,shortname');
    $rolesbyshortname = [];
    foreach ($roles as $role) {
        $rolesbyshortname[$role->shortname] = (int)$role->id;
    }
    $count = 0;
    foreach ($rows as $row) {
        $shortname = trim((string)($row[0] ?? ''));
        if ($shortname === '' || !isset($rolesbyshortname[$shortname])) {
            continue;
        }
        $roleid = $rolesbyshortname[$shortname];
        foreach ($capindexes as $idx => $cap) {
            $permission = local_aisgk_perm_parse($row[$idx] ?? '');
            role_change_permission($roleid, $context, $cap, $permission);
            $count++;
        }
    }
    return $count;
}

function local_aisgk_perm_apply_defaults(array $caps, context_system $context): int {
    global $DB;
    $map = [
        'manager' => ['*'],
        'editingteacher' => ['local/aisgk:managebooks', 'local/aisgk:createtopic', 'local/aisgk:createhomework', 'local/aisgk:viewbooks'],
        'teacher' => ['local/aisgk:viewbooks'],
        'student' => ['local/aisgk:viewbooks'],
    ];
    $roles = $DB->get_records('role', null, '', 'id,shortname');
    $capset = array_flip($caps);
    $count = 0;
    foreach ($roles as $role) {
        if (!array_key_exists($role->shortname, $map)) {
            continue;
        }
        $allowed = $map[$role->shortname];
        foreach ($caps as $cap) {
            $permission = (in_array('*', $allowed, true) || in_array($cap, $allowed, true)) ? CAP_ALLOW : CAP_INHERIT;
            role_change_permission((int)$role->id, $context, $cap, $permission);
            $count++;
        }
    }
    // Site admin is not controlled through role_capabilities; it always has permissions.
    return $count;
}

$roles = local_aisgk_perm_roles();
$caps = local_aisgk_perm_caps();

if ($action === 'export') {
    require_sesskey();
    local_aisgk_perm_export($roles, $caps, $context);
}

if ($action === 'import') {
    require_sesskey();
    if (empty($_FILES['permfile']['tmp_name']) || !is_uploaded_file($_FILES['permfile']['tmp_name'])) {
        redirect(new moodle_url('/local/aisgk/permissions.php'), 'Chưa chọn file Excel.', null, \core\output\notification::NOTIFY_ERROR);
    }
    try {
        $count = local_aisgk_perm_import($_FILES['permfile']['tmp_name'], $caps, $context);
        redirect(new moodle_url('/local/aisgk/permissions.php'), 'Đã nhập phân quyền: ' . $count . ' ô quyền.', null, \core\output\notification::NOTIFY_SUCCESS);
    } catch (Throwable $e) {
        redirect(new moodle_url('/local/aisgk/permissions.php'), 'Lỗi nhập phân quyền: ' . $e->getMessage(), null, \core\output\notification::NOTIFY_ERROR);
    }
}

if ($action === 'save') {
    require_sesskey();
    $perm = optional_param_array('perm', [], PARAM_RAW);
    $saved = 0;
    foreach ($perm as $roleid => $items) {
        $roleid = (int)$roleid;
        if ($roleid <= 0 || !is_array($items)) {
            continue;
        }
        foreach ($items as $cap => $value) {
            if (!in_array($cap, $caps, true)) {
                continue;
            }
            role_change_permission($roleid, $context, $cap, local_aisgk_perm_parse($value));
            $saved++;
        }
    }
    redirect(new moodle_url('/local/aisgk/permissions.php'), 'Đã lưu phân quyền: ' . $saved . ' ô quyền.', null, \core\output\notification::NOTIFY_SUCCESS);
}

if ($action === 'defaults') {
    require_sesskey();
    $count = local_aisgk_perm_apply_defaults($caps, $context);
    redirect(new moodle_url('/local/aisgk/permissions.php'), 'Đã khôi phục quyền mặc định: ' . $count . ' ô quyền.', null, \core\output\notification::NOTIFY_SUCCESS);
}

echo $OUTPUT->header();
echo html_writer::tag('h2', 'Phân quyền');
echo html_writer::tag('p', 'Quản lý nhanh quyền ALSM theo vai trò. Có thể xuất Excel trước khi reset và nhập lại sau khi cần.', ['class' => 'muted']);

$exporturl = new moodle_url('/local/aisgk/permissions.php', ['action' => 'export', 'sesskey' => sesskey()]);
$defaultsurl = new moodle_url('/local/aisgk/permissions.php', ['action' => 'defaults', 'sesskey' => sesskey()]);
echo html_writer::start_div('mb-3 d-flex flex-wrap align-items-center', ['style' => 'gap:8px']);
echo html_writer::link($exporturl, 'Xuất Excel', ['class' => 'btn btn-secondary']);
echo html_writer::link($defaultsurl, 'Khôi phục mặc định', ['class' => 'btn btn-outline-secondary', 'onclick' => "return confirm('Áp lại quyền mặc định ALSM?');"]);
echo html_writer::start_tag('form', ['method' => 'post', 'enctype' => 'multipart/form-data', 'action' => (new moodle_url('/local/aisgk/permissions.php'))->out(false), 'class' => 'd-inline-flex align-items-center', 'style' => 'gap:6px;margin:0']);
echo html_writer::empty_tag('input', ['type' => 'hidden', 'name' => 'sesskey', 'value' => sesskey()]);
echo html_writer::empty_tag('input', ['type' => 'hidden', 'name' => 'action', 'value' => 'import']);
echo html_writer::empty_tag('input', ['type' => 'file', 'name' => 'permfile', 'accept' => '.xls,.html,.csv', 'required' => 'required', 'class' => 'form-control']);
echo html_writer::empty_tag('input', ['type' => 'submit', 'value' => 'Nhập Excel', 'class' => 'btn btn-primary']);
echo html_writer::end_tag('form');
echo html_writer::end_div();

if (!$caps) {
    echo $OUTPUT->notification('Chưa tìm thấy capability local/aisgk.', \core\output\notification::NOTIFY_WARNING);
    echo $OUTPUT->footer();
    exit;
}

echo html_writer::start_tag('form', ['method' => 'post', 'action' => (new moodle_url('/local/aisgk/permissions.php'))->out(false)]);
echo html_writer::empty_tag('input', ['type' => 'hidden', 'name' => 'sesskey', 'value' => sesskey()]);
echo html_writer::empty_tag('input', ['type' => 'hidden', 'name' => 'action', 'value' => 'save']);
echo html_writer::start_div('table-responsive');
echo html_writer::start_tag('table', ['class' => 'generaltable table table-sm', 'style' => 'font-size:13px']);
echo html_writer::start_tag('thead') . html_writer::start_tag('tr');
echo html_writer::tag('th', 'Vai trò');
foreach ($caps as $cap) {
    echo html_writer::tag('th', s(str_replace('local/aisgk:', '', $cap)));
}
echo html_writer::end_tag('tr') . html_writer::end_tag('thead');
echo html_writer::start_tag('tbody');
$options = [
    (string)CAP_INHERIT => 'Kế thừa',
    (string)CAP_ALLOW => 'Cho phép',
    (string)CAP_PREVENT => 'Chặn',
    (string)CAP_PROHIBIT => 'Cấm',
];
foreach ($roles as $role) {
    echo html_writer::start_tag('tr');
    echo html_writer::tag('th', s(role_get_name($role, $context)) . html_writer::tag('div', s($role->shortname), ['class' => 'small text-muted']));
    foreach ($caps as $cap) {
        $current = (string)local_aisgk_perm_get((int)$role->id, $cap, $context);
        $name = 'perm[' . (int)$role->id . '][' . s($cap) . ']';
        echo html_writer::start_tag('td');
        echo html_writer::select($options, $name, $current, false, ['class' => 'custom-select form-control form-control-sm', 'style' => 'min-width:96px']);
        echo html_writer::end_tag('td');
    }
    echo html_writer::end_tag('tr');
}
echo html_writer::end_tag('tbody');
echo html_writer::end_tag('table');
echo html_writer::end_div();
echo html_writer::empty_tag('input', ['type' => 'submit', 'value' => 'Lưu phân quyền', 'class' => 'btn btn-primary']);
echo html_writer::end_tag('form');

echo $OUTPUT->footer();
