<?php
require('../../config.php');

use local_aisgk\book_repository;
use local_aisgk\local\sgk_processor;
use local_aisgk\toc_repository;
use local_aisgk\ai_key_manager;

define('AJAX_SCRIPT', true);

$courseid = required_param('id', PARAM_INT);
$bookid = optional_param('bookid', 0, PARAM_INT);
$op = required_param('op', PARAM_ALPHA);
require_sesskey();

$course = get_course($courseid);
require_login($course);
$context = context_course::instance($courseid);
require_capability('local/aisgk:createtopic', $context);

$book = null;
if ($bookid > 0) {
    $book = book_repository::get_by_id($bookid);
    if (!$book || (int)$book->courseid !== $courseid) {
        throw new invalid_parameter_exception('Invalid book');
    }
}



function local_aisgk_topic_emit_stream(array $payload): void {
    echo json_encode($payload, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES) . "
";
    if (function_exists('ob_get_level')) {
        while (ob_get_level() > 0) {
            @ob_end_flush();
        }
    }
    flush();
}

function local_aisgk_topic_row_value($row, string $key, $default = '') {
    if (is_array($row)) {
        return $row[$key] ?? $default;
    }
    if (is_object($row)) {
        return $row->{$key} ?? $default;
    }
    return $default;
}

function local_aisgk_topic_json_rows(array $rows): array {
    $out = [];
    foreach ($rows as $row) {
        $bookname = local_aisgk_topic_row_value($row, 'bookname', '');
        if ($bookname === '') {
            $bookname = local_aisgk_topic_row_value($row, 'bookfilename', '');
        }
        $out[] = [
            'bookid' => (string)local_aisgk_topic_row_value($row, 'bookid', ''),
            'bookname' => (string)$bookname,
            'sobai' => (string)local_aisgk_topic_row_value($row, 'sobai', ''),
            'tenbai' => (string)local_aisgk_topic_row_value($row, 'tenbai', ''),
            'trang' => (string)local_aisgk_topic_row_value($row, 'trang', ''),
            'endtrang' => (string)local_aisgk_topic_row_value($row, 'endtrang', ''),
            'rawline' => (string)local_aisgk_topic_row_value($row, 'rawline', ''),
        ];
    }
    return $out;
}


$payload = json_decode(file_get_contents('php://input'), true) ?: [];

function local_aisgk_topic_log(string $message): void {
    global $CFG;
    if (empty($CFG->dataroot)) {
        return;
    }
    @file_put_contents($CFG->dataroot . '/aisgk_gemini.log', '[' . date('Y-m-d H:i:s') . '] ' . $message . "
", FILE_APPEND);
}

function local_aisgk_topic_parse_page_range(string $range): array {
    $range = trim($range);
    $pagefrom = 0;
    $pageto = 0;
    if (preg_match('/^(\d+)\s*-\s*(\d+)$/', $range, $m)) {
        $pagefrom = (int)$m[1];
        $pageto = (int)$m[2];
    } else if (preg_match('/^\d+$/', $range)) {
        $pagefrom = (int)$range;
        $pageto = (int)$range;
    }
    if ($pagefrom < 1 || $pageto < $pagefrom) {
        throw new invalid_parameter_exception('TOC page range invalid');
    }
    return [$pagefrom, $pageto];
}

function local_aisgk_topic_google_extract_json(string $apikey, array $images, string $model = 'gemini-flash-latest'): array {
    $parts = [[
        'text' => 'Trích xuất dữ liệu từ bảng mục lục trong ảnh. Kết quả chỉ xuất JSON hợp lệ, không thêm markdown, không giải thích. JSON phải có dạng {"rows":[{"sobai":"","tenbai":"","trang":""}]}. Giữ nguyên thứ tự mục lục. Nếu không thấy số bài thì sobai để rỗng. Chỉ lấy các dòng mục lục thực sự và số trang. Không bịa dữ liệu.'
    ]];

    foreach ($images as $image) {
        $mime = 'image/png';
        $ext = strtolower(pathinfo($image, PATHINFO_EXTENSION));
        if ($ext === 'jpg' || $ext === 'jpeg') {
            $mime = 'image/jpeg';
        } else if ($ext === 'webp') {
            $mime = 'image/webp';
        }
        $data = @file_get_contents($image);
        if ($data === false || $data === '') {
            continue;
        }
        $parts[] = [
            'inlineData' => [
                'mimeType' => $mime,
                'data' => base64_encode($data),
            ],
        ];
    }

    local_aisgk_topic_log('GOOGLE images=' . count($images) . ', parts=' . count($parts) . ', model=' . $model);
    if (count($parts) < 2) {
        throw new moodle_exception('errorprocessingbook', 'local_aisgk', '', 'Không có ảnh mục lục để gửi AI.');
    }

    $request = [
        'contents' => [[
            'parts' => $parts,
        ]],
        'generationConfig' => [
            'responseMimeType' => 'application/json',
            'temperature' => 0.1,
        ],
    ];

    $url = 'https://generativelanguage.googleapis.com/v1beta/models/' . $model . ':generateContent';
    $ch = curl_init($url);
    curl_setopt_array($ch, [
        CURLOPT_RETURNTRANSFER => true,
        CURLOPT_POST => true,
        CURLOPT_HTTPHEADER => [
            'Content-Type: application/json',
            'X-goog-api-key: ' . $apikey,
        ],
        CURLOPT_POSTFIELDS => json_encode($request, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES),
        CURLOPT_TIMEOUT => 120,
    ]);
    $response = curl_exec($ch);
    $errno = curl_errno($ch);
    $error = curl_error($ch);
    $httpcode = (int)curl_getinfo($ch, CURLINFO_RESPONSE_CODE);
    curl_close($ch);

    local_aisgk_topic_log('GOOGLE http=' . $httpcode . ', errno=' . $errno . ', response=' . substr((string)$response, 0, 2000));

    if ($errno) {
        throw new moodle_exception('errorprocessingbook', 'local_aisgk', '', 'Lỗi kết nối Google Gemini: ' . $error);
    }
    if (!is_string($response) || trim($response) === '') {
        throw new moodle_exception('errorprocessingbook', 'local_aisgk', '', 'Google Gemini không trả dữ liệu.');
    }
    $decoded = json_decode($response, true);
    if (!is_array($decoded)) {
        throw new moodle_exception('errorprocessingbook', 'local_aisgk', '', 'Google Gemini trả dữ liệu không hợp lệ: ' . $response);
    }
    if ($httpcode >= 400 || !empty($decoded['error'])) {
        $message = (string)($decoded['error']['message'] ?? ('Google Gemini HTTP ' . $httpcode));
        $status = strtoupper((string)($decoded['error']['status'] ?? ''));
        $quotahit = (bool)preg_match('/quota|rate limit|resource exhausted|429|free tier/i', $message . ' ' . $status);
        throw new moodle_exception('errorprocessingbook', 'local_aisgk', '', ($quotahit ? 'FREE_TIER_QUOTA_EXCEEDED: ' : 'GEMINI_ERROR: ') . $message);
    }

    $text = '';
    foreach (($decoded['candidates'] ?? []) as $candidate) {
        foreach (($candidate['content']['parts'] ?? []) as $part) {
            if (!empty($part['text'])) {
                $text .= $part['text'];
            }
        }
    }
    return local_aisgk_topic_extract_rows_from_text($text);
}

function local_aisgk_topic_shopaikey_extract_json(string $apikey, array $images, string $model): array {
    $content = [[
        'type' => 'text',
        'text' => 'Trích xuất dữ liệu từ bảng mục lục trong ảnh. Kết quả chỉ xuất JSON hợp lệ, không thêm markdown, không giải thích. JSON phải có dạng {"rows":[{"sobai":"","tenbai":"","trang":""}]}. Giữ nguyên thứ tự mục lục. Nếu không thấy số bài thì sobai để rỗng. Chỉ lấy các dòng mục lục thực sự và số trang. Không bịa dữ liệu.'
    ]];

    foreach ($images as $image) {
        $mime = 'image/png';
        $ext = strtolower(pathinfo($image, PATHINFO_EXTENSION));
        if ($ext === 'jpg' || $ext === 'jpeg') {
            $mime = 'image/jpeg';
        } else if ($ext === 'webp') {
            $mime = 'image/webp';
        }
        $data = @file_get_contents($image);
        if ($data === false || $data === '') {
            continue;
        }
        $content[] = [
            'type' => 'image_url',
            'image_url' => [
                'url' => 'data:' . $mime . ';base64,' . base64_encode($data),
            ],
        ];
    }

    local_aisgk_topic_log('SHOPAIKEY images=' . count($images) . ', parts=' . count($content) . ', model=' . $model);
    if (count($content) < 2) {
        throw new moodle_exception('errorprocessingbook', 'local_aisgk', '', 'Không có ảnh mục lục để gửi AI.');
    }

    $request = [
        'model' => $model,
        'messages' => [[
            'role' => 'user',
            'content' => $content,
        ]],
        'temperature' => 0.1,
        'response_format' => ['type' => 'json_object'],
    ];

    $url = 'https://api.shopaikey.com/v1/chat/completions';
    $ch = curl_init($url);
    curl_setopt_array($ch, [
        CURLOPT_RETURNTRANSFER => true,
        CURLOPT_POST => true,
        CURLOPT_HTTPHEADER => [
            'Content-Type: application/json',
            'Authorization: Bearer ' . $apikey,
        ],
        CURLOPT_POSTFIELDS => json_encode($request, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES),
        CURLOPT_TIMEOUT => 120,
    ]);
    $response = curl_exec($ch);
    $errno = curl_errno($ch);
    $error = curl_error($ch);
    $httpcode = (int)curl_getinfo($ch, CURLINFO_RESPONSE_CODE);
    curl_close($ch);

    local_aisgk_topic_log('SHOPAIKEY http=' . $httpcode . ', errno=' . $errno . ', response=' . substr((string)$response, 0, 2000));

    if ($errno) {
        throw new moodle_exception('errorprocessingbook', 'local_aisgk', '', 'Lỗi kết nối ShopAIKey: ' . $error);
    }
    if (!is_string($response) || trim($response) === '') {
        throw new moodle_exception('errorprocessingbook', 'local_aisgk', '', 'ShopAIKey không trả dữ liệu.');
    }
    $decoded = json_decode($response, true);
    if (!is_array($decoded)) {
        throw new moodle_exception('errorprocessingbook', 'local_aisgk', '', 'ShopAIKey trả dữ liệu không hợp lệ: ' . $response);
    }
    if ($httpcode >= 400 || !empty($decoded['error'])) {
        $err = $decoded['error'] ?? [];
        $message = is_array($err) ? (string)($err['message'] ?? ('ShopAIKey HTTP ' . $httpcode)) : (string)$err;
        $quotahit = (bool)preg_match('/quota|rate limit|resource exhausted|429|too many requests/i', $message);
        throw new moodle_exception('errorprocessingbook', 'local_aisgk', '', ($quotahit ? 'FREE_TIER_QUOTA_EXCEEDED: ' : 'SHOPAIKEY_ERROR: ') . $message);
    }

    $text = (string)($decoded['choices'][0]['message']['content'] ?? '');
    if (is_array($decoded['choices'][0]['message']['content'] ?? null)) {
        $pieces = [];
        foreach ($decoded['choices'][0]['message']['content'] as $part) {
            if (!empty($part['text'])) { $pieces[] = $part['text']; }
        }
        $text = implode("
", $pieces);
    }
    return local_aisgk_topic_extract_rows_from_text($text);
}

function local_aisgk_topic_extract_rows_from_text(string $text): array {
    $text = trim($text);
    if ($text === '') {
        throw new moodle_exception('errorprocessingbook', 'local_aisgk', '', 'AI không trả phần JSON văn bản.');
    }
    $json = json_decode($text, true);
    if (!is_array($json) && preg_match('/\{.*\}/s', $text, $m)) {
        $json = json_decode($m[0], true);
    }
    if (!is_array($json)) {
        throw new moodle_exception('errorprocessingbook', 'local_aisgk', '', 'Không phân tích được JSON AI trả về: ' . mb_substr($text, 0, 1000));
    }
    $rows = $json['rows'] ?? $json;
    if (!is_array($rows)) {
        throw new moodle_exception('errorprocessingbook', 'local_aisgk', '', 'JSON AI không có mảng rows hợp lệ.');
    }
    return $rows;
}

function local_aisgk_topic_ai_is_temporary_overload(string $message): bool {
    return (bool)preg_match('/high demand|overload|overloaded|temporarily unavailable|try again later|service unavailable|503|model is currently/i', $message);
}

function local_aisgk_topic_ai_model_attempts(string $provider, string $primarymodel): array {
    $models = [];
    $primarymodel = trim($primarymodel);
    if ($primarymodel !== '') {
        $models[] = $primarymodel;
    }

    if ($provider === 'shopaikey') {
        foreach ([
            'gemini-2.5-flash-lite',
            'gemini-2.5-flash',
            'gemini-flash-latest',
            'gpt-5.4-mini',
            'gpt-5.4-nano',
        ] as $m) {
            $models[] = $m;
        }
    } else {
        foreach ([
            'gemini-2.5-flash-lite',
            'gemini-2.5-flash',
            'gemini-flash-latest',
            'gemini-1.5-flash',
        ] as $m) {
            $models[] = $m;
        }
    }

    $out = [];
    foreach ($models as $m) {
        $m = trim((string)$m);
        if ($m !== '' && !in_array($m, $out, true)) {
            $out[] = $m;
        }
    }
    return $out;
}
function local_aisgk_topic_ai_extract_json(\stdClass $key, array $images, string $feature = 'scan'): array {
    $provider = trim((string)($key->provider ?? (($key->category_key ?? 'free') === 'pay' ? 'shopaikey' : 'google')));
    $model = trim((string)($feature === 'homework' ? ($key->model_homework ?? '') : ($key->model_scan ?? '')));
    if ($model === '') {
        if ($provider === 'shopaikey') {
            $model = $feature === 'homework' ? 'gpt-5.4-mini' : 'gemini-3.1-flash-lite-preview';
        } else {
            $model = 'gemini-flash-latest';
        }
    }
    $apikey = trim((string)($key->api_key ?? ''));
    if ($apikey === '') {
        throw new moodle_exception('errorprocessingbook', 'local_aisgk', '', 'API key rỗng.');
    }
    if ($provider === 'shopaikey') {
        return local_aisgk_topic_shopaikey_extract_json($apikey, $images, $model);
    }
    return local_aisgk_topic_google_extract_json($apikey, $images, $model);
}

if ($op === 'scanadvanced') {
    header('Content-Type: text/plain; charset=utf-8');
    @ini_set('output_buffering', 'off');
    @ini_set('zlib.output_compression', '0');
    @set_time_limit(0);

    try {
        if ($bookid < 1) {
            throw new invalid_parameter_exception('Hãy chọn một SGK cụ thể trước khi Scan TOC.');
        }
        $columns = ((int)($payload['columns'] ?? 1) === 2) ? 2 : 1;
        $psm = max(3, min(13, (int)($payload['psm'] ?? 4)));
        $range = trim((string)($payload['pagerange'] ?? '5-5'));
        [$pagefrom, $pageto] = local_aisgk_topic_parse_page_range($range);

        local_aisgk_topic_emit_stream(['ok' => true, 'type' => 'start']);
        $preview = sgk_processor::preview_topic_items_advanced(
            $bookid,
            $columns,
            50,
            $psm,
            $pagefrom,
            $pageto,
            static function(array $progress): void {
                local_aisgk_topic_emit_stream(['ok' => true, 'type' => 'progress', 'progress' => $progress]);
            }
        );

        $rows = [];
        foreach ($preview['items'] as $item) {
            $rows[] = [
                'bookid' => $bookid,
                'bookname' => (string)($book->name ?: $book->filename),
                'sobai' => $item['lessonno'] ?? '',
                'tenbai' => $item['lessontitle'] ?? '',
                'trang' => $item['startpage'] ?? '',
                'endtrang' => $item['endpage'] ?? '',
                'rawline' => $item['rawocr'] ?? '',
            ];
        }
        $rows = toc_repository::calculate_end_pages($rows);
        local_aisgk_topic_emit_stream(['ok' => true, 'type' => 'result', 'rows' => local_aisgk_topic_json_rows($rows)]);
    } catch (Throwable $e) {
        http_response_code(500);
        local_aisgk_topic_emit_stream(['ok' => false, 'error' => $e->getMessage()]);
    }
    exit;
}

header('Content-Type: application/json; charset=utf-8');

try {
    if ($op === 'load') {
        if ($bookid > 0) {
            $rows = toc_repository::get_draft_by_bookid($bookid);
            if (!$rows) {
                $rows = toc_repository::get_by_bookid($bookid);
            }
        } else {
            $rows = toc_repository::get_draft_by_courseid($courseid);
            if (!$rows) {
                $rows = toc_repository::get_by_courseid($courseid);
            }
        }
        echo json_encode(['ok' => true, 'rows' => local_aisgk_topic_json_rows($rows)]);
        exit;
    }

    if ($op === 'scan') {
        if ($bookid < 1) {
            throw new invalid_parameter_exception('Hãy chọn một SGK cụ thể trước khi Scan TOC.');
        }
        $columns = ((int)($payload['columns'] ?? 1) === 2) ? 2 : 1;
        $psm = max(3, min(13, (int)($payload['psm'] ?? 4)));
        $range = trim((string)($payload['pagerange'] ?? '5-5'));
        [$pagefrom, $pageto] = local_aisgk_topic_parse_page_range($range);
        $preview = sgk_processor::preview_topic_items($bookid, $columns, 50, $psm, $pagefrom, $pageto);
        $rows = [];
        foreach ($preview['items'] as $item) {
            $rows[] = [
                'bookid' => $bookid,
                'bookname' => (string)($book->name ?: $book->filename),
                'sobai' => $item['lessonno'] ?? '',
                'tenbai' => $item['lessontitle'] ?? '',
                'trang' => $item['startpage'] ?? '',
                'endtrang' => $item['endpage'] ?? '',
                'rawline' => $item['rawocr'] ?? '',
            ];
        }
        $rows = toc_repository::calculate_end_pages($rows);
        echo json_encode(['ok' => true, 'rows' => local_aisgk_topic_json_rows($rows)]);
        exit;
    }

if ($op === 'aiextract') {
    global $DB;
    if ($bookid < 1) {
        throw new invalid_parameter_exception('Hãy chọn một SGK cụ thể trước khi dùng AI.');
    }

    $range = trim((string)($payload['pagerange'] ?? '5-5'));
    [$pagefrom, $pageto] = local_aisgk_topic_parse_page_range($range);

    $bookrecord = book_repository::get_by_id($bookid);
    if (!$bookrecord) {
        throw new invalid_parameter_exception('Invalid book');
    }

    local_aisgk_topic_log('ENTER aiextract course=' . $courseid . ', book=' . $bookid);
    sgk_processor::render_toc_images($bookid, $pagefrom, $pageto, 200);
    $images = sgk_processor::get_source_images((int)$bookrecord->courseid, $bookid);
    local_aisgk_topic_log('Rendered images: ' . json_encode($images, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES));


    $airesult = \local_aisgk\local\ai_service::extract_toc_from_images($images, (int)$USER->id);
    $rows = $airesult['rows'];

    $rows = array_map(static function($row) use ($bookid, $bookrecord) {
        if (is_array($row)) {
            $row['bookid'] = $bookid;
            $row['bookname'] = (string)($bookrecord->name ?: $bookrecord->filename);
        }
        return $row;
    }, $rows);
    $rows = toc_repository::sanitize_rows($rows);
    $rows = toc_repository::calculate_end_pages($rows);

    $usage = $airesult['usage'] ?? [];
    $msg = 'AI đã trích xuất ' . count($rows) . ' dòng mục lục.';
    $msg .= ' Model: ' . (string)($airesult['model'] ?? '');
    $msg .= ' | Tokens: ' . (int)($airesult['tokens'] ?? 0);
    $msg .= ' | Key: ' . ((string)($airesult['keysource'] ?? 'system') === 'local_aisgk_user_ai_keys' ? 'của tôi' : 'hệ thống');
    $msg .= ' | Loại: ' . (string)($airesult['category'] ?? 'free');
    if (isset($usage['remain_calls'])) {
        $msg .= ' | Còn ~' . (int)$usage['remain_calls'] . ' lần gọi';
    }

    echo json_encode([
        'ok' => true,
        'rows' => local_aisgk_topic_json_rows($rows),
        'message' => $msg,
        'model' => (string)($airesult['model'] ?? ''),
        'tokens' => (int)($airesult['tokens'] ?? 0),
        'category' => (string)($airesult['category'] ?? 'free'),
        'remain_calls' => (int)($usage['remain_calls'] ?? 0),
    ], JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
    exit;
}
//----------
    if ($op === 'createtopics') {
        global $DB;
        require_once($CFG->dirroot . '/course/lib.php');

        $tocs = $DB->get_records_sql("
            SELECT t.*, b.name AS bookname, b.filename AS bookfilename, b.sortorder AS booksortorder
              FROM {local_aisgk_book_toc} t
              JOIN {local_aisgk_books} b ON b.id = t.bookid
             WHERE b.courseid = ?
          ORDER BY b.sortorder ASC, b.id ASC, t.sortorder ASC, t.id ASC
        ", [$courseid]);

        if (!$tocs) {
            echo json_encode([
                'ok' => false,
                'error' => 'Chưa có dữ liệu mục lục đã Save trong DB.'
            ], JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
            exit;
        }

        $course = $DB->get_record('course', ['id' => $courseid], '*', MUST_EXIST);
        $sectionnum = 1;
        $createdmap = 0;
        $updatedmap = 0;
        $updatedsections = 0;
        $usedsectionids = [];
        $skipped = 0;

        foreach ($tocs as $toc) {
            $title = trim((string)$toc->tenbai);
            $startpage = isset($toc->trang) ? (int)$toc->trang : 0;
            $endpage = isset($toc->endtrang) ? (int)$toc->endtrang : 0;

            if ($title === '' || $startpage < 1 || $endpage < $startpage) {
                $skipped++;
                continue;
            }

            course_create_sections_if_missing($course, $sectionnum);

            $section = $DB->get_record('course_sections', [
                'course' => $courseid,
                'section' => $sectionnum,
            ], '*', MUST_EXIST);

            course_update_section($course, $section, [
                'name' => $title,
                'summary' => '',
                'summaryformat' => FORMAT_HTML,
                'visible' => 1,
            ]);
            $updatedsections++;
            $usedsectionids[] = (int)$section->id;

            $map = $DB->get_record('local_aisgk_section_toc', [
                'sectionid' => (int)$section->id,
            ]);

            if ($map) {
                if ((int)$map->tocid !== (int)$toc->id) {
                    $map->tocid = (int)$toc->id;
                    $DB->update_record('local_aisgk_section_toc', $map);
                }
                $updatedmap++;
            } else {
                $DB->insert_record('local_aisgk_section_toc', [
                    'sectionid' => (int)$section->id,
                    'tocid' => (int)$toc->id,
                ]);
                $createdmap++;
            }

            $sectionnum++;
        }

        if ($usedsectionids) {
            list($insql, $params) = $DB->get_in_or_equal($usedsectionids, SQL_PARAMS_QM, 'p', false);
            $params[] = $courseid;
            $DB->delete_records_select('local_aisgk_section_toc',
                "sectionid IN (SELECT id FROM {course_sections} WHERE id $insql AND course = ?)", $params);
        }

        rebuild_course_cache($courseid, true);

        echo json_encode([
            'ok' => true,
            'message' => 'Đã tạo/cập nhật ' . $updatedsections . ' bài học. Map mới: ' . $createdmap . ', map cập nhật: ' . $updatedmap . ($skipped ? ', bỏ qua: ' . $skipped : '') . '.',
            'sections' => $updatedsections,
            'createdmap' => $createdmap,
            'updatedmap' => $updatedmap,
            'skipped' => $skipped,
        ], JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
        exit;
    }

    if ($op === 'deletelessons') {
        global $DB;
        require_once($CFG->dirroot . '/course/lib.php');

        $course = $DB->get_record('course', ['id' => $courseid], '*', MUST_EXIST);
        $sql = "SELECT m.id AS mapid, m.sectionid, m.tocid, cs.section
                  FROM {local_aisgk_section_toc} m
                  JOIN {course_sections} cs ON cs.id = m.sectionid
                 WHERE cs.course = ? AND cs.section > 0
              ORDER BY cs.section DESC";
        $maps = array_values($DB->get_records_sql($sql, [$courseid]));
        $deleted = 0;
        $cleared = 0;
        $errors = [];

        $mapids = array_map(static function($m) { return (int)$m->mapid; }, $maps);

        foreach ($maps as $map) {
            $sectionnum = (int)$map->section;
            $sectionid = (int)$map->sectionid;
            try {
                if (function_exists('course_delete_section')) {
                    course_delete_section($course, $sectionnum, true, false);
                    $deleted++;
                } else {
                    $DB->update_record('course_sections', (object)[
                        'id' => $sectionid,
                        'name' => null,
                        'summary' => '',
                        'summaryformat' => FORMAT_HTML,
                    ]);
                    $cleared++;
                }
            } catch (Throwable $e) {
                $errors[] = 'Section ' . $sectionnum . ': ' . $e->getMessage();
                try {
                    $DB->update_record('course_sections', (object)[
                        'id' => $sectionid,
                        'name' => null,
                        'summary' => '',
                        'summaryformat' => FORMAT_HTML,
                    ]);
                    $cleared++;
                } catch (Throwable $ignored) {
                    // Keep original error only.
                }
            }
        }

        if ($mapids) {
            $DB->delete_records_list('local_aisgk_section_toc', 'id', $mapids);
        }
        $DB->delete_records_select('local_aisgk_section_toc',
            'sectionid IN (SELECT id FROM {course_sections} WHERE course = ?)', [$courseid]);
        rebuild_course_cache($courseid, true);

        $msg = 'Đã xóa bài học/topic đã tạo. Xóa section: ' . $deleted . ', làm sạch: ' . $cleared . '.';
        if ($errors) {
            $msg .= ' Một số section có lỗi: ' . implode(' | ', array_slice($errors, 0, 3));
        }
        echo json_encode(['ok' => true, 'message' => $msg, 'deleted' => $deleted, 'cleared' => $cleared], JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
        exit;
    }

    if ($op === 'save') {
        $rows = toc_repository::sanitize_rows($payload['rows'] ?? []);
        if ($bookid > 0) {
            foreach ($rows as &$row) {
                $row['bookid'] = $bookid;
            }
            unset($row);
        }
        $rows = toc_repository::calculate_end_pages($rows);
        if ($bookid > 0) {
            toc_repository::replace_book_toc($bookid, $rows);
            toc_repository::replace_book_toc_draft($bookid, $rows);
        } else {
            toc_repository::replace_course_toc($courseid, $rows);
            toc_repository::replace_course_toc_draft($courseid, $rows);
        }
        echo json_encode(['ok' => true, 'rows' => local_aisgk_topic_json_rows($rows)]);
        exit;
    }

    if ($op === 'restore') {
        if ($bookid > 0) {
            $rows = toc_repository::get_draft_by_bookid($bookid);
            if (!$rows) {
                $rows = toc_repository::get_by_bookid($bookid);
            }
        } else {
            $rows = toc_repository::get_draft_by_courseid($courseid);
            if (!$rows) {
                $rows = toc_repository::get_by_courseid($courseid);
            }
        }
        echo json_encode(['ok' => true, 'rows' => local_aisgk_topic_json_rows($rows)]);
        exit;
    }

    if ($op === 'delete') {
        toc_repository::delete_course_toc_and_draft($courseid);
        $DB->delete_records_select('local_aisgk_section_toc',
            'sectionid IN (SELECT id FROM {course_sections} WHERE course = ?)', [$courseid]);
        echo json_encode(['ok' => true]);
        exit;
    }

    throw new invalid_parameter_exception('Invalid op');
} catch (Throwable $e) {
    local_aisgk_topic_log('CATCH: ' . $e->getMessage());
    http_response_code(500);
    echo json_encode(['ok' => false, 'error' => $e->getMessage()]);
}
