<?php
require('../../config.php');

use local_aisgk\book_repository;
use local_aisgk\local\sgk_processor;
use local_aisgk\toc_repository;

define('AJAX_SCRIPT', true);

$courseid = required_param('id', PARAM_INT);
$bookid = required_param('bookid', PARAM_INT);
$op = required_param('op', PARAM_ALPHA);
require_sesskey();

$course = get_course($courseid);
require_login($course);
$context = context_course::instance($courseid);
require_capability('local/aisgk:createtopic', $context);

$book = book_repository::get_by_id($bookid);
if (!$book || (int)$book->courseid !== $courseid) {
    throw new invalid_parameter_exception('Invalid book');
}

function local_aisgk_topic_emit_stream(array $payload): void {
    echo json_encode($payload, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES) . "\n";
    if (function_exists('ob_get_level')) {
        while (ob_get_level() > 0) {
            @ob_end_flush();
        }
    }
    flush();
}

function local_aisgk_topic_json_rows(array $rows): array {
    $out = [];
    foreach ($rows as $row) {
        $out[] = [
            'sobai' => (string)($row['sobai'] ?? $row->sobai ?? ''),
            'tenbai' => (string)($row['tenbai'] ?? $row->tenbai ?? ''),
            'trang' => (string)($row['trang'] ?? $row->trang ?? ''),
            'endtrang' => (string)($row['endtrang'] ?? $row->endtrang ?? ''),
            'rawline' => (string)($row['rawline'] ?? $row->rawline ?? ''),
        ];
    }
    return $out;
}

$payload = json_decode(file_get_contents('php://input'), true) ?: [];
@file_put_contents('/tmp/aisgk_gemini.log', "=== ENTRY ===\nop=" . $op . " courseid=" . $courseid . " bookid=" . $bookid . "\n", FILE_APPEND);

function local_aisgk_topic_parse_page_range(string $range): array {
    $range = trim($range);
    $pagefrom = 0;
    $pageto = 0;
    if (preg_match('/^(\d+)\s*-\s*(\d+)$/', $range, $m)) {
        $pagefrom = (int)$m[1];
        $pageto = (int)$m[2];
    } else if (preg_match('/^\d+$/', $range)) {
        $pagefrom = (int)$range;
        $pageto = (int)$range;
    }
    if ($pagefrom < 1 || $pageto < $pagefrom) {
        throw new invalid_parameter_exception('TOC page range invalid');
    }
    return [$pagefrom, $pageto];
}

function local_aisgk_topic_gemini_extract_json(string $apikey, array $images): array {
    $parts = [[
        'text' => 'Trích xuất dữ liệu từ bảng mục lục trong ảnh. Kết quả chỉ xuất JSON hợp lệ, không thêm markdown, không giải thích. JSON phải có dạng {"rows":[{"sobai":"","tenbai":"","trang":""}]}. Giữ nguyên thứ tự mục lục. Nếu không thấy số bài thì sobai để rỗng. Chỉ lấy các dòng mục lục thực sự có tên bài/chương và số trang. Không bịa dữ liệu.'
    ]];

    foreach ($images as $image) {
        $mime = 'image/png';
        $ext = strtolower(pathinfo($image, PATHINFO_EXTENSION));
        if ($ext === 'jpg' || $ext === 'jpeg') {
            $mime = 'image/jpeg';
        } else if ($ext === 'webp') {
            $mime = 'image/webp';
        }

        $data = @file_get_contents($image);
        if ($data === false || $data === '') {
            continue;
        }

        $parts[] = [
            'inlineData' => [
                'mimeType' => $mime,
                'data' => base64_encode($data),
            ],
        ];
    }

    @file_put_contents('/tmp/aisgk_gemini.log', "=== IMAGES ===\n" . print_r($images, true) . "\n", FILE_APPEND);
    @file_put_contents('/tmp/aisgk_gemini.log', "=== PARTS COUNT ===\n" . count($parts) . "\n", FILE_APPEND);

    if (count($parts) < 2) {
        throw new moodle_exception('errorprocessingbook', 'local_aisgk', '', 'Không có ảnh mục lục để gửi AI.');
    }

    $request = [
        'contents' => [[
            'role' => 'user',
            'parts' => $parts,
        ]],
        'generationConfig' => [
            'temperature' => 0.1,
            'responseMimeType' => 'application/json',
        ],
    ];

    $models = [
        'gemini-flash-latest',
        'gemini-2.5-flash-lite',
        'gemini-2.5-flash',
    ];

    $lastmessage = '';
    $laststatus = '';

    foreach ($models as $model) {
        $url = 'https://generativelanguage.googleapis.com/v1beta/models/' . $model . ':generateContent';
        $ch = curl_init($url);
        curl_setopt_array($ch, [
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_POST => true,
            CURLOPT_HTTPHEADER => [
                'Content-Type: application/json',
                'X-goog-api-key: ' . $apikey,
            ],
            CURLOPT_POSTFIELDS => json_encode($request, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES),
            CURLOPT_TIMEOUT => 120,
        ]);

        @file_put_contents('/tmp/aisgk_gemini.log', "=== MODEL {$model} REQUEST ===\n" . json_encode($request, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES) . "\n", FILE_APPEND);

        $response = curl_exec($ch);
        $errno = curl_errno($ch);
        $error = curl_error($ch);
        $httpcode = (int)curl_getinfo($ch, CURLINFO_RESPONSE_CODE);
        curl_close($ch);

        @file_put_contents('/tmp/aisgk_gemini.log', "=== MODEL {$model} HTTP {$httpcode} ===\n{$response}\n\n", FILE_APPEND);

        if ($errno) {
            throw new moodle_exception('errorprocessingbook', 'local_aisgk', '', 'Lỗi kết nối Gemini: ' . $error);
        }

        if (!is_string($response) || trim($response) === '') {
            $lastmessage = 'Gemini không trả dữ liệu.';
            $laststatus = '';
            continue;
        }

        $decoded = json_decode($response, true);
        if (!is_array($decoded)) {
            throw new moodle_exception('errorprocessingbook', 'local_aisgk', '', 'Gemini trả dữ liệu không hợp lệ: ' . $response);
        }

        if ($httpcode >= 400 || !empty($decoded['error'])) {
            $message = (string)($decoded['error']['message'] ?? ('Gemini HTTP ' . $httpcode));
            $status = strtoupper((string)($decoded['error']['status'] ?? ''));
            $lastmessage = $message;
            $laststatus = $status;

            if (preg_match('/not found|not supported|unsupported|404/i', $message . ' ' . $status)) {
                continue;
            }

            $quotahit = (bool)preg_match('/quota|rate limit|resource exhausted|429|free tier/i', $message . ' ' . $status);
            throw new moodle_exception('errorprocessingbook', 'local_aisgk', '', ($quotahit ? 'FREE_TIER_QUOTA_EXCEEDED: ' : 'GEMINI_ERROR: ') . $message);
        }

        $text = '';
        foreach (($decoded['candidates'] ?? []) as $candidate) {
            foreach (($candidate['content']['parts'] ?? []) as $part) {
                if (!empty($part['text'])) {
                    $text .= $part['text'];
                }
            }
        }

        $text = trim($text);
        if ($text === '') {
            throw new moodle_exception('errorprocessingbook', 'local_aisgk', '', 'Gemini không trả phần JSON văn bản.');
        }

        $json = json_decode($text, true);
        if (!is_array($json) && preg_match('/\{.*\}/s', $text, $m)) {
            $json = json_decode($m[0], true);
        }

        if (!is_array($json)) {
            throw new moodle_exception('errorprocessingbook', 'local_aisgk', '', 'Không phân tích được JSON Gemini trả về: ' . $text);
        }

        $rows = $json['rows'] ?? $json;
        if (!is_array($rows)) {
            throw new moodle_exception('errorprocessingbook', 'local_aisgk', '', 'JSON Gemini không có mảng rows hợp lệ.');
        }

        return $rows;
    }

    $quotahit = (bool)preg_match('/quota|rate limit|resource exhausted|429|free tier/i', $lastmessage . ' ' . $laststatus);
    if ($lastmessage !== '') {
        throw new moodle_exception('errorprocessingbook', 'local_aisgk', '', ($quotahit ? 'FREE_TIER_QUOTA_EXCEEDED: ' : 'GEMINI_ERROR: ') . $lastmessage);
    }

    throw new moodle_exception('errorprocessingbook', 'local_aisgk', '', 'Gemini không trả dữ liệu hợp lệ.');
}

if ($op === 'scanadvanced') {
    header('Content-Type: text/plain; charset=utf-8');
    @ini_set('output_buffering', 'off');
    @ini_set('zlib.output_compression', '0');
    @set_time_limit(0);

    try {
        $columns = ((int)($payload['columns'] ?? 1) === 2) ? 2 : 1;
        $psm = max(3, min(13, (int)($payload['psm'] ?? 4)));
        $range = trim((string)($payload['pagerange'] ?? '3-4'));
        [$pagefrom, $pageto] = local_aisgk_topic_parse_page_range($range);

        local_aisgk_topic_emit_stream(['ok' => true, 'type' => 'start']);
        $preview = sgk_processor::preview_topic_items_advanced(
            $bookid,
            $columns,
            50,
            $psm,
            $pagefrom,
            $pageto,
            static function(array $progress): void {
                local_aisgk_topic_emit_stream(['ok' => true, 'type' => 'progress', 'progress' => $progress]);
            }
        );

        $rows = [];
        foreach ($preview['items'] as $item) {
            $rows[] = [
                'sobai' => $item['lessonno'] ?? '',
                'tenbai' => $item['lessontitle'] ?? '',
                'trang' => $item['startpage'] ?? '',
                'endtrang' => $item['endpage'] ?? '',
                'rawline' => $item['rawocr'] ?? '',
            ];
        }
        $rows = toc_repository::calculate_end_pages($rows);
        local_aisgk_topic_emit_stream(['ok' => true, 'type' => 'result', 'rows' => local_aisgk_topic_json_rows($rows)]);
    } catch (Throwable $e) {
        http_response_code(500);
        local_aisgk_topic_emit_stream(['ok' => false, 'error' => $e->getMessage()]);
    }
    exit;
}

header('Content-Type: application/json; charset=utf-8');

try {
    if ($op === 'scan') {
        $columns = ((int)($payload['columns'] ?? 1) === 2) ? 2 : 1;
        $psm = max(3, min(13, (int)($payload['psm'] ?? 4)));
        $range = trim((string)($payload['pagerange'] ?? '3-4'));
        [$pagefrom, $pageto] = local_aisgk_topic_parse_page_range($range);
        $preview = sgk_processor::preview_topic_items($bookid, $columns, 50, $psm, $pagefrom, $pageto);
        $rows = [];
        foreach ($preview['items'] as $item) {
            $rows[] = [
                'sobai' => $item['lessonno'] ?? '',
                'tenbai' => $item['lessontitle'] ?? '',
                'trang' => $item['startpage'] ?? '',
                'endtrang' => $item['endpage'] ?? '',
                'rawline' => $item['rawocr'] ?? '',
            ];
        }
        $rows = toc_repository::calculate_end_pages($rows);
        echo json_encode(['ok' => true, 'rows' => local_aisgk_topic_json_rows($rows)]);
        exit;
    }

    if ($op === 'aiextract') {
        @file_put_contents('/tmp/aisgk_gemini.log', "=== AIEXTRACT START ===\nrange=" . (string)($payload['pagerange'] ?? '') . "\n", FILE_APPEND);
        $range = trim((string)($payload['pagerange'] ?? '3-4'));
        [$pagefrom, $pageto] = local_aisgk_topic_parse_page_range($range);
        $apikey = trim((string)($payload['apikey'] ?? ''));
        if ($apikey === '') {
            throw new invalid_parameter_exception('Thiếu Gemini API key');
        }

        $bookrecord = book_repository::get_by_id($bookid);
        if (!$bookrecord) {
            throw new invalid_parameter_exception('Invalid book');
        }

        sgk_processor::render_toc_images($bookid, $pagefrom, $pageto, 200);
        $images = sgk_processor::get_source_images((int)$bookrecord->courseid, $bookid);
        $rows = local_aisgk_topic_gemini_extract_json($apikey, $images);
        $rows = toc_repository::sanitize_rows($rows);
        $rows = toc_repository::calculate_end_pages($rows);

        echo json_encode([
            'ok' => true,
            'rows' => local_aisgk_topic_json_rows($rows),
            'message' => 'AI đã trích xuất ' . count($rows) . ' dòng mục lục.',
        ]);
        exit;
    }

    if ($op === 'save') {
        $rows = toc_repository::sanitize_rows($payload['rows'] ?? []);
        $rows = toc_repository::calculate_end_pages($rows);
        toc_repository::replace_book_toc($bookid, $rows);
        toc_repository::replace_book_toc_draft($bookid, $rows);
        echo json_encode(['ok' => true, 'rows' => local_aisgk_topic_json_rows($rows)]);
        exit;
    }

    if ($op === 'restore') {
        $rows = toc_repository::get_draft_by_bookid($bookid);
        if (!$rows) {
            $rows = toc_repository::get_by_bookid($bookid);
        }
        echo json_encode(['ok' => true, 'rows' => local_aisgk_topic_json_rows($rows)]);
        exit;
    }

    if ($op === 'delete') {
        toc_repository::delete_course_toc_and_draft($courseid);
        echo json_encode(['ok' => true]);
        exit;
    }

    throw new invalid_parameter_exception('Invalid op');
} catch (Throwable $e) {
    @file_put_contents('/tmp/aisgk_gemini.log', "=== CATCH ===\n" . $e->getMessage() . "\n" . $e->getTraceAsString() . "\n\n", FILE_APPEND);
    http_response_code(500);
    echo json_encode(['ok' => false, 'error' => $e->getMessage()]);
}
