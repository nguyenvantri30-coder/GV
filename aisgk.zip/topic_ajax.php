<?php
require('../../config.php');

use local_aisgk\book_repository;
use local_aisgk\local\sgk_processor;
use local_aisgk\toc_repository;
use local_aisgk\ai_key_manager;

define('AJAX_SCRIPT', true);

$courseid = required_param('id', PARAM_INT);
$bookid = required_param('bookid', PARAM_INT);
$op = required_param('op', PARAM_ALPHA);
require_sesskey();

$course = get_course($courseid);
require_login($course);
$context = context_course::instance($courseid);
require_capability('local/aisgk:createtopic', $context);

$book = book_repository::get_by_id($bookid);
if (!$book || (int)$book->courseid !== $courseid) {
    throw new invalid_parameter_exception('Invalid book');
}



function local_aisgk_topic_emit_stream(array $payload): void {
    echo json_encode($payload, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES) . "
";
    if (function_exists('ob_get_level')) {
        while (ob_get_level() > 0) {
            @ob_end_flush();
        }
    }
    flush();
}

function local_aisgk_topic_json_rows(array $rows): array {
    $out = [];
    foreach ($rows as $row) {
        $out[] = [
            'sobai' => (string)($row['sobai'] ?? $row->sobai ?? ''),
            'tenbai' => (string)($row['tenbai'] ?? $row->tenbai ?? ''),
            'trang' => (string)($row['trang'] ?? $row->trang ?? ''),
            'endtrang' => (string)($row['endtrang'] ?? $row->endtrang ?? ''),
            'rawline' => (string)($row['rawline'] ?? $row->rawline ?? ''),
        ];
    }
    return $out;
}


$payload = json_decode(file_get_contents('php://input'), true) ?: [];

function local_aisgk_topic_log(string $message): void {
    global $CFG;
    if (empty($CFG->dataroot)) {
        return;
    }
    @file_put_contents($CFG->dataroot . '/aisgk_gemini.log', '[' . date('Y-m-d H:i:s') . '] ' . $message . "
", FILE_APPEND);
}

function local_aisgk_topic_parse_page_range(string $range): array {
    $range = trim($range);
    $pagefrom = 0;
    $pageto = 0;
    if (preg_match('/^(\d+)\s*-\s*(\d+)$/', $range, $m)) {
        $pagefrom = (int)$m[1];
        $pageto = (int)$m[2];
    } else if (preg_match('/^\d+$/', $range)) {
        $pagefrom = (int)$range;
        $pageto = (int)$range;
    }
    if ($pagefrom < 1 || $pageto < $pagefrom) {
        throw new invalid_parameter_exception('TOC page range invalid');
    }
    return [$pagefrom, $pageto];
}

function local_aisgk_topic_google_extract_json(string $apikey, array $images, string $model = 'gemini-flash-latest'): array {
    $parts = [[
        'text' => 'Trích xuất dữ liệu từ bảng mục lục trong ảnh. Kết quả chỉ xuất JSON hợp lệ, không thêm markdown, không giải thích. JSON phải có dạng {"rows":[{"sobai":"","tenbai":"","trang":""}]}. Giữ nguyên thứ tự mục lục. Nếu không thấy số bài thì sobai để rỗng. Chỉ lấy các dòng mục lục thực sự có tên bài/chương và số trang. Không bịa dữ liệu.'
    ]];

    foreach ($images as $image) {
        $mime = 'image/png';
        $ext = strtolower(pathinfo($image, PATHINFO_EXTENSION));
        if ($ext === 'jpg' || $ext === 'jpeg') {
            $mime = 'image/jpeg';
        } else if ($ext === 'webp') {
            $mime = 'image/webp';
        }
        $data = @file_get_contents($image);
        if ($data === false || $data === '') {
            continue;
        }
        $parts[] = [
            'inline_data' => [
                'mime_type' => $mime,
                'data' => base64_encode($data),
            ],
        ];
    }

    local_aisgk_topic_log('GOOGLE images=' . count($images) . ', parts=' . count($parts) . ', model=' . $model);
    if (count($parts) < 2) {
        throw new moodle_exception('errorprocessingbook', 'local_aisgk', '', 'Không có ảnh mục lục để gửi AI.');
    }

    $request = [
        'contents' => [[
            'parts' => $parts,
        ]],
        'generationConfig' => [
            'response_mime_type' => 'application/json',
            'temperature' => 0.1,
        ],
    ];

    $url = 'https://generativelanguage.googleapis.com/v1beta/models/' . $model . ':generateContent?key=' . urlencode($apikey);
    $ch = curl_init($url);
    curl_setopt_array($ch, [
        CURLOPT_RETURNTRANSFER => true,
        CURLOPT_POST => true,
        CURLOPT_HTTPHEADER => ['Content-Type: application/json'],
        CURLOPT_POSTFIELDS => json_encode($request, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES),
        CURLOPT_TIMEOUT => 120,
    ]);
    $response = curl_exec($ch);
    $errno = curl_errno($ch);
    $error = curl_error($ch);
    $httpcode = (int)curl_getinfo($ch, CURLINFO_RESPONSE_CODE);
    curl_close($ch);

    local_aisgk_topic_log('GOOGLE http=' . $httpcode . ', errno=' . $errno . ', response=' . substr((string)$response, 0, 2000));

    if ($errno) {
        throw new moodle_exception('errorprocessingbook', 'local_aisgk', '', 'Lỗi kết nối Google Gemini: ' . $error);
    }
    if (!is_string($response) || trim($response) === '') {
        throw new moodle_exception('errorprocessingbook', 'local_aisgk', '', 'Google Gemini không trả dữ liệu.');
    }
    $decoded = json_decode($response, true);
    if (!is_array($decoded)) {
        throw new moodle_exception('errorprocessingbook', 'local_aisgk', '', 'Google Gemini trả dữ liệu không hợp lệ: ' . $response);
    }
    if ($httpcode >= 400 || !empty($decoded['error'])) {
        $message = (string)($decoded['error']['message'] ?? ('Google Gemini HTTP ' . $httpcode));
        $status = strtoupper((string)($decoded['error']['status'] ?? ''));
        $quotahit = (bool)preg_match('/quota|rate limit|resource exhausted|429|free tier/i', $message . ' ' . $status);
        throw new moodle_exception('errorprocessingbook', 'local_aisgk', '', ($quotahit ? 'FREE_TIER_QUOTA_EXCEEDED: ' : 'GEMINI_ERROR: ') . $message);
    }

    $text = '';
    foreach (($decoded['candidates'] ?? []) as $candidate) {
        foreach (($candidate['content']['parts'] ?? []) as $part) {
            if (!empty($part['text'])) {
                $text .= $part['text'];
            }
        }
    }
    return local_aisgk_topic_extract_rows_from_text($text);
}

function local_aisgk_topic_shopaikey_extract_json(string $apikey, array $images, string $model): array {
    $content = [[
        'type' => 'text',
        'text' => 'Trích xuất dữ liệu từ bảng mục lục trong ảnh. Kết quả chỉ xuất JSON hợp lệ, không thêm markdown, không giải thích. JSON phải có dạng {"rows":[{"sobai":"","tenbai":"","trang":""}]}. Giữ nguyên thứ tự mục lục. Nếu không thấy số bài thì sobai để rỗng. Chỉ lấy các dòng mục lục thực sự có tên bài/chương và số trang. Không bịa dữ liệu.'
    ]];

    foreach ($images as $image) {
        $mime = 'image/png';
        $ext = strtolower(pathinfo($image, PATHINFO_EXTENSION));
        if ($ext === 'jpg' || $ext === 'jpeg') {
            $mime = 'image/jpeg';
        } else if ($ext === 'webp') {
            $mime = 'image/webp';
        }
        $data = @file_get_contents($image);
        if ($data === false || $data === '') {
            continue;
        }
        $content[] = [
            'type' => 'image_url',
            'image_url' => [
                'url' => 'data:' . $mime . ';base64,' . base64_encode($data),
            ],
        ];
    }

    local_aisgk_topic_log('SHOPAIKEY images=' . count($images) . ', parts=' . count($content) . ', model=' . $model);
    if (count($content) < 2) {
        throw new moodle_exception('errorprocessingbook', 'local_aisgk', '', 'Không có ảnh mục lục để gửi AI.');
    }

    $request = [
        'model' => $model,
        'messages' => [[
            'role' => 'user',
            'content' => $content,
        ]],
        'temperature' => 0.1,
        'response_format' => ['type' => 'json_object'],
    ];

    $url = 'https://api.shopaikey.com/v1/chat/completions';
    $ch = curl_init($url);
    curl_setopt_array($ch, [
        CURLOPT_RETURNTRANSFER => true,
        CURLOPT_POST => true,
        CURLOPT_HTTPHEADER => [
            'Content-Type: application/json',
            'Authorization: Bearer ' . $apikey,
        ],
        CURLOPT_POSTFIELDS => json_encode($request, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES),
        CURLOPT_TIMEOUT => 120,
    ]);
    $response = curl_exec($ch);
    $errno = curl_errno($ch);
    $error = curl_error($ch);
    $httpcode = (int)curl_getinfo($ch, CURLINFO_RESPONSE_CODE);
    curl_close($ch);

    local_aisgk_topic_log('SHOPAIKEY http=' . $httpcode . ', errno=' . $errno . ', response=' . substr((string)$response, 0, 2000));

    if ($errno) {
        throw new moodle_exception('errorprocessingbook', 'local_aisgk', '', 'Lỗi kết nối ShopAIKey: ' . $error);
    }
    if (!is_string($response) || trim($response) === '') {
        throw new moodle_exception('errorprocessingbook', 'local_aisgk', '', 'ShopAIKey không trả dữ liệu.');
    }
    $decoded = json_decode($response, true);
    if (!is_array($decoded)) {
        throw new moodle_exception('errorprocessingbook', 'local_aisgk', '', 'ShopAIKey trả dữ liệu không hợp lệ: ' . $response);
    }
    if ($httpcode >= 400 || !empty($decoded['error'])) {
        $err = $decoded['error'] ?? [];
        $message = is_array($err) ? (string)($err['message'] ?? ('ShopAIKey HTTP ' . $httpcode)) : (string)$err;
        $quotahit = (bool)preg_match('/quota|rate limit|resource exhausted|429|too many requests/i', $message);
        throw new moodle_exception('errorprocessingbook', 'local_aisgk', '', ($quotahit ? 'FREE_TIER_QUOTA_EXCEEDED: ' : 'SHOPAIKEY_ERROR: ') . $message);
    }

    $text = (string)($decoded['choices'][0]['message']['content'] ?? '');
    if (is_array($decoded['choices'][0]['message']['content'] ?? null)) {
        $pieces = [];
        foreach ($decoded['choices'][0]['message']['content'] as $part) {
            if (!empty($part['text'])) { $pieces[] = $part['text']; }
        }
        $text = implode("
", $pieces);
    }
    return local_aisgk_topic_extract_rows_from_text($text);
}

function local_aisgk_topic_extract_rows_from_text(string $text): array {
    $text = trim($text);
    if ($text === '') {
        throw new moodle_exception('errorprocessingbook', 'local_aisgk', '', 'AI không trả phần JSON văn bản.');
    }
    $json = json_decode($text, true);
    if (!is_array($json) && preg_match('/\{.*\}/s', $text, $m)) {
        $json = json_decode($m[0], true);
    }
    if (!is_array($json)) {
        throw new moodle_exception('errorprocessingbook', 'local_aisgk', '', 'Không phân tích được JSON AI trả về: ' . mb_substr($text, 0, 1000));
    }
    $rows = $json['rows'] ?? $json;
    if (!is_array($rows)) {
        throw new moodle_exception('errorprocessingbook', 'local_aisgk', '', 'JSON AI không có mảng rows hợp lệ.');
    }
    return $rows;
}

function local_aisgk_topic_ai_extract_json(\stdClass $key, array $images, string $feature = 'scan'): array {
    $provider = trim((string)($key->provider ?? (($key->category_key ?? 'free') === 'pay' ? 'shopaikey' : 'google')));
    $model = trim((string)($feature === 'homework' ? ($key->model_homework ?? '') : ($key->model_scan ?? '')));
    if ($model === '') {
        if ($provider === 'shopaikey') {
            $model = $feature === 'homework' ? 'gpt-5.4-mini' : 'gemini-3.1-flash-lite-preview';
        } else {
            $model = 'gemini-flash-latest';
        }
    }
    $apikey = trim((string)($key->api_key ?? ''));
    if ($apikey === '') {
        throw new moodle_exception('errorprocessingbook', 'local_aisgk', '', 'API key rỗng.');
    }
    if ($provider === 'shopaikey') {
        return local_aisgk_topic_shopaikey_extract_json($apikey, $images, $model);
    }
    return local_aisgk_topic_google_extract_json($apikey, $images, $model);
}

if ($op === 'scanadvanced') {
    header('Content-Type: text/plain; charset=utf-8');
    @ini_set('output_buffering', 'off');
    @ini_set('zlib.output_compression', '0');
    @set_time_limit(0);

    try {
        $columns = ((int)($payload['columns'] ?? 1) === 2) ? 2 : 1;
        $psm = max(3, min(13, (int)($payload['psm'] ?? 4)));
        $range = trim((string)($payload['pagerange'] ?? '3-4'));
        [$pagefrom, $pageto] = local_aisgk_topic_parse_page_range($range);

        local_aisgk_topic_emit_stream(['ok' => true, 'type' => 'start']);
        $preview = sgk_processor::preview_topic_items_advanced(
            $bookid,
            $columns,
            50,
            $psm,
            $pagefrom,
            $pageto,
            static function(array $progress): void {
                local_aisgk_topic_emit_stream(['ok' => true, 'type' => 'progress', 'progress' => $progress]);
            }
        );

        $rows = [];
        foreach ($preview['items'] as $item) {
            $rows[] = [
                'sobai' => $item['lessonno'] ?? '',
                'tenbai' => $item['lessontitle'] ?? '',
                'trang' => $item['startpage'] ?? '',
                'endtrang' => $item['endpage'] ?? '',
                'rawline' => $item['rawocr'] ?? '',
            ];
        }
        $rows = toc_repository::calculate_end_pages($rows);
        local_aisgk_topic_emit_stream(['ok' => true, 'type' => 'result', 'rows' => local_aisgk_topic_json_rows($rows)]);
    } catch (Throwable $e) {
        http_response_code(500);
        local_aisgk_topic_emit_stream(['ok' => false, 'error' => $e->getMessage()]);
    }
    exit;
}

header('Content-Type: application/json; charset=utf-8');

try {
    if ($op === 'scan') {
        $columns = ((int)($payload['columns'] ?? 1) === 2) ? 2 : 1;
        $psm = max(3, min(13, (int)($payload['psm'] ?? 4)));
        $range = trim((string)($payload['pagerange'] ?? '3-4'));
        [$pagefrom, $pageto] = local_aisgk_topic_parse_page_range($range);
        $preview = sgk_processor::preview_topic_items($bookid, $columns, 50, $psm, $pagefrom, $pageto);
        $rows = [];
        foreach ($preview['items'] as $item) {
            $rows[] = [
                'sobai' => $item['lessonno'] ?? '',
                'tenbai' => $item['lessontitle'] ?? '',
                'trang' => $item['startpage'] ?? '',
                'endtrang' => $item['endpage'] ?? '',
                'rawline' => $item['rawocr'] ?? '',
            ];
        }
        $rows = toc_repository::calculate_end_pages($rows);
        echo json_encode(['ok' => true, 'rows' => local_aisgk_topic_json_rows($rows)]);
        exit;
    }

if ($op === 'aiextract') {
    $range = trim((string)($payload['pagerange'] ?? '3-4'));
    [$pagefrom, $pageto] = local_aisgk_topic_parse_page_range($range);

    $bookrecord = book_repository::get_by_id($bookid);
    if (!$bookrecord) {
        throw new invalid_parameter_exception('Invalid book');
    }

    sgk_processor::render_toc_images($bookid, $pagefrom, $pageto, 200);
    $images = sgk_processor::get_source_images((int)$bookrecord->courseid, $bookid);

    $attempts = [];
    $rows = null;
    $maxtries = 3;

    for ($try = 1; $try <= $maxtries; $try++) {
        $key = ai_key_manager::get_available_key('scan');
        if (!$key) {
            if ($try === 1) {
                throw new moodle_exception('errorprocessingbook', 'local_aisgk', '', 'Không có AI key khả dụng.');
            }
            break;
        }

        if (in_array((int)$key->id, $attempts, true)) {
            break;
        }
        $attempts[] = (int)$key->id;

        $apikey = trim((string)$key->api_key);
        if ($apikey === '') {
            ai_key_manager::mark_blocked($key, 'API key rỗng');
            continue;
        }

        $model = trim((string)($key->model_scan ?? ''));
        if ($model === '') {
            $model = ($key->category_key ?? '') === 'pay'
                ? 'gemini-3.1-flash-lite-preview'
                : 'gemini-flash-latest';
        }

        usleep(rand(2000000, 4000000));

        try {
            $rows = local_aisgk_topic_gemini_extract_json($apikey, $images, $model);
            ai_key_manager::mark_success($key);
            break;
        } catch (Throwable $e) {
            $msg = $e->getMessage();

            if (preg_match('/429|rate limit|resource exhausted|quota|too many requests/i', $msg)) {
                ai_key_manager::mark_429($key);
                continue;
            }

            if (preg_match('/invalid api key|api key not valid|forbidden|permission denied|401|403|unauthorized/i', $msg)) {
                ai_key_manager::mark_blocked($key, $msg);
                continue;
            }

            ai_key_manager::mark_blocked($key, $msg);
            continue;
        }
    }

    if ($rows === null) {
        throw new moodle_exception('errorprocessingbook', 'local_aisgk', '', 'Tất cả AI key hiện thời đều không dùng được hoặc đang cooldown.');
    }

    $rows = toc_repository::sanitize_rows($rows);
    $rows = toc_repository::calculate_end_pages($rows);

    echo json_encode([
        'ok' => true,
        'rows' => local_aisgk_topic_json_rows($rows),
        'message' => 'AI đã trích xuất ' . count($rows) . ' dòng mục lục.',
    ]);
    exit;
}
//----------
    if ($op === 'save') {
        $rows = toc_repository::sanitize_rows($payload['rows'] ?? []);
        $rows = toc_repository::calculate_end_pages($rows);
        toc_repository::replace_book_toc($bookid, $rows);
        toc_repository::replace_book_toc_draft($bookid, $rows);
        echo json_encode(['ok' => true, 'rows' => local_aisgk_topic_json_rows($rows)]);
        exit;
    }

    if ($op === 'restore') {
        $rows = toc_repository::get_draft_by_bookid($bookid);
        if (!$rows) {
            $rows = toc_repository::get_by_bookid($bookid);
        }
        echo json_encode(['ok' => true, 'rows' => local_aisgk_topic_json_rows($rows)]);
        exit;
    }

    if ($op === 'delete') {
        toc_repository::delete_course_toc_and_draft($courseid);
        echo json_encode(['ok' => true]);
        exit;
    }

    throw new invalid_parameter_exception('Invalid op');
} catch (Throwable $e) {
    local_aisgk_topic_log('CATCH: ' . $e->getMessage());
    http_response_code(500);
    echo json_encode(['ok' => false, 'error' => $e->getMessage()]);
}
