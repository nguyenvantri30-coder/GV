<?php
require('../../config.php');

use local_aisgk\book_repository;
use local_aisgk\local\sgk_processor;
use local_aisgk\toc_repository;

define('AJAX_SCRIPT', true);

$courseid = required_param('id', PARAM_INT);
$bookid = required_param('bookid', PARAM_INT);
$op = required_param('op', PARAM_ALPHA);
require_sesskey();

$course = get_course($courseid);
require_login($course);
$context = context_course::instance($courseid);
require_capability('local/aisgk:createtopic', $context);

$book = book_repository::get_by_id($bookid);
if (!$book || (int)$book->courseid !== $courseid) {
    throw new invalid_parameter_exception('Invalid book');
}

header('Content-Type: application/json; charset=utf-8');

function local_aisgk_topic_json_rows(array $rows): array {
    $out = [];
    foreach ($rows as $row) {
        $out[] = [
            'sobai' => (string)($row['sobai'] ?? $row->sobai ?? ''),
            'tenbai' => (string)($row['tenbai'] ?? $row->tenbai ?? ''),
            'trang' => (string)($row['trang'] ?? $row->trang ?? ''),
            'endtrang' => (string)($row['endtrang'] ?? $row->endtrang ?? ''),
            'rawline' => (string)($row['rawline'] ?? $row->rawline ?? ''),
        ];
    }
    return $out;
}

$payload = json_decode(file_get_contents('php://input'), true) ?: [];

try {
    if ($op === 'scan') {
        $columns = ((int)($payload['columns'] ?? 1) === 2) ? 2 : 1;
        $psm = max(3, min(13, (int)($payload['psm'] ?? 4)));
        $range = trim((string)($payload['pagerange'] ?? '3-4'));
        $pagefrom = 0;
        $pageto = 0;
        if (preg_match('/^(\d+)\s*-\s*(\d+)$/', $range, $m)) {
            $pagefrom = (int)$m[1];
            $pageto = (int)$m[2];
        } else if (preg_match('/^\d+$/', $range)) {
            $pagefrom = (int)$range;
            $pageto = (int)$range;
        }
        if ($pagefrom < 1 || $pageto < $pagefrom) {
            throw new invalid_parameter_exception('TOC page range invalid');
        }
        $preview = sgk_processor::preview_topic_items($bookid, $columns, 50, $psm, $pagefrom, $pageto);
        $rows = [];
        foreach ($preview['items'] as $item) {
            $rows[] = [
                'sobai' => $item['lessonno'] ?? '',
                'tenbai' => $item['lessontitle'] ?? '',
                'trang' => $item['startpage'] ?? '',
                'endtrang' => $item['endpage'] ?? '',
                'rawline' => $item['rawocr'] ?? '',
            ];
        }
        $rows = toc_repository::calculate_end_pages($rows);
        echo json_encode(['ok' => true, 'rows' => local_aisgk_topic_json_rows($rows)]);
        exit;
    }

    if ($op === 'save') {
        $rows = toc_repository::sanitize_rows($payload['rows'] ?? []);
        $rows = toc_repository::calculate_end_pages($rows);
        toc_repository::replace_book_toc($bookid, $rows);
        toc_repository::replace_book_toc_draft($bookid, $rows);
        echo json_encode(['ok' => true, 'rows' => local_aisgk_topic_json_rows($rows)]);
        exit;
    }

    if ($op === 'restore') {
        $rows = toc_repository::get_draft_by_bookid($bookid);
        if (!$rows) {
            $rows = toc_repository::get_by_bookid($bookid);
        }
        echo json_encode(['ok' => true, 'rows' => local_aisgk_topic_json_rows($rows)]);
        exit;
    }

    if ($op === 'delete') {
        toc_repository::delete_course_toc_and_draft($courseid);
        echo json_encode(['ok' => true]);
        exit;
    }

    throw new invalid_parameter_exception('Invalid op');
} catch (Throwable $e) {
    http_response_code(500);
    echo json_encode(['ok' => false, 'error' => $e->getMessage()]);
}
