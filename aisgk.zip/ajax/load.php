<?php
require('../../../config.php');
require_login();
require_sesskey();

use local_aisgk\book_repository;
use local_aisgk\toc_repository;
use local_aisgk\local\sgk_processor;

header('Content-Type: application/json; charset=utf-8');
$data = json_decode(file_get_contents('php://input'));
if (!$data) { $data = (object)[]; }

$courseid = isset($data->courseid) ? (int)$data->courseid : 0;
$bookid = isset($data->bookid) ? (int)$data->bookid : 0;

$course = get_course($courseid);
require_login($course);
$context = context_course::instance($courseid);
require_capability('local/aisgk:createtopic', $context);
$book = book_repository::get_by_id($bookid);
if (!$book || (int)$book->courseid !== $courseid) {
    throw new moodle_exception('invalidparameter');
}

$drafts = $DB->get_records('local_aisgk_book_toc_draft', ['courseid' => $courseid, 'bookid' => $bookid], 'sortorder ASC, id ASC');
$rows = [];
if ($drafts) {
    foreach ($drafts as $row) {
        $rows[] = [
            'sobai' => ((string)$row->sobai === '0') ? '' : (string)$row->sobai,
            'tenbai' => (string)$row->tenbai,
            'trang' => (string)($row->trang ?? ''),
            'endtrang' => (string)($row->endtrang ?? ''),
            'rawline' => (string)($row->rawline ?? ''),
            'source' => 'Draft',
        ];
    }
} else {
    foreach (toc_repository::get_by_bookid($bookid) as $row) {
        $rows[] = [
            'sobai' => ((string)$row->sobai === '0') ? '' : (string)$row->sobai,
            'tenbai' => (string)$row->tenbai,
            'trang' => (string)($row->trang ?? ''),
            'endtrang' => (string)($row->endtrang ?? ''),
            'rawline' => (string)($row->rawline ?? ''),
            'source' => 'Saved',
        ];
    }
}

echo json_encode([
    'rows' => $rows,
    'tocpage' => ((int)$book->tocfrompage) . '-' . ((int)$book->toctopage),
], JSON_UNESCAPED_UNICODE);
