<?php
require('../../../config.php');
require_login();
require_sesskey();

use local_aisgk\book_repository;
use local_aisgk\toc_repository;
use local_aisgk\local\sgk_processor;

header('Content-Type: application/json; charset=utf-8');
$data = json_decode(file_get_contents('php://input'));
if (!$data) { $data = (object)[]; }

$courseid = isset($data->courseid) ? (int)$data->courseid : 0;
$bookid = isset($data->bookid) ? (int)$data->bookid : 0;
$frompage = isset($data->frompage) ? max(1, (int)$data->frompage) : 3;
$topage = isset($data->topage) ? max($frompage, (int)$data->topage) : $frompage;
$rows = isset($data->rows) && is_array($data->rows) ? $data->rows : [];

$course = get_course($courseid);
require_login($course);
$context = context_course::instance($courseid);
require_capability('local/aisgk:createtopic', $context);
$book = book_repository::get_by_id($bookid);
if (!$book || (int)$book->courseid !== $courseid) {
    throw new moodle_exception('invalidparameter');
}

$clean = [];
foreach ($rows as $row) {
    $r = [
        'sobai' => trim((string)($row->sobai ?? '')),
        'tenbai' => trim((string)($row->tenbai ?? '')),
        'trang' => trim((string)($row->trang ?? '')),
        'endtrang' => trim((string)($row->endtrang ?? '')),
        'rawline' => trim((string)($row->rawline ?? '')),
    ];
    if ($r['sobai'] === '' && $r['tenbai'] === '' && $r['trang'] === '' && $r['endtrang'] === '' && $r['rawline'] === '') {
        continue;
    }
    $clean[] = $r;
}
$clean = toc_repository::calculate_end_pages($clean);
toc_repository::replace_book_toc($bookid, $clean);

$DB->delete_records('local_aisgk_book_toc_draft', ['courseid' => $courseid, 'bookid' => $bookid]);
$now = time();
$sort = 1;
foreach ($clean as $row) {
    $rec = (object)[
        'courseid' => $courseid,
        'bookid' => $bookid,
        'sobai' => is_numeric($row['sobai']) ? (int)$row['sobai'] : 0,
        'tenbai' => (string)($row['tenbai'] ?? ''),
        'trang' => ($row['trang'] !== '' && is_numeric($row['trang'])) ? (int)$row['trang'] : null,
        'endtrang' => ($row['endtrang'] !== '' && is_numeric($row['endtrang'])) ? (int)$row['endtrang'] : null,
        'sortorder' => $sort++,
        'rawline' => (string)($row['rawline'] ?? ''),
        'timecreated' => $now,
        'timemodified' => $now,
        'usermodified' => $USER->id,
    ];
    $DB->insert_record('local_aisgk_book_toc_draft', $rec);
}

$book->tocfrompage = $frompage;
$book->toctopage = $topage;
$book->timemodified = $now;
$DB->update_record('local_aisgk_books', $book);

echo json_encode(['ok' => 1, 'rowcount' => count($clean)], JSON_UNESCAPED_UNICODE);
