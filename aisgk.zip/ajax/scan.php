<?php
require('../../../config.php');
require_login();
require_sesskey();

use local_aisgk\book_repository;
use local_aisgk\toc_repository;
use local_aisgk\local\sgk_processor;

header('Content-Type: application/json; charset=utf-8');
$data = json_decode(file_get_contents('php://input'));
if (!$data) { $data = (object)[]; }

$courseid = isset($data->courseid) ? (int)$data->courseid : 0;
$bookid = isset($data->bookid) ? (int)$data->bookid : 0;
$columns = (isset($data->columns) && (int)$data->columns === 2) ? 2 : 1;
$psm = isset($data->psm) ? (int)$data->psm : 6;
$frompage = isset($data->frompage) ? max(1, (int)$data->frompage) : 3;
$topage = isset($data->topage) ? max($frompage, (int)$data->topage) : $frompage;

$course = get_course($courseid);
require_login($course);
$context = context_course::instance($courseid);
require_capability('local/aisgk:createtopic', $context);
$book = book_repository::get_by_id($bookid);
if (!$book || (int)$book->courseid !== $courseid) {
    throw new moodle_exception('invalidparameter');
}

$preview = sgk_processor::preview_topic_lines($bookid, $frompage, $topage, $columns, 50, $psm);
$items = [];
foreach ($preview['content_lines'] as $line) {
    if (sgk_processor::is_target_line($line)) {
        $items[] = $line;
    }
}
$parsed = sgk_processor::parse_bai_lines($items);
$rows = [];
foreach ($parsed as $item) {
    $rows[] = [
        'sobai' => $item['lessonno'] ?? '',
        'tenbai' => $item['lessontitle'] ?? '',
        'trang' => $item['startpage'] ?? '',
        'endtrang' => $item['endpage'] ?? '',
        'rawline' => $item['rawocr'] ?? '',
        'source' => 'Scan',
    ];
}
$rows = toc_repository::calculate_end_pages($rows);
echo json_encode(['rows' => array_values($rows)], JSON_UNESCAPED_UNICODE);
