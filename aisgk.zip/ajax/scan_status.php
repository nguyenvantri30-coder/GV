<?php
require('../../../config.php');

$jobid = required_param('jobid', PARAM_INT);
$courseid = required_param('courseid', PARAM_INT);

$course = get_course($courseid);
require_login($course);
$context = context_course::instance($courseid);
require_capability('local/aisgk:createtopic', $context);

header('Content-Type: application/json; charset=utf-8');

global $DB;
$job = $DB->get_record('local_aisgk_scanjobs', ['id' => $jobid], '*', IGNORE_MISSING);
if (!$job) {
    echo json_encode(['ok' => false, 'error' => 'Job not found']);
    exit;
}

$data = [
    'id' => (int)$job->id,
    'status' => (string)$job->status,
    'stepno' => (int)$job->stepno,
    'steptext' => (string)$job->steptext,
    'progress' => (int)$job->progress,
    'message' => (string)($job->message ?? ''),
    'errormsg' => (string)($job->errormsg ?? ''),
    'result' => null,
];
if (!empty($job->resultjson)) {
    $decoded = json_decode($job->resultjson, true);
    if (is_array($decoded)) {
        $data['result'] = $decoded;
    }
}

echo json_encode(['ok' => true, 'job' => $data]);
