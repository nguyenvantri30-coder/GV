<?php
require('../../../config.php');
require_login();
require_sesskey();

use local_aisgk\book_repository;
use local_aisgk\toc_repository;
use local_aisgk\local\sgk_processor;

header('Content-Type: application/json; charset=utf-8');
$data = json_decode(file_get_contents('php://input'));
if (!$data) { $data = (object)[]; }

$courseid = isset($data->courseid) ? (int)$data->courseid : 0;
$course = get_course($courseid);
require_login($course);
$context = context_course::instance($courseid);
require_capability('local/aisgk:createtopic', $context);

$bookids = $DB->get_fieldset_select('local_aisgk_books', 'id', 'courseid = ?', [$courseid]);
if ($bookids) {
    list($insql, $params) = $DB->get_in_or_equal($bookids, SQL_PARAMS_QM);
    $DB->delete_records_select('local_aisgk_book_toc', 'bookid ' . $insql, $params);
}
$DB->delete_records('local_aisgk_book_toc_draft', ['courseid' => $courseid]);

echo json_encode(['ok' => 1, 'rowcount' => 0], JSON_UNESCAPED_UNICODE);
