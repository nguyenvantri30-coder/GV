<?php
require('../../../config.php');

use local_aisgk\book_repository;

$courseid = required_param('courseid', PARAM_INT);
$bookid = required_param('bookid', PARAM_INT);
$columns = optional_param('columns', 1, PARAM_INT);
$psm = optional_param('psm', 3, PARAM_INT);
require_sesskey();

$course = get_course($courseid);
require_login($course);
$context = context_course::instance($courseid);
require_capability('local/aisgk:createtopic', $context);

$columns = ($columns === 2) ? 2 : 1;
$psm = max(3, min(11, $psm));

$book = book_repository::get_by_id($bookid);
if (!$book || (int)$book->courseid !== $courseid) {
    throw new moodle_exception('invalidparameter');
}

header('Content-Type: application/json; charset=utf-8');

global $DB, $CFG, $USER;

$existing = $DB->get_records_select('local_aisgk_scanjobs', 'bookid = ? AND status IN (?, ?)', [$bookid, 'queued', 'running'], 'id DESC', '*', 0, 1);
if ($existing) {
    $job = reset($existing);
    echo json_encode(['ok' => true, 'jobid' => (int)$job->id, 'reused' => true]);
    exit;
}

$job = (object)[
    'bookid' => $bookid,
    'courseid' => $courseid,
    'userid' => $USER->id,
    'status' => 'queued',
    'stepno' => 1,
    'steptext' => 'Bắt đầu',
    'progress' => 0,
    'columns' => $columns,
    'psm' => $psm,
    'message' => 'Đang xếp vào hàng đợi',
    'resultjson' => null,
    'errormsg' => null,
    'timecreated' => time(),
    'timeupdated' => time(),
];
$jobid = $DB->insert_record('local_aisgk_scanjobs', $job);

$phpbin = PHP_BINARY ?: '/usr/bin/php';
$script = $CFG->dirroot . '/local/aisgk/cli/advanced_scan.php';
$cmd = escapeshellcmd($phpbin) . ' ' . escapeshellarg($script) . ' --jobid=' . (int)$jobid . ' > /dev/null 2>&1 &';
exec($cmd);

echo json_encode(['ok' => true, 'jobid' => (int)$jobid, 'reused' => false]);
