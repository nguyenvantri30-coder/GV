<?php
defined('MOODLE_INTERNAL') || die();

if ($hassiteconfig) {
    // ALSM must remain a top-level Site administration category, not hidden under Local plugins.
    $alsmcategory = 'local_aisgk_admin';
    if (!$ADMIN->locate($alsmcategory)) {
        $ADMIN->add('root', new admin_category($alsmcategory, get_string('alsm', 'local_aisgk')));
    }

    $ADMIN->add($alsmcategory, new admin_externalpage(
        'local_aisgk_portal',
        get_string('alsmportal', 'local_aisgk'),
        new moodle_url('/local/aisgk/index.php'),
        'moodle/site:config'
    ));

    $ADMIN->add($alsmcategory, new admin_externalpage(
        'local_aisgk_year_backup',
        get_string('yearbackup', 'local_aisgk'),
        new moodle_url('/local/aisgk/year_backup.php'),
        'moodle/site:config'
    ));
    $ADMIN->add($alsmcategory, new admin_externalpage(
        'local_aisgk_year_new',
        get_string('newschoolyear', 'local_aisgk'),
        new moodle_url('/local/aisgk/year_new.php'),
        'moodle/site:config'
    ));
    $ADMIN->add($alsmcategory, new admin_externalpage(
        'local_aisgk_year_inherit',
        get_string('inheritdata', 'local_aisgk'),
        new moodle_url('/local/aisgk/year_inherit.php'),
        'moodle/site:config'
    ));
}
