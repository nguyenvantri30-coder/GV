<?php
defined('MOODLE_INTERNAL') || die();

if ($hassiteconfig) {
    // Keep ALSM visible even if Moodle renders local plugin settings under different trees.
    // Primary entry: top-level Site administration item.
    $ADMIN->add('root', new admin_externalpage(
        'local_aisgk',
        get_string('alsm', 'local_aisgk'),
        new moodle_url('/local/aisgk/index.php'),
        'moodle/site:config'
    ));

    // Fallback entry under Plugins > Local plugins, so ALSM is still reachable if a theme/admin tree
    // does not display root-level pages contributed by local plugins.
    $fallbackcategory = 'local_aisgk_admin';
    if (!$ADMIN->locate($fallbackcategory)) {
        $ADMIN->add('localplugins', new admin_category($fallbackcategory, get_string('alsm', 'local_aisgk')));
    }

    $ADMIN->add($fallbackcategory, new admin_externalpage(
        'local_aisgk_portal_fallback',
        get_string('alsmportal', 'local_aisgk'),
        new moodle_url('/local/aisgk/index.php'),
        'moodle/site:config'
    ));

    $ADMIN->add($fallbackcategory, new admin_externalpage(
        'local_aisgk_year_backup',
        get_string('yearbackup', 'local_aisgk'),
        new moodle_url('/local/aisgk/year_backup.php'),
        'moodle/site:config'
    ));
    $ADMIN->add($fallbackcategory, new admin_externalpage(
        'local_aisgk_year_new',
        get_string('newschoolyear', 'local_aisgk'),
        new moodle_url('/local/aisgk/year_new.php'),
        'moodle/site:config'
    ));
    $ADMIN->add($fallbackcategory, new admin_externalpage(
        'local_aisgk_year_inherit',
        get_string('inheritdata', 'local_aisgk'),
        new moodle_url('/local/aisgk/year_inherit.php'),
        'moodle/site:config'
    ));
}
