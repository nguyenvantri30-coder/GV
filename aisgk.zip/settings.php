<?php
defined('MOODLE_INTERNAL') || die();

if ($hassiteconfig) {
    $ADMIN->add('localplugins', new admin_category('local_aisgk_admin', get_string('alsm', 'local_aisgk')));
    $ADMIN->add('local_aisgk_admin', new admin_externalpage(
        'local_aisgk_year_backup',
        get_string('yearbackup', 'local_aisgk'),
        new moodle_url('/local/aisgk/year_backup.php'),
        'moodle/site:config'
    ));
    $ADMIN->add('local_aisgk_admin', new admin_externalpage(
        'local_aisgk_year_new',
        get_string('newschoolyear', 'local_aisgk'),
        new moodle_url('/local/aisgk/year_new.php'),
        'moodle/site:config'
    ));
    $ADMIN->add('local_aisgk_admin', new admin_externalpage(
        'local_aisgk_year_inherit',
        get_string('inheritdata', 'local_aisgk'),
        new moodle_url('/local/aisgk/year_inherit.php'),
        'moodle/site:config'
    ));
}
