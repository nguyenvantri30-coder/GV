<?php
require('../../config.php');

use local_aisgk\aikey_repository;
use local_aisgk\ai_key_manager;

if (!defined('AJAX_SCRIPT')) {
    define('AJAX_SCRIPT', true);
}
$courseid = required_param('id', PARAM_INT);
$op = required_param('op', PARAM_ALPHAEXT);
require_sesskey();
$course = get_course($courseid);
require_login($course);
$context = context_course::instance($courseid);
require_capability('local/aisgk:createhomework', $context);
header('Content-Type: application/json; charset=utf-8');
$payload = json_decode(file_get_contents('php://input'), true) ?: [];

function local_aisgk_myapi_row_json($row): array {
    $lastused = (int)($row->last_used ?? 0);
    $lasttokensat = (int)($row->last_tokens_at ?? 0);
    return [
        'id' => (int)($row->id ?? 0),
        'gmail_account' => (string)($row->gmail_account ?? ''),
        'api_key' => (string)($row->api_key ?? ''),
        'category_key' => (string)($row->category_key ?? 'free'),
        'provider' => (string)($row->provider ?? 'google'),
        'model_scan' => (string)($row->model_scan ?? 'gemini-flash-latest'),
        'model_homework' => (string)($row->model_homework ?? 'gemini-flash-latest'),
        'model_img' => (string)($row->model_img ?? ''),
        'model_scan_status' => (string)($row->model_scan_status ?? ''),
        'model_homework_status' => (string)($row->model_homework_status ?? ''),
        'model_img_status' => (string)($row->model_img_status ?? ''),
        'status' => (string)($row->status ?? 'active'),
        'last_used' => $lastused > 0 ? userdate($lastused, '%Y-%m-%dT%H:%M') : '',
        'last_model' => (string)($row->last_model ?? ''),
        'last_tokens' => (int)($row->last_tokens ?? 0),
        'last_tokens_at' => $lasttokensat > 0 ? userdate($lasttokensat, '%Y-%m-%d %H:%M') : '',
        'last_error' => (string)($row->last_error ?? ''),
        'usage_remaining' => (string)($row->usage_remaining ?? '0'),
        'daily_limit' => (int)($row->daily_limit ?? 0),
        'daily_used' => (int)($row->daily_used ?? 0),
        'models_cache_json' => (string)($row->models_cache_json ?? ''),
        'models_cache_at' => (int)($row->models_cache_at ?? 0),
    ];
}
function local_aisgk_myapi_rows_json(array $rows): array { return array_map('local_aisgk_myapi_row_json', array_values($rows)); }

function local_aisgk_http_json(string $url, array $headers, $payload = null, int $timeout = 45, string $method = 'POST'): array {
    $ch = curl_init($url);
    $opts = [CURLOPT_RETURNTRANSFER => true, CURLOPT_TIMEOUT => $timeout, CURLOPT_HTTPHEADER => $headers];
    if (strtoupper($method) === 'POST') {
        $opts[CURLOPT_POST] = true;
        $opts[CURLOPT_POSTFIELDS] = json_encode($payload, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
    }
    curl_setopt_array($ch, $opts);
    $response = curl_exec($ch);
    $http = (int)curl_getinfo($ch, CURLINFO_HTTP_CODE);
    $err = curl_error($ch);
    curl_close($ch);
    $json = json_decode((string)$response, true);
    return ['http' => $http, 'error' => $err, 'raw' => (string)$response, 'json' => is_array($json) ? $json : null];
}

function local_aisgk_detect_image_transport($value): string {
    if (!is_array($value)) { return 'unknown'; }

    // OpenAI / proxy URL shapes. Prefer URL if both are present because it avoids
    // carrying base64 through Moodle memory after the API call.
    foreach (['url', 'image_url', 'file_url', 'uri', 'fileUri', 'file_uri'] as $k) {
        if (!empty($value[$k]) && is_string($value[$k])) {
            $v = trim($value[$k]);
            if (preg_match('#^https?://#i', $v) || preg_match('#^gs://#i', $v)) {
                return 'url';
            }
        }
    }

    // Gemini inlineData and OpenAI/proxy b64_json/base64 shapes. This is only a
    // transport format; generated JSON must still store Moodle fileurl only.
    foreach (['inlineData', 'inline_data'] as $k) {
        if (!empty($value[$k]) && is_array($value[$k]) && !empty($value[$k]['data'])) {
            return 'base64';
        }
    }
    foreach (['b64_json', 'base64', 'base64_data', 'image_base64', 'data'] as $k) {
        if (!empty($value[$k]) && is_string($value[$k])) {
            $v = trim($value[$k]);
            if ($v !== '' && (preg_match('#^data:image/[^;]+;base64,#i', $v) || strlen($v) > 80)) {
                return 'base64';
            }
        }
    }

    // Known nested containers.
    foreach (['candidates', 'content', 'parts', 'data', 'images', 'predictions', 'artifacts', 'output', 'result'] as $k) {
        if (!empty($value[$k])) {
            $fmt = local_aisgk_detect_image_transport($value[$k]);
            if ($fmt !== 'unknown') { return $fmt; }
        }
    }

    // Generic recursion for provider/proxy wrappers.
    foreach ($value as $child) {
        if (is_array($child)) {
            $fmt = local_aisgk_detect_image_transport($child);
            if ($fmt !== 'unknown') { return $fmt; }
        }
    }
    return 'unknown';
}

function local_aisgk_extract_inline_image(array $json): bool {
    return local_aisgk_detect_image_transport($json) !== 'unknown';
}




function local_aisgk_model_is_imagen(string $model): bool {
    $m = strtolower(preg_replace('#^models/#', '', trim($model)));
    return (bool)preg_match('/^imagen[-_]|(^|[-_])imagen[-_]/', $m);
}


function local_aisgk_shopaikey_normalize_image_model(string $model): string {
    $m = strtolower(preg_replace('#^models/#', '', trim($model)));
    $map = [
        'gemini-2.5-flash-image' => 'nano-banana',
        'gemini-2.5-flash-preview-image' => 'nano-banana',
        'gemini-3.1-flash-image-preview' => 'nano-banana-2',
        'gemini-3-flash-image-preview' => 'nano-banana-2',
        'gemini-3-pro-image-preview' => 'nano-banana-pro',
        'gemini-3-pro-image' => 'nano-banana-pro',
        'nano-banana-pro-preview' => 'nano-banana-pro',
    ];
    return $map[$m] ?? $m;
}

function local_aisgk_shopaikey_image_family(string $model): string {
    $m = local_aisgk_shopaikey_normalize_image_model($model);
    if (preg_match('/^nano-banana(?:-2|-pro)?$/', $m)) { return 'google_nano'; }
    if (preg_match('/^(?:dall-e-2|dall-e-3|gpt-image-[0-9](?:\.[0-9])?)$/', $m)) { return 'openai_image'; }
    return '';
}

function local_aisgk_guess_image_transport(string $provider, string $model): string {
    $m = strtolower(preg_replace('#^models/#', '', trim($model)));
    $provider = strtolower(trim($provider));
    if ($m === '') { return ''; }

    // Dedicated Imagen models are not Gemini generateContent models. In our Moodle
    // pipeline they should be treated as image-capable and URL-oriented when exposed
    // by a proxy/Vertex-style endpoint. Do not mark them unknown just because a
    // generateContent probe returns 404.
    if (local_aisgk_model_is_imagen($m)) { return 'url'; }

    // Gemini image / Nano Banana models normally return inlineData/base64 on the
    // Gemini-native endpoint. This is transport only: backend decodes and stores a
    // Moodle file URL, never stores base64 in question JSON.
    if (strpos($m, 'gemini') !== false && strpos($m, 'image') !== false) { return 'base64'; }
    if ($provider === 'shopaikey' && strpos($m, 'nano-banana') !== false) { return 'url'; }
    if (strpos($m, 'nano-banana') !== false) { return 'base64'; }

    // OpenAI-compatible image endpoints and many proxies can return URL or b64_json;
    // keep unknown unless runtime response confirms it.
    return '';
}


function local_aisgk_image_probe_recitation_or_safety(array $res): bool {
    if ((int)($res['http'] ?? 0) >= 400 || !is_array($res['json'] ?? null)) { return false; }
    $raw = strtolower((string)($res['raw'] ?? ''));
    if (strpos($raw, 'image_recitation') !== false || strpos($raw, 'recitation') !== false) { return true; }
    $json = $res['json'];
    if (!empty($json['candidates']) && is_array($json['candidates'])) {
        foreach ($json['candidates'] as $cand) {
            $reason = strtolower((string)($cand['finishReason'] ?? $cand['finish_reason'] ?? ''));
            if ($reason === 'image_recitation' || $reason === 'recitation' || strpos($reason, 'safety') !== false) { return true; }
        }
    }
    return false;
}

function local_aisgk_probe_error_kind(int $http, string $raw): string {
    $msg = strtolower($raw);
    if ($http === 401 || strpos($msg, 'api key not valid') !== false || strpos($msg, 'invalid api key') !== false || strpos($msg, 'unauthenticated') !== false) {
        return 'blocked';
    }
    if ($http === 403 || strpos($msg, 'permission denied') !== false || strpos($msg, 'forbidden') !== false || strpos($msg, 'not enabled') !== false) {
        return 'blocked';
    }
    if (strpos($msg, 'model_not_found') !== false || strpos($msg, 'model not found') !== false || strpos($msg, 'no available channel') !== false || strpos($msg, 'get_channel_failed') !== false) {
        return 'blocked';
    }
    if (strpos($msg, 'quota exceeded') !== false || strpos($msg, 'exceeded your current quota') !== false || strpos($msg, 'free_tier') !== false || strpos($msg, 'rpd') !== false || strpos($msg, 'daily') !== false) {
        return 'quota';
    }
    if ($http === 429 || strpos($msg, 'rate limit') !== false || strpos($msg, 'resource exhausted') !== false || strpos($msg, 'too many requests') !== false) {
        return 'cooldown';
    }
    if (strpos($msg, 'unsupported') !== false || strpos($msg, 'responsemodalities') !== false || strpos($msg, 'modality') !== false || strpos($msg, 'inline') !== false || strpos($msg, 'does not support') !== false) {
        return 'unsupported';
    }
    if ($http === 400 || $http === 404) {
        return 'unsupported';
    }
    if ($http >= 500) {
        return 'cooldown';
    }
    return 'error';
}


function local_aisgk_parse_sse_events(string $raw): array {
    $events = [];
    $current = '';
    $lines = preg_split('/\r\n|\r|\n/', $raw);
    foreach ($lines as $line) {
        $line = trim((string)$line);
        if ($line === '') { continue; }
        if (stripos($line, 'data:') !== 0) { continue; }
        $data = trim(substr($line, 5));
        if ($data === '' || $data === '[DONE]') { continue; }
        $json = json_decode($data, true);
        if (is_array($json)) {
            $events[] = $json;
        }
    }
    return $events;
}

function local_aisgk_openai_like_text_response_ok(array $json): bool {
    if (isset($json['choices']) && is_array($json['choices']) && count($json['choices']) > 0) {
        return true;
    }
    if (isset($json['candidates']) && is_array($json['candidates']) && count($json['candidates']) > 0) {
        return true;
    }
    foreach (['text', 'output_text', 'content'] as $k) {
        if (isset($json[$k]) && trim((string)$json[$k]) !== '') {
            return true;
        }
    }
    return false;
}

function local_aisgk_text_probe_succeeded(array $res): bool {
    $http = (int)($res['http'] ?? 0);
    if ($http >= 400) { return false; }

    // JSON thường: OpenAI-compatible/Gemini native. Chỉ cần provider trả choices/candidates
    // hợp lệ là xác nhận model có text capability; không bắt buộc content khác rỗng vì
    // một số model/proxy trả finish_reason=length hoặc reasoning token trong probe rất ngắn.
    if (is_array($res['json'] ?? null)) {
        if (local_aisgk_openai_like_text_response_ok($res['json'])) { return true; }
    }

    // ShopAIKey/OpenAI-compatible có thể trả Server-Sent Events khi model chạy dạng stream:
    // data: {"object":"chat.completion.chunk", "choices":[{"delta":{"content":"OK"}}]}
    // Đây là response hợp lệ, không phải lỗi parser. Hỗ trợ generic cho mọi model stream,
    // không hardcode riêng gpt-5-mini/gpt-5.1.
    $raw = (string)($res['raw'] ?? '');
    if (stripos(ltrim($raw), 'data:') === 0) {
        foreach (local_aisgk_parse_sse_events($raw) as $event) {
            if (local_aisgk_openai_like_text_response_ok($event)) { return true; }
        }
    }

    return false;
}

function local_aisgk_feature_capability_name(string $feature): string {
    return ($feature === 'img' || $feature === 'image') ? 'image_output' : 'text_output';
}

function local_aisgk_cached_probe_result(int $id, string $provider, string $model, string $feature): ?array {
    global $DB, $USER;
    if ($id <= 0 || !$DB->get_manager()->table_exists('local_aisgk_user_ai_keys')) { return null; }
    $record = $DB->get_record('local_aisgk_user_ai_keys', ['id' => $id, 'userid' => (int)$USER->id]);
    if (!$record) { return null; }
    $raw = trim((string)($record->models_cache_json ?? ''));
    if ($raw === '') { return null; }
    $cache = json_decode($raw, true);
    if (!is_array($cache) || empty($cache['capabilities']) || !is_array($cache['capabilities'])) { return null; }
    $model = preg_replace('#^models/#', '', trim($model));
    $entry = $cache['capabilities'][$model] ?? null;
    if (!is_array($entry)) { return null; }
    if (!empty($entry['provider']) && (string)$entry['provider'] !== $provider) { return null; }
    $cap = local_aisgk_feature_capability_name($feature);
    // Only skip runtime probe for confirmed positive capability. Negative/unknown may be rechecked later,
    // but transient quota/cooldown failures are never stored as negative capability.
    if (empty($entry[$cap])) { return null; }
    // For image models, old cache entries may confirm image_output but not yet know
    // whether the API/proxy returns URL or inline base64. Re-probe once to fill it.
    if (($feature === 'img' || $feature === 'image') && empty($entry['image_transport'])) { return null; }
    return [
        'model' => $model,
        'provider' => $provider,
        'feature' => $feature,
        'text_output' => !empty($entry['text_output']),
        'image_output' => !empty($entry['image_output']),
        'image_transport' => (string)($entry['image_transport'] ?? ''),
        'source' => 'db_cache',
        'checked_at' => (int)($entry['checked_at'] ?? time()),
        'ok' => true,
        'skipped' => true,
        'error_kind' => '',
        'message' => 'Capability đã xác nhận trong DB cache, bỏ qua runtime probe để tránh tốn quota.',
    ];
}

function local_aisgk_decode_status_map(string $raw): array {
    $raw = trim($raw);
    if ($raw === '') { return []; }
    $decoded = json_decode($raw, true);
    return is_array($decoded) ? $decoded : [];
}

function local_aisgk_normalize_status_map_for_models(string $modelsraw, array $map): string {
    $models = [];
    foreach (explode(',', $modelsraw) as $m) {
        $m = trim($m);
        if ($m !== '' && !in_array($m, $models, true)) { $models[] = $m; }
    }
    $out = [];
    foreach ($models as $m) {
        $state = $map[$m] ?? ['status' => 'active', 'cooldown_until' => 0, 'last_error' => '', 'last_used' => 0];
        if (!is_array($state)) { $state = ['status' => (string)$state]; }
        $status = (string)($state['status'] ?? 'active');
        if (!in_array($status, ['active', 'cooldown', 'blocked'], true)) { $status = 'active'; }
        $out[$m] = [
            'status' => $status,
            'cooldown_until' => max(0, (int)($state['cooldown_until'] ?? 0)),
            'last_error' => mb_substr((string)($state['last_error'] ?? ''), 0, 1000),
            'last_used' => max(0, (int)($state['last_used'] ?? 0)),
        ];
    }
    return $out ? json_encode($out, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES) : '';
}

function local_aisgk_update_probe_model_status(int $id, string $model, string $feature, string $status, string $error = '', int $cooldownuntil = 0): array {
    global $DB, $USER;
    if ($id <= 0 || $model === '' || !$DB->get_manager()->table_exists('local_aisgk_user_ai_keys')) { return []; }
    $record = $DB->get_record('local_aisgk_user_ai_keys', ['id' => $id, 'userid' => (int)$USER->id]);
    if (!$record) { return []; }
    if (!in_array($status, ['active', 'cooldown', 'blocked'], true)) { $status = 'active'; }
    $state = [
        'status' => $status,
        'cooldown_until' => max(0, $cooldownuntil),
        'last_error' => mb_substr($error, 0, 1000),
        'last_used' => time(),
    ];
    $features = ($feature === 'img' || $feature === 'image') ? ['img'] : ['homework'];
    foreach ($features as $f) {
        $field = ($f === 'img') ? 'model_img_status' : 'model_homework_status';
        $modelfield = ($f === 'img') ? 'model_img' : 'model_homework';
        $map = local_aisgk_decode_status_map((string)($record->$field ?? ''));
        $map[$model] = $state;
        $record->$field = local_aisgk_normalize_status_map_for_models((string)($record->$modelfield ?? ''), $map);
    }
    $record->last_error = ($status === 'active') ? '' : mb_substr($error, 0, 1000);
    $record->timemodified = time();
    $DB->update_record('local_aisgk_user_ai_keys', $record);
    return [
        'model_homework_status' => (string)($record->model_homework_status ?? ''),
        'model_img_status' => (string)($record->model_img_status ?? ''),
        'last_error' => (string)($record->last_error ?? ''),
    ];
}

function local_aisgk_probe_google_model(string $apikey, string $model, string $feature): array {
    $model = preg_replace('#^models/#', '', trim($model));
    if ($model === '') { throw new invalid_parameter_exception('Thiếu model'); }
    $result = [
        'model' => $model,
        'provider' => 'google',
        'feature' => $feature,
        'text_output' => false,
        'image_output' => false,
        'image_transport' => '',
        'source' => 'probe',
        'checked_at' => time(),
        'ok' => false,
        'message' => '',
    ];

    // Dedicated Imagen models must not be probed with Gemini generateContent.
    // If they are configured under provider=google, mark image capability/transport
    // from the model family and let real generation use the proper image endpoint/proxy.
    if (($feature === 'img' || $feature === 'image') && local_aisgk_model_is_imagen($model)) {
        $result['image_output'] = true;
        $result['image_transport'] = 'url';
        $result['text_output'] = false;
        $result['ok'] = true;
        $result['source'] = 'heuristic_imagen_endpoint';
        $result['message'] = 'Imagen là model chuyên sinh ảnh; không probe bằng generateContent. Đã xác nhận image_output, transport=url.';
        return $result;
    }

    // Metadata first: cheap and does not consume generation quota when available.
    $metaurl = 'https://generativelanguage.googleapis.com/v1beta/models/' . rawurlencode($model) . '?key=' . rawurlencode($apikey);
    $meta = local_aisgk_http_json($metaurl, ['Content-Type: application/json'], null, 20, 'GET');
    if ($meta['http'] < 400 && is_array($meta['json'])) {
        $methods = $meta['json']['supportedGenerationMethods'] ?? $meta['json']['supported_generation_methods'] ?? [];
        $features = $meta['json']['supportedModelFeatures'] ?? $meta['json']['supported_model_features'] ?? $meta['json']['supportedFeatures'] ?? [];
        $methodstr = is_array($methods) ? implode(',', $methods) : (string)$methods;
        $featurestr = is_array($features) ? implode(',', $features) : (string)$features;
        if (stripos($methodstr, 'generateContent') !== false || stripos($methodstr, 'chat') !== false) { $result['text_output'] = true; }
        if (stripos($featurestr, 'generateImage') !== false || stripos($featurestr, 'imageModality') !== false || stripos($featurestr, 'IMAGE') !== false) { $result['image_output'] = true; }
        // Naming heuristic augments metadata because Google/Proxy metadata is not always complete for image previews.
        if (ai_key_manager::has_image_capability($model)) { $result['image_output'] = true; }
        if (ai_key_manager::has_text_capability($model)) { $result['text_output'] = true; }
        $result['source'] = 'metadata+heuristic';
    }

    if ($feature === 'img' || $feature === 'image') {
        if (!ai_key_manager::has_image_capability($model) && empty($result['image_output'])) {
            $result['ok'] = false;
            $result['message'] = 'Metadata/heuristic không cho thấy model có image_output; bỏ qua probe ảnh để tránh tốn quota.';
            return $result;
        }
        $url = 'https://generativelanguage.googleapis.com/v1beta/models/' . rawurlencode($model) . ':generateContent?key=' . rawurlencode($apikey);
        $payload = [
            'contents' => [[
                'role' => 'user',
                'parts' => [['text' => 'Tạo một biểu tượng giáo dục trừu tượng rất đơn giản: một hình vuông nhỏ màu xanh trên nền trắng, không chữ, không logo. Chỉ xuất ảnh.']],
            ]],
            'generationConfig' => [
                'responseModalities' => ['IMAGE'],
                'imageConfig' => ['imageSize' => '64x64'],
            ],
        ];
        $res = local_aisgk_http_json($url, ['Content-Type: application/json'], $payload, 60, 'POST');
        $transport = is_array($res['json']) ? local_aisgk_detect_image_transport($res['json']) : 'unknown';
        if ($res['http'] < 400 && is_array($res['json']) && $transport !== 'unknown') {
            $result['image_output'] = true;
            $result['image_transport'] = $transport;
            if (ai_key_manager::has_text_capability($model)) { $result['text_output'] = true; }
            $result['ok'] = true;
            $result['source'] = 'runtime_probe';
            $result['message'] = 'Probe IMAGE thành công: model trả dữ liệu ảnh dạng ' . $transport . '.';
            return $result;
        }
        $raw = mb_substr((string)$res['raw'], 0, 600);
        $kind = local_aisgk_probe_error_kind((int)$res['http'], (string)$res['raw']);
        $recitation = local_aisgk_image_probe_recitation_or_safety($res);
        // Quota/cooldown/block/recitation are not proof that the model lacks image capability.
        if (in_array($kind, ['quota', 'cooldown', 'blocked'], true) || $recitation) {
            $result['image_output'] = !empty($result['image_output']) || ai_key_manager::has_image_capability($model);
            if (empty($result['image_transport'])) {
                $result['image_transport'] = local_aisgk_guess_image_transport('google', $model);
            }
            if ($recitation && $result['image_output']) {
                $result['ok'] = true;
                $result['source'] = 'heuristic+runtime_probe';
                $result['message'] = 'Model có image_output theo capability/heuristic, nhưng prompt probe bị IMAGE_RECITATION/safety nên không trả ảnh mẫu. Đã giữ capability; khi sinh thật sẽ dùng prompt bài học.';
                return $result;
            }
        } else if (local_aisgk_model_is_imagen($model)) {
            // 404 from generateContent for Imagen means wrong method/endpoint, not no image capability.
            $result['image_output'] = true;
            $result['image_transport'] = 'url';
        } else {
            $result['image_output'] = false;
        }
        $result['ok'] = false;
        $result['source'] = 'runtime_probe';
        $result['error_kind'] = $kind;
        $result['message'] = 'Probe IMAGE chưa lấy được ảnh thật. HTTP ' . $res['http'] . ': ' . $raw;
        return $result;
    }

    // Text feature probe.
    $url = 'https://generativelanguage.googleapis.com/v1beta/models/' . rawurlencode($model) . ':generateContent?key=' . rawurlencode($apikey);
    $payload = [
        'contents' => [[
            'role' => 'user',
            'parts' => [['text' => 'Trả lời đúng một chữ: OK']],
        ]],
        'generationConfig' => ['responseModalities' => ['TEXT']],
    ];
    $res = local_aisgk_http_json($url, ['Content-Type: application/json'], $payload, 45, 'POST');
    if (local_aisgk_text_probe_succeeded($res)) {
        $result['text_output'] = true;
        $result['ok'] = true;
        $result['source'] = 'runtime_probe';
        $result['message'] = 'Probe TEXT thành công. Provider đã chấp nhận model và trả response hợp lệ.';
        return $result;
    }
    $kind = local_aisgk_probe_error_kind((int)$res['http'], (string)$res['raw']);
    // Transient/key errors must update key+model status, but must not erase known text capability.
    if (in_array($kind, ['quota', 'cooldown', 'blocked'], true)) {
        $result['text_output'] = !empty($result['text_output']) || ai_key_manager::has_text_capability($model);
    } else {
        $result['text_output'] = false;
    }
    $result['ok'] = false;
    $result['source'] = 'runtime_probe';
    $result['error_kind'] = $kind;
    $result['message'] = 'Probe TEXT không thành công. HTTP ' . $res['http'] . ': ' . mb_substr((string)$res['raw'], 0, 600);
    return $result;
}

function local_aisgk_probe_shopaikey_model(string $apikey, string $model, string $feature): array {
    $model = preg_replace('#^models/#', '', trim($model));
    if ($model === '') { throw new invalid_parameter_exception('Thiếu model'); }
    $result = [
        'model' => $model,
        'provider' => 'shopaikey',
        'feature' => $feature,
        'text_output' => ai_key_manager::has_text_capability($model),
        'image_output' => ai_key_manager::has_image_capability($model),
        'image_transport' => '',
        'source' => 'heuristic',
        'checked_at' => time(),
        'ok' => false,
        'message' => '',
    ];
    if ($feature === 'img' || $feature === 'image') {
        if (!$result['image_output']) {
            $result['message'] = 'Tên/metadata không cho thấy model có image_output; bỏ qua probe ảnh để tránh tốn quota.';
            return $result;
        }
        $m = strtolower($model);
        $shopmodel = local_aisgk_shopaikey_normalize_image_model($model);
        $family = local_aisgk_shopaikey_image_family($shopmodel);
        if ($family === 'openai_image') {
            // Real one-shot image probe for OpenAI-compatible image models.
            // This deliberately creates a tiny/low-cost image so the Check button verifies
            // actual endpoint availability, response transport and provider routing.
            // IMPORTANT: the plugin sends exactly ONE HTTP request per model here; some
            // providers/proxies may log internal channel retries for that single request.
            $is_dalle = (strpos($m, 'dall') !== false);
            $payload = [
                'model' => $shopmodel,
                'prompt' => 'Minimal probe image: one small black square on a plain white background. No text. No logo.',
                'n' => 1,
                'size' => $is_dalle ? '1024x1024' : 'auto',
                'response_format' => 'b64_json',
            ];
            if ($is_dalle) {
                $payload['quality'] = 'standard';
            } else {
                $payload['quality'] = 'low';
                $payload['background'] = 'auto';
            }
            $res = local_aisgk_http_json('https://api.shopaikey.com/v1/images/generations', ['Content-Type: application/json', 'Authorization: Bearer ' . $apikey], $payload, 90, 'POST');
        } else if ($family === 'google_nano') {
            $payload = ['model' => $shopmodel, 'prompt' => 'Simple test image: a small black square on white background.', 'size' => '1:1', 'format' => 'jpeg', 'response_format' => 'url', 'image_urls' => []];
            if ($shopmodel !== 'nano-banana') { $payload['imageSize'] = '0.5K'; }
            $res = local_aisgk_http_json('https://api.shopaikey.com/images/google/generations', ['Content-Type: application/json', 'Authorization: Bearer ' . $apikey], $payload, 75, 'POST');
        } else {
            $result['image_output'] = false;
            $result['ok'] = false;
            $result['source'] = 'heuristic';
            $result['error_kind'] = 'unsupported';
            $result['message'] = 'Model Img không thuộc endpoint ShopAIKey được hỗ trợ. Dùng nano-banana, nano-banana-2, nano-banana-pro, dall-e-2, dall-e-3, gpt-image-1/1.5/2.';
            return $result;
        }
        if (false) {
            $url = 'https://api.shopaikey.com/v1beta/models/' . rawurlencode($model) . ':generateContent?key=' . rawurlencode($apikey);
            $payload = [
                'contents' => [[ 'role' => 'user', 'parts' => [['text' => 'Tạo một biểu tượng giáo dục trừu tượng rất đơn giản: một hình vuông nhỏ màu xanh trên nền trắng, không chữ, không logo. Chỉ xuất ảnh.']] ]],
                'generationConfig' => ['responseModalities' => ['IMAGE'], 'imageConfig' => ['imageSize' => '64x64']],
            ];
            $res = local_aisgk_http_json($url, ['Content-Type: application/json', 'Authorization: Bearer ' . $apikey], $payload, 75, 'POST');
        }
        $transport = is_array($res['json']) ? local_aisgk_detect_image_transport($res['json']) : 'unknown';
        if ($res['http'] < 400 && is_array($res['json']) && $transport !== 'unknown') {
            $result['image_output'] = true;
            $result['image_transport'] = $transport;
            $result['ok'] = true;
            $result['source'] = 'runtime_probe';
            $result['message'] = 'Probe IMAGE thành công: model trả ảnh dạng ' . $transport . '.';
            return $result;
        }
        $kind = local_aisgk_probe_error_kind((int)$res['http'], (string)$res['raw']);
        $recitation = local_aisgk_image_probe_recitation_or_safety($res);
        if (in_array($kind, ['quota', 'cooldown', 'blocked'], true) || $recitation) {
            $result['image_output'] = !empty($result['image_output']) || ai_key_manager::has_image_capability($model);
            if (empty($result['image_transport'])) {
                $result['image_transport'] = local_aisgk_guess_image_transport('shopaikey', $model);
            }
            if ($recitation && $result['image_output']) {
                $result['ok'] = true;
                $result['source'] = 'heuristic+runtime_probe';
                $result['message'] = 'Model có image_output theo capability/heuristic, nhưng prompt probe bị IMAGE_RECITATION/safety nên không trả ảnh mẫu. Đã giữ capability; khi sinh thật sẽ dùng prompt bài học.';
                return $result;
            }
        } else if (local_aisgk_model_is_imagen($model)) {
            $result['image_output'] = true;
            $result['image_transport'] = 'url';
        } else {
            $result['image_output'] = false;
        }
        $result['ok'] = false;
        $result['source'] = 'runtime_probe';
        $result['error_kind'] = $kind;
        $result['message'] = 'Probe IMAGE không thành công hoặc không có inlineData/url. HTTP ' . $res['http'] . ': ' . mb_substr((string)$res['raw'], 0, 600);
        return $result;
    }

    // Generic OpenAI-compatible text probe for ShopAIKey. If it fails, keep heuristic but report failure.
    $payload = ['model' => $model, 'messages' => [['role' => 'user', 'content' => 'Reply with exactly one word: OK']], 'temperature' => 0, 'max_tokens' => 16];
    $res = local_aisgk_http_json('https://api.shopaikey.com/v1/chat/completions', ['Content-Type: application/json', 'Authorization: Bearer ' . $apikey], $payload, 45, 'POST');
    if (local_aisgk_text_probe_succeeded($res)) {
        $result['text_output'] = true;
        $result['ok'] = true;
        $result['source'] = 'runtime_probe';
        $result['message'] = 'Probe TEXT thành công. Provider đã chấp nhận model và trả response hợp lệ.';
        return $result;
    }
    $kind = local_aisgk_probe_error_kind((int)$res['http'], (string)$res['raw']);
    if (in_array($kind, ['quota', 'cooldown', 'blocked'], true)) {
        $result['text_output'] = !empty($result['text_output']) || ai_key_manager::has_text_capability($model);
    } else {
        $result['text_output'] = false;
    }
    $result['ok'] = false;
    $result['error_kind'] = $kind;
    $result['message'] = 'Probe TEXT không thành công. HTTP ' . $res['http'] . ': ' . mb_substr((string)$res['raw'], 0, 600);
    return $result;
}

function local_aisgk_store_model_capability_cache(int $id, array $probe): bool {
    global $DB, $USER;
    if ($id <= 0 || !$DB->get_manager()->table_exists('local_aisgk_user_ai_keys')) { return false; }
    $record = $DB->get_record('local_aisgk_user_ai_keys', ['id' => $id, 'userid' => (int)$USER->id]);
    if (!$record) { return false; }
    $cache = [];
    $raw = trim((string)($record->models_cache_json ?? ''));
    if ($raw !== '') {
        $decoded = json_decode($raw, true);
        if (is_array($decoded)) { $cache = $decoded; }
    }
    if (!isset($cache['capabilities']) || !is_array($cache['capabilities'])) { $cache['capabilities'] = []; }
    $model = (string)($probe['model'] ?? '');
    if ($model === '') { return false; }
    $oldentry = isset($cache['capabilities'][$model]) && is_array($cache['capabilities'][$model]) ? $cache['capabilities'][$model] : [];
    $kind = (string)($probe['error_kind'] ?? '');
    $transient = in_array($kind, ['quota', 'cooldown', 'blocked'], true);
    $text = !empty($probe['text_output']) || !empty($oldentry['text_output']);
    $image = !empty($probe['image_output']) || !empty($oldentry['image_output']);
    $transport = (string)($probe['image_transport'] ?? ($oldentry['image_transport'] ?? ''));
    if (!in_array($transport, ['url', 'base64'], true)) { $transport = ''; }
    if (!$transient) {
        // For true unsupported/no-capability results, allow the checked feature to become false.
        $feature = (string)($probe['feature'] ?? '');
        if ($feature === 'img' || $feature === 'image') {
            $image = !empty($probe['image_output']);
        } else if ($feature !== '') {
            $text = !empty($probe['text_output']);
        }
    }
    $cache['capabilities'][$model] = [
        'provider' => (string)($probe['provider'] ?? ($oldentry['provider'] ?? '')),
        'text_output' => $text,
        'image_output' => $image,
        'image_transport' => $transport,
        'source' => (string)($probe['source'] ?? 'probe'),
        'checked_at' => (int)($probe['checked_at'] ?? time()),
        'last_feature' => (string)($probe['feature'] ?? ''),
        'last_ok' => !empty($probe['ok']),
        'last_error_kind' => $kind,
        'last_message' => mb_substr((string)($probe['message'] ?? ''), 0, 1000),
    ];
    $record->models_cache_json = json_encode($cache, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
    $record->models_cache_at = time();
    $record->timemodified = time();
    $DB->update_record('local_aisgk_user_ai_keys', $record);
    return true;
}



function local_aisgk_discover_models_for_key(string $provider, string $apikey): array {
    $apikey = trim($apikey);
    if ($apikey === '') { throw new invalid_parameter_exception('Thiếu API key'); }
    if ($provider === 'shopaikey') {
        $url = 'https://api.shopaikey.com/v1beta/models';
        $headers = ['Authorization: Bearer ' . $apikey, 'Content-Type: application/json'];
    } else {
        $url = 'https://generativelanguage.googleapis.com/v1beta/models?key=' . rawurlencode($apikey);
        $headers = ['Content-Type: application/json'];
    }
    $ch = curl_init($url);
    curl_setopt_array($ch, [CURLOPT_RETURNTRANSFER => true, CURLOPT_TIMEOUT => 25, CURLOPT_HTTPHEADER => $headers]);
    $response = curl_exec($ch);
    $http = (int)curl_getinfo($ch, CURLINFO_HTTP_CODE);
    $err = curl_error($ch);
    curl_close($ch);
    if ($response === false || $http >= 400) {
        throw new moodle_exception('errorprocessingbook', 'local_aisgk', '', 'Không lấy được danh sách model HTTP ' . $http . ': ' . ($response ?: $err));
    }
    $json = json_decode((string)$response, true);
    if (!is_array($json)) { throw new invalid_parameter_exception('Response model list không phải JSON'); }
    $models = isset($json['models']) && is_array($json['models']) ? $json['models'] : $json;
    $out = ['homework' => [], 'img' => [], 'raw' => []];
    foreach ($models as $m) {
        if (!is_array($m)) { continue; }
        $name = (string)($m['name'] ?? '');
        if (strpos($name, 'models/') === 0) { $name = substr($name, 7); }
        if ($name === '') { continue; }
        $display = (string)($m['displayName'] ?? $m['display_name'] ?? '');
        $desc = (string)($m['description'] ?? '');
        $methods = $m['supportedGenerationMethods'] ?? $m['supported_generation_methods'] ?? [];
        $methodstr = is_array($methods) ? implode(',', $methods) : (string)$methods;
        $hay = strtolower($name . ' ' . $display . ' ' . $desc . ' ' . $methodstr);
        $isimg = preg_match('/image|imagen|nano[- ]?banana|gpt-image/i', $hay);
        $isbadtext = preg_match('/image|imagen|nano[- ]?banana|gpt-image|tts|audio|veo|video|embedding|embed|lyria|aqa|robotics/i', $hay);
        $hasmethods = trim($methodstr) !== '';
        $cantext = (stripos($methodstr, 'generateContent') !== false || stripos($methodstr, 'chat') !== false || stripos($methodstr, 'responses') !== false || stripos($methodstr, 'completion') !== false);
        // Some ShopAIKey model-list responses only include name/displayName and do not expose methods.
        // In that case, treat non-image/non-audio/non-embedding models as text-capable so Scan/Homework combo works.
        if (!$hasmethods && !$isbadtext) { $cantext = true; }
        if ($isimg) {
            $out['img'][] = $name;
        } else if ($cantext && preg_match('/(^|[-_])(gemini|gpt|claude|deepseek|qwen|llama|mistral|grok|flash|pro|latest|preview)/i', $name . ' ' . $display)) {
            // Model Img may use newer multi-modal text models with image output/tool support.
            // Keep them after true image models so image-specific models are preferred.
            $out['img'][] = $name;
        }
        if ($cantext && !$isbadtext) { $out['homework'][] = $name; }
        $out['raw'][] = ['name' => $name, 'displayName' => $display, 'description' => mb_substr($desc, 0, 240), 'methods' => $methods];
    }
    if ($provider === 'shopaikey') {
        $shopimg = ['nano-banana','nano-banana-2','nano-banana-pro','gpt-image-1','gpt-image-1.5','gpt-image-2'];
        foreach ($shopimg as $m) {
            if (ai_key_manager::has_image_capability($m)) { $out['img'][] = $m; }
            $out['raw'][] = ['name' => $m, 'displayName' => $m, 'description' => 'ShopAIKey image endpoint model', 'methods' => ['image_generation']];
        }
    }
    foreach (['homework','img'] as $k) { $out[$k] = array_values(array_unique($out[$k])); }
    return $out;
}

function local_aisgk_recommended_models(string $provider, array $available): array {
    $scanpref = ['gemini-2.5-flash','gemini-3.1-flash-lite','gemini-3.1-flash-lite-preview','gemini-3.5-flash','gemini-flash-latest'];
    $hwpref = ['gemini-2.5-flash','gemini-3.5-flash','gemini-2.5-pro','gemini-flash-latest','gemini-3.1-flash-lite','gemini-3.1-flash-lite-preview'];
    // ShopAIKey exposes image generation through two documented endpoint families:
    // - /images/google/generations: nano-banana, nano-banana-2, nano-banana-pro
    // - /v1/images/generations: gpt-image-1, gpt-image-1.5, gpt-image-2 are ShopAIKey image aliases; dall-e-* can still appear when returned by /v1/models.
    // Keep upstream Gemini image names out of ShopAIKey recommendations; they are accepted
    // only as backward-compatible aliases in the router/probe layer.
    $imgpref = ($provider === 'shopaikey')
        ? ['nano-banana-2','nano-banana-pro','nano-banana','gpt-image-2','gpt-image-1.5','gpt-image-1']
        : ['gemini-3.1-flash-image-preview','gemini-2.5-flash-image','nano-banana-pro-preview','gemini-3-pro-image-preview','imagen-3.0-generate-002'];
    $pick = function(array $pref, array $got) { $out=[]; foreach ($pref as $m) if (in_array($m,$got,true)) $out[]=$m; foreach ($got as $m) if (!in_array($m,$out,true)) $out[]=$m; return implode(',', $out); };
    return ['homework'=>$pick($hwpref, $available['homework'] ?? []), 'img'=>$pick($imgpref, $available['img'] ?? [])];
}

try {
    global $DB, $USER;
    if ($op === 'preference') {
        $enabled = !empty($payload['enabled']) ? 1 : 0;
        set_user_preference('local_aisgk_use_my_api', $enabled, (int)$USER->id);
        echo json_encode(['ok' => true, 'enabled' => $enabled]);
        exit;
    }

    if ($op === 'restore') {
        aikey_repository::sync_usage_remaining_for_user_pay_keys((int)$USER->id);
        $rows = $DB->get_records('local_aisgk_user_ai_keys', ['userid' => (int)$USER->id], 'id ASC');
        echo json_encode(['ok' => true, 'rows' => local_aisgk_myapi_rows_json($rows), 'enabled' => (int)get_user_preferences('local_aisgk_use_my_api', 0)]);
        exit;
    }

    if ($op === 'save') {
        $rows = is_array($payload['rows'] ?? null) ? $payload['rows'] : [];
        $transaction = $DB->start_delegated_transaction();
        $existingids = $DB->get_fieldset_select('local_aisgk_user_ai_keys', 'id', 'userid = ?', [(int)$USER->id]);
        $seen = [];
        $now = time();
        foreach ($rows as $row) {
            $record = aikey_repository::normalize_row($row, $now, (int)$USER->id);
            $record->userid = (int)$USER->id;
            if (!empty($row['id']) && is_numeric($row['id']) && $DB->record_exists('local_aisgk_user_ai_keys', ['id' => (int)$row['id'], 'userid' => (int)$USER->id])) {
                $record->id = (int)$row['id'];
                $current = $DB->get_record('local_aisgk_user_ai_keys', ['id' => $record->id], '*', MUST_EXIST);
                $record->timecreated = (int)$current->timecreated;
                foreach (['last_model','last_tokens','last_tokens_at','usage_remaining','usage_last_sync','daily_used','daily_reset_at','in_use_by','in_use_until','models_cache_json','models_cache_at'] as $f) {
                    if (isset($current->$f)) { $record->$f = $current->$f; }
                }
                $DB->update_record('local_aisgk_user_ai_keys', $record);
                $seen[] = $record->id;
            } else if (trim((string)$record->api_key) !== '' || trim((string)$record->gmail_account) !== '') {
                $seen[] = (int)$DB->insert_record('local_aisgk_user_ai_keys', $record);
            }
        }
        $delete = array_diff(array_map('intval', $existingids), array_map('intval', $seen));
        if ($delete) {
            [$insql, $params] = $DB->get_in_or_equal($delete, SQL_PARAMS_QM);
            $DB->delete_records_select('local_aisgk_user_ai_keys', 'userid = ? AND id ' . $insql, array_merge([(int)$USER->id], $params));
        }
        $transaction->allow_commit();
        aikey_repository::sync_usage_remaining_for_user_pay_keys((int)$USER->id);
        $out = $DB->get_records('local_aisgk_user_ai_keys', ['userid' => (int)$USER->id], 'id ASC');
        echo json_encode(['ok' => true, 'rows' => local_aisgk_myapi_rows_json($out)]);
        exit;
    }

    if ($op === 'probemodel' || $op === 'probemodels') {
        $provider = trim((string)($payload['provider'] ?? 'google'));
        if (!in_array($provider, ['google','shopaikey'], true)) { $provider = 'google'; }
        $apikey = trim((string)($payload['api_key'] ?? ''));
        if ($apikey === '') { throw new invalid_parameter_exception('Thiếu API key'); }
        $feature = trim((string)($payload['feature'] ?? 'homework'));
        if (!in_array($feature, ['homework','img','image'], true)) { $feature = 'homework'; }
        $id = (int)($payload['id'] ?? 0);
        $forceprobe = !empty($payload['force']) || !empty($payload['refresh']);

        $models = [];
        if ($op === 'probemodels') {
            $rawmodels = $payload['models'] ?? [];
            if (!is_array($rawmodels)) { $rawmodels = explode(',', (string)$rawmodels); }
            foreach ($rawmodels as $m) {
                $m = trim((string)$m);
                if ($m !== '' && !in_array($m, $models, true)) { $models[] = $m; }
            }
        } else {
            $model = trim((string)($payload['model'] ?? ''));
            if ($model !== '') { $models[] = $model; }
        }
        if (!$models) { throw new invalid_parameter_exception('Thiếu model'); }

        $results = [];
        $laststatusupdates = [];
        foreach ($models as $model) {
            $saved = false;
            $statusupdates = [];
            try {
                // Bấm nút check là yêu cầu kiểm tra thật để cập nhật quota/cooldown/block hiện tại.
                // Cache DB chỉ dùng khi mở popup/đồng bộ UI, hoặc khi caller không bật force.
                $cached = $forceprobe ? null : local_aisgk_cached_probe_result($id, $provider, $model, $feature);
                if ($cached !== null) {
                    $probe = $cached;
                    $saved = true;
                } else {
                    $probe = ($provider === 'shopaikey')
                        ? local_aisgk_probe_shopaikey_model($apikey, $model, $feature)
                        : local_aisgk_probe_google_model($apikey, $model, $feature);
                    $saved = local_aisgk_store_model_capability_cache($id, $probe);
                    $kind = (string)($probe['error_kind'] ?? '');
                    if (!empty($probe['ok'])) {
                        $statusupdates = local_aisgk_update_probe_model_status($id, $model, $feature, 'active', '', 0);
                    } else if ($kind === 'quota') {
                        // 429 chỉ áp cho key+model hiện tại. Không được dừng cả danh sách.
                        $statusupdates = local_aisgk_update_probe_model_status($id, $model, $feature, 'cooldown', (string)($probe['message'] ?? ''), strtotime('tomorrow 00:05') ?: (time() + DAYSECS));
                    } else if ($kind === 'cooldown') {
                        $statusupdates = local_aisgk_update_probe_model_status($id, $model, $feature, 'cooldown', (string)($probe['message'] ?? ''), time() + 600);
                    } else if ($kind === 'blocked') {
                        $statusupdates = local_aisgk_update_probe_model_status($id, $model, $feature, 'blocked', (string)($probe['message'] ?? ''), 0);
                    }
                }
            } catch (Throwable $e) {
                // Lỗi một model không được làm mất cơ hội check các model còn lại.
                $probe = [
                    'model' => $model,
                    'provider' => $provider,
                    'feature' => $feature,
                    'text_output' => false,
                    'image_output' => false,
                    'image_transport' => '',
                    'source' => 'runtime_probe',
                    'checked_at' => time(),
                    'ok' => false,
                    'error_kind' => 'error',
                    'message' => 'Probe lỗi: ' . $e->getMessage(),
                ];
                $saved = false;
                $statusupdates = [];
            }
            if ($statusupdates) { $laststatusupdates = $statusupdates; }
            $results[] = ['ok' => true, 'probe' => $probe, 'saved' => $saved, 'status_updates' => $statusupdates];
        }

        if ($op === 'probemodel') {
            $one = $results[0];
            echo json_encode(['ok' => true, 'probe' => $one['probe'], 'saved' => $one['saved'], 'status_updates' => $one['status_updates']], JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
        } else {
            echo json_encode(['ok' => true, 'results' => $results, 'status_updates' => $laststatusupdates], JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
        }
        exit;
    }


    if ($op === 'models') {
        $provider = trim((string)($payload['provider'] ?? 'google'));
        if (!in_array($provider, ['google','shopaikey'], true)) { $provider = 'google'; }
        $apikey = trim((string)($payload['api_key'] ?? ''));
        $available = local_aisgk_discover_models_for_key($provider, $apikey);
        echo json_encode(['ok' => true, 'models' => $available, 'recommended' => local_aisgk_recommended_models($provider, $available)], JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
        exit;
    }

    throw new invalid_parameter_exception('Invalid op');
} catch (Throwable $e) {
    http_response_code(500);
    echo json_encode(['ok' => false, 'error' => $e->getMessage()]);
}
