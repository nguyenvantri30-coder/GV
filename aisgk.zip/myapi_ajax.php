<?php
require('../../config.php');

use local_aisgk\aikey_repository;

define('AJAX_SCRIPT', true);
$courseid = required_param('id', PARAM_INT);
$op = required_param('op', PARAM_ALPHAEXT);
require_sesskey();
$course = get_course($courseid);
require_login($course);
$context = context_course::instance($courseid);
require_capability('local/aisgk:createhomework', $context);
header('Content-Type: application/json; charset=utf-8');
$payload = json_decode(file_get_contents('php://input'), true) ?: [];

function local_aisgk_myapi_row_json($row): array {
    $lastused = (int)($row->last_used ?? 0);
    $lasttokensat = (int)($row->last_tokens_at ?? 0);
    return [
        'id' => (int)($row->id ?? 0),
        'gmail_account' => (string)($row->gmail_account ?? ''),
        'api_key' => (string)($row->api_key ?? ''),
        'category_key' => (string)($row->category_key ?? 'free'),
        'provider' => (string)($row->provider ?? 'google'),
        'model_scan' => (string)($row->model_scan ?? 'gemini-flash-latest'),
        'model_homework' => (string)($row->model_homework ?? 'gemini-flash-latest'),
        'status' => (string)($row->status ?? 'active'),
        'last_used' => $lastused > 0 ? userdate($lastused, '%Y-%m-%dT%H:%M') : '',
        'limit_rpm' => (int)($row->limit_rpm ?? 8),
        'limit_rpd' => (int)($row->limit_rpd ?? 200),
        'limit_tpm' => (int)($row->limit_tpm ?? 200000),
        'used_rpm' => (int)($row->used_rpm ?? 0),
        'used_rpd' => (int)($row->used_rpd ?? 0),
        'used_tpm' => (int)($row->used_tpm ?? 0),
        'last_model' => (string)($row->last_model ?? ''),
        'last_tokens' => (int)($row->last_tokens ?? 0),
        'last_tokens_at' => $lasttokensat > 0 ? userdate($lasttokensat, '%Y-%m-%d %H:%M') : '',
        'remain_calls_est' => (int)($row->remain_calls_est ?? 0),
        'last_error' => (string)($row->last_error ?? ''),
        'usage_remaining' => (string)($row->usage_remaining ?? '0'),
    ];
}
function local_aisgk_myapi_rows_json(array $rows): array { return array_map('local_aisgk_myapi_row_json', array_values($rows)); }

try {
    global $DB, $USER;
    if ($op === 'preference') {
        $enabled = !empty($payload['enabled']) ? 1 : 0;
        set_user_preference('local_aisgk_use_my_api', $enabled, (int)$USER->id);
        echo json_encode(['ok' => true, 'enabled' => $enabled]);
        exit;
    }

    if ($op === 'restore') {
        aikey_repository::sync_usage_remaining_for_user_pay_keys((int)$USER->id);
        $rows = $DB->get_records('local_aisgk_user_ai_keys', ['userid' => (int)$USER->id], 'id ASC');
        echo json_encode(['ok' => true, 'rows' => local_aisgk_myapi_rows_json($rows), 'enabled' => (int)get_user_preferences('local_aisgk_use_my_api', 0)]);
        exit;
    }

    if ($op === 'save') {
        $rows = is_array($payload['rows'] ?? null) ? $payload['rows'] : [];
        $transaction = $DB->start_delegated_transaction();
        $existingids = $DB->get_fieldset_select('local_aisgk_user_ai_keys', 'id', 'userid = ?', [(int)$USER->id]);
        $seen = [];
        $now = time();
        foreach ($rows as $row) {
            $record = aikey_repository::normalize_row($row, $now, (int)$USER->id);
            $record->userid = (int)$USER->id;
            if (!empty($row['id']) && is_numeric($row['id']) && $DB->record_exists('local_aisgk_user_ai_keys', ['id' => (int)$row['id'], 'userid' => (int)$USER->id])) {
                $record->id = (int)$row['id'];
                $current = $DB->get_record('local_aisgk_user_ai_keys', ['id' => $record->id], '*', MUST_EXIST);
                $record->timecreated = (int)$current->timecreated;
                foreach (['used_rpm','used_rpd','used_tpm','minute_bucket','day_bucket','last_model','last_tokens','last_tokens_at','remain_calls_est','usage_remaining','usage_last_sync'] as $f) {
                    if (isset($current->$f)) { $record->$f = $current->$f; }
                }
                $DB->update_record('local_aisgk_user_ai_keys', $record);
                $seen[] = $record->id;
            } else if (trim((string)$record->api_key) !== '' || trim((string)$record->gmail_account) !== '') {
                $seen[] = (int)$DB->insert_record('local_aisgk_user_ai_keys', $record);
            }
        }
        $delete = array_diff(array_map('intval', $existingids), array_map('intval', $seen));
        if ($delete) {
            [$insql, $params] = $DB->get_in_or_equal($delete, SQL_PARAMS_QM);
            $DB->delete_records_select('local_aisgk_user_ai_keys', 'userid = ? AND id ' . $insql, array_merge([(int)$USER->id], $params));
        }
        $transaction->allow_commit();
        $out = $DB->get_records('local_aisgk_user_ai_keys', ['userid' => (int)$USER->id], 'id ASC');
        echo json_encode(['ok' => true, 'rows' => local_aisgk_myapi_rows_json($out)]);
        exit;
    }
    throw new invalid_parameter_exception('Invalid op');
} catch (Throwable $e) {
    http_response_code(500);
    echo json_encode(['ok' => false, 'error' => $e->getMessage()]);
}
