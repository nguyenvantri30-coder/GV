<?php
require_once(__DIR__ . '/../../config.php');

$courseid = required_param('id', PARAM_INT);
$columns = optional_param('columns', 1, PARAM_INT);
$splitpercent = optional_param('splitpercent', 50, PARAM_INT);
$psm = optional_param('psm', 3, PARAM_INT);

require_login($courseid);

$context = context_course::instance($courseid);
require_capability('local/aisgk:createtopic', $context);

$PAGE->set_url(new moodle_url('/local/aisgk/test_preview.php', ['id' => $courseid]));
$PAGE->set_context($context);
$PAGE->set_pagelayout('embedded');

global $DB;
$book = $DB->get_record('local_aisgk_books', ['courseid' => $courseid], '*', IGNORE_MISSING);

echo $OUTPUT->header();
echo html_writer::tag('h3', 'Preview MỤC LỤC');

//echo html_writer::start_tag('form', ['method' => 'get']);
echo html_writer::start_tag('form', [
    'method' => 'get',
    'action' => new moodle_url('/local/aisgk/test_preview.php'),
]);
echo html_writer::empty_tag('input', ['type' => 'hidden', 'name' => 'id', 'value' => $courseid]);

echo html_writer::label('Columns', 'id_columns');
echo ' ';
echo html_writer::select([1 => '1 column', 2 => '2 column'], 'columns', $columns, false, ['id' => 'id_columns']);

echo ' ';
echo html_writer::label('Split %', 'id_splitpercent');
echo ' ';
echo html_writer::empty_tag('input', [
    'type' => 'number',
    'name' => 'splitpercent',
    'id' => 'id_splitpercent',
    'value' => $splitpercent,
    'min' => 20,
    'max' => 80,
    'style' => 'width:90px'
]);

echo ' ';
echo html_writer::label('PSM', 'id_psm');
echo ' ';
echo html_writer::empty_tag('input', [
    'type' => 'number',
    'name' => 'psm',
    'id' => 'id_psm',
    'value' => $psm,
    'min' => 3,
    'max' => 13,
    'style' => 'width:90px'
]);

echo ' ';

echo html_writer::tag('button', 'Xem preview', [
    'type' => 'submit',
    'id' => 'btn-preview',
    'class' => 'btn btn-primary'
]);

echo html_writer::end_tag('form');

if (!$book) {
    echo html_writer::div('Khóa học này chưa có SGK.', 'alert alert-warning');
    echo $OUTPUT->footer();
    exit;
}

try {
    if ($columns === 2) {
        $result = \local_aisgk\local\sgk_processor::preview_topic_items_2col(
            (int)$book->id,
            $columns,
            $splitpercent,
            $psm
        );
    } else {
        $result = \local_aisgk\local\sgk_processor::preview_topic_items(
            (int)$book->id,
            $columns,
            $splitpercent,
            $psm
        );
    }

    if (!empty($result['toc_lines'])) {
        echo html_writer::tag('h4', 'Núi 1: vùng MỤC LỤC');
        echo html_writer::tag('pre', s(implode("
", $result['toc_lines'])));
    }

    if (!empty($result['matched_lines'])) {
        echo html_writer::tag('h4', 'Núi 2: dòng hợp lệ');
        echo html_writer::tag('pre', s(implode("
", $result['matched_lines'])));
    }

    if (!empty($result['items'])) {
        echo html_writer::start_tag('table', ['class' => 'generaltable']);
        echo html_writer::start_tag('thead');
        echo html_writer::tag('tr',
            html_writer::tag('th', 'Số bài') .
            html_writer::tag('th', 'Tên bài') .
            html_writer::tag('th', 'Trang') .
            html_writer::tag('th', 'Raw')
        );
        echo html_writer::end_tag('thead');

        echo html_writer::start_tag('tbody');
        foreach ($result['items'] as $item) {
            echo html_writer::tag('tr',
                html_writer::tag('td', s((string)($item['sobai'] ?? ''))) .
                html_writer::tag('td', s($item['tenbai'] ?? '')) .
                html_writer::tag('td', s((string)($item['trang'] ?? ''))) .
                html_writer::tag('td', s($item['raw'] ?? ''))
            );
        }
        echo html_writer::end_tag('tbody');
        echo html_writer::end_tag('table');
    } else {
        echo html_writer::div('Không parse được dòng nào.', 'alert alert-warning');
    }
} catch (Throwable $e) {
    echo html_writer::div('Lỗi: ' . s($e->getMessage()), 'alert alert-danger');
}
$PAGE->requires->js_init_code("
    document.addEventListener('DOMContentLoaded', function() {
        const btn = document.getElementById('btn-preview');
        if (!btn) return;

        btn.addEventListener('click', function() {
            const start = performance.now();

            const interval = setInterval(function() {
                const elapsed = ((performance.now() - start) / 1000).toFixed(1);
                btn.textContent = '⏳ Đang chạy (' + elapsed + 's)';
            }, 100);

            sessionStorage.setItem('aisgk_preview_start', String(start));
        });

        const start = sessionStorage.getItem('aisgk_preview_start');
        if (start) {
            const total = ((performance.now() - Number(start)) / 1000).toFixed(2);
            btn.textContent = '✅ Xem preview (' + total + 's)';
            sessionStorage.removeItem('aisgk_preview_start');
        }
    });
");
echo $OUTPUT->footer();
