<?php
require_once(__DIR__ . '/../../config.php');
require_once($CFG->libdir . '/adminlib.php');

use local_aisgk\local\service\school_year_backup_service;

require_login();
admin_externalpage_setup('local_aisgk_year_inherit');
require_capability('moodle/site:config', context_system::instance());

$PAGE->set_url(new moodle_url('/local/aisgk/year_inherit.php'));
$PAGE->set_title(get_string('inheritdata', 'local_aisgk'));
$PAGE->set_heading(get_string('alsm', 'local_aisgk'));

$pending = $DB->get_records_select('local_aisgk_school_year', "status IN ('new_pending_inherit','new_pending_wipe')", null, 'timecreated DESC', '*', 0, 10);
$groups = school_year_backup_service::get_inheritance_groups();

echo $OUTPUT->header();
echo html_writer::tag('h2', get_string('inheritdata', 'local_aisgk'));
echo html_writer::tag('div', get_string('inheritdataintro', 'local_aisgk'), ['class' => 'alert alert-info']);

if (!$pending) {
    echo $OUTPUT->notification(get_string('noinheritpending', 'local_aisgk'), 'notifymessage');
} else {
    foreach ($pending as $year) {
        $cfg = json_decode((string)$year->configjson, true) ?: [];
        echo html_writer::start_tag('div', ['class' => 'card mb-3']);
        echo html_writer::start_tag('div', ['class' => 'card-body']);
        echo html_writer::tag('h3', s($year->name));
        if (($cfg['transition_mode'] ?? '') === 'wipe') {
            echo html_writer::tag('div', get_string('inheritdisabledwipe', 'local_aisgk'), ['class' => 'alert alert-danger']);
        } else {
            echo html_writer::tag('p', get_string('inheritselectdesc', 'local_aisgk'));
            echo html_writer::start_tag('div', ['class' => 'row']);
            foreach ($groups as $key => $label) {
                echo html_writer::start_tag('div', ['class' => 'col-md-6']);
                echo html_writer::tag('label', html_writer::empty_tag('input', ['type' => 'checkbox', 'checked' => 'checked', 'disabled' => 'disabled']) . ' ' . s($label));
                echo html_writer::end_tag('div');
            }
            echo html_writer::end_tag('div');
            echo html_writer::tag('div', get_string('inheritnotimplemented', 'local_aisgk'), ['class' => 'alert alert-warning mt-3']);
        }
        echo html_writer::end_tag('div');
        echo html_writer::end_tag('div');
    }
}

echo $OUTPUT->footer();
