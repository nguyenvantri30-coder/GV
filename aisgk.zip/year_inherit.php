<?php
require_once(__DIR__ . '/../../config.php');

$localaisgkmodal = optional_param('modal', 0, PARAM_BOOL);
function local_aisgk_modal_page_open($title = '') {
    global $OUTPUT, $localaisgkmodal;
    if ($localaisgkmodal) {
        echo '<!doctype html><html><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>' . s($title) . '</title><style>html,body{margin:0!important;padding:0!important;background:#fff!important;overflow:hidden;font-family:Arial,Helvetica,sans-serif}.modal-clean-wrap{padding:10px;box-sizing:border-box;width:100%;height:100vh;overflow:auto}.btn,.local-aisgk-modal .btn,button,input[type=submit]{display:inline-flex!important;align-items:center!important;justify-content:center!important;height:34px!important;line-height:1!important;padding:0 12px!important;box-sizing:border-box!important;vertical-align:middle!important}table{border-collapse:collapse}.muted{color:#64748b}.table-responsive{overflow:auto}</style></head><body><div class="modal-clean-wrap">';
    } else {
        local_aisgk_modal_page_open($PAGE->title ?? '');
    }
}
function local_aisgk_modal_page_close() {
    global $OUTPUT, $localaisgkmodal;
    if ($localaisgkmodal) {
        echo '</div></body></html>';
    } else {
        local_aisgk_modal_page_close();
    }
}


$context = context_system::instance();
$PAGE->set_context($context);
require_login();
require_capability('moodle/site:config', $context);

require_once($CFG->libdir . '/adminlib.php');

use local_aisgk\local\service\school_year_backup_service;

$PAGE->set_url(new moodle_url('/local/aisgk/year_inherit.php'));
$PAGE->set_title(get_string('inheritdata', 'local_aisgk'));
$PAGE->set_heading(get_string('inheritdata', 'local_aisgk'));
$PAGE->set_pagelayout('standard');

$pending = $DB->get_records_select('local_aisgk_school_year', "status IN ('new_pending_inherit','new_pending_wipe')", null, 'timecreated DESC', '*', 0, 10);
$groups = school_year_backup_service::get_inheritance_groups();

local_aisgk_modal_page_open($PAGE->title ?? '');
echo html_writer::tag('h2', get_string('inheritdata', 'local_aisgk'));
echo html_writer::tag('div', get_string('inheritdataintro', 'local_aisgk'), ['class' => 'alert alert-info']);

if (!$pending) {
    echo $OUTPUT->notification(get_string('noinheritpending', 'local_aisgk'), 'notifymessage');
} else {
    foreach ($pending as $year) {
        $cfg = json_decode((string)$year->configjson, true) ?: [];
        echo html_writer::start_tag('div', ['class' => 'card mb-3']);
        echo html_writer::start_tag('div', ['class' => 'card-body']);
        echo html_writer::tag('h3', s($year->name));
        if (($cfg['transition_mode'] ?? '') === 'wipe') {
            echo html_writer::tag('div', get_string('inheritdisabledwipe', 'local_aisgk'), ['class' => 'alert alert-danger']);
        } else {
            echo html_writer::tag('p', get_string('inheritselectdesc', 'local_aisgk'));
            echo html_writer::start_tag('div', ['class' => 'row']);
            foreach ($groups as $key => $label) {
                echo html_writer::start_tag('div', ['class' => 'col-md-6']);
                echo html_writer::tag('label', html_writer::empty_tag('input', ['type' => 'checkbox', 'checked' => 'checked', 'disabled' => 'disabled']) . ' ' . s($label));
                echo html_writer::end_tag('div');
            }
            echo html_writer::end_tag('div');
            echo html_writer::tag('div', get_string('inheritnotimplemented', 'local_aisgk'), ['class' => 'alert alert-warning mt-3']);
        }
        echo html_writer::end_tag('div');
        echo html_writer::end_tag('div');
    }
}

echo html_writer::tag('p', html_writer::link(new moodle_url('/local/aisgk/index.php'), get_string('back'), ['class' => 'btn btn-secondary mt-3']));
local_aisgk_modal_page_close();
