<?php

define('NO_DEBUG_DISPLAY', true);
require('../../config.php');

$courseid = required_param('courseid', PARAM_INT);
$homeworkid = required_param('homeworkid', PARAM_INT);
$filename = required_param('file', PARAM_FILE);

require_login($courseid);
$context = context_course::instance($courseid);
require_capability('local/aisgk:createhomework', $context);

$base = !empty($CFG->localcachedir) ? $CFG->localcachedir : ($CFG->dataroot . '/localcache');
$dir = $base . '/local_aisgk/previewimg/u' . (int)$USER->id . '/h' . max(0, $homeworkid);
$path = $dir . '/' . basename($filename);

if (!is_file($path) || !preg_match('/\.png$/i', $path)) {
    http_response_code(404);
    exit('filenotfound');
}

// This is an <img src="..."> endpoint, so do not require sesskey and do not force download.
send_file($path, basename($filename), 0, 0, false, false, 'image/png');
