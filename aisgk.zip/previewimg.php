<?php
require('../../config.php');

require_login();
require_sesskey();

$courseid = required_param('courseid', PARAM_INT);
$homeworkid = required_param('homeworkid', PARAM_INT);
$filename = required_param('file', PARAM_FILE);

$context = context_course::instance($courseid);
require_capability('local/aisgk:createhomework', $context);

$base = !empty($CFG->localcachedir) ? $CFG->localcachedir : ($CFG->dataroot . '/localcache');
$dir = $base . '/local_aisgk/previewimg/u' . (int)$USER->id . '/h' . max(0, $homeworkid);
$path = $dir . '/' . basename($filename);

if (!is_file($path) || !preg_match('/\.png$/i', $path)) {
    throw new moodle_exception('filenotfound');
}

send_file($path, basename($filename), 0, 0, true, true, 'image/png');
