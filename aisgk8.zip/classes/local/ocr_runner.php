<?php
namespace local_aisgk\local;

defined('MOODLE_INTERNAL') || die();

class ocr_runner {
    protected const GS = '/usr/bin/gs';
    protected const CONVERT = '/usr/bin/convert';
    protected const TESSERACT = '/usr/bin/tesseract';
    protected const IDENTIFY = '/usr/bin/identify';

    public static function get_parallelism(): int {
        $cpu = 1;
        if (function_exists('shell_exec')) {
            $out = @shell_exec('nproc 2>/dev/null');
            if (is_string($out) && trim($out) !== '' && ctype_digit(trim($out))) {
                $cpu = max(1, (int)trim($out));
            }
        }
        return max(1, min(4, $cpu));
    }

    public static function render_pdf_pages(string $pdfpath, string $dir, int $bookid, int $frompage, int $topage, int $dpi = 200): array {
        $jobs = [];
        $index = 1;
        for ($page = $frompage; $page <= $topage; $page++, $index++) {
            $outfile = $dir . '/' . $bookid . '_' . $index . '.png';
            $command = sprintf(
                'TMPDIR=%1$s TEMP=%1$s TMP=%1$s %2$s -dSAFER -dBATCH -dNOPAUSE -sDEVICE=pnggray -r%3$d -dFirstPage=%4$d -dLastPage=%4$d -sOutputFile=%5$s %6$s',
                escapeshellarg($dir),
                escapeshellarg(self::GS),
                $dpi,
                $page,
                escapeshellarg($outfile),
                escapeshellarg($pdfpath)
            );
            $jobs[] = ['command' => $command, 'expect' => $outfile];
        }
        self::run_job_batch($jobs, $dir, self::get_parallelism());
        return array_values(array_map(static fn($job) => $job['expect'], $jobs));
    }

    public static function preprocess_image(string $imagepath): string {
        return self::convert_variant(
            $imagepath,
            'prep',
            '-colorspace Gray -auto-level -deskew 40% -sharpen 0x0.7 -threshold 58%'
        );
    }

    public static function preprocess_title_image_2col(string $imagepath, string $suffix = 'title'): string {
        return self::convert_variant(
            $imagepath,
            $suffix,
            '-colorspace Gray -auto-level -deskew 35% -sharpen 0x0.8 -normalize -threshold 62%'
        );
    }

    public static function preprocess_page_image_2col(string $imagepath, string $suffix = 'page'): string {
        return self::convert_variant(
            $imagepath,
            $suffix,
            '-colorspace Gray -auto-level -deskew 35% -sharpen 0x1.0 -threshold 70%'
        );
    }

    public static function preprocess_page_image_strong_2col(string $imagepath, string $suffix = 'pagestrong'): string {
        return self::convert_variant(
            $imagepath,
            $suffix,
            '-colorspace Gray -auto-level -deskew 35% -morphology Close Rectangle:1x2 -threshold 78%'
        );
    }

    public static function preprocess_page_image_invert_2col(string $imagepath, string $suffix = 'pageinv'): string {
        return self::convert_variant(
            $imagepath,
            $suffix,
            '-colorspace Gray -negate -auto-level -threshold 58%'
        );
    }

    protected static function convert_variant(string $imagepath, string $suffix, string $ops): string {
        $outpath = preg_replace('/\.png$/i', '_' . $suffix . '.png', $imagepath);
        $command = sprintf('%s %s %s %s', escapeshellarg(self::CONVERT), escapeshellarg($imagepath), $ops, escapeshellarg($outpath));
        $result = command_runner::run($command);
        if ($result['code'] !== 0 || !is_file($outpath)) {
            throw new \moodle_exception('errorprocessingbook', 'local_aisgk', '', null, $result['output']);
        }
        return $outpath;
    }

    public static function get_image_size(string $imagepath): array {
        $command = sprintf('%s -format %s %s', escapeshellarg(self::IDENTIFY), escapeshellarg('%w %h'), escapeshellarg($imagepath));
        $result = command_runner::run($command);
        if ($result['code'] !== 0 || $result['stdout'] === '') {
            throw new \moodle_exception('errorprocessingbook', 'local_aisgk', '', null, $result['output']);
        }
        [$width, $height] = array_map('intval', preg_split('/\s+/', trim($result['stdout'])));
        if ($width < 1 || $height < 1) {
            throw new \moodle_exception('errorprocessingbook', 'local_aisgk', '', null, 'Không đọc được kích thước ảnh OCR.');
        }
        return [$width, $height];
    }

    public static function crop_columns(string $imagepath, int $splitpercent): array {
        [$width, $height] = self::get_image_size($imagepath);
        $splitx = (int)floor($width * max(20, min(80, $splitpercent)) / 100);
        $left = preg_replace('/\.png$/i', '_l.png', $imagepath);
        $right = preg_replace('/\.png$/i', '_r.png', $imagepath);

        $jobs = [
            [
                'command' => sprintf('%s %s -crop %s +repage %s', escapeshellarg(self::CONVERT), escapeshellarg($imagepath), escapeshellarg($splitx . 'x' . $height . '+0+0'), escapeshellarg($left)),
                'expect' => $left,
            ],
            [
                'command' => sprintf('%s %s -crop %s +repage %s', escapeshellarg(self::CONVERT), escapeshellarg($imagepath), escapeshellarg(($width - $splitx) . 'x' . $height . '+' . $splitx . '+0'), escapeshellarg($right)),
                'expect' => $right,
            ],
        ];
        self::run_job_batch($jobs, dirname($imagepath), 2);
        return [$left, $right];
    }

    public static function detect_two_column_regions(string $imagepath, int $n = 4): array {
        [$fullwidth] = self::get_image_size($imagepath);
        $profile = self::build_density_profile($imagepath, $n, false);
        $globalclusters = self::find_clusters($profile, 5, 30);
        $halves = self::pick_two_halves_by_position($globalclusters, count($profile));

        if (count($halves) < 2) {
            $leftwidth = (int)floor($fullwidth * 0.5);
            $rightwidth = $fullwidth - $leftwidth;
            $left = ['x' => 0, 'w' => max(1, $leftwidth)];
            $right = ['x' => $leftwidth, 'w' => max(1, $rightwidth)];
            $leftparts = self::fallback_half_parts($left, 0.82);
            $rightparts = self::fallback_half_parts($right, 0.70);
        } else {
            $left = [
                'x' => max(0, $halves[0]['x1'] * $n - 8),
                'w' => max(1, (($halves[0]['x2'] - $halves[0]['x1'] + 1) * $n) + 16),
            ];
            $right = [
                'x' => max(0, $halves[1]['x1'] * $n - 8),
                'w' => max(1, (($halves[1]['x2'] - $halves[1]['x1'] + 1) * $n) + 16),
            ];
            $leftparts = self::pick_subclusters_in_half($profile, $halves[0], $n);
            $rightparts = self::pick_subclusters_in_half($profile, $halves[1], $n);
            if (count($leftparts) < 2 || $leftparts[0]['w'] < 20 || $leftparts[1]['w'] < 10) {
                $leftparts = self::fallback_half_parts($left, 0.82);
            }
            if (count($rightparts) < 2 || $rightparts[0]['w'] < 20 || $rightparts[1]['w'] < 10) {
                $rightparts = self::fallback_half_parts($right, 0.70);
            }
        }

        $fix = static function(array $region) use ($fullwidth): array {
            $region['x'] = max(0, min((int)$region['x'], $fullwidth - 1));
            $region['w'] = max(1, min((int)$region['w'], $fullwidth - $region['x']));
            return $region;
        };

        return [
            'l' => $fix($left),
            'l1' => $fix($leftparts[0]),
            'l2' => $fix($leftparts[1]),
            'r' => $fix($right),
            'r1' => $fix($rightparts[0]),
            'r2' => $fix($rightparts[1]),
        ];
    }

    protected static function fallback_half_parts(array $half, float $titleratio): array {
        $titlewidth = (int)floor($half['w'] * $titleratio);
        $pagewidth = $half['w'] - $titlewidth;
        return [
            ['x' => $half['x'], 'w' => max(1, $titlewidth)],
            ['x' => $half['x'] + $titlewidth, 'w' => max(1, $pagewidth)],
        ];
    }

    protected static function build_density_profile(string $imagepath, int $n = 4, bool $countwhite = false): array {
        $tile = (1 / max(1, $n)) * 100;
        $command = sprintf(
            '%s %s -thumbnail %d%% -colorspace Gray -scale x1! txt:-',
            escapeshellarg(self::CONVERT),
            escapeshellarg($imagepath),
            $tile
        );
        $result = command_runner::run($command);
        if ($result['code'] !== 0) {
            throw new \moodle_exception('errorprocessingbook', 'local_aisgk', '', null, $result['output']);
        }
        $profile = [];
        foreach (preg_split('/\R/u', $result['stdout']) as $line) {
            if (preg_match('/\(\s*(\d+)\s*\)/', $line, $m)) {
                $gray = (int)$m[1];
                $profile[] = $countwhite ? $gray : (255 - $gray);
            }
        }
        return $profile;
    }

    protected static function find_clusters(array $profile, int $threshold = 5, int $rest = 10): array {
        $clusters = [];
        $start = null;
        $blankrun = 0;
        foreach ($profile as $x => $value) {
            if ($value > $threshold) {
                if ($start === null) {
                    $start = $x;
                }
                $blankrun = 0;
                continue;
            }
            if ($start !== null) {
                $blankrun++;
                if ($blankrun >= $rest) {
                    $clusters[] = ['x1' => $start, 'x2' => $x - $blankrun];
                    $start = null;
                    $blankrun = 0;
                }
            }
        }
        if ($start !== null) {
            $clusters[] = ['x1' => $start, 'x2' => count($profile) - 1];
        }
        return $clusters;
    }

    protected static function pick_largest_clusters(array $clusters, int $max = 2): array {
        if (!$clusters) {
            return [];
        }
        usort($clusters, static function($a, $b) {
            return ($b['x2'] - $b['x1']) <=> ($a['x2'] - $a['x1']);
        });
        $clusters = array_slice($clusters, 0, min($max, count($clusters)));
        usort($clusters, static function($a, $b) {
            return $a['x1'] <=> $b['x1'];
        });
        return array_values($clusters);
    }

    protected static function pick_two_halves_by_position(array $clusters, int $totalcols): array {
        if (!$clusters) {
            return [];
        }
        $mid = (int)floor($totalcols / 2);
        $left = [];
        $right = [];
        foreach ($clusters as $cluster) {
            $center = (int)floor(($cluster['x1'] + $cluster['x2']) / 2);
            if ($center < $mid) {
                $left[] = $cluster;
            } else {
                $right[] = $cluster;
            }
        }
        $pick = static function(array $arr): ?array {
            if (!$arr) {
                return null;
            }
            usort($arr, static function($a, $b) {
                return ($b['x2'] - $b['x1']) <=> ($a['x2'] - $a['x1']);
            });
            return $arr[0];
        };
        $bestleft = $pick($left);
        $bestright = $pick($right);
        if ($bestleft && $bestright) {
            return [$bestleft, $bestright];
        }
        return self::pick_largest_clusters($clusters, 2);
    }

    protected static function pick_subclusters_in_half(array $profile, array $half, int $n): array {
        $segment = array_slice($profile, $half['x1'], $half['x2'] - $half['x1'] + 1);
        $subclusters = self::pick_largest_clusters(self::find_clusters($segment, 5, 8), 2);
        if (count($subclusters) >= 2) {
            $a = $subclusters[0];
            $b = $subclusters[1];
            $x1a = ($a['x1'] + $half['x1']) * $n;
            $x2a = ($a['x2'] + $half['x1']) * $n;
            $x1b = ($b['x1'] + $half['x1']) * $n;
            $x2b = ($b['x2'] + $half['x1']) * $n;
            return [
                ['x' => max(0, $x1a - 6), 'w' => max(1, ($x2a - $x1a) + 12)],
                ['x' => max(0, $x1b - 6), 'w' => max(1, ($x2b - $x1b) + 12)],
            ];
        }
        return [];
    }

    public static function crop_region(string $imagepath, array $region, string $suffix): string {
        [, $height] = self::get_image_size($imagepath);
        $dest = preg_replace('/\.png$/i', '_' . $suffix . '.png', $imagepath);
        $command = sprintf(
            '%s %s -crop %s +repage %s',
            escapeshellarg(self::CONVERT),
            escapeshellarg($imagepath),
            escapeshellarg(((int)$region['w']) . 'x' . $height . '+' . ((int)$region['x']) . '+0'),
            escapeshellarg($dest)
        );
        $result = command_runner::run($command);
        if ($result['code'] !== 0 || !is_file($dest)) {
            throw new \moodle_exception('errorprocessingbook', 'local_aisgk', '', null, $result['output']);
        }
        return $dest;
    }

    public static function crop_detected_regions(string $imagepath): array {
        $regions = self::detect_two_column_regions($imagepath, 4);
        $files = [];
        foreach ($regions as $name => $region) {
            $files[$name] = self::crop_region($imagepath, $region, $name);
        }
        return $files;
    }

    public static function page_region_should_invert_2col(string $imagepath): bool {
        $command = sprintf(
            '%s %s -colorspace Gray -resize 20%% -threshold 80%% -format %s info:',
            escapeshellarg(self::CONVERT),
            escapeshellarg($imagepath),
            escapeshellarg('%[fx:mean]')
        );
        $result = command_runner::run($command);
        if ($result['code'] !== 0 || $result['stdout'] === '') {
            return false;
        }
        return ((float)trim($result['stdout'])) < 0.55;
    }

    public static function extract_real_page_band_by_two_peaks_2col(string $imagepath, string $suffix = 'pageband', bool $countwhite = false): string {
        [$fullwidth, $fullheight] = self::get_image_size($imagepath);
        $n = 2;
        $profile = self::build_density_profile($imagepath, $n, $countwhite);
        $clusters = self::find_clusters($profile, 4, 3);
        if (!$clusters) {
            return $imagepath;
        }
        $mid = (int)floor(count($profile) * 0.55);
        $clusters = array_values(array_filter($clusters, static function($cluster) use ($mid): bool {
            $center = (int)floor(($cluster['x1'] + $cluster['x2']) / 2);
            return $center >= $mid;
        }));
        if (!$clusters) {
            return $imagepath;
        }
        usort($clusters, static function($a, $b) {
            return (($b['x1'] + $b['x2']) / 2) <=> (($a['x1'] + $a['x2']) / 2);
        });
        $best = $clusters[0];
        $x1 = max(0, $best['x1'] * $n - 3);
        $x2 = min($fullwidth - 1, ($best['x2'] + 1) * $n + 3);
        $region = ['x' => $x1, 'w' => max(1, $x2 - $x1)];
        return self::crop_region($imagepath, $region, $suffix);
    }

    public static function ocr_text_exact(string $imagepath, string $lang = 'vie+eng', int $psm = 6, string $whitelist = ''): string {
        $base = preg_replace('/\.png$/i', '', $imagepath) . '_ocr';
        $extra = ' -c preserve_interword_spaces=1';
        if ($whitelist !== '') {
            $extra .= ' -c tessedit_char_whitelist=' . escapeshellarg($whitelist);
        }
        $command = sprintf(
            '%s %s %s -l %s --psm %d%s',
            escapeshellarg(self::TESSERACT),
            escapeshellarg($imagepath),
            escapeshellarg($base),
            escapeshellarg($lang),
            max(3, min(13, $psm)),
            $extra
        );
        $result = command_runner::run($command);
        $txtfile = $base . '.txt';
        if ($result['code'] !== 0 || !is_file($txtfile)) {
            throw new \moodle_exception('errorprocessingbook', 'local_aisgk', '', null, $result['output']);
        }
        return trim((string)file_get_contents($txtfile));
    }

    public static function ocr_tsv_exact(string $imagepath, string $lang = 'vie+eng', int $psm = 6, string $whitelist = ''): array {
        $base = preg_replace('/\.png$/i', '', $imagepath) . '_ocr_tsv';
        $extra = ' -c preserve_interword_spaces=1';
        if ($whitelist !== '') {
            $extra .= ' -c tessedit_char_whitelist=' . escapeshellarg($whitelist);
        }
        $command = sprintf(
            '%s %s %s -l %s --psm %d tsv%s',
            escapeshellarg(self::TESSERACT),
            escapeshellarg($imagepath),
            escapeshellarg($base),
            escapeshellarg($lang),
            max(3, min(13, $psm)),
            $extra
        );
        $result = command_runner::run($command);
        $tsvfile = $base . '.tsv';
        if ($result['code'] !== 0 || !is_file($tsvfile)) {
            throw new \moodle_exception('errorprocessingbook', 'local_aisgk', '', null, $result['output']);
        }
        $lines = file($tsvfile, FILE_IGNORE_NEW_LINES) ?: [];
        if (count($lines) < 2) {
            return [];
        }
        $groups = [];
        foreach (array_slice($lines, 1) as $line) {
            $cols = str_getcsv($line, "\t");
            if (count($cols) < 12 || (int)$cols[0] !== 5) {
                continue;
            }
            $text = trim((string)$cols[11]);
            if ($text === '') {
                continue;
            }
            $key = $cols[1] . ':' . $cols[2] . ':' . $cols[3] . ':' . $cols[4];
            $left = (int)$cols[6];
            $top = (int)$cols[7];
            $width = (int)$cols[8];
            $height = (int)$cols[9];
            if (!isset($groups[$key])) {
                $groups[$key] = [
                    'parts' => [],
                    'left' => $left,
                    'top' => $top,
                    'right' => $left + $width,
                    'bottom' => $top + $height,
                ];
            }
            $groups[$key]['parts'][] = ['left' => $left, 'text' => $text];
            $groups[$key]['left'] = min($groups[$key]['left'], $left);
            $groups[$key]['top'] = min($groups[$key]['top'], $top);
            $groups[$key]['right'] = max($groups[$key]['right'], $left + $width);
            $groups[$key]['bottom'] = max($groups[$key]['bottom'], $top + $height);
        }
        $entries = [];
        foreach ($groups as $group) {
            usort($group['parts'], static fn($a, $b) => $a['left'] <=> $b['left']);
            $text = preg_replace('/\s+/u', ' ', trim(implode(' ', array_column($group['parts'], 'text'))));
            if ($text === '') {
                continue;
            }
            $entries[] = [
                'text' => $text,
                'y' => (int)round(($group['top'] + $group['bottom']) / 2),
                'top' => (int)$group['top'],
                'bottom' => (int)$group['bottom'],
                'left' => (int)$group['left'],
            ];
        }
        usort($entries, static function($a, $b) {
            return $a['y'] === $b['y'] ? ($a['left'] <=> $b['left']) : ($a['y'] <=> $b['y']);
        });
        return array_values($entries);
    }

    protected static function is_probably_new_toc_item_2col(string $text): bool {
        $text = trim(preg_replace('/\s+/u', ' ', $text));
        if ($text === '') {
            return false;
        }
        return (bool)preg_match(
            '/^\s*(bài\s*\d+|bai\s*\d+|chương\b|chuong\b|chủ\s*đề\b|chu\s*de\b|phần\b|phan\b|luyện\s*tập\b|luyen\s*tap\b|ôn\s*tập\b|on\s*tap\b|bài\s*tập\s*cuối\s*chương\b|bai\s*tap\s*cuoi\s*chuong\b|hoạt\s*động\b|tam\s*thiep\b|t[âaă]m\s*thiệp\b|vẽ\s*hình\b|ve\s*hinh\b|geogebra\b|sử\s*dụng\s*máy\s*tính\b|su\s*dung\s*may\s*tinh\b|bảng\s*tra\s*cứu\b|bang\s*tra\s*cuu\b|bảng\s*giải\s*thích\b|bang\s*giai\s*thich\b)/ui',
            $text
        );
    }

    protected static function title_line_looks_incomplete_2col(string $text): bool {
        $text = trim(preg_replace('/\s+/u', ' ', $text));
        if ($text === '') {
            return false;
        }
        $last3 = mb_substr($text, max(0, mb_strlen($text, 'UTF-8') - 3), null, 'UTF-8');
        if (mb_strpos($last3, '.', 0, 'UTF-8') === false) {
            return false;
        }
        $tokens = preg_split('/\s+/u', $text) ?: [];
        if (!$tokens) {
            return false;
        }
        $last = end($tokens);
        $clean = preg_replace('/[^\p{L}\p{N}\.]/u', '', (string)$last);
        $clean = trim((string)$clean);
        if ($clean === '' || $clean === '.') {
            return false;
        }
        if (preg_match('/^[IVXLivxl]+\.?$/u', $clean)) {
            return false;
        }
        $lettersonly = preg_replace('/[^\p{L}\p{N}]/u', '', $clean);
        return mb_strlen((string)$lettersonly, 'UTF-8') === 1;
    }

    protected static function is_all_uppercase_line(string $line): bool {
        $letters = preg_replace('/[^\p{L}]+/u', '', $line);
        if ($letters === '') {
            return false;
        }
        return mb_strtoupper($letters, 'UTF-8') === $letters;
    }

    public static function merge_indented_title_entries_2col(array $entries): array {
        $entries = self::normalize_entries($entries);
        if (count($entries) < 2) {
            return $entries;
        }
        $baselefts = [];
        foreach ($entries as $entry) {
            $text = trim((string)($entry['text'] ?? ''));
            $left = (int)($entry['left'] ?? 0);
            if ($text !== '' && self::is_probably_new_toc_item_2col($text)) {
                $baselefts[] = $left;
            }
        }
        if (!$baselefts) {
            return $entries;
        }
        sort($baselefts);
        $avgleft = $baselefts[(int)floor(count($baselefts) / 2)];
        $result = [];
        foreach ($entries as $entry) {
            $text = trim((string)($entry['text'] ?? ''));
            $left = (int)($entry['left'] ?? 0);
            if (!$result) {
                $result[] = $entry;
                continue;
            }
            $lastidx = count($result) - 1;
            $prev = $result[$lastidx];
            $dy = abs((int)$entry['top'] - (int)$prev['bottom']);
            $isnewitem = self::is_probably_new_toc_item_2col($text);
            $isindentedcontinuation = (!$isnewitem && $left >= ($avgleft + 25) && $dy <= 22);
            if ($isindentedcontinuation) {
                $result[$lastidx]['text'] = trim((string)$prev['text'] . ' ' . $text);
                $result[$lastidx]['bottom'] = max((int)$prev['bottom'], (int)$entry['bottom']);
                $result[$lastidx]['y'] = (int)round(($result[$lastidx]['top'] + $result[$lastidx]['bottom']) / 2);
                continue;
            }
            $result[] = $entry;
        }
        return array_values($result);
    }

    public static function normalize_page_token_2col(?string $token): ?int {
        $token = trim((string)$token);
        if ($token === '') {
            return null;
        }
        $token = preg_replace('/^[^\pL\pN\+\-]+|[^\pL\pN\+\-]+$/u', '', $token);
        $token = preg_replace('/\s+/u', '', $token);
        if ($token === '') {
            return null;
        }
        if (preg_match('/^\d{1,4}$/', $token)) {
            return (int)$token;
        }
        $mapped = strtr($token, ['O' => '0', 'o' => '0', 'I' => '1', 'l' => '1', 'S' => '5', 's' => '5', 'B' => '8', 'Z' => '2', 'T' => '7', 't' => '7', '+' => '7']);
        return preg_match('/^\d{1,4}$/', $mapped) ? (int)$mapped : null;
    }

    public static function normalize_entries(array $entries): array {
        $out = [];
        foreach ($entries as $entry) {
            $text = trim(preg_replace('/\s+/u', ' ', (string)($entry['text'] ?? '')));
            if ($text === '') {
                continue;
            }
            $entry['text'] = $text;
            $out[] = $entry;
        }
        return array_values($out);
    }

    public static function merge_wrapped_title_entries_2col(array $entries): array {
        $entries = self::normalize_entries($entries);
        if (count($entries) < 2) {
            return $entries;
        }
        $result = [];
        foreach ($entries as $entry) {
            if (!$result) {
                $result[] = $entry;
                continue;
            }
            $previndex = count($result) - 1;
            $prev = $result[$previndex];
            $prevtext = (string)$prev['text'];
            $currtext = (string)$entry['text'];
            $firstchar = null;
            if (preg_match('/\p{L}/u', $currtext, $m, PREG_OFFSET_CAPTURE)) {
                $offset = $m[0][1];
                $firstchar = mb_substr($currtext, $offset, 1, 'UTF-8');
            }
            $islowerstart = false;
            if ($firstchar !== null) {
                $islowerstart = (
                    mb_strtolower($firstchar, 'UTF-8') === $firstchar &&
                    mb_strtoupper($firstchar, 'UTF-8') !== $firstchar
                );
            }
            $closey = abs((int)$entry['top'] - (int)$prev['bottom']) <= 18 || abs((int)$entry['y'] - (int)$prev['y']) <= 10;
            $currisnewitem = self::is_probably_new_toc_item_2col($currtext);
            if ($currisnewitem) {
                $result[] = $entry;
                continue;
            }
            $previncomplete = self::title_line_looks_incomplete_2col($prevtext);
            $shouldmerge = false;
            if ($islowerstart && !$currisnewitem) {
                $shouldmerge = true;
            } else if ($previncomplete && !$currisnewitem && $closey) {
                $shouldmerge = true;
            }
            if ($shouldmerge) {
                $result[$previndex]['text'] = trim($prevtext . ' ' . $currtext);
                $result[$previndex]['bottom'] = max((int)$prev['bottom'], (int)$entry['bottom']);
                $result[$previndex]['y'] = (int)round(($result[$previndex]['top'] + $result[$previndex]['bottom']) / 2);
                continue;
            }
            $result[] = $entry;
        }
        return array_values($result);
    }

    public static function filter_title_entry_lines_2col(array $entries): array {
        $entries = self::normalize_entries($entries);
        $out = [];
        foreach ($entries as $entry) {
            $line = trim((string)($entry['text'] ?? ''));
            $line = preg_replace('/\s+/u', ' ', $line);
            if ($line === '') {
                continue;
            }
            if (preg_match('/^(MỤC LỤC|MUC LUC|TRANG)$/iu', $line)) {
                continue;
            }
            if (self::is_all_uppercase_line($line) && !preg_match('/^(CHƯƠNG\s+[IVX\d]+|PHẦN\b)/ui', $line)) {
                continue;
            }
            $isnewitem = self::is_probably_new_toc_item_2col($line);
            if ($isnewitem) {
                $entry['text'] = $line;
                $out[] = $entry;
                continue;
            }
            if (!$out) {
                continue;
            }
            $lastidx = count($out) - 1;
            $prevtext = (string)$out[$lastidx]['text'];
            $dy = abs((int)$entry['top'] - (int)$out[$lastidx]['bottom']);
            $previncomplete = self::title_line_looks_incomplete_2col($prevtext);
            $firstchar = null;
            if (preg_match('/\p{L}/u', $line, $m, PREG_OFFSET_CAPTURE)) {
                $offset = $m[0][1];
                $firstchar = mb_substr($line, $offset, 1, 'UTF-8');
            }
            $islowerstart = false;
            if ($firstchar !== null) {
                $islowerstart = (
                    mb_strtolower($firstchar, 'UTF-8') === $firstchar &&
                    mb_strtoupper($firstchar, 'UTF-8') !== $firstchar
                );
            }
            $iscontinuation = false;
            if ($dy <= 20 && $previncomplete) {
                $iscontinuation = true;
            } else if ($dy <= 12 && $islowerstart) {
                $iscontinuation = true;
            }
            if ($iscontinuation) {
                $out[$lastidx]['text'] = trim($out[$lastidx]['text'] . ' ' . $line);
                $out[$lastidx]['bottom'] = max((int)$out[$lastidx]['bottom'], (int)$entry['bottom']);
                $out[$lastidx]['y'] = (int)round(($out[$lastidx]['top'] + $out[$lastidx]['bottom']) / 2);
            }
        }
        return array_values($out);
    }

    public static function filter_page_entry_lines_2col(array $entries): array {
        $out = [];
        foreach (self::normalize_entries($entries) as $entry) {
            $text = trim((string)($entry['text'] ?? ''));
            if ($text === '') {
                continue;
            }
            if (isset($entry['left']) && (int)$entry['left'] < 3) {
                continue;
            }
            if (!preg_match_all('/[0-9OolIsSBZT\+]{1,4}/u', $text, $m)) {
                continue;
            }
            $best = null;
            foreach ($m[0] as $token) {
                $page = self::normalize_page_token_2col($token);
                if ($page !== null) {
                    $best = $page;
                }
            }
            if ($best === null) {
                continue;
            }
            $entry['page'] = $best;
            $out[] = $entry;
        }
        return array_values($out);
    }

    public static function pair_title_page_entries_by_y_2col(array $titles, array $pages, int $tolerance = 26): array {
        $pairs = [];
        $used = [];
        foreach ($titles as $title) {
            $bestindex = null;
            $bestdist = null;
            foreach ($pages as $index => $pageentry) {
                if (isset($used[$index])) {
                    continue;
                }
                $dist = abs((int)$title['y'] - (int)$pageentry['y']);
                if ($bestdist === null || $dist < $bestdist) {
                    $bestdist = $dist;
                    $bestindex = $index;
                }
            }
            if ($bestindex !== null && $bestdist !== null && $bestdist <= $tolerance) {
                $used[$bestindex] = true;
                $pairs[] = [
                    'text' => $title['text'],
                    'y' => (int)$title['y'],
                    'page' => (int)$pages[$bestindex]['page'],
                ];
            } else {
                $pairs[] = [
                    'text' => $title['text'],
                    'y' => (int)$title['y'],
                    'page' => null,
                ];
            }
        }
        return array_values($pairs);
    }

    public static function ocr_images(array $images, int $columns = 1, int $splitpercent = 50, int $psm = 4, string $lang = 'vie+eng'): array {
        $jobs = [];
        $ordered = [];
        foreach ($images as $image) {
            if ((int)$columns === 2) {
                [$left, $right] = self::crop_columns($image, $splitpercent);
                foreach ([$left, $right] as $part) {
                    $prepared = self::preprocess_image($part);
                    $base = preg_replace('/\.png$/i', '', $prepared);
                    $jobs[] = [
                        'command' => sprintf('%s %s %s -l %s --psm %d -c preserve_interword_spaces=1', escapeshellarg(self::TESSERACT), escapeshellarg($prepared), escapeshellarg($base), escapeshellarg($lang), $psm),
                        'expect' => $base . '.txt',
                    ];
                    $ordered[] = $base . '.txt';
                }
                continue;
            }
            $prepared = self::preprocess_image($image);
            $base = preg_replace('/\.png$/i', '', $prepared);
            $jobs[] = [
                'command' => sprintf('%s %s %s -l %s --psm %d -c preserve_interword_spaces=1', escapeshellarg(self::TESSERACT), escapeshellarg($prepared), escapeshellarg($base), escapeshellarg($lang), $psm),
                'expect' => $base . '.txt',
            ];
            $ordered[] = $base . '.txt';
        }

        self::run_job_batch($jobs, null, self::get_parallelism());
        $texts = [];
        foreach ($ordered as $txtfile) {
            $texts[] = is_file($txtfile) ? trim((string)file_get_contents($txtfile)) : '';
        }
        return $texts;
    }

    protected static function run_job_batch(array $jobs, ?string $cwd, int $parallelism): void {
        if (!$jobs) {
            return;
        }
        $parallelism = max(1, $parallelism);
        foreach (array_chunk($jobs, $parallelism) as $chunk) {
            $procs = [];
            foreach ($chunk as $idx => $job) {
                $descriptor = [0 => ['pipe', 'r'], 1 => ['pipe', 'w'], 2 => ['pipe', 'w']];
                $proc = proc_open($job['command'], $descriptor, $pipes, $cwd);
                if (!is_resource($proc)) {
                    throw new \moodle_exception('errorprocessingbook', 'local_aisgk', '', null, 'Không thể khởi tạo tiến trình OCR.');
                }
                fclose($pipes[0]);
                $procs[$idx] = ['proc' => $proc, 'pipes' => $pipes, 'expect' => $job['expect']];
            }
            foreach ($procs as $procinfo) {
                $stdout = stream_get_contents($procinfo['pipes'][1]);
                $stderr = stream_get_contents($procinfo['pipes'][2]);
                fclose($procinfo['pipes'][1]);
                fclose($procinfo['pipes'][2]);
                $code = proc_close($procinfo['proc']);
                if ($code !== 0 || !is_file($procinfo['expect'])) {
                    $output = trim(trim((string)$stdout) . "\n" . trim((string)$stderr));
                    throw new \moodle_exception('errorprocessingbook', 'local_aisgk', '', null, $output);
                }
            }
        }
    }
}
