define(['jquery', 'core/modal_factory'], function($, ModalFactory) {
    var makeDraggableAndResizable = function(modal) {
        var root = modal.getRoot();
        var dialog = root.find('.modal-dialog');
        var content = root.find('.modal-content');
        var header = root.find('.modal-header');
        var body = modal.getBody();
        var iframe = body.find('iframe');

        dialog.css({
            position: 'fixed',
            left: '5vw',
            top: '4vh',
            width: '90vw',
            maxWidth: '90vw',
            margin: '0',
            transform: 'none'
        });

        content.css({
            position: 'relative',
            width: '100%',
            height: '90vh',
            minWidth: '760px',
            minHeight: '420px',
            overflow: 'hidden',
            resize: 'both',
            boxSizing: 'border-box'
        });

        header.css({
            cursor: 'move',
            userSelect: 'none'
        });

        body.css({
            padding: '0',
            overflow: 'hidden',
            height: 'calc(90vh - 56px)'
        });

        iframe.css({
            width: '100%',
            height: '100%',
            border: '0',
            display: 'block'
        });

        var resizeObserver = function() {
            var headerHeight = header.outerHeight() || 56;
            var newHeight = content.outerHeight() - headerHeight;
            if (newHeight < 200) {
                newHeight = 200;
            }
            body.css('height', newHeight + 'px');
            iframe.css('height', '100%');
        };

        resizeObserver();

        var dragging = false;
        var startX = 0;
        var startY = 0;
        var startLeft = 0;
        var startTop = 0;

        header.on('mousedown', function(e) {
            if ($(e.target).closest('button, .close, [data-action="hide"]').length) {
                return;
            }

            dragging = true;
            startX = e.clientX;
            startY = e.clientY;
            startLeft = parseFloat(dialog.css('left')) || 0;
            startTop = parseFloat(dialog.css('top')) || 0;

            $(document).on('mousemove.localAisgkDrag', function(ev) {
                if (!dragging) {
                    return;
                }

                var left = startLeft + (ev.clientX - startX);
                var top = startTop + (ev.clientY - startY);

                var maxLeft = Math.max(0, window.innerWidth - dialog.outerWidth());
                var maxTop = Math.max(0, window.innerHeight - 80);

                if (left < 0) {
                    left = 0;
                }
                if (top < 0) {
                    top = 0;
                }
                if (left > maxLeft) {
                    left = maxLeft;
                }
                if (top > maxTop) {
                    top = maxTop;
                }

                dialog.css({
                    left: left + 'px',
                    top: top + 'px'
                });
            });

            $(document).on('mouseup.localAisgkDrag', function() {
                dragging = false;
                $(document).off('.localAisgkDrag');
            });
        });

        var ro = new ResizeObserver(function() {
            resizeObserver();
        });
        ro.observe(content[0]);

        root.on('hidden.bs.modal', function() {
            ro.disconnect();
            $(document).off('.localAisgkDrag');
        });
    };

    var open = async function(config) {
        config = config || {};

        var title = config.title || '';
        var url = config.url || '';

        var iframe = $('<iframe>', {
            src: url,
            title: title,
            css: {
                width: '100%',
                height: '100%',
                border: '0',
                display: 'block'
            }
        });

        var modal = await ModalFactory.create({
            title: title,
            body: iframe,
            large: true
        });

        modal.show();
        makeDraggableAndResizable(modal);
    };

    return {
        open: open
    };
});
