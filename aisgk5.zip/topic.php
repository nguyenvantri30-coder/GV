<?php
require('../../config.php');

use local_aisgk\book_repository;
use local_aisgk\toc_repository;
use local_aisgk\local\sgk_processor;

$courseid = required_param('id', PARAM_INT);
$bookid = optional_param('bookid', 0, PARAM_INT);
$action = optional_param('action', '', PARAM_ALPHA);

$course = get_course($courseid);
require_login($course);

$context = context_course::instance($courseid);
require_capability('local/aisgk:createtopic', $context);

$PAGE->set_context($context);
$PAGE->set_url('/local/aisgk/topic.php', ['id' => $courseid, 'bookid' => $bookid]);
$PAGE->set_pagelayout('embedded');
$PAGE->set_title(get_string('createtopic', 'local_aisgk'));

$books = book_repository::get_all_by_courseid($courseid);
if (empty($books)) {
    throw new moodle_exception('bookrequired', 'local_aisgk');
}

if ($bookid <= 0) {
    $bookid = (int)reset($books)->id;
}

$book = book_repository::get_by_id($bookid);
if (!$book || (int)$book->courseid !== $courseid) {
    throw new moodle_exception('invalidparameter');
}

$scanmessage = '';
$scanerror = '';

if ($action === 'save' && confirm_sesskey() && data_submitted()) {
    $rows = [];
    $sobais = optional_param_array('sobai', [], PARAM_RAW_TRIMMED);
    $tenbais = optional_param_array('tenbai', [], PARAM_RAW_TRIMMED);
    $trangs = optional_param_array('trang', [], PARAM_RAW_TRIMMED);
    $endtrangs = optional_param_array('endtrang', [], PARAM_RAW_TRIMMED);
    $rawlines = optional_param_array('rawline', [], PARAM_RAW_TRIMMED);
    $deletes = optional_param_array('delete', [], PARAM_INT);

    $max = max(count($sobais), count($tenbais), count($trangs), count($endtrangs), count($rawlines));
    for ($i = 0; $i < $max; $i++) {
        if (!empty($deletes[$i])) {
            continue;
        }

        $row = [
            'sobai' => trim((string)($sobais[$i] ?? '')),
            'tenbai' => trim((string)($tenbais[$i] ?? '')),
            'trang' => trim((string)($trangs[$i] ?? '')),
            'endtrang' => trim((string)($endtrangs[$i] ?? '')),
            'rawline' => trim((string)($rawlines[$i] ?? '')),
        ];

        if ($row['sobai'] === '' && $row['tenbai'] === '' && $row['trang'] === '' && $row['endtrang'] === '' && $row['rawline'] === '') {
            continue;
        }

        $rows[] = $row;
    }

    $rows = toc_repository::calculate_end_pages($rows);
    toc_repository::replace_book_toc($bookid, $rows);

    redirect(
        new moodle_url('/local/aisgk/topic.php', ['id' => $courseid, 'bookid' => $bookid]),
        get_string('tocsaved', 'local_aisgk'),
        null,
        \core\output\notification::NOTIFY_SUCCESS
    );
}

if ($action === 'scan' && confirm_sesskey()) {
    try {
        $preview = sgk_processor::preview_topic_items($bookid);
        $rows = [];
        foreach ($preview['items'] as $item) {
            $rows[] = [
                'sobai' => $item['sobai'] ?? '',
                'tenbai' => $item['tenbai'] ?? '',
                'trang' => $item['trang'] ?? '',
                'endtrang' => $item['endtrang'] ?? '',
                'rawline' => $item['rawline'] ?? '',
            ];
        }
        $rows = toc_repository::calculate_end_pages($rows);
        toc_repository::replace_book_toc($bookid, $rows);
        $scanmessage = get_string('tocscanned', 'local_aisgk', count($rows));
    } catch (Throwable $e) {
        $scanerror = $e->getMessage();
    }
}

$tocrows = toc_repository::get_by_bookid($bookid);
if (empty($tocrows)) {
    for ($i = 1; $i <= 8; $i++) {
        $tocrows[] = (object)[
            'sobai' => '',
            'tenbai' => '',
            'trang' => null,
            'endtrang' => null,
            'rawline' => '',
        ];
    }
}

echo $OUTPUT->header();
?>
<style>
.local-aisgk-topic-manager {
    padding: 8px 10px 14px;
}

.local-aisgk-toolbar,
.local-aisgk-bookinfo,
.local-aisgk-actions {
    margin-bottom: 12px;
}

.local-aisgk-book-select-form {
    display: flex;
    gap: 8px;
    align-items: end;
    flex-wrap: wrap;
    margin-top: 8px;
}

.local-aisgk-book-select-form .fitem {
    display: flex;
    flex-direction: column;
    gap: 4px;
}

.local-aisgk-book-select-form select {
    min-width: 320px;
    max-width: 100%;
    height: 34px;
}

.local-aisgk-bookinfo {
    border: 1px solid #dbe3ea;
    background: #f8fbff;
    border-radius: 8px;
    padding: 10px 12px;
    font-size: 13px;
    line-height: 1.5;
}

.local-aisgk-actions {
    display: flex;
    gap: 8px;
    align-items: center;
    flex-wrap: wrap;
}

.local-aisgk-inline-form {
    margin: 0;
}

.local-aisgk-toc-hint {
    font-size: 12px;
    color: #666;
    margin-top: 6px;
}

.local-aisgk-toc-table {
    width: 100%;
    border-collapse: collapse;
    table-layout: fixed;
    margin-top: 10px;
}

.local-aisgk-toc-table th,
.local-aisgk-toc-table td {
    border: 1px solid #e5e7eb;
    padding: 4px 5px;
    vertical-align: top;
    font-size: 13px;
}

.local-aisgk-toc-table th {
    background: #f8f9fa;
    font-weight: 600;
}

.local-aisgk-toc-col-index {
    width: 44px;
}
.local-aisgk-toc-col-sobai {
    width: 82px;
}
.local-aisgk-toc-col-trang {
    width: 92px;
}
.local-aisgk-toc-col-endtrang {
    width: 92px;
}
.local-aisgk-toc-col-tenbai {
    width: 34%;
}
.local-aisgk-toc-col-rawline {
    width: 32%;
}
.local-aisgk-toc-col-delete {
    width: 70px;
    text-align: center;
}

.local-aisgk-toc-table input[type="text"],
.local-aisgk-toc-table input[type="number"] {
    width: 100%;
    box-sizing: border-box;
    min-height: 28px;
    height: 28px;
    padding: 3px 6px;
    font-size: 13px;
    margin: 0;
}

.local-aisgk-toc-table textarea {
    width: 100%;
    box-sizing: border-box;
    min-height: 48px;
    height: 48px;
    padding: 4px 6px;
    font-size: 13px;
    line-height: 1.3;
    resize: vertical;
    margin: 0;
}

.local-aisgk-toc-table .cell-center {
    text-align: center;
}

.local-aisgk-toc-footer {
    margin-top: 12px;
    display: flex;
    gap: 8px;
    flex-wrap: wrap;
    align-items: center;
}

.local-aisgk-toc-footer .btn,
.local-aisgk-actions .btn,
.local-aisgk-book-select-form .btn {
    min-height: 32px;
    padding: 5px 10px;
    font-size: 13px;
}
</style>

<script>
document.addEventListener('DOMContentLoaded', function() {
    var addRowBtn = document.getElementById('local-aisgk-add-row');
    var tbody = document.getElementById('local-aisgk-toc-body');

    if (addRowBtn && tbody) {
        addRowBtn.addEventListener('click', function(e) {
            e.preventDefault();

            var index = tbody.querySelectorAll('tr').length;
            var tr = document.createElement('tr');

            tr.innerHTML =
                '<td class="cell-center">' + (index + 1) + '</td>' +
                '<td><input type="text" name="sobai[]" value="" class="form-control"></td>' +
                '<td><textarea name="tenbai[]" class="form-control"></textarea></td>' +
                '<td><input type="number" name="trang[]" value="" min="1" class="form-control"></td>' +
                '<td><input type="number" name="endtrang[]" value="" min="1" class="form-control"></td>' +
                '<td><textarea name="rawline[]" class="form-control"></textarea></td>' +
                '<td class="cell-center"><input type="checkbox" name="delete[' + index + ']" value="1"></td>';

            tbody.appendChild(tr);
        });
    }
});
</script>
<?php

echo html_writer::start_div('local-aisgk-modal-page local-aisgk-topic-manager');
echo html_writer::tag('h4', get_string('createtopicforcourse', 'local_aisgk'));
echo html_writer::tag('p', get_string('topicmanagerdesc', 'local_aisgk'));

$options = [];
foreach ($books as $item) {
    $options[$item->id] = format_string($item->name ?: $item->filename);
}

echo html_writer::start_tag('form', [
    'method' => 'get',
    'action' => new moodle_url('/local/aisgk/topic.php'),
    'class' => 'local-aisgk-book-select-form'
]);
echo html_writer::empty_tag('input', ['type' => 'hidden', 'name' => 'id', 'value' => $courseid]);

echo html_writer::start_div('fitem');
echo html_writer::label(get_string('bookselect', 'local_aisgk'), 'menu-bookid');
echo html_writer::select($options, 'bookid', $bookid, false, ['id' => 'menu-bookid']);
echo html_writer::end_div();

echo html_writer::start_div('fitem');
echo html_writer::empty_tag('input', [
    'type' => 'submit',
    'value' => get_string('viewchange', 'local_aisgk'),
    'class' => 'btn btn-secondary'
]);
echo html_writer::end_div();

echo html_writer::end_tag('form');

echo html_writer::tag(
    'div',
    get_string('booklabel', 'local_aisgk') . ': <strong>' . s($book->name ?: $book->filename) . '</strong><br>' .
    get_string('tocpageslabel', 'local_aisgk') . ': ' . (int)$book->tocfrompage . ' - ' . (int)$book->toctopage,
    ['class' => 'local-aisgk-bookinfo']
);

if ($scanmessage !== '') {
    echo $OUTPUT->notification($scanmessage, \core\output\notification::NOTIFY_SUCCESS);
}
if ($scanerror !== '') {
    echo $OUTPUT->notification($scanerror, \core\output\notification::NOTIFY_ERROR);
}

echo html_writer::start_div('local-aisgk-actions');

echo html_writer::start_tag('form', [
    'method' => 'post',
    'action' => new moodle_url('/local/aisgk/topic.php', ['id' => $courseid, 'bookid' => $bookid, 'action' => 'scan']),
    'class' => 'local-aisgk-inline-form'
]);
echo html_writer::empty_tag('input', ['type' => 'hidden', 'name' => 'sesskey', 'value' => sesskey()]);
echo html_writer::empty_tag('input', [
    'type' => 'submit',
    'value' => get_string('scantoc', 'local_aisgk'),
    'class' => 'btn btn-secondary'
]);
echo html_writer::end_tag('form');

echo html_writer::tag('div', get_string('tocscanincludespecial', 'local_aisgk'), ['class' => 'local-aisgk-toc-hint']);

echo html_writer::end_div();

echo html_writer::start_tag('form', [
    'method' => 'post',
    'action' => new moodle_url('/local/aisgk/topic.php', ['id' => $courseid, 'bookid' => $bookid, 'action' => 'save'])
]);
echo html_writer::empty_tag('input', ['type' => 'hidden', 'name' => 'sesskey', 'value' => sesskey()]);

echo html_writer::start_tag('table', ['class' => 'generaltable local-aisgk-toc-table local-aisgk-toc-editor']);
echo html_writer::start_tag('thead');
echo html_writer::tag(
    'tr',
    html_writer::tag('th', '#', ['class' => 'local-aisgk-toc-col-index']) .
    html_writer::tag('th', 'Lesson no.', ['class' => 'local-aisgk-toc-col-sobai']) .
    html_writer::tag('th', 'Lesson title', ['class' => 'local-aisgk-toc-col-tenbai']) .
    html_writer::tag('th', 'Start page', ['class' => 'local-aisgk-toc-col-trang']) .
    html_writer::tag('th', 'End page', ['class' => 'local-aisgk-toc-col-endtrang']) .
    html_writer::tag('th', 'Raw OCR', ['class' => 'local-aisgk-toc-col-rawline']) .
    html_writer::tag('th', 'Delete', ['class' => 'local-aisgk-toc-col-delete'])
);
echo html_writer::end_tag('thead');

echo html_writer::start_tag('tbody', ['id' => 'local-aisgk-toc-body']);

foreach ($tocrows as $index => $row) {
    $i = (int)$index;

    echo html_writer::start_tag('tr');

    echo html_writer::tag('td', (string)($i + 1), ['class' => 'cell-center']);

    echo html_writer::tag('td',
        html_writer::empty_tag('input', [
            'type' => 'text',
            'name' => 'sobai[]',
            'value' => ((string)($row->sobai ?? '') === '0' ? '' : s((string)($row->sobai ?? ''))),
            'class' => 'form-control'
        ])
    );

    echo html_writer::tag('td',
        html_writer::tag('textarea',
            s((string)($row->tenbai ?? '')),
            [
                'name' => 'tenbai[]',
                'class' => 'form-control'
            ]
        )
    );

    echo html_writer::tag('td',
        html_writer::empty_tag('input', [
            'type' => 'number',
            'name' => 'trang[]',
            'value' => s((string)($row->trang ?? '')),
            'class' => 'form-control',
            'min' => 1
        ])
    );

    echo html_writer::tag('td',
        html_writer::empty_tag('input', [
            'type' => 'number',
            'name' => 'endtrang[]',
            'value' => s((string)($row->endtrang ?? '')),
            'class' => 'form-control',
            'min' => 1
        ])
    );

    echo html_writer::tag('td',
        html_writer::tag('textarea',
            s((string)($row->rawline ?? '')),
            [
                'name' => 'rawline[]',
                'class' => 'form-control'
            ]
        )
    );

    echo html_writer::tag('td',
        html_writer::empty_tag('input', [
            'type' => 'checkbox',
            'name' => 'delete[' . $i . ']',
            'value' => 1
        ]),
        ['class' => 'cell-center']
    );

    echo html_writer::end_tag('tr');
}

echo html_writer::end_tag('tbody');
echo html_writer::end_tag('table');

echo html_writer::tag('p', get_string('endtrangautohelp', 'local_aisgk'), ['class' => 'text-muted mt-2']);

echo html_writer::start_div('local-aisgk-toc-footer');
echo html_writer::tag('button', 'Add row', [
    'type' => 'button',
    'id' => 'local-aisgk-add-row',
    'class' => 'btn btn-secondary'
]);
echo html_writer::empty_tag('input', [
    'type' => 'submit',
    'value' => get_string('savechanges', 'local_aisgk'),
    'class' => 'btn btn-primary'
]);
echo html_writer::link(
    new moodle_url('/local/aisgk/topic.php', ['id' => $courseid, 'bookid' => $bookid]),
    get_string('reloadtoc', 'local_aisgk'),
    ['class' => 'btn btn-secondary']
);
echo html_writer::end_div();

echo html_writer::end_tag('form');
echo html_writer::end_div();

echo $OUTPUT->footer();
