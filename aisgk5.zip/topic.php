<?php
require('../../config.php');

use local_aisgk\book_repository;
use local_aisgk\toc_repository;
use local_aisgk\local\sgk_processor;

$courseid = required_param('id', PARAM_INT);
$bookid = optional_param('bookid', 0, PARAM_INT);
$action = optional_param('action', '', PARAM_ALPHA);
$columns = optional_param('columns', 1, PARAM_INT);
$psm = optional_param('psm', 3, PARAM_INT);
$columns = ($columns === 2) ? 2 : 1;
$splitpercent = 50;

$course = get_course($courseid);
require_login($course);

$context = context_course::instance($courseid);
require_capability('local/aisgk:createtopic', $context);

$PAGE->set_context($context);
$PAGE->set_url('/local/aisgk/topic.php', ['id' => $courseid, 'bookid' => $bookid]);
$PAGE->set_pagelayout('embedded');
$PAGE->set_title(get_string('createtopic', 'local_aisgk'));

$books = book_repository::get_all_by_courseid($courseid);
if (empty($books)) {
    throw new moodle_exception('bookrequired', 'local_aisgk');
}

if ($bookid <= 0) {
    $bookid = (int)reset($books)->id;
}

$book = book_repository::get_by_id($bookid);
if (!$book || (int)$book->courseid !== $courseid) {
    throw new moodle_exception('invalidparameter');
}

$scanmessage = '';
$scanerror = '';

if ($action === 'save' && confirm_sesskey() && data_submitted()) {
    $rows = [];
    $sobais = optional_param_array('sobai', [], PARAM_RAW_TRIMMED);
    $tenbais = optional_param_array('tenbai', [], PARAM_RAW_TRIMMED);
    $trangs = optional_param_array('trang', [], PARAM_RAW_TRIMMED);
    $endtrangs = optional_param_array('endtrang', [], PARAM_RAW_TRIMMED);
    $rawlines = optional_param_array('rawline', [], PARAM_RAW_TRIMMED);
    $deletes = optional_param_array('delete', [], PARAM_INT);

    $max = max(count($sobais), count($tenbais), count($trangs), count($endtrangs), count($rawlines));
    for ($i = 0; $i < $max; $i++) {
        if (!empty($deletes[$i])) {
            continue;
        }

        $row = [
            'sobai' => trim((string)($sobais[$i] ?? '')),
            'tenbai' => trim((string)($tenbais[$i] ?? '')),
            'trang' => trim((string)($trangs[$i] ?? '')),
            'endtrang' => trim((string)($endtrangs[$i] ?? '')),
            'rawline' => trim((string)($rawlines[$i] ?? '')),
        ];

        if ($row['sobai'] === '' && $row['tenbai'] === '' && $row['trang'] === '' && $row['endtrang'] === '' && $row['rawline'] === '') {
            continue;
        }

        $rows[] = $row;
    }

    $rows = toc_repository::calculate_end_pages($rows);
    toc_repository::replace_book_toc($bookid, $rows);

    redirect(
        new moodle_url('/local/aisgk/topic.php', ['id' => $courseid, 'bookid' => $bookid]),
        get_string('tocsaved', 'local_aisgk'),
        null,
        \core\output\notification::NOTIFY_SUCCESS
    );
}

if ($action === 'scan' && confirm_sesskey()) {
    try {
        $preview = sgk_processor::preview_topic_items($bookid, $columns, $splitpercent, $psm);
        $rows = [];
        foreach ($preview['items'] as $item) {
            $rows[] = [
                'sobai' => $item['sobai'] ?? '',
                'tenbai' => $item['tenbai'] ?? '',
                'trang' => $item['trang'] ?? '',
                'endtrang' => $item['endtrang'] ?? '',
                'rawline' => $item['rawline'] ?? '',
            ];
        }
        $rows = toc_repository::calculate_end_pages($rows);
        toc_repository::replace_book_toc($bookid, $rows);
        $scanmessage = get_string('tocscanned', 'local_aisgk', count($rows));
    } catch (Throwable $e) {
        $scanerror = $e->getMessage();
    }
}

$tocrows = toc_repository::get_by_bookid($bookid);
if (empty($tocrows)) {
    for ($i = 1; $i <= 8; $i++) {
        $tocrows[] = (object)[
            'sobai' => '',
            'tenbai' => '',
            'trang' => null,
            'endtrang' => null,
            'rawline' => '',
        ];
    }
}

echo $OUTPUT->header();
?>
<style>
html, body.pagelayout-embedded {
    overflow: hidden !important;
}

body.pagelayout-embedded #page-wrapper,
body.pagelayout-embedded #page,
body.pagelayout-embedded #page-content,
body.pagelayout-embedded #region-main-box,
body.pagelayout-embedded #region-main,
body.pagelayout-embedded [role="main"] {
    overflow: visible !important;
    max-height: none !important;
    height: auto !important;
}

.local-aisgk-topic-manager {
    padding: 6px 8px 10px;
    font-size: 13px;
}

.local-aisgk-topbar,
.local-aisgk-bookinfo,
.local-aisgk-actions,
.local-aisgk-toc-footer {
    margin-bottom: 8px;
}

.local-aisgk-topbar,
.local-aisgk-scan-form,
.local-aisgk-toc-footer {
    display: flex;
    gap: 8px;
    align-items: end;
    flex-wrap: wrap;
}

.local-aisgk-topbar .fitem,
.local-aisgk-scan-form .fitem {
    display: flex;
    flex-direction: column;
    gap: 3px;
    margin: 0;
}

.local-aisgk-topbar label,
.local-aisgk-scan-form label {
    margin: 0;
    font-size: 12px;
    line-height: 1.2;
}

.local-aisgk-topbar select,
.local-aisgk-scan-form select,
.local-aisgk-scan-form input[type="number"] {
    min-width: 108px;
    height: 32px;
}

.local-aisgk-topbar .local-aisgk-book-select {
    min-width: 320px;
}

.local-aisgk-bookinfo {
    border: 1px solid #dbe3ea;
    background: #f8fbff;
    border-radius: 6px;
    padding: 7px 10px;
    line-height: 1.35;
}

.local-aisgk-bookinfo strong {
    font-weight: 600;
}

.local-aisgk-toc-table {
    width: 100%;
    border-collapse: collapse;
    table-layout: fixed;
}

.local-aisgk-toc-table th,
.local-aisgk-toc-table td {
    border: 1px solid #e5e7eb;
    padding: 3px 4px;
    vertical-align: top;
    font-size: 12px;
}

.local-aisgk-toc-table th {
    background: #f8f9fa;
    font-weight: 600;
    white-space: nowrap;
}

.local-aisgk-toc-col-index { width: 38px; }
.local-aisgk-toc-col-sobai { width: 74px; }
.local-aisgk-toc-col-trang,
.local-aisgk-toc-col-endtrang { width: 74px; }
.local-aisgk-toc-col-tenbai { width: auto; }
.local-aisgk-toc-col-add { width: 46px; text-align: center; }
.local-aisgk-toc-col-delete { width: 58px; text-align: center; }

.local-aisgk-toc-table input[type="text"],
.local-aisgk-toc-table input[type="number"],
.local-aisgk-toc-table textarea {
    width: 100%;
    box-sizing: border-box;
    margin: 0;
    padding: 3px 5px;
    font-size: 12px;
}

.local-aisgk-toc-table input[type="text"],
.local-aisgk-toc-table input[type="number"] {
    height: 26px;
    min-height: 26px;
}

.local-aisgk-toc-table textarea {
    min-height: 38px;
    line-height: 1.25;
    resize: vertical;
    overflow-y: hidden;
}

.local-aisgk-toc-table .cell-center {
    text-align: center;
}

.local-aisgk-toc-footer .btn,
.local-aisgk-actions .btn,
.local-aisgk-topbar .btn {
    min-height: 32px;
    padding: 5px 10px;
    font-size: 13px;
}

.local-aisgk-row-add-btn {
    min-width: 28px;
    height: 26px;
    line-height: 1;
    padding: 0 8px;
}

.local-aisgk-checkall-wrap {
    display: inline-flex !important;
    align-items: center !important;
    justify-content: center;
    gap: 0 !important;
}

.local-aisgk-meta-help {
    color: #666;
    font-size: 11px;
    line-height: 1.2;
}

.local-aisgk-table-wrap {
    overflow-x: auto;
}
</style>

<script>
document.addEventListener('DOMContentLoaded', function() {
    var tbody = document.getElementById('local-aisgk-toc-body');
    var addRowBtn = document.getElementById('local-aisgk-add-row');
    var checkAll = document.getElementById('local-aisgk-delete-all');

    if (!tbody) {
        return;
    }

    function updateRowNumbers() {
        var rows = tbody.querySelectorAll('tr');
        rows.forEach(function(row, index) {
            var indexCell = row.querySelector('.local-aisgk-row-index');
            if (indexCell) {
                indexCell.textContent = String(index + 1);
            }
        });
    }

    function createRowHtml(index) {
        return '' +
            '<td class="cell-center local-aisgk-row-index">' + (index + 1) + '</td>' +
            '<td><input type="text" name="sobai[]" value="" class="form-control"></td>' +
            '<td><textarea name="tenbai[]" class="form-control" rows="2"></textarea><input type="hidden" name="rawline[]" value=""></td>' +
            '<td><input type="number" name="trang[]" value="" min="1" class="form-control"></td>' +
            '<td><input type="number" name="endtrang[]" value="" min="1" class="form-control"></td>' +
            '<td class="cell-center"><button type="button" class="btn btn-secondary local-aisgk-row-add-btn">+</button></td>' +
            '<td class="cell-center"><input type="checkbox" class="local-aisgk-delete-box" name="delete[' + index + ']" value="1"></td>';
    }

    function createRow(index) {
        var tr = document.createElement('tr');
        tr.innerHTML = createRowHtml(index);
        return tr;
    }

    function addRowAt(afterRow) {
        var index = tbody.querySelectorAll('tr').length;
        var newRow = createRow(index);

        if (afterRow && afterRow.nextSibling) {
            tbody.insertBefore(newRow, afterRow.nextSibling);
        } else if (afterRow) {
            tbody.appendChild(newRow);
        } else {
            tbody.appendChild(newRow);
        }

        updateRowNumbers();
    }

    if (addRowBtn) {
        addRowBtn.addEventListener('click', function(e) {
            e.preventDefault();
            addRowAt(null);
        });
    }

    tbody.addEventListener('click', function(e) {
        var addBtn = e.target.closest('.local-aisgk-row-add-btn');
        if (addBtn) {
            e.preventDefault();
            var row = addBtn.closest('tr');
            addRowAt(row);
            return;
        }
    });

    tbody.addEventListener('change', function(e) {
        var deleteBox = e.target.closest('.local-aisgk-delete-box');
        if (deleteBox && deleteBox.checked) {
            var row = deleteBox.closest('tr');
            if (row) {
                row.remove();
                updateRowNumbers();
            }
        }
    });

    if (checkAll) {
        checkAll.addEventListener('change', function() {
            var boxes = tbody.querySelectorAll('.local-aisgk-delete-box');
            boxes.forEach(function(box) {
                box.checked = checkAll.checked;
                if (checkAll.checked) {
                    var row = box.closest('tr');
                    if (row) {
                        row.remove();
                    }
                }
            });
            updateRowNumbers();
            checkAll.checked = false;
        });
    }

    updateRowNumbers();
});

</script>
<?php

echo html_writer::start_div('local-aisgk-modal-page local-aisgk-topic-manager');

$options = [];
foreach ($books as $item) {
    $options[$item->id] = format_string($item->name ?: $item->filename);
}

echo html_writer::start_tag('form', [
    'method' => 'get',
    'action' => new moodle_url('/local/aisgk/topic.php'),
    'class' => 'local-aisgk-topbar',
    'title' => get_string('topicmanagerdesc', 'local_aisgk')
]);
echo html_writer::empty_tag('input', ['type' => 'hidden', 'name' => 'id', 'value' => $courseid]);

echo html_writer::start_div('fitem');
echo html_writer::label(get_string('bookselect', 'local_aisgk'), 'menu-bookid');
echo html_writer::select($options, 'bookid', $bookid, false, ['id' => 'menu-bookid', 'class' => 'local-aisgk-book-select']);
echo html_writer::end_div();

echo html_writer::start_div('fitem');
echo html_writer::label('&nbsp;', 'local-aisgk-view-book', false, ['class' => 'accesshide']);
echo html_writer::empty_tag('input', [
    'type' => 'submit',
    'id' => 'local-aisgk-view-book',
    'value' => get_string('viewchange', 'local_aisgk'),
    'class' => 'btn btn-secondary'
]);
echo html_writer::end_div();

echo html_writer::end_tag('form');

echo html_writer::tag(
    'div',
    '<strong>' . s($book->name ?: $book->filename) . '</strong> · ' .
    get_string('tocpageslabel', 'local_aisgk') . ': ' . (int)$book->tocfrompage . ' - ' . (int)$book->toctopage,
    ['class' => 'local-aisgk-bookinfo']
);

if ($scanmessage !== '') {
    echo $OUTPUT->notification($scanmessage, \core\output\notification::NOTIFY_SUCCESS);
}
if ($scanerror !== '') {
    echo $OUTPUT->notification($scanerror, \core\output\notification::NOTIFY_ERROR);
}

echo html_writer::start_div('local-aisgk-actions');

echo html_writer::start_tag('form', [
    'method' => 'post',
    'action' => new moodle_url('/local/aisgk/topic.php', ['id' => $courseid, 'bookid' => $bookid, 'action' => 'scan']),
    'class' => 'local-aisgk-inline-form local-aisgk-scan-form'
]);
echo html_writer::empty_tag('input', ['type' => 'hidden', 'name' => 'sesskey', 'value' => sesskey()]);

echo html_writer::start_div('fitem');
echo html_writer::label('OCR layout', 'id_columns');
echo html_writer::select([1 => '1 cột', 2 => '2 cột'], 'columns', $columns, false, ['id' => 'id_columns']);
echo html_writer::end_div();

echo html_writer::start_div('fitem');
echo html_writer::label('PSM', 'id_psm');
echo html_writer::select(
    [
        3 => '3 - Auto',
        4 => '4 - Single column',
        6 => '6 - Block text',
        7 => '7 - Single line',
        11 => '11 - Sparse text',
    ],
    'psm',
    $psm ?? 3,
    false,
    [
        'id' => 'id_psm',
        'class' => 'form-control',
        'title' => 'Khuyên dùng PSM 6 cho mục lục SGK.'
    ]
);
echo html_writer::end_div();

echo html_writer::start_div('fitem');
echo html_writer::label('&nbsp;', 'local-aisgk-scan-submit', false, ['class' => 'accesshide']);
echo html_writer::empty_tag('input', [
    'type' => 'submit',
    'id' => 'local-aisgk-scan-submit',
    'value' => get_string('scantoc', 'local_aisgk'),
    'class' => 'btn btn-secondary'
]);
echo html_writer::end_div();

echo html_writer::end_tag('form');

echo html_writer::end_div();

echo html_writer::start_tag('form', [
    'method' => 'post',
    'action' => new moodle_url('/local/aisgk/topic.php', ['id' => $courseid, 'bookid' => $bookid, 'action' => 'save'])
]);
echo html_writer::empty_tag('input', ['type' => 'hidden', 'name' => 'sesskey', 'value' => sesskey()]);

echo html_writer::start_div('local-aisgk-table-wrap');
echo html_writer::start_tag('table', ['class' => 'generaltable local-aisgk-toc-table local-aisgk-toc-editor']);
echo html_writer::start_tag('thead');
echo html_writer::tag(
    'tr',
    html_writer::tag('th', '#', ['class' => 'local-aisgk-toc-col-index']) .
    html_writer::tag('th', get_string('sobai', 'local_aisgk'), ['class' => 'local-aisgk-toc-col-sobai']) .
    html_writer::tag('th', get_string('tenbai', 'local_aisgk'), ['class' => 'local-aisgk-toc-col-tenbai']) .
    html_writer::tag('th', get_string('trangbatdau', 'local_aisgk'), ['class' => 'local-aisgk-toc-col-trang']) .
    html_writer::tag('th', get_string('trangketthuc', 'local_aisgk'), ['class' => 'local-aisgk-toc-col-endtrang']) .
    html_writer::tag('th', '+', ['class' => 'local-aisgk-toc-col-add']) .
    html_writer::tag(
    'th',
    html_writer::tag('label',
        html_writer::empty_tag('input', [
            'type' => 'checkbox',
            'id' => 'local-aisgk-delete-all',
        ]),
        ['class' => 'local-aisgk-checkall-wrap', 'title' => 'Delete all visible rows']
    ),
    ['class' => 'local-aisgk-toc-col-delete']
   )

);
echo html_writer::end_tag('thead');

echo html_writer::start_tag('tbody', ['id' => 'local-aisgk-toc-body']);

foreach ($tocrows as $index => $row) {
    $i = (int)$index;

    echo html_writer::start_tag('tr');
    
    echo html_writer::tag('td', (string)($i + 1), ['class' => 'cell-center local-aisgk-row-index']);

    echo html_writer::tag('td',
        html_writer::empty_tag('input', [
            'type' => 'text',
            'name' => 'sobai[]',
            'value' => ((string)($row->sobai ?? '') === '0' ? '' : s((string)($row->sobai ?? ''))),
            'class' => 'form-control'
        ])
    );

    echo html_writer::tag('td',
        html_writer::tag('textarea',
            s((string)($row->tenbai ?? '')),
            [
                'name' => 'tenbai[]',
                'class' => 'form-control',
                'rows' => 2
            ]
        ) .
        html_writer::empty_tag('input', [
            'type' => 'hidden',
            'name' => 'rawline[]',
            'value' => s((string)($row->rawline ?? ''))
        ])
    );

    echo html_writer::tag('td',
        html_writer::empty_tag('input', [
            'type' => 'number',
            'name' => 'trang[]',
            'value' => s((string)($row->trang ?? '')),
            'class' => 'form-control',
            'min' => 1
        ])
    );

    echo html_writer::tag('td',
        html_writer::empty_tag('input', [
            'type' => 'number',
            'name' => 'endtrang[]',
            'value' => s((string)($row->endtrang ?? '')),
            'class' => 'form-control',
            'min' => 1
        ])
    );
    
    echo html_writer::tag('td',
    html_writer::tag('button', '+', [
        'type' => 'button',
        'class' => 'btn btn-secondary local-aisgk-row-add-btn'
     ]),
     ['class' => 'cell-center']
    );

    echo html_writer::tag('td',
    html_writer::empty_tag('input', [
        'type' => 'checkbox',
        'name' => 'delete[' . $i . ']',
        'value' => 1,
        'class' => 'local-aisgk-delete-box'
    ]),
    ['class' => 'cell-center']
   ); 

    echo html_writer::end_tag('tr');
}

echo html_writer::end_tag('tbody');
echo html_writer::end_tag('table');
echo html_writer::end_div();

echo html_writer::tag('p', get_string('endtrangautohelp', 'local_aisgk'), ['class' => 'text-muted mt-2']);

echo html_writer::start_div('local-aisgk-toc-footer');
echo html_writer::tag('button', '+ Row', [
    'type' => 'button',
    'id' => 'local-aisgk-add-row',
    'class' => 'btn btn-secondary'
]);
echo html_writer::empty_tag('input', [
    'type' => 'submit',
    'value' => get_string('savechanges', 'local_aisgk'),
    'class' => 'btn btn-primary'
]);
echo html_writer::link(
    new moodle_url('/local/aisgk/topic.php', ['id' => $courseid, 'bookid' => $bookid]),
    get_string('reloadtoc', 'local_aisgk'),
    ['class' => 'btn btn-secondary']
);
echo html_writer::end_div();

echo html_writer::end_tag('form');
echo html_writer::end_div();

echo $OUTPUT->footer();
