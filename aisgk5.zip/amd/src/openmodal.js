import ModalFactory from 'core/modal_factory';

export const open = async(config) => {
    const title = config.title || '';
    const url = config.url || '';
    const height = config.height || 420;

    const iframeHtml = `
        <iframe
            src="${url}"
            style="width:100%; height:${height}px; border:0;"
            title="${title}"
        ></iframe>
    `;

    const modal = await ModalFactory.create({
        title: title,
        body: iframeHtml,
        large: true,
    });

    modal.show();
};
