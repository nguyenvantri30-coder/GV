export const init = (config) => {
    const selectors = [
        '#page-header .page-header-headings h1',
        '.page-header-headings h1',
        '.page-context-header h1',
        'header#page-header h1',
    ];

    let titleNode = null;
    for (const selector of selectors) {
        titleNode = document.querySelector(selector);
        if (titleNode) break;
    }

    if (!titleNode) return;

    if (document.querySelector('.local-aisgk-course-actions')) return;

    const wrap = document.createElement('span');
    wrap.className = 'local-aisgk-course-actions ms-3';

    // Tải SGK
    if (config.canmanagebook) {
        const uploadBtn = document.createElement('button');
        uploadBtn.type = 'button';
        uploadBtn.className = 'btn btn-sm btn-primary';
        uploadBtn.textContent = config.uploadlabel;

        uploadBtn.addEventListener('click', (e) => {
            e.preventDefault();
            require(['local_aisgk/openmodal', 'core/str'], function(modal, Str) {
                Str.get_string('uploadbookmodaltitle', 'local_aisgk').then(function(title) {
                    modal.open({
                        title: title,
                        url: config.uploadurl,
                        height: 360
                    });
                });
            });
        });

        wrap.appendChild(uploadBtn);
    }

    // Tạo Chủ đề
    if (config.cancreatetopic) {
        const topicBtn = document.createElement('button');
        topicBtn.type = 'button';
        topicBtn.className = 'btn btn-sm btn-secondary';
        topicBtn.textContent = config.topiclabel;

        topicBtn.addEventListener('click', (e) => {
            e.preventDefault();
            require(['local_aisgk/openmodal', 'core/str'], function(modal, Str) {
                Str.get_string('createtopicmodaltitle', 'local_aisgk').then(function(title) {
                    modal.open({
                        title: title,
                        url: config.topicurl,
                        height: 520
                    });
                });
            });
        });

        wrap.appendChild(topicBtn);
    }

    titleNode.appendChild(wrap);
};
