<?php
require_once(__DIR__ . '/../../config.php');

$courseid = required_param('id', PARAM_INT);

require_login($courseid);

$context = context_course::instance($courseid);
require_capability('local/aisgk:createtopic', $context);

$PAGE->set_url(new moodle_url('/local/aisgk/test_preview.php', ['id' => $courseid]));
$PAGE->set_context($context);
$PAGE->set_pagelayout('embedded');

echo $OUTPUT->header();
echo html_writer::tag('h3', 'Preview MỤC LỤC → dòng chứa Bài');

try {
    //$result = \local_aisgk\local\sgk_processor::preview_topic_lines($courseid);
    $result = \local_aisgk\local\sgk_processor::preview_topic_items($courseid);
     
   // echo html_writer::tag('h4', 'Content lines sau MỤC LỤC');
    //echo html_writer::tag('pre', s(implode("\n", $result['content_lines'] ?? []))); 

    if (!empty($result['items'])) {
    echo html_writer::start_tag('table', ['class' => 'generaltable']);
    echo html_writer::start_tag('thead');
    echo html_writer::tag('tr',
        html_writer::tag('th', 'Số bài') .
        html_writer::tag('th', 'Tên bài') .
        html_writer::tag('th', 'Trang') .
        html_writer::tag('th', 'Raw')
    );
    echo html_writer::end_tag('thead');

    echo html_writer::start_tag('tbody');
    foreach ($result['items'] as $item) {
        echo html_writer::tag('tr',
            html_writer::tag('td', s((string)$item['sobai'])) .
            html_writer::tag('td', s($item['tenbai'])) .
            html_writer::tag('td', s((string)$item['trang'])) .
            html_writer::tag('td', s($item['raw']))
        );
    }
    echo html_writer::end_tag('tbody');
    echo html_writer::end_tag('table');
} else {
    echo html_writer::div('Không parse được dòng Bài nào.', 'alert alert-warning');
}
   
    //echo html_writer::tag('h4', 'Raw OCR');
    //echo html_writer::tag('pre', s($result['raw']));
} catch (Throwable $e) {
    echo html_writer::div('Lỗi: ' . s($e->getMessage()), 'alert alert-danger');
}

echo $OUTPUT->footer();
