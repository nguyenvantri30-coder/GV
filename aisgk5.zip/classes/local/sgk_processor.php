<?php
namespace local_aisgk\local;

defined('MOODLE_INTERNAL') || die();

use local_aisgk\book_repository;

class sgk_processor {
    const COMPONENT = 'local_aisgk';
    const FILEAREA = 'bookpdf';

    protected static function debug_log($label, $data): void {
        $file = '/var/www/html/moodle/local/aisgk/ocr_debug.log';
        $out = "===== " . $label . " =====\n";

        if (is_array($data)) {
            foreach ($data as $k => $v) {
                if (is_array($v)) {
                    $out .= $k . ': ' . json_encode($v, JSON_UNESCAPED_UNICODE) . "\n";
                } else {
                    $out .= $v . "\n";
                }
            }
        } else {
            $out .= $data . "\n";
        }

        $out .= "\n";
        file_put_contents($file, $out, FILE_APPEND);
    }

    protected static function get_context_for_book(int $courseid): \context_course {
        return \context_course::instance($courseid);
    }

    protected static function get_book_record(int $bookid): \stdClass {
        $book = book_repository::get_by_id($bookid);
        if (!$book) {
            throw new \moodle_exception('invalidparameter');
        }
        return $book;
    }

    protected static function get_book_file(int $bookid): \stored_file {
        $book = self::get_book_record($bookid);
        $context = self::get_context_for_book((int)$book->courseid);
        $fs = get_file_storage();
        $files = $fs->get_area_files(
            $context->id,
            self::COMPONENT,
            self::FILEAREA,
            (int)$book->fileitemid,
            'itemid, filepath, filename',
            false
        );

        foreach ($files as $file) {
            if (!$file->is_directory()) {
                return $file;
            }
        }

        throw new \moodle_exception('bookrequired', 'local_aisgk');
    }

    public static function get_temp_dir(int $courseid, int $bookid): string {
        global $CFG;
        $dir = $CFG->dataroot . '/local_aisgk/tmp/' . $courseid . '/' . $bookid;
        if (!is_dir($dir)) {
            mkdir($dir, $CFG->directorypermissions, true);
        }
        return $dir;
    }

    public static function clear_temp_dir(int $courseid, int $bookid): void {
        $dir = self::get_temp_dir($courseid, $bookid);
        foreach (['*.png', '*.txt', '*.pdf', '*.log'] as $pattern) {
            foreach (glob($dir . '/' . $pattern) ?: [] as $file) {
                @unlink($file);
            }
        }
    }

    protected static function export_pdf_to_temp(int $bookid): string {
        $book = self::get_book_record($bookid);
        $storedfile = self::get_book_file($bookid);
        $dir = self::get_temp_dir((int)$book->courseid, $bookid);
        $pdfpath = $dir . '/book_' . $bookid . '.pdf';
        if (file_exists($pdfpath)) {
            @unlink($pdfpath);
        }
        $storedfile->copy_content_to($pdfpath);
        if (!file_exists($pdfpath) || filesize($pdfpath) <= 0) {
            throw new \moodle_exception('errorprocessingbook', 'local_aisgk');
        }
        return $pdfpath;
    }

    public static function get_mucluc(int $bookid, int $tutrang, int $dentrang, int $donet = 200): array {
        $book = self::get_book_record($bookid);
        if ($tutrang <= 0 || $dentrang <= 0 || $tutrang > $dentrang) {
            throw new \invalid_parameter_exception('Khoảng trang không hợp lệ');
        }

        $donet = max(72, min(250, $donet));
        self::clear_temp_dir((int)$book->courseid, $bookid);
        $pdfpath = self::export_pdf_to_temp($bookid);
        $dir = self::get_temp_dir((int)$book->courseid, $bookid);

        $index = 1;
        for ($page = $tutrang; $page <= $dentrang; $page++, $index++) {
            $out = $dir . '/' . $bookid . '_' . $index . '.png';
            $tmpdir = escapeshellarg($dir);
            $cmd = sprintf(
                'TMPDIR=%s TEMP=%s TMP=%s /usr/bin/gs -dSAFER -dBATCH -dNOPAUSE -sDEVICE=pnggray -r%d -dFirstPage=%d -dLastPage=%d -sOutputFile=%s %s 2>&1',
                $tmpdir,
                $tmpdir,
                $tmpdir,
                $donet,
                $page,
                $page,
                escapeshellarg($out),
                escapeshellarg($pdfpath)
            );
            exec($cmd, $output, $returnvar);
            if ($returnvar !== 0 || !file_exists($out)) {
                throw new \moodle_exception('errorprocessingbook', 'local_aisgk', '', null, implode("\n", $output));
            }
        }

        return self::get_source_images((int)$book->courseid, $bookid);
    }

    protected static function preprocess_image_for_ocr(string $imagepath): string {
        $outpath = preg_replace('/\.png$/i', '_prep.png', $imagepath);
        $cmd = sprintf(
            '/usr/bin/convert %s -colorspace Gray -auto-level -sharpen 0x0.8 -deskew 40%% %s 2>&1',
            escapeshellarg($imagepath),
            escapeshellarg($outpath)
        );
        exec($cmd, $output, $returnvar);
        if ($returnvar !== 0 || !file_exists($outpath)) {
            throw new \moodle_exception('errorprocessingbook', 'local_aisgk', '', null, implode("\n", $output));
        }
        return $outpath;
    }

    protected static function ocr_one_tesseract(string $imagepath, string $lang = 'vie', int $psm = 3): string {
        $txtbase = preg_replace('/\.png$/i', '', $imagepath);
        $psm = max(3, min(13, (int)$psm));
        $cmd = sprintf(
            '/usr/bin/tesseract %s %s -l %s --psm %d -c preserve_interword_spaces=1 2>&1',
            escapeshellarg($imagepath),
            escapeshellarg($txtbase),
            escapeshellarg('vie+eng'),
            $psm
        );
        exec($cmd, $output, $returnvar);
        if ($returnvar !== 0) {
            throw new \moodle_exception('errorprocessingbook', 'local_aisgk', '', null, implode("\n", $output));
        }
        $txtfile = $txtbase . '.txt';
        return file_exists($txtfile) ? trim((string)file_get_contents($txtfile)) : '';
    }

    protected static function count_nonempty_lines(string $text): int {
        $count = 0;
        foreach (preg_split('/\R/u', $text) as $line) {
            if (trim((string)$line) !== '') {
                $count++;
            }
        }
        return $count;
    }

    public static function ocr_img(int $bookid, string $engine_default = 'tesseract', int $columns = 1, int $splitpercent = 50, int $psm = 3): array {
        $book = self::get_book_record($bookid);
        $images = self::get_source_images((int)$book->courseid, $bookid);
        if (empty($images)) {
            throw new \moodle_exception('bookimagesmissing', 'local_aisgk');
        }

        $results = [];
        foreach ($images as $img) {
            $text = self::ocr_one_image($img, $columns, $splitpercent, 'vie', $psm);
            $linecount = self::count_nonempty_lines($text);
            if ($linecount < 2) {
                $prep = self::preprocess_image_for_ocr($img);
                $preptext = self::ocr_one_image($prep, $columns, $splitpercent, 'vie', $psm);
                if (self::count_nonempty_lines($preptext) >= $linecount) {
                    $text = $preptext;
                }
            }
            $results[] = [
                'file' => basename($img),
                'path' => $img,
                'text' => $text,
            ];
        }

        return [
            'engine' => 'tesseract',
            'files' => $results,
            'joined' => implode("\n\n", array_column($results, 'text')),
        ];
    }

    public static function orc_img(int $bookid, string $engine_default = 'tesseract', int $columns = 1, int $splitpercent = 50, int $psm = 3): array {
        return self::ocr_img($bookid, $engine_default, $columns, $splitpercent, $psm);
    }

    public static function preview_topic_lines(int $bookid, int $tutrang = 4, int $dentrang = 5, int $columns = 1, int $splitpercent = 50, int $psm = 3): array {
        self::get_mucluc($bookid, $tutrang, $dentrang, 200);
        $ocr = self::ocr_img($bookid, 'tesseract', $columns, $splitpercent, $psm);
        $raw = $ocr['joined'];
        self::debug_log('RAW OCR', $raw);

        $normalized = preg_replace("/\r\n|\r/u", "\n", $raw);
        $lines = explode("\n", $normalized);
        self::debug_log('LINES (RAW SPLIT)', $lines);

        $lines = self::merge_wrapped_lines($lines);
        self::debug_log('LINES (AFTER MERGE)', $lines);

        $contentlines = array_values(array_filter(array_map('trim', $lines)));

        return [
            'raw' => $raw,
            'content_lines' => $contentlines,
            'matched_lines' => $contentlines,
            'preview' => implode("\n", $contentlines),
        ];
    }

    private static function merge_wrapped_lines(array $lines): array {
        $merged = [];
        $buffer = '';

        foreach ($lines as $line) {
            $line = trim((string)$line);
            $line = preg_replace('/\s+/u', ' ', $line);

            if ($line === '') {
                continue;
            }

            if (preg_match('/^(MỤC LỤC|Má»¤C Lá»¤C|Trang|TRANG)$/iu', $line)
                || preg_match('/^[=\-\._\s]+$/u', $line)) {
                continue;
            }

            $startswithupper = (bool)preg_match('/^\p{Lu}/u', $line);

            if ($buffer === '') {
                $buffer = $line;
                continue;
            }

            if ($startswithupper) {
                $merged[] = trim($buffer);
                $buffer = $line;
                continue;
            }

            $buffer .= ' ' . $line;
            $buffer = trim(preg_replace('/\s+/u', ' ', $buffer));
        }

        if ($buffer !== '') {
            $merged[] = trim($buffer);
        }

        return $merged;
    }

    public static function parse_bai_lines(array $lines): array {
        $items = [];

        foreach ($lines as $line) {
            $line = trim((string)$line);
            if ($line === '') {
                continue;
            }

            $line = preg_replace('/\s+/u', ' ', $line);
            $line = preg_replace('/[.…]{2,}/u', ' ', $line);

            if (preg_match('/^(MỤC LỤC|Má»¤C Lá»¤C|Trang|TRANG)$/iu', $line)
                || preg_match('/^[=\-\._\s]+$/u', $line)) {
                continue;
            }

            $lessonno = null;
            $lessontitle = $line;
            $startpage = null;

            if (preg_match('/^(.*?)(?:\s+(\d{1,4}))\s*$/u', $line, $m)) {
                $lessontitle = trim((string)$m[1]);
                $startpage = (int)$m[2];
            } else {
                $lessontitle = preg_replace('/\s+[[:alpha:]]{1,4}\s*$/u', '', $lessontitle);
                $lessontitle = trim((string)$lessontitle);
            }

            if (preg_match('/^(?:Bài|BÃ\s*i)\s+(\d+)\b/ui', $lessontitle, $m)) {
                $lessonno = (int)$m[1];
                $lessontitle = preg_replace('/^(?:Bài|BÃ\s*i)\s+\d+\s*[\.:\-]?\s*/ui', '', $lessontitle);
                $lessontitle = trim((string)$lessontitle);
            }

            $items[] = [
                'lessonno' => $lessonno,
                'lessontitle' => $lessontitle,
                'startpage' => $startpage,
                'endpage' => null,
                'rawocr' => $line,
            ];
        }

        $count = count($items);
        for ($i = 0; $i < $count; $i++) {
            $nextpage = null;
            for ($j = $i + 1; $j < $count; $j++) {
                if ($items[$j]['startpage'] !== null) {
                    $nextpage = (int)$items[$j]['startpage'];
                    break;
                }
            }

            if ($items[$i]['startpage'] !== null && $nextpage !== null && $nextpage > $items[$i]['startpage']) {
                $items[$i]['endpage'] = $nextpage - 1;
            }
        }

        return $items;
    }

    public static function preview_topic_items(int $bookid, int $columns = 1, int $splitpercent = 50, int $psm = 3): array {
        $book = self::get_book_record($bookid);
        $preview = self::preview_topic_lines($bookid, (int)$book->tocfrompage, (int)$book->toctopage, $columns, $splitpercent, $psm);
        $items = self::parse_bai_lines($preview['content_lines']);

        return [
            'raw' => $preview['raw'],
            'content_lines' => $preview['content_lines'],
            'matched_lines' => $preview['matched_lines'],
            'items' => $items,
        ];
    }

    protected static function get_source_images(int $courseid, int $bookid): array {
        $dir = self::get_temp_dir($courseid, $bookid);
        $allfiles = glob($dir . '/' . $bookid . '_*.png') ?: [];
        $images = array_values(array_filter($allfiles, function($file) use ($bookid) {
            return preg_match('/\/' . preg_quote((string)$bookid, '/') . '_\d+\.png$/', $file);
        }));
        natsort($images);
        return array_values($images);
    }

    protected static function normalize_column_options(int $columns, int $splitpercent): array {
        $columns = ($columns === 2) ? 2 : 1;
        $splitpercent = max(20, min(80, $splitpercent));
        return [$columns, $splitpercent];
    }

    protected static function get_image_dimensions(string $imagepath): array {
        $cmd = sprintf(
            '/usr/bin/identify -format %s %s 2>&1',
            escapeshellarg('%w %h'),
            escapeshellarg($imagepath)
        );
        exec($cmd, $output, $returnvar);
        if ($returnvar !== 0 || empty($output[0])) {
            throw new \moodle_exception('errorprocessingbook', 'local_aisgk', '', null, implode("\n", $output));
        }

        $parts = preg_split('/\s+/', trim((string)$output[0]));
        $width = isset($parts[0]) ? (int)$parts[0] : 0;
        $height = isset($parts[1]) ? (int)$parts[1] : 0;
        if ($width <= 0 || $height <= 0) {
            throw new \moodle_exception('errorprocessingbook', 'local_aisgk', '', null, 'Invalid image size: ' . $imagepath);
        }
        return [$width, $height];
    }

    protected static function crop_image(string $src, string $dest, int $width, int $height, int $x, int $y = 0): void {
        $cmd = sprintf(
            '/usr/bin/convert %s -crop %s +repage %s 2>&1',
            escapeshellarg($src),
            escapeshellarg($width . 'x' . $height . '+' . $x . '+' . $y),
            escapeshellarg($dest)
        );
        exec($cmd, $output, $returnvar);
        if ($returnvar !== 0 || !file_exists($dest) || filesize($dest) <= 0) {
            throw new \moodle_exception('errorprocessingbook', 'local_aisgk', '', null, implode("\n", $output));
        }
    }

    /**
     * Hàm 1: Lấy mật độ cột bằng ảnh thu nhỏ để tiết kiệm RAM.
     */
    protected static function lay_mat_do_rut_gon(string $path_anh, int $n = 4): array {
        $tile = (1 / $n) * 100;
        $cmd = sprintf(
            '/usr/bin/convert %s -thumbnail %d%% -colorspace Gray -scale x1! txt:-',
            escapeshellarg($path_anh),
            $tile
        );

        exec($cmd, $output);

        $matdo = [];
        foreach ($output as $line) {
            if (preg_match('/\(\s*(\d+)\s*\)/', $line, $m)) {
                $matdo[] = 255 - (int)$m[1];
            }
        }
        return $matdo;
    }

    /**
     * Hàm 2: Thuật toán tìm các "ngọn núi" theo trục ngang.
     */
    protected static function tim_cac_cum_toa_do(array $matdo, int $nguongpixel = 5, int $khoangcachnghi = 10): array {
        $caccum = [];
        $batdau = null;
        $socottrang = 0;

        foreach ($matdo as $x => $giatri) {
            if ($giatri > $nguongpixel) {
                if ($batdau === null) {
                    $batdau = $x;
                }
                $socottrang = 0;
            } else if ($batdau !== null) {
                $socottrang++;
                if ($socottrang >= $khoangcachnghi) {
                    $caccum[] = ['x1' => $batdau, 'x2' => $x - $socottrang];
                    $batdau = null;
                    $socottrang = 0;
                }
            }
        }

        if ($batdau !== null) {
            $caccum[] = ['x1' => $batdau, 'x2' => count($matdo) - 1];
        }

        return $caccum;
    }

    /**
     * Hàm 3: Xác định vùng cắt theo logic 2 "quả núi".
     * Tạm thời mới giữ lại để dùng cho layout 2 cột ở bước sau.
     */
    public static function xac_dinh_vung_cat_sieu_toc(string $path_anh, int $n = 4): array {
        $matdonho = self::lay_mat_do_rut_gon($path_anh, $n);
        $cacnuatrang = self::tim_cac_cum_toa_do($matdonho, 5, 30);

        $ketqua = [];
        foreach ($cacnuatrang as $nua) {
            $vungdulieu = array_slice($matdonho, $nua['x1'], $nua['x2'] - $nua['x1'] + 1);
            $cumcon = self::tim_cac_cum_toa_do($vungdulieu, 5, 8);

            foreach ($cumcon as $c) {
                $x1goc = ($c['x1'] + $nua['x1']) * $n;
                $x2goc = ($c['x2'] + $nua['x1']) * $n;
                $ketqua[] = [
                    'x' => max(0, $x1goc - 10),
                    'w' => ($x2goc - $x1goc) + 20,
                ];
            }
        }

        return $ketqua;
    }

    protected static function split_image_columns(string $imagepath, int $splitpercent): array {
        [$fullwidth, $fullheight] = self::get_image_dimensions($imagepath);
        $leftwidth = (int)floor($fullwidth * $splitpercent / 100);
        $rightwidth = $fullwidth - $leftwidth;

        if ($leftwidth < 1 || $rightwidth < 1) {
            return [$imagepath];
        }

        $leftbase = tempnam(sys_get_temp_dir(), 'aisgk_col_l_');
        $rightbase = tempnam(sys_get_temp_dir(), 'aisgk_col_r_');
        $leftfile = $leftbase . '.png';
        $rightfile = $rightbase . '.png';

        self::crop_image($imagepath, $leftfile, $leftwidth, $fullheight, 0, 0);
        self::crop_image($imagepath, $rightfile, $rightwidth, $fullheight, $leftwidth, 0, 0);

        @copy($leftfile, '/var/www/html/moodle/local/aisgk/left_debug.png');
        @copy($rightfile, '/var/www/html/moodle/local/aisgk/right_debug.png');

        return [$leftfile, $rightfile];
    }

    protected static function ocr_one_image(string $imagepath, int $columns = 1, int $splitpercent = 50, string $lang = 'vie', int $psm = 3): string {
        [$columns, $splitpercent] = self::normalize_column_options($columns, $splitpercent);

        if ($columns !== 2) {
            return self::ocr_one_tesseract($imagepath, $lang, $psm);
        }

        $columnimages = self::split_image_columns($imagepath, $splitpercent);
        if (count($columnimages) < 2) {
            return self::ocr_one_tesseract($imagepath, $lang, $psm);
        }

        $texts = [];
        foreach ($columnimages as $colimg) {
            try {
                $texts[] = self::ocr_one_tesseract($colimg, $lang, $psm);
            } finally {
                if ($colimg !== $imagepath && file_exists($colimg)) {
                    @unlink($colimg);
                }
            }
        }

        return trim(implode("\n", array_filter($texts, static function($text) {
            return trim((string)$text) !== '';
        })));
    }
}
