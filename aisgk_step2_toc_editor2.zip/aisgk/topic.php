<?php
require('../../config.php');

use local_aisgk\book_repository;
use local_aisgk\toc_repository;

$courseid = required_param('id', PARAM_INT);
$bookid = optional_param('bookid', 0, PARAM_INT);
$action = optional_param('action', '', PARAM_ALPHA);

$course = get_course($courseid);
require_login($course);

$context = context_course::instance($courseid);
require_capability('local/aisgk:createtopic', $context);

$PAGE->set_context($context);
$PAGE->set_url('/local/aisgk/topic.php', ['id' => $courseid, 'bookid' => $bookid]);
$PAGE->set_pagelayout('embedded');
$PAGE->set_title(get_string('createtopic', 'local_aisgk'));

$books = book_repository::get_all_by_courseid($courseid);
if (empty($books)) {
    throw new moodle_exception('bookrequired', 'local_aisgk');
}

if ($bookid <= 0) {
    $bookid = (int)reset($books)->id;
}

$book = book_repository::get_by_id($bookid);
if (!$book || (int)$book->courseid !== $courseid) {
    throw new moodle_exception('invalidparameter');
}

if ($action === 'save' && confirm_sesskey() && data_submitted()) {
    $rows = [];
    $sobais = optional_param_array('sobai', [], PARAM_RAW_TRIMMED);
    $tenbais = optional_param_array('tenbai', [], PARAM_RAW_TRIMMED);
    $trangs = optional_param_array('trang', [], PARAM_RAW_TRIMMED);
    $endtrangs = optional_param_array('endtrang', [], PARAM_RAW_TRIMMED);
    $rawlines = optional_param_array('rawline', [], PARAM_RAW_TRIMMED);

    $max = max(count($sobais), count($tenbais), count($trangs), count($endtrangs), count($rawlines));
    for ($i = 0; $i < $max; $i++) {
        $rows[] = [
            'sobai' => $sobais[$i] ?? '',
            'tenbai' => $tenbais[$i] ?? '',
            'trang' => $trangs[$i] ?? '',
            'endtrang' => $endtrangs[$i] ?? '',
            'rawline' => $rawlines[$i] ?? '',
        ];
    }
    $rows = toc_repository::calculate_end_pages($rows);
    toc_repository::replace_book_toc($bookid, $rows);
    redirect(
        new moodle_url('/local/aisgk/topic.php', ['id' => $courseid, 'bookid' => $bookid]),
        get_string('tocsaved', 'local_aisgk'),
        null,
        \core\output\notification::NOTIFY_SUCCESS
    );
}

$tocrows = toc_repository::get_by_bookid($bookid);
if (empty($tocrows)) {
    for ($i = 1; $i <= 8; $i++) {
        $tocrows[] = (object)[
            'sobai' => '',
            'tenbai' => '',
            'trang' => null,
            'endtrang' => null,
            'rawline' => '',
        ];
    }
}

echo $OUTPUT->header();

echo html_writer::start_div('local-aisgk-modal-page local-aisgk-topic-manager');
echo html_writer::tag('h4', get_string('createtopicforcourse', 'local_aisgk'));
echo html_writer::tag('p', get_string('topicmanagerdesc', 'local_aisgk'));

$options = [];
foreach ($books as $item) {
    $options[$item->id] = format_string($item->name ?: $item->filename);
}
echo html_writer::start_tag('form', ['method' => 'get', 'action' => new moodle_url('/local/aisgk/topic.php')]);
echo html_writer::empty_tag('input', ['type' => 'hidden', 'name' => 'id', 'value' => $courseid]);
echo html_writer::label(get_string('bookselect', 'local_aisgk'), 'menu-bookid');
echo html_writer::select($options, 'bookid', $bookid, false, ['id' => 'menu-bookid']);
echo html_writer::empty_tag('input', ['type' => 'submit', 'value' => get_string('viewchange', 'local_aisgk'), 'class' => 'btn btn-secondary ml-2']);
echo html_writer::end_tag('form');

echo html_writer::tag('div',
    get_string('booklabel', 'local_aisgk') . ': <strong>' . s($book->name ?: $book->filename) . '</strong><br>' .
    get_string('tocpageslabel', 'local_aisgk') . ': ' . (int)$book->tocfrompage . ' - ' . (int)$book->toctopage,
    ['class' => 'alert alert-info mt-3']
);

echo html_writer::start_tag('form', ['method' => 'post', 'action' => new moodle_url('/local/aisgk/topic.php', ['id' => $courseid, 'bookid' => $bookid, 'action' => 'save'])]);
echo html_writer::empty_tag('input', ['type' => 'hidden', 'name' => 'sesskey', 'value' => sesskey()]);

echo html_writer::start_tag('table', ['class' => 'generaltable local-aisgk-toc-table']);
echo html_writer::start_tag('thead');
echo html_writer::tag('tr',
    html_writer::tag('th', '#') .
    html_writer::tag('th', get_string('sobai', 'local_aisgk')) .
    html_writer::tag('th', get_string('tenbai', 'local_aisgk')) .
    html_writer::tag('th', get_string('trangbatdau', 'local_aisgk')) .
    html_writer::tag('th', get_string('trangketthuc', 'local_aisgk')) .
    html_writer::tag('th', get_string('rawline', 'local_aisgk'))
);
echo html_writer::end_tag('thead');
echo html_writer::start_tag('tbody');

foreach ($tocrows as $index => $row) {
    $i = (int)$index;
    echo html_writer::start_tag('tr');
    echo html_writer::tag('td', (string)($i + 1));
    echo html_writer::tag('td', html_writer::empty_tag('input', [
        'type' => 'text', 'name' => 'sobai[]', 'value' => s((string)($row->sobai ?? '')), 'class' => 'form-control'
    ]));
    echo html_writer::tag('td', html_writer::empty_tag('input', [
        'type' => 'text', 'name' => 'tenbai[]', 'value' => s((string)($row->tenbai ?? '')), 'class' => 'form-control'
    ]));
    echo html_writer::tag('td', html_writer::empty_tag('input', [
        'type' => 'number', 'name' => 'trang[]', 'value' => s((string)($row->trang ?? '')), 'class' => 'form-control', 'min' => 1
    ]));
    echo html_writer::tag('td', html_writer::empty_tag('input', [
        'type' => 'number', 'name' => 'endtrang[]', 'value' => s((string)($row->endtrang ?? '')), 'class' => 'form-control', 'min' => 1
    ]));
    echo html_writer::tag('td', html_writer::empty_tag('input', [
        'type' => 'text', 'name' => 'rawline[]', 'value' => s((string)($row->rawline ?? '')), 'class' => 'form-control'
    ]));
    echo html_writer::end_tag('tr');
}

echo html_writer::end_tag('tbody');
echo html_writer::end_tag('table');

echo html_writer::tag('p', get_string('endtrangautohelp', 'local_aisgk'), ['class' => 'text-muted']);
echo html_writer::start_div('mt-3');
echo html_writer::empty_tag('input', ['type' => 'submit', 'value' => get_string('savechanges', 'local_aisgk'), 'class' => 'btn btn-primary']);
echo ' ';
echo html_writer::link(new moodle_url('/local/aisgk/topic.php', ['id' => $courseid, 'bookid' => $bookid]), get_string('reloadtoc', 'local_aisgk'), ['class' => 'btn btn-secondary']);
echo html_writer::end_div();

echo html_writer::end_tag('form');
echo html_writer::end_div();

echo $OUTPUT->footer();
