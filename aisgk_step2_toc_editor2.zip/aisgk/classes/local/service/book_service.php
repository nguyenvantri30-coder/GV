<?php
namespace local_aisgk\local\service;

defined('MOODLE_INTERNAL') || die();

use context_course;
use local_aisgk\book_repository;
use moodle_exception;

class book_service {
    public static function save_uploaded_book(int $courseid, array $uploadedfile, string $bookname = ''): int {
        $context = context_course::instance($courseid);

        if (empty($uploadedfile['name'])) {
            throw new moodle_exception('nofile', 'local_aisgk');
        }

        if ((int)$uploadedfile['error'] !== UPLOAD_ERR_OK) {
            throw new moodle_exception('uploaderror');
        }

        $filename = clean_param($uploadedfile['name'], PARAM_FILE);
        $ext = strtolower(pathinfo($filename, PATHINFO_EXTENSION));
        $mimetype = mime_content_type($uploadedfile['tmp_name']);

        if ($ext !== 'pdf' && $mimetype !== 'application/pdf') {
            throw new moodle_exception('invalidfiletype', 'local_aisgk');
        }

        $bookid = book_repository::create_book($courseid, $bookname, $filename);
        $fs = get_file_storage();
        $itemid = $bookid;

        $fileinfo = [
            'contextid' => $context->id,
            'component' => 'local_aisgk',
            'filearea'  => 'bookpdf',
            'itemid'    => $itemid,
            'filepath'  => '/',
            'filename'  => $filename,
        ];

        $fs->create_file_from_pathname($fileinfo, $uploadedfile['tmp_name']);
        book_repository::update_fileitemid($bookid, $itemid, $filename);
        return $bookid;
    }
}
