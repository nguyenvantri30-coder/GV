<?php
namespace local_aisgk\local;
defined('MOODLE_INTERNAL') || die();
class sgk_processor {
    const COMPONENT = 'local_aisgk';
    const FILEAREA  = 'bookpdf';
    /**
     * Sửa chỗ này nếu file SGK của bạn lưu theo system context.
     * Hiện tại đang ưu tiên course context.
     */
    protected static function get_context_for_book(int $courseid): \context {
        return \context_course::instance($courseid);
        // Nếu trước đây bạn lưu ở system context thì đổi thành:
        // return \context_system::instance();
    }
    protected static function get_book_record(int $courseid) {
        global $DB;
        return $DB->get_record('local_aisgk_books', ['courseid' => $courseid], '*', MUST_EXIST);
    }
    protected static function get_book_file(int $courseid): \stored_file {
        $context = self::get_context_for_book($courseid);
        $fs = get_file_storage();
        $files = $fs->get_area_files(
            $context->id,
            self::COMPONENT,
            self::FILEAREA,
            $courseid,
            'itemid, filepath, filename',
            false
        );
        if (empty($files)) {
            throw new \moodle_exception('Không tìm thấy SGK trong file storage cho courseid=' . $courseid);
        }
        foreach ($files as $file) {
            if (!$file->is_directory()) {
                return $file;
            }
        }
        throw new \moodle_exception('Có record SGK nhưng không lấy được file thật.');
    }
    public static function get_temp_dir(int $courseid): string {
        global $CFG;
        $dir = $CFG->dataroot . '/local_aisgk/tmp/' . $courseid;
        if (!is_dir($dir)) {
            mkdir($dir, $CFG->directorypermissions, true);
        }
        return $dir;
    }
    public static function clear_temp_dir(int $courseid): void {
        $dir = self::get_temp_dir($courseid);
        $patterns = [
            $dir . '/*.png',
            $dir . '/*.txt',
            $dir . '/*.pdf',
            $dir . '/*.json',
            $dir . '/*.log',
        ];
        foreach ($patterns as $pattern) {
            foreach (glob($pattern) ?: [] as $file) {
                @unlink($file);
            }
        }
    }
    protected static function export_pdf_to_temp(int $courseid): string {
        $storedfile = self::get_book_file($courseid);
        $dir = self::get_temp_dir($courseid);
        $pdfpath = $dir . '/course_' . $courseid . '.pdf';
        if (file_exists($pdfpath)) {
            @unlink($pdfpath);
        }
        $storedfile->copy_content_to($pdfpath);
        if (!file_exists($pdfpath) || filesize($pdfpath) <= 0) {
            throw new \moodle_exception('Không export được PDF SGK ra thư mục tạm.');
        }
        return $pdfpath;
    }
    /**
     * get_mucluc(id_khoahoc, tutrang, dentrang, donet)
     * - tìm SGK theo courseid
     * - trích từ tutrang -> dentrang thành PNG
     * - tên file: {courseid}_1.png, {courseid}_2.png...
     */
    public static function get_mucluc(int $courseid, int $tutrang, int $dentrang, int $donet = 200): array {
        if ($courseid <= 0) {
            throw new \invalid_parameter_exception('courseid không hợp lệ');
        }
        if ($tutrang <= 0 || $dentrang <= 0 || $tutrang > $dentrang) {
            throw new \invalid_parameter_exception('Khoảng trang không hợp lệ');
        }
        $donet = max(72, min(300, $donet));
        self::clear_temp_dir($courseid);
        $pdfpath = self::export_pdf_to_temp($courseid);
        $dir = self::get_temp_dir($courseid);
        $index = 1;
        for ($page = $tutrang; $page <= $dentrang; $page++, $index++) {
            $base = $dir . '/' . $courseid . '_' . $index;
            $tmpdir = escapeshellarg($dir);
            $cmd = sprintf(
                'TMPDIR=%s TEMP=%s TMP=%s /usr/bin/gs -dSAFER -dBATCH -dNOPAUSE -sDEVICE=pnggray -r%d -dFirstPage=%d -dLastPage=%d -sOutputFile=%s %s 2>&1',
                $tmpdir,
                $tmpdir,
                $tmpdir,
                $donet,
                $page,
                $page,
                escapeshellarg($base . '.png'),
                escapeshellarg($pdfpath)
            );
            exec($cmd, $output, $returnvar);
            if ($returnvar !== 0) {
                throw new \moodle_exception("Ghostscript lỗi ở trang {$page}: " . implode("\n", $output));
            }
            if (!file_exists($base . '.png')) {
                throw new \moodle_exception("Không sinh được ảnh PNG cho trang {$page}");
            }
        }
        return self::get_source_images($courseid);
    }
        /**
     * Tiền xử lý ảnh scan để OCR tốt hơn:
     * - grayscale
     * - auto-level
     * - tăng nét nhẹ
     * - phóng to 200%
     * - threshold thành đen trắng
     *
     * @param string $imagepath
     * @return string đường dẫn ảnh đã xử lý
     * @throws \moodle_exception
     */
        protected static function preprocess_image_for_ocr(string $imagepath): string {
            $outpath = preg_replace('/\.png$/i', '_prep.png', $imagepath);
            $cmd = sprintf(
                '/usr/bin/convert %s -colorspace Gray -auto-level -contrast-stretch 0x4%% -sharpen 0x1.0 -resize 150%% %s 2>&1',
                escapeshellarg($imagepath),
                escapeshellarg($outpath)
            );
            exec($cmd, $output, $returnvar);
            if ($returnvar !== 0 || !file_exists($outpath)) {
                throw new \moodle_exception('Lỗi tiền xử lý ảnh OCR cho ' . basename($imagepath) . ': ' . implode("\n", $output));
            }
            return $outpath;
        }
        protected static function ocr_one_tesseract(string $imagepath, string $lang = 'vie'): string {
            $prepimage = self::preprocess_image_for_ocr($imagepath);
            $txtbase = preg_replace('/\.png$/i', '', $prepimage);
            $cmd = sprintf(
                '/usr/bin/tesseract %s %s -l %s --psm 11 2>&1',
                escapeshellarg($prepimage),
                escapeshellarg($txtbase),
                escapeshellarg($lang)
            );
            exec($cmd, $output, $returnvar);
            if ($returnvar !== 0) {
                throw new \moodle_exception('Tesseract lỗi cho ' . basename($imagepath) . ': ' . implode("\n", $output));
            }
            $txtfile = $txtbase . '.txt';
            if (!file_exists($txtfile)) {
                throw new \moodle_exception('Không thấy file TXT OCR cho ' . basename($imagepath));
            }
            $text = file_get_contents($txtfile);
            return $text === false ? '' : trim($text);
        }
    /**
    ham lấy mục lục nâng cao
    */
    protected static function ocr_one_tesseract_tsv(string $imagepath, string $lang = 'vie'): array {
    //$prepimage = self::preprocess_image_for_ocr($imagepath);
        $prepimage = $imagepath;
        $tsvbase = preg_replace('/\.png$/i', '_tsv', $prepimage);
        $cmd = sprintf(
            '/usr/bin/tesseract %s %s -l %s --psm 11 tsv 2>&1',
            escapeshellarg($prepimage),
            escapeshellarg($tsvbase),
            escapeshellarg($lang)
        );
        exec($cmd, $output, $returnvar);
        if ($returnvar !== 0) {
            throw new \moodle_exception('Tesseract TSV lỗi cho ' . basename($imagepath) . ': ' . implode("\n", $output));
        }
        $tsvfile = $tsvbase . '.tsv';
        if (!file_exists($tsvfile)) {
            throw new \moodle_exception('Không thấy file TSV OCR cho ' . basename($imagepath));
        }
        $rows = file($tsvfile, FILE_IGNORE_NEW_LINES | FILE_SKIP_EMPTY_LINES);
        if ($rows === false || empty($rows)) {
            throw new \moodle_exception('Không đọc được TSV cho ' . basename($imagepath));
        }
        return $rows;
    }
    protected static function extract_lines_from_tsv(array $tsvrows): array {
        $lines = [];
        foreach ($tsvrows as $idx => $row) {
        // Bỏ header.
            if ($idx === 0 && preg_match('/^level[\t ]+page_num/i', $row)) {
                continue;
            }
            $cols = preg_split("/\t+/", $row);
        // Fallback nếu TSV bị tách bằng nhiều khoảng trắng.
            if (count($cols) < 12) {
                $cols = preg_split('/\s+/', $row, 12);
            }
            if (count($cols) < 12) {
                continue;
            }
            $level = (int)$cols[0];
            if ($level !== 5) {
            continue; // chỉ lấy word level
        }
        $blocknum = (int)$cols[2];
        $parnum   = (int)$cols[3];
        $linenum  = (int)$cols[4];
        $left     = (int)$cols[6];
        $top      = (int)$cols[7];
        $width    = (int)$cols[8];
        $height   = (int)$cols[9];
        $text     = trim((string)$cols[11]);
        if ($text === '') {
            continue;
        }
        $key = $blocknum . '_' . $parnum . '_' . $linenum;
        if (!isset($lines[$key])) {
            $lines[$key] = [
                'key' => $key,
                'text_parts' => [],
                'left' => $left,
                'top' => $top,
                'right' => $left + $width,
                'bottom' => $top + $height,
            ];
        }
        $lines[$key]['text_parts'][] = $text;
        $lines[$key]['left'] = min($lines[$key]['left'], $left);
        $lines[$key]['top'] = min($lines[$key]['top'], $top);
        $lines[$key]['right'] = max($lines[$key]['right'], $left + $width);
        $lines[$key]['bottom'] = max($lines[$key]['bottom'], $top + $height);
    }
    $result = [];
    foreach ($lines as $line) {
        $line['text'] = trim(preg_replace('/\s+/u', ' ', implode(' ', $line['text_parts'])));
        unset($line['text_parts']);
        $result[] = $line;
    }
    usort($result, function($a, $b) {
        if ($a['top'] === $b['top']) {
            return $a['left'] <=> $b['left'];
        }
        return $a['top'] <=> $b['top'];
    });
    return $result;
}
    /**
    hàm mới thêm
    */
    /**
     * Gọi pix2tex qua HTTP API nội bộ.
     * Mặc định dùng localhost:8502/predict
     *
     * Yêu cầu:
     * python -m pix2tex.api.run --port 8502 --host 127.0.0.1
     */
    protected static function ocr_one_pix2tex(string $imagepath): string {
        global $CFG;
        $apiurl = !empty($CFG->local_aisgk_pix2tex_url)
        ? $CFG->local_aisgk_pix2tex_url
        : 'http://127.0.0.1:8502/predict';
        $curl = new \curl();
        $response = $curl->post($apiurl, ['file' => new \CURLFile($imagepath)]);
        if ($response === false || $response === null || trim($response) === '') {
            throw new \moodle_exception('Pix2tex API không trả về dữ liệu cho ' . basename($imagepath));
        }
        $decoded = json_decode($response, true);
        if (is_array($decoded)) {
            if (!empty($decoded['prediction'])) {
                return trim($decoded['prediction']);
            }
            if (!empty($decoded['text'])) {
                return trim($decoded['text']);
            }
            // fallback nếu API đổi key.
            return trim(print_r($decoded, true));
        }
        return trim($response);
    }
    /**
     * ocr_img(id_khoahoc, engine_default='tesseract')
     * - lấy các ảnh PNG tương ứng theo courseid
     * - sắp xếp theo tên file
     * - OCR theo engine
     * - join kết quả đúng thứ tự
     */
    public static function ocr_img(int $courseid, string $engine_default = 'tesseract'): array {
        $images = self::get_source_images($courseid);
        if (empty($images)) {
            throw new \moodle_exception('Chưa có ảnh PNG. Hãy chạy get_mucluc trước.');
        }
        $engine = strtolower(trim($engine_default));
        if (!in_array($engine, ['tesseract', 'pix2tex'])) {
            $engine = 'tesseract';
        }
        $results = [];
        foreach ($images as $img) {
            $text = ($engine === 'pix2tex')
            ? self::ocr_one_pix2tex($img)
            : self::ocr_one_tesseract($img, 'vie');
            $results[] = [
                'file' => basename($img),
                'path' => $img,
                'text' => $text,
            ];
        }
        return [
            'engine' => $engine,
            'files' => $results,
            'joined' => implode("\n\n", array_column($results, 'text')),
        ];
    }
    /**
     * Alias để tương thích nếu bạn gọi orc_img.
     */
    public static function orc_img(int $courseid, string $engine_default = 'tesseract'): array {
        return self::ocr_img($courseid, $engine_default);
    }
    /**
     * Chức năng nút "Tạo Chủ đề":
     * - lấy 6 trang đầu
     * - OCR bằng tesseract
     * - tìm dòng sau khi gặp "MỤC LỤC"
     * - chỉ giữ các dòng có chữ "Bài"
     */
    public static function preview_topic_lines(int $courseid, int $tutrang = 4, int $dentrang = 5): array {
        self::get_mucluc($courseid, $tutrang, $dentrang, 200);
        $ocr = self::ocr_img($courseid, 'tesseract');
        $raw = $ocr['joined'];
        $normalized = preg_replace("/\r\n|\r/u", "\n", $raw);
        $lines = explode("\n", $normalized);
        $foundmucluc = false;
        $contentlines = [];
        $matched = [];
        foreach ($lines as $line) {
            $line = trim($line);
            if ($line === '') {
                continue;
            }
            $upper = mb_strtoupper($line, 'UTF-8');
            if (!$foundmucluc && mb_strpos($upper, 'MỤC LỤC') !== false) {
                $foundmucluc = true;
                continue;
            }
            if ($foundmucluc) {
                $contentlines[] = $line;
                if (preg_match('/\bBài\b/u', $line)) {
                    $matched[] = $line;
                }
            }
        }
        return [
            'raw' => $raw,
            'content_lines' => $contentlines,
            'matched_lines' => $matched,
            'preview' => implode("\n", $matched),
        ];
    }
     /**
     * Parse các dòng "Bài ..." thành cấu trúc dữ liệu.
     *
     * Kỳ vọng các dạng gần giống:
     * - Bài 1. Mở đầu 6
     * - Bài 2: Chất quanh ta 10
     * - Bài 3 Mở đầu về tế bào 15
     */
     public static function parse_bai_lines(array $lines): array {
        $items = [];
        $cleanlines = [];
        foreach ($lines as $line) {
            $line = trim(preg_replace('/\s+/u', ' ', $line));
            if ($line !== '') {
                $cleanlines[] = $line;
            }
        }
        $groups = [];
        $currentgroup = [
            'title' => null,
            'bai' => [],
            'pages' => [],
        ];
        foreach ($cleanlines as $line) {
            if (preg_match('/^\s*Chủ đề\s+\d+\b/u', $line)) {
                if (!empty($currentgroup['bai']) || !empty($currentgroup['pages']) || $currentgroup['title'] !== null) {
                    $groups[] = $currentgroup;
                }
                $currentgroup = [
                    'title' => $line,
                    'bai' => [],
                    'pages' => [],
                ];
                continue;
            }
            if (preg_match('/^\s*Bài\s+(\d+)\b/u', $line, $m)) {
                $sobai = (int)$m[1];
                $tenbai = preg_replace('/^\s*Bài\s+\d+\s*[\.\:\-]?\s*/u', '', $line);
                $tenbai = trim($tenbai, " \t\n\r\0\x0B.-:");
                $currentgroup['bai'][] = [
                    'raw' => $line,
                    'sobai' => $sobai,
                    'tenbai' => $tenbai,
                    'trang' => null,
                ];
                continue;
            }
        // Chỉ lấy dòng chỉ có số làm số trang.
            if (preg_match('/^\d{1,4}$/u', $line)) {
                $currentgroup['pages'][] = (int)$line;
                continue;
            }
        }
        if (!empty($currentgroup['bai']) || !empty($currentgroup['pages']) || $currentgroup['title'] !== null) {
            $groups[] = $currentgroup;
        }
        foreach ($groups as $group) {
            $bai = $group['bai'];
            $pages = $group['pages'];
            $bcount = count($bai);
            $pcount = count($pages);
            if ($bcount > 0 && $pcount > 0) {
                if ($bcount === $pcount) {
                    for ($i = 0; $i < $bcount; $i++) {
                        $bai[$i]['trang'] = $pages[$i];
                    }
                } else if ($pcount < $bcount) {
                // OCR mất trang đầu thì ghép từ cuối để tránh lệch dây chuyền.
                    $offset = $bcount - $pcount;
                    for ($i = 0; $i < $pcount; $i++) {
                        $bai[$offset + $i]['trang'] = $pages[$i];
                    }
                } else {
                    for ($i = 0; $i < $bcount; $i++) {
                        $bai[$i]['trang'] = $pages[$i];
                    }
                }
            }
            foreach ($bai as $item) {
                $items[] = $item;
            }
        }
    // Khử trùng lặp theo số bài.
        $dedup = [];
        foreach ($items as $item) {
            $key = (int)($item['sobai'] ?? 0);
            if ($key <= 0) {
                continue;
            }
            if (!isset($dedup[$key])) {
                $dedup[$key] = $item;
                continue;
            }
            $oldhaspage = !empty($dedup[$key]['trang']);
            $newhaspage = !empty($item['trang']);
            if (!$oldhaspage && $newhaspage) {
                $dedup[$key] = $item;
                continue;
            }
            if (($oldhaspage === $newhaspage) &&
                mb_strlen((string)$item['tenbai']) > mb_strlen((string)$dedup[$key]['tenbai'])) {
                $dedup[$key] = $item;
        }
    }
    $items = array_values($dedup);
    usort($items, function($a, $b) {
        return ((int)$a['sobai']) <=> ((int)$b['sobai']);
    });
    return $items;
}
    /**
     * Lấy preview dạng có cấu trúc cho nút Tạo Chủ đề.
     */
    public static function preview_topic_items(int $courseid): array {
        $preview = self::preview_topic_lines($courseid, 4, 5);
        $items = self::parse_bai_lines($preview['content_lines']);
        return [
            'raw' => $preview['raw'],
            'content_lines' => $preview['content_lines'],
            'matched_lines' => $preview['matched_lines'],
            'items' => $items,
        ];
    }
    protected static function get_source_images(int $courseid): array {
        $dir = self::get_temp_dir($courseid);
        $allfiles = glob($dir . '/' . $courseid . '_*.png') ?: [];
        $images = array_values(array_filter($allfiles, function($file) use ($courseid) {
            return preg_match('/\/' . preg_quote((string)$courseid, '/') . '_\d+\.png$/', $file);
        }));
        natsort($images);
        return array_values($images);
    }
}
