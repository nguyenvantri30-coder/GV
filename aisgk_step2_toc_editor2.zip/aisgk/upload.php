<?php
require('../../config.php');

use local_aisgk\form\upload_book_form;
use local_aisgk\local\service\book_service;

$courseid = required_param('id', PARAM_INT);

$course = get_course($courseid);
require_login($course);

$context = context_course::instance($courseid);
require_capability('local/aisgk:managebooks', $context);

$PAGE->set_context($context);
$PAGE->set_url('/local/aisgk/upload.php', ['id' => $courseid]);

$mform = new upload_book_form();

if ($mform->is_cancelled()) {
    redirect(new moodle_url('/course/view.php', ['id' => $courseid]));
}

if (!$data = $mform->get_data()) {
    redirect(new moodle_url('/local/aisgk/upload_form.php', ['id' => $courseid]));
}

$draftitemid = file_get_submitted_draft_itemid('bookpdf');
$usercontext = context_user::instance($USER->id);
$fs = get_file_storage();
$draftfiles = $fs->get_area_files($usercontext->id, 'user', 'draft', $draftitemid, 'id DESC', false);

if (empty($draftfiles)) {
    throw new moodle_exception('nofile', 'local_aisgk');
}

$draftfile = reset($draftfiles);
$tmppath = make_request_directory() . '/' . $draftfile->get_filename();
$draftfile->copy_content_to($tmppath);

$uploadedfile = [
    'name' => $draftfile->get_filename(),
    'tmp_name' => $tmppath,
    'error' => UPLOAD_ERR_OK,
];

book_service::save_uploaded_book($courseid, $uploadedfile, $data->bookname ?? '');

redirect(
    new moodle_url('/course/view.php', ['id' => $courseid]),
    get_string('bookuploaded', 'local_aisgk'),
    null,
    \core\output\notification::NOTIFY_SUCCESS
);
