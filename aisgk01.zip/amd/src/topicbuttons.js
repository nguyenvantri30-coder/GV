const buildUrl = (baseUrl, sectionId) => {
    const sep = baseUrl.includes('?') ? '&' : '?';
    return `${baseUrl}${sep}sectionid=${sectionId}`;
};

const openHomeworkModal = (config, sectionId) => {
    require(['local_aisgk/openmodal', 'core/str'], function(modal, Str) {
        Str.get_string('createhomeworkmodaltitle', 'local_aisgk').then(function(title) {
            modal.open({
                title: title,
                url: buildUrl(config.basehomeworkurl, sectionId),
                height: 560
            });
        }).catch(function() {
            modal.open({
                title: config.homeworktitle || config.buttonlabel,
                url: buildUrl(config.basehomeworkurl, sectionId),
                height: 560
            });
        });
    });
};

const findSectionAnchor = (sectionNode) => {
    const selectors = [
        '[data-for="sectiontitle"]',
        '[data-for="sectioninfo"]',
        '.section-item__header',
        '.sectionname',
        '.content .sectionname',
        'h3',
        'h4',
        '.section-title',
        '.course-section-header'
    ];

    for (const selector of selectors) {
        const node = sectionNode.querySelector(selector);
        if (node) {
            return node;
        }
    }

    return sectionNode.firstElementChild || sectionNode;
};

const injectButtonIntoSection = (sectionNode, config) => {
    if (!config.cancreatehw || sectionNode.querySelector('.local-aisgk-topic-homework')) {
        return;
    }

    const sectionId = sectionNode.getAttribute('data-id');
    if (!sectionId) {
        return;
    }

    const anchor = findSectionAnchor(sectionNode);
    if (!anchor) {
        return;
    }

    const wrap = document.createElement('div');
    wrap.className = 'local-aisgk-topic-homework';

    const btn = document.createElement('button');
    btn.type = 'button';
    btn.className = 'btn btn-sm btn-outline-primary';
    btn.textContent = config.buttonlabel;
    btn.addEventListener('click', function(e) {
        e.preventDefault();
        openHomeworkModal(config, sectionId);
    });
    wrap.appendChild(btn);

    const headerActions = sectionNode.querySelector('.section-actions, .actions, [data-for="section_action_menu"], .section-item__actions');
    if (headerActions && headerActions.parentNode) {
        headerActions.parentNode.insertBefore(wrap, headerActions);
        return;
    }

    if (anchor.parentNode) {
        anchor.parentNode.appendChild(wrap);
        return;
    }

    sectionNode.prepend(wrap);
};

const scanSections = (config) => {
    const selectors = [
        '[data-for="section"][data-id]',
        'li.section[data-id]',
        '.course-section[data-id]'
    ];

    for (const selector of selectors) {
        const sections = document.querySelectorAll(selector);
        if (sections.length) {
            sections.forEach(function(sectionNode) {
                injectButtonIntoSection(sectionNode, config);
            });
        }
    }
};

export const init = (config) => {
    scanSections(config);

    let retryCount = 0;
    const interval = window.setInterval(function() {
        scanSections(config);
        retryCount += 1;
        if (retryCount >= 20) {
            window.clearInterval(interval);
        }
    }, 700);

    const observer = new MutationObserver(function() {
        scanSections(config);
    });

    observer.observe(document.body, {
        childList: true,
        subtree: true,
    });
};
