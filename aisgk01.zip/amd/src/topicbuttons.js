const buildUrl = (baseUrl, sectionId) => {
    const sep = baseUrl.includes('?') ? '&' : '?';
    return `${baseUrl}${sep}sectionid=${sectionId}`;
};

const openHomeworkModal = (config, sectionId) => {
    require(['local_aisgk/openmodal', 'core/str'], function(modal, Str) {
        Str.get_string('createhomeworkmodaltitle', 'local_aisgk').then(function(title) {
            modal.open({
                title: title,
                url: buildUrl(config.basehomeworkurl, sectionId),
                height: 620,
            });
        });
    });
};

const findTitleHost = (sectionNode) => {
    const selectors = [
        '[data-for="section_title"]',
        '.sectionname.course-content-item',
        '.sectionname',
        '.content .sectionname',
        'h3',
        'h4',
    ];

    for (const selector of selectors) {
        const anchor = sectionNode.querySelector(selector);
        if (anchor) {
            return anchor;
        }
    }

    return null;
};

const injectButtonIntoSection = (sectionNode, config) => {
    if (!config.cancreatehw || sectionNode.querySelector('.local-aisgk-topic-homework')) {
        return;
    }

    const sectionId = sectionNode.getAttribute('data-id');
    if (!sectionId) {
        return;
    }

    const titleHost = findTitleHost(sectionNode);
    if (!titleHost) {
        return;
    }

    const wrap = document.createElement('span');
    wrap.className = 'local-aisgk-topic-homework';

    const btn = document.createElement('button');
    btn.type = 'button';
    btn.className = 'btn btn-sm btn-outline-primary local-aisgk-topic-btn';
    btn.textContent = config.buttonlabel;
    btn.addEventListener('click', (e) => {
        e.preventDefault();
        openHomeworkModal(config, sectionId);
    });

    wrap.appendChild(btn);

    const menu = sectionNode.querySelector('[data-region="sectionbadges"]')
        || sectionNode.querySelector('.section_action_menu')
        || sectionNode.querySelector('.actions');

    if (menu && menu.parentNode) {
        menu.parentNode.insertBefore(wrap, menu);
        return;
    }

    if (titleHost.parentNode) {
        titleHost.parentNode.appendChild(wrap);
    }
};

const scanSections = (config) => {
    document.querySelectorAll('[data-for="section"][data-id]').forEach((sectionNode) => {
        injectButtonIntoSection(sectionNode, config);
    });
};

export const init = (config) => {
    scanSections(config);

    const observer = new MutationObserver(() => {
        scanSections(config);
    });

    observer.observe(document.body, {
        childList: true,
        subtree: true,
    });
};
