const openUploadModal = (config) => {
    require(['local_aisgk/openmodal', 'core/str'], function(modal, Str) {
        Str.get_string('uploadbookmodaltitle', 'local_aisgk').then(function(title) {
            modal.open({
                title: title,
                url: config.uploadurl,
                height: 460,
            });
        });
    });
};

const openTopicModal = (config) => {
    require(['local_aisgk/openmodal', 'core/str'], function(modal, Str) {
        Str.get_string('createtopicmodaltitle', 'local_aisgk').then(function(title) {
            modal.open({
                title: title,
                url: config.topicurl,
                height: 760,
            });
        });
    });
};

const findHeaderTarget = () => {
    const selectors = [
        '#page-header .page-header-headings',
        '.page-header-headings',
        '.page-context-header',
        'header#page-header .w-100',
        'header#page-header',
    ];

    for (const selector of selectors) {
        const node = document.querySelector(selector);
        if (node) {
            return node;
        }
    }

    return null;
};

export const init = (config) => {
    const headerTarget = findHeaderTarget();
    if (!headerTarget || document.querySelector('.local-aisgk-course-actions')) {
        return;
    }

    headerTarget.classList.add('local-aisgk-header-target');

    const wrap = document.createElement('div');
    wrap.className = 'local-aisgk-course-actions';

    if (config.canmanagebook) {
        const uploadBtn = document.createElement('button');
        uploadBtn.type = 'button';
        uploadBtn.className = 'btn btn-sm btn-primary local-aisgk-btn';
        uploadBtn.textContent = config.hasbook ? config.replacelabel : config.uploadlabel;
        uploadBtn.addEventListener('click', (e) => {
            e.preventDefault();
            openUploadModal(config);
        });
        wrap.appendChild(uploadBtn);
    }

    if (config.cancreatetopic) {
        const topicBtn = document.createElement('button');
        topicBtn.type = 'button';
        topicBtn.className = 'btn btn-sm btn-outline-secondary local-aisgk-btn';
        topicBtn.textContent = config.topiclabel;
        topicBtn.addEventListener('click', (e) => {
            e.preventDefault();
            openTopicModal(config);
        });
        wrap.appendChild(topicBtn);
    }

    headerTarget.appendChild(wrap);
};
