const openModal = (titlekey, fallbacktitle, url, height) => {
    require(['local_aisgk/openmodal', 'core/str'], function(modal, Str) {
        Str.get_string(titlekey, 'local_aisgk').then(function(title) {
            modal.open({
                title: title,
                url: url,
                height: height
            });
        }).catch(function() {
            modal.open({
                title: fallbacktitle,
                url: url,
                height: height
            });
        });
    });
};

const buildButton = (label, className, onclick) => {
    const btn = document.createElement('button');
    btn.type = 'button';
    btn.className = className;
    btn.textContent = label;
    btn.addEventListener('click', onclick);
    return btn;
};

const findAnchor = () => {
    const selectors = [
        '#page-header .page-header-headings',
        '#page-header .page-context-header',
        '#page-header .d-flex.flex-wrap',
        '#page-header .d-flex',
        '#page-header',
        'header#page-header',
        '#topofscroll',
        '#region-main'
    ];

    for (const selector of selectors) {
        const node = document.querySelector(selector);
        if (node) {
            return node;
        }
    }

    return null;
};

const ensureButtons = (config) => {
    if (document.querySelector('.local-aisgk-course-actions')) {
        return;
    }

    const anchor = findAnchor();
    if (!anchor) {
        return;
    }

    const wrap = document.createElement('div');
    wrap.className = 'local-aisgk-course-actions';

    if (config.canmanagebook) {
        wrap.appendChild(buildButton(
            config.uploadlabel,
            'btn btn-sm btn-primary',
            function(e) {
                e.preventDefault();
                openModal('uploadbookmodaltitle', config.uploadtitle || config.uploadlabel, config.uploadurl, 420);
            }
        ));
    }

    if (config.cancreatetopic) {
        wrap.appendChild(buildButton(
            config.topiclabel,
            'btn btn-sm btn-secondary',
            function(e) {
                e.preventDefault();
                openModal('createtopicmodaltitle', config.topictitle || config.topiclabel, config.topicurl, 640);
            }
        ));
    }

    const titleNode = anchor.querySelector('h1');
    if (titleNode && titleNode.parentNode && !anchor.classList.contains('local-aisgk-course-actions')) {
        titleNode.parentNode.appendChild(wrap);
    } else {
        anchor.prepend(wrap);
    }
};

export const init = (config) => {
    ensureButtons(config);

    let retryCount = 0;
    const interval = window.setInterval(function() {
        ensureButtons(config);
        retryCount += 1;
        if (document.querySelector('.local-aisgk-course-actions') || retryCount >= 20) {
            window.clearInterval(interval);
        }
    }, 500);

    const observer = new MutationObserver(function() {
        ensureButtons(config);
    });

    observer.observe(document.body, {
        childList: true,
        subtree: true,
    });
};
