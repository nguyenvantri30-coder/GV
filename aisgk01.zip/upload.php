<?php
require('../../config.php');

use local_aisgk\book_repository;
use local_aisgk\local\service\book_service;

$courseid = optional_param('id', 0, PARAM_INT);
if (!$courseid) {
    throw new moodle_exception('missingcourseid', 'local_aisgk');
}
$course = get_course($courseid);
require_login($course);
$context = context_course::instance($courseid);
require_capability('local/aisgk:managebooks', $context);

$PAGE->set_context($context);
$PAGE->set_url('/local/aisgk/upload.php', ['id' => $courseid]);
$PAGE->set_pagelayout('embedded');
$PAGE->set_title(get_string('uploadbook', 'local_aisgk'));

$books = book_repository::get_all_by_courseid($courseid);
$message = '';
$messagetype = 'success';

if (data_submitted() && confirm_sesskey()) {
    try {
        if (empty($_FILES['bookpdf']) || empty($_FILES['bookpdf']['name'])) {
            throw new moodle_exception('nofile', 'local_aisgk');
        }
        if (!empty($_FILES['bookpdf']['error']) && (int)$_FILES['bookpdf']['error'] !== UPLOAD_ERR_OK) {
            throw new moodle_exception('uploaderrorserver', 'local_aisgk', '', $_FILES['bookpdf']['error']);
        }
        $bookname = trim(optional_param('bookname', '', PARAM_TEXT));
        book_service::save_uploaded_book($courseid, $_FILES['bookpdf'], $bookname);
        $books = book_repository::get_all_by_courseid($courseid);
        $message = get_string('bookuploaded', 'local_aisgk');
    } catch (Throwable $e) {
        $message = $e->getMessage();
        $messagetype = 'error';
    }
}

$bookcount = count($books);
$minfrompage = $bookcount ? (int)min(array_map(static fn($b) => (int)$b->tocfrompage, $books)) : 0;
$maxtopage = $bookcount ? (int)max(array_map(static fn($b) => (int)$b->toctopage, $books)) : 0;

echo $OUTPUT->header();
?>
<style>
.local-aisgk-upload-page {padding: 14px; background: #f8fafc;}
.local-aisgk-upload-stack {display: grid; grid-template-columns: minmax(0, 1.25fr) minmax(320px, 0.9fr); gap: 16px; align-items: start;}
.local-aisgk-panel {background: #fff; border: 1px solid #dbe3ea; border-radius: 12px; box-shadow: 0 4px 18px rgba(15, 23, 42, .04);}
.local-aisgk-panel-head {padding: 14px 16px 8px; border-bottom: 1px solid #eef2f7;}
.local-aisgk-panel-body {padding: 16px;}
.local-aisgk-title {margin: 0; font-size: 18px; font-weight: 700;}
.local-aisgk-subtitle {margin: 6px 0 0; color: #64748b; font-size: 13px;}
.local-aisgk-summary {display: grid; grid-template-columns: repeat(3, minmax(0, 1fr)); gap: 12px; margin-bottom: 16px;}
.local-aisgk-metric {padding: 12px; border: 1px solid #e2e8f0; border-radius: 10px; background: #fff;}
.local-aisgk-metric-label {display: block; color: #64748b; font-size: 12px; margin-bottom: 4px;}
.local-aisgk-metric-value {display: block; font-size: 22px; font-weight: 700; line-height: 1.2;}
.local-aisgk-upload-form .frow {margin-bottom: 14px;}
.local-aisgk-upload-form label {display: block; font-weight: 600; margin-bottom: 6px;}
.local-aisgk-upload-form input[type="text"], .local-aisgk-upload-form input[type="file"] {width: 100%; box-sizing: border-box;}
.local-aisgk-actions {display: flex; gap: 10px; align-items: center; flex-wrap: wrap;}
.local-aisgk-help-list {margin: 0; padding-left: 18px; color: #475569;}
.local-aisgk-existing table {width: 100%; border-collapse: collapse;}
.local-aisgk-existing th, .local-aisgk-existing td {border-bottom: 1px solid #e5e7eb; padding: 10px 8px; text-align: left; vertical-align: top;}
.local-aisgk-existing th {font-size: 12px; text-transform: uppercase; letter-spacing: .03em; color: #64748b; background: #f8fafc;}
.local-aisgk-book-name {font-weight: 600;}
.local-aisgk-empty {padding: 14px; border: 1px dashed #cbd5e1; border-radius: 10px; color: #64748b; background: #f8fafc;}
@media (max-width: 991.98px) {
    .local-aisgk-upload-stack {grid-template-columns: 1fr;}
}
@media (max-width: 575.98px) {
    .local-aisgk-summary {grid-template-columns: 1fr;}
}
</style>
<div class="local-aisgk-upload-page">
    <?php if ($message !== ''): ?>
        <div class="alert alert-<?php echo $messagetype === 'success' ? 'success' : 'danger'; ?> mb-3"><?php echo s($message); ?></div>
    <?php endif; ?>

    <div class="local-aisgk-summary">
        <div class="local-aisgk-metric">
            <span class="local-aisgk-metric-label"><?php echo s(get_string('booklabel', 'local_aisgk')); ?></span>
            <span class="local-aisgk-metric-value"><?php echo (int)$bookcount; ?></span>
        </div>
        <div class="local-aisgk-metric">
            <span class="local-aisgk-metric-label"><?php echo s(get_string('tocfrompage', 'local_aisgk')); ?></span>
            <span class="local-aisgk-metric-value"><?php echo $minfrompage; ?></span>
        </div>
        <div class="local-aisgk-metric">
            <span class="local-aisgk-metric-label"><?php echo s(get_string('toctopage', 'local_aisgk')); ?></span>
            <span class="local-aisgk-metric-value"><?php echo $maxtopage; ?></span>
        </div>
    </div>

    <div class="local-aisgk-upload-stack">
        <section class="local-aisgk-panel">
            <div class="local-aisgk-panel-head">
                <h3 class="local-aisgk-title"><?php echo s(get_string('uploadbook', 'local_aisgk')); ?></h3>
                <p class="local-aisgk-subtitle"><?php echo s(get_string('uploadbookhelp', 'local_aisgk')); ?></p>
            </div>
            <div class="local-aisgk-panel-body">
                <form class="local-aisgk-upload-form" method="post" enctype="multipart/form-data">
                    <input type="hidden" name="sesskey" value="<?php echo sesskey(); ?>">
                    <div class="frow">
                        <label for="id_bookname"><?php echo s(get_string('bookname', 'local_aisgk')); ?></label>
                        <input type="text" id="id_bookname" name="bookname" class="form-control" placeholder="<?php echo s(get_string('booknameplaceholder', 'local_aisgk')); ?>">
                    </div>
                    <div class="frow">
                        <label for="id_bookpdf"><?php echo s(get_string('uploadbook', 'local_aisgk')); ?></label>
                        <input type="file" id="id_bookpdf" name="bookpdf" class="form-control" accept=".pdf,application/pdf" required>
                        <div class="text-muted small mt-2"><?php echo s(get_string('uploadlimitnote', 'local_aisgk')); ?></div>
                    </div>
                    <div class="local-aisgk-actions">
                        <button type="submit" class="btn btn-primary"><?php echo s($bookcount ? get_string('replacebook', 'local_aisgk') : get_string('uploadbook', 'local_aisgk')); ?></button>
                        <span class="text-muted small"><?php echo s(get_string('bookname_help', 'local_aisgk')); ?></span>
                    </div>
                </form>
            </div>
        </section>

        <aside class="local-aisgk-panel">
            <div class="local-aisgk-panel-head">
                <h3 class="local-aisgk-title"><?php echo s(get_string('existingbooks', 'local_aisgk')); ?></h3>
                <p class="local-aisgk-subtitle"><?php echo s(get_string('uploadbookhelp', 'local_aisgk')); ?></p>
            </div>
            <div class="local-aisgk-panel-body">
                <ul class="local-aisgk-help-list">
                    <li><?php echo s(get_string('uploadlimitnote', 'local_aisgk')); ?></li>
                    <li><?php echo s(get_string('topicmanagerdesc', 'local_aisgk')); ?></li>
                </ul>
            </div>
        </aside>
    </div>

    <section class="local-aisgk-panel local-aisgk-existing mt-3">
        <div class="local-aisgk-panel-head">
            <h3 class="local-aisgk-title"><?php echo s(get_string('existingbooks', 'local_aisgk')); ?></h3>
            <p class="local-aisgk-subtitle"><?php echo s(get_string('bookselect', 'local_aisgk')); ?></p>
        </div>
        <div class="local-aisgk-panel-body">
            <?php if (!$books): ?>
                <div class="local-aisgk-empty"><?php echo s(get_string('nobooksincourse', 'local_aisgk')); ?></div>
            <?php else: ?>
                <div class="table-responsive">
                    <table>
                        <thead>
                            <tr>
                                <th>#</th>
                                <th><?php echo s(get_string('bookname', 'local_aisgk')); ?></th>
                                <th><?php echo s(get_string('filename', 'local_aisgk')); ?></th>
                                <th><?php echo s(get_string('tocfrompage', 'local_aisgk')); ?></th>
                                <th><?php echo s(get_string('toctopage', 'local_aisgk')); ?></th>
                            </tr>
                        </thead>
                        <tbody>
                        <?php foreach ($books as $idx => $book): ?>
                            <tr>
                                <td><?php echo $idx + 1; ?></td>
                                <td><div class="local-aisgk-book-name"><?php echo s($book->name ?: $book->filename); ?></div></td>
                                <td><?php echo s($book->filename); ?></td>
                                <td><?php echo (int)$book->tocfrompage; ?></td>
                                <td><?php echo (int)$book->toctopage; ?></td>
                            </tr>
                        <?php endforeach; ?>
                        </tbody>
                    </table>
                </div>
            <?php endif; ?>
        </div>
    </section>
</div>
<?php
echo $OUTPUT->footer();
