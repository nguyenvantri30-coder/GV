<?php
require('../../config.php');

use local_aisgk\book_repository;

$courseid = required_param('id', PARAM_INT);
$sectionid = optional_param('sectionid', 0, PARAM_INT);

$course = get_course($courseid);
require_login($course);

$context = context_course::instance($courseid);
require_capability('local/aisgk:createhomework', $context);

$PAGE->set_context($context);
$PAGE->set_url('/local/aisgk/homework.php', ['id' => $courseid, 'sectionid' => $sectionid]);
$PAGE->set_pagelayout('embedded');
$PAGE->set_title(get_string('createhomework', 'local_aisgk'));

if (!book_repository::course_has_book($courseid)) {
    throw new moodle_exception('bookrequired', 'local_aisgk');
}

$section = null;
if (!empty($sectionid)) {
    $modinfo = get_fast_modinfo($course);
    $sectioninfo = $modinfo->get_section_info_by_id($sectionid);
    if (!$sectioninfo) {
        throw new moodle_exception('sectionnotfound', 'local_aisgk');
    }
    $section = $sectioninfo;
}

$sectionlabel = '';
if ($section) {
    $sectionlabel = !empty($section->name) ? format_string($section->name) : (string)$section->section;
}

echo $OUTPUT->header();
?>
<style>
.local-aisgk-homework-page {padding: 14px; background: #f8fafc;}
.local-aisgk-homework-panel {background: #fff; border: 1px solid #dbe3ea; border-radius: 12px; box-shadow: 0 4px 18px rgba(15, 23, 42, .04);}
.local-aisgk-homework-head {padding: 14px 16px 10px; border-bottom: 1px solid #eef2f7;}
.local-aisgk-homework-body {padding: 16px;}
.local-aisgk-homework-title {margin: 0; font-size: 18px; font-weight: 700;}
.local-aisgk-homework-subtitle {margin: 6px 0 0; color: #64748b; font-size: 13px;}
.local-aisgk-homework-grid {display: grid; grid-template-columns: repeat(2, minmax(0, 1fr)); gap: 12px; margin-bottom: 16px;}
.local-aisgk-homework-field label {display: block; font-weight: 600; margin-bottom: 6px;}
.local-aisgk-homework-field input, .local-aisgk-homework-field textarea {width: 100%; box-sizing: border-box;}
.local-aisgk-homework-field textarea {min-height: 92px;}
.local-aisgk-homework-note {padding: 12px; border: 1px dashed #cbd5e1; border-radius: 10px; background: #f8fafc; color: #475569;}
@media (max-width: 767.98px) {
    .local-aisgk-homework-grid {grid-template-columns: 1fr;}
}
</style>
<div class="local-aisgk-homework-page">
    <section class="local-aisgk-homework-panel">
        <div class="local-aisgk-homework-head">
            <h3 class="local-aisgk-homework-title"><?php echo s(get_string('createhomeworkforsection', 'local_aisgk')); ?></h3>
            <p class="local-aisgk-homework-subtitle"><?php echo s(get_string('homeworkstubdesc', 'local_aisgk')); ?></p>
        </div>
        <div class="local-aisgk-homework-body">
            <div class="local-aisgk-homework-grid">
                <div class="local-aisgk-homework-field">
                    <label><?php echo s(get_string('section', 'local_aisgk')); ?></label>
                    <input type="text" class="form-control" value="<?php echo s($sectionlabel); ?>" disabled>
                </div>
                <div class="local-aisgk-homework-field">
                    <label>courseid / sectionid</label>
                    <input type="text" class="form-control" value="<?php echo (int)$courseid; ?> / <?php echo (int)$sectionid; ?>" disabled>
                </div>
                <div class="local-aisgk-homework-field">
                    <label>Tiêu đề BTVN</label>
                    <input type="text" class="form-control" placeholder="Giao diện đã sẵn sàng cho bước xử lý thật" disabled>
                </div>
                <div class="local-aisgk-homework-field">
                    <label>Hạn nộp</label>
                    <input type="text" class="form-control" placeholder="Sẽ nối vào logic giao bài ở bước sau" disabled>
                </div>
                <div class="local-aisgk-homework-field" style="grid-column: 1 / -1;">
                    <label>Mô tả</label>
                    <textarea class="form-control" disabled>Khung giao diện popup cho Tạo BTVN đã được làm gọn để đúng luồng thao tác trong khóa học. Phần sinh nội dung và giao bài thật sẽ nối vào sau.</textarea>
                </div>
            </div>
            <div class="local-aisgk-homework-note">Popup này hiện mới là giao diện khung theo yêu cầu cũ, chưa kích hoạt phần xử lý giao bài thực tế.</div>
        </div>
    </section>
</div>
<?php
echo $OUTPUT->footer();
