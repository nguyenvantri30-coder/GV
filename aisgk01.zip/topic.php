<?php
require('../../config.php');

use local_aisgk\book_repository;
use local_aisgk\local\service\scan_service;
use local_aisgk\toc_repository;

$courseid = required_param('id', PARAM_INT);
$bookid = optional_param('bookid', 0, PARAM_INT);
$action = optional_param('action', '', PARAM_ALPHA);
$columns = optional_param('columns', 1, PARAM_INT);
$psm = optional_param('psm', 4, PARAM_INT);
$splitpercent = optional_param('splitpercent', 50, PARAM_INT);

$course = get_course($courseid);
require_login($course);
$context = context_course::instance($courseid);
require_capability('local/aisgk:createtopic', $context);

$PAGE->set_context($context);
$PAGE->set_url('/local/aisgk/topic.php', ['id' => $courseid, 'bookid' => $bookid]);
$PAGE->set_pagelayout('embedded');
$PAGE->set_title(get_string('createtopic', 'local_aisgk'));

$books = book_repository::get_all_by_courseid($courseid);
if (!$books) {
    throw new moodle_exception('bookrequired', 'local_aisgk');
}
if ($bookid < 1) {
    $bookid = (int)reset($books)->id;
}
$book = book_repository::get_by_id($bookid);
if (!$book || (int)$book->courseid !== $courseid) {
    throw new moodle_exception('invalidparameter');
}

if ($action === 'save' && confirm_sesskey() && data_submitted()) {
    $rows = [];
    $sobais = optional_param_array('sobai', [], PARAM_RAW_TRIMMED);
    $tenbais = optional_param_array('tenbai', [], PARAM_RAW_TRIMMED);
    $trangs = optional_param_array('trang', [], PARAM_RAW_TRIMMED);
    $endtrangs = optional_param_array('endtrang', [], PARAM_RAW_TRIMMED);
    $rawlines = optional_param_array('rawline', [], PARAM_RAW_TRIMMED);
    $deletes = optional_param_array('delete', [], PARAM_INT);
    $max = max(count($sobais), count($tenbais), count($trangs), count($endtrangs), count($rawlines));

    for ($i = 0; $i < $max; $i++) {
        if (!empty($deletes[$i])) {
            continue;
        }
        $row = [
            'sobai' => $sobais[$i] ?? '',
            'tenbai' => $tenbais[$i] ?? '',
            'trang' => $trangs[$i] ?? '',
            'endtrang' => $endtrangs[$i] ?? '',
            'rawline' => $rawlines[$i] ?? '',
        ];
        if (trim(implode('', array_map('strval', $row))) === '') {
            continue;
        }
        $rows[] = $row;
    }
    $rows = toc_repository::calculate_end_pages($rows);
    toc_repository::replace_book_toc($bookid, $rows);
    redirect(
        new moodle_url('/local/aisgk/topic.php', ['id' => $courseid, 'bookid' => $bookid]),
        get_string('tocsaved', 'local_aisgk'),
        null,
        \core\output\notification::NOTIFY_SUCCESS
    );
}

if ($action === 'scan' && confirm_sesskey()) {
    scan_service::queue_toc_scan($bookid, $USER->id, $columns, $splitpercent, $psm);
    redirect(
        new moodle_url('/local/aisgk/topic.php', ['id' => $courseid, 'bookid' => $bookid]),
        get_string('tocscanqueued', 'local_aisgk'),
        null,
        \core\output\notification::NOTIFY_SUCCESS
    );
}

$tocrows = toc_repository::get_by_bookid($bookid);
if (!$tocrows) {
    for ($i = 0; $i < 8; $i++) {
        $tocrows[] = (object)['sobai' => '', 'tenbai' => '', 'trang' => '', 'endtrang' => '', 'rawline' => ''];
    }
}

$statusmap = [
    'queued' => ['alert-info', get_string('scanstatusqueued', 'local_aisgk')],
    'running' => ['alert-warning', get_string('scanstatusrunning', 'local_aisgk')],
    'done' => ['alert-success', get_string('scanstatusdone', 'local_aisgk', (int)($book->lastscanitemcount ?? 0))],
    'failed' => ['alert-danger', format_string(get_string('scanstatusfailed', 'local_aisgk', s((string)($book->scanmessage ?? ''))))],
];
[$statusclass, $statustext] = $statusmap[$book->scanstatus ?? 'idle'] ?? ['alert-secondary', get_string('scanstatusidle', 'local_aisgk')];

$booklabel = $book->name ?: $book->filename;
$scanconfig = [
    'columns' => in_array($columns, [1, 2], true) ? $columns : 1,
    'psm' => max(3, min(13, (int)$psm)),
    'splitpercent' => max(20, min(80, (int)$splitpercent)),
];

echo $OUTPUT->header();
?>
<style>
.local-aisgk-topic-page {padding: 14px; background: #f8fafc;}
.local-aisgk-shell {display: grid; grid-template-columns: minmax(0, 1fr) 300px; gap: 16px; align-items: start;}
.local-aisgk-panel {background: #fff; border: 1px solid #dbe3ea; border-radius: 12px; box-shadow: 0 4px 18px rgba(15, 23, 42, .04);}
.local-aisgk-panel-head {padding: 14px 16px 10px; border-bottom: 1px solid #eef2f7;}
.local-aisgk-panel-body {padding: 16px;}
.local-aisgk-title {margin: 0; font-size: 18px; font-weight: 700;}
.local-aisgk-subtitle {margin: 6px 0 0; color: #64748b; font-size: 13px;}
.local-aisgk-toolbar {display: flex; gap: 10px; align-items: end; flex-wrap: wrap;}
.local-aisgk-toolbar .fitem {display: flex; flex-direction: column; gap: 6px; min-width: 120px;}
.local-aisgk-toolbar label {font-size: 12px; font-weight: 600; color: #334155; margin: 0;}
.local-aisgk-toolbar input, .local-aisgk-toolbar select {width: 100%;}
.local-aisgk-kpis {display: grid; grid-template-columns: repeat(3, minmax(0, 1fr)); gap: 12px; margin-bottom: 16px;}
.local-aisgk-kpi {padding: 12px; border: 1px solid #e2e8f0; border-radius: 10px; background: #fff;}
.local-aisgk-kpi-label {display: block; color: #64748b; font-size: 12px; margin-bottom: 4px;}
.local-aisgk-kpi-value {display: block; font-size: 18px; font-weight: 700;}
.local-aisgk-status {margin-bottom: 16px;}
.local-aisgk-table-wrap {overflow: auto; max-height: 58vh; border: 1px solid #dbe3ea; border-radius: 10px; background: #fff;}
.local-aisgk-toc-table {width: 100%; min-width: 980px; border-collapse: collapse;}
.local-aisgk-toc-table th, .local-aisgk-toc-table td {border-bottom: 1px solid #e5e7eb; padding: 8px 8px; vertical-align: top; font-size: 12px;}
.local-aisgk-toc-table th {background: #f8fafc; position: sticky; top: 0; z-index: 1; text-transform: uppercase; letter-spacing: .03em; color: #64748b;}
.local-aisgk-toc-table input[type="text"], .local-aisgk-toc-table input[type="number"], .local-aisgk-toc-table textarea {width: 100%; box-sizing: border-box; font-size: 13px; padding: 6px 8px; border: 1px solid #cbd5e1; border-radius: 6px;}
.local-aisgk-toc-table textarea {min-height: 54px; resize: vertical;}
.local-aisgk-row-index {text-align: center; color: #64748b; font-weight: 600;}
.local-aisgk-delete-cell {text-align: center;}
.local-aisgk-sticky-actions {display: flex; justify-content: space-between; gap: 10px; align-items: center; flex-wrap: wrap; padding-top: 14px;}
.local-aisgk-note {margin: 0; color: #64748b; font-size: 12px;}
.local-aisgk-side-list {margin: 0; padding-left: 18px; color: #475569;}
.local-aisgk-booklist {display: grid; gap: 10px;}
.local-aisgk-bookitem {padding: 10px 12px; border: 1px solid #e2e8f0; border-radius: 10px; background: #f8fafc;}
.local-aisgk-bookitem.is-active {border-color: #2563eb; background: #eff6ff;}
.local-aisgk-bookitem-title {display: block; font-weight: 600;}
.local-aisgk-bookitem-meta {display: block; margin-top: 4px; color: #64748b; font-size: 12px;}
@media (max-width: 991.98px) {
    .local-aisgk-shell {grid-template-columns: 1fr;}
}
@media (max-width: 575.98px) {
    .local-aisgk-kpis {grid-template-columns: 1fr;}
}
</style>
<div class="local-aisgk-topic-page">
    <div class="local-aisgk-kpis">
        <div class="local-aisgk-kpi">
            <span class="local-aisgk-kpi-label"><?php echo s(get_string('booklabel', 'local_aisgk')); ?></span>
            <span class="local-aisgk-kpi-value"><?php echo s($booklabel); ?></span>
        </div>
        <div class="local-aisgk-kpi">
            <span class="local-aisgk-kpi-label"><?php echo s(get_string('tocfrompage', 'local_aisgk')); ?></span>
            <span class="local-aisgk-kpi-value"><?php echo (int)$book->tocfrompage; ?></span>
        </div>
        <div class="local-aisgk-kpi">
            <span class="local-aisgk-kpi-label"><?php echo s(get_string('toctopage', 'local_aisgk')); ?></span>
            <span class="local-aisgk-kpi-value"><?php echo (int)$book->toctopage; ?></span>
        </div>
    </div>

    <div class="alert <?php echo $statusclass; ?> local-aisgk-status"><?php echo $statustext; ?></div>

    <div class="local-aisgk-shell">
        <section class="local-aisgk-panel">
            <div class="local-aisgk-panel-head">
                <h3 class="local-aisgk-title"><?php echo s(get_string('createtopic', 'local_aisgk')); ?></h3>
                <p class="local-aisgk-subtitle"><?php echo s(get_string('topicmanagerdesc', 'local_aisgk')); ?></p>
            </div>
            <div class="local-aisgk-panel-body">
                <form method="get" action="<?php echo new moodle_url('/local/aisgk/topic.php'); ?>" class="local-aisgk-toolbar mb-3">
                    <input type="hidden" name="id" value="<?php echo (int)$courseid; ?>">
                    <div class="fitem">
                        <label for="id_bookid"><?php echo s(get_string('bookselect', 'local_aisgk')); ?></label>
                        <select id="id_bookid" name="bookid" class="custom-select">
                            <?php foreach ($books as $option): ?>
                                <option value="<?php echo (int)$option->id; ?>" <?php echo ((int)$option->id === (int)$bookid) ? 'selected' : ''; ?>><?php echo s($option->name ?: $option->filename); ?></option>
                            <?php endforeach; ?>
                        </select>
                    </div>
                    <button type="submit" class="btn btn-outline-secondary"><?php echo s(get_string('viewchange', 'local_aisgk')); ?></button>
                </form>

                <form method="post" action="<?php echo new moodle_url('/local/aisgk/topic.php', ['id' => $courseid, 'bookid' => $bookid, 'action' => 'scan']); ?>" class="local-aisgk-toolbar mb-4">
                    <input type="hidden" name="sesskey" value="<?php echo sesskey(); ?>">
                    <div class="fitem">
                        <label for="id_columns">Cột</label>
                        <select id="id_columns" name="columns" class="custom-select">
                            <option value="1" <?php echo $scanconfig['columns'] === 1 ? 'selected' : ''; ?>>1</option>
                            <option value="2" <?php echo $scanconfig['columns'] === 2 ? 'selected' : ''; ?>>2</option>
                        </select>
                    </div>
                    <div class="fitem">
                        <label for="id_psm">PSM</label>
                        <input type="number" id="id_psm" name="psm" min="3" max="13" class="form-control" value="<?php echo (int)$scanconfig['psm']; ?>">
                    </div>
                    <div class="fitem">
                        <label for="id_splitpercent">Split %</label>
                        <input type="number" id="id_splitpercent" name="splitpercent" min="20" max="80" class="form-control" value="<?php echo (int)$scanconfig['splitpercent']; ?>">
                    </div>
                    <button type="submit" class="btn btn-primary"><?php echo s(get_string('scantoc', 'local_aisgk')); ?></button>
                </form>

                <form method="post" action="<?php echo new moodle_url('/local/aisgk/topic.php', ['id' => $courseid, 'bookid' => $bookid, 'action' => 'save']); ?>">
                    <input type="hidden" name="sesskey" value="<?php echo sesskey(); ?>">
                    <div class="local-aisgk-table-wrap">
                        <table class="local-aisgk-toc-table" id="local-aisgk-toc-table">
                            <thead>
                                <tr>
                                    <th>#</th>
                                    <th><?php echo s(get_string('sobai', 'local_aisgk')); ?></th>
                                    <th><?php echo s(get_string('tenbai', 'local_aisgk')); ?></th>
                                    <th><?php echo s(get_string('trangbatdau', 'local_aisgk')); ?></th>
                                    <th><?php echo s(get_string('trangketthuc', 'local_aisgk')); ?></th>
                                    <th><?php echo s(get_string('rawline', 'local_aisgk')); ?></th>
                                    <th><?php echo s(get_string('delete', 'local_aisgk')); ?></th>
                                </tr>
                            </thead>
                            <tbody>
                            <?php foreach ($tocrows as $i => $row): ?>
                                <tr>
                                    <td class="local-aisgk-row-index"><?php echo (int)$i + 1; ?></td>
                                    <td><input type="number" name="sobai[<?php echo $i; ?>]" value="<?php echo s((string)$row->sobai); ?>"></td>
                                    <td><input type="text" name="tenbai[<?php echo $i; ?>]" value="<?php echo s((string)$row->tenbai); ?>"></td>
                                    <td><input type="number" name="trang[<?php echo $i; ?>]" value="<?php echo s((string)$row->trang); ?>"></td>
                                    <td><input type="number" name="endtrang[<?php echo $i; ?>]" value="<?php echo s((string)$row->endtrang); ?>"></td>
                                    <td><textarea name="rawline[<?php echo $i; ?>]"><?php echo s((string)$row->rawline); ?></textarea></td>
                                    <td class="local-aisgk-delete-cell"><input type="checkbox" name="delete[<?php echo $i; ?>]" value="1"></td>
                                </tr>
                            <?php endforeach; ?>
                            </tbody>
                        </table>
                    </div>
                    <div class="local-aisgk-sticky-actions">
                        <div class="d-flex gap-2 flex-wrap align-items-center">
                            <button type="button" class="btn btn-outline-secondary" id="local-aisgk-add-row"><?php echo s(get_string('addrow', 'local_aisgk')); ?></button>
                            <p class="local-aisgk-note"><?php echo s(get_string('endtrangautohelp', 'local_aisgk')); ?></p>
                        </div>
                        <button type="submit" class="btn btn-success"><?php echo s(get_string('savechanges', 'local_aisgk')); ?></button>
                    </div>
                </form>
            </div>
        </section>

        <aside class="local-aisgk-panel">
            <div class="local-aisgk-panel-head">
                <h3 class="local-aisgk-title"><?php echo s(get_string('existingbooks', 'local_aisgk')); ?></h3>
                <p class="local-aisgk-subtitle"><?php echo s(get_string('bookselect', 'local_aisgk')); ?></p>
            </div>
            <div class="local-aisgk-panel-body">
                <div class="local-aisgk-booklist">
                    <?php foreach ($books as $option): ?>
                        <div class="local-aisgk-bookitem <?php echo ((int)$option->id === (int)$bookid) ? 'is-active' : ''; ?>">
                            <span class="local-aisgk-bookitem-title"><?php echo s($option->name ?: $option->filename); ?></span>
                            <span class="local-aisgk-bookitem-meta"><?php echo s(get_string('tocfrompage', 'local_aisgk')); ?>: <?php echo (int)$option->tocfrompage; ?> · <?php echo s(get_string('toctopage', 'local_aisgk')); ?>: <?php echo (int)$option->toctopage; ?></span>
                        </div>
                    <?php endforeach; ?>
                </div>
                <hr>
                <ul class="local-aisgk-side-list">
                    <li><?php echo s(get_string('tocscanincludespecial', 'local_aisgk')); ?></li>
                    <li><?php echo s(get_string('endtrangautohelp', 'local_aisgk')); ?></li>
                </ul>
            </div>
        </aside>
    </div>
</div>
<script>
(function() {
    const table = document.getElementById('local-aisgk-toc-table');
    const addBtn = document.getElementById('local-aisgk-add-row');
    if (!table || !addBtn) {
        return;
    }
    const tbody = table.querySelector('tbody');
    const renumber = () => {
        tbody.querySelectorAll('tr').forEach((row, index) => {
            const cell = row.querySelector('.local-aisgk-row-index');
            if (cell) {
                cell.textContent = index + 1;
            }
        });
    };
    addBtn.addEventListener('click', () => {
        const index = tbody.querySelectorAll('tr').length;
        const tr = document.createElement('tr');
        tr.innerHTML = `
            <td class="local-aisgk-row-index">${index + 1}</td>
            <td><input type="number" name="sobai[${index}]" value=""></td>
            <td><input type="text" name="tenbai[${index}]" value=""></td>
            <td><input type="number" name="trang[${index}]" value=""></td>
            <td><input type="number" name="endtrang[${index}]" value=""></td>
            <td><textarea name="rawline[${index}]"></textarea></td>
            <td class="local-aisgk-delete-cell"><input type="checkbox" name="delete[${index}]" value="1"></td>`;
        tbody.appendChild(tr);
        renumber();
    });
})();
</script>
<?php
echo $OUTPUT->footer();
