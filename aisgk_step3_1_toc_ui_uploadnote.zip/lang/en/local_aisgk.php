<?php
$string['pluginname'] = 'AI SGK';
$string['uploadbook'] = 'Upload textbook';
$string['replacebook'] = 'Replace textbook';
$string['createtopic'] = 'Create topic';
$string['createhomework'] = 'Create homework';
$string['createtopichomework'] = 'Create homework';
$string['uploadbookmodaltitle'] = 'Upload textbook PDF';
$string['nofile'] = 'No file selected.';
$string['invalidfiletype'] = 'Only PDF files are allowed.';
$string['savechanges'] = 'Save';
$string['cancel'] = 'Cancel';
$string['bookuploaded'] = 'Textbook saved successfully.';
$string['bookreplaced'] = 'Textbook replaced successfully.';
$string['managebooks'] = 'Manage textbooks';
$string['viewbooks'] = 'View textbooks';
$string['createtopic_desc'] = 'Allows creating topics at course level.';
$string['createhomework_desc'] = 'Allows creating homework for each topic.';
$string['managebooks_desc'] = 'Allows uploading and replacing the course textbook.';
$string['viewbooks_desc'] = 'Allows viewing the course textbook.';
$string['bookrequired'] = 'This course does not have a textbook yet. Please upload one first.';
$string['sectionnotfound'] = 'Topic not found.';
$string['section'] = 'Topic';
$string['topicstubdesc'] = 'This is the course-level Create Topic page. Later it can be connected to topic/lesson creation flow.';
$string['homeworkstubdesc'] = 'This is the per-topic homework creation page. Later it will connect to AI question generation.';
$string['createtopicforcourse'] = 'Create topic for course';
$string['createhomeworkforsection'] = 'Create homework for topic';


$string['uploadbookhelp'] = 'PDF files only. A course may contain multiple textbooks.';
$string['bookname'] = 'Book name';
$string['bookname_help'] = 'Example: Math 6 - Volume 1, Math 6 - Volume 2.';
$string['topicmanagerdesc'] = 'Select a book to enter, edit, and save its table of contents. This data will be reused for topic and homework creation.';
$string['bookselect'] = 'Select book';
$string['viewchange'] = 'View';
$string['booklabel'] = 'Book';
$string['tocpageslabel'] = 'TOC scan pages';
$string['sobai'] = 'Lesson no.';
$string['tenbai'] = 'Lesson title';
$string['trangbatdau'] = 'Start page';
$string['trangketthuc'] = 'End page';
$string['rawline'] = 'Raw OCR';
$string['tocsaved'] = 'Table of contents saved.';
$string['endtrangautohelp'] = 'If the end page is left blank, it will be calculated as the next lesson start page minus 1 when saving.';
$string['reloadtoc'] = 'Reload';

$string['scantoc'] = 'Scan table of contents';
$string['tocscanned'] = 'Scanned and saved %d lesson rows.';
$string['bookimagesmissing'] = 'No source images found for OCR. Please scan again.';
$string['errorprocessingbook'] = 'Book processing error: {$a}';

$string['uploadlimitnote'] = 'If large PDFs cannot be uploaded, increase the limits in Nginx, PHP, and Moodle Site upload limit.';
$string['tocscanincludespecial'] = 'Scanning keeps Lesson, Practice, and Review lines.';
