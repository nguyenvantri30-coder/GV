<?php
namespace local_aisgk\form;

defined('MOODLE_INTERNAL') || die();

require_once($GLOBALS['CFG']->libdir . '/formslib.php');

class upload_book_form extends \moodleform {
    public function definition() {
        $mform = $this->_form;

        $mform->addElement('text', 'bookname', get_string('bookname', 'local_aisgk'));
        $mform->setType('bookname', PARAM_TEXT);
        $mform->addHelpButton('bookname', 'bookname', 'local_aisgk');

        $mform->addElement('filepicker', 'bookpdf', get_string('uploadbook', 'local_aisgk'), null, [
            'accepted_types' => ['.pdf'],
            'maxbytes' => 0,
        ]);
        $mform->addRule('bookpdf', null, 'required', null, 'client');
        $mform->addElement('static', 'uploadlimitnote', '', get_string('uploadlimitnote', 'local_aisgk'));

        $this->add_action_buttons(true, get_string('savechanges', 'local_aisgk'));
    }
}
