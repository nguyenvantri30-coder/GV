<?php
namespace local_aisgk\local;

defined('MOODLE_INTERNAL') || die();

use local_aisgk\book_repository;

class sgk_processor {
    const COMPONENT = 'local_aisgk';
    const FILEAREA = 'bookpdf';

    protected static function get_context_for_book(int $courseid): \context_course {
        return \context_course::instance($courseid);
    }

    protected static function get_book_record(int $bookid): \stdClass {
        $book = book_repository::get_by_id($bookid);
        if (!$book) {
            throw new \moodle_exception('invalidparameter');
        }
        return $book;
    }

    protected static function get_book_file(int $bookid): \stored_file {
        $book = self::get_book_record($bookid);
        $context = self::get_context_for_book((int)$book->courseid);
        $fs = get_file_storage();
        $files = $fs->get_area_files(
            $context->id,
            self::COMPONENT,
            self::FILEAREA,
            (int)$book->fileitemid,
            'itemid, filepath, filename',
            false
        );

        foreach ($files as $file) {
            if (!$file->is_directory()) {
                return $file;
            }
        }

        throw new \moodle_exception('bookrequired', 'local_aisgk');
    }

    public static function get_temp_dir(int $courseid, int $bookid): string {
        global $CFG;
        $dir = $CFG->dataroot . '/local_aisgk/tmp/' . $courseid . '/' . $bookid;
        if (!is_dir($dir)) {
            mkdir($dir, $CFG->directorypermissions, true);
        }
        return $dir;
    }

    public static function clear_temp_dir(int $courseid, int $bookid): void {
        $dir = self::get_temp_dir($courseid, $bookid);
        foreach (['*.png', '*.txt', '*.pdf', '*.log'] as $pattern) {
            foreach (glob($dir . '/' . $pattern) ?: [] as $file) {
                @unlink($file);
            }
        }
    }

    protected static function export_pdf_to_temp(int $bookid): string {
        $book = self::get_book_record($bookid);
        $storedfile = self::get_book_file($bookid);
        $dir = self::get_temp_dir((int)$book->courseid, $bookid);
        $pdfpath = $dir . '/book_' . $bookid . '.pdf';
        if (file_exists($pdfpath)) {
            @unlink($pdfpath);
        }
        $storedfile->copy_content_to($pdfpath);
        if (!file_exists($pdfpath) || filesize($pdfpath) <= 0) {
            throw new \moodle_exception('errorprocessingbook', 'local_aisgk');
        }
        return $pdfpath;
    }

    public static function get_mucluc(int $bookid, int $tutrang, int $dentrang, int $donet = 200): array {
        $book = self::get_book_record($bookid);
        if ($tutrang <= 0 || $dentrang <= 0 || $tutrang > $dentrang) {
            throw new \invalid_parameter_exception('Khoảng trang không hợp lệ');
        }
        $donet = max(72, min(250, $donet));
        self::clear_temp_dir((int)$book->courseid, $bookid);
        $pdfpath = self::export_pdf_to_temp($bookid);
        $dir = self::get_temp_dir((int)$book->courseid, $bookid);

        $index = 1;
        for ($page = $tutrang; $page <= $dentrang; $page++, $index++) {
            $out = $dir . '/' . $bookid . '_' . $index . '.png';
            $tmpdir = escapeshellarg($dir);
            $cmd = sprintf(
                'TMPDIR=%s TEMP=%s TMP=%s /usr/bin/gs -dSAFER -dBATCH -dNOPAUSE -sDEVICE=pnggray -r%d -dFirstPage=%d -dLastPage=%d -sOutputFile=%s %s 2>&1',
                $tmpdir,
                $tmpdir,
                $tmpdir,
                $donet,
                $page,
                $page,
                escapeshellarg($out),
                escapeshellarg($pdfpath)
            );
            exec($cmd, $output, $returnvar);
            if ($returnvar !== 0 || !file_exists($out)) {
                throw new \moodle_exception('errorprocessingbook', 'local_aisgk', '', null, implode("\n", $output));
            }
        }

        return self::get_source_images((int)$book->courseid, $bookid);
    }

    protected static function preprocess_image_for_ocr(string $imagepath): string {
        $outpath = preg_replace('/\.png$/i', '_prep.png', $imagepath);
        $cmd = sprintf(
            '/usr/bin/convert %s -colorspace Gray -auto-level -sharpen 0x0.8 -deskew 40%% %s 2>&1',
            escapeshellarg($imagepath),
            escapeshellarg($outpath)
        );
        exec($cmd, $output, $returnvar);
        if ($returnvar !== 0 || !file_exists($outpath)) {
            throw new \moodle_exception('errorprocessingbook', 'local_aisgk', '', null, implode("\n", $output));
        }
        return $outpath;
    }

    protected static function ocr_one_tesseract(string $imagepath, string $lang = 'vie'): string {
        $txtbase = preg_replace('/\.png$/i', '', $imagepath);
        $cmd = sprintf(
            '/usr/bin/tesseract %s %s -l %s --psm 4 -c preserve_interword_spaces=1 2>&1',
            escapeshellarg($imagepath),
            escapeshellarg($txtbase),
            escapeshellarg($lang)
        );
        exec($cmd, $output, $returnvar);
        if ($returnvar !== 0) {
            throw new \moodle_exception('errorprocessingbook', 'local_aisgk', '', null, implode("\n", $output));
        }
        $txtfile = $txtbase . '.txt';
        return file_exists($txtfile) ? trim((string)file_get_contents($txtfile)) : '';
    }

    public static function ocr_img(int $bookid, string $engine_default = 'tesseract'): array {
        $book = self::get_book_record($bookid);
        $images = self::get_source_images((int)$book->courseid, $bookid);
        if (empty($images)) {
            throw new \moodle_exception('bookimagesmissing', 'local_aisgk');
        }

        $results = [];
        foreach ($images as $img) {
            $text = self::ocr_one_tesseract($img, 'vie');
            $linecount = self::count_target_lines($text);
            if ($linecount < 2) {
                $prep = self::preprocess_image_for_ocr($img);
                $preptext = self::ocr_one_tesseract($prep, 'vie');
                if (self::count_target_lines($preptext) >= $linecount) {
                    $text = $preptext;
                }
            }
            $results[] = [
                'file' => basename($img),
                'path' => $img,
                'text' => $text,
            ];
        }

        return [
            'engine' => 'tesseract',
            'files' => $results,
            'joined' => implode("\n\n", array_column($results, 'text')),
        ];
    }

    public static function orc_img(int $bookid, string $engine_default = 'tesseract'): array {
        return self::ocr_img($bookid, $engine_default);
    }

    public static function preview_topic_lines(int $bookid, int $tutrang = 4, int $dentrang = 5): array {
        self::get_mucluc($bookid, $tutrang, $dentrang, 200);
        $ocr = self::ocr_img($bookid, 'tesseract');
        $raw = $ocr['joined'];
        $normalized = preg_replace("/\r\n|\r/u", "\n", $raw);
        $lines = explode("\n", $normalized);
        $matched = [];
        foreach ($lines as $line) {
            $line = trim((string)$line);
            if ($line === '') {
                continue;
            }
            if (self::is_target_line($line)) {
                $matched[] = $line;
            }
        }
        return [
            'raw' => $raw,
            'content_lines' => array_values(array_filter(array_map('trim', $lines))),
            'matched_lines' => $matched,
            'preview' => implode("\n", $matched),
        ];
    }

    public static function parse_bai_lines(array $lines): array {
        $items = [];
        $specialindex = 0;

        foreach ($lines as $line) {
            $line = trim((string)$line);
            if ($line === '') {
                continue;
            }
            $line = preg_replace('/\s+/u', ' ', $line);
            $line = preg_replace('/[.…]{2,}/u', ' ', $line);
            if (!self::is_target_line($line)) {
                continue;
            }

            $parsed = self::parse_target_line($line);
            if ($parsed === null) {
                continue;
            }

            if (!empty($parsed['sobai'])) {
                $key = 'bai_' . (int)$parsed['sobai'];
            } else {
                $key = 'special_' . (++$specialindex) . '_' . md5(core_text::strtolower((string)$parsed['tenbai']));
            }
            $items[$key][] = $parsed;
        }

        $dedup = [];
        foreach ($items as $candidates) {
            usort($candidates, function($a, $b) {
                $apage = empty($a['trang']) ? 0 : 1;
                $bpage = empty($b['trang']) ? 0 : 1;
                if ($apage !== $bpage) {
                    return $bpage <=> $apage;
                }
                return mb_strlen((string)$b['tenbai']) <=> mb_strlen((string)$a['tenbai']);
            });
            $best = $candidates[0];
            $best['endtrang'] = null;
            $dedup[] = $best;
        }

        usort($dedup, function($a, $b) {
            $apage = (int)($a['trang'] ?? 0);
            $bpage = (int)($b['trang'] ?? 0);
            if ($apage > 0 && $bpage > 0 && $apage !== $bpage) {
                return $apage <=> $bpage;
            }
            $asobai = (int)($a['sobai'] ?? 0);
            $bsobai = (int)($b['sobai'] ?? 0);
            if ($asobai !== $bsobai) {
                if ($asobai === 0) {
                    return 1;
                }
                if ($bsobai === 0) {
                    return -1;
                }
                return $asobai <=> $bsobai;
            }
            return strnatcasecmp((string)$a['tenbai'], (string)$b['tenbai']);
        });

        return $dedup;
    }

    public static function preview_topic_items(int $bookid): array {
        $book = self::get_book_record($bookid);
        $preview = self::preview_topic_lines($bookid, (int)$book->tocfrompage, (int)$book->toctopage);
        $items = self::parse_bai_lines($preview['matched_lines']);
        return [
            'raw' => $preview['raw'],
            'content_lines' => $preview['content_lines'],
            'matched_lines' => $preview['matched_lines'],
            'items' => $items,
        ];
    }

    protected static function get_source_images(int $courseid, int $bookid): array {
        $dir = self::get_temp_dir($courseid, $bookid);
        $allfiles = glob($dir . '/' . $bookid . '_*.png') ?: [];
        $images = array_values(array_filter($allfiles, function($file) use ($bookid) {
            return preg_match('/\/' . preg_quote((string)$bookid, '/') . '_\d+\.png$/', $file);
        }));
        natsort($images);
        return array_values($images);
    }

    protected static function count_target_lines(string $text): int {
        $count = 0;
        foreach (preg_split('/\R/u', $text) as $line) {
            if (self::is_target_line((string)$line)) {
                $count++;
            }
        }
        return $count;
    }

    protected static function is_target_line(string $line): bool {
        $line = trim($line);
        if ($line === '') {
            return false;
        }

        return (bool)(
            preg_match('/\bBài\b/ui', $line) ||
            preg_match('/^B\w*i\s+\d+/ui', $line) ||
            preg_match('/\bLuy(?:ệ|e)n\s*t(?:ậ|a)p\b/ui', $line) ||
            preg_match('/\bÔn\s*t(?:ậ|a)p\b/ui', $line) ||
            preg_match('/\bOn\s*t(?:a|ậ)p\b/ui', $line)
        );
    }

    protected static function parse_target_line(string $line): ?array {
        $sobai = 0;
        $tenbai = '';
        $trang = null;

        if (preg_match('/^\s*B\w*i\s+(\d+)\s*[\.:\-]?\s*(.*?)\s+(\d{1,4})\s*$/ui', $line, $m)) {
            $sobai = (int)$m[1];
            $tenbai = trim((string)$m[2], " \t\n\r\0\x0B.-:");
            $trang = (int)$m[3];
        } else if (preg_match('/^\s*B\w*i\s+(\d+)\s*[\.:\-]?\s*(.*?)\s*$/ui', $line, $m)) {
            $sobai = (int)$m[1];
            $tenbai = trim((string)$m[2], " \t\n\r\0\x0B.-:");
            if (preg_match('/\s(\d{1,4})\s*$/u', $tenbai, $pm)) {
                $trang = (int)$pm[1];
                $tenbai = trim((string)preg_replace('/\s+\d{1,4}\s*$/u', '', $tenbai));
            }
        } else if (preg_match('/^\s*((?:Luy(?:ệ|e)n\s*t(?:ậ|a)p)|(?:Ôn\s*t(?:ậ|a)p)|(?:On\s*t(?:a|ậ)p))\s*[\.:\-]?\s*(.*?)\s+(\d{1,4})\s*$/ui', $line, $m)) {
            $tenbai = trim((string)$m[1] . ' ' . $m[2]);
            $tenbai = trim($tenbai, " \t\n\r\0\x0B.-:");
            $trang = (int)$m[3];
        } else if (preg_match('/^\s*((?:Luy(?:ệ|e)n\s*t(?:ậ|a)p)|(?:Ôn\s*t(?:ậ|a)p)|(?:On\s*t(?:a|ậ)p))\s*[\.:\-]?\s*(.*?)\s*$/ui', $line, $m)) {
            $tenbai = trim((string)$m[1] . ' ' . $m[2]);
            $tenbai = trim($tenbai, " \t\n\r\0\x0B.-:");
            if (preg_match('/\s(\d{1,4})\s*$/u', $tenbai, $pm)) {
                $trang = (int)$pm[1];
                $tenbai = trim((string)preg_replace('/\s+\d{1,4}\s*$/u', '', $tenbai));
            }
        }

        if ($sobai === 0 && $tenbai === '') {
            return null;
        }

        return [
            'sobai' => $sobai,
            'tenbai' => $tenbai,
            'trang' => $trang,
            'rawline' => $line,
        ];
    }
}
