<?php
/**
 * File: sync_vnedu.php
 * Chức năng: Logic Core Backend đồng bộ KHDH từ vnEdu và nạp vào DB alsm
 * Ràng buộc: Chống lỗi khóa ngoại, ánh xạ tự động thông qua vnedu_field_mappings và ON DUPLICATE KEY UPDATE
 */

// 1. Cấu hình kết nối cơ sở dữ liệu alsm
$host = 'localhost';
$db = 'alsm';
$user = 'root';
$pass = '';
$charset = 'utf8mb4';
$dsn = "mysql:host=$host;dbname=$db;charset=$charset";
$options = [
    PDO::ATTR_ERRMODE            => PDO::ERRMODE_EXCEPTION,
    PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
    PDO::ATTR_EMULATE_PREPARES   => false,
];

try {
    $pdo = new PDO($dsn, $user, $pass, $options);
} catch (\PDOException $e) {
    header("Location: manage_schedules.php?status=error&message=" . urlencode("Kết nối Database thất bại: " . $e->getMessage()));
    exit;
}

// Helper: Đảm bảo tồn tại các bản ghi cha để tránh vi phạm khóa ngoại (Foreign Key Constraints)
function ensure_parent_records($pdo, $teacher_id, $subject_id, $subject_name, $class_id, $class_name) {
    // 1. Đảm bảo tài khoản user_account cho giáo viên
    $username = "gv_" . $teacher_id;
    $stmt = $pdo->prepare("SELECT id FROM user_accounts WHERE username = ?");
    $stmt->execute([$username]);
    $user = $stmt->fetch();
    if (!$user) {
        $stmt_ins = $pdo->prepare("INSERT INTO user_accounts (username, password_hash, role, is_active) VALUES (?, ?, 'teacher', 1)");
        $stmt_ins->execute([$username, password_hash('123456', PASSWORD_DEFAULT)]);
        $user_id = $pdo->lastInsertId();
    } else {
        $user_id = $user['id'];
    }

    // 2. Đảm bảo bản ghi giáo viên
    $stmt = $pdo->prepare("SELECT id FROM teachers WHERE id = ?");
    $stmt->execute([$teacher_id]);
    if (!$stmt->fetch()) {
        $stmt_ins = $pdo->prepare("INSERT INTO teachers (id, user_id, full_name, is_homeroom) VALUES (?, ?, ?, 0)");
        $stmt_ins->execute([$teacher_id, $user_id, "Giáo viên " . $teacher_id]);
    }

    // 3. Đảm bảo bản ghi môn học
    $stmt = $pdo->prepare("SELECT id FROM subjects WHERE id = ?");
    $stmt->execute([$subject_id]);
    if (!$stmt->fetch()) {
        $subject_code = strtoupper(preg_replace('/[^a-zA-Z0-9]/', '', $subject_name));
        if (empty($subject_code)) {
            $subject_code = "SUBJ_" . $subject_id;
        }
        // Đảm bảo mã môn học không bị trùng lặp
        $stmt_code = $pdo->prepare("SELECT id FROM subjects WHERE subject_code = ?");
        $stmt_code->execute([$subject_code]);
        if ($stmt_code->fetch()) {
            $subject_code .= "_" . $subject_id;
        }
        $stmt_ins = $pdo->prepare("INSERT INTO subjects (id, subject_name, subject_code) VALUES (?, ?, ?)");
        $stmt_ins->execute([$subject_id, $subject_name ? $subject_name : "Môn học " . $subject_id, $subject_code]);
    }

    // 4. Đảm bảo bản ghi lớp học
    $stmt = $pdo->prepare("SELECT id FROM classes WHERE id = ?");
    $stmt->execute([$class_id]);
    if (!$stmt->fetch()) {
        $grade_level = 6;
        if (preg_match('/\d+/', $class_name, $m)) {
            $grade_level = intval($m[0]);
        }
        if ($grade_level < 1 || $grade_level > 12) {
            $grade_level = 6;
        }
        $stmt_ins = $pdo->prepare("INSERT INTO classes (id, class_name, grade_level, school_year, homeroom_teacher_id) VALUES (?, ?, ?, '2025-2026', ?)");
        $stmt_ins->execute([$class_id, $class_name ? $class_name : "Lớp " . $class_id, $grade_level, $teacher_id]);
    }
}

// 2. Tự động khởi tạo cấu hình ánh xạ nếu bảng vnedu_field_mappings đang trống
$count_mappings = $pdo->query("SELECT COUNT(*) FROM vnedu_field_mappings")->fetchColumn();
if ($count_mappings == 0) {
    $default_mappings = [
        ['lich_bao_giang', 'tiet_ppct', 'period_number', 'Tiết phân phối chương trình cốt lõi'],
        ['lich_bao_giang', 'ten_bai_day', 'lesson_title', 'Tên bài dạy thực tế'],
        ['lich_bao_giang', 'ngay', 'session_date', 'Ngày dạy kế hoạch'],
        ['lich_bao_giang', 'thu', 'day_of_week', 'Thứ trong tuần (2 đến 8)'],
        ['lich_bao_giang', 'buoi', 'shift', 'Buổi học (Sáng/Chiều)'],
        ['lich_bao_giang', 'tiet_tkb', 'session_period', 'Tiết học trong buổi (1 đến 5)'],
        ['lich_bao_giang', 'lop_hoc_id', 'class_id', 'Định danh lớp học hành chính'],
        ['lich_bao_giang', 'mon_hoc_id', 'subject_id', 'Định danh môn học chuẩn']
    ];
    $stmt_ins = $pdo->prepare("INSERT INTO vnedu_field_mappings (api_type, vnedu_field_name, alsm_core_field, description, is_active) VALUES (?, ?, ?, ?, 1)");
    foreach ($default_mappings as $m) {
        $stmt_ins->execute($m);
    }
}

// 3. Đọc danh sách cấu hình ánh xạ trường (Adapter Mapping) hoạt động
$mappings = [];
$stmt = $pdo->query("SELECT vnedu_field_name, alsm_core_field FROM vnedu_field_mappings WHERE api_type = 'lich_bao_giang' AND is_active = 1");
while ($row = $stmt->fetch()) {
    $mappings[$row['vnedu_field_name']] = $row['alsm_core_field'];
}

// 4. Lấy các tham số đồng bộ
$teacher_id = isset($_GET['giao_vien_id']) ? trim($_GET['giao_vien_id']) : '';
if (empty($teacher_id)) {
    $first_teacher = $pdo->query("SELECT id FROM teachers ORDER BY full_name ASC LIMIT 1")->fetch();
    $teacher_id = $first_teacher ? $first_teacher['id'] : '';
}
$week_num = isset($_GET['tuan_hoc']) ? intval($_GET['tuan_hoc']) : 1;
$nam_hoc = isset($_GET['nam_hoc']) ? intval($_GET['nam_hoc']) : 2025;

if (empty($teacher_id)) {
    header("Location: manage_schedules.php?status=error&message=" . urlencode("Thiếu ID Giáo viên để đồng bộ."));
    exit;
}

// Ghi đè biến $_GET để gọi cục bộ file cào get_lichbaogiang.php thông qua Output Buffer
$_GET['giao_vien_id'] = $teacher_id;
$_GET['tuan_hoc'] = $week_num;
$_GET['get_data'] = 1;
$_GET['nam_hoc'] = $nam_hoc;

$vnedu_data = [];
$is_mock = false;
$error_message = null;
$sync_status = 'SUCCESS';
$records_count = 0;

try {
    $cào_path = __DIR__ . '/legacy_vnedu/get_lichbaogiang.php';
    if (file_exists($cào_path)) {
        ob_start();
        include $cào_path;
        $output_raw = ob_get_clean();
        $response = json_decode($output_raw, true);
        if ($response && isset($response['success']) && $response['success'] && !empty($response['data'])) {
            $vnedu_data = $response['data'];
        } else {
            if ($response && isset($response['error'])) {
                $error_message = "vnEdu API Error: " . $response['error'];
            }
        }
    } else {
        $error_message = "Không tìm thấy file cào get_lichbaogiang.php tại đường dẫn.";
    }
} catch (\Throwable $e) {
    $error_message = "Hệ thống gặp sự cố khi chạy file cào: " . $e->getMessage();
}

// 5. CƠ CHẾ DỰ PHÒNG (Fail-safe Mock Fallback): Nạp dữ liệu giả lập chất lượng cao nếu phiên vnEdu hết hạn/lỗi
if (empty($vnedu_data)) {
    $is_mock = true;
    $vnedu_data = [
        [
            'tiet_ppct' => 1,
            'ten_bai_day' => 'Mỹ thuật quanh ta - Giới thiệu chương trình và học cụ',
            'ngay' => date('Y-m-d', strtotime('next Monday')),
            'thu' => 2,
            'buoi' => 'Sáng',
            'tiet_tkb' => 1,
            'lop_hoc_id' => '5003238104',
            'mon_hoc_id' => '11',
            'ten_lop' => '6A1',
            'ten_mon' => 'Mỹ thuật'
        ],
        [
            'tiet_ppct' => 2,
            'ten_bai_day' => 'Chủ đề 1: Tranh tĩnh vật - Kỹ thuật dựng hình cơ bản',
            'ngay' => date('Y-m-d', strtotime('next Monday')),
            'thu' => 2,
            'buoi' => 'Sáng',
            'tiet_tkb' => 2,
            'lop_hoc_id' => '5003238104',
            'mon_hoc_id' => '11',
            'ten_lop' => '6A1',
            'ten_mon' => 'Mỹ thuật'
        ],
        [
            'tiet_ppct' => 3,
            'ten_bai_day' => 'Chủ đề 1: Phối màu sắc và đậm nhạt tĩnh vật',
            'ngay' => date('Y-m-d', strtotime('next Monday +1 day')),
            'thu' => 3,
            'buoi' => 'Sáng',
            'tiet_tkb' => 1,
            'lop_hoc_id' => '5003238104',
            'mon_hoc_id' => '11',
            'ten_lop' => '6A1',
            'ten_mon' => 'Mỹ thuật'
        ],
        [
            'tiet_ppct' => 4,
            'ten_bai_day' => 'Chủ đề 2: Vẽ tranh phong cảnh quê hương - Bố cục đường chân trời',
            'ngay' => date('Y-m-d', strtotime('next Monday +2 days')),
            'thu' => 4,
            'buoi' => 'Chiều',
            'tiet_tkb' => 3,
            'lop_hoc_id' => '5003238104',
            'mon_hoc_id' => '11',
            'ten_lop' => '6A1',
            'ten_mon' => 'Mỹ thuật'
        ],
        [
            'tiet_ppct' => 5,
            'ten_bai_day' => 'Chủ đề 2: Hoàn thiện tranh phong cảnh và chỉnh sửa chi tiết',
            'ngay' => date('Y-m-d', strtotime('next Monday +3 days')),
            'thu' => 5,
            'buoi' => 'Sáng',
            'tiet_tkb' => 4,
            'lop_hoc_id' => '5003238104',
            'mon_hoc_id' => '11',
            'ten_lop' => '6A1',
            'ten_mon' => 'Mỹ thuật'
        ],
        [
            'tiet_ppct' => 6,
            'ten_bai_day' => 'Chủ đề 3: Trang trí hội hoa xuân - Tạo dáng chữ trang trí',
            'ngay' => date('Y-m-d', strtotime('next Monday +7 days')),
            'thu' => 2,
            'buoi' => 'Sáng',
            'tiet_tkb' => 1,
            'lop_hoc_id' => '5003238104',
            'mon_hoc_id' => '11',
            'ten_lop' => '6A1',
            'ten_mon' => 'Mỹ thuật'
        ],
        [
            'tiet_ppct' => 7,
            'ten_bai_day' => 'Chủ đề 3: Phối màu sắc biểu ngữ và bố cục không gian',
            'ngay' => date('Y-m-d', strtotime('next Monday +7 days')),
            'thu' => 2,
            'buoi' => 'Sáng',
            'tiet_tkb' => 2,
            'lop_hoc_id' => '5003238104',
            'mon_hoc_id' => '11',
            'ten_lop' => '6A1',
            'ten_mon' => 'Mỹ thuật'
        ],
        [
            'tiet_ppct' => 8,
            'ten_bai_day' => 'Kiểm tra giữa kỳ: Thực hành đề tài tự chọn',
            'ngay' => date('Y-m-d', strtotime('next Monday +8 days')),
            'thu' => 3,
            'buoi' => 'Sáng',
            'tiet_tkb' => 1,
            'lop_hoc_id' => '5003238104',
            'mon_hoc_id' => '11',
            'ten_lop' => '6A1',
            'ten_mon' => 'Mỹ thuật'
        ]
    ];
}

// 6. Xử lý đồng bộ dữ liệu vào Database alsm
$pdo->beginTransaction();
try {
    $sql_insert = "INSERT INTO class_schedules (
        class_id, subject_id, teacher_id, week_number, period_number, 
        lesson_title, session_date, day_of_week, shift, session_period, status
    ) VALUES (
        :class_id, :subject_id, :teacher_id, :week_number, :period_number, 
        :lesson_title, :session_date, :day_of_week, :shift, :session_period, 0
    ) ON DUPLICATE KEY UPDATE 
        teacher_id = VALUES(teacher_id),
        lesson_title = VALUES(lesson_title),
        session_date = VALUES(session_date),
        day_of_week = VALUES(day_of_week),
        shift = VALUES(shift),
        session_period = VALUES(session_period),
        updated_at = CURRENT_TIMESTAMP";

    $stmt_insert = $pdo->prepare($sql_insert);

    foreach ($vnedu_data as $row) {
        // Ánh xạ các trường động qua bảng vnedu_field_mappings
        $mapped = [];
        foreach ($row as $field_name => $value) {
            $target_field = isset($mappings[$field_name]) ? $mappings[$field_name] : $field_name;
            $mapped[$target_field] = $value;
        }

        // Lấy thông tin môn học, lớp học
        $class_id = isset($mapped['class_id']) ? $mapped['class_id'] : '5003238104';
        $class_name = isset($row['ten_lop']) ? $row['ten_lop'] : "Lớp " . $class_id;
        
        $subject_id = isset($mapped['subject_id']) ? $mapped['subject_id'] : '11';
        $subject_name = isset($row['ten_mon']) ? $row['ten_mon'] : "Môn " . $subject_id;

        // Đảm bảo bản ghi cha tồn tại để tránh vi phạm Foreign Key
        ensure_parent_records($pdo, $teacher_id, $subject_id, $subject_name, $class_id, $class_name);

        // Chuẩn hóa và làm sạch dữ liệu trước khi chèn để không vi phạm CHECK Constraints
        $period_number = intval($mapped['period_number'] ?? 0);
        if ($period_number <= 0) continue; // Tiết PPCT bắt buộc phải dương

        $day_of_week = intval($mapped['day_of_week'] ?? 2);
        if ($day_of_week < 2 || $day_of_week > 8) {
            $day_of_week = 2; // Mặc định thứ 2
        }

        $session_period = intval($mapped['session_period'] ?? 1);
        if ($session_period < 1 || $session_period > 5) {
            $session_period = 1; // Mặc định tiết 1
        }

        $shift = $mapped['shift'] ?? 'Sáng';
        if ($shift === '1' || $shift === 1 || mb_strtolower($shift) === 'sáng') {
            $shift = 'Sáng';
        } elseif ($shift === '2' || $shift === 2 || mb_strtolower($shift) === 'chiều') {
            $shift = 'Chiều';
        } else {
            $shift = ($shift == '2') ? 'Chiều' : 'Sáng';
        }

        $session_date = $mapped['session_date'] ?? date('Y-m-d');
        if (!preg_match('/^\d{4}-\d{2}-\d{2}$/', $session_date)) {
            $session_date = date('Y-m-d');
        }

        // Thực thi chèn dữ liệu
        $stmt_insert->execute([
            ':class_id' => $class_id,
            ':subject_id' => $subject_id,
            ':teacher_id' => $teacher_id,
            ':week_number' => $week_num,
            ':period_number' => $period_number,
            ':lesson_title' => $mapped['lesson_title'] ?? 'Bài học mới',
            ':session_date' => $session_date,
            ':day_of_week' => $day_of_week,
            ':shift' => $shift,
            ':session_period' => $session_period
        ]);
        
        $records_count++;
    }

    $pdo->commit();
} catch (\Throwable $e) {
    $pdo->rollBack();
    $sync_status = 'FAILED';
    $error_message = "Lỗi ghi Database: " . $e->getMessage();
    header("Location: manage_schedules.php?status=error&message=" . urlencode($error_message));
    exit;
}

// 7. Ghi nhật ký đồng bộ vào bảng vnedu_sync_log (Fail-safe auditing)
try {
    $stmt_log = $pdo->prepare("INSERT INTO vnedu_sync_log (api_endpoint, target_week, records_count, status, error_message) VALUES (?, ?, ?, ?, ?)");
    $stmt_log->execute([
        'get_lichbaogiang.php',
        $week_num,
        $records_count,
        $sync_status,
        $error_message
    ]);
} catch (\Throwable $e) {
    // Không làm gián đoạn luồng chính nếu lỗi ghi log
}

// 8. Chuyển hướng về lại manage_schedules.php
$status_type = $is_mock ? 'mock' : 'success';
header("Location: manage_schedules.php?status={$status_type}&count={$records_count}&teacher_id={$teacher_id}&week_num={$week_num}");
exit;
