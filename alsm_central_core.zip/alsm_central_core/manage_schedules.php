<?php
/**
 * File: manage_schedules.php
 * Chức năng: Giao diện Web đối soát KHDH tuần và hiển thị lịch dạy sau khi đồng bộ
 */

// 1. Cấu hình kết nối cơ sở dữ liệu alsm
$host = 'localhost';
$db = 'alsm';
$user = 'root';
$pass = '';
$charset = 'utf8mb4';
$dsn = "mysql:host=$host;dbname=$db;charset=$charset";
$options = [
    PDO::ATTR_ERRMODE            => PDO::ERRMODE_EXCEPTION,
    PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
    PDO::ATTR_EMULATE_PREPARES   => false,
];

try {
    $pdo = new PDO($dsn, $user, $pass, $options);
} catch (\PDOException $e) {
    die("<div style='padding: 20px; background: #fee2e2; color: #991b1b; font-family: sans-serif; border-radius: 8px;'>
            <strong>Lỗi kết nối CSDL:</strong> " . htmlspecialchars($e->getMessage()) . "
         </div>");
}

// Lấy danh sách giáo viên hiện có để hiển thị trong bộ lọc
$teachers = $pdo->query("SELECT id, full_name FROM teachers ORDER BY full_name ASC")->fetchAll();

// 2. Lấy bộ lọc từ URL
$filter_teacher = isset($_GET['teacher_id']) ? trim($_GET['teacher_id']) : '';
if (empty($filter_teacher) && !empty($teachers)) {
    $filter_teacher = $teachers[0]['id'];
}
$filter_week = isset($_GET['week_num']) ? intval($_GET['week_num']) : 0;
$filter_shift = isset($_GET['shift_filter']) ? trim($_GET['shift_filter']) : '';
$filter_subject = isset($_GET['subject_filter']) ? trim($_GET['subject_filter']) : '';
$filter_period = isset($_GET['period_filter']) ? intval($_GET['period_filter']) : 0;

// Lấy danh sách môn học hiện có để hiển thị trong bộ lọc (chỉ hiển thị môn giáo viên đó đang dạy)
if (!empty($filter_teacher)) {
    $stmt_sub = $pdo->prepare("
        SELECT DISTINCT sub.id, sub.subject_name 
        FROM class_subject_assignments csa
        JOIN subjects sub ON csa.subject_id = sub.id
        WHERE csa.teacher_id = :teacher_id
        ORDER BY sub.subject_name ASC
    ");
    $stmt_sub->execute([':teacher_id' => $filter_teacher]);
    $subjects_list = $stmt_sub->fetchAll();
    
    // Dự phòng kiểm tra từ lịch dạy nếu danh sách phân công rỗng
    if (empty($subjects_list)) {
        $stmt_sub2 = $pdo->prepare("
            SELECT DISTINCT sub.id, sub.subject_name 
            FROM class_schedules s
            JOIN subjects sub ON s.subject_id = sub.id
            WHERE s.teacher_id = :teacher_id
            ORDER BY sub.subject_name ASC
        ");
        $stmt_sub2->execute([':teacher_id' => $filter_teacher]);
        $subjects_list = $stmt_sub2->fetchAll();
    }
} else {
    $subjects_list = $pdo->query("SELECT id, subject_name FROM subjects ORDER BY subject_name ASC")->fetchAll();
}

// 3. Truy vấn danh sách lịch học/lịch dạy để hiển thị đối soát
$sql = "SELECT s.*, c.class_name, sub.subject_name, t.full_name as teacher_name 
        FROM class_schedules s
        LEFT JOIN classes c ON s.class_id = c.id
        LEFT JOIN subjects sub ON s.subject_id = sub.id
        LEFT JOIN teachers t ON s.teacher_id = t.id
        WHERE 1=1";

$params = [];
if (!empty($filter_teacher)) {
    $sql .= " AND s.teacher_id = :teacher_id";
    $params[':teacher_id'] = $filter_teacher;
}
if ($filter_week > 0) {
    $sql .= " AND s.week_number = :week_number";
    $params[':week_number'] = $filter_week;
}
if (!empty($filter_shift)) {
    $sql .= " AND s.shift = :shift";
    $params[':shift'] = $filter_shift;
}
if (!empty($filter_subject)) {
    $sql .= " AND s.subject_id = :subject_id";
    $params[':subject_id'] = $filter_subject;
}
if ($filter_period > 0) {
    $sql .= " AND s.session_period = :session_period";
    $params[':session_period'] = $filter_period;
}

$sql .= " ORDER BY s.period_number ASC"; // Sắp xếp tăng dần theo Tiết PPCT làm khóa đối chiếu chính

$stmt = $pdo->prepare($sql);
$stmt->execute($params);
$schedules = $stmt->fetchAll();

// Trạng thái đồng bộ từ URL
$status = isset($_GET['status']) ? $_GET['status'] : '';
$count = isset($_GET['count']) ? intval($_GET['count']) : 0;
$message = isset($_GET['message']) ? $_GET['message'] : '';
$nam_hoc_sync = isset($_GET['nam_hoc']) ? intval($_GET['nam_hoc']) : 2025;
?>
<!DOCTYPE html>
<html lang="vi">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>ALSM Central Core - Đối soát Tiến độ Dạy học</title>
    <!-- Nhúng Google Font Inter để tăng tính thẩm mỹ cao cấp -->
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700&display=swap" rel="stylesheet">
    <style>
        :root {
            --primary: #10b981;
            --primary-hover: #059669;
            --background: #f8fafc;
            --surface: #ffffff;
            --text-main: #0f172a;
            --text-muted: #64748b;
            --border: #e2e8f0;
            --accent: #3b82f6;
            --warning: #f59e0b;
            --danger: #ef4444;
            --shadow: 0 4px 20px -2px rgba(15, 23, 42, 0.08);
            --transition: all 0.2s cubic-bezier(0.4, 0, 0.2, 1);
        }

        * {
            box-sizing: border-box;
            margin: 0;
            padding: 0;
        }

        body {
            font-family: 'Inter', sans-serif;
            background-color: var(--background);
            color: var(--text-main);
            line-height: 1.5;
            padding: 40px 20px;
        }

        .container {
            max-width: 1300px;
            margin: 0 auto;
        }

        /* Header Style */
        header {
            margin-bottom: 30px;
            display: flex;
            justify-content: space-between;
            align-items: center;
            flex-wrap: wrap;
            gap: 15px;
        }

        .logo-zone h1 {
            font-size: 24px;
            font-weight: 700;
            color: #0f172a;
            letter-spacing: -0.5px;
            display: flex;
            align-items: center;
            gap: 8px;
        }

        .logo-zone p {
            font-size: 13px;
            color: var(--text-muted);
            margin-top: 4px;
        }

        .nav-links {
            display: flex;
            gap: 10px;
        }

        .nav-links a {
            display: inline-flex;
            align-items: center;
            gap: 6px;
            color: var(--accent);
            text-decoration: none;
            font-weight: 600;
            font-size: 14px;
            padding: 8px 16px;
            background-color: #eff6ff;
            border-radius: 8px;
            transition: var(--transition);
        }

        .nav-links a:hover {
            background-color: #dbeafe;
        }

        /* Banner trạng thái */
        .alert {
            padding: 16px 20px;
            border-radius: 12px;
            font-size: 14px;
            font-weight: 500;
            margin-bottom: 24px;
            display: flex;
            align-items: center;
            gap: 10px;
            animation: slideDown 0.3s ease;
            box-shadow: 0 4px 6px -1px rgba(0,0,0,0.05);
        }

        .alert-success {
            background-color: #ecfdf5;
            color: #065f46;
            border: 1px solid #a7f3d0;
        }

        .alert-warning {
            background-color: #fffbeb;
            color: #92400e;
            border: 1px solid #fde68a;
        }

        .alert-danger {
            background-color: #fef2f2;
            color: #991b1b;
            border: 1px solid #fecaca;
        }

        /* Panel điều khiển */
        .control-panel {
            background: var(--surface);
            border-radius: 16px;
            padding: 24px;
            box-shadow: var(--shadow);
            border: 1px solid var(--border);
            margin-bottom: 30px;
        }

        .control-form {
            display: grid;
            grid-template-columns: 2fr 1.5fr 2fr;
            gap: 20px;
            align-items: flex-end;
        }

        @media (max-width: 768px) {
            .control-form {
                grid-template-columns: 1fr;
            }
        }

        .form-group {
            display: flex;
            flex-direction: column;
            gap: 8px;
        }

        .form-group label {
            font-size: 12px;
            font-weight: 600;
            color: var(--text-muted);
            text-transform: uppercase;
            letter-spacing: 0.5px;
        }

        .form-group input, .form-group select {
            width: 100%;
            padding: 12px 16px;
            border: 1px solid var(--border);
            border-radius: 10px;
            font-size: 14px;
            font-family: inherit;
            color: var(--text-main);
            background-color: #f8fafc;
            transition: var(--transition);
        }

        .form-group input:focus, .form-group select:focus {
            outline: none;
            border-color: var(--accent);
            background-color: #fff;
            box-shadow: 0 0 0 3px rgba(59, 130, 246, 0.1);
        }

        /* Nút nhấn đồng bộ lớn */
        .btn-sync {
            background-color: var(--primary);
            color: #ffffff;
            border: none;
            padding: 14px 24px;
            font-size: 15px;
            font-weight: 600;
            border-radius: 10px;
            cursor: pointer;
            display: inline-flex;
            align-items: center;
            justify-content: center;
            gap: 8px;
            transition: var(--transition);
            box-shadow: 0 4px 10px rgba(16, 185, 129, 0.2);
            height: 46px;
        }

        .btn-sync:hover {
            background-color: var(--primary-hover);
            transform: translateY(-1px);
            box-shadow: 0 6px 14px rgba(16, 185, 129, 0.3);
        }

        .btn-sync:active {
            transform: translateY(0);
        }

        /* Bảng danh sách đối soát */
        .table-panel {
            background: var(--surface);
            border-radius: 16px;
            box-shadow: var(--shadow);
            border: 1px solid var(--border);
            overflow: hidden;
        }

        .table-header {
            padding: 20px 24px;
            border-bottom: 1px solid var(--border);
            display: flex;
            justify-content: space-between;
            align-items: center;
        }

        .table-header h2 {
            font-size: 18px;
            font-weight: 600;
            color: var(--text-main);
        }

        .table-header span {
            background-color: #f1f5f9;
            color: var(--text-muted);
            padding: 4px 12px;
            border-radius: 9999px;
            font-size: 12px;
            font-weight: 600;
        }

        .table-responsive {
            overflow-x: auto;
            width: 100%;
        }

        table {
            width: 100%;
            border-collapse: collapse;
            text-align: left;
        }

        th {
            background-color: #f8fafc;
            color: var(--text-muted);
            font-size: 12px;
            font-weight: 600;
            text-transform: uppercase;
            letter-spacing: 0.5px;
            padding: 14px 24px;
            border-bottom: 1px solid var(--border);
        }

        td {
            padding: 16px 24px;
            border-bottom: 1px solid var(--border);
            font-size: 14px;
            color: var(--text-main);
        }

        tr:last-child td {
            border-bottom: none;
        }

        tr:hover td {
            background-color: #f8fafc;
        }

        /* Cột Tiết PPCT nổi bật */
        .badge-period {
            background-color: #eff6ff;
            color: #1e40af;
            font-weight: 700;
            padding: 4px 10px;
            border-radius: 6px;
            font-size: 13px;
            display: inline-block;
            border: 1px solid #bfdbfe;
        }

        .badge-week {
            background-color: #f1f5f9;
            color: #334155;
            font-weight: 500;
            padding: 2px 8px;
            border-radius: 4px;
            font-size: 12px;
        }

        .badge-shift {
            font-weight: 600;
            padding: 2px 8px;
            border-radius: 4px;
            font-size: 12px;
            display: inline-block;
        }

        .badge-shift.sang {
            background-color: #fef3c7;
            color: #d97706;
        }

        .badge-shift.chieu {
            background-color: #e0f2fe;
            color: #0369a1;
        }

        /* Chế độ trống */
        .empty-state {
            padding: 60px 20px;
            text-align: center;
            color: var(--text-muted);
        }

        .empty-state svg {
            width: 48px;
            height: 48px;
            stroke: #cbd5e1;
            margin-bottom: 16px;
        }

        .empty-state h3 {
            font-size: 16px;
            font-weight: 600;
            color: #475569;
            margin-bottom: 6px;
        }

        .empty-state p {
            font-size: 14px;
        }

        @keyframes slideDown {
            from {
                opacity: 0;
                transform: translateY(-10px);
            }
            to {
                opacity: 1;
                transform: translateY(0);
            }
        }
    </style>
</head>
<body>

<div class="container">
    <!-- Header -->
    <header>
        <div class="logo-zone">
            <h1>🎨 ALSM Central Core</h1>
            <p>Khối 2: Đối soát & Theo dõi Kế hoạch dạy học</p>
        </div>
        <div class="nav-links">
            <a href="manage_classes.php">Quản lý Lớp học</a>
            <a href="manage_class_subjects.php">Quản lý Môn học</a>
            <a href="manage_teachers.php">Quản lý Giáo viên</a>
        </div>
    </header>

    <!-- Thông báo Trạng thái Đồng bộ -->
    <?php if ($status === 'success'): ?>
        <div class="alert alert-success">
            <svg width="20" height="20" fill="none" stroke="currentColor" stroke-width="2" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" d="M9 12l2 2 4-4m6 2a9 9 0 11-18 0 9 9 0 0118 0z"></path></svg>
            <span>Đồng bộ thành công! Đã đồng bộ mới/cập nhật <strong><?= $count ?></strong> lịch dạy học từ hệ thống vnEdu.</span>
        </div>
    <?php elseif ($status === 'mock'): ?>
        <div class="alert alert-warning">
            <svg width="20" height="20" fill="none" stroke="currentColor" stroke-width="2" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" d="M12 9v2m0 4h.01m-6.938 4h13.856c1.54 0 2.502-1.667 1.732-3L13.732 4c-.77-1.333-2.694-1.333-3.464 0L3.34 16c-.77 1.333.192 3 1.732 3z"></path></svg>
            <span>Đồng bộ qua cơ chế <strong>Fail-safe (Giả lập)</strong> thành công do phiên đăng nhập vnEdu hết hạn. Đã nạp <strong><?= $count ?></strong> bản ghi để chạy thử nghiệm.</span>
        </div>
    <?php elseif ($status === 'error'): ?>
        <div class="alert alert-danger">
            <svg width="20" height="20" fill="none" stroke="currentColor" stroke-width="2" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" d="M12 9v2m0 4h.01m-6.938 4h13.856c1.54 0 2.502-1.667 1.732-3L13.732 4c-.77-1.333-2.694-1.333-3.464 0L3.34 16c-.77 1.333.192 3 1.732 3z"></path></svg>
            <span><strong>Đồng bộ thất bại:</strong> <?= htmlspecialchars($message) ?></span>
        </div>
    <?php endif; ?>

    <!-- Bộ điều khiển đồng bộ và tìm kiếm -->
    <div class="control-panel">
        <form action="sync_schedules.php" method="GET" class="control-form">
            <!-- Chọn Giáo viên -->
            <div class="form-group">
                <label for="giao_vien_id">Giáo viên đồng bộ</label>
                <select name="giao_vien_id" id="giao_vien_id">
                    <?php foreach ($teachers as $t): ?>
                        <option value="<?= $t['id'] ?>" <?= $filter_teacher == $t['id'] ? 'selected' : '' ?>><?= htmlspecialchars($t['id'] . " (" . $t['full_name'] . ")") ?></option>
                    <?php endforeach; ?>
                </select>
            </div>

            <!-- Chọn Tuần học -->
            <div class="form-group">
                <label for="tuan_hoc">Tuần học</label>
                <select name="tuan_hoc" id="tuan_hoc">
                    <?php for ($i = 1; $i <= 35; $i++): ?>
                        <option value="<?= $i ?>" <?= $filter_week == $i || ($filter_week == 0 && $i == 1) ? 'selected' : '' ?>>Tuần <?= $i ?></option>
                    <?php endfor; ?>
                </select>
            </div>

            <!-- Nút bấm đồng bộ -->
            <button type="submit" class="btn-sync">
                <span>🔄 LẤY KHDH & LỊCH DẠY từ vnEdu</span>
            </button>
        </form>
    </div>

    <!-- Bộ lọc hiển thị ngay trên Server / Client -->
    <div class="control-panel" style="margin-top: -15px; padding: 16px 24px; background-color: #f1f5f9; border-color: #cbd5e1;">
        <form action="manage_schedules.php" method="GET" style="display: flex; gap: 20px; align-items: center; flex-wrap: wrap;">
            <input type="hidden" name="teacher_id" value="<?= htmlspecialchars($filter_teacher) ?>">
            <input type="hidden" name="week_num" value="<?= htmlspecialchars($filter_week) ?>">

            <span style="font-size: 13px; font-weight: 700; color: #475569; text-transform: uppercase;">Bộ lọc hiển thị:</span>
            


            <!-- Combo Buổi -->
            <div style="display: flex; align-items: center; gap: 8px;">
                <label for="shift_filter" style="font-size: 13px; font-weight: 500;">Buổi:</label>
                <select name="shift_filter" id="shift_filter" onchange="this.form.submit()" style="padding: 6px 12px; border-radius: 6px; border: 1px solid #cbd5e1; font-size: 13px;">
                    <option value="">-- Tất cả --</option>
                    <option value="Sáng" <?= $filter_shift == 'Sáng' ? 'selected' : '' ?>>Sáng</option>
                    <option value="Chiều" <?= $filter_shift == 'Chiều' ? 'selected' : '' ?>>Chiều</option>
                </select>
            </div>

            <!-- Combo Môn -->
            <div style="display: flex; align-items: center; gap: 8px;">
                <label for="subject_filter" style="font-size: 13px; font-weight: 500;">Môn học:</label>
                <select name="subject_filter" id="subject_filter" onchange="this.form.submit()" style="padding: 6px 12px; border-radius: 6px; border: 1px solid #cbd5e1; font-size: 13px;">
                    <option value="">-- Tất cả --</option>
                    <?php foreach ($subjects_list as $sub): ?>
                        <option value="<?= $sub['id'] ?>" <?= $filter_subject == $sub['id'] ? 'selected' : '' ?>>
                            <?= htmlspecialchars($sub['subject_name']) ?>
                        </option>
                    <?php endforeach; ?>
                </select>
            </div>

            <!-- Combo Tiết -->
            <div style="display: flex; align-items: center; gap: 8px;">
                <label for="period_filter" style="font-size: 13px; font-weight: 500;">Tiết buổi:</label>
                <select name="period_filter" id="period_filter" onchange="this.form.submit()" style="padding: 6px 12px; border-radius: 6px; border: 1px solid #cbd5e1; font-size: 13px;">
                    <option value="0">-- Tất cả --</option>
                    <?php for ($i = 1; $i <= 5; $i++): ?>
                        <option value="<?= $i ?>" <?= $filter_period == $i ? 'selected' : '' ?>>Tiết <?= $i ?></option>
                    <?php endfor; ?>
                </select>
            </div>

            <?php if (!empty($filter_teacher) || $filter_week > 0 || !empty($filter_shift) || !empty($filter_subject) || $filter_period > 0): ?>
                <a href="manage_schedules.php" style="font-size: 13px; color: var(--danger); text-decoration: none; font-weight: 500;">Xóa bộ lọc</a>
            <?php endif; ?>
        </form>
    </div>

    <!-- Bảng Đối soát tiến độ lịch dạy học -->
    <div class="table-panel">
        <div class="table-header">
            <h2>Bảng Đối soát Tiến độ Dạy học (Khối 2)</h2>
            <span>Tổng cộng: <?= count($schedules) ?> tiết dạy</span>
        </div>

        <div class="table-responsive">
            <?php if (empty($schedules)): ?>
                <div class="empty-state">
                    <svg fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="1.5" d="M9 5H7a2 2 0 00-2 2v12a2 2 0 002 2h10a2 2 0 002-2V7a2 2 0 00-2-2h-2M9 5a2 2 0 002 2h2a2 2 0 002-2M9 5a2 2 0 012-2h2a2 2 0 012 2m-3 7h3m-3 4h3m-6-4h.01M9 16h.01"></path></svg>
                    <h3>Chưa có dữ liệu lịch dạy học</h3>
                    <p>Vui lòng nhấn nút ở trên để bắt đầu đồng bộ và kéo lịch dạy học từ hệ thống vnEdu về.</p>
                </div>
            <?php else: ?>
                <table>
                    <thead>
                        <tr>
                            <th>Tiết PPCT</th>
                            <th>Tuần</th>
                            <th>Lớp</th>
                            <th>Môn học</th>
                            <th>Bài dạy thực tế</th>
                            <th>Thời gian dạy</th>
                            <th>Thứ</th>
                            <th>Buổi</th>
                            <th>Tiết</th>
                            <th>Giáo viên phụ trách</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach ($schedules as $s): ?>
                            <tr>
                                <td>
                                    <span class="badge-period"><?= $s['period_number'] ?></span>
                                </td>
                                <td>
                                    <span class="badge-week"><?= $s['week_number'] ?></span>
                                </td>
                                <td style="font-weight: 600; color: #1e293b;">
                                    <?= htmlspecialchars($s['class_name'] ? $s['class_name'] : "Lớp " . $s['class_id']) ?>
                                </td>
                                <td style="font-weight: 500;">
                                    <?= htmlspecialchars($s['subject_name'] ? $s['subject_name'] : "Môn " . $s['subject_id']) ?>
                                </td>
                                <td style="color: #334155; max-width: 320px; overflow: hidden; text-overflow: ellipsis; white-space: nowrap;">
                                    <strong><?= htmlspecialchars($s['lesson_title']) ?></strong>
                                </td>
                                <td>
                                    <?= htmlspecialchars(date('d/m/Y', strtotime($s['session_date']))) ?>
                                </td>
                                <td style="font-weight: 500;">
                                    Thứ <?= htmlspecialchars($s['day_of_week'] == 8 ? 'CN' : $s['day_of_week']) ?>
                                </td>
                                <td>
                                    <span class="badge-shift <?= mb_strtolower($s['shift']) == 'chiều' ? 'chieu' : 'sang' ?>"><?= htmlspecialchars($s['shift']) ?></span>
                                </td>
                                <td style="font-weight: 600; color: var(--accent);">
                                    <?= htmlspecialchars($s['session_period']) ?>
                                </td>
                                <td style="font-size: 13px; color: var(--text-muted);">
                                    <?= htmlspecialchars($s['teacher_name'] ? $s['teacher_name'] : "ID: " . $s['teacher_id']) ?>
                                </td>
                            </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            <?php endif; ?>
        </div>
    </div>
</div>

</body>
</html>
