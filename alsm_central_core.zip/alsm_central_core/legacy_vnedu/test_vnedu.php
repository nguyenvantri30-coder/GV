<?php
/**
 * File: test_vnedu.php
 * Mục đích: Quét tất cả các biến Object ({}) chứa thông tin học sinh thực tế quanh mã HS
 */

require_once __DIR__ . '/core.php';

try {
    $ss = get_valid_vnedu_session();
    
    $namHocGoc = 2025; $khoi = '7'; $lopId = '5003238264'; $monId = '11'; $thang = '13-2025'; $muc = 'ck1';

    $apiUrl = "https://mevzecuvssitessgddaknong.vnedu.vn/v5/?load=edu.so_diem.nhap&app_nam_hoc=" . $namHocGoc . "&my_token=" . $ss['my_token'];

    $payload = [
        'my_token' => $ss['my_token'], 'my_user_id' => $ss['my_user_id'], 'app_nam_hoc' => $namHocGoc,
        'winid' => '2848a8a588ed399dc351ffb1f00ec6cf', 'nam_hoc' => $namHocGoc, 'iLopId' => $lopId,
        'iKhoi' => $khoi, 'iMonHocId' => $monId, 'iHocKyId' => 1, 'deleteMode' => '0',
        'thang' => $thang, 'muc' => $muc, 'dot_diem_id' => '0', 'dot_diem_data' => '',
        'dot_id' => '1', 'dm_cua_mon_hoc' => '0', 'dm_cua_khoi_hoc' => '0', 'dm_cua_toi' => '1'
    ];

    $headers = [
        'Content-Type: application/x-www-form-urlencoded; charset=UTF-8',
        'User-Agent: Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36',
        'X-Requested-With: XMLHttpRequest',
        'Referer: https://mevzecuvssitessgddaknong.vnedu.vn/v5/'
    ];

    $response = vnedu_curl_request($apiUrl, 'POST', http_build_query($payload), $headers);

    echo "<h2>=== DÒ TÌM BIẾN CHỨA DATA HỌC SINH & ĐIỂM ===</h2>";
    
    $targetHs = '2411532639';
    $posHs = strpos($response, $targetHs);

    if ($posHs !== false) {
        echo "<p style='color:green;'>Tìm thấy mã học sinh tại vị trí: <b>$posHs</b></p>";
        
        // Chiến thuật: Quét ngược lên trước vị trí mã học sinh 5000 ký tự để tìm các khai báo biến Javascript
        $startScan = max(0, $posHs - 5000);
        $scanZone = substr($response, $startScan, 6000);
        
        // Tìm tất cả các biến dạng var abc = { hoặc var abc = [ trong vùng này
        preg_match_all('/var\s+([a-zA-Z0-9_]+)\s*=\s*([\[\{])/i', $scanZone, $matches, PREG_OFFSET_CAPTURE);
        
        if (!empty($matches[1])) {
            echo "<h3>Các biến dữ liệu được khai báo gần vùng chứa học sinh:</h3>";
            echo "<table border='1' cellpadding='8' style='border-collapse:collapse; font-family:monospace;'>";
            echo "<tr style='background:#eee;'><th>Tên Biến</th><th>Loại</th><th>Nội dung xem trước (120 ký tự)</th></tr>";
            
            foreach ($matches[1] as $index => $match) {
                $varName = $match[0];
                $varType = $matches[2][$index][0] === '[' ? 'Mảng []' : 'Object {}';
                $localOffset = $match[1];
                
                $preview = substr($scanZone, $localOffset, 120);
                
                // Highlight các biến tiềm năng
                $style = (strpos($varName, 'LopHoc') !== false) ? "color:#888;" : "color:red; font-weight:bold;";
                
                echo "<tr>";
                echo "<td style='$style'>$varName</td>";
                echo "<td>$varType</td>";
                echo "<td><pre style='margin:0; background:#f9f9f9; padding:5px;'>" . htmlspecialchars($preview) . "</pre></td>";
                echo "</tr>";
            }
            echo "</table>";
        } else {
            echo "Không tìm thấy biến Javascript nào khai báo bằng từ khóa <code>var</code> ở vùng này.";
        }
    } else {
        echo "<p style='color:red;'>Không tìm thấy mã học sinh để làm mốc định vị.</p>";
    }

} catch (Exception $e) {
    echo "Lỗi: " . $e->getMessage();
}