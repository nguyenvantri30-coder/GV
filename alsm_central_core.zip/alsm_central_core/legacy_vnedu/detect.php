<?php
header('Content-Type: text/html; charset=utf-8');

$files = ['core.php', 'get_giaovien.php', 'test_panel.html'];

echo "<h3>🔍 KIỂM TRA KÝ TỰ BOM ẨN TRONG CÁC FILE:</h3>";

foreach ($files as $fileName) {
    if (!file_exists($fileName)) {
        echo "File $fileName không tồn tại.<br>";
        continue;
    }
    
    $content = file_get_contents($fileName);
    // 3 byte đầu tiên của UTF-8 BOM là EF BB BF
    $bom = substr($content, 0, 3);
    
    if ($bom === "\xEF\xBB\xBF") {
        echo "❌ File <b>$fileName</b>: <span style='color:red;font-weight:bold;'>Phát hiện có ký tự BOM ẩn ở đầu file!</span><br>";
    } else {
        echo "✅ File <b>$fileName</b>: <span style='color:green;'>Sạch sẽ, không có BOM.</span><br>";
    }
    
    // Kiểm tra xem có khoảng trắng trước <?php không
    if (strpos($content, '<?php') > 0) {
        echo "⚠️ File <b>$fileName</b>: <span style='color:orange;'>Có khoảng trắng hoặc dòng trống nằm TRƯỚC thẻ &lt;?php</span><br>";
    }
}