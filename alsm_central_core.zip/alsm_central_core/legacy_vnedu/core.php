<?php
// Thư mục lưu cấu hình bảo mật
define('VNEDU_DATA_DIR', __DIR__ . DIRECTORY_SEPARATOR . 'data_secure' . DIRECTORY_SEPARATOR);
if (!is_dir(VNEDU_DATA_DIR)) { @mkdir(VNEDU_DATA_DIR, 0755, true); }

// Hàm gửi cURL dùng chung cho toàn bộ hệ thống (Bổ sung tham số $cookieFile để phân tách)
function vnedu_curl_request($url, $method = 'GET', $dataPost = null, $headers = [], $cookieFile = null) {
    // Nếu không truyền cookieFile riêng, mặc định dùng file global chung (bảo phòng)
    if (empty($cookieFile)) {
        $cookieFile = VNEDU_DATA_DIR . 'cookie_global_jar.txt';
    }
    
    $ch = curl_init();
    curl_setopt($ch, CURLOPT_URL, $url);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    curl_setopt($ch, CURLOPT_FOLLOWLOCATION, true);
    curl_setopt($ch, CURLOPT_MAXREDIRS, 5);
    curl_setopt($ch, CURLOPT_COOKIEJAR, $cookieFile);  // Lưu cookie của năm này
    curl_setopt($ch, CURLOPT_COOKIEFILE, $cookieFile); // Đọc cookie của năm này
    curl_setopt($ch, CURLOPT_USERAGENT, 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36');
    curl_setopt($ch, CURLOPT_TIMEOUT, 30);
    curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);

    if (strtoupper($method) === 'POST') {
        curl_setopt($ch, CURLOPT_POST, true);
        curl_setopt($ch, CURLOPT_POSTFIELDS, $dataPost);
    }
    
    if (!empty($headers)) {
        curl_setopt($ch, CURLOPT_HTTPHEADER, $headers);
    }
    
    $result = curl_exec($ch);
    curl_close($ch);
    return $result;
}

// HÀM CỐT LÕI NÂNG CẤP: Phân tách hoàn toàn Session & Cookie theo năm học
function get_valid_vnedu_session($target_nam_hoc = null) {
    // 1. Tự động tính toán năm học mặc định dựa trên tháng hiện tại nếu để trống
    if (empty($target_nam_hoc)) {
        $thangHienTai = (int)date('m');
        $target_nam_hoc = ($thangHienTai < 8) ? (date('Y') - 1) : date('Y');
    }
    $target_nam_hoc = intval($target_nam_hoc);

    // 🌟 ĐỊNH NGHĨA FILE CACHE ĐỘC LẬP THEO NĂM HỌC
    $sessionFile = VNEDU_DATA_DIR . "session_{$target_nam_hoc}.json";
    $cookieFile  = VNEDU_DATA_DIR . "cookie_{$target_nam_hoc}_jar.txt";

    // 2. Nếu đã có phiên làm việc của năm này -> Kiểm tra xem Token còn sống không
    if (file_exists($sessionFile) && file_exists($cookieFile)) {
        $session = json_decode(file_get_contents($sessionFile), true);
        
        if ($session && !empty($session['my_token'])) {
            // Gọi thử auth.check để kiểm tra trạng thái token của năm học này
            $testUrl = "https://mevzecuvssitessgddaknong.vnedu.vn/v5/?" . http_build_query([
                'call' => 'auth.check',
                'app_nam_hoc' => $target_nam_hoc,
                'my_token' => $session['my_token'],
                'my_user_id' => $session['my_user_id'],
                'user_id' => $session['my_user_id']
            ]);
            
            $res = vnedu_curl_request($testUrl, 'POST', null, [
                'X-Requested-With: XMLHttpRequest',
                'Content-Type: application/x-www-form-urlencoded'
            ], $cookieFile); // Truyền đúng file cookie của năm học
            
            $resData = json_decode($res, true);
            if (isset($resData['success']) && $resData['success'] == 1) {
                // Đính kèm luôn đường dẫn file cookie vào session trả về để file con tiện sử dụng
                $session['cookie_file_path'] = $cookieFile; 
                return $session; 
            }
        }
    }

    // 3. Nếu chưa có hoặc phiên của năm này đã chết -> TIẾN HÀNH ĐĂNG NHẬP RIÊNG CHO NĂM ĐÓ
    $initUrl = "https://user.vnedu.vn/sso/login?app_id=1&continue=aHR0cDovL2RpZW5kYW4udm5lZHUudm4vc2VjdXJpdHkvc3NvVm5lZHU=";
    $initHtml = vnedu_curl_request($initUrl, 'GET', null, [], $cookieFile);
    preg_match('/jtoken\s*=\s*["\']([^"\']+)["\']/', $initHtml, $jtMatch);
    preg_match('/jcode\s*=\s*["\']([^"\']+)["\']/', $initHtml, $jcMatch);
    
    $jtoken = !empty($jtMatch[1]) ? $jtMatch[1] : "0.3408331684782986";
    $jcode  = !empty($jcMatch[1]) ? $jcMatch[1] : "216de97e0eb590f76bc04d71cf8a4c9a";

    // POST Đăng nhập ẩn qua SSO
    $loginUrl = "https://user.vnedu.vn/sso/?call=auth.login&jtoken={$jtoken}&jcode={$jcode}";
    $payload = http_build_query([
        'continue' => 'aHR0cDovL2RpZW5kYW4udm5lZHUudm4vc2VjdXJpdHkvc3NvVm5lZHU=',
        'app_id' => '1',
        'loginQrToken' => 'VNEDU001DB6C81828EF858C6A6395DAB00CE7F66',
        'txtUsername' => 'nvt.duyen', 
        'txtPassword' => 'Vnedu0336395105@#',
        'txtCaptcha' => ''
    ]);
    vnedu_curl_request($loginUrl, 'POST', $payload, [], $cookieFile);

    // Khởi tạo app_nam_hoc cụ thể trên phân hệ v5 của vnEdu
    $schoolUrl = "https://mevzecuvssitessgddaknong.vnedu.vn/v5/?app_nam_hoc=" . $target_nam_hoc;
    $htmlContent = vnedu_curl_request($schoolUrl, 'GET', null, [], $cookieFile);

    $tokenToken = ''; $myUserId = ''; 

    if (preg_match_all('/\b[a-f0-9]{32}\b/i', $htmlContent, $hashes)) { $tokenToken = end($hashes[0]); }
    if (preg_match_all('/\b\d{9,11}\b/', $htmlContent, $ids)) {
        foreach ($ids[0] as $id) { if (strlen($id) >= 9) { $myUserId = $id; break; } }
    }

    if (!empty($tokenToken) && !empty($myUserId)) {
        $newSession = [
            'my_token'   => $tokenToken,
            'my_user_id' => $myUserId,
            'nam_hoc'    => $target_nam_hoc,
            'updated_at' => time()
        ];
        file_put_contents($sessionFile, json_encode($newSession));
        $newSession['cookie_file_path'] = $cookieFile;
        return $newSession;
    }

    throw new Exception("Không thể khởi tạo phiên đăng nhập vnEdu động cho năm học " . $target_nam_hoc);
}

/**
 * Hàm lọc danh sách bản ghi theo các trường tùy chọn
 * @param array $rawData Mảng dữ liệu thô gồm nhiều bản ghi (ví dụ: $dataArray['aRoot'])
 * @param array|string $fields Danh sách các trường muốn lấy (Mảng hoặc Chuỗi phân cách bằng dấu phẩy)
 * @param array $mappingArr Mảng cấu hình ánh xạ đổi tên key nếu cần (gốc => tên mới)
 * @return array Mảng dữ liệu đã được lọc sạch đúng các trường yêu cầu
 */
function filter_api_fields($rawData, $fields = [], $mappingArr = []) {
    if (!is_array($rawData)) return [];
    
    // Xử lý chuyển đổi chuỗi fields thành mảng
    if (is_string($fields) && !empty($fields)) {
        $fields = array_map('trim', explode(',', $fields));
    } elseif (empty($fields)) {
        $fields = [];
    }
    
    $takeAll = empty($fields) ? true : false;
    $result = [];
    
    foreach ($rawData as $item) {
        $row = [];
        
        if ($takeAll) {
            // Trường hợp lấy TẤT CẢ: Áp dụng đặt lại tên theo mapping, các trường khác giữ nguyên bản
            foreach ($item as $key => $value) {
                $finalKey = isset($mappingArr[$key]) ? $mappingArr[$key] : $key;
                $row[$finalKey] = $value;
            }
            // Đảm bảo các thuộc tính trong mapping không bị bỏ sót nếu key gốc viết kiểu khác
            foreach ($mappingArr as $originKey => $targetKey) {
                if (isset($item[$originKey])) {
                    $row[$targetKey] = $item[$originKey];
                }
            }
        } else {
            // Trường hợp lọc trường cụ thể theo danh sách yêu cầu
            foreach ($fields as $field) {
                $originalKey = array_search($field, $mappingArr);
                if ($originalKey !== false && isset($item[$originalKey])) {
                    $row[$field] = $item[$originalKey];
                } elseif (isset($item[$field])) {
                    $row[$field] = $item[$field];
                } else {
                    $row[$field] = '';
                }
            }
        }
        $result[] = $row;
    }
    return $result;
}

/**
 * Hàm lọc dữ liệu mảng phẳng theo điều kiện động từ URL (Dùng chung cho mọi file con)
 * Quy ước tham số truyền lên URL: ?filter=ten_truong=gia_tri (Ví dụ: ?filter=ten_lop=6A1)
 */
function vnedu_filter_data($dataMảngFlatted) {
    // 1. Kiểm tra nếu mảng rỗng hoặc không có tham số filter trên URL thì trả về luôn
    if (empty($dataMảngFlatted) || !is_array($dataMảngFlatted) || !isset($_GET['filter'])) {
        return $dataMảngFlatted;
    }

    $filterParam = trim($_GET['filter']);
    if (empty($filterParam) || strpos($filterParam, '=') === false) {
        return $dataMảngFlatted;
    }

    // 2. Tách tên cột và giá trị cần lọc (Chỉ tách ở dấu '=' đầu tiên để an toàn)
    list($key, $value) = explode('=', $filterParam, 2);
    $key   = trim($key);
    $value = trim($value);

    if ($key === '' || $value === '') {
        return $dataMảngFlatted;
    }

    // 3. Thực hiện lọc mảng (Hỗ trợ lọc tương đối, không phân biệt hoa thường nếu là chuỗi)
    $filtered = array_filter($dataMảngFlatted, function($item) use ($key, $value) {
        if (!isset($item[$key])) {
            return false;
        }
        
        $itemValue = (string)$item[$key];
        
        // Nếu giá trị cần tìm là số thuần, ưu tiên so sánh tuyệt đối
        if (is_numeric($value) && is_numeric($itemValue)) {
            return floatval($itemValue) == floatval($value);
        }
        
        // Nếu là chuỗi, tìm kiếm tương đối (chứa từ khóa) và không phân biệt hoa thường
        return mb_strpos(mb_strtolower($itemValue), mb_strtolower($value)) !== false;
    });

    // 4. Reset lại chỉ số mảng 0, 1, 2... và trả về
    return array_values($filtered);
}