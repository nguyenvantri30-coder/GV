<!DOCTYPE html>
<html lang="vi">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>vnEdu API Test Panel - AISGK Plugin</title>
    <style>
        body {
            font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, Helvetica, Arial, sans-serif;
            background-color: #f5f7fb;
            color: #333;
            margin: 0;
            padding: 20px;
        }
        .container {
            max-width: 1200px;
            margin: 0 auto;
        }
        h2 {
            color: #1e293b;
            border-bottom: 2px solid #e2e8f0;
            padding-bottom: 10px;
        }
        .grid {
            display: grid;
            grid-template-columns: 1fr 2fr;
            gap: 20px;
            margin-top: 20px;
        }
        .menu-panel {
            background: #fff;
            padding: 20px;
            border-radius: 8px;
            box-shadow: 0 4px 6px -1px rgba(0,0,0,0.1);
        }
        .result-panel {
            background: #fff;
            padding: 20px;
            border-radius: 8px;
            box-shadow: 0 4px 6px -1px rgba(0,0,0,0.1);
            display: flex;
            flex-direction: column;
        }
        .api-item {
            display: flex;
            justify-content: space-between;
            align-items: center;
            padding: 12px;
            margin-bottom: 10px;
            background: #f8fafc;
            border: 1px solid #e2e8f0;
            border-radius: 6px;
            transition: all 0.2s;
        }
        .api-item:hover {
            border-color: #3b82f6;
            background: #eff6ff;
        }
        .api-info b {
            display: block;
            color: #1e293b;
        }
        .api-info span {
            font-size: 12px;
            color: #64748b;
            font-family: monospace;
        }
        button {
            background: #2563eb;
            color: #fff;
            border: none;
            padding: 8px 14px;
            border-radius: 4px;
            cursor: pointer;
            font-weight: 500;
            transition: background 0.2s;
        }
        button:hover {
            background: #1d4ed8;
        }
        button:disabled {
            background: #94a3b8;
            cursor: not-allowed;
        }
        .meta-info {
            display: flex;
            gap: 15px;
            margin-bottom: 10px;
            font-size: 13px;
        }
        .badge {
            padding: 3px 8px;
            border-radius: 4px;
            font-weight: bold;
        }
        .badge-time { background: #fee2e2; color: #991b1b; }
        .badge-status { background: #dcfce7; color: #166534; }
        pre {
            background: #0f172a;
            color: #38bdf8;
            padding: 15px;
            border-radius: 6px;
            overflow-x: auto;
            font-family: "Fira Code", Consolas, Monaco, monospace;
            font-size: 13px;
            flex-grow: 1;
            margin: 0;
            min-height: 400px;
            max-height: 600px;
        }
    </style>
</head>
<body>

<div class="container">
    <h2>🛠️ vnEdu API Test Dashboard (AISGK Engine)</h2>
    <p style="color: #64748b; margin-top: -5px;">Hệ thống kiểm thử nhanh luồng đồng bộ dữ liệu từ phân hệ v5 sang Moodle local.</p>

    <div class="grid">
        <div class="menu-panel">
            <h3 style="margin-top: 0; color: #334155;">Danh sách hàm test</h3>
            
            <div class="api-item">
                <div class="api-info">
                    <b>1. Danh sách Giáo viên</b>
                    <span>get_giaovien.php</span>
                </div>
                <button onclick="runTest('get_giaovien.php')">Gọi API</button>
            </div>

            <div class="api-item">
                <div class="api-info">
                    <b>2. Danh sách Lớp học</b>
                    <span>get_lop.php</span>
                </div>
                <button onclick="runTest('get_lop.php')">Gọi API</button>
            </div>

            <div class="api-item">
                <div class="api-info">
                    <b>3. Danh sách Học sinh</b>
                    <span>get_hocsinh.php</span>
                </div>
                <button onclick="runTest('get_hocsinh.php')">Gọi API</button>
            </div>

            <div class="api-item">
                <div class="api-info">
                    <b>4. Sổ Điểm học tập</b>
                    <span>get_diem.php</span>
                </div>
                <button onclick="runTest('get_diem.php')">Gọi API</button>
            </div>

            <div class="api-item">
                <div class="api-info">
                    <b>5. Phân công giảng dạy</b>
                    <span>get_phancong.php</span>
                </div>
                <button onclick="runTest('get_phancong.php')">Gọi API</button>
            </div>

            <div class="api-item">
                <div class="api-info">
                    <b>6. Kế hoạch / Lịch báo giảng</b>
                    <span>get_lichbaogiang.php</span>
                </div>
                <button onclick="runTest('get_lichbaogiang.php')">Gọi API</button>
            </div>
        </div>

        <div class="result-panel">
            <h3 style="margin-top: 0; color: #334155;">Phản hồi hệ thống (JSON Response)</h3>
            <div class="meta-info">
                <div id="loadingStatus" style="display:none; color: #eab308; font-weight: bold;">⏳ Đang kết nối vnEdu...</div>
                <div id="metaSpeed" class="badge badge-time" style="display:none;">Thời gian xử lý: 0ms</div>
                <div id="metaStatus" class="badge badge-status" style="display:none;">HTTP 200</div>
            </div>
            <pre id="jsonViewer">// Chọn một hàm bất kỳ ở menu bên trái để thực hiện gọi dữ liệu ngầm...</pre>
        </div>
    </div>
</div>

<script>
function runTest(fileName) {
    const jsonViewer = document.getElementById('jsonViewer');
    const loadingStatus = document.getElementById('loadingStatus');
    const metaSpeed = document.getElementById('metaSpeed');
    const metaStatus = document.getElementById('metaStatus');
    
    // Khởi tạo trạng thái chờ
    jsonViewer.textContent = '// Đang thực thi yêu cầu ngầm thông qua core.php... Vui lòng đợi...';
    loadingStatus.style.display = 'block';
    metaSpeed.style.display = 'none';
    metaStatus.style.display = 'none';
    
    // Đo thời gian bắt đầu request
    const startTime = performance.now();
    
    // Thực hiện Fetch API gọi đến file PHP tương ứng
    fetch(fileName)
        .then(response => {
            metaStatus.textContent = 'HTTP ' + response.status;
            metaStatus.style.display = 'block';
            metaStatus.style.className = response.ok ? 'badge badge-status' : 'badge badge-time';
            return response.text(); // Đọc dạng text trước đề phòng file PHP lỗi cú pháp (báo lỗi chuỗi trắng)
        })
        .then(text => {
            const endTime = performance.now();
            const duration = Math.round(endTime - startTime);
            metaSpeed.textContent = `Thời gian phản hồi: ${duration} ms`;
            metaSpeed.style.display = 'block';
            loadingStatus.style.display = 'none';
            
            try {
                // Thử giải mã chuỗi text nhận được thành JSON định dạng thụt lề 4 dấu cách
                const json = JSON.parse(text);
                jsonViewer.textContent = JSON.stringify(json, null, 4);
            } catch (e) {
                // Nếu PHP bị lỗi chết (Fatal Error/Parse Error) thì in thô mã nguồn lỗi ra để lập trình viên sửa
                jsonViewer.textContent = "⚠ LỖI TRẢ VỀ KHÔNG PHẢI JSON THUẦN (Có thể file PHP của bạn đang bị lỗi cú pháp):\n\n" + text;
            }
        })
        .catch(error => {
            loadingStatus.style.display = 'none';
            jsonViewer.textContent = "❌ Lỗi kết nối mạng: " + error.message;
        });
}
</script>

</body>
</html>