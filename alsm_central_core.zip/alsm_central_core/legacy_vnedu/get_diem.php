<?php
/**
 * File: get_diem.php
 * Chức năng: Trích xuất dữ liệu điểm chi tiết từ mã nguồn HTML phân hệ `edu.so_diem.nhap`
 * Logic: Tự động rẽ nhánh Endpoint và tham số giữa v5 (Năm hiện tại) và v3 (Các năm cũ lịch sử)
 */

require_once __DIR__ . '/core.php';

function get_diem_thuc_chien($khoi, $lopId, $monId, $hocKy, $filterIdHs = [], $fields = [], $namHocGocInput = null) {
    try {
        // 1. Lấy Session/Token hợp lệ từ hệ thống lõi core.php
        $ss = get_valid_vnedu_session($namHocGocInput); 
        
        $hocKy = (!empty($hocKy)) ? intval($hocKy) : 1;
        $khoi  = (!empty($khoi)) ? trim($khoi) : '6';
        $namHocGoc = isset($ss['nam_hoc']) ? intval($ss['nam_hoc']) : 2025; 

        // 2. Tính toán năm hiện tại thực tế của hệ thống để làm mốc rẽ nhánh v5/v3
        $thangHienTai = (int)date('m');
        $namHienTaiThucTe = ($thangHienTai < 8) ? (date('Y') - 1) : date('Y');

        // Định cấu hình tham số tháng và mục theo học kỳ để vnEdu trả về đúng bảng
        if ($hocKy === 2) {
            $namHocHk = $namHocGoc + 1; 
            $thang    = "222-" . $namHocHk;
            $muc      = 'gk2'; 
        } else {
            $thang    = "13-" . $namHocGoc; 
            $muc      = 'ck1';
        }

        // 🌟 3. PHÂN TÁCH ENDPOINT VÀ PAYLOAD TUYỆT ĐỐI THEO PHIÊN BẢN NĂM HỌC
        $versionDir = '';
        $payload = [];

        if ($namHocGoc == $namHienTaiThucTe) {
            // --- ĐƯỜNG TRUYỀN V5 ĐỘNG: DÀNH CHO NĂM HIỆN TẠI ---
            $versionDir = 'v5';
            $payload = [
                'my_token'        => $ss['my_token'],
                'my_user_id'      => $ss['my_user_id'],
                'app_nam_hoc'     => $namHocGoc,
                'winid'           => '2848a8a588ed399dc351ffb1f00ec6cf',
                'nam_hoc'         => $namHocGoc,
                'iLopId'          => $lopId,
                'iKhoi'           => $khoi,
                'iMonHocId'       => $monId,
                'iHocKyId'        => $hocKy,
                'deleteMode'      => '0',
                'thang'           => $thang,
                'muc'             => $muc,
                'dot_diem_id'     => '0',
                'dot_diem_data'   => '',
                'dot_id'          => '1',
                'dm_cua_mon_hoc'  => '0',
                'dm_cua_khoi_hoc' => '0',
                'dm_cua_toi'      => '1'
            ];
        } else {
            // --- ĐƯỜNG TRUYỀN V3 TĨNH: DÀNH CHO CÁC NĂM CŨ LỊCH SỬ ---
            $versionDir = 'v3';
            $payload = [
                'my_token'        => $ss['my_token'],
                'my_user_id'      => $ss['my_user_id'],
                'app_nam_hoc'     => $namHocGoc,
                'nam_hoc'         => $namHocGoc,
                'iLopId'          => $lopId,
                'iKhoi'           => $khoi,
                'iMonHocId'       => $monId,
                'iHocKyId'        => $hocKy,
                'deleteMode'      => '0',
                'thang'           => $thang,
                'muc'             => $muc,
                'dot_diem_id'     => '0',
                'dot_diem_data'   => '',
                'dot_id'          => '1',
                'dm_cua_mon_hoc'  => '0',
                'dm_cua_khoi_hoc' => '0',
                'dm_cua_toi'      => '1'
                // Tối giản cấu hình theo cơ chế nạp form cũ của core v3
            ];
        }

        // Tạo API URL đích đồng bộ theo đúng phiên bản thư mục
        $apiUrl = "https://mevzecuvssitessgddaknong.vnedu.vn/{$versionDir}/?load=edu.so_diem.nhap&app_nam_hoc=" . $namHocGoc . "&my_token=" . $ss['my_token'];

        $headers = [
            'Content-Type: application/x-www-form-urlencoded; charset=UTF-8',
            'User-Agent: Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36',
            'X-Requested-With: XMLHttpRequest',
            'Referer: https://mevzecuvssitessgddaknong.vnedu.vn/' . $versionDir . '/'
        ];

        // 4. Gửi Request POST gọi giao diện nhập điểm từ vnEdu qua file Cookie độc lập
        $response = vnedu_curl_request($apiUrl, 'POST', http_build_query($payload), $headers, $ss['cookie_file_path']);

        if (empty($response)) {
            return ['success' => false, 'error' => "Dữ liệu phản hồi từ sổ điểm vnEdu ({$versionDir}) rỗng."];
        }

        // 5. Khởi tạo cây DOM để phân tích dữ liệu bằng XPath từ mã HTML nhận được
        $doc = new DOMDocument();
        libxml_use_internal_errors(true);
        $doc->loadHTML('<?xml encoding="UTF-8">' . $response);
        libxml_clear_errors();
        $xpath = new DOMXPath($doc);

        // Map cấu trúc định danh cột điểm dựa trên thuộc tính b (loại điểm) và c (số cột) của vnEdu
        $mapLoaiDiem = [
            '2_1' => 'tx1', '2_2' => 'tx2', '2_3' => 'tx3', '2_4' => 'tx4',
            '3_1' => 'gk',
            '4_1' => 'ck'
        ];

        // Tìm tất cả các dòng học sinh dựa trên cấu trúc thẻ tr có thuộc tính id là số
        $rows = $xpath->query("//table[contains(@class, 'tablefix')]/tbody/tr[@id]");
        $processedData = [];

        // Nếu không quét được dòng nào ở năm cũ, ép in ra debug để check lỗi giao diện html
        if ($rows->length === 0 && $namHocGoc != $namHienTaiThucTe) {
            header('Content-Type: application/json; charset=utf-8');
            echo json_encode([
                'success' => false,
                'msg' => 'Không tìm thấy bảng điểm tablefix trong HTML phản hồi của năm cũ v3.',
                'url_goi' => $apiUrl,
                'payload_sent' => $payload,
                'raw_html_preview' => mb_substr($response, 0, 2000) // Trích 2000 ký tự đầu xem lỗi
            ], JSON_UNESCAPED_UNICODE | JSON_PRETTY_PRINT);
            exit;
        }

        foreach ($rows as $row) {
            $studentId = trim($row->getAttribute('id'));
            
            // Kiểm tra tính hợp lệ của mã học sinh
            if (!is_numeric($studentId) || strlen($studentId) < 5) {
                continue; 
            }

            // Bộ lọc nhanh theo danh sách ID học sinh nếu phía Moodle truyền lên
            if (!empty($filterIdHs) && !in_array((int)$studentId, $filterIdHs)) {
                continue;
            }

            // Tạo mảng dữ liệu thô (chứa tất cả các trường có thể lấy được)
            $rawStudentData = [
                'id_hs'     => $studentId,
                'ho_dem'    => '',
                'ten'       => '',
                'ngay_sinh' => '',
                'tx1' => '', 'tx2' => '', 'tx3' => '', 'tx4' => '',
                'gk'        => '',
                'ck'        => '',
                'tbm'       => '',
                'nhan_xet'  => ''
            ];

            // Trích xuất Thông tin cá nhân (Họ đệm, Tên, Ngày sinh) dựa vào các ô td đầu tiên
            $tds = $row->getElementsByTagName('td');
            if ($tds->length >= 5) {
                $rawStudentData['ho_dem']    = trim($tds->item(2)->nodeValue);
                $rawStudentData['ten']       = trim($tds->item(3)->nodeValue);
                $rawStudentData['ngay_sinh'] = trim($tds->item(4)->nodeValue);
            }

            // Trích xuất các Cột Điểm Thành Phần thông qua các thẻ span có class `input_diem`
            $spans = $xpath->query(".//span[contains(@class, 'input_diem')]", $row);
            foreach ($spans as $span) {
                $b = $span->getAttribute('b');
                $c = $span->getAttribute('c');
                $keyDiem = "{$b}_{$c}";
                if (isset($mapLoaiDiem[$keyDiem])) {
                    $rawStudentData[$mapLoaiDiem[$keyDiem]] = trim($span->nodeValue);
                }
            }

            // Trích xuất Điểm Trung Bình Môn Học Kỳ (TBM)
            $tbmTd = $xpath->query(".//td[contains(@class, 'TBHK_tt')]", $row);
            if ($tbmTd->length > 0) {
                $rawStudentData['tbm'] = trim($tbmTd->item(0)->nodeValue);
            }

            // Trích xuất Nhận Xét của giáo viên bộ môn
            $nxTd = $xpath->query(".//td[contains(@title, 'ký tự')]", $row);
            if ($nxTd->length > 0) {
                $rawStudentData['nhan_xet'] = rtrim(trim($nxTd->item(0)->nodeValue), ',');
            }

            // --- 6. ÁP DỤNG LOGIC FIELDS ĐẦU RA ---
            if (!empty($fields)) {
                $filteredRow = [];
                foreach ($fields as $field) {
                    $field = trim($field);
                    $filteredRow[$field] = $rawStudentData[$field] ?? '';
                }
                $processedData[] = $filteredRow;
            } else {
                $processedData[] = $rawStudentData;
            }
        }

        return [
            'success' => true,
            'nam_hoc' => strtoupper($namHocGoc),
            'total'   => count($processedData),
            'data'    => $processedData
        ];

    } catch (Exception $e) {
        return ['success' => false, 'error' => $e->getMessage()];
    }
}

// --- THU THẬP THAM SỐ TỪ URL MOODLE ĐẨY SANG ---
$khoi   = $_GET['khoi'] ?? null;
$lopId  = $_GET['lop_id'] ?? null;
$monId  = $_GET['mon_id'] ?? null;
$hk     = $_GET['hk'] ?? null;
$namHoc = $_GET['nam_hoc'] ?? null; 

// Kiểm tra các tham số bắt buộc để định vị sổ điểm
if (!$khoi || !$lopId || !$monId || !$hk) {
    header('Content-Type: application/json; charset=utf-8');
    echo json_encode([
        'success' => false,
        'error'   => 'Thiếu tham số cấu hình bắt buộc để lấy điểm (khoi, lop_id, mon_id, hk).'
    ], JSON_UNESCAPED_UNICODE);
    exit;
}

// Xử lý tham số lọc danh sách học sinh cụ thể (?id_hs=2206836668,2206836665)
$idHsRaw = $_GET['id_hs'] ?? [];
$filterIdHs = [];
if (!empty($idHsRaw)) {
    $filterIdHs = is_array($idHsRaw) ? array_map('intval', $idHsRaw) : array_map('intval', explode(',', $idHsRaw));
}

// Xử lý tham số trường chọn lọc (?fields=id_hs,ten,tx1,tbm)
$fieldsRaw = $_GET['fields'] ?? '';
$fields = !empty($fieldsRaw) ? explode(',', $fieldsRaw) : [];

// 7. Trả kết quả định dạng JSON chuẩn hóa về cho Moodle
header('Content-Type: application/json; charset=utf-8');
$output = get_diem_thuc_chien($khoi, $lopId, $monId, $hk, $filterIdHs, $fields, $namHoc);

// 🌟 2. KIỂM TRA VÀ LỌC ĐÚNG MẢNG 'data' TRONG JSON
if (isset($output['data']) && is_array($output['data'])) {
    // Tiến hành lọc dữ liệu bên trong mảng data
    $output['data'] = vnedu_filter_data($output['data']);
    
    // Cập nhật lại số lượng đếm (total) sau khi đã lọc để Moodle nhận diện chuẩn
    if (isset($output['total'])) {
        $output['total'] = count($output['data']);
    }
}
echo json_encode($output, JSON_UNESCAPED_UNICODE | JSON_PRETTY_PRINT);