<?php
header('Content-Type: text/html; charset=utf-8');

$files = ['core.php', 'get_giaovien.php', 'test_panel.html'];

echo "<h3>🛠️ TIẾN HÀNH SỬA LỖI BOM VÀ KHOẢNG TRẮNG ĐẦU FILE:</h3>";

foreach ($files as $fileName) {
    if (!file_exists($fileName)) {
        echo "File $fileName không tồn tại.<br>";
        continue;
    }
    
    // Đọc toàn bộ nội dung file
    $content = file_get_contents($fileName);
    
    // 1. Cắt bỏ ký tự BOM (\xEF\xBB\xBF) nếu có ở đầu file
    if (substr($content, 0, 3) === "\xEF\xBB\xBF") {
        $content = substr($content, 3);
    }
    
    // 2. Gọt sạch mọi khoảng trắng, dấu cách, dòng trống ở đầu và cuối file
    $content = trim($content);
    
    // Lưu đè lại file sạch
    if (file_put_contents($fileName, $content) !== false) {
        echo "✅ Đã sửa thành công file: <b>$fileName</b> (Đã sạch BOM & Khoảng trắng)<br>";
    } else {
        echo "❌ Thất bại khi ghi file: <b>$fileName</b> (Vui lòng kiểm tra quyền ghi của thư mục)<br>";
    }
}

echo "<br><b>👉 Bây giờ bạn hãy chạy lại file detect.php hoặc bấm test thử xem kết quả nhé!</b>";