<?php
/**
 * File: get_giaovien.php
 * Chức năng: Trích xuất danh sách giáo viên theo năm học động.
 */

require_once __DIR__ . '/core.php';

function get_ds_giaovien($fields = [], $namHocGocInput = null) {
    try {
        // 1. Gọi core lấy đúng phiên làm việc và file cookie tương ứng của năm được yêu cầu
        $ss = get_valid_vnedu_session($namHocGocInput);
        
        $namHocGoc  = intval($ss['nam_hoc']);
        $cookieFile = $ss['cookie_file_path']; 

        // 2. Xây dựng tham số query, sử dụng chính xác năm học đã được switch
        $queryParams = [
            'call'        => 'vnedu.giaovien.api.getUser', 
            '_dc'         => round(microtime(true) * 1000), 
            'my_user_id'  => $ss['my_user_id'],
            'app_nam_hoc' => $namHocGoc, 
            'my_token'    => $ss['my_token'], 
            'nam_hoc'     => $namHocGoc, 
            'page'        => 1, 
            'start'       => 0, 
            'limit'       => 1000
        ];
        
        $apiUrl = "https://mevzecuvssitessgddaknong.vnedu.vn/v5/?" . http_build_query($queryParams);
        
        $headers = [
            'Accept: */*',
            'X-Requested-With: XMLHttpRequest',
            'Referer: https://mevzecuvssitessgddaknong.vnedu.vn/v5/'
        ];

        // 3. Gửi request cURL kèm theo file cookie độc lập của năm học đó
        $response = vnedu_curl_request($apiUrl, 'GET', null, $headers, $cookieFile);
        $dataArray = json_decode($response, true);

        if ($dataArray === null || !isset($dataArray['aRoot'])) {
            throw new Exception("Lỗi lấy danh sách giáo viên cho năm học " . $namHocGoc);
        }

        // Ma trận ánh xạ dữ liệu đầu ra để đưa sang Moodle
        $mapping = [
            'gv_id'     => 'gv_id',
            'full_name' => 'ten_gv'
        ];

        // 4. Gọi hàm helper từ core để lọc dữ liệu sạch
        $filteredData = filter_api_fields($dataArray['aRoot'], $fields, $mapping);
        
        return [
            'success' => true, 
            'nam_hoc' => $namHocGoc,
            'total'   => count($filteredData), 
            'data'    => $filteredData
        ];

    } catch (Exception $e) {
        return ['success' => false, 'error' => $e->getMessage()];
    }
}

// --- THU THẬP THAM SỐ TỪ URL ---
$namHocInput = $_GET['nam_hoc'] ?? null; 
$fieldsParam = isset($_GET['fields']) ? trim($_GET['fields']) : '';

// Xuất dữ liệu JSON trả về cho hệ thống chỉ khi chạy trực tiếp
if (basename($_SERVER['SCRIPT_FILENAME']) === 'get_giaovien.php') {
    header('Content-Type: application/json; charset=utf-8');
    $output = get_ds_giaovien($fieldsParam, $namHocInput);
    // 🌟 2. KIỂM TRA VÀ LỌC ĐÚNG MẢNG 'data' TRONG JSON
    if (isset($output['data']) && is_array($output['data'])) {
        // Tiến hành lọc dữ liệu bên trong mảng data
        $output['data'] = vnedu_filter_data($output['data']);
        
        // Cập nhật lại số lượng đếm (total) sau khi đã lọc để Moodle nhận diện chuẩn
        if (isset($output['total'])) {
            $output['total'] = count($output['data']);
        }
    }
    echo json_encode($output, JSON_UNESCAPED_UNICODE | JSON_PRETTY_PRINT);
}