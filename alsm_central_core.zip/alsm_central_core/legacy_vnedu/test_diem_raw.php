<?php
require_once __DIR__ . '/core.php';

function get_bang_diem_vnedu($lopId, $monId, $hocKy, $muc = 'ck1') {
    $ss = get_valid_vnedu_session();

    // Bước 1: Lấy danh sách cấu hình đầu điểm (để biết lớp có bao nhiêu cột điểm)
    $urlConfig = "https://mevzecuvssitessgddaknong.vnedu.vn/v5/?call=edu.config_nhap_diem_theo_dot.getListActive&nam_hoc=2025&my_token={$ss['my_token']}&hoc_ky={$hocKy}&khoi_id=6&lop_id={$lopId}&mon_id={$monId}";
    $resConfig = vnedu_curl_request($urlConfig, 'GET');
    
    // Bước 2: Lấy dữ liệu điểm chi tiết (POST)
    $urlDiem = "https://mevzecuvssitessgddaknong.vnedu.vn/v5/?load=edu.so_diem.nhap&app_nam_hoc=2025&my_token={$ss['my_token']}";
    $payload = [
        'my_token' => $ss['my_token'],
        'my_user_id' => $ss['my_user_id'],
        'iLopId' => $lopId,
        'iMonHocId' => $monId,
        'iHocKyId' => $hocKy,
        'muc' => $muc,
        'nam_hoc' => '2025'
    ];
    
    $resDiem = vnedu_curl_request($urlDiem, 'POST', http_build_query($payload));

    // Bước 3: Bóc tách dữ liệu từ chuỗi trả về
    // Trong kết quả trả về, vnEdu thường lưu JSON trong biến 'var aDiem' hoặc 'var aData'
    // Ta dùng Regex để lấy đoạn JSON đó ra
    preg_match('/var aData = (.*?);/', $resDiem, $matches);
    
    if (isset($matches[1])) {
        return json_decode($matches[1], true);
    }
    return ['error' => 'Không tìm thấy dữ liệu điểm trong phản hồi.'];
}

header('Content-Type: application/json; charset=utf-8');
echo json_encode(get_bang_diem_vnedu($_GET['lop_id'], $_GET['mon_id'], $_GET['hk']), JSON_UNESCAPED_UNICODE);