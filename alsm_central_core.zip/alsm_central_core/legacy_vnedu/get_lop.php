<?php
/**
 * File: get_lop.php
 * Chức năng: Trích xuất danh sách lớp học (Hỗ trợ chọn năm học động, độc lập luồng cookie)
 */

require_once __DIR__ . '/core.php';

function get_ds_lop($fields = [], $namHocGocInput = null) {
    try {
        // 1. Gọi core lấy đúng phiên làm việc và file cookie tương ứng của năm được yêu cầu
        $ss = get_valid_vnedu_session($namHocGocInput);
        
        $namHocGoc  = intval($ss['nam_hoc']);
        $cookieFile = $ss['cookie_file_path']; // Nhận file cookie biệt lập của năm học đó

        // 2. Xây dựng tham số query, sử dụng chính xác năm học đã được chọn
        $queryParams = [
            'call'        => 'edu.lop_hoc.getLopAndMonChuyen', 
            'nam_hoc'     => $namHocGoc,
            '_dc'         => round(microtime(true) * 1000), // Dùng timestamp miligiây thực tế chống cache tuyệt đối
            'my_user_id'  => $ss['my_user_id'], 
            'app_nam_hoc' => $namHocGoc, 
            'my_token'    => $ss['my_token']
        ];
        
        $apiUrl = "https://mevzecuvssitessgddaknong.vnedu.vn/v5/?" . http_build_query($queryParams) . "&app_status_lop_hoc=*";
        
        $headers = [
            'Content-Type: application/json', 
            'X-Requested-With: XMLHttpRequest',
            'Referer: https://mevzecuvssitessgddaknong.vnedu.vn/v5/'
        ];

        // 3. Gửi request POST kèm theo payload "[]" và FILE COOKIE RIÊNG BIỆT của năm đó
        $response = vnedu_curl_request($apiUrl, 'POST', "[]", $headers, $cookieFile);
        $dataArray = json_decode($response, true);

        if ($dataArray === null || !isset($dataArray['aRoot'])) {
            throw new Exception("Lỗi lấy danh sách lớp cho năm học " . $namHocGoc);
        }

        // Ma trận đặt lại tên key đầu ra để map sang Moodle cho đồng nhất
        $mapping = [
            'lop_id'   => 'id',
            'ten_lop'  => 'ten',
            'khoi_id'  => 'khoi',
            'si_so'    => 'sy_so',
            'gvcn_id'  => 'chu_nhiem_id'
        ];

        // 4. Lọc dữ liệu sạch bằng hàm helper từ core
        $filteredData = filter_api_fields($dataArray['aRoot'], $fields, $mapping);
        
        return [
            'success' => true, 
            'nam_hoc' => $namHocGoc,
            'total'   => count($filteredData), 
            'data'    => $filteredData
        ];

    } catch (Exception $e) {
        return ['success' => false, 'error' => $e->getMessage()];
    }
}

// --- THU THẬP THAM SỐ TỪ URL (Hỗ trợ linh hoạt cho cả Test Panel và Backend) ---
$namHocInput = $_GET['nam_hoc'] ?? null; 
$fieldsParam = isset($_GET['fields']) ? trim($_GET['fields']) : '';

// Xuất dữ liệu JSON
header('Content-Type: application/json; charset=utf-8');
$output= get_ds_lop($fieldsParam, $namHocInput);
// 🌟 2. KIỂM TRA VÀ LỌC ĐÚNG MẢNG 'data' TRONG JSON
if (isset($output['data']) && is_array($output['data'])) {
    // Tiến hành lọc dữ liệu bên trong mảng data
    $output['data'] = vnedu_filter_data($output['data']);
    
    // Cập nhật lại số lượng đếm (total) sau khi đã lọc để Moodle nhận diện chuẩn
    if (isset($output['total'])) {
        $output['total'] = count($output['data']);
    }
}
echo json_encode($output, JSON_UNESCAPED_UNICODE | JSON_PRETTY_PRINT);