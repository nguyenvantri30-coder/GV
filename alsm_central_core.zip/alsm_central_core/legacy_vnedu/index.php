<?php
ini_set('display_errors', 1);
error_reporting(E_ALL);
header('Content-Type: text/html; charset=utf-8');

$cookieFile = __DIR__ . DIRECTORY_SEPARATOR . 'cookie_jar.txt';
if (file_exists($cookieFile)) { @unlink($cookieFile); }

function bieuDienRequest($url, $method = 'GET', $dataPost = null, $cookieJar = '') {
    $ch = curl_init();
    curl_setopt($ch, CURLOPT_URL, $url);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    curl_setopt($ch, CURLOPT_FOLLOWLOCATION, true); // Tự động xử lý chuỗi SSO chuyển hướng chéo tên miền
    curl_setopt($ch, CURLOPT_MAXREDIRS, 10);
    curl_setopt($ch, CURLOPT_COOKIEJAR, $cookieJar);
    curl_setopt($ch, CURLOPT_COOKIEFILE, $cookieJar);
    curl_setopt($ch, CURLOPT_USERAGENT, 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36');
    curl_setopt($ch, CURLOPT_TIMEOUT, 30);
    curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);

    if (strtoupper($method) === 'POST') {
        curl_setopt($ch, CURLOPT_POST, true);
        curl_setopt($ch, CURLOPT_POSTFIELDS, $dataPost);
        curl_setopt($ch, CURLOPT_HTTPHEADER, array('Content-Type: application/x-www-form-urlencoded; charset=UTF-8'));
    }
    $result = curl_exec($ch);
    curl_close($ch);
    return $result;
}

try {
    echo "<h3>=== HỆ THỐNG AUTO-LOGIN VNEDU TỰ ĐỘNG HÓA 100% ===</h3>";

    // --- BƯỚC 1: LẤY JTOKEN/JCODE MỚI TỰ ĐỘNG ---
    echo "<b>Bước 1:</b> Khởi tạo phiên login lấy mã nhảy... ";
    $initUrl = "https://user.vnedu.vn/sso/login?app_id=1&continue=aHR0cDovL2RpZW5kYW4udm5lZHUudm4vc2VjdXJpdHkvc3NvVm5lZHU=";
    $initHtml = bieuDienRequest($initUrl, 'GET', null, $cookieFile);
    
    // Bóc jtoken và jcode từ form login thô của vnEdu
    preg_match('/jtoken\s*=\s*["\']([^"\']+)["\']/', $initHtml, $jtMatch);
    preg_match('/jcode\s*=\s*["\']([^"\']+)["\']/', $initHtml, $jcMatch);
    
    $jtoken = !empty($jtMatch[1]) ? $jtMatch[1] : "0.3408331684782986"; // Phòng hờ lỗi
    $jcode  = !empty($jcMatch[1]) ? $jcMatch[1] : "216de97e0eb590f76bc04d71cf8a4c9a";
    echo "<span style='color:green;'>[OK]</span><br>";

    // --- BƯỚC 2: POST ĐĂNG NHẬP (Luồng redirect tự chạy xuyên suốt) ---
    echo "<b>Bước 2:</b> Thực hiện POST đăng nhập & thông chuỗi SSO ngầm... ";
    $loginUrl = "https://user.vnedu.vn/sso/?call=auth.login&jtoken={$jtoken}&jcode={$jcode}";
    $payload = http_build_query(array(
        'continue' => 'aHR0cDovL2RpZW5kYW4udm5lZHUudm4vc2VjdXJpdHkvc3NvVm5lZHU=',
        'app_id' => '1',
        'loginQrToken' => 'VNEDU001DB6C81828EF858C6A6395DAB00CE7F66', // Giữ nguyên token QR tĩnh này
        'txtUsername' => 'nvt.nguyenvantri', // Tài khoản trường cấp
        'txtPassword' => 'Myngamy123@@',
        'txtCaptcha' => ''
    ));
    bieuDienRequest($loginUrl, 'POST', $payload, $cookieFile);
    echo "<span style='color:green;'>[OK]</span><br>";

    // --- BƯỚC 3: TẢI TRANG CHỦ V5 ĐỂ QUÉT THÔNG TIN ---
    echo "<b>Bước 3:</b> Truy cập trang v5 để bóc tách thông tin cấu hình... ";
    $schoolUrl = "https://mevzecuvssitessgddaknong.vnedu.vn/v5/";
    $htmlContent = bieuDienRequest($schoolUrl, 'GET', null, $cookieFile);
    echo "<span style='color:green;'>[OK]</span><br>";

    // --- BƯỚC 4: REGEX TỰ ĐỘNG LẤY TẤT CẢ BIẾN ---
    echo "<b>Bước 4:</b> Đang phân tích động các tham số... ";
    $tokenToken = '';
    $myUserId = '';
    $namHoc = date('Y'); // Mặc định lấy năm hiện tại nếu quét lỗi

    // Thọc lấy Token (MD5)
    if (preg_match_all('/\b[a-f0-9]{32}\b/i', $htmlContent, $matchesHashes)) {
        $tokenToken = end($matchesHashes[0]);
    }
    // Thọc lấy User ID
    if (preg_match_all('/\b\d{9,11}\b/', $htmlContent, $matchesIds)) {
        foreach ($matchesIds[0] as $id) {
            if (strlen($id) >= 9) { $myUserId = $id; break; }
        }
    }
    // Thọc lấy Năm học động từ mã nguồn (Tìm cụm từ phpviet_nam_hoc hoặc nam_hoc)
    if (preg_match('/(?:nam_hoc|phpviet_nam_hoc)["\'?]?\s*[:=]\s*["\']?(\d{4})["\']?/i', $htmlContent, $matchYear)) {
        $namHoc = $matchYear[1];
    }

    if (!empty($tokenToken) && !empty($myUserId)) {
        echo "<span style='color:green;'>[THÀNH CÔNG]</span><br>";
        echo "🧬 Token động: <b>$tokenToken</b> | 🆔 User ID động: <b>$myUserId</b> | 📅 Năm học: <b>$namHoc</b><br><br>";
        
        // --- BƯỚC 5: GỌI API AN TOÀN ---
        echo "<b>Bước 5: Lấy dữ liệu danh sách giáo viên cán bộ:</b><br>";
        $queryParams = array(
            'call' => 'vnedu.giaovien.api.getUser',
            '_dc' => time() . '000',
            'my_user_id' => $myUserId,
            'app_nam_hoc' => $namHoc,
            'my_token' => $tokenToken,
            'nam_hoc' => $namHoc,
            'page' => 1,
            'start' => 0,
            'limit' => 1000
        );
        
        $apiUrl = "https://mevzecuvssitessgddaknong.vnedu.vn/v5/?" . http_build_query($queryParams);
        
        // Gọi bằng cấu trúc Header AJAX chuyên biệt
        $ch = curl_init();
        curl_setopt($ch, CURLOPT_URL, $apiUrl);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        curl_setopt($ch, CURLOPT_COOKIEFILE, $cookieFile);
        curl_setopt($ch, CURLOPT_HTTPHEADER, array('X-Requested-With: XMLHttpRequest', 'Accept: */*'));
        $apiResponse = curl_exec($ch);
        curl_close($ch);
        
        echo "<pre style='background:#f4f4f4; padding:10px; border:1px solid #ccc;'>";
        print_r(json_decode($apiResponse, true));
        echo "</pre>";
    } else {
        echo "<span style='color:red;'>[THẤT BẠI] Không thể bóc tách tham số tự động.</span><br>";
    }

} catch (Exception $e) {
    echo "Lỗi: " . $e->getMessage();
} finally {
    if (file_exists($cookieFile)) { @unlink($cookieFile); }
}
?>