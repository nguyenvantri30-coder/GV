<?php
/**
 * File: get_phancong.php
 * Chức năng: Trích xuất dữ liệu phân công giảng dạy (Phẳng hóa ma trận ID vnEdu phục vụ đồng bộ Moodle)
 * Logic: Tự động rẽ nhánh v5/v3 theo năm học, giữ nguyên ID gốc để làm mã thống nhất.
 */

require_once __DIR__ . '/core.php';

try {
    // 0. Hứng tham số năm học từ Moodle truyền lên (Ví dụ: ?nam_hoc=2025)
    $namHocInput = isset($_GET['nam_hoc']) ? intval($_GET['nam_hoc']) : null;

    // Lấy thông tin session và file cookie riêng biệt từ core
    $ss = get_valid_vnedu_session($namHocInput);

    $namHocGoc  = intval($ss['nam_hoc']);
    $cookieFile = $ss['cookie_file_path'];

    // 1. Tính toán năm hiện tại thực tế để rẽ nhánh hạ tầng v5/v3
    $thangHienTai = (int)date('m');
    $namHienTaiThucTe = ($thangHienTai < 8) ? (date('Y') - 1) : date('Y');

    $versionDir  = '';
    $payloadData = [];

    // 2. PHÂN TÁCH ENDPOINT VÀ PAYLOAD THEO PHIÊN BẢN NĂM HỌC
    if ($namHocGoc == $namHienTaiThucTe) {
        $versionDir = 'v5';
    } else {
        $versionDir = 'v3';
        
    }

    $payloadData = [
            'my_token'    => $ss['my_token'],
            'my_user_id'  => $ss['my_user_id'],
            'app_nam_hoc' => $namHocGoc,
            'nam_hoc'     => $namHocGoc,
            'cap_hoc'     => '2'
    ];

    $apiUrl = "https://mevzecuvssitessgddaknong.vnedu.vn/{$versionDir}/?" . http_build_query([
        'call'        => 'edu.pcgd.getPhanCong',
        'app_nam_hoc' => $namHocGoc,
        'my_token'    => $ss['my_token']
    ]);

    $payload = http_build_query($payloadData);

    $headers = [
        'Content-Type: application/x-www-form-urlencoded; charset=UTF-8',
        'X-Requested-With: XMLHttpRequest',
        'Accept: application/json, text/javascript, */*; q=0.01',
        'Referer: https://mevzecuvssitessgddaknong.vnedu.vn/' . $versionDir . '/'
    ];

    // 3. Thực thi cURL với đúng file Cookie của phiên làm việc
    $response = vnedu_curl_request($apiUrl, 'POST', $payload, $headers, $cookieFile);
    $dataArray = json_decode($response, true);

    if ($dataArray === null) {
        throw new Exception("Không thể giải mã dữ liệu phân công giảng dạy hoặc dữ liệu rỗng.");
    }

    // 🌟 4. THUẬT TOÁN PHẲNG HÓA ID NGUYÊN GỐC CHO MOODLE DỄ XỬ LÝ
    $flattenedData = [];
    
    // Kiểm tra cấu trúc dữ liệu trả về có bọc trong trường 'data' hay nằm ở gốc của mảng
    $rawMatrix = isset($dataArray['data']) ? $dataArray['data'] : $dataArray;

    if (is_array($rawMatrix)) {
        foreach ($rawMatrix as $giaoVienId => $monHocs) {
            if (!is_array($monHocs)) continue;
            
            foreach ($monHocs as $monId => $lops) {
                if (!is_array($lops)) continue;
                
                foreach ($lops as $lopId => $hocKys) {
                    // Tạo một bản ghi phẳng, giữ nguyên mã ID gốc thống nhất
                    $flattenedData[] = [
                        'giao_vien_id' => (string)$giaoVienId,
                        'mon_hoc_id'   => (string)$monId,
                        'lop_id'       => (string)$lopId,
                        'hoc_ky_1'     => isset($hocKys['hoc_ky_1']) ? intval($hocKys['hoc_ky_1']) : 0,
                        'hoc_ky_2'     => isset($hocKys['hoc_ky_2']) ? intval($hocKys['hoc_ky_2']) : 0
                    ];
                }
            }
        }
    }

    // 5. ĐÓNG GÓI KẾT QUẢ CHUẨN ĐỒNG BỘ
    $output = [
      'success'      => true,
      'nam_hoc'      => $namHocGoc,
      'total'        => count($flattenedData),
      'data'         => $flattenedData
    ];

    // 6. Trả về JSON cho Moodle đọc
    header('Content-Type: application/json; charset=utf-8');
    // 🌟 2. KIỂM TRA VÀ LỌC ĐÚNG MẢNG 'data' TRONG JSON
    if (isset($output['data']) && is_array($output['data'])) {
        // Tiến hành lọc dữ liệu bên trong mảng data
        $output['data'] = vnedu_filter_data($output['data']);
        
        // Cập nhật lại số lượng đếm (total) sau khi đã lọc để Moodle nhận diện chuẩn
        if (isset($output['total'])) {
            $output['total'] = count($output['data']);
        }
    }
    echo json_encode($output, JSON_UNESCAPED_UNICODE | JSON_PRETTY_PRINT);

} catch (Exception $e) {
    header('Content-Type: application/json; charset=utf-8');
    echo json_encode([
        'success' => false,
        'error' => $e->getMessage()
    ], JSON_UNESCAPED_UNICODE);
}