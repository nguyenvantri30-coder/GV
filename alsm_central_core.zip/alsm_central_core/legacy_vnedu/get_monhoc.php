<?php
/**
 * File: get_monhoc.php
 * Chức năng: Trích xuất danh sách môn học của lớp kèm trạng thái học, giáo viên bộ môn và tự động nhận diện KHỐI HỌC.
 * Endpoint khai thác: edu.lop_hoc.getMonHoc (GET) - Hỗ trợ chọn năm học động, độc lập luồng xử lý cookie
 */

require_once __DIR__ . '/core.php';

function get_monhoc_chuan_vnedu($lopId, $fields = [], $namHocGocInput = null) {
    try {
        // 1. Gọi core lấy đúng phiên làm việc và file cookie tương ứng của năm được yêu cầu
        $ss = get_valid_vnedu_session($namHocGocInput);
        
        $namHocGoc  = intval($ss['nam_hoc']);
        $cookieFile = $ss['cookie_file_path']; // Nhận file cookie biệt lập của năm học đó từ core

        // 2. Xây dựng URL gọi API dạng GET của vnEdu, sử dụng chính xác năm học đã chọn
        $queryParams = http_build_query([
            'call'         => 'edu.lop_hoc.getMonHoc',
            'lop_id'       => $lopId,
            'nam_hoc'      => $namHocGoc,
            '_dc'          => round(microtime(true) * 1000), // Chống cache bằng timestamp miligiây thực tế
            'my_user_id'   => $ss['my_user_id'],
            'app_nam_hoc'  => $namHocGoc,
            'my_token'     => $ss['my_token'],
            'page'         => 1,
            'start'        => 0,
            'limit'        => 50 // Quét sạch toàn bộ môn học trong lớp
        ]);

        $apiUrl = "https://mevzecuvssitessgddaknong.vnedu.vn/v5/?" . $queryParams;

        $headers = [
            'Accept: */*',
            'X-Requested-With: XMLHttpRequest',
            'Referer: https://mevzecuvssitessgddaknong.vnedu.vn/v5/'
        ];

        // 🌟 Gửi request GET kèm theo FILE COOKIE RIÊNG BIỆT của năm học đó
        $response = vnedu_curl_request($apiUrl, 'GET', null, $headers, $cookieFile);

        if (empty($response)) {
            return ['success' => false, 'error' => 'Dữ liệu phản hồi từ vnEdu rỗng.'];
        }

        // 3. Giải mã dữ liệu JSON nhận được từ vnEdu
        $dataJson = json_decode($response, true);
        
        $rawList = [];
        if (is_array($dataJson)) {
            if (isset($dataJson['data']) && is_array($dataJson['data'])) {
                $rawList = $dataJson['data'];
            } elseif (isset($dataJson['root']) && is_array($dataJson['root'])) {
                $rawList = $dataJson['root'];
            } else {
                $rawList = $dataJson;
            }
        } else {
            return ['success' => false, 'error' => 'Phản hồi từ vnEdu không phải JSON hợp lệ.', 'raw' => $response];
        }

        // 🌟 4. LOGIC TỰ ĐỘNG NHẬN DIỆN KHỐI HỌC DÀNH CHO CẤP THCS
        // Phân tích bản ghi đầu tiên để bóc tách số khối học từ tên lớp
        $khoiSo = "";
        $tenKhoi = "Chưa xác định";

        if (!empty($rawList) && isset($rawList[0])) {
            $firstItem = $rawList[0];
            $tenLopGoc = $firstItem['ten_lop'] ?? $firstItem['lop_ten'] ?? '';
            
            if (!empty($tenLopGoc)) {
                preg_match('/\d/', $tenLopGoc, $matches);
                if (!empty($matches[0])) {
                    $khoiSo = $matches[0];
                    $tenKhoi = "Khối " . $khoiSo;
                }
            }
        }

        $processedData = [];

        foreach ($rawList as $item) {
            // Giải mã trạng thái lớp có học môn này hay không
            $isHoc = isset($item['checked']) && ($item['checked'] == 1 || $item['checked'] === '1' || $item['checked'] === true);

            // Thử lấy trường khối ẩn nếu vnEdu có sẵn, nếu không dùng kết quả suy luận từ tên lớp
            $itemKhoi = $item['khoi'] ?? $item['khoi_hoc'] ?? $item['id_khoi'] ?? $khoiSo;
            $itemTenKhoi = isset($item['ten_khoi']) ? $item['ten_khoi'] : (!empty($itemKhoi) ? "Khối " . $itemKhoi : $tenKhoi);

            // Ánh xạ dữ liệu đầu ra chuẩn phục vụ mapping cấu trúc Moodle
            $rawSubjectData = [
                'mon_hoc_id'   => $item['id'] ?? '',
                'ten_mon_hoc'  => $item['ten'] ?? '',
                'so_tiet'      => $item['so_tiet'] ?? '',
                'he_so'        => $item['he_so'] ?? '1',
                'hoc'          => $isHoc,
                'gv_id_hk1'    => $item['gv_id_1'] ?? '', 
                'gv_ten_hk1'   => (!empty($item['ten_gv1'])) ? $item['ten_gv1'] : 'Chưa phân công',
                'gv_id_hk2'    => $item['gv_id_2'] ?? '',
                'gv_ten_hk2'   => (!empty($item['ten_gv2'])) ? $item['ten_gv2'] : 'Chưa phân công',
                'ky_hoc_str'   => $item['ky_hoc_str'] ?? 'Học cả 2 học kỳ',
                'ma_moet'      => $item['ma_moet'] ?? '',
                // 🌟 Bổ sung 2 cột thông tin khối học phục vụ mapping tự động sang Moodle
                'khoi'         => $itemKhoi, 
                'ten_khoi'     => $itemTenKhoi
            ];

            // CƠ CHẾ BẢO PHÒNG (FALLBACK): Giữ lại các key gốc nếu cần debug sâu
            foreach ($item as $key => $val) {
                if (!isset($rawSubjectData[$key])) {
                    $rawSubjectData[$key] = $val;
                }
            }

            // 5. THỰC THI BỘ LỌC ĐẦU RA (Nếu panel hoặc backend yêu cầu lọc trường cụ thể)
            if (!empty($fields)) {
                $filteredRow = [];
                foreach ($fields as $field) {
                    $field = trim($field);
                    $filteredRow[$field] = $rawSubjectData[$field] ?? $item[$field] ?? '';
                }
                $processedData[] = $filteredRow;
            } else {
                $processedData[] = $rawSubjectData;
            }
        }

        return [
            'success' => true,
            'nam_hoc' => $namHocGoc,
            'total'   => count($processedData),
            'data'    => $processedData
        ];

    } catch (Exception $e) {
        return ['success' => false, 'error' => $e->getMessage()];
    }
}

// --- THU THẬP THAM SỐ TỪ URL (Hỗ trợ linh hoạt cho cả Test Panel và Backend) ---
$lopId  = $_GET['lop_id'] ?? null;
$namHoc = $_GET['nam_hoc'] ?? null; // Nhận động từ Panel hoặc lệnh Moodle Backend gửi lên

// Kiểm tra tham số bắt buộc
if (!$lopId) {
    header('Content-Type: application/json; charset=utf-8');
    echo json_encode([
        'success' => false,
        'error'   => 'Thiếu tham số cấu hình bắt buộc trên panel: lop_id.'
    ], JSON_UNESCAPED_UNICODE);
    exit;
}

// Xử lý tham số trích xuất chọn lọc trường dữ liệu
$fieldsRaw = $_GET['fields'] ?? '';
$fields = !empty($fieldsRaw) ? explode(',', $fieldsRaw) : [];

// 6. Xuất JSON Response chỉ khi được gọi trực tiếp (không phải thông qua require/include từ file khác)
if (basename($_SERVER['SCRIPT_FILENAME']) === 'get_monhoc.php') {
    header('Content-Type: application/json; charset=utf-8');
    $output = get_monhoc_chuan_vnedu($lopId, $fields, $namHoc);
    // 🌟 2. KIỂM TRA VÀ LỌC ĐÚNG MẢNG 'data' TRONG JSON
    if (isset($output['data']) && is_array($output['data'])) {
        // Tiến hành lọc dữ liệu bên trong mảng data
        $output['data'] = vnedu_filter_data($output['data']);
        
        // Cập nhật lại số lượng đếm (total) sau khi đã lọc để Moodle nhận diện chuẩn
        if (isset($output['total'])) {
            $output['total'] = count($output['data']);
        }
    }
    echo json_encode($output, JSON_UNESCAPED_UNICODE | JSON_PRETTY_PRINT);
}