<?php
/**
 * File: get_lichbaogiang.php
 * Chức năng: Bóc tách danh mục Phân môn hoặc Lịch báo giảng chi tiết từ vnEdu
 * Logic: Tự động rẽ nhánh Endpoint, Header và Token động giữa v5 (Năm hiện tại) và v3 (Năm cũ)
 */

require_once __DIR__ . '/core.php';

/**
 * Hàm lõi xử lý lấy và đồng bộ lịch báo giảng vnEdu
 */
function get_lich_bao_giang_hoan_hao($giaoVienId, $tuanHoc, $getData = false, $fields = [], $namHocGocInput = null) {
    if (empty($giaoVienId) || empty($tuanHoc)) {
        return ['success' => false, 'error' => 'Thiếu tham số bắt buộc.'];
    }

    try {
        // 1. Khởi tạo và kiểm tra Session vnEdu dựa theo năm học yêu cầu
        $ss = get_valid_vnedu_session($namHocGocInput);

        $namHocGoc  = intval($ss['nam_hoc']);
        $cookieFile = $ss['cookie_file_path'];

        // 2. Tính toán năm hiện tại thực tế của hệ thống để làm mốc rẽ nhánh v5/v3
        $thangHienTai = (int)date('m');
        $namHienTaiThucTe = ($thangHienTai < 8) ? (date('Y') - 1) : date('Y');

        $versionDir  = '';
        $payloadData = [];

        // 🌟 3. RẼ NHÁNH ENDPOINT VÀ PAYLOAD TUYỆT ĐỐI THEO PHIÊN BẢN NĂM HỌC
        if ($namHocGoc == $namHienTaiThucTe) {
            // --- CẤU HÌNH CHO NĂM HIỆN TẠI (CHẠY V5) ---
            $versionDir  = 'v5';
            $payloadData = [
                'my_token'    => $ss['my_token'],
                'my_user_id'  => $ss['my_user_id'],
                'app_nam_hoc' => $namHocGoc,
                'namHoc'      => $namHocGoc,
                'capHoc'      => '2', // Cấp THCS
                'giaoVienId'  => $giaoVienId,
                'tuanHoc'     => $tuanHoc,
                'winId'       => '42d9ce3cbdd7b9ed08c09c1ef65409d6',
                'iNgayTacDung'=> '',
                'isEdit'      => '0'
            ];
        } else {
            // --- CẤU HÌNH CHO CÁC NĂM CŨ LỊCH SỬ (CHẠY V3) ---
            $versionDir  = 'v3';
            $payloadData = [
                'my_token'    => $ss['my_token'],
                'my_user_id'  => $ss['my_user_id'],
                'app_nam_hoc' => $namHocGoc,
                'namHoc'      => $namHocGoc,
                'capHoc'      => '2',
                'giaoVienId'  => $giaoVienId,
                'tuanHoc'     => $tuanHoc,
                'iNgayTacDung'=> '',
                'isEdit'      => '0'
                // Khối form cũ tối giản của hạ tầng core v3
            ];
        }

        // Tạo URL endpoint đích đồng bộ chính xác theo phiên bản thư mục ($versionDir)
        $apiUrl = "https://mevzecuvssitessgddaknong.vnedu.vn/{$versionDir}/?load=edu.lich_bao_giang.lich_bao_giang&app_nam_hoc=" . $namHocGoc . "&my_token=" . $ss['my_token'];
        $payload = http_build_query($payloadData);

        // Thiết lập Header chuẩn, đồng bộ Referer động theo đúng phân hệ hạ tầng tương ứng
        $headers = [
            'Content-Type: application/x-www-form-urlencoded; charset=UTF-8',
            'X-Requested-With: XMLHttpRequest',
            'Accept: */*',
            'Referer: https://mevzecuvssitessgddaknong.vnedu.vn/' . $versionDir . '/'
        ];

        // 4. Gửi request cURL qua hàm hệ thống lõi với file Cookie tách biệt
        $response = vnedu_curl_request($apiUrl, 'POST', $payload, $headers, $cookieFile);
        if (empty($response)) {
            throw new Exception("Không nhận được phản hồi từ server vnEdu phân hệ " . strtoupper($versionDir));
        }

        // Đặt tên biến mục tiêu cần bóc tách dựa theo luồng tham số đầu vào
        $targetVar = $getData ? 'var aLichBGDetail' : 'var aPhanMon';
        $finalData = [];

        // 5. THUẬT TOÁN BÓC TÁCH KHỐI JAVASCRIPT THÔ SANG MẢNG DỮ LIỆU SẠCH
        if (strpos($response, $targetVar) !== false) {
            $posVar = strpos($response, $targetVar);
            
            // Tìm dấu mở khối đầu tiên (Mảng [ hoặc Đối tượng {) ngay sau tên biến mục tiêu
            $posStartArr = strpos($response, '[', $posVar);
            $posStartObj = strpos($response, '{', $posVar);
            
            if ($posStartArr !== false && ($posStartObj === false || $posStartArr < $posStartObj)) {
                $posStart = $posStartArr;
                $posEnd = strpos($response, '];', $posStart);
            } else {
                $posStart = $posStartObj;
                $posEnd = strpos($response, '};', $posStart);
            }

            if ($posStart !== false && $posEnd !== false) {
                $jsonDataTho = substr($response, $posStart, ($posEnd - $posStart) + 1);
                $decodedData = json_decode(trim($jsonDataTho), true);
                
                if (is_array($decodedData)) {
                    if ($getData) {
                        // Đối với luồng lịch chi tiết (Object "2_1_2" => {...}), chuyển phẳng thành mảng tuần tự
                        $finalData = array_values($decodedData);
                    } else {
                        // Đối với luồng danh mục phân môn (Array)
                        $finalData = $decodedData;
                    }
                }
            }
        }

        // Bẫy lỗi và in debug nhanh nếu năm cũ chạy lỗi không bóc được biến JS
        if (empty($finalData)) {
            header('Content-Type: application/json; charset=utf-8');
            echo json_encode([
                'success' => false, 
                'version_used' => strtoupper($versionDir),
                'error'   => "Không thể bóc tách hoặc không tồn tại dữ liệu cho mục tiêu: $targetVar",
                'url_goi' => $apiUrl,
                'vnedu_raw_preview' => mb_substr($response, 0, 1500) // Trích xem chuỗi JS trả về có chứa var mục tiêu không
            ], JSON_UNESCAPED_UNICODE | JSON_PRETTY_PRINT);
            exit;
        }

        // 6. XỬ LÝ MAP TRƯỜNG VÀ ĐỒNG BỘ LUỒNG FIELDS TÙY CHỌN
        $resultData = [];

        if ($getData) {
            // LUỒNG LẤY LỊCH DẠY CHI TIẾT (get_data=1)
            foreach ($finalData as $row) {
                $fullRow = $row;
                $fullRow['lop']     = isset($row['ten_lop']) ? $row['ten_lop'] : null;
                $fullRow['mon']     = isset($row['ten_mon']) ? $row['ten_mon'] : null;
                $fullRow['bai_day'] = isset($row['ten_bai_day']) ? $row['ten_bai_day'] : null;

                if (!empty($fields)) {
                    $cleanedRow = [];
                    foreach ($fields as $f) {
                        if (array_key_exists($f, $fullRow)) {
                            $cleanedRow[$f] = $fullRow[$f];
                        }
                    }
                    $resultData[] = $cleanedRow;
                } else {
                    $resultData[] = $fullRow;
                }
            }
        } else {
            // LUỒNG LẤY DANH MỤC MÔN HỌC TOÀN TRƯỜNG (get_data=0)
            $mappingDanhMuc = [
                'id'            => 'mon_id',
                'mon_id'        => 'mon_id', 
                'ten'           => 'ten_phan_mon',
                'ten_phan_mon'  => 'ten_phan_mon',
                'ten_mon'       => 'ten_mon_chinh',
                'ten_mon_chinh' => 'ten_mon_chinh'
            ];
            
            if (!empty($fields)) {
                $resultData = filter_api_fields($finalData, $fields, $mappingDanhMuc);
            } else {
                $resultData = $finalData;
            }
        }

        // 7. TRẢ KẾT QUẢ ĐẦU RA CHUẨN JSON
        return [
            'success'   => true,
            'nam_hoc' => $namHocGoc,
            'giao_vien' => $giaoVienId,
            'tuan'      => $tuanHoc,
            'mode'      => $getData ? 'lich_day_chi_tiet' : 'danh_muc_phan_mon',
            'total'     => count($resultData),
            'data'      => $resultData
        ];

    } catch (Exception $e) {
        return ['success' => false, 'error' => $e->getMessage()];
    }
}

// Tiếp nhận tham số động từ phương thức GET công khai
$gvIdParam   = isset($_GET['giao_vien_id']) ? trim($_GET['giao_vien_id']) : '';
$tuanParam   = isset($_GET['tuan_hoc']) ? trim($_GET['tuan_hoc']) : '';
$fieldsParam = isset($_GET['fields']) ? trim($_GET['fields']) : '';
$getData     = isset($_GET['get_data']) ? (int)$_GET['get_data'] : 0;
$namHocParam = isset($_GET['nam_hoc']) ? intval($_GET['nam_hoc']) : null; 

$fieldsArray = !empty($fieldsParam) ? explode(',', $fieldsParam) : [];

// Cấu hình Header đầu ra cho API JSON về phía Moodle
header('Content-Type: application/json; charset=utf-8');
$output = get_lich_bao_giang_hoan_hao($gvIdParam, $tuanParam, $getData, $fieldsArray, $namHocParam);
// 🌟 2. KIỂM TRA VÀ LỌC ĐÚNG MẢNG 'data' TRONG JSON
if (isset($output['data']) && is_array($output['data'])) {
    // Tiến hành lọc dữ liệu bên trong mảng data
    $output['data'] = vnedu_filter_data($output['data']);
    
    // Cập nhật lại số lượng đếm (total) sau khi đã lọc để Moodle nhận diện chuẩn
    if (isset($output['total'])) {
        $output['total'] = count($output['data']);
    }
}
echo json_encode($output, JSON_UNESCAPED_UNICODE | JSON_PRETTY_PRINT);