<?php
require_once __DIR__ . '/core.php';

try {
    $ss = get_valid_vnedu_session();
    $queryParams = [
        'load'        => 'edu.lich_bao_giang.lich_bao_giang',
        'app_nam_hoc' => $ss['nam_hoc'],
        'my_token'    => $ss['my_token']
    ];
    $apiUrl = "https://mevzecuvssitessgddaknong.vnedu.vn/v5/?" . http_build_query($queryParams);

    $payloadData = [
        'my_token'    => $ss['my_token'],
        'my_user_id'  => $ss['my_user_id'],
        'app_nam_hoc' => $ss['nam_hoc'],
        'namHoc'      => $ss['nam_hoc'],
        'capHoc'      => '2',
        'giaoVienId'  => '7214982924', 
        'tuanHoc'     => '1',          
        'winId'       => '42d9ce3cbdd7b9ed08c09c1ef65409d6',
        'iNgayTacDung'=> '',
        'isEdit'      => '0'
    ];
    $payload = http_build_query($payloadData);
    $headers = ['Content-Type: application/x-www-form-urlencoded; charset=UTF-8', 'X-Requested-With: XMLHttpRequest'];

    $response = vnedu_curl_request($apiUrl, 'POST', $payload, $headers);
    
    echo "<pre>=== SOI CẤU TRÚC BIẾN ALICHBGDETAIL ===\n";
    if (strpos($response, 'var aLichBGDetail') !== false) {
        $posVar = strpos($response, 'var aLichBGDetail');
        $posStart = strpos($response, '{', $posVar);
        $posEnd = strpos($response, '};', $posStart);
        
        if ($posStart !== false && $posEnd !== false) {
            $jsonDataTho = substr($response, $posStart, ($posEnd - $posStart) + 1);
            $decoded = json_decode(trim($jsonDataTho), true);
            
            // Lấy ra phần tử đầu tiên trong lịch dạy để xem các Key đặt tên là gì
            if (!empty($decoded)) {
                $firstKey = array_key_first($decoded);
                echo "Key mẫu: " . $firstKey . "\n";
                echo "Dữ liệu bên trong:\n";
                print_r($decoded[$firstKey]);
            } else {
                echo "Biến aLichBGDetail rỗng.";
            }
        }
    } else {
        echo "Không tìm thấy biến var aLichBGDetail";
    }

} catch (Exception $e) {
    echo "Lỗi: " . $e->getMessage();
}