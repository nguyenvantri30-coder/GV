<?php
/**
 * File: get_hocsinh.php
 * Chức năng: Trích xuất danh sách học sinh theo lớp học (Tự động chuyển đổi thông minh giữa Endpoint v5 và v3)
 */

require_once __DIR__ . '/core.php';

function get_dshs_by_lop($lopId, $fields = [], $namHocGocInput = null) {
    if (empty($lopId)) {
        return ['success' => false, 'error' => 'Thiếu tham số ID lớp học.'];
    }

    try {
        // 1. Gọi core lấy Session và cookie tương ứng của năm được yêu cầu
        $ss = get_valid_vnedu_session($namHocGocInput);
        
        $namHocGoc  = intval($ss['nam_hoc']);
        $cookieFile = $ss['cookie_file_path']; 

        // 2. Tính toán năm hiện tại thực tế của hệ thống để làm mốc so sánh
        $thangHienTai = (int)date('m');
        $namHienTaiThucTe = ($thangHienTai < 8) ? (date('Y') - 1) : date('Y');

        $queryParams = [];
        $versionDir  = ''; // Biến chứa v3 hoặc v5 động

        // 🌟 3. RẼ NHÁNH ENDPOINT VÀ THAM SỐ TUYỆT ĐỐI THEO PHIÊN BẢN HỆ THỐNG
        if ($namHocGoc == $namHienTaiThucTe) {
            // --- CẤU HÌNH CHO NĂM HIỆN TẠI (ÉP CHẠY V5) ---
            $versionDir  = 'v5';
            $queryParams = [
                'call'        => 'edu.hoc_sinh.getHocSinh', 
                'lop_id'      => $lopId, 
                'nam_hoc'     => $namHocGoc,
                'check'       => '1',      
                '_dc'         => round(microtime(true) * 1000), 
                'my_user_id'  => $ss['my_user_id'],
                'app_nam_hoc' => $namHocGoc, 
                'my_token'    => $ss['my_token']
            ];
        } else {
            // --- CẤU HÌNH CHO CÁC NĂM CŨ LỊCH SỬ (ÉP CHẠY V3) ---
            $versionDir  = 'v3';
            $queryParams = [
                'call'        => 'edu.hoc_sinh.getHocSinh', 
                'lop_id'      => $lopId, 
                'nam_hoc'     => $namHocGoc,
                'check'       => '1', // Log F12 thực tế năm cũ vẫn truyền 1
                '_dc'         => round(microtime(true) * 1000), 
                'my_user_id'  => $ss['my_user_id'],
                'app_nam_hoc' => $namHocGoc, 
                'my_token'    => $ss['my_token'], 
                'page'        => 1, 
                'start'       => 0, 
                'limit'       => 100 
            ];
        }

        // Tạo URL động động theo thư mục phiên bản ($versionDir) tương ứng
        $apiUrl = "https://mevzecuvssitessgddaknong.vnedu.vn/{$versionDir}/?" . http_build_query($queryParams);
        
        $headers = [
            'Accept: */*',
            'X-Requested-With: XMLHttpRequest',
            'Referer: https://mevzecuvssitessgddaknong.vnedu.vn/' . $versionDir . '/'
        ];

        // 4. Gửi request cURL với file cookie độc lập
        $response = vnedu_curl_request($apiUrl, 'GET', null, $headers, $cookieFile);
        $dataArray = json_decode($response, true);

        // Kiểm tra tính toàn vẹn của dữ liệu trả về từ vnEdu
        if ($dataArray === null || !isset($dataArray['aRoot'])) {
            throw new Exception("Không lấy được dữ liệu học sinh của năm học " . $namHocGoc . " từ phân hệ " . strtoupper($versionDir));
        }

        // Bản đồ ánh xạ cấu trúc đầu ra cho Moodle
        $mapping = [
            'hoc_sinh_id'    => 'hs_id',
            'ma_hoc_sinh'    => 'ma_hs',
            'ten_hoc_sinh'   => 'ho_ten', 
            'ngay_sinh'      => 'ngay_sinh',
            'gioi_tinh'      => 'gioi_tinh',
            'trang_thai_ten' => 'trang_thai'
        ];

        // 5. Lọc và định dạng dữ liệu trả về thông qua hàm dùng chung
        $filteredData = filter_api_fields($dataArray['aRoot'], $fields, $mapping);

        return [
            'success' => true,
            'nam_hoc' => $namHocGoc,
            'total'   => count($filteredData),
            'data'    => $filteredData
        ];

    } catch (Exception $e) {
        return ['success' => false, 'error' => $e->getMessage()];
    }
}

// --- HỨNG THAM SỐ TỪ URL ---
$lopIdParam  = isset($_GET['lop_id']) ? trim($_GET['lop_id']) : '';
$namHocInput = $_GET['nam_hoc'] ?? null; 
$fieldsParam = isset($_GET['fields']) ? trim($_GET['fields']) : ''; 

// Xuất cấu trúc JSON
header('Content-Type: application/json; charset=utf-8');
$output = get_dshs_by_lop($lopIdParam, $fieldsParam, $namHocInput);
// 🌟 2. KIỂM TRA VÀ LỌC ĐÚNG MẢNG 'data' TRONG JSON
if (isset($output['data']) && is_array($output['data'])) {
    // Tiến hành lọc dữ liệu bên trong mảng data
    $output['data'] = vnedu_filter_data($output['data']);
    
    // Cập nhật lại số lượng đếm (total) sau khi đã lọc để Moodle nhận diện chuẩn
    if (isset($output['total'])) {
        $output['total'] = count($output['data']);
    }
}
echo json_encode($output, JSON_UNESCAPED_UNICODE | JSON_PRETTY_PRINT);