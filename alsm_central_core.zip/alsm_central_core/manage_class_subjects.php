<?php
/**
 * File: manage_class_subjects.php
 * Chức năng: Giao diện Web hiển thị đối soát phân công môn học theo lớp
 * Thiết kế: Dạng lưới thẻ (Cards Grid) kết hợp Tab khối lớp gọn gàng, hỗ trợ tìm kiếm làm nổi bật trực quan
 */

// 1. Cấu hình kết nối cơ sở dữ liệu alsm
$host = 'localhost';
$db = 'alsm';
$user = 'root';
$pass = '';
$charset = 'utf8mb4';
$dsn = "mysql:host=$host;dbname=$db;charset=$charset";
$options = [
    PDO::ATTR_ERRMODE            => PDO::ERRMODE_EXCEPTION,
    PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
    PDO::ATTR_EMULATE_PREPARES   => false,
];

try {
    $pdo = new PDO($dsn, $user, $pass, $options);
} catch (\PDOException $e) {
    die("<div style='padding: 20px; background: #fee2e2; color: #991b1b; font-family: sans-serif; border-radius: 8px;'>
            <strong>Lỗi kết nối CSDL:</strong> " . htmlspecialchars($e->getMessage()) . "
         </div>");
}

// Lấy danh sách toàn bộ lớp học để làm bộ lọc và hiển thị danh sách
$classes_list = $pdo->query("SELECT id, class_name, grade_level, student_count, homeroom_teacher_id FROM classes ORDER BY grade_level ASC, class_name ASC")->fetchAll();

// Lấy danh sách giáo viên để đối chiếu tên GVCN nhanh
$teachers_list = $pdo->query("SELECT id, full_name FROM teachers")->fetchAll();
$teachers_map = [];
foreach ($teachers_list as $t) {
    $teachers_map[$t['id']] = $t['full_name'];
}

// Hứng bộ lọc lớp học từ URL/Form
$filter_class = isset($_GET['class_filter']) ? trim($_GET['class_filter']) : '';

// 2. Truy vấn danh sách phân công môn học kèm liên kết tên lớp, môn học, giáo viên
// Thực hiện GROUP_CONCAT để gộp các giáo viên dạy chung môn tích hợp trên cùng 1 dòng
$sql = "SELECT 
            csa.class_id, 
            csa.subject_id, 
            s.subject_name, 
            GROUP_CONCAT(t.full_name ORDER BY t.full_name SEPARATOR ', ') AS teacher_names
        FROM class_subject_assignments csa
        LEFT JOIN subjects s ON csa.subject_id = s.id
        LEFT JOIN teachers t ON csa.teacher_id = t.id
        GROUP BY csa.class_id, csa.subject_id
        ORDER BY s.subject_name ASC";

$stmt = $pdo->query($sql);
$assignments = $stmt->fetchAll();

// Group assignments theo class_id
$class_assignments = [];
foreach ($assignments as $a) {
    $class_assignments[$a['class_id']][] = [
        'subject_id' => $a['subject_id'],
        'subject_name' => $a['subject_name'] ?: 'Môn ' . $a['subject_id'],
        'teachers' => $a['teacher_names'] ?: 'Chưa phân công'
    ];
}

// Tổ chức lại dữ liệu thành các thẻ Lớp học
$classes_data = [];
$total_assignments_count = 0;
foreach ($classes_list as $c) {
    $class_id = $c['id'];
    $subjects = isset($class_assignments[$class_id]) ? $class_assignments[$class_id] : [];
    
    // Đếm tổng số phân công thực tế trong CSDL
    if (isset($class_assignments[$class_id])) {
        // Mỗi dòng giáo viên là 1 bản ghi trong bảng csa
        // Ta cần đếm số lượng giáo viên trong class_subject_assignments cho lớp này
    }

    $classes_data[$class_id] = [
        'class_id' => $class_id,
        'class_name' => $c['class_name'],
        'grade_level' => $c['grade_level'],
        'student_count' => $c['student_count'],
        'homeroom_teacher' => isset($teachers_map[$c['homeroom_teacher_id']]) ? $teachers_map[$c['homeroom_teacher_id']] : 'Chưa phân công',
        'subjects' => $subjects
    ];
}

// Đếm tổng số bản ghi phân công trong DB
$total_assignments_count = $pdo->query("SELECT COUNT(*) FROM class_subject_assignments")->fetchColumn();

// Trạng thái đồng bộ từ URL
$status = isset($_GET['status']) ? $_GET['status'] : '';
$count = isset($_GET['count']) ? intval($_GET['count']) : 0;
$message = isset($_GET['message']) ? $_GET['message'] : '';

// Hàm lấy Emoji đặc trưng cho môn học
function get_subject_emoji($name) {
    $name = mb_strtolower($name);
    if (strpos($name, 'toán') !== false) return '📐';
    if (strpos($name, 'văn') !== false || strpos($name, 'tiếng việt') !== false) return '📚';
    if (strpos($name, 'ngoại ngữ') !== false || strpos($name, 'tiếng anh') !== false) return '🇬🇧';
    if (strpos($name, 'lịch sử') !== false || strpos($name, 'địa lý') !== false || strpos($name, 'địa lí') !== false) return '🌍';
    if (strpos($name, 'tự nhiên') !== false || strpos($name, 'vật lý') !== false || strpos($name, 'hóa học') !== false || strpos($name, 'sinh học') !== false) return '🔬';
    if (strpos($name, 'tin học') !== false) return '💻';
    if (strpos($name, 'thể chất') !== false || strpos($name, 'thể dục') !== false) return '⚽';
    if (strpos($name, 'nghệ thuật') !== false || strpos($name, 'âm nhạc') !== false || strpos($name, 'mỹ thuật') !== false) return '🎨';
    if (strpos($name, 'công nghệ') !== false) return '🛠️';
    if (strpos($name, 'đạo đức') !== false || strpos($name, 'gdcd') !== false) return '⚖️';
    if (strpos($name, 'trải nghiệm') !== false) return '🌟';
    if (strpos($name, 'địa phương') !== false) return '🏡';
    return '📘';
}
?>
<!DOCTYPE html>
<html lang="vi">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>ALSM Central Core - Đối soát Phân công Môn học</title>
    <!-- Nhúng Google Font Inter -->
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700;800&display=swap" rel="stylesheet">
    <style>
        :root {
            --primary: #3b82f6;
            --primary-hover: #2563eb;
            --background: #f1f5f9;
            --surface: #ffffff;
            --text-main: #0f172a;
            --text-muted: #64748b;
            --border: #cbd5e1;
            --border-light: #f1f5f9;
            --accent: #10b981;
            --accent-hover: #059669;
            --warning: #eab308;
            --danger: #ef4444;
            --shadow: 0 10px 25px -3px rgba(59, 130, 246, 0.05), 0 4px 6px -2px rgba(0, 0, 0, 0.02);
            --transition: all 0.25s cubic-bezier(0.4, 0, 0.2, 1);
        }

        * {
            box-sizing: border-box;
            margin: 0;
            padding: 0;
        }

        body {
            font-family: 'Inter', sans-serif;
            background-color: var(--background);
            color: var(--text-main);
            line-height: 1.5;
            padding: 40px 20px;
        }

        .container {
            max-width: 1400px;
            margin: 0 auto;
        }

        /* Header Style */
        header {
            margin-bottom: 30px;
            display: flex;
            justify-content: space-between;
            align-items: center;
            flex-wrap: wrap;
            gap: 15px;
        }

        .logo-zone h1 {
            font-size: 26px;
            font-weight: 800;
            color: #0f172a;
            letter-spacing: -0.75px;
            display: flex;
            align-items: center;
            gap: 10px;
        }

        .logo-zone p {
            font-size: 14px;
            color: var(--text-muted);
            margin-top: 4px;
        }

        .nav-links {
            display: flex;
            gap: 10px;
        }

        .nav-links a {
            display: inline-flex;
            align-items: center;
            gap: 6px;
            color: var(--primary);
            text-decoration: none;
            font-weight: 600;
            font-size: 14px;
            padding: 8px 16px;
            background-color: #eff6ff;
            border-radius: 8px;
            transition: var(--transition);
        }

        .nav-links a:hover {
            background-color: #dbeafe;
            color: var(--primary-hover);
        }

        /* Banner trạng thái */
        .alert {
            padding: 16px 20px;
            border-radius: 12px;
            font-size: 14px;
            font-weight: 500;
            margin-bottom: 24px;
            display: flex;
            align-items: center;
            gap: 10px;
            animation: slideDown 0.3s ease;
            box-shadow: 0 4px 6px -1px rgba(0,0,0,0.05);
        }

        .alert-success {
            background-color: #ecfdf5;
            color: #065f46;
            border: 1px solid #a7f3d0;
        }

        .alert-warning {
            background-color: #fffbeb;
            color: #92400e;
            border: 1px solid #fde68a;
        }

        .alert-danger {
            background-color: #fef2f2;
            color: #991b1b;
            border: 1px solid #fecaca;
        }

        /* Panel điều khiển */
        .control-panel {
            background: var(--surface);
            border-radius: 16px;
            padding: 24px;
            box-shadow: var(--shadow);
            border: 1px solid var(--border);
            margin-bottom: 24px;
        }

        .control-form {
            display: flex;
            align-items: flex-end;
            gap: 20px;
            flex-wrap: wrap;
        }

        .form-group {
            display: flex;
            flex-direction: column;
            gap: 8px;
        }

        .form-group.flex-grow {
            flex-grow: 1;
            min-width: 280px;
        }

        .form-group label {
            font-size: 12px;
            font-weight: 700;
            color: var(--text-muted);
            text-transform: uppercase;
            letter-spacing: 0.5px;
        }

        .form-group select, .form-group input {
            width: 100%;
            padding: 12px 16px;
            border: 1px solid var(--border);
            border-radius: 10px;
            font-size: 14px;
            font-family: inherit;
            color: var(--text-main);
            background-color: #f8fafc;
            transition: var(--transition);
        }

        .form-group select:focus, .form-group input:focus {
            outline: none;
            border-color: var(--primary);
            background-color: #fff;
            box-shadow: 0 0 0 3px rgba(59, 130, 246, 0.1);
        }

        .btn-sync {
            background-color: var(--accent);
            color: #ffffff;
            border: none;
            padding: 14px 24px;
            font-size: 14px;
            font-weight: 700;
            border-radius: 10px;
            cursor: pointer;
            display: inline-flex;
            align-items: center;
            justify-content: center;
            gap: 8px;
            transition: var(--transition);
            box-shadow: 0 4px 10px rgba(16, 185, 129, 0.2);
            height: 46px;
            text-decoration: none;
        }

        .btn-sync:hover {
            background-color: var(--accent-hover);
            transform: translateY(-1px);
            box-shadow: 0 6px 14px rgba(16, 185, 129, 0.3);
        }

        /* Tabs Khối Lớp */
        .grade-tabs {
            display: flex;
            gap: 8px;
            margin-bottom: 24px;
            flex-wrap: wrap;
        }

        .tab-btn {
            background: #cbd5e1;
            color: #475569;
            border: none;
            padding: 10px 24px;
            font-size: 14px;
            font-weight: 700;
            border-radius: 9999px;
            cursor: pointer;
            transition: var(--transition);
        }

        .tab-btn.active {
            background: var(--primary);
            color: #ffffff;
            box-shadow: 0 4px 10px rgba(59, 130, 246, 0.2);
        }

        .tab-btn:hover:not(.active) {
            background: #94a3b8;
            color: #0f172a;
        }

        /* Lưới Thẻ Lớp Học */
        .class-cards-grid {
            display: grid;
            grid-template-columns: repeat(auto-fill, minmax(320px, 1fr));
            gap: 24px;
        }

        @media (min-width: 1200px) {
            .class-cards-grid {
                grid-template-columns: repeat(4, 1fr); /* Tối đa 4 cột trên màn hình rộng */
            }
        }

        .class-card {
            background: var(--surface);
            border-radius: 16px;
            border: 1px solid var(--border);
            box-shadow: var(--shadow);
            display: flex;
            flex-direction: column;
            overflow: hidden;
            transition: var(--transition);
        }

        .class-card:hover {
            transform: translateY(-4px);
            box-shadow: 0 12px 24px -5px rgba(0, 0, 0, 0.08);
            border-color: var(--primary);
        }

        .card-header {
            padding: 16px 20px;
            background: #f8fafc;
            border-bottom: 1px solid var(--border-light);
            display: flex;
            flex-direction: column;
            gap: 6px;
        }

        .card-title-row {
            display: flex;
            justify-content: space-between;
            align-items: center;
        }

        .class-badge {
            background: #eff6ff;
            color: var(--primary-hover);
            font-size: 18px;
            font-weight: 800;
            padding: 4px 12px;
            border-radius: 8px;
            border: 1px solid #dbeafe;
        }

        .student-count {
            font-size: 13px;
            font-weight: 600;
            color: var(--text-muted);
        }

        .homeroom-row {
            font-size: 13px;
            font-weight: 500;
            color: #475569;
            display: flex;
            align-items: center;
            gap: 4px;
        }

        .homeroom-teacher {
            font-weight: 700;
            color: #1e293b;
        }

        .card-body {
            padding: 12px 20px 20px 20px;
            flex-grow: 1;
            display: flex;
            flex-direction: column;
            gap: 8px;
        }

        .subject-item {
            display: flex;
            justify-content: space-between;
            align-items: center;
            padding: 6px 0;
            border-bottom: 1px solid var(--border-light);
            transition: var(--transition);
        }

        .subject-item:last-child {
            border-bottom: none;
        }

        .subject-info {
            display: flex;
            align-items: center;
            gap: 6px;
            max-width: 50%;
        }

        .subject-name {
            font-size: 13px;
            font-weight: 600;
            color: #334155;
            overflow: hidden;
            text-overflow: ellipsis;
            white-space: nowrap;
        }

        .subject-id-badge {
            font-size: 9px;
            background: #f1f5f9;
            color: #64748b;
            padding: 1px 4px;
            border-radius: 4px;
            font-family: monospace;
            border: 1px solid #e2e8f0;
        }

        .subject-teachers {
            font-size: 13px;
            font-weight: 700;
            color: #0f172a;
            text-align: right;
            max-width: 50%;
            overflow: hidden;
            text-overflow: ellipsis;
            white-space: nowrap;
        }

        /* Trạng thái Highlight tìm kiếm */
        .subject-item.highlight {
            background-color: #fef08a;
            border-radius: 6px;
            padding-left: 8px;
            padding-right: 8px;
        }

        .subject-item.highlight .subject-teachers {
            color: #b45309;
        }

        /* Trạng thái trống */
        .empty-state {
            grid-column: 1 / -1;
            padding: 60px 20px;
            text-align: center;
            color: var(--text-muted);
            background: var(--surface);
            border-radius: 16px;
            border: 1px solid var(--border);
        }

        .empty-state svg {
            width: 48px;
            height: 48px;
            stroke: #cbd5e1;
            margin-bottom: 16px;
        }

        @keyframes slideDown {
            from {
                opacity: 0;
                transform: translateY(-10px);
            }
            to {
                opacity: 1;
                transform: translateY(0);
            }
        }
    </style>
</head>
<body>

<div class="container">
    <!-- Header -->
    <header>
        <div class="logo-zone">
            <h1>🎨 ALSM Central Core</h1>
            <p>Khối 2: Quản lý & Đối soát Phân công Môn học theo Lớp</p>
        </div>
        <div class="nav-links">
            <a href="manage_schedules.php">Đối soát KHDH</a>
            <a href="manage_classes.php">Quản lý Lớp học</a>
            <a href="manage_teachers.php">Quản lý Giáo viên</a>
            <a href="manage_subjects_master.php">Sổ cái Môn học</a>
        </div>
    </header>

    <!-- Thông báo Trạng thái Đồng bộ -->
    <?php if ($status === 'success'): ?>
        <div class="alert alert-success">
            <svg width="20" height="20" fill="none" stroke="currentColor" stroke-width="2.5" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" d="M9 12l2 2 4-4m6 2a9 9 0 11-18 0 9 9 0 0118 0z"></path></svg>
            <span>Đồng bộ thành công! Đã nạp và đối soát toàn bộ <strong><?= $count ?></strong> phân công giảng dạy cho các lớp học từ vnEdu.</span>
        </div>
    <?php elseif ($status === 'mock'): ?>
        <div class="alert alert-warning">
            <svg width="20" height="20" fill="none" stroke="currentColor" stroke-width="2.5" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" d="M12 9v2m0 4h.01m-6.938 4h13.856c1.54 0 2.502-1.667 1.732-3L13.732 4c-.77-1.333-2.694-1.333-3.464 0L3.34 16c-.77 1.333.192 3 1.732 3z"></path></svg>
            <span>Một số lớp học hết hạn phiên vnEdu. Hệ thống đã tự động nạp phân công từ file dự phòng **Fail-safe Fallback** để đảm bảo đầy đủ.</span>
        </div>
    <?php elseif ($status === 'error'): ?>
        <div class="alert alert-danger">
            <svg width="20" height="20" fill="none" stroke="currentColor" stroke-width="2.5" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" d="M12 9v2m0 4h.01m-6.938 4h13.856c1.54 0 2.502-1.667 1.732-3L13.732 4c-.77-1.333-2.694-1.333-3.464 0L3.34 16c-.77 1.333.192 3 1.732 3z"></path></svg>
            <span><strong>Lỗi đồng bộ:</strong> <?= htmlspecialchars($message) ?></span>
        </div>
    <?php endif; ?>

    <!-- Bộ điều khiển đồng bộ và tìm kiếm -->
    <div class="control-panel">
        <form action="manage_class_subjects.php" method="GET" class="control-form" id="filterForm" onsubmit="return false;">
            <!-- Chọn Lớp để Lọc -->
            <div class="form-group">
                <label for="class_filter">Tìm kiếm theo lớp</label>
                <select name="class_filter" id="class_filter" onchange="filterAssignments()" style="min-width: 180px;">
                    <option value="">-- Tất cả các lớp --</option>
                    <?php foreach ($classes_list as $c): ?>
                        <option value="<?= $c['id'] ?>" <?= $filter_class == $c['id'] ? 'selected' : '' ?>>
                            Lớp <?= htmlspecialchars($c['class_name']) ?>
                        </option>
                    <?php endforeach; ?>
                </select>
            </div>

            <!-- Tìm kiếm nhanh Phân công -->
            <div class="form-group flex-grow">
                <label for="searchAssignment">Tìm kiếm môn hoặc giáo viên</label>
                <input type="text" id="searchAssignment" placeholder="Nhập tên môn học, tên giáo viên hoặc từ khóa để tìm và bôi vàng..." onkeyup="filterAssignments()">
            </div>

            <!-- Số lượng đối soát -->
            <div class="form-group" style="min-width: 140px; text-align: center;">
                <label>Số phân công CSDL</label>
                <div style="font-weight: 800; font-size: 20px; color: var(--primary); padding: 8px; border: 1px dashed var(--border); border-radius: 8px; background: #f8fafc;" id="totalCountDisplay">
                    <?= $total_assignments_count ?>
                </div>
            </div>

            <!-- Nút bấm đồng bộ lớn màu xanh lá dẫn đến sync_class_subjects.php -->
            <a href="sync_class_subjects.php" class="btn-sync">
                <span>🔄 ĐỒNG BỘ MÔN HỌC & PHÂN CÔNG TỪ VNEDU</span>
            </a>
        </form>
    </div>

    <!-- Bộ Lọc Tabs Khối Lớp -->
    <div class="grade-tabs">
        <button class="tab-btn active" data-grade="all">Tất cả các khối</button>
        <button class="tab-btn" data-grade="6">Khối 6</button>
        <button class="tab-btn" data-grade="7">Khối 7</button>
        <button class="tab-btn" data-grade="8">Khối 8</button>
        <button class="tab-btn" data-grade="9">Khối 9</button>
    </div>

    <div style="margin-bottom: 12px; font-size: 13px; font-weight: 700; color: var(--text-muted);" id="assignCount">
        Đang hiển thị: <?= count($classes_data) ?> lớp
    </div>

    <!-- Lưới Thẻ Lớp Học -->
    <div class="class-cards-grid" id="classCardsGrid">
        <?php if (empty($classes_data)): ?>
            <div class="empty-state">
                <svg fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="1.5" d="M8 7V3m8 4V3m-9 8h10M5 21h14a2 2 0 002-2V7a2 2 0 00-2-2H5a2 2 0 00-2 2v12a2 2 0 002 2z"></path></svg>
                <h3>Chưa có dữ liệu phân công môn học</h3>
                <p>Vui lòng nhấn nút ở trên để bắt đầu đồng bộ.</p>
            </div>
        <?php else: ?>
            <?php foreach ($classes_data as $class_id => $c): ?>
                <div class="class-card" data-class-id="<?= $class_id ?>" data-grade="<?= $c['grade_level'] ?>" data-class-name="<?= htmlspecialchars(strtolower($c['class_name'])) ?>">
                    <!-- Tiêu đề thẻ -->
                    <div class="card-header">
                        <div class="card-title-row">
                            <span class="class-badge"><?= htmlspecialchars($c['class_name']) ?></span>
                            <span class="student-count">👥 <?= htmlspecialchars($c['student_count']) ?> HS</span>
                        </div>
                        <div class="homeroom-row">
                            <span>Chủ nhiệm:</span>
                            <span class="homeroom-teacher"><?= htmlspecialchars($c['homeroom_teacher']) ?></span>
                        </div>
                    </div>
                    
                    <!-- Danh sách môn học -->
                    <div class="card-body">
                        <?php if (empty($c['subjects'])): ?>
                            <div style="font-size: 12px; color: var(--text-muted); text-align: center; padding: 20px 0;">
                                Chưa có phân công môn học
                            </div>
                        <?php else: ?>
                            <?php foreach ($c['subjects'] as $sub): ?>
                                <div class="subject-item">
                                    <div class="subject-info">
                                        <span><?= get_subject_emoji($sub['subject_name']) ?></span>
                                        <span class="subject-name" title="<?= htmlspecialchars($sub['subject_name']) ?>"><?= htmlspecialchars($sub['subject_name']) ?></span>
                                        <span class="subject-id-badge" title="Mã môn học"><?= htmlspecialchars($sub['subject_id']) ?></span>
                                    </div>
                                    <div class="subject-teachers" title="<?= htmlspecialchars($sub['teachers']) ?>">
                                        <?= htmlspecialchars($sub['teachers']) ?>
                                    </div>
                                </div>
                            <?php endforeach; ?>
                        <?php endif; ?>
                    </div>
                </div>
            <?php endforeach; ?>
        <?php endif; ?>
    </div>
</div>

<script>
// Logic lọc thẻ và môn học trên client-side
function filterAssignments() {
    const input = document.getElementById("searchAssignment");
    const filter = input.value.toLowerCase().trim();
    const classFilter = document.getElementById("class_filter");
    const selectedClass = classFilter.value;
    
    // Lấy tab khối lớp đang chọn
    const activeTabBtn = document.querySelector(".tab-btn.active");
    const activeGrade = activeTabBtn ? activeTabBtn.getAttribute("data-grade") : "all";
    
    const cards = document.querySelectorAll(".class-card");
    let visibleCount = 0;
    
    cards.forEach(card => {
        const cardGrade = card.getAttribute("data-grade");
        const className = card.getAttribute("data-class-name");
        const cardClassId = card.getAttribute("data-class-id");
        
        // 1. Kiểm tra lọc theo Khối lớp (Tabs)
        const matchGrade = (activeGrade === "all" || cardGrade === activeGrade);
        
        // 2. Kiểm tra lọc theo Tên lớp cụ thể (Dropdown)
        const matchClass = (!selectedClass || cardClassId === selectedClass);
        
        // 3. Kiểm tra lọc theo Từ khóa tìm kiếm (Môn học hoặc Giáo viên)
        let matchSearch = false;
        if (!filter) {
            matchSearch = true;
            // Xóa bôi màu
            card.querySelectorAll(".subject-item").forEach(item => {
                item.classList.remove("highlight");
            });
        } else {
            // Tìm kiếm trong tên lớp hành chính
            if (className.includes(filter)) {
                matchSearch = true;
            }
            
            // Tìm kiếm chi tiết trong từng dòng môn học
            const items = card.querySelectorAll(".subject-item");
            let hasMatchInCard = false;
            items.forEach(item => {
                const subjectName = item.querySelector(".subject-name").textContent.toLowerCase();
                const teachers = item.querySelector(".subject-teachers").textContent.toLowerCase();
                
                if (subjectName.includes(filter) || teachers.includes(filter)) {
                    item.classList.add("highlight");
                    hasMatchInCard = true;
                } else {
                    item.classList.remove("highlight");
                }
            });
            
            if (hasMatchInCard) {
                matchSearch = true;
            }
        }
        
        // 4. Kết hợp hiển thị thẻ
        if (matchGrade && matchClass && matchSearch) {
            card.style.display = "";
            visibleCount++;
        } else {
            card.style.display = "none";
        }
    });
    
    document.getElementById("assignCount").textContent = `Đang hiển thị: ${visibleCount} lớp`;
}

// Gán sự kiện click cho các nút Tab Khối Lớp
document.querySelectorAll(".tab-btn").forEach(btn => {
    btn.addEventListener("click", function() {
        document.querySelectorAll(".tab-btn").forEach(b => b.classList.remove("active"));
        this.classList.add("active");
        filterAssignments();
    });
});

// Chạy lọc lần đầu để áp dụng bộ lọc từ URL (nếu có)
window.addEventListener("DOMContentLoaded", () => {
    filterAssignments();
});
</script>

</body>
</html>
