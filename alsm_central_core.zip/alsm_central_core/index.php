<?php
header("Location: manage_schedules.php");
exit;
