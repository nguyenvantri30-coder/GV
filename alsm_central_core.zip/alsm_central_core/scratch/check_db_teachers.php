<?php
$host = 'localhost';
$db = 'alsm';
$user = 'root';
$pass = '';
$charset = 'utf8mb4';
$dsn = "mysql:host=$host;dbname=$db;charset=$charset";
$options = [
    PDO::ATTR_ERRMODE            => PDO::ERRMODE_EXCEPTION,
    PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
    PDO::ATTR_EMULATE_PREPARES   => false,
];
$pdo = new PDO($dsn, $user, $pass, $options);

$teachers = $pdo->query("SELECT id, full_name, citizen_id, phone FROM teachers ORDER BY full_name")->fetchAll();
echo "Total Teachers: " . count($teachers) . "\n";
echo "ID - Name - CCCD (citizen_id) - Phone\n";
foreach ($teachers as $t) {
    $cccd = $t['citizen_id'] ? $t['citizen_id'] : 'EMPTY';
    $phone = $t['phone'] ? $t['phone'] : 'EMPTY';
    echo "{$t['id']} - {$t['full_name']} - {$cccd} - {$phone}\n";
}
?>
