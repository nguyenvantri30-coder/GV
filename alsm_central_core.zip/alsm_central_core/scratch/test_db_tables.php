<?php
try {
    $p = new PDO('mysql:host=localhost;dbname=alsm;charset=utf8mb4', 'root', '');
    print_r($p->query('SHOW TABLES')->fetchAll(PDO::FETCH_COLUMN));
} catch (Exception $e) {
    echo "Error: " . $e->getMessage() . "\n";
}
