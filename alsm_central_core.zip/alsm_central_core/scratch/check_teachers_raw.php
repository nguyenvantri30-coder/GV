<?php
require_once __DIR__ . '/../legacy_vnedu/core.php';

try {
    $ss = get_valid_vnedu_session(2025);
    $namHocGoc  = intval($ss['nam_hoc']);
    $cookieFile = $ss['cookie_file_path'];

    $queryParams = [
        'call'        => 'vnedu.giaovien.api.getUser',
        '_dc'         => round(microtime(true) * 1000),
        'my_user_id'  => $ss['my_user_id'],
        'app_nam_hoc' => $namHocGoc,
        'my_token'    => $ss['my_token'],
        'nam_hoc'     => $namHocGoc,
        'page'        => 1,
        'start'       => 0,
        'limit'       => 5
    ];
    
    $apiUrl = "https://mevzecuvssitessgddaknong.vnedu.vn/v5/?" . http_build_query($queryParams);
    $headers = [
        'Accept: */*',
        'X-Requested-With: XMLHttpRequest',
        'Referer: https://mevzecuvssitessgddaknong.vnedu.vn/v5/'
    ];

    $response = vnedu_curl_request($apiUrl, 'GET', null, $headers, $cookieFile);
    $dataArray = json_decode($response, true);
    
    if (isset($dataArray['aRoot']) && !empty($dataArray['aRoot'])) {
        echo "Successfully fetched raw teachers. Total items: " . count($dataArray['aRoot']) . "\n";
        echo "Keys of the first teacher:\n";
        print_r(array_keys($dataArray['aRoot'][0]));
        echo "\nSample raw teacher data:\n";
        print_r($dataArray['aRoot'][0]);
    } else {
        echo "No data found or aRoot is empty. Response:\n";
        print_r($dataArray);
    }
} catch (Exception $e) {
    echo "Error: " . $e->getMessage() . "\n";
}
?>
