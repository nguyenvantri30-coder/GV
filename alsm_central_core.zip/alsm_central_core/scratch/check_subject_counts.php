<?php
$host = 'localhost';
$db = 'alsm';
$user = 'root';
$pass = '';
$charset = 'utf8mb4';
$dsn = "mysql:host=$host;dbname=$db;charset=$charset";
$options = [
    PDO::ATTR_ERRMODE            => PDO::ERRMODE_EXCEPTION,
    PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
    PDO::ATTR_EMULATE_PREPARES   => false,
];
$pdo = new PDO($dsn, $user, $pass, $options);

$classes = $pdo->query("SELECT id, class_name FROM classes ORDER BY class_name")->fetchAll();
foreach ($classes as $c) {
    $stmt = $pdo->prepare("SELECT COUNT(DISTINCT subject_id) FROM class_subject_assignments WHERE class_id = ?");
    $stmt->execute([$c['id']]);
    $count = $stmt->fetchColumn();
    echo "Class {$c['class_name']} ({$c['id']}) has {$count} unique subjects.\n";
}
?>
