<?php
$host = 'localhost';
$db = 'alsm';
$user = 'root';
$pass = '';
$charset = 'utf8mb4';
$dsn = "mysql:host=$host;dbname=$db;charset=$charset";
$options = [
    PDO::ATTR_ERRMODE            => PDO::ERRMODE_EXCEPTION,
    PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
    PDO::ATTR_EMULATE_PREPARES   => false,
];
$pdo = new PDO($dsn, $user, $pass, $options);

// We want to see how many subjects and assignments each class has, and print the subjects list.
$classes = $pdo->query("SELECT id, class_name FROM classes ORDER BY class_name")->fetchAll();
foreach ($classes as $c) {
    echo "=== Class {$c['class_name']} ({$c['id']}) ===\n";
    $sql = "SELECT csa.subject_id, s.subject_name, GROUP_CONCAT(t.full_name SEPARATOR ', ') as teachers
            FROM class_subject_assignments csa
            LEFT JOIN subjects s ON csa.subject_id = s.id
            LEFT JOIN teachers t ON csa.teacher_id = t.id
            WHERE csa.class_id = ?
            GROUP BY csa.subject_id
            ORDER BY s.subject_name";
    $stmt = $pdo->prepare($sql);
    $stmt->execute([$c['id']]);
    $subjects = $stmt->fetchAll();
    echo "Total subjects: " . count($subjects) . "\n";
    foreach ($subjects as $s) {
         echo "  - {$s['subject_name']} (ID: {$s['subject_id']}) taught by [{$s['teachers']}]\n";
    }
    echo "\n";
}
?>
