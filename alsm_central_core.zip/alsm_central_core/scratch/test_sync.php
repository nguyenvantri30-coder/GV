<?php
$host = 'localhost';
$db = 'alsm';
$user = 'root';
$pass = '';
$charset = 'utf8mb4';
$dsn = "mysql:host=$host;dbname=$db;charset=$charset";
$options = [
    PDO::ATTR_ERRMODE            => PDO::ERRMODE_EXCEPTION,
    PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
    PDO::ATTR_EMULATE_PREPARES   => false,
];
$pdo = new PDO($dsn, $user, $pass, $options);

// Load get_monhoc
$_GET['lop_id'] = '5003238104';
ob_start();
require_once __DIR__ . '/../legacy_vnedu/get_monhoc.php';
ob_end_clean();

$classes = $pdo->query("SELECT id, class_name FROM classes")->fetchAll();
$assignments_to_sync = [];
$success_count = 0;
$fail_count = 0;

foreach ($classes as $c) {
    $lop_id = $c['id'];
    $class_name = $c['class_name'];
    $res = get_monhoc_chuan_vnedu($lop_id, [], 2025);
    if ($res && isset($res['success']) && $res['success'] && !empty($res['data'])) {
        $success_count++;
        echo "Class {$class_name} ({$lop_id}): Success, got " . count($res['data']) . " subjects.\n";
        foreach ($res['data'] as $sub) {
            if (isset($sub['hoc']) && ($sub['hoc'] == 1 || $sub['hoc'] === true)) {
                $assignments_to_sync[] = [
                    'class_id' => $lop_id,
                    'mon_hoc_id' => $sub['mon_hoc_id'],
                    'ten_mon_hoc' => $sub['ten_mon_hoc'],
                    'gv_id_hk1' => $sub['gv_id_hk1'],
                    'gv_ten_hk1' => $sub['gv_ten_hk1']
                ];
            }
        }
    } else {
        $fail_count++;
        $err = $res['error'] ?? 'Unknown error';
        echo "Class {$class_name} ({$lop_id}): Failed - {$err}\n";
    }
}

echo "Total classes success: {$success_count}, failed: {$fail_count}\n";
echo "Total assignments scraped: " . count($assignments_to_sync) . "\n";
?>
