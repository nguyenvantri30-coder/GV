<?php
$host = 'localhost';
$db = 'alsm';
$user = 'root';
$pass = '';
$charset = 'utf8mb4';
$dsn = "mysql:host=$host;dbname=$db;charset=$charset";
$options = [
    PDO::ATTR_ERRMODE            => PDO::ERRMODE_EXCEPTION,
    PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
    PDO::ATTR_EMULATE_PREPARES   => false,
];
$pdo = new PDO($dsn, $user, $pass, $options);

$sql = "SELECT csa.*, s.subject_name, t.full_name AS teacher_name 
        FROM class_subject_assignments csa
        LEFT JOIN subjects s ON csa.subject_id = s.id
        LEFT JOIN teachers t ON csa.teacher_id = t.id
        WHERE csa.class_id = '5003238104'
        ORDER BY s.subject_name ASC";
$stmt = $pdo->query($sql);
$rows = $stmt->fetchAll();
foreach ($rows as $row) {
    echo "Subj: {$row['subject_name']} ({$row['subject_id']}) - Teacher: {$row['teacher_name']} ({$row['teacher_id']})\n";
}
?>
