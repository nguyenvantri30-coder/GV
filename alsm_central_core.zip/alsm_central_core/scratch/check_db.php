<?php
$host = 'localhost';
$db = 'alsm';
$user = 'root';
$pass = '';
$charset = 'utf8mb4';
$dsn = "mysql:host=$host;dbname=$db;charset=$charset";
$options = [
    PDO::ATTR_ERRMODE            => PDO::ERRMODE_EXCEPTION,
    PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
    PDO::ATTR_EMULATE_PREPARES   => false,
];
$pdo = new PDO($dsn, $user, $pass, $options);

echo "--- CLASSES COUNT ---\n";
$classes = $pdo->query("SELECT id, class_name, grade_level FROM classes ORDER BY grade_level, class_name")->fetchAll();
echo "Total: " . count($classes) . "\n";
foreach ($classes as $c) {
    echo "ID: {$c['id']} - Name: {$c['class_name']} - Grade: {$c['grade_level']}\n";
}

echo "\n--- ASSIGNMENTS BY CLASS ---\n";
$assigns = $pdo->query("SELECT class_id, COUNT(*) as qty FROM class_subject_assignments GROUP BY class_id")->fetchAll();
foreach ($assigns as $a) {
    echo "Class ID: {$a['class_id']} - Qty: {$a['qty']}\n";
}

$total_assigns = $pdo->query("SELECT COUNT(*) FROM class_subject_assignments")->fetchColumn();
echo "Total Assignments: {$total_assigns}\n";
?>
