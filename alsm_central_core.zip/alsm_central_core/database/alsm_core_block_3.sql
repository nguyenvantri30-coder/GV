-- =============================================================================
-- HỆ THỐNG QUẢN LÝ THÔNG MINH ALSM CENTRAL CORE
-- FILE KHỞI TẠO CƠ SỞ DỮ LIỆU: KHỐI 3 (THEO DÕI HỌC TẬP & CHẨN ĐOÁN)
-- Môi trường tương thích: MySQL 8.0+ / MariaDB 10.4+
-- =============================================================================

SET FOREIGN_KEY_CHECKS = 0;
DROP TABLE IF EXISTS `diagnostics_alerts`;
DROP TABLE IF EXISTS `student_evaluations`;
DROP TABLE IF EXISTS `student_task_grades`;
DROP TABLE IF EXISTS `class_tasks`;
DROP TABLE IF EXISTS `student_attendance`;
SET FOREIGN_KEY_CHECKS = 1;

-- =============================================================================
-- 1. BẢNG ĐIỂM DANH CHUYÊN CẦN SỐ (student_attendance)
-- =============================================================================
CREATE TABLE `student_attendance` (
    `id` BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    `student_id` BIGINT UNSIGNED NOT NULL COMMENT 'ID học sinh tham gia học',
    `schedule_id` BIGINT UNSIGNED NOT NULL COMMENT 'Liên kết lịch học tuần (Biết rõ tiết PPCT nào)',
    `status` ENUM('ATTENDED', 'ABSENT_COMPLIANT', 'ABSENT_NON_COMPLIANT') DEFAULT 'ATTENDED' 
    COMMENT 'Trạng thái (Có tham gia, Nghỉ có phép, Nghỉ không phép/Trốn học số)',
    `note` VARCHAR(255) DEFAULT NULL COMMENT 'Lý do nghỉ hoặc ghi chú hành vi số',
    `updated_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    UNIQUE KEY `uidx_student_schedule` (`student_id`, `schedule_id`),
    CONSTRAINT `fk_attendance_student` FOREIGN KEY (`student_id`) REFERENCES `students` (`id`) ON DELETE CASCADE,
    CONSTRAINT `fk_attendance_schedule` FOREIGN KEY (`schedule_id`) REFERENCES `class_schedules` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='Ghi nhận sự chuyên cần số và hành vi tham gia tiết học';

-- =============================================================================
-- 2. BẢNG NHIỆM VỤ VỀ NHÀ (class_tasks) - Giao tự động theo Tiết PPCT
-- =============================================================================
CREATE TABLE `class_tasks` (
    `id` BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    `schedule_id` BIGINT UNSIGNED NOT NULL COMMENT 'Neo trực tiếp vào Lịch học (Biết rõ bài này thuộc Tiết PPCT nào)',
    `task_type` ENUM('QUIZ', 'VIDEO', 'SUMMARY_IMAGE') NOT NULL COMMENT 'Loại nhiệm vụ (Quiz, Video, Ảnh tóm tắt)',
    `moodle_quiz_id` BIGINT UNSIGNED DEFAULT NULL COMMENT 'Mã tham chiếu ID Quiz sang Moodle nếu cần đồng bộ',
    `max_score` DECIMAL(5,2) DEFAULT 10.00 COMMENT 'Thang điểm tối đa',
    `deadline` DATETIME NOT NULL COMMENT 'Hạn chót khóa sổ làm bài',
    `is_active` TINYINT(1) DEFAULT 1 COMMENT '1: Đang giao, 0: Đóng/Hủy',
    `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    CONSTRAINT `fk_tasks_schedule` FOREIGN KEY (`schedule_id`) REFERENCES `class_schedules` (`id`) ON DELETE CASCADE,
    CONSTRAINT `chk_class_tasks_is_active` CHECK (`is_active` IN (0, 1))
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='Kho chứa đề/nhiệm vụ về nhà được bốc tự động cho lớp';

-- =============================================================================
-- 3. KHO RAW DATA TỐI CAO: KẾT QUẢ CHI TIẾT (student_task_grades)
-- =============================================================================
CREATE TABLE `student_task_grades` (
    `id` BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    `student_id` BIGINT UNSIGNED NOT NULL,
    `task_id` BIGINT UNSIGNED NOT NULL,
    `score` DECIMAL(5,2) NOT NULL COMMENT 'Điểm số thực tế đạt được',
    `wrong_questions` TEXT DEFAULT NULL COMMENT 'Chuỗi JSON hoặc text lưu danh sách mã các câu làm sai (Ví dụ: ["Q1", "Q5", "Q12"])',
    
    -- Trục băm nhỏ siêu dữ liệu (Metadata) phục vụ báo cáo vĩ mô và AI chẩn đoán
    `failed_yccd` TEXT DEFAULT NULL COMMENT 'Mã các Yêu cầu cần đạt bị hổng (Ví dụ: ["YCCD_6_MT_1", "YCCD_6_MT_3"])',
    `failed_knowledge` TEXT DEFAULT NULL COMMENT 'Danh sách mảng kiến thức bị hổng',
    `failed_competencies` TEXT DEFAULT NULL COMMENT 'Danh sách năng lực chung và đặc thù bị yếu',
    `failed_nls` TEXT DEFAULT NULL COMMENT 'Mã năng lực số bị hổng',
    `failed_ai_competency` TEXT DEFAULT NULL COMMENT 'Mã năng lực AI bị hổng',
    
    `attempt_count` TINYINT DEFAULT 1 COMMENT 'Số lần làm bài',
    `duration_seconds` INT DEFAULT 0 COMMENT 'Thời gian làm bài (tính bằng giây)',
    `submitted_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP COMMENT 'Thời điểm nộp bài thực tế',
    UNIQUE KEY `uidx_student_task` (`student_id`, `task_id`),
    CONSTRAINT `fk_grades_student` FOREIGN KEY (`student_id`) REFERENCES `students` (`id`) ON DELETE CASCADE,
    CONSTRAINT `fk_grades_task` FOREIGN KEY (`task_id`) REFERENCES `class_tasks` (`id`) ON DELETE CASCADE,
    CONSTRAINT `chk_grades_attempt_count` CHECK (`attempt_count` > 0)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='Kho lưu trữ dữ liệu thô (Raw Data) băm nhỏ siêu dữ liệu sau mỗi bài làm';

-- =============================================================================
-- 4. BẢNG TỔNG HỢP ĐÁNH GIÁ ĐỊNH KỲ VĨ MÔ (student_evaluations)
-- =============================================================================
CREATE TABLE `student_evaluations` (
    `id` BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    `student_id` BIGINT UNSIGNED NOT NULL,
    `subject_id` BIGINT UNSIGNED NOT NULL COMMENT 'Đánh giá lũy kế theo từng môn học độc lập',
    `period_type` ENUM('DAILY', 'WEEKLY', 'MONTHLY', 'YEARLY') NOT NULL COMMENT 'Trục mốc thời gian tổng hợp',
    `period_value` VARCHAR(20) NOT NULL COMMENT 'Giá trị mốc (Ví dụ: Tuần 24, Tháng 05, Năm 2026)',
    `average_score` DECIMAL(5,2) NOT NULL COMMENT 'Điểm trung bình lũy kế trong giai đoạn',
    `mastered_yccd_rate` DECIMAL(5,2) NOT NULL COMMENT 'Tỷ lệ % đạt các Yêu cầu cần đạt',
    `nls_rank` VARCHAR(10) DEFAULT NULL COMMENT 'Xếp hạng năng lực số hiện tại',
    `ai_rank` VARCHAR(10) DEFAULT NULL COMMENT 'Xếp hạng năng lực AI hiện tại',
    `summary_comment` TEXT DEFAULT NULL COMMENT 'Nhận xét tổng hợp tự động từ AI Core',
    `updated_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    UNIQUE KEY `uidx_eval_timeline` (`student_id`, `subject_id`, `period_type`, `period_value`),
    CONSTRAINT `fk_eval_student` FOREIGN KEY (`student_id`) REFERENCES `students` (`id`) ON DELETE CASCADE,
    CONSTRAINT `fk_eval_subject` FOREIGN KEY (`subject_id`) REFERENCES `subjects` (`id`) ON DELETE RESTRICT
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='Bảng lưu trữ kết quả lũy kế vĩ mô, tránh tính toán lại từ đầu';

-- =============================================================================
-- 5. BỘ MÁY THUẬT TOÁN TỐI CAO: CHẨN ĐOÁN & CẢNH BÁO SỚM (diagnostics_alerts)
-- =============================================================================
CREATE TABLE `diagnostics_alerts` (
    `id` BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    `student_id` BIGINT UNSIGNED NOT NULL,
    `task_id` BIGINT UNSIGNED DEFAULT NULL COMMENT 'Nếu cảnh báo sinh ra ngay sau 1 bài làm cụ thể',
    `alert_type` ENUM('BEHAVIOR', 'ACADEMIC', 'CRITICAL') NOT NULL COMMENT 'Loại báo động (Hành vi/Lười học, Chuyên môn/Hổng YCCĐ, Nguy cấp)',
    `alert_level` ENUM('GREEN', 'YELLOW', 'ORANGE', 'RED') DEFAULT 'GREEN' COMMENT 'Đèn tín hiệu cảnh báo xu hướng',
    `diagnosis_payload` JSON NOT NULL COMMENT 'Dữ liệu đóng gói Phiếu chẩn đoán (Lưu YCCĐ hổng, NLS yếu...) để đẩy đi',
    `is_sent_to_parent` TINYINT(1) DEFAULT 0 COMMENT '0: Chờ quét gateway, 1: Đã bắn tin đa kênh về máy Phụ huynh',
    `is_resolved` TINYINT(1) DEFAULT 0 COMMENT '1: Học sinh đã làm bù / đã khắc phục xong lỗ hổng kiến thức',
    `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    CONSTRAINT `fk_alerts_student` FOREIGN KEY (`student_id`) REFERENCES `students` (`id`) ON DELETE CASCADE,
    CONSTRAINT `fk_alerts_task` FOREIGN KEY (`task_id`) REFERENCES `class_tasks` (`id`) ON DELETE SET NULL,
    CONSTRAINT `chk_alerts_is_sent_to_parent` CHECK (`is_sent_to_parent` IN (0, 1)),
    CONSTRAINT `chk_alerts_is_resolved` CHECK (`is_resolved` IN (0, 1))
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='Kết quả chẩn đoán Real-time phục vụ kích hoạt Gateway đẩy tin Phụ huynh';