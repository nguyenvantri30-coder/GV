-- =============================================================================
-- HỆ THỐNG QUẢN LÝ THÔNG MINH ALSM CENTRAL CORE
-- FILE KHỞI TẠO CƠ SỞ DỮ LIỆU: KHỐI 4 (THI ĐUA & GAMIFICATION)
-- Môi trường tương thích: MySQL 8.0+ / MariaDB 10.4+
-- =============================================================================

SET FOREIGN_KEY_CHECKS = 0;
DROP TABLE IF EXISTS `fund_ledger`;
DROP TABLE IF EXISTS `student_emulation_points`;
DROP TABLE IF EXISTS `emulation_rules`;
SET FOREIGN_KEY_CHECKS = 1;

-- =============================================================================
-- 1. BẢNG TIÊU CHÍ THI ĐUA (emulation_rules) - Cấu hình luật thưởng phạt
-- =============================================================================
CREATE TABLE `emulation_rules` (
    `id` INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    `rule_code` VARCHAR(50) NOT NULL COMMENT 'Mã quy tắc (Ví dụ: LAM_BAI_SO_DAT_MAX, NOP_TRE, TRON_HOC_SO)',
    `rule_name` VARCHAR(150) NOT NULL COMMENT 'Tên hiển thị của tiêu chí thi đua',
    `points_modifier` INT NOT NULL COMMENT 'Số điểm cộng hoặc trừ (Ví dụ: +10, -5)',
    `rule_type` ENUM('BONUS', 'PENALTY') NOT NULL COMMENT 'Loại quy tắc (Thưởng / Phạt)',
    `description` VARCHAR(255) DEFAULT NULL COMMENT 'Mô tả chi tiết hành vi kích hoạt luật này',
    `is_active` TINYINT(1) DEFAULT 1,
    UNIQUE KEY `uidx_rule_code` (`rule_code`),
    CONSTRAINT `chk_emulation_rules_is_active` CHECK (`is_active` IN (0, 1))
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='Bộ quy tắc tự động cộng trừ điểm thi đua dựa trên hành vi số';

-- =============================================================================
-- 2. BẢNG ĐIỂM THI ĐUA SỐ TỰ ĐỘNG (student_emulation_points) - Kho tích lũy
-- =============================================================================
CREATE TABLE `student_emulation_points` (
    `id` BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    `student_id` BIGINT UNSIGNED NOT NULL,
    `rule_id` BIGINT UNSIGNED DEFAULT NULL COMMENT 'Liên kết tới luật được áp dụng (NULL nếu do GV cộng bằng tay)',
    `points_changed` INT NOT NULL COMMENT 'Số điểm biến động thực tế tại thời điểm ghi nhận',
    `current_balance` INT NOT NULL COMMENT 'Số dư điểm số tích lũy của học sinh sau khi biến động',
    
    -- Trục tầng thời gian để phục vụ Dashboard phân loại Ngày/Tuần/Tháng/Năm
    `log_date` DATE NOT NULL COMMENT 'Ngày ghi nhận biến động',
    `week_number` INT NOT NULL COMMENT 'Tuần ghi nhận biến động',
    `month_value` TINYINT NOT NULL COMMENT 'Tháng ghi nhận biến động (1 đến 12)',
    `school_year` VARCHAR(9) NOT NULL COMMENT 'Năm học tích lũy (Ví dụ: 2025-2026)',
    
    `reason` TEXT DEFAULT NULL COMMENT 'Lý do chi tiết (Ví dụ: Tự động thưởng do đạt Điểm 10 Tiết PPCT 12)',
    `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    CONSTRAINT `fk_emulation_student` FOREIGN KEY (`student_id`) REFERENCES `students` (`id`) ON DELETE CASCADE,
    CONSTRAINT `chk_emulation_week_number` CHECK (`week_number` BETWEEN 1 AND 53),
    CONSTRAINT `chk_emulation_month_value` CHECK (`month_value` BETWEEN 1 AND 12)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='Sổ cái ghi nhận điểm thi đua số tích lũy, phân loại tăng dần theo thời gian';

-- =============================================================================
-- 3. SỔ CÁI TÀI CHÍNH MINH BẠCH (fund_ledger) - Quản lý Quỹ và Đổi thưởng
-- =============================================================================
CREATE TABLE `fund_ledger` (
    `id` BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    `transaction_type` ENUM('REVENUE', 'EXPENSE') NOT NULL COMMENT 'Loại giao dịch (REVENUE: Thu quỹ / EXPENSE: Xuất quỹ đổi quà)',
    `amount` DECIMAL(12,2) NOT NULL COMMENT 'Số tiền biến động thực tế (VNĐ)',
    `points_redeemed` INT DEFAULT 0 COMMENT 'Số điểm thi đua bị trừ nếu đây là giao dịch học sinh đổi điểm lấy quà',
    `student_id` BIGINT UNSIGNED DEFAULT NULL COMMENT 'ID học sinh nhận quà (NULL nếu là giao dịch thu quỹ chung)',
    `item_name` VARCHAR(150) DEFAULT NULL COMMENT 'Tên quà tặng hoặc tên khoản thu (Ví dụ: Vở vẽ Mỹ thuật, Cọ vẽ, Quỹ phụ huynh đóng)',
    `quantity` INT DEFAULT 1 COMMENT 'Số lượng quà đổi',
    `recorded_date` DATE NOT NULL COMMENT 'Ngày thực hiện giao dịch',
    `school_year` VARCHAR(9) NOT NULL,
    `note` TEXT DEFAULT NULL COMMENT 'Ghi chú đối soát thủ công',
    `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    CONSTRAINT `fk_ledger_student` FOREIGN KEY (`student_id`) REFERENCES `students` (`id`) ON DELETE SET NULL,
    CONSTRAINT `chk_ledger_amount` CHECK (`amount` >= 0.00),
    CONSTRAINT `chk_ledger_points_redeemed` CHECK (`points_redeemed` >= 0),
    CONSTRAINT `chk_ledger_quantity` CHECK (`quantity` > 0)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='Sổ cái tài chính minh bạch quản lý dòng tiền Quỹ thu và Quỹ chi đổi quà';