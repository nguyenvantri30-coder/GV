-- =============================================================================
-- HỆ THỐNG QUẢN LÝ THÔNG MINH ALSM CENTRAL CORE
-- FILE KHỞI TẠO CƠ SỞ DỮ LIỆU: KHỐI 1 (HỒ SƠ) & KHỐI 2 (VẬN HÀNH LỚP HỌC)
-- Môi trường tương thích: MySQL 8.0+ / MariaDB 10.4+
-- =============================================================================

SET FOREIGN_KEY_CHECKS = 0;
DROP TABLE IF EXISTS `class_subject_assignments`;
DROP TABLE IF EXISTS `vnedu_sync_log`;
DROP TABLE IF EXISTS `vnedu_field_mappings`;
DROP TABLE IF EXISTS `class_schedules`;
DROP TABLE IF EXISTS `class_teachers_subjects`;
DROP TABLE IF EXISTS `class_students`;
DROP TABLE IF EXISTS `classes`;
DROP TABLE IF EXISTS `subjects`;
DROP TABLE IF EXISTS `parent_channels`;
DROP TABLE IF EXISTS `parents`;
DROP TABLE IF EXISTS `students`;
DROP TABLE IF EXISTS `teachers`;
DROP TABLE IF EXISTS `user_accounts`;
SET FOREIGN_KEY_CHECKS = 1;

-- =============================================================================
-- KHỐI 1: HỒ SƠ CƠ BẢN (CORE MASTER PROFILES)
-- =============================================================================

-- 1. Bảng tài khoản đăng nhập tập trung
CREATE TABLE `user_accounts` (
    `id` BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    `username` VARCHAR(50) NOT NULL COMMENT 'Tiền tố định danh: hs_xxx, gv_xxx, ph_xxx',
    `password_hash` VARCHAR(255) NOT NULL COMMENT 'Mật khẩu đã mã hóa',
    `role` ENUM('admin', 'teacher', 'student', 'parent') NOT NULL COMMENT 'Phân quyền hệ thống',
    `is_active` TINYINT(1) DEFAULT 1 COMMENT 'Trạng thái hoạt động (1: Bật, 0: Khóa)',
    `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    `updated_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    UNIQUE KEY `idx_username` (`username`),
    CONSTRAINT `chk_user_accounts_is_active` CHECK (`is_active` IN (0, 1))
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='Quản lý tài khoản đăng nhập tập trung cho toàn hệ thống ALSM';

-- 2. Bảng danh mục môn học tĩnh toàn trường
CREATE TABLE `subjects` (
    `id` BIGINT UNSIGNED PRIMARY KEY COMMENT 'Định danh môn học chuẩn hệ thống (Ví dụ lấy theo ID vnEdu hoặc mã tự sinh)',
    `subject_name` VARCHAR(100) NOT NULL COMMENT 'Tên môn học (Mỹ thuật, Toán, Ngữ văn...)',
    `subject_code` VARCHAR(20) DEFAULT NULL COMMENT 'Mã viết tắt của môn học (MYTHUAT, TOAN...)',
    `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    UNIQUE KEY `idx_subject_code` (`subject_code`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='Danh mục môn học tĩnh của toàn trường';

-- 3. Bảng thông tin giáo viên
CREATE TABLE `teachers` (
    `id` BIGINT UNSIGNED PRIMARY KEY COMMENT 'Khóa chính - Lấy trực tiếp ID Giáo viên của vnEdu (giandieu_id)',
    `user_id` BIGINT UNSIGNED NOT NULL COMMENT 'Liên kết sang tài khoản đăng nhập',
    `full_name` VARCHAR(100) NOT NULL COMMENT 'Họ và tên giáo viên',
    `citizen_id` VARCHAR(50) DEFAULT NULL COMMENT 'Căn cước công dân',
    `phone` VARCHAR(50) DEFAULT NULL COMMENT 'Số điện thoại liên lạc',
    `phone_number` VARCHAR(15) DEFAULT NULL COMMENT 'Số điện thoại cá nhân (cũ)',
    `email` VARCHAR(100) DEFAULT NULL COMMENT 'Thư điện tử liên lạc',
    `is_homeroom` TINYINT(1) DEFAULT 0 COMMENT '1: Có chủ nhiệm, 0: Chỉ dạy bộ môn',
    `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    `updated_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    CONSTRAINT `fk_teachers_user` FOREIGN KEY (`user_id`) REFERENCES `user_accounts` (`id`) ON DELETE RESTRICT,
    CONSTRAINT `chk_teachers_is_homeroom` CHECK (`is_homeroom` IN (0, 1))
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='Thông tin giáo viên bộ môn và chủ nhiệm';

-- 4. Bảng thông tin học sinh
CREATE TABLE `students` (
    `id` BIGINT UNSIGNED PRIMARY KEY COMMENT 'Khóa chính - Lấy trực tiếp ID Học sinh của vnEdu (hocsinh_id)',
    `user_id` BIGINT UNSIGNED NOT NULL COMMENT 'Liên kết sang tài khoản đăng nhập',
    `student_code` VARCHAR(20) DEFAULT NULL COMMENT 'Mã số học sinh của trường',
    `full_name` VARCHAR(100) NOT NULL COMMENT 'Họ và tên học sinh',
    `birthday` DATE DEFAULT NULL COMMENT 'Ngày tháng năm sinh',
    `gender` ENUM('Nam', 'Nữ') DEFAULT NULL COMMENT 'Giới tính',
    `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    `updated_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    CONSTRAINT `fk_students_user` FOREIGN KEY (`user_id`) REFERENCES `user_accounts` (`id`) ON DELETE RESTRICT
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='Thông tin học sinh toàn trường';

-- 5. Bảng phụ huynh học sinh (Thiết kế phẳng tuyệt đối 1:1)
CREATE TABLE `parents` (
    `id` BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY COMMENT 'Khóa định danh độc lập của ALSM',
    `user_id` BIGINT UNSIGNED NOT NULL COMMENT 'Liên kết sang tài khoản đăng nhập (ph_xxx)',
    `student_id` BIGINT UNSIGNED NOT NULL COMMENT 'Mối liên kết cứng 1:1 với học sinh',
    `parent_name` VARCHAR(100) DEFAULT NULL COMMENT 'Họ tên cha/mẹ/người giám hộ',
    `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    `updated_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    UNIQUE KEY `uidx_student_id` (`student_id`) COMMENT 'Ràng buộc UNIQUE triệt tiêu hoàn toàn tài khoản rác/trùng',
    CONSTRAINT `fk_parents_user` FOREIGN KEY (`user_id`) REFERENCES `user_accounts` (`id`) ON DELETE RESTRICT,
    CONSTRAINT `fk_parents_student` FOREIGN KEY (`student_id`) REFERENCES `students` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='Thông tin phụ huynh học sinh (Mô hình phẳng biệt lập 1-1)';

-- 6. Cổng kết nối đa kênh ngoài hệ thống phục vụ Gateway gửi tin
CREATE TABLE `parent_channels` (
    `id` BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    `parent_id` BIGINT UNSIGNED NOT NULL COMMENT 'Liên kết tới tài khoản phụ huynh nhận tin',
    `sms_phone` VARCHAR(15) DEFAULT NULL COMMENT 'Số điện thoại nhận SMS quảng bá/khẩn cấp',
    `zalo_user_id` VARCHAR(100) DEFAULT NULL COMMENT 'Định danh Zalo User ID (qua OA)',
    `telegram_chat_id` VARCHAR(50) DEFAULT NULL COMMENT 'Định danh Chat ID của Bot Telegram',
    `preferred_channel` ENUM('sms', 'zalo', 'telegram') DEFAULT 'zalo' COMMENT 'Kênh ưu tiên đẩy thông báo',
    `updated_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    CONSTRAINT `fk_channels_parent` FOREIGN KEY (`parent_id`) REFERENCES `parents` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='Cổng kết nối định danh phục vụ điều phối tin nhắn đa kênh';


-- =============================================================================
-- KHỐI 2: QUẢN LÝ LỚP HỌC (CLASS OPERATIONS)
-- =============================================================================

-- 1. Bảng quản lý lớp hành chính ALSM độc lập
CREATE TABLE `classes` (
    `id` BIGINT UNSIGNED PRIMARY KEY COMMENT 'Khóa chính - Lấy trực tiếp ID lớp học của vnEdu (lop_id)',
    `class_name` VARCHAR(20) NOT NULL COMMENT 'Tên lớp hành chính (Ví dụ: 6A1, 9A1...)',
    `grade_level` TINYINT NOT NULL COMMENT 'Khối lớp (6, 7, 8, 9)',
    `student_count` INT UNSIGNED DEFAULT 0 COMMENT 'Sĩ số học sinh',
    `school_year` VARCHAR(9) NOT NULL COMMENT 'Năm học hiện tại (Ví dụ: 2025-2026)',
    `homeroom_teacher_id` BIGINT UNSIGNED DEFAULT NULL COMMENT 'Giáo viên chủ nhiệm lớp',
    `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    CONSTRAINT `fk_classes_teacher` FOREIGN KEY (`homeroom_teacher_id`) REFERENCES `teachers` (`id`) ON DELETE SET NULL,
    CONSTRAINT `chk_classes_grade_level` CHECK (`grade_level` BETWEEN 1 AND 12)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='Danh sách lớp hành chính độc lập của hệ thống ALSM';

-- 2. Bảng ghi danh học sinh vào lớp hành chính (Quan hệ Nhiều - Nhiều)
CREATE TABLE `class_students` (
    `class_id` BIGINT UNSIGNED NOT NULL COMMENT 'ID lớp hành chính',
    `student_id` BIGINT UNSIGNED NOT NULL COMMENT 'ID học sinh',
    `status` TINYINT DEFAULT 1 COMMENT 'Trạng thái học (1: Đang học, 0: Chuyển lớp/Thôi học)',
    `assigned_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    PRIMARY KEY (`class_id`, `student_id`),
    CONSTRAINT `fk_cs_class` FOREIGN KEY (`class_id`) REFERENCES `classes` (`id`) ON DELETE CASCADE,
    CONSTRAINT `fk_cs_student` FOREIGN KEY (`student_id`) REFERENCES `students` (`id`) ON DELETE CASCADE,
    CONSTRAINT `chk_cs_status` CHECK (`status` IN (0, 1))
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='Bảng trung gian phân phối học sinh vào lớp hành chính';

-- 3. Sơ đồ phân công chuyên môn chéo giữa Giáo viên, Môn học và Lớp hành chính
CREATE TABLE `class_teachers_subjects` (
    `id` BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    `teacher_id` BIGINT UNSIGNED NOT NULL COMMENT 'ID giáo viên bộ môn phụ trách',
    `subject_id` BIGINT UNSIGNED NOT NULL COMMENT 'ID môn học giảng dạy',
    `class_id` BIGINT UNSIGNED NOT NULL COMMENT 'ID lớp hành chính tiếp nhận',
    `term` TINYINT NOT NULL COMMENT 'Học kỳ áp dụng (1: Học kỳ 1, 2: Học kỳ 2, 3: Cả hai)',
    `assigned_year` VARCHAR(9) NOT NULL COMMENT 'Năm học thực thi phân công',
    `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    UNIQUE KEY `uidx_teacher_subject_class` (`teacher_id`, `subject_id`, `class_id`, `assigned_year`, `term`) COMMENT 'Chặn trùng lặp phân công chéo',
    CONSTRAINT `fk_cts_teacher` FOREIGN KEY (`teacher_id`) REFERENCES `teachers` (`id`) ON DELETE RESTRICT,
    CONSTRAINT `fk_cts_subject` FOREIGN KEY (`subject_id`) REFERENCES `subjects` (`id`) ON DELETE RESTRICT,
    CONSTRAINT `fk_cts_class` FOREIGN KEY (`class_id`) REFERENCES `classes` (`id`) ON DELETE CASCADE,
    CONSTRAINT `chk_cts_term` CHECK (`term` IN (1, 2, 3))
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='Bản đồ phân công chuyên môn phẳng cho giáo viên theo môn học và lớp học';

-- 4. Kế hoạch dạy học / Lịch báo giảng theo tuần (Trục cột lõi hệ thống)
CREATE TABLE `class_schedules` (
    `id` BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    `class_id` BIGINT UNSIGNED NOT NULL COMMENT 'ID lớp hành chính làm nhiệm vụ',
    `subject_id` BIGINT UNSIGNED NOT NULL COMMENT 'ID môn học',
    `teacher_id` BIGINT UNSIGNED NOT NULL COMMENT 'ID giáo viên đứng lớp',
    `week_number` INT NOT NULL COMMENT 'Tuần thực hiện theo năm học (Ví dụ: Tuần 1, Tuần 20)',
    `period_number` INT NOT NULL COMMENT 'TIẾT PPCT (Phân phối chương trình) - THƯỚC ĐO TIẾN ĐỘ GỐC TĂNG TUYẾN TÍNH',
    `lesson_title` VARCHAR(255) DEFAULT NULL COMMENT 'Tên bài dạy thực tế (Thông tin hiển thị phụ trợ, lấy từ vnEdu)',
    `session_date` DATE NOT NULL COMMENT 'Ngày dạy kế hoạch theo lịch báo giảng',
    `day_of_week` TINYINT NOT NULL COMMENT 'Thứ trong tuần (2 đến 8)',
    `shift` ENUM('Sáng', 'Chiều') NOT NULL COMMENT 'Buổi học thực tế',
    `session_period` TINYINT NOT NULL COMMENT 'Tiết học trong buổi (Tiết 1 đến 5)',
    `status` TINYINT DEFAULT 0 COMMENT 'Trạng thái (0: Kế hoạch, 1: Đã hoàn thành/đối soát, 2: Thay đổi/Hủy bỏ)',
    `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    `updated_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    UNIQUE KEY `uidx_class_subject_period` (`class_id`, `subject_id`, `period_number`) COMMENT 'KHÓA CHẶN TỐI CAO: Bảo đảm tính tuần tự, chống nhảy tiết, chống ghi đè lỗi dữ liệu',
    CONSTRAINT `fk_schedules_class` FOREIGN KEY (`class_id`) REFERENCES `classes` (`id`) ON DELETE CASCADE,
    CONSTRAINT `fk_schedules_subject` FOREIGN KEY (`subject_id`) REFERENCES `subjects` (`id`) ON DELETE RESTRICT,
    CONSTRAINT `fk_schedules_teacher` FOREIGN KEY (`teacher_id`) REFERENCES `teachers` (`id`) ON DELETE RESTRICT,
    CONSTRAINT `chk_schedules_week_number` CHECK (`week_number` BETWEEN 1 AND 53),
    CONSTRAINT `chk_schedules_day_of_week` CHECK (`day_of_week` BETWEEN 2 AND 8),
    CONSTRAINT `chk_schedules_session_period` CHECK (`session_period` BETWEEN 1 AND 5),
    CONSTRAINT `chk_schedules_status` CHECK (`status` IN (0, 1, 2))
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='Lịch báo giảng/KHDH tuần cào từ vnEdu đầu tuần - Trục neo tiến độ chính';

-- 5. Bảng cấu hình ánh xạ trường tùy biến (Adapter Mapping) chống bẩn DB Core
CREATE TABLE `vnedu_field_mappings` (
    `id` INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    `api_type` ENUM('phan_cong', 'lich_bao_giang', 'diem') NOT NULL COMMENT 'Loại API vnEdu tương ứng',
    `vnedu_field_name` VARCHAR(100) NOT NULL COMMENT 'Tên trường tùy biến thô từ vnEdu (Ví dụ: tiet_ctgd, bai_day...)',
    `alsm_core_field` VARCHAR(100) NOT NULL COMMENT 'Tên trường ánh xạ tương ứng chuẩn ALSM Core (Ví dụ: period_number, lesson_title)',
    `description` VARCHAR(255) DEFAULT NULL COMMENT 'Ghi chú nghiệp vụ giải thích lý do mapping',
    `is_active` TINYINT(1) DEFAULT 1,
    UNIQUE KEY `uidx_api_field` (`api_type`, `vnedu_field_name`),
    CONSTRAINT `chk_field_mappings_is_active` CHECK (`is_active` IN (0, 1))
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='Bảng cấu hình Adapter Mapping phục vụ bóc tách dữ liệu thô tùy biến từ vnEdu';

-- 6. Nhật ký đồng bộ dữ liệu phục vụ cơ chế Fail-safe hệ thống
CREATE TABLE `vnedu_sync_log` (
    `id` BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    `sync_time` TIMESTAMP DEFAULT CURRENT_TIMESTAMP COMMENT 'Thời điểm thực hiện kích hoạt cào',
    `api_endpoint` VARCHAR(100) NOT NULL COMMENT 'File cào xử lý (Ví dụ: get_lichbaogiang.php)',
    `target_week` INT DEFAULT NULL COMMENT 'Tuần mục tiêu đồng bộ dữ liệu',
    `records_count` INT DEFAULT 0 COMMENT 'Số bản ghi cào và xử lý thành công',
    `status` ENUM('SUCCESS', 'FAILED', 'PARTIAL') NOT NULL COMMENT 'Trạng thái vận hành pipeline',
    `error_message` TEXT DEFAULT NULL COMMENT 'Lưu chi tiết log lỗi nếu pipeline crash để kích hoạt cảnh báo admin',
    `operator_id` BIGINT UNSIGNED DEFAULT NULL COMMENT 'ID tài khoản kích hoạt (NULL nếu là cronjob tự động đêm Chủ Nhật)'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='Nhật ký giám sát đường truyền cào dữ liệu vNedu - Kích hoạt Fail-safe vĩ mô';

-- 7. Bảng phân công môn học cho giáo viên theo lớp
CREATE TABLE `class_subject_assignments` (
    `class_id` BIGINT UNSIGNED NOT NULL,
    `subject_id` BIGINT UNSIGNED NOT NULL,
    `teacher_id` BIGINT UNSIGNED NOT NULL,
    `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    PRIMARY KEY (`class_id`, `subject_id`, `teacher_id`),
    CONSTRAINT `fk_csa_class` FOREIGN KEY (`class_id`) REFERENCES `classes` (`id`) ON DELETE CASCADE,
    CONSTRAINT `fk_csa_subject` FOREIGN KEY (`subject_id`) REFERENCES `subjects` (`id`) ON DELETE CASCADE,
    CONSTRAINT `fk_csa_teacher` FOREIGN KEY (`teacher_id`) REFERENCES `teachers` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='Bảng phân công môn học cho giáo viên theo lớp';

