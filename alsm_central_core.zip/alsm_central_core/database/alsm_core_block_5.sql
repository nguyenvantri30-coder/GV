-- =============================================================================
-- HỆ THỐNG QUẢN LÝ THÔNG MINH ALSM CENTRAL CORE
-- FILE KHỞI TẠO CƠ SỞ DỮ LIỆU: KHỐI 5 (GIÁO VIÊN & TIẾN ĐỘ)
-- Môi trường tương thích: MySQL 8.0+ / MariaDB 10.4+
-- =============================================================================

SET FOREIGN_KEY_CHECKS = 0;
DROP TABLE IF EXISTS `teacher_ops_audit`;
DROP TABLE IF EXISTS `teacher_signals`;
SET FOREIGN_KEY_CHECKS = 1;

-- =============================================================================
-- 1. BẢNG ĐÈN TÍN HIỆU & CẤU HÌNH FAIL-SAFE (teacher_signals)
-- =============================================================================
CREATE TABLE `teacher_signals` (
    `id` BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    `teacher_id` BIGINT UNSIGNED NOT NULL COMMENT 'Giáo viên tiếp nhận tín hiệu',
    `subject_id` BIGINT UNSIGNED NOT NULL COMMENT 'Môn học bộ môn quét dữ liệu',
    `target_week` INT NOT NULL COMMENT 'Tuần kế hoạch cần đối soát (Quét đêm Chủ Nhật)',
    
    -- Hệ thống đèn báo động Fail-safe phục vụ vận hành
    `signal_status` ENUM('GREEN', 'YELLOW', 'ORANGE', 'RED') DEFAULT 'GREEN' 
    COMMENT 'GREEN: Đủ KHDH; YELLOW: Thiếu học liệu; ORANGE: KHDH biến động/Lệch tiết; RED: Gãy kết nối/Chưa duyệt bài',
    
    `is_backup_activated` TINYINT(1) DEFAULT 0 COMMENT '1: Kích hoạt chế độ bốc đề dự phòng tự động của hệ thống khi GV trễ hạn',
    `alert_message` TEXT DEFAULT NULL COMMENT 'Nội dung thông báo nhắc nhở tự động gửi cho GV',
    `checked_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP COMMENT 'Thời điểm quét hệ thống (Thường là 24h đêm Chủ Nhật)',
    UNIQUE KEY `uidx_teacher_subject_week` (`teacher_id`, `subject_id`, `target_week`),
    CONSTRAINT `fk_signals_teacher` FOREIGN KEY (`teacher_id`) REFERENCES `teachers` (`id`) ON DELETE CASCADE,
    CONSTRAINT `fk_signals_subject` FOREIGN KEY (`subject_id`) REFERENCES `subjects` (`id`) ON DELETE RESTRICT,
    CONSTRAINT `chk_signals_target_week` CHECK (`target_week` BETWEEN 1 AND 53),
    CONSTRAINT `chk_signals_is_backup` CHECK (`is_backup_activated` IN (0, 1))
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='Hệ thống quét đèn tín hiệu cảnh báo sớm và kích hoạt chế độ Fail-safe cho Giáo viên';

-- =============================================================================
-- 2. BẢNG ĐỐI SOÁT CHUYÊN MÔN THỰC TẾ (teacher_ops_audit) - Camera giám sát hành vi
-- =============================================================================
CREATE TABLE `teacher_ops_audit` (
    `id` BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    `teacher_id` BIGINT UNSIGNED NOT NULL COMMENT 'GV bị đối soát',
    `schedule_id` BIGINT UNSIGNED NOT NULL COMMENT 'Neo vào tiết PPCT cụ thể trong Lịch học tuần',
    
    -- Các mốc thời gian thực tế để đo "độ giòn" và tính nghiêm túc của hành vi giao bài
    `expected_publish_time` DATETIME NOT NULL COMMENT 'Hạn chót phải giao nhiệm vụ (Ví dụ: 6h00 sáng ngày dạy theo LBG)',
    `actual_publish_time` DATETIME DEFAULT NULL COMMENT 'Thời điểm thực tế GV bấm duyệt/giao bài lên hệ thống',
    
    `audit_result` ENUM('ON_TIME', 'LATE', 'BYPASSED_BY_SYSTEM') DEFAULT 'ON_TIME' 
    COMMENT 'ON_TIME: Đúng hạn; LATE: Trễ hạn; BYPASSED_BY_SYSTEM: Hệ thống tự bốc đề thay thế do GV bỏ quên',
    
    `updated_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    UNIQUE KEY `uidx_teacher_schedule_audit` (`teacher_id`, `schedule_id`),
    CONSTRAINT `fk_audit_teacher` FOREIGN KEY (`teacher_id`) REFERENCES `teachers` (`id`) ON DELETE CASCADE,
    CONSTRAINT `fk_audit_schedule` FOREIGN KEY (`schedule_id`) REFERENCES `class_schedules` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='Bảng đối soát hành vi số, đo lường tiến độ giao bài thực tế của Giáo viên so với KHDH';