-- =============================================================================
-- HỆ THỐNG QUẢN LÝ THÔNG MINH ALSM CENTRAL CORE
-- FILE CẬP NHẬT: KHỐI 6 - BỘ NÃO MA TRẬN PL3 MÃ HÓA & KH KHO HỌC LIỆU
-- Môi trường tương thích: MySQL 8.0+ / MariaDB 10.4+
-- =============================================================================

SET FOREIGN_KEY_CHECKS = 0;
DROP TABLE IF EXISTS `class_lecture_lessons`;
DROP TABLE IF EXISTS `class_lecture_courses`;
DROP TABLE IF EXISTS `library_items`;
DROP TABLE IF EXISTS `pl3_matrix_lessons`;
DROP TABLE IF EXISTS `lecture_courses`;
SET FOREIGN_KEY_CHECKS = 1;

-- =============================================================================
-- 1. KHÓA BÀI GIẢNG / MÔN HỌC THEO KHỐI (Tương đương Moodle Course Master)
-- =============================================================================
CREATE TABLE `lecture_courses` (
    `id` BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    `moodle_course_id` BIGINT UNSIGNED DEFAULT NULL COMMENT 'ID tham chiếu gốc tương ứng trên hệ thống Moodle nếu có',
    `course_name` VARCHAR(150) NOT NULL COMMENT 'Ví dụ: Mỹ thuật Khối 6, Toán Khối 7',
    `grade_level` TINYINT NOT NULL COMMENT 'Khối lớp (6, 7, 8, 9)',
    `school_year` VARCHAR(9) NOT NULL COMMENT 'Năm học (2025-2026)',
    `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    CONSTRAINT `chk_courses_grade_level` CHECK (`grade_level` BETWEEN 1 AND 12)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='Danh mục khóa học tổng thể để neo ma trận PL3';

-- =============================================================================
-- 2. TRÁI TIM PROMPT ĐỘNG: BẢNG MA TRẬN PL3 CHI TIẾT (pl3_matrix_lessons)
-- Bảng này chứa toàn bộ các cột thuộc tính đã mã hóa sau khi nạp file PL3 của thầy
-- =============================================================================
CREATE TABLE `pl3_matrix_lessons` (
    `id` BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    `course_id` BIGINT UNSIGNED NOT NULL COMMENT 'Thuộc khóa học/môn học khối nào',
    `week` INT NOT NULL COMMENT 'Tuần học kế hoạch theo phân phối chương trình',
    `period_start` INT NOT NULL COMMENT 'Tiết PPCT bắt đầu của bài học này',
    `period_end` INT NOT NULL COMMENT 'Tiết PPCT kết thúc của bài học này (Ví dụ: Bài 2 học từ tiết 3 đến tiết 4)',
    `lesson_title` VARCHAR(255) NOT NULL COMMENT 'Tên bài học gốc (Ví dụ: Sơ lược về Mỹ thuật thời Lê)',
    
    -- Các cột thuộc tính ma trận giáo dục - Sẽ lưu trữ dạng MÃ HÓA / ĐỊNH DANH CHUẨN
    `code_yccd_bo` TEXT DEFAULT NULL COMMENT 'Mã hóa danh sách Yêu cầu cần đạt của Bộ GD&ĐT',
    `code_yccd_bai` TEXT DEFAULT NULL COMMENT 'Mã hóa danh sách Yêu cầu cần đạt chi tiết của riêng bài học này',
    `code_knowledge` TEXT DEFAULT NULL COMMENT 'Mã hóa đơn vị Kiến thức cốt lõi',
    `code_comp_general` TEXT DEFAULT NULL COMMENT 'Mã hóa Năng lực chung (Tự chủ, giao tiếp, sáng tạo...)',
    `code_comp_specific` TEXT DEFAULT NULL COMMENT 'Mã hóa Năng lực đặc thù môn học (Năng lực Mỹ thuật...)',
    `code_nls` TEXT DEFAULT NULL COMMENT 'Mã hóa các chỉ số Năng lực số liên quan',
    `code_ai` TEXT DEFAULT NULL COMMENT 'Mã hóa các chỉ số Năng lực AI tương ứng',
    `code_qualities` TEXT DEFAULT NULL COMMENT 'Mã hóa Phẩm chất chủ yếu (Yêu nước, nhân ái, chăm chỉ...)',
    
    `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    CONSTRAINT `fk_pl3_course` FOREIGN KEY (`course_id`) REFERENCES `lecture_courses` (`id`) ON DELETE CASCADE,
    CONSTRAINT `chk_pl3_week` CHECK (`week` BETWEEN 1 AND 53),
    CONSTRAINT `chk_pl3_periods` CHECK (`period_start` <= `period_end` AND `period_start` > 0)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='Kho lưu trữ Ma trận PL3 chi tiết phục vụ bốc tách thuộc tính tạo Prompt động';

-- =============================================================================
-- 3. KHO THƯ VIỆN HỌC LIỆU ĐÃ SINH (library_items) - Có gắn mã định danh PL3
-- =============================================================================
CREATE TABLE `library_items` (
    `id` BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    `pl3_lesson_id` BIGINT UNSIGNED NOT NULL COMMENT 'Neo chính xác vào bài học nào trong ma trận PL3 gốc',
    `creator_id` BIGINT UNSIGNED NOT NULL COMMENT 'ID Giáo viên đóng góp hoặc duyệt câu hỏi (Dùng để tính tỷ trọng)',
    `item_type` ENUM('QUESTION_CALCULATED', 'QUESTION_MULTIPLE', 'VIDEO') DEFAULT 'QUESTION_CALCULATED' COMMENT 'Ưu tiên Trắc nghiệm tính toán',
    `content_body` TEXT NOT NULL COMMENT 'Nội dung câu hỏi (Đã nhúng công thức biến số biến thiên)',
    `answer_metadata` JSON DEFAULT NULL COMMENT 'Cấu hình đáp án và dải biến thiên công thức (Calculated Simple)',
    
    -- Các mã định danh PL3 được AI găm thẳng vào câu hỏi khi sinh ra từ Prompt động
    `mapped_yccd` VARCHAR(50) NOT NULL COMMENT 'Mã YCCD cụ thể mà câu hỏi này đánh giá trực tiếp',
    `mapped_nls` VARCHAR(30) DEFAULT NULL COMMENT 'Mã NLS câu hỏi này bóc tách',
    `mapped_ai` VARCHAR(30) DEFAULT NULL COMMENT 'Mã Năng lực AI câu hỏi này đo lường',
    
    `difficulty_level` ENUM('RECOGNIZE', 'UNDERSTAND', 'APPLY', 'HIGH_APPLY') DEFAULT 'RECOGNIZE',
    `is_active` TINYINT(1) DEFAULT 1,
    `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    CONSTRAINT `fk_library_pl3` FOREIGN KEY (`pl3_lesson_id`) REFERENCES `pl3_matrix_lessons` (`id`) ON DELETE RESTRICT,
    CONSTRAINT `fk_library_creator` FOREIGN KEY (`creator_id`) REFERENCES `teachers` (`id`) ON DELETE RESTRICT,
    CONSTRAINT `chk_library_items_is_active` CHECK (`is_active` IN (0, 1))
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='Kho học liệu đã sinh từ AI được gắn chặt mã định danh thuộc tính từ ma trận PL3';

-- =============================================================================
-- 4. BẢNG LIÊN KẾT CHÉO PHẲNG GIỮA LỚP HÀNH CHÍNH VÀ KHÓA HỌC
-- =============================================================================
CREATE TABLE `class_lecture_courses` (
    `class_id` BIGINT UNSIGNED NOT NULL COMMENT 'ID lớp hành chính ở Khối 2',
    `course_id` BIGINT UNSIGNED NOT NULL COMMENT 'ID khóa học ở Khối 6',
    `assigned_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    PRIMARY KEY (`class_id`, `course_id`),
    CONSTRAINT `fk_clc_class` FOREIGN KEY (`class_id`) REFERENCES `classes` (`id`) ON DELETE CASCADE,
    CONSTRAINT `fk_clc_course` FOREIGN KEY (`course_id`) REFERENCES `lecture_courses` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='Liên kết phẳng một Lớp hành chính tham gia học nhiều môn học/khóa học';

-- =============================================================================
-- 5. BỘ ĐỀ ĐÓNG BĂNG CHO TỪNG TIẾT PPCT CỦA LỚP (class_lecture_lessons)
-- =============================================================================
CREATE TABLE `class_lecture_lessons` (
    `id` BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    `class_id` BIGINT UNSIGNED NOT NULL,
    `pl3_lesson_id` BIGINT UNSIGNED NOT NULL COMMENT 'Bài học tương ứng trong ma trận PL3',
    `period_number` INT NOT NULL COMMENT 'Tiết PPCT thực tế chạy bài tập này',
    `task_template_payload` JSON NOT NULL COMMENT 'Cấu trúc bộ đề trắc nghiệm tính toán hoàn chỉnh cho lớp (Đóng băng dữ liệu)',
    `generated_type` ENUM('TEACHER_PROPORTION', 'SYSTEM_FALLBACK') DEFAULT 'TEACHER_PROPORTION',
    `frozen_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    UNIQUE KEY `uidx_class_pl3_period` (`class_id`, `pl3_lesson_id`, `period_number`),
    CONSTRAINT `fk_cll_class` FOREIGN KEY (`class_id`) REFERENCES `classes` (`id`) ON DELETE CASCADE,
    CONSTRAINT `fk_cll_pl3` FOREIGN KEY (`pl3_lesson_id`) REFERENCES `pl3_matrix_lessons` (`id`) ON DELETE CASCADE,
    CONSTRAINT `chk_cll_period_number` CHECK (`period_number` > 0)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='Bộ đề trắc nghiệm tính toán chốt chặn theo tiết PPCT cụ thể của từng lớp hành chính';