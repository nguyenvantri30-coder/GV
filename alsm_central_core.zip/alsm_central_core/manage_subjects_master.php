<?php
/**
 * File: manage_subjects_master.php
 * Chức năng: Giao diện Web hiển thị Sổ cái danh mục môn học toàn trường từ bảng subjects
 */

// 1. Cấu hình kết nối cơ sở dữ liệu alsm
$host = 'localhost';
$db = 'alsm';
$user = 'root';
$pass = '';
$charset = 'utf8mb4';
$dsn = "mysql:host=$host;dbname=$db;charset=$charset";
$options = [
    PDO::ATTR_ERRMODE            => PDO::ERRMODE_EXCEPTION,
    PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
    PDO::ATTR_EMULATE_PREPARES   => false,
];

try {
    $pdo = new PDO($dsn, $user, $pass, $options);
} catch (\PDOException $e) {
    die("<div style='padding: 20px; background: #fee2e2; color: #991b1b; font-family: sans-serif; border-radius: 8px;'>
            <strong>Lỗi kết nối CSDL:</strong> " . htmlspecialchars($e->getMessage()) . "
         </div>");
}

// 2. Truy vấn danh mục môn học
try {
    $sql = "SELECT * FROM subjects ORDER BY CAST(id AS UNSIGNED) ASC";
    $stmt = $pdo->query($sql);
    $subjects = $stmt->fetchAll();
} catch (\PDOException $e) {
    die("<div style='padding: 20px; background: #fee2e2; color: #991b1b; font-family: sans-serif; border-radius: 8px;'>
            <strong>Lỗi truy vấn CSDL:</strong> " . htmlspecialchars($e->getMessage()) . "
         </div>");
}
?>
<!DOCTYPE html>
<html lang="vi">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>ALSM Central Core - Danh mục Môn học Toàn trường</title>
    <!-- Nhúng Google Font Inter -->
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700&display=swap" rel="stylesheet">
    <style>
        :root {
            --primary: #6366f1;
            --primary-hover: #4f46e5;
            --background: #f8fafc;
            --surface: #ffffff;
            --text-main: #0f172a;
            --text-muted: #64748b;
            --border: #e2e8f0;
            --accent: #0ea5e9;
            --success: #10b981;
            --shadow: 0 10px 25px -3px rgba(99, 102, 241, 0.05), 0 4px 6px -2px rgba(0, 0, 0, 0.02);
            --transition: all 0.2s cubic-bezier(0.4, 0, 0.2, 1);
        }

        * {
            box-sizing: border-box;
            margin: 0;
            padding: 0;
        }

        body {
            font-family: 'Inter', sans-serif;
            background-color: var(--background);
            color: var(--text-main);
            line-height: 1.5;
            padding: 40px 20px;
        }

        .container {
            max-width: 1000px;
            margin: 0 auto;
        }

        /* Header Style */
        header {
            margin-bottom: 30px;
            display: flex;
            justify-content: space-between;
            align-items: center;
            flex-wrap: wrap;
            gap: 15px;
        }

        .logo-zone h1 {
            font-size: 22px;
            font-weight: 800;
            color: #0f172a;
            letter-spacing: -0.5px;
            display: flex;
            align-items: center;
            gap: 8px;
        }

        .logo-zone p {
            font-size: 13px;
            color: var(--text-muted);
            margin-top: 4px;
        }

        .btn-back {
            display: inline-flex;
            align-items: center;
            gap: 8px;
            color: var(--primary);
            text-decoration: none;
            font-weight: 600;
            font-size: 14px;
            padding: 10px 18px;
            background-color: #e0e7ff;
            border-radius: 8px;
            transition: var(--transition);
            box-shadow: 0 2px 4px rgba(99, 102, 241, 0.05);
        }

        .btn-back:hover {
            background-color: var(--primary);
            color: #ffffff;
            transform: translateY(-1px);
        }

        /* Card Panel */
        .table-panel {
            background: var(--surface);
            border-radius: 16px;
            padding: 24px;
            box-shadow: var(--shadow);
            border: 1px solid var(--border);
        }

        .table-header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 20px;
            border-bottom: 1px solid var(--border);
            padding-bottom: 15px;
        }

        .table-header h2 {
            font-size: 18px;
            font-weight: 700;
            color: var(--text-main);
        }

        .badge-count {
            background-color: #f1f5f9;
            color: #475569;
            padding: 4px 10px;
            border-radius: 20px;
            font-size: 13px;
            font-weight: 600;
        }

        /* Search input */
        .search-container {
            margin-bottom: 20px;
        }

        .search-input {
            width: 100%;
            padding: 12px 16px;
            font-family: inherit;
            font-size: 14px;
            border: 1px solid var(--border);
            border-radius: 8px;
            outline: none;
            transition: var(--transition);
        }

        .search-input:focus {
            border-color: var(--primary);
            box-shadow: 0 0 0 3px rgba(99, 102, 241, 0.15);
        }

        /* Table CSS */
        .table-responsive {
            overflow-x: auto;
        }

        table {
            width: 100%;
            border-collapse: collapse;
            text-align: left;
            font-size: 14px;
        }

        th {
            background-color: #f8fafc;
            color: var(--text-muted);
            font-weight: 700;
            text-transform: uppercase;
            font-size: 12px;
            letter-spacing: 0.5px;
            padding: 14px 16px;
            border-bottom: 2px solid var(--border);
        }

        td {
            padding: 14px 16px;
            border-bottom: 1px solid var(--border);
            color: var(--text-main);
            font-weight: 500;
            transition: var(--transition);
        }

        tr:last-child td {
            border-bottom: none;
        }

        tr {
            transition: var(--transition);
        }

        tr:hover td {
            background-color: #f1f5f9;
        }

        .subject-badge {
            display: inline-block;
            background-color: #eff6ff;
            color: #2563eb;
            font-size: 12px;
            font-weight: 600;
            padding: 3px 8px;
            border-radius: 6px;
        }

        /* Empty State */
        .empty-state {
            text-align: center;
            padding: 40px 20px;
            color: var(--text-muted);
        }

        .empty-state svg {
            width: 48px;
            height: 48px;
            margin-bottom: 12px;
            color: #94a3b8;
        }

        .highlight {
            background-color: #fde047;
            color: #000000;
            padding: 1px 3px;
            border-radius: 3px;
            font-weight: 700;
        }
    </style>
</head>
<body>
    <div class="container">
        <!-- Header -->
        <header>
            <div class="logo-zone">
                <h1>🎨 ALSM CENTRAL CORE - SỔ CÁI DANH MỤC MÔN HỌC TOÀN TRƯỜNG</h1>
                <p>Danh sách các môn học chính thức đồng bộ từ hệ thống quản lý trường học vnEdu</p>
            </div>
            <div>
                <a href="manage_class_subjects.php" class="btn-back">
                    <span>⬅️ Quay lại Quản lý Lớp & Môn</span>
                </a>
            </div>
        </header>

        <!-- Main Panel -->
        <div class="table-panel">
            <div class="table-header">
                <h2>Danh sách môn học chính thức</h2>
                <span class="badge-count">Tổng số: <?= count($subjects) ?> môn</span>
            </div>

            <!-- Tìm kiếm nhanh -->
            <div class="search-container">
                <input type="text" id="quick-search" class="search-input" placeholder="Nhập tên môn học hoặc mã môn học để tìm nhanh...">
            </div>

            <div class="table-responsive">
                <?php if (empty($subjects)): ?>
                    <div class="empty-state">
                        <svg fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
                            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="1.5" d="M9.172 16.172a4 4 0 015.656 0M9 10h.01M15 10h.01M21 12a9 9 0 11-18 0 9 9 0 0118 0z"></path>
                        </svg>
                        <h3>Không tìm thấy môn học nào</h3>
                        <p>Danh sách môn học trong CSDL đang trống.</p>
                    </div>
                <?php else: ?>
                    <table id="subjects-table">
                        <thead>
                            <tr>
                                <th style="width: 80px; text-align: center;">STT</th>
                                <th style="width: 250px;">Mã Môn Học trên vnEdu (ID)</th>
                                <th>Tên Môn Học Thực Tế</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php $stt = 1; foreach ($subjects as $sub): ?>
                                <tr class="subject-row">
                                    <td style="text-align: center; color: var(--text-muted);"><?= $stt++ ?></td>
                                    <td><span class="subject-badge"><?= htmlspecialchars($sub['id']) ?></span></td>
                                    <td class="subject-name-cell"><?= htmlspecialchars($sub['subject_name']) ?></td>
                                </tr>
                            <?php endforeach; ?>
                        </tbody>
                    </table>
                <?php endif; ?>
            </div>
        </div>
    </div>

    <!-- Client-side Quick Search and Highlight Script -->
    <script>
        document.getElementById('quick-search').addEventListener('input', function(e) {
            const query = e.target.value.trim().toLowerCase();
            const rows = document.querySelectorAll('.subject-row');
            
            rows.forEach(row => {
                const badge = row.querySelector('.subject-badge');
                const nameCell = row.querySelector('.subject-name-cell');
                
                const idText = badge.textContent;
                const nameText = nameCell.textContent;
                
                const idMatch = idText.toLowerCase().includes(query);
                const nameMatch = nameText.toLowerCase().includes(query);
                
                if (idMatch || nameMatch) {
                    row.style.display = '';
                    
                    // Reset highlights
                    badge.innerHTML = escapeHTML(idText);
                    nameCell.innerHTML = escapeHTML(nameText);
                    
                    // Apply highlights if query is not empty
                    if (query !== '') {
                        if (idMatch) {
                            badge.innerHTML = highlightText(idText, query);
                        }
                        if (nameMatch) {
                            nameCell.innerHTML = highlightText(nameText, query);
                        }
                    }
                } else {
                    row.style.display = 'none';
                }
            });
        });

        function escapeHTML(str) {
            return str.replace(/&/g, '&amp;')
                      .replace(/</g, '&lt;')
                      .replace(/>/g, '&gt;')
                      .replace(/"/g, '&quot;')
                      .replace(/'/g, '&#039;');
        }

        function highlightText(text, query) {
            const index = text.toLowerCase().indexOf(query);
            if (index >= 0) {
                const originalQuery = text.substring(index, index + query.length);
                return escapeHTML(text.substring(0, index)) + 
                       '<span class="highlight">' + escapeHTML(originalQuery) + '</span>' + 
                       escapeHTML(text.substring(index + query.length));
            }
            return escapeHTML(text);
        }
    </script>
</body>
</html>
