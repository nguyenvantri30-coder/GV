<?php
/**
 * File: sync_class_subjects.php
 * Chức năng: Logic Backend đồng bộ môn học và phân công giảng dạy từ vnEdu cho TẤT CẢ 16 lớp học
 * Ràng buộc: Xử lý tách giáo viên từ môn tích hợp (dấu phẩy), bảo toàn khóa ngoại, hỗ trợ JSON fallback
 */

// 1. Cấu hình kết nối cơ sở dữ liệu alsm
$host = 'localhost';
$db = 'alsm';
$user = 'root';
$pass = '';
$charset = 'utf8mb4';
$dsn = "mysql:host=$host;dbname=$db;charset=$charset";
$options = [
    PDO::ATTR_ERRMODE            => PDO::ERRMODE_EXCEPTION,
    PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
    PDO::ATTR_EMULATE_PREPARES   => false,
];

try {
    $pdo = new PDO($dsn, $user, $pass, $options);
} catch (\PDOException $e) {
    header("Location: manage_class_subjects.php?status=error&message=" . urlencode("Kết nối Database thất bại: " . $e->getMessage()));
    exit;
}

// Helper: Đảm bảo giáo viên tồn tại trước khi phân công để tránh lỗi khóa ngoại
function ensure_teacher_exists($pdo, $teacher_id, $teacher_name) {
    if (empty($teacher_id)) return;

    // 1. Đảm bảo tài khoản user_account
    $username = "gv_" . $teacher_id;
    $stmt = $pdo->prepare("SELECT id FROM user_accounts WHERE username = ?");
    $stmt->execute([$username]);
    $user = $stmt->fetch();
    if (!$user) {
        $stmt_ins = $pdo->prepare("INSERT INTO user_accounts (username, password_hash, role, is_active) VALUES (?, ?, 'teacher', 1)");
        $stmt_ins->execute([$username, password_hash('123456', PASSWORD_DEFAULT)]);
        $user_id = $pdo->lastInsertId();
    } else {
        $user_id = $user['id'];
    }

    // 2. Đảm bảo bản ghi giáo viên
    $stmt = $pdo->prepare("SELECT id, full_name FROM teachers WHERE id = ?");
    $stmt->execute([$teacher_id]);
    $t_rec = $stmt->fetch();
    if (!$t_rec) {
        $stmt_ins = $pdo->prepare("INSERT INTO teachers (id, user_id, full_name, is_homeroom) VALUES (?, ?, ?, 0)");
        $stmt_ins->execute([$teacher_id, $user_id, !empty($teacher_name) ? $teacher_name : "Giáo viên " . $teacher_id]);
    } else {
        // Cập nhật tên đầy đủ thực tế của giáo viên nếu đang ở tên tạm
        if (!empty($teacher_name) && (strpos($t_rec['full_name'], 'Giáo viên') === 0 || empty($t_rec['full_name']))) {
            $stmt_up = $pdo->prepare("UPDATE teachers SET full_name = ? WHERE id = ?");
            $stmt_up->execute([$teacher_name, $teacher_id]);
        }
    }
}

// Helper: Đảm bảo lớp học tồn tại để tránh vi phạm khóa ngoại
function ensure_class_exists($pdo, $class_id) {
    if (empty($class_id)) return;
    $stmt = $pdo->prepare("SELECT id FROM classes WHERE id = ?");
    $stmt->execute([$class_id]);
    if (!$stmt->fetch()) {
        $stmt_ins = $pdo->prepare("INSERT INTO classes (id, class_name, grade_level, school_year) VALUES (?, ?, 6, '2025-2026')");
        $stmt_ins->execute([$class_id, "Lớp " . $class_id]);
    }
}

// 2. Nạp dữ liệu dự phòng từ file JSON trước để sẵn sàng dùng khi có lớp lỗi
$fallback_assignments = [];
$fallback_file = __DIR__ . '/legacy_vnedu/data_secure/fallback_assignments.json';
if (file_exists($fallback_file)) {
    $fallback_assignments = json_decode(file_get_contents($fallback_file), true);
    if (!is_array($fallback_assignments)) {
        $fallback_assignments = [];
    }
}

$assignments_to_sync = [];
$is_mock = false;
$error_message = null;

try {
    // Nạp file get_monhoc.php một lần duy nhất để lấy hàm
    $_GET['lop_id'] = '5003238104';
    ob_start();
    require_once __DIR__ . '/legacy_vnedu/get_monhoc.php';
    ob_end_clean();

    // Lấy toàn bộ danh sách lớp hiện có trong hệ thống
    $classes = $pdo->query("SELECT id FROM classes")->fetchAll();
    
    foreach ($classes as $c) {
        $lop_id = $c['id'];
        $got_online = false;
        
        try {
            $res = get_monhoc_chuan_vnedu($lop_id, [], 2025);
            if ($res && isset($res['success']) && $res['success'] && !empty($res['data'])) {
                $got_online = true;
                foreach ($res['data'] as $sub) {
                    // Chỉ đồng bộ các môn mà lớp thực tế có học
                    if (isset($sub['hoc']) && ($sub['hoc'] == 1 || $sub['hoc'] === true)) {
                        $assignments_to_sync[] = [
                            'class_id' => $lop_id,
                            'mon_hoc_id' => $sub['mon_hoc_id'],
                            'ten_mon_hoc' => $sub['ten_mon_hoc'],
                            'gv_id_hk1' => $sub['gv_id_hk1'],
                            'gv_ten_hk1' => $sub['gv_ten_hk1']
                        ];
                    }
                }
            }
        } catch (\Throwable $e) {
            // Ghi nhận lỗi nhưng không dừng tiến trình để lớp khác vẫn chạy được
        }

        // Nếu cào trực tiếp cho lớp này thất bại hoặc không có dữ liệu, dùng fallback cho riêng lớp đó
        if (!$got_online) {
            $is_mock = true; // Có ít nhất 1 lớp phải dùng dữ liệu fallback
            $found_in_fallback = false;
            foreach ($fallback_assignments as $f_row) {
                if (strval($f_row['class_id']) === strval($lop_id)) {
                    $assignments_to_sync[] = $f_row;
                    $found_in_fallback = true;
                }
            }
        }
    }
} catch (\Throwable $e) {
    $error_message = "Sự cố khi chuẩn bị dữ liệu: " . $e->getMessage();
}

if (empty($assignments_to_sync)) {
    header("Location: manage_class_subjects.php?status=error&message=" . urlencode("Không lấy được dữ liệu phân công từ vnEdu và không có file backup dự phòng."));
    exit;
}

// 4. Thực hiện ghi dữ liệu phân công vào CSDL
$pdo->beginTransaction();
$records_count = 0;

try {
    // Xóa sạch bảng phân công cũ để tránh trùng lặp hoặc các bản ghi thừa (stale)
    $pdo->exec("DELETE FROM class_subject_assignments");

    // Chuẩn bị các câu lệnh SQL
    $stmt_insert_subj = $pdo->prepare("INSERT INTO subjects (id, subject_name) VALUES (:mon_hoc_id, :ten_mon_hoc) ON DUPLICATE KEY UPDATE subject_name = VALUES(subject_name)");
    $stmt_insert_assign = $pdo->prepare("INSERT INTO class_subject_assignments (class_id, subject_id, teacher_id) VALUES (:class_id, :mon_hoc_id, :teacher_id) ON DUPLICATE KEY UPDATE class_id=class_id");

    foreach ($assignments_to_sync as $row) {
        $class_id = trim($row['class_id']);
        $mon_hoc_id = trim($row['mon_hoc_id']);
        $ten_mon_hoc = trim($row['ten_mon_hoc']);

        // Đảm bảo lớp học tồn tại trong CSDL
        ensure_class_exists($pdo, $class_id);

        // Nạp môn học
        $stmt_insert_subj->execute([
            ':mon_hoc_id' => $mon_hoc_id,
            ':ten_mon_hoc' => $ten_mon_hoc
        ]);

        // Phân tách danh sách giáo viên
        $teacher_ids = array_map('trim', explode(',', $row['gv_id_hk1']));
        $teacher_names = isset($row['gv_ten_hk1']) ? array_map('trim', explode(',', $row['gv_ten_hk1'])) : [];

        foreach ($teacher_ids as $k => $teacher_id) {
            if (empty($teacher_id)) continue;

            $teacher_name = isset($teacher_names[$k]) ? $teacher_names[$k] : "Giáo viên " . $teacher_id;

            // Đảm bảo giáo viên tồn tại
            ensure_teacher_exists($pdo, $teacher_id, $teacher_name);

            // Nạp phân công giảng dạy
            $stmt_insert_assign->execute([
                ':class_id' => $class_id,
                ':mon_hoc_id' => $mon_hoc_id,
                ':teacher_id' => $teacher_id
            ]);

            $records_count++;
        }
    }

    $pdo->commit();
} catch (\Throwable $e) {
    $pdo->rollBack();
    $error_message = "Lỗi ghi Database: " . $e->getMessage();
    header("Location: manage_class_subjects.php?status=error&message=" . urlencode($error_message));
    exit;
}

// 5. Chuyển hướng về lại manage_class_subjects.php
$status_type = $is_mock ? 'mock' : 'success';
header("Location: manage_class_subjects.php?status={$status_type}&count={$records_count}");
exit;
