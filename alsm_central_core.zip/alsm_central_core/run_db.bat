@echo off
SET MYSQL_PATH=D:\xampp81\mysql\bin\mysql.exe
SET DB_NAME=alsm

echo --------------------------------------------------
echo  ALSM CORE - DANG NAP TOAN BO DATABASE...
echo --------------------------------------------------

if not exist "%MYSQL_PATH%" (
    echo [LOI] Khong tim thay XAMPP81 tai %MYSQL_PATH%
    pause
    exit
)

echo -> Dang nap Khoi 1 va Khoi 2...
"%MYSQL_PATH%" -u root --default-character-set=utf8mb4 -p %DB_NAME% < database\alsm_core_blocks_1_2.sql

echo -> Dang nap Khoi 3...
"%MYSQL_PATH%" -u root --default-character-set=utf8mb4 -p %DB_NAME% < database\alsm_core_block_3.sql

echo -> Dang nap Khoi 4...
"%MYSQL_PATH%" -u root --default-character-set=utf8mb4 -p %DB_NAME% < database\alsm_core_block_4.sql

echo -> Dang nap Khoi 5...
"%MYSQL_PATH%" -u root --default-character-set=utf8mb4 -p %DB_NAME% < database\alsm_core_block_5.sql

echo -> Dang nap Khoi 6...
"%MYSQL_PATH%" -u root --default-character-set=utf8mb4 -p %DB_NAME% < database\alsm_core_block_6.sql

echo --------------------------------------------------
echo  [THANH CONG] Da quy hoach xong Khoi 1, 2, 3, 4, 5, 6!
echo --------------------------------------------------
pause