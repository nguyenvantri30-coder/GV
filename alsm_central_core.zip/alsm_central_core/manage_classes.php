<?php
/**
 * File: manage_classes.php
 * Chức năng: Giao diện Web quản lý, đối soát danh sách lớp học
 * Tích hợp tìm kiếm nhanh, hiển thị sĩ số, và lấy tên GV Chủ nhiệm (LEFT JOIN)
 */

// 1. Cấu hình kết nối cơ sở dữ liệu alsm
$host = 'localhost';
$db = 'alsm';
$user = 'root';
$pass = '';
$charset = 'utf8mb4';
$dsn = "mysql:host=$host;dbname=$db;charset=$charset";
$options = [
    PDO::ATTR_ERRMODE            => PDO::ERRMODE_EXCEPTION,
    PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
    PDO::ATTR_EMULATE_PREPARES   => false,
];

try {
    $pdo = new PDO($dsn, $user, $pass, $options);
} catch (\PDOException $e) {
    die("<div style='padding: 20px; background: #fee2e2; color: #991b1b; font-family: sans-serif; border-radius: 8px;'>
            <strong>Lỗi kết nối CSDL:</strong> " . htmlspecialchars($e->getMessage()) . "
         </div>");
}

// 2. Truy vấn danh sách lớp học kèm tên giáo viên chủ nhiệm
$sql = "SELECT c.*, t.full_name AS teacher_name 
        FROM classes c
        LEFT JOIN teachers t ON c.homeroom_teacher_id = t.id
        ORDER BY c.grade_level ASC, c.class_name ASC";
$stmt = $pdo->query($sql);
$classes = $stmt->fetchAll();

// Trạng thái đồng bộ từ URL
$status = isset($_GET['status']) ? $_GET['status'] : '';
$count = isset($_GET['count']) ? intval($_GET['count']) : 0;
$message = isset($_GET['message']) ? $_GET['message'] : '';
?>
<!DOCTYPE html>
<html lang="vi">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>ALSM Central Core - Đối soát Lớp học</title>
    <!-- Nhúng Google Font Inter -->
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700&display=swap" rel="stylesheet">
    <style>
        :root {
            --primary: #10b981; /* Màu xanh lá nổi bật theo yêu cầu nút bấm */
            --primary-hover: #059669;
            --background: #f8fafc;
            --surface: #ffffff;
            --text-main: #0f172a;
            --text-muted: #64748b;
            --border: #e2e8f0;
            --accent: #3b82f6;
            --warning: #eab308;
            --danger: #ef4444;
            --shadow: 0 10px 25px -3px rgba(16, 185, 129, 0.05), 0 4px 6px -2px rgba(0, 0, 0, 0.02);
            --transition: all 0.25s cubic-bezier(0.4, 0, 0.2, 1);
        }

        * {
            box-sizing: border-box;
            margin: 0;
            padding: 0;
        }

        body {
            font-family: 'Inter', sans-serif;
            background-color: var(--background);
            color: var(--text-main);
            line-height: 1.5;
            padding: 40px 20px;
        }

        .container {
            max-width: 1200px;
            margin: 0 auto;
        }

        /* Header Style */
        header {
            margin-bottom: 30px;
            display: flex;
            justify-content: space-between;
            align-items: center;
            flex-wrap: wrap;
            gap: 15px;
        }

        .logo-zone h1 {
            font-size: 26px;
            font-weight: 800;
            color: #0f172a;
            letter-spacing: -0.75px;
            display: flex;
            align-items: center;
            gap: 10px;
        }

        .logo-zone p {
            font-size: 14px;
            color: var(--text-muted);
            margin-top: 4px;
        }

        .nav-links {
            display: flex;
            gap: 10px;
        }

        .nav-links a {
            display: inline-flex;
            align-items: center;
            gap: 6px;
            color: var(--accent);
            text-decoration: none;
            font-weight: 600;
            font-size: 14px;
            padding: 8px 16px;
            background-color: #eff6ff;
            border-radius: 8px;
            transition: var(--transition);
        }

        .nav-links a:hover {
            background-color: #dbeafe;
        }

        /* Banner trạng thái */
        .alert {
            padding: 16px 20px;
            border-radius: 12px;
            font-size: 14px;
            font-weight: 500;
            margin-bottom: 24px;
            display: flex;
            align-items: center;
            gap: 10px;
            animation: slideDown 0.3s ease;
            box-shadow: 0 4px 6px -1px rgba(0,0,0,0.05);
        }

        .alert-success {
            background-color: #ecfdf5;
            color: #065f46;
            border: 1px solid #a7f3d0;
        }

        .alert-danger {
            background-color: #fef2f2;
            color: #991b1b;
            border: 1px solid #fecaca;
        }

        /* Panel điều khiển */
        .control-panel {
            background: var(--surface);
            border-radius: 16px;
            padding: 24px;
            box-shadow: var(--shadow);
            border: 1px solid var(--border);
            margin-bottom: 30px;
        }

        .control-form {
            display: flex;
            align-items: flex-end;
            gap: 20px;
            flex-wrap: wrap;
        }

        .form-group {
            display: flex;
            flex-direction: column;
            gap: 8px;
        }

        .form-group.flex-grow {
            flex-grow: 1;
            min-width: 250px;
        }

        .form-group label {
            font-size: 12px;
            font-weight: 700;
            color: var(--text-muted);
            text-transform: uppercase;
            letter-spacing: 0.5px;
        }

        .form-group input {
            width: 100%;
            padding: 12px 16px;
            border: 1px solid var(--border);
            border-radius: 10px;
            font-size: 14px;
            font-family: inherit;
            color: var(--text-main);
            background-color: #f8fafc;
            transition: var(--transition);
        }

        .form-group input:focus {
            outline: none;
            border-color: var(--primary);
            background-color: #fff;
            box-shadow: 0 0 0 3px rgba(16, 185, 129, 0.1);
        }

        /* Nút nhấn đồng bộ lớn màu xanh lá */
        .btn-sync {
            background-color: var(--primary);
            color: #ffffff;
            border: none;
            padding: 14px 24px;
            font-size: 15px;
            font-weight: 700;
            border-radius: 10px;
            cursor: pointer;
            display: inline-flex;
            align-items: center;
            justify-content: center;
            gap: 8px;
            transition: var(--transition);
            box-shadow: 0 4px 10px rgba(16, 185, 129, 0.2);
            height: 46px;
            text-decoration: none;
        }

        .btn-sync:hover {
            background-color: var(--primary-hover);
            transform: translateY(-1px);
            box-shadow: 0 6px 14px rgba(16, 185, 129, 0.3);
        }

        .btn-sync:active {
            transform: translateY(0);
        }

        /* Bảng danh sách */
        .table-panel {
            background: var(--surface);
            border-radius: 16px;
            box-shadow: var(--shadow);
            border: 1px solid var(--border);
            overflow: hidden;
        }

        .table-header {
            padding: 20px 24px;
            border-bottom: 1px solid var(--border);
            display: flex;
            justify-content: space-between;
            align-items: center;
            flex-wrap: wrap;
            gap: 10px;
        }

        .table-header h2 {
            font-size: 18px;
            font-weight: 700;
            color: var(--text-main);
        }

        .table-header .badge-count {
            background-color: #d1fae5;
            color: #065f46;
            padding: 4px 12px;
            border-radius: 9999px;
            font-size: 12px;
            font-weight: 700;
        }

        .table-responsive {
            overflow-x: auto;
            width: 100%;
        }

        table {
            width: 100%;
            border-collapse: collapse;
            text-align: left;
        }

        th {
            background-color: #f8fafc;
            color: var(--text-muted);
            font-size: 12px;
            font-weight: 700;
            text-transform: uppercase;
            letter-spacing: 0.5px;
            padding: 14px 24px;
            border-bottom: 1px solid var(--border);
        }

        td {
            padding: 16px 24px;
            border-bottom: 1px solid var(--border);
            font-size: 14px;
            color: var(--text-main);
            transition: var(--transition);
        }

        tr:last-child td {
            border-bottom: none;
        }

        tr:hover td {
            background-color: #f8fafc;
        }

        .badge-id {
            background-color: #f1f5f9;
            color: #334155;
            font-weight: 600;
            padding: 4px 8px;
            border-radius: 6px;
            font-family: monospace;
            font-size: 13px;
        }

        .badge-grade {
            background-color: #e0f2fe;
            color: #0369a1;
            font-weight: 700;
            padding: 4px 8px;
            border-radius: 6px;
            font-size: 13px;
        }

        .badge-student {
            background-color: #fef3c7;
            color: #92400e;
            font-weight: 700;
            padding: 4px 10px;
            border-radius: 6px;
            font-size: 13px;
        }

        /* Chế độ trống */
        .empty-state {
            padding: 60px 20px;
            text-align: center;
            color: var(--text-muted);
        }

        .empty-state svg {
            width: 48px;
            height: 48px;
            stroke: #cbd5e1;
            margin-bottom: 16px;
        }

        .empty-state h3 {
            font-size: 16px;
            font-weight: 700;
            color: #475569;
            margin-bottom: 6px;
        }

        @keyframes slideDown {
            from {
                opacity: 0;
                transform: translateY(-10px);
            }
            to {
                opacity: 1;
                transform: translateY(0);
            }
        }
    </style>
</head>
<body>

<div class="container">
    <!-- Header -->
    <header>
        <div class="logo-zone">
            <h1>🎨 ALSM Central Core</h1>
            <p>Khối 2: Quản lý & Đối soát danh sách Lớp học</p>
        </div>
        <div class="nav-links">
            <a href="manage_schedules.php">Đối soát KHDH</a>
            <a href="manage_teachers.php">Quản lý Giáo viên</a>
        </div>
    </header>

    <!-- Thông báo Trạng thái Đồng bộ -->
    <?php if ($status === 'success'): ?>
        <div class="alert alert-success">
            <svg width="20" height="20" fill="none" stroke="currentColor" stroke-width="2.5" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" d="M9 12l2 2 4-4m6 2a9 9 0 11-18 0 9 9 0 0118 0z"></path></svg>
            <span>Đồng bộ thành công! Đã đồng bộ mới/cập nhật <strong><?= $count ?></strong> lớp học từ vnEdu.</span>
        </div>
    <?php elseif ($status === 'error'): ?>
        <div class="alert alert-danger">
            <svg width="20" height="20" fill="none" stroke="currentColor" stroke-width="2.5" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" d="M12 9v2m0 4h.01m-6.938 4h13.856c1.54 0 2.502-1.667 1.732-3L13.732 4c-.77-1.333-2.694-1.333-3.464 0L3.34 16c-.77 1.333.192 3 1.732 3z"></path></svg>
            <span><strong>Lỗi đồng bộ:</strong> <?= htmlspecialchars($message) ?></span>
        </div>
    <?php endif; ?>

    <!-- Bộ điều khiển đồng bộ và tìm kiếm -->
    <div class="control-panel">
        <div class="control-form">
            <!-- Tìm kiếm nhanh Lớp học -->
            <div class="form-group flex-grow">
                <label for="searchClass">Tìm kiếm lớp học</label>
                <input type="text" id="searchClass" placeholder="Nhập tên lớp, khối, giáo viên hoặc mã lớp để lọc nhanh..." onkeyup="filterClasses()">
            </div>

            <!-- Nút bấm đồng bộ lớn màu xanh lá dẫn đến sync_classes.php -->
            <a href="sync_classes.php" class="btn-sync">
                <span>🔄 ĐỒNG BỘ DANH SÁCH LỚP HỌC TỪ VNEDU</span>
            </a>
        </div>
    </div>

    <!-- Bảng Đối soát Lớp học -->
    <div class="table-panel">
        <div class="table-header">
            <h2>Danh sách Lớp học hệ thống</h2>
            <span class="badge-count" id="classCount">Tổng cộng: <?= count($classes) ?> lớp học</span>
        </div>

        <div class="table-responsive">
            <?php if (empty($classes)): ?>
                <div class="empty-state">
                    <svg fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="1.5" d="M19 21V5a2 2 0 00-2-2H7a2 2 0 00-2 2v16m14 0h2m-2 0h-5m-9 0H3m2 0h5M9 7h1m-1 4h1m4-4h1m-1 4h1m-5 10v-5a1 1 0 011-1h2a1 1 0 011 1v5m-4 0h4"></path></svg>
                    <h3>Chưa có dữ liệu lớp học</h3>
                    <p>Vui lòng nhấn nút ở trên để đồng bộ danh sách lớp học từ vnEdu về.</p>
                </div>
            <?php else: ?>
                <table id="classesTable">
                    <thead>
                        <tr>
                            <th>Mã Lớp (vnEdu ID)</th>
                            <th>Tên lớp</th>
                            <th>Khối</th>
                            <th>Sĩ số học sinh</th>
                            <th>GV Chủ Nhiệm (Họ tên / ID gốc)</th>
                            <th>Năm học</th>
                            <th>Thời gian khởi tạo</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach ($classes as $c): ?>
                            <tr class="class-row">
                                <td>
                                    <span class="badge-id"><?= htmlspecialchars($c['id']) ?></span>
                                </td>
                                <td style="font-weight: 700; color: #1e293b;" class="col-name">
                                    Lớp <?= htmlspecialchars($c['class_name']) ?>
                                </td>
                                <td>
                                    <span class="badge-grade">Khối <?= htmlspecialchars($c['grade_level']) ?></span>
                                </td>
                                <td>
                                    <span class="badge-student"><?= htmlspecialchars($c['student_count']) ?> HS</span>
                                </td>
                                <td style="font-weight: 600; color: var(--accent);" class="col-teacher">
                                    <?php 
                                    if ($c['teacher_name']) {
                                        echo htmlspecialchars($c['teacher_name']);
                                    } elseif ($c['homeroom_teacher_id']) {
                                        echo htmlspecialchars("ID: " . $c['homeroom_teacher_id']);
                                    } else {
                                        echo '<span style="color:#64748b; font-weight:normal;">Chưa phân công</span>';
                                    }
                                    ?>
                                </td>
                                <td style="font-size: 13px; color: var(--text-muted);">
                                    <?= htmlspecialchars($c['school_year']) ?>
                                </td>
                                <td style="font-size: 13px; color: var(--text-muted);">
                                    <?= htmlspecialchars(date('d/m/Y H:i', strtotime($c['created_at']))) ?>
                                </td>
                            </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            <?php endif; ?>
        </div>
    </div>
</div>

<script>
function filterClasses() {
    const input = document.getElementById("searchClass");
    const filter = input.value.toLowerCase().trim();
    const table = document.getElementById("classesTable");
    if (!table) return;
    
    const rows = table.getElementsByClassName("class-row");
    let visibleCount = 0;
    
    for (let i = 0; i < rows.length; i++) {
        const row = rows[i];
        const nameText = row.querySelector(".col-name").textContent.toLowerCase();
        const idText = row.querySelector(".badge-id").textContent.toLowerCase();
        const teacherText = row.querySelector(".col-teacher").textContent.toLowerCase();
        
        if (nameText.includes(filter) || idText.includes(filter) || teacherText.includes(filter)) {
            row.style.display = "";
            visibleCount++;
        } else {
            row.style.display = "none";
        }
    }
    
    document.getElementById("classCount").textContent = `Tìm thấy: ${visibleCount} / ${rows.length} lớp học`;
}
</script>

</body>
</html>
