<?php
/**
 * File: manage_teachers.php
 * Chức năng: Giao diện Web quản lý, đối soát danh sách giáo viên
 * Tích hợp tìm kiếm nhanh, đồng bộ hóa động, hiển thị thông tin SĐT và CCCD
 */

// 1. Cấu hình kết nối cơ sở dữ liệu alsm
$host = 'localhost';
$db = 'alsm';
$user = 'root';
$pass = '';
$charset = 'utf8mb4';
$dsn = "mysql:host=$host;dbname=$db;charset=$charset";
$options = [
    PDO::ATTR_ERRMODE            => PDO::ERRMODE_EXCEPTION,
    PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
    PDO::ATTR_EMULATE_PREPARES   => false,
];

try {
    $pdo = new PDO($dsn, $user, $pass, $options);
} catch (\PDOException $e) {
    die("<div style='padding: 20px; background: #fee2e2; color: #991b1b; font-family: sans-serif; border-radius: 8px;'>
            <strong>Lỗi kết nối CSDL:</strong> " . htmlspecialchars($e->getMessage()) . "
         </div>");
}

// 2. Lấy danh sách giáo viên cùng tài khoản tương ứng
$sql = "SELECT t.*, u.username, u.role 
        FROM teachers t
        LEFT JOIN user_accounts u ON t.user_id = u.id
        ORDER BY t.full_name ASC";
$stmt = $pdo->query($sql);
$teachers = $stmt->fetchAll();

// Trạng thái đồng bộ từ URL
$status = isset($_GET['status']) ? $_GET['status'] : '';
$count = isset($_GET['count']) ? intval($_GET['count']) : 0;
$message = isset($_GET['message']) ? $_GET['message'] : '';
$nam_hoc_sync = isset($_GET['nam_hoc']) ? intval($_GET['nam_hoc']) : 2025;
?>
<!DOCTYPE html>
<html lang="vi">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>ALSM Central Core - Đối soát Giáo viên</title>
    <!-- Nhúng Google Font Inter -->
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700&display=swap" rel="stylesheet">
    <style>
        :root {
            --primary: #4f46e5;
            --primary-hover: #4338ca;
            --background: #f8fafc;
            --surface: #ffffff;
            --text-main: #0f172a;
            --text-muted: #64748b;
            --border: #e2e8f0;
            --accent: #0ea5e9;
            --warning: #eab308;
            --success: #10b981;
            --danger: #ef4444;
            --shadow: 0 10px 25px -3px rgba(79, 70, 229, 0.05), 0 4px 6px -2px rgba(0, 0, 0, 0.02);
            --transition: all 0.25s cubic-bezier(0.4, 0, 0.2, 1);
        }

        * {
            box-sizing: border-box;
            margin: 0;
            padding: 0;
        }

        body {
            font-family: 'Inter', sans-serif;
            background-color: var(--background);
            color: var(--text-main);
            line-height: 1.5;
            padding: 40px 20px;
        }

        .container {
            max-width: 1200px;
            margin: 0 auto;
        }

        /* Header Style */
        header {
            margin-bottom: 30px;
            display: flex;
            justify-content: space-between;
            align-items: center;
            flex-wrap: wrap;
            gap: 15px;
        }

        .logo-zone h1 {
            font-size: 26px;
            font-weight: 800;
            color: #0f172a;
            letter-spacing: -0.75px;
            display: flex;
            align-items: center;
            gap: 10px;
        }

        .logo-zone p {
            font-size: 14px;
            color: var(--text-muted);
            margin-top: 4px;
        }

        .nav-links a {
            display: inline-flex;
            align-items: center;
            gap: 6px;
            color: var(--primary);
            text-decoration: none;
            font-weight: 600;
            font-size: 14px;
            padding: 8px 16px;
            background-color: #eff6ff;
            border-radius: 8px;
            transition: var(--transition);
        }

        .nav-links a:hover {
            background-color: #dbeafe;
            color: var(--primary-hover);
        }

        /* Banner trạng thái */
        .alert {
            padding: 16px 20px;
            border-radius: 12px;
            font-size: 14px;
            font-weight: 500;
            margin-bottom: 24px;
            display: flex;
            align-items: center;
            gap: 10px;
            animation: slideDown 0.3s ease;
            box-shadow: 0 4px 6px -1px rgba(0,0,0,0.05);
        }

        .alert-success {
            background-color: #ecfdf5;
            color: #065f46;
            border: 1px solid #a7f3d0;
        }

        .alert-warning {
            background-color: #fffbeb;
            color: #92400e;
            border: 1px solid #fde68a;
        }

        .alert-danger {
            background-color: #fef2f2;
            color: #991b1b;
            border: 1px solid #fecaca;
        }

        /* Panel điều khiển */
        .control-panel {
            background: var(--surface);
            border-radius: 16px;
            padding: 24px;
            box-shadow: var(--shadow);
            border: 1px solid var(--border);
            margin-bottom: 30px;
        }

        .control-form {
            display: flex;
            align-items: flex-end;
            gap: 20px;
            flex-wrap: wrap;
        }

        .form-group {
            display: flex;
            flex-direction: column;
            gap: 8px;
        }

        .form-group.flex-grow {
            flex-grow: 1;
            min-width: 250px;
        }

        .form-group label {
            font-size: 12px;
            font-weight: 700;
            color: var(--text-muted);
            text-transform: uppercase;
            letter-spacing: 0.5px;
        }

        .form-group select, .form-group input {
            width: 100%;
            padding: 12px 16px;
            border: 1px solid var(--border);
            border-radius: 10px;
            font-size: 14px;
            font-family: inherit;
            color: var(--text-main);
            background-color: #f8fafc;
            transition: var(--transition);
        }

        .form-group select:focus, .form-group input:focus {
            outline: none;
            border-color: var(--primary);
            background-color: #fff;
            box-shadow: 0 0 0 3px rgba(79, 70, 229, 0.1);
        }

        /* Nút nhấn đồng bộ */
        .btn-sync {
            background-color: var(--primary);
            color: #ffffff;
            border: none;
            padding: 14px 24px;
            font-size: 15px;
            font-weight: 600;
            border-radius: 10px;
            cursor: pointer;
            display: inline-flex;
            align-items: center;
            justify-content: center;
            gap: 8px;
            transition: var(--transition);
            box-shadow: 0 4px 10px rgba(79, 70, 229, 0.2);
            height: 46px;
        }

        .btn-sync:hover {
            background-color: var(--primary-hover);
            transform: translateY(-1px);
            box-shadow: 0 6px 14px rgba(79, 70, 229, 0.3);
        }

        .btn-sync:active {
            transform: translateY(0);
        }

        /* Bảng danh sách */
        .table-panel {
            background: var(--surface);
            border-radius: 16px;
            box-shadow: var(--shadow);
            border: 1px solid var(--border);
            overflow: hidden;
        }

        .table-header {
            padding: 20px 24px;
            border-bottom: 1px solid var(--border);
            display: flex;
            justify-content: space-between;
            align-items: center;
            flex-wrap: wrap;
            gap: 10px;
        }

        .table-header h2 {
            font-size: 18px;
            font-weight: 700;
            color: var(--text-main);
        }

        .table-header .badge-count {
            background-color: #e0e7ff;
            color: #3730a3;
            padding: 4px 12px;
            border-radius: 9999px;
            font-size: 12px;
            font-weight: 700;
        }

        .table-responsive {
            overflow-x: auto;
            width: 100%;
        }

        table {
            width: 100%;
            border-collapse: collapse;
            text-align: left;
        }

        th {
            background-color: #f8fafc;
            color: var(--text-muted);
            font-size: 12px;
            font-weight: 700;
            text-transform: uppercase;
            letter-spacing: 0.5px;
            padding: 14px 24px;
            border-bottom: 1px solid var(--border);
        }

        td {
            padding: 16px 24px;
            border-bottom: 1px solid var(--border);
            font-size: 14px;
            color: var(--text-main);
            transition: var(--transition);
        }

        tr:last-child td {
            border-bottom: none;
        }

        tr:hover td {
            background-color: #f8fafc;
        }

        .badge-id {
            background-color: #f1f5f9;
            color: #334155;
            font-weight: 600;
            padding: 4px 8px;
            border-radius: 6px;
            font-family: monospace;
            font-size: 13px;
        }

        .badge-role {
            background-color: #eff6ff;
            color: #1e40af;
            font-weight: 600;
            padding: 2px 8px;
            border-radius: 4px;
            font-size: 12px;
        }

        .badge-homeroom {
            font-weight: 600;
            padding: 2px 8px;
            border-radius: 4px;
            font-size: 12px;
        }

        .badge-homeroom.active {
            background-color: #dcfce7;
            color: #15803d;
        }

        .badge-homeroom.inactive {
            background-color: #f1f5f9;
            color: #64748b;
        }

        /* Chế độ trống */
        .empty-state {
            padding: 60px 20px;
            text-align: center;
            color: var(--text-muted);
        }

        .empty-state svg {
            width: 48px;
            height: 48px;
            stroke: #cbd5e1;
            margin-bottom: 16px;
        }

        .empty-state h3 {
            font-size: 16px;
            font-weight: 700;
            color: #475569;
            margin-bottom: 6px;
        }

        @keyframes slideDown {
            from {
                opacity: 0;
                transform: translateY(-10px);
            }
            to {
                opacity: 1;
                transform: translateY(0);
            }
        }
    </style>
</head>
<body>

<div class="container">
    <!-- Header -->
    <header>
        <div class="logo-zone">
            <h1>🎨 ALSM Central Core</h1>
            <p>Khối 1: Quản lý & Đối soát danh sách Giáo viên</p>
        </div>
        <div class="nav-links">
            <a href="manage_schedules.php">
                <svg width="16" height="16" fill="none" stroke="currentColor" stroke-width="2.5" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" d="M10 19l-7-7m0 0l7-7m-7 7h18"></path></svg>
                Đối soát KHDH Tuần
            </a>
        </div>
    </header>

    <!-- Thông báo Trạng thái Đồng bộ -->
    <?php if ($status === 'success'): ?>
        <div class="alert alert-success">
            <svg width="20" height="20" fill="none" stroke="currentColor" stroke-width="2.5" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" d="M9 12l2 2 4-4m6 2a9 9 0 11-18 0 9 9 0 0118 0z"></path></svg>
            <span>Đồng bộ thành công! Đã cập nhật <strong><?= $count ?></strong> giáo viên từ hệ thống vnEdu năm học <strong><?= $nam_hoc_sync ?></strong>.</span>
        </div>
    <?php elseif ($status === 'mock'): ?>
        <div class="alert alert-warning">
            <svg width="20" height="20" fill="none" stroke="currentColor" stroke-width="2.5" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" d="M12 9v2m0 4h.01m-6.938 4h13.856c1.54 0 2.502-1.667 1.732-3L13.732 4c-.77-1.333-2.694-1.333-3.464 0L3.34 16c-.77 1.333.192 3 1.732 3z"></path></svg>
            <span>Phiên đăng nhập vnEdu hết hạn. Hệ thống đã tự động kích hoạt <strong>Fail-safe (Giả lập)</strong> để nạp <strong><?= $count ?></strong> giáo viên thử nghiệm.</span>
        </div>
    <?php elseif ($status === 'error'): ?>
        <div class="alert alert-danger">
            <svg width="20" height="20" fill="none" stroke="currentColor" stroke-width="2.5" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" d="M12 9v2m0 4h.01m-6.938 4h13.856c1.54 0 2.502-1.667 1.732-3L13.732 4c-.77-1.333-2.694-1.333-3.464 0L3.34 16c-.77 1.333.192 3 1.732 3z"></path></svg>
            <span><strong>Lỗi đồng bộ:</strong> <?= htmlspecialchars($message) ?></span>
        </div>
    <?php endif; ?>

    <!-- Bộ điều khiển đồng bộ và tìm kiếm -->
    <div class="control-panel">
        <form action="sync_teachers.php" method="GET" class="control-form">
            <!-- Chọn Năm Học -->
            <div class="form-group">
                <label for="nam_hoc">Năm học đồng bộ</label>
                <select name="nam_hoc" id="nam_hoc" style="min-width: 150px;">
                    <option value="2025" <?= $nam_hoc_sync == 2025 ? 'selected' : '' ?>>2025 - 2026</option>
                    <option value="2026" <?= $nam_hoc_sync == 2026 ? 'selected' : '' ?>>2026 - 2027</option>
                    <option value="2024" <?= $nam_hoc_sync == 2024 ? 'selected' : '' ?>>2024 - 2025</option>
                </select>
            </div>

            <!-- Tìm kiếm nhanh Giáo viên -->
            <div class="form-group flex-grow">
                <label for="searchTeacher">Tìm kiếm giáo viên</label>
                <input type="text" id="searchTeacher" placeholder="Nhập tên, số điện thoại, CCCD hoặc ID giáo viên để lọc nhanh..." onkeyup="filterTeachers()">
            </div>

            <!-- Nút bấm đồng bộ -->
            <button type="submit" class="btn-sync">
                <span>🔄 ĐỒNG BỘ GIÁO VIÊN từ vnEdu</span>
            </button>
        </form>
    </div>

    <!-- Bảng Đối soát Giáo viên -->
    <div class="table-panel">
        <div class="table-header">
            <h2>Danh sách Giáo viên hệ thống</h2>
            <span class="badge-count" id="teacherCount">Tổng cộng: <?= count($teachers) ?> giáo viên</span>
        </div>

        <div class="table-responsive">
            <?php if (empty($teachers)): ?>
                <div class="empty-state">
                    <svg fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="1.5" d="M12 4.354a4 4 0 110 5.292M15 21H3v-1a6 6 0 0112 0v1zm0 0h6v-1a6 6 0 00-9-5.197M13 7a4 4 0 11-8 0 4 4 0 018 0z"></path></svg>
                    <h3>Chưa có dữ liệu giáo viên</h3>
                    <p>Vui lòng nhấn nút ở trên để đồng bộ và lấy danh sách giáo viên từ vnEdu.</p>
                </div>
            <?php else: ?>
                <table id="teachersTable">
                    <thead>
                        <tr>
                            <th>Mã GV (vnEdu ID)</th>
                            <th>Họ và tên</th>
                            <th>Số CCCD</th>
                            <th>Số điện thoại</th>
                            <th>Tài khoản liên kết</th>
                            <th>Chủ nhiệm</th>
                            <th>Cập nhật lúc</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach ($teachers as $t): ?>
                            <tr class="teacher-row">
                                <td>
                                    <span class="badge-id"><?= htmlspecialchars($t['id']) ?></span>
                                </td>
                                <td style="font-weight: 700; color: #1e293b;" class="col-name">
                                    <?= htmlspecialchars($t['full_name']) ?>
                                </td>
                                <td style="font-weight: 500; font-family: monospace;" class="col-citizen">
                                    <?= htmlspecialchars($t['citizen_id'] ? $t['citizen_id'] : '—') ?>
                                </td>
                                <td style="font-weight: 600; color: var(--primary);" class="col-phone">
                                    <?= htmlspecialchars($t['phone'] ? $t['phone'] : '—') ?>
                                </td>
                                <td>
                                    <span class="badge-role"><?= htmlspecialchars($t['username'] ? $t['username'] : '—') ?></span>
                                </td>
                                <td>
                                    <span class="badge-homeroom <?= $t['is_homeroom'] ? 'active' : 'inactive' ?>">
                                        <?= $t['is_homeroom'] ? 'Có chủ nhiệm' : 'Không' ?>
                                    </span>
                                </td>
                                <td style="font-size: 13px; color: var(--text-muted);">
                                    <?= htmlspecialchars(date('d/m/Y H:i', strtotime($t['updated_at']))) ?>
                                </td>
                            </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            <?php endif; ?>
        </div>
    </div>
</div>

<script>
function filterTeachers() {
    const input = document.getElementById("searchTeacher");
    const filter = input.value.toLowerCase().trim();
    const table = document.getElementById("teachersTable");
    if (!table) return;
    
    const rows = table.getElementsByClassName("teacher-row");
    let visibleCount = 0;
    
    for (let i = 0; i < rows.length; i++) {
        const row = rows[i];
        const nameText = row.querySelector(".col-name").textContent.toLowerCase();
        const idText = row.querySelector(".badge-id").textContent.toLowerCase();
        const citizenText = row.querySelector(".col-citizen").textContent.toLowerCase();
        const phoneText = row.querySelector(".col-phone").textContent.toLowerCase();
        
        if (nameText.includes(filter) || idText.includes(filter) || citizenText.includes(filter) || phoneText.includes(filter)) {
            row.style.display = "";
            visibleCount++;
        } else {
            row.style.display = "none";
        }
    }
    
    document.getElementById("teacherCount").textContent = `Tìm thấy: ${visibleCount} / ${rows.length} giáo viên`;
}
</script>

</body>
</html>
